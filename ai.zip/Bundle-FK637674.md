# FK637674 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK637674**

## Example Bundle: FK637674

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: Informasjon til brukeren

 

# Pakningsvedlegg: Informasjon til brukeren

## NovoRapid PumpCart 100 enheter/ml injeksjonsvæske, oppløsning i sylinderampulle

### insulin aspart


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.
* Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.
* Kontakt lege, sykepleier eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om:

 

## I dette pakningsvedlegget finner du informasjon om:

1. Hva NovoRapid PumpCart er og hva det brukes mot
1. Hva du må vite før du bruker NovoRapid PumpCart
1. Hvordan du bruker NovoRapid PumpCart
1. Mulige bivirkninger
1. Hvordan du oppbevarer NovoRapid PumpCart
1. Innholdet i pakningen og ytterligere informasjon


#### 1. Hva NovoRapid PumpCart er og hva det brukes mot

 

## 1. Hva NovoRapid PumpCart er og hva det brukes mot

NovoRapid er et moderne insulin (insulinanalog) med en hurtigvirkende effekt. Moderne insulinpreparater er forbedrete versjoner av humant insulin.

NovoRapid brukes til å senke det høye blodsukkernivået hos voksne, ungdom og barn fra 1 år og oppover med diabetes mellitus (diabetes). Diabetes er en sykdom hvor kroppen ikke produserer nok insulin til å kontrollere blodsukkernivået. Behandling med NovoRapid hjelper med å forhindre komplikasjoner fra din diabetes.

NovoRapid PumpCart er til bruk i en pumpe og dekker hele ditt daglige insulinbehov: både ditt behov for insulin i løpet av dagen (basalinsulin) og ditt behov for måltidsinsulin (bolusinsulin). Før du bruker NovoRapid PumpCart i pumpen skal du ha fått en omfattende instruksjon av din lege eller sykepleier.

**Basalinsulin-behov (behov for insulin i løpet av dagen)**: Når du bruker NovoRapid PumpCart i en pumpe avgis insulinet konstant slik at den dekker ditt behov for basalinsulin. Dersom du endrer innstillingen av basalinsulinet, vil endringen begynne å påvirke deg innen 10-20 minutter. Hvis du stopper pumpen, vil insulinets effekt vare i 3 til 5 timer. Før du stiller inn eller endrer dosen med basalinsulin, les omhyggelig pumpens bruksanvisning.

**Bolusinsulin-behov (måltidsinsulinbehov)**: NovoRapid vil begynne å senke blodsukkeret ditt innen 10-20 minutter etter at du har startet en bolusinjeksjon (se avsnitt 3, Hvordan du bruker NovoRapid PumpCart, for mer informasjon om hvordan du justerer din bolusdose). Maksimal effekt inntreffer mellom 1 og 3 timer etter bolusinjeksjonen og effekten varer i 3 til 5 timer.


#### 2. Hva du må vite før du bruker NovoRapid PumpCart

 

## 2. Hva du må vite før du bruker NovoRapid PumpCart


#### 3. Hvordan du bruker NovoRapid PumpCart

 

## 3. Hvordan du bruker NovoRapid PumpCart

Dose og når skal du ta insulin
Bruk alltid insulinet og innstill basal- og bolusdoser (måltidsdoser) nøyaktig slik legen din har fortalt deg. Kontakt lege, sykepleier eller apotek hvis du er usikker. Ditt bolusinsulin (måltidsinsulin) må justeres basert på din blodsukkermåling og matinntak. Spis et måltid eller mellommåltid innen 10 minutter etter bolusdosen for å unngå lavt blodsukker. Ved behov kan du ta bolusdosen rett etter at du er ferdig med å spise.

Ikke skift insulinet ditt med mindre legen din har gitt deg beskjed om det. Skifte av insulintype eller - merke kan medføre at legen vil justere dosen.

Bruk hos barn og ungdom
NovoRapid kan brukes til ungdom og barn fra 1 år og oppover.

Bruk hos spesielle pasientgrupper
Dersom du har redusert nyre- eller leverfunksjon eller dersom du er over 65 år, må du kontrollere blodsukkeret ditt mer regelmessig og diskutere endringer av insulindosen med legen.

Hvordan og hvor skal det injiseres
NovoRapid PumpCart er kun tilpasset injisering under huden (subkutant) ved bruk av en pumpe. Du må aldri injisere direkte i en blodåre (intravenøst) eller muskel (intramuskulært). Snakk med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.

Før NovoRapid PumpCart brukes i en pumpe skal du ha en omfattende opplæring i bruk av pumpen, og du skal ha informasjon om hva som skal gjøres i tilfelle sykdom, hva som skal gjøres ved for høyt eller for lavt blodsukker eller hva som skal gjøres ved feil med pumpen. Følg legens instruksjoner og råd vedrørende bruk av NovoRapid PumpCart i pumpen.

Vanligvis injiserer du insulinet foran ved midjen (magen). Alternativt, hvis legen har anbefalt det, kan du bruke låret eller overarmen. Når du bytter infusjonssettet (kateter og nål), pass på at du bytter sted for innsetting av nålen (injeksjonssted). Dette kan redusere risikoen for utvikling av kuler eller fordypninger i huden (se avsnitt 4, Mulige bivirkninger). Bytte av infusjonssettet må utføres i henhold til instruksjonene i bruksanvisningen vedlagt infusjonssettet.

Når du bruker en insulinpumpe
For å få størst utbytte av insulininjeksjonen, og for å være sikker på at pumpen fungerer ordentlig, er det best at du måler blodsukkernivået regelmessig. Hvis du får problemer kontakt legen din.

* NovoRapid PumpCart skal kun brukes sammen med en pumpe som er utformet til bruk sammen med denne sylinderampullen, som Accu-Chek Insight og YpsoPump insulinpumper.
* NovoRapid PumpCart er en ferdigfylt sylinderampulle klar til bruk direkte i pumpen. Følg bruksanvisningen til pumpen.
* For å sikre korrekt dosering, skal NovoRapid PumpCart aldri brukes i en insulinpenn.
* Når NovoRapid brukes i en pumpe, skal den aldri blandes med noe annet legemiddel inkludert andre insulinpreparater.
* Sylinderampullen må ikke etterfylles. Når den er tom, skal den kastes.
* Ha alltid med deg en ekstra NovoRapid PumpCart.

Les nøye bruksanvisningen til NovoRapid PumpCart som inngår i dette pakningsvedlegget.

Hva skal gjøres hvis det oppstår feil med pumpen
Sørg for at du har en alternativ metode tilgjengelig for å kunne injisere insulinet under huden (for eksempel en injeksjonspenn) i tilfelle pumpen skulle slutte å virke.


#### 4. Mulige bivirkninger

 

## 4. Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.

a) Sammendrag av alvorlige og svært vanlige bivirkninger

**Lavt blodsukker (føling, hypoglykemi) **er en svært vanlig bivirkning. Den kan berøre flere enn 1 av 10 personer.

Lavt blodsukker kan inntreffe hvis du:
* Injiserer for mye insulin.
* Spiser for lite eller hopper over et måltid.
* Mosjonerer mer enn vanlig.
* Drikker alkohol (se Inntak av alkohol sammen med NovoRapid under avsnitt 2).

Symptomer på lavt blodsukker:Kaldsvetting, kald og blek hud, hodepine, hjertebank, kvalme, usedvanlig stor sultfølelse, forbigående synsforstyrrelser, døsighet, unormal tretthet og svakhet, nervøsitet eller skjelving, angst, forvirring og konsentrasjonsproblemer.

Alvorlig lavt blodsukker kan føre til bevisstløshet. Dersom langvarig alvorlig lavt blodsukker ikke behandles, kan det føre til hjerneskade (midlertidig eller livsvarig) og til og med død. Du kan komme raskere til bevissthet igjen hvis du får en injeksjon av hormonet glukagon av en person som er blitt instruert i hvordan det skal brukes. Dersom glukagon er injisert, må du så snart du kommer til bevissthet få glukose eller et sukkerholdig mellommåltid. Hvis du ikke reagerer på glukagonbehandling, må du behandles ved et sykehus.

Hva skal du gjøre hvis du får lavt blodsukker:
* Dersom du opplever lavt blodsukker, spis glukosetabletter eller et annet mellommåltid med høyt sukkerinnhold (for eksempel søtsaker, kjeks, fruktjuice) og juster insulintilførselen eller stopp pumpen. Hvis mulig, mål blodsukkeret ditt og ta en hvil. For sikkerhets skyld må du alltid ha med deg glukosetabletter eller et mellommåltid med høyt sukkerinnhold.
* Når symptomer på lavt blodsukker har forsvunnet, eller når blodsukkernivået er stabilisert, fortsettes insulinbehandlingen som vanlig.
* Dersom du får et så lavt blodsukker at du besvimer, dersom du har hatt behov for en injeksjon av glukagon, eller dersom du har hatt gjentatte episoder med lavt blodsukker skal du snakke med legen. Det kan være nødvendig å justere insulindosen, tidspunktet for insulindosering, matinntak eller mengde fysisk aktivitet.

Fortell relevante personer at du har diabetes og hva konsekvensene kan være, inkludert risikoen for å besvime (bli bevisstløs) på grunn av lavt blodsukker. La dem få vite at hvis du besvimer må de legge deg i stabilt sideleie og tilkalle lege med det samme. De må ikke gi deg noe å spise eller drikke på grunn av risiko for kvelning.

**Alvorlige allergiske reaksjoner **overfor NovoRapid eller et av innholdsstoffene i preparatet (en såkalt systemisk allergisk reaksjon) er en svært sjelden bivirkning, men kan potensielt være livstruende. Den kan berøre færre enn 1 av 10 000 personer.

Søk råd hos helsepersonell omgående:
* Dersom symptomene på allergi sprer seg til andre deler av kroppen.
* Dersom du plutselig føler deg dårlig og du: begynner å svette, blir kvalm (kaster opp), får pustebesvær, får hjertebank, føler deg svimmel.
* Dersom du merker noen av disse symptomene, søk råd hos helsepersonell omgående.

**Hudforandringer på injeksjonsstedet: **Fettvevet kan skrumpe (lipoatrofi) eller fortykkes (lipohypertrofi) (kan berøre færre enn 1 av 100 personer) hvis du injiserer insulin på samme sted. Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete, innskrumpet eller fortykket område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.

b) Liste over andre bivirkninger

**Mindre vanlige bivirkninger**

Kan berøre færre enn 1 av 100 personer.

Symptomer på allergi:Lokale allergiske reaksjoner (smerte, rødhet, elveblest, inflammasjon, blåmerker, hevelse og kløe) på injeksjonsstedet kan forekomme. Disse forsvinner vanligvis i løpet av få uker ved fortsatt bruk av insulinet. Hvis de ikke forsvinner, eller det sprer seg over hele kroppen, snakk med lege omgående. Se også Alvorlige allergiske reaksjoner ovenfor.

Synsforstyrrelser:Synsforstyrrelser kan oppstå i begynnelsen av en insulinbehandling, men er vanligvis av forbigående karakter.

Hovne ledd:Når du begynner insulinbehandlingen, kan væskeansamling forårsake hevelse rundt ankler og andre ledd. Dette er normalt av forbigående karakter, hvis ikke, snakk med legen.

Diabetisk retinopati(en øyesykdom relatert til diabetes som kan føre til synstap): Dersom du har diabetisk retinopati og blodsukkernivået ditt forbedres veldig raskt, kan retinopatien bli verre. Spør legen om dette.

Sjeldne bivirkninger
Kan berøre færre enn 1 av 1000 personer.

Smertefull neuropati(smerte som skyldes nerveskade): Hvis blodsukkernivået ditt forbedres veldig raskt kan du få en nerverelatert smerte. Dette kalles akutt smertefull neuropati og er vanligvis forbigående.

c) Følger ved diabetes
Høyt blodsukker (hyperglykemi)

Høyt blodsukker kan inntreffe hvis du:
* Ikke har injisert nok insulin.
* Glemmer å ta insulin eller avbryter behandlingen med insulin.
* Gjentatte ganger tar mindre insulin enn det du trenger.
* Får en infeksjon og/eller feber.
* Spiser mer enn vanlig.
* Mosjonerer mindre enn vanlig.

Varselsymptomer på høyt blodsukker:

Varselsymptomene utvikler seg gradvis. De inkluderer: økt vannlating, tørste, manglende appetitt, uvelhet (kvalme eller oppkast), døsighet eller tretthet, rødmende hud, tørr hud, munntørrhet og fruktluktende (acetonluktende) ånde.

Hva gjør du hvis du får høyt blodsukker:
* Dersom du får noen av symptomene nevnt ovenfor: kontroller blodsukkernivået, hvis mulig kontroller urinen for ketoner, søk deretter råd hos helsepersonell omgående.
* Dette kan være symptomer på en meget alvorlig tilstand kalt diabetisk ketoacidose (opphopning av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Dersom den ikke behandles, kan den føre til diabetisk koma og til slutt død.


#### 5. Hvordan du oppbevarer NovoRapid PumpCart

 

## 5. Hvordan du oppbevarer NovoRapid PumpCart

Oppbevares utilgjengelig for barn.

Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på sylinderampullens etikett og eske etter “EXP”. Utløpsdatoen er den siste dagen i den angitte måneden.

Oppbevar alltid sylinderampullen i ytteremballasjen når den ikke er i bruk for å beskytte mot lys.

NovoRapid PumpCart skal ved oppbevaring og bruk beskyttes mot sterk varme og lys.

**Før anbrudd: **NovoRapid PumpCart som ikke er tatt i bruk skal oppbevares i kjøleskap ved 2-8ºC, borte fra kjøleelementet. Skal ikke fryses.

**Under bruk eller medbrakt som reserve: **NovoRapid PumpCart som er tatt i bruk skal ikke oppbevares i kjøleskap. NovoRapid PumpCart som er medbrakt som reserve kan oppbevares i opptil 2 uker ved høyst 30ºC. Deretter kan den brukes i opptil 7 dager ved høyst 37ºC i en pumpe som er utformet til bruk sammen med denne sylinderampullen, som Accu-Chek Insight og YpsoPump insulinpumper. Oppbevar NovoRapid PumpCart i blisterpakningen til den skal brukes, for å beskytte den mot skade. Beskytt alltid sylinderampullen mot lys under bruk.

Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.


#### 6. Innholdet i pakningen og ytterligere informasjon

 

## 6. Innholdet i pakningen og ytterligere informasjon


####  NovoRapid PumpCart inj, oppl 100 E/ml 
LEGEMIDDELMERKEVAREID:
** ID_B6BB9798-15DA-4B87-99F9-A70679C1CA6C **
-------

Full name: **NovoRapid PumpCart inj, oppl 100 E/ml**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_6AAECC05-331B-4149-919F-F8728DB42C2D ** 

VARENUMMER: ** 043207 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK637674",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "637674"
  },
  "type" : "document",
  "timestamp" : "2023-03-20T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK637674-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK637674-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK637674-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK637674-COMP</b></p><a name=\"FK637674-COMP\"> </a><a name=\"hcFK637674-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/637674</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2023-03-20</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: NovoRapid PumpCart Novo Nordisk sylinderampuller til bruk i et pumpesystem for insulininfusjon som Accu-Chek Insight og YpsoPump insulinpumper</p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Binary #15636649</b></p><a name=\"FK637674-COMP/15636649\"> </a><a name=\"hcFK637674-COMP/15636649\"> </a><p><b>contentType</b>: image/jpeg</p><p><b>data</b>: <code>iVBORw0KGgoAAAANSUhEUgAAADYAAAAv...</code> (base64 data - 6,328 base64 chars)</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Binary #15636648</b></p><a name=\"FK637674-COMP/15636648\"> </a><a name=\"hcFK637674-COMP/15636648\"> </a><p><b>contentType</b>: image/jpeg</p><p><b>data</b>: <code>iVBORw0KGgoAAAANSUhEUgAAAVsAAAEH...</code> (base64 data - 33,388 base64 chars)</p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Binary",
        "id" : "15636649",
        "contentType" : "image/jpeg",
        "data" : "iVBORw0KGgoAAAANSUhEUgAAADYAAAAvCAIAAAAn/q7ZAAAAAXNSR0IArs4c6QAAEkNJREFUWEetWQmQVeWV/pe7vqVfr+yL4tImKLhQCiIaoSRRLBxFxaQSjTgmmtEpqywrVjKjpjJlkjJTkxhTxiWjuCviEkURUUBREBmJyCKLSMvW9Mbrt93tX+b77+tGq4a2mHFu3X79+vW7/3/uOd/5znfOpVprchQHvqQIXjTTiqZvCKGaWppQJSXjPFFEaFKuhVSJtganWinb+WalVYbiOqGkoNRS1NaEMUIYTdczB5VYgXJKCMcfR7IE3z+qAxfDIqoZxVJ64NT4BFfHIVNSJ7Knr1aj3vodhzZ/UbPzLVoqWwmiYQMVigrcD7NwJxQXmZPhlLDb2HZk4+qWHa2JZhV4zLjPWJteaK6lWlv4LYRt80wh8/gLH/zu/ud//Yendh0gUnN4SyWJ8TizE8XgN3jRmJj6TxMu4cz0ryP67/9sYn1BY6050l8yjKQmOzqSPy98ee2W7uXrOv748OJKABstgyNFGHcSQWAQRQAGLgMCzCcD8R7ayqP2oiZfBa3BI2JlNlMqEdr2ixG5508PEyvn+E35pjGLX13x4Sef1aRFLQ8XcnhO4y7wBneFtYyhqVNTUH8t1o7axK/4zNg1ECCzi+S29uy31+1a8/G2TK5QLZZK1UhS/8mXln/eXZPUlhK3oy2ENPWYSVD8mCO97dSraQoe+ThqE1O3pcsYs5C89QjjQ+FkDlTJfY8+6xda9u/ednL7GCYq+ULDWx98svrjz0NCwsTY4lCd5r/xWeo5jb2RKXhNvfjNTYRpWgktsIkishZFsFTIBLv3BOTVdzZu3N1ZDIIRBeuWBZdNnXSsEiHLD/+3exfu6dFBjCskVwlO21iEA0nDLEpsSvBKgRb1jU00CwBHjERJBM9lfBdI19ROqLW/P/njw09kG1uiWvmC6ZNnT2u749ZrLF0LokTw7H1/fcpvzAVBwrgNxoIxqcfq8FNIHkO0X0vNRx1ogxcNik3xY4hHJGBc+1CVvLB01Z6eitS6rSlzxZwZI3LkhNFk5vRJMkaaW0uWv/fp51ViZ0xItdIiSgMNsqrDULI0p+HUb4xFY5lBoe26cGYSxoywmJD1m3Y9+uQLnpcrde275IJzpk+ZYONbUXzrP13dPrYlKh2KJHvgicXFmAjuplhJaTIlSDB/mi/1cjXk8b/wIr6aCFjFURW4Up5NOnvJS6+tjqSjYjHlpAnXzpvjW8jwOGMnE0bwH1w0gwaHmO0vWblu2dqtEYctFmemlpgYA4ADhaPuzm+MxXpJkUIC1gCP77giIqvXblmxegNnPpf6x5ddfNwIhmqniPJ8iybiyu+effqJY4Mw6o/pky+/ubuLKGYR26lbM8CL5q3B5f9PdYFptmUr4BuZQujuXZ2vLXv3UFnGoZo5/ezvTjvZCrUUyHrjSJfG4wrkhh9c6rqecvIbtu99adl7yGzQVN2L+J1S96BtA1XxCOGuB3rQz+nvw35PM8N4rf6NRMMLjFOZKF2W5PW12z7a3JHzs8c2OT+ac+6IRuI6VBiAeqFyhbaiKLr4wslTJh4naxVCvSXL1+zrkaG0gROzLAiVogAO8uTQaESWYX/oJcTHJBkswpmWTvOR+RSv5hOKBKkmgRJVSenGg+SuB16MeJ7L5IJJY2dNHC4DsvdAcV9XdctnnQf6RMfBUk+5H7lx28+uGeYzh/vbPute+Pzyqob0IkKF0G6xCiJp+FXKVOgNcUCKHC7lHClmDE4LSR3Q6VvcBjCuA1mBGuPKKqvMTXc/u/z9zTKojW+0/3LnjWedOm5rR98Djz/bU1PE9rltNWVY0vfZPb+9sxSSR59d8/sHF8OckU32/b//xYxTG5kKEyIsZsegdMJcaDxkuIHpkQN9uJqnJPAlbuvWmppqZJjSGSmdRHE7896Hm5cuXyZE2WHlS+eeN2nKuBoj3YK+umbja+u2rdh88OkV2xet3Lp8zcYgJK4ml86edtpJ4zO+s78/ennFuu6ituHWKLBIQrmjmQtFnHrqyJ4EFoEGY+VA1R28jZSr6mqh/h/4FPLTO1DUj7+4zMqgYPRPah915aWzAHSEjWXzJUGVk4tYJiHZ3oCeftYMzyceJ+OGkcvnnNfgU1z1zN+Wv7N+ayiZTW0BBZzqRyOaTOU58gHpa+xI9eqX1tU5YbABqGcUlvG04z33xgfvb/rCzTfl8/4Vc2eOa7NNHbMJ96wE6pqyShDxXIHaftuI0XFMbKIdTWZOPXnalInasvsT/vTfVuzcW+ZOlkuKlgE8FiUxswf48n+aCZzV9WmKwi+NTJkVSWIIJpVQyD7X2t1Nnn3lrWpCu7sOnnFy+0Uzp3MZURHCTN8hTAkVV5NaEYzjkFjLBK5BwuF1VCubP3eWzxLXsVev3/LG6o3lwLL8RmgfGQVKIV++xoupyjflCG/qBG2sHkzrQR+DIEqKPLJ46c59PYQ5jRlv/tzvNXnMBerROinSiJhS6eo4bwtP9vu6mnO4A5GIdRmxtTz71FGXzJpK4lpi5Ra98cFH27sUEoSaFUC3kQCfDhVoyDaj3AasMwYqaSSyqXVGIeFSRWlMyY495KlFr2Y9107Kl5w/de75Jwb9fWAk7qD4Egf1DVGDALddkcRUy4ZcDpczCwUTCRfnXXLd/ItGNTotza0bt3+x9L1NPSGusxxu2WgggYkhTSQ8dWFqZRpvIWIhokq1hDQRSsfSmHyoQh587LlqIOwkGOmr2386P6dIS2NehJEpvUhOULaXi7UtqBfFOklU27Bh4NW0CVC2A7iSMY1swZUXlYu9rSPH3/vYi2s2F7Ey546Ik6znDxXplLoHcVD/kuc4vb29TYVm1CiJdsjOBJqs3bDjzZXrXK/Qs2/PDdfMb/EQOyFFZOXzxtOK+D455tgJ2UJbrD1BPNvN+5ksPMjTPlokSIlwRBOdM2taS4ZUS31OvvnPCxcVE2DWhmqjQONQXhzMkoF7SEOc5LJZdOdgEkr9Sqx7yuSJRa/2lWUtUGeedurlc76TdxTTkUBsCRWMRYmR+GPGjCM8U4stqX3Ks4ixAYqMQRqWZcFMWHvcKH7XbTeSqOhkslu/6Hr57U9LCbFtH3EcqsBA9dUbzgGiNiQXhrlcPozgGhs1lznsjZUfvrduY2tbqxbhjT9dkM+a/MaF1HHDRDLUXCmIIM1ZN65WIIcoY1KKfC5jMhr/QrwthyEnsGhEZk0bP+P0E0RQ7OzuRscDRCLYYZAMJXcMcdZT2FSWlMMdyxaJzPgNIXQoIcjgx55ZopmfBJXpZ0065+wxtcCwESS4RONhOSAClxFHktaMo8NyxgEB0TiqNDXm4FrLhv8AGWa5HkPqWqTZIzcvmFdwjYroqohFr2840CO9XO5rAp1Sd11iGmhr23HSRXmc0Jog/7lw8c6ObtvxG9zoZz+ei4Yo45nBDGp/HCYO5Rgy+MwC2kc25xyaeA40IVAScGI4gXKLcMcgDZlhoXoTcOHk9tFnTj5+eEu+Gqs//OXR3fv60pZmCNKB4kgHRiY3BiQPIY7tBmFiO976DXteXvKW7bdgz8svnDrzzOGWBIUbZYErbIJMxkwH6sVs3JLzuA6URB8TWo7KZSyZhFhdcxevpmPERQqMXmvwyPU/nHfC+JFhlFRi+l+f7OjtH1LroLlhzAgZ6AQsUR8UoMXAGwuRePqlpTF1dRKNbs1fNe9CfM93QVLGKcyyPA/zELAhlBrIVGddMjKTDOf94zPBMQU2Zngz4wyNrNaJlhE6PZuBgaUZSIjk9PbWs749fkSeNeb8u+996P0te9B3JfgmwIVWGEpQ4NVQM7/zF79i1EIHlkiF/wPpHFsClq7z2ruf3vPX5/1Ca9DTefvN15571rhUAKeDE6QIbg2Gcky9BPg5TCCsotEt+dOOGzXrjJO+Na7lzCmnYEnOtAsZLALHglTQcVBFF21bror1xPb21aveiYUsS3fHno7Zs85kulIfYiEVo0rNskCZgkLXSyVwEbaENyxsnwSSuF2Rc9m1t+3qU4zwb7dlH733ztGtiGu9TJr0OlzPIaAr1SCbyyK9OCdBZPoTxAR8bjPYH7oWR8obUMIp0NlGwKKkeOWYvLLy4zvueaDKm6Wo3vaPF15/1ewMEzQJucCgz5USxMyY4pVE90sKaCMKRmNL2Go7z7++qrsUM9TROP7V7bcMyxMnQXNKIfwp8AeHYyec6GVMu8mAs5VrPvr7zt5NHcUPtvev/7TzYG+/GSSmhJbaR+NYQBqCI+EU3KjnkZnnTT5n2hkyLIXV4LkXVnQeIrWYoXSDdWMRUs+J4E+pekH92s6DOhQGlKAoRfYVk8t/8su+CpVBcsG00x787bW+gKxKj4GZG3gRmxuhB+rBXRVDcsHF368pl3mFSPGk2vPAb26ZNXUiRzMPrW6mijyIYnRbiGQcxZQh2Zz+mGzZXbnmpp+HiZXU4puu+/5N156bZcLjKghC6uYN64LRbAaNYmkBorWRBTVi/emxF/eUREmSYcMbf3Ld/KAGrUBQ8oht7Bk4YRuXuN2AqBrw45E+wbojtvtQsrfKVXZYx/4ujCgQUYQmMsMfYNAMktHrM8dGGmGQIxN5cntu9vlTLYapdMvCp5ft3F3FBhjFuH6uVA3SvgTNEgatYBCMP2wGP679+/43V21QkK8Wnzdn5inHZ3zMScCUYHbKwdhmjpmOgbEfiiSkXiyMjMhnc4VcAwQBlnK5k3Ezng2fcfQoGnMRwo0oIxA1ilOjbtArNWa5CMnVV/7D6LYmAKISxA898mQoSCzRiNOMl0kwzUhpm1taYQEMUg90q4VPLtG0MS7Hx7a1Xnnhd1hNczNhRTtvOkOURGl2gpTGieDbVLEMCFmRLOe+lmMaG8YWcr4UI5uHwXwZAazQjZjdQVGgR0FFcsAqsBtUiiVYLCcfn5938WzPJY0thWUrVr2zdhMUUJRQXGZG4Xf9y50Irsk0y+mr6dUbtj/zyqrOnuLxY9sWXPG9804b2exTx+aVctkx05z6ANkM5gczWsdxjKcBWC6u1U6f2D75WxMmnTjunDPaT5owrLWpIQorjmMBjqAc6E6EjRsOipD7RgEpkck48NKYY8at+2Tn3s79UsaHisUZM6ZnM5jzk5zPaLUcZ3w7rpWdXH5rV/zPd/z7po5yqVS6+JyJv75twdhCAsUvEygBy6Zumh8m69NR5kBPO6gzjXofmGumszPoWHTM4Ju0u8CUBc8HQPtmMAb5a9q/VJILwgV1asR5e2Px1l/e3dfV25zzr//hZTdcMzNL0EBqWo1RIIjPSU2T3zz0+v1PL63QhuGtzZfOOOVHl5xPw0O4+dDUbY8KlBsDeswD04ntVweD9eYWw5RUvhuhzmLM4s2QSqCu1E2ENXBk2ohIrmMg3AwXKKjMjol7oJg88vgL27ftiWrV9vFN9/3u58e0kIKtaRnlKSGYaG3rEFfdfPe+qlfjOUCsEPe1uLzrQBf3MhFzHKgX0+ojMRm2wWnSDHvVZzFGtRvLTT3Fq9ag3Ii52J6DKQyG614EtEyFwtcsjelGKsphopmuakM01ZiwJvQVOady9eXn/evNc7O400SFYCgQ986Onbs+/5SSihZ9lJYrUX9fUCa5nFVoQrNWFHFIRYwJJgYdGCvheYqCfiCxomj/E21BPEfKipQd4sRAR9lIXDwRMhXiyxN/gonBVUg+GwNSpS2hOOow5kVxudacyTb6vseob9tPPfE4MtgwaHfU7TkFqNd312/93X1PFGMegnwcLyqXoKIwz7C8XEBIQ95T5YO2KeP1dpEj1VDk0lYddfHLKWYKQgOINKbwVgI44kMT6PqzKtPW4wECvGu8CFCjOIKAcmBpxQ6VhOvZzY0kKu9+bdF/0KhGy7LMIFcJD2L9xd7O3lK1FGKgiumIdoE/0CuhlQjCDCPDwHDGwKw/xWOaH/UZcH1UAI00OP83MIARto7N4wwAPjXRxDodI1tUAg+4DnwrMZnH7SaxjcIRk9aW5v7i/jHDc5NPGm5jGyh7oWmpVstmnJwt8dBRSIDGqWFSB02tQhB4lEj0KZbvGWlTfwwxmBYGhSka6xOqw/Oh+hsQC2ANOKYTY2QuOHVAgCAEBoDplBH/xrdRxfGJoWlFSsUSCCuuhhm02pVq7GdsoApymibF9KkdhlQZCb0Ep0T9jmvkvYDqs7NGJh420ViZjiAHZxnmD/gnHfylYICwQkATLJmSqKlxCLR5UJlmTB0c6dDDTEvMDBr0Rmm1Wi3kC+isHct06P8NB29Erk99ig8AAAAASUVORK5CYII="
      },
      {
        "resourceType" : "Binary",
        "id" : "15636648",
        "contentType" : "image/jpeg",
        "data" : "iVBORw0KGgoAAAANSUhEUgAAAVsAAAEHCAIAAACP4XI2AAAAAXNSR0IArs4c6QAAYYtJREFUeF7tfQeAJFd5Zld1DpNzWm3OWXFXARCSwXCS4QgCbDDWYYPxHT58Ng44gBPG4Q6wAYNJwgSDclxppdUqbc45TNzJeaanc6q+73+vqrq6p3vSTuiZfbVve6qrq169+uu97/3vj1IymTSJTVBAUEBQgFFAFnQQFBAUEBTQKSAQQXQGQQFBgRQFBCKI3iAoICggEEH0AUEBQYFsFBA8gugXggKCAoJHEH1AUEBQQPAIog8ICggKTEwBKZc9QjxiMsumrs7gyeONFy82RiPxGA6ZFFlOJOW4yYSiGTIkzSaTNBuEnsESBm1gRRJWFbPxBkQdS4cCiklSLBZZlqVYLGaz2byj/qKiottuu+3mWzaXltpoyGYbcDkRQYmZ9u594+SJy4mYpaa6obCo2O/3FRQ4o7GAkoxJsqIhAqs4iU8dFGYwOI2Agn1eA98xfo4/iCN48qXzGsWTCArMEgWUZBKDlMapJMlAhGRSutbW7h0bW71qxb3vvPOm5ZXTQ4SOa30//vF/WcyOLZs3L79puc3uVJRIPJG0WJNmC8agPuwZFswABHI+93QRAQzCLNFQVCMosHQoAO6fbyZZMkWjJrvDOjIyfPlSc3d3X3191Uc++oAE5n7clpNHeOKxPWfOnN21645du25xu93xuMluS/oCIYfTarWC22AYQKwBn7e1QTnT4UnV8TqmCy4CDpZOJxZPMssUSCqSQkNSCYUTVosZI7ene+CVV95samr667/5QlZEyLl0P3vmXF1d7cqVyzweF1bpZgugJun2mM3muGKKmKQYFQgUUKQEViy0kleLBhEcKKZatMtlutE0Suq+egPEjqCAoEBSSSoojEswud0Ws1nG9+rq8rq6SkgWhoe8WeEnJyKYzY6yskqLxRWJJBMJBYsFkxRPQkiRCCYSEDEmWGETOkn1jGXGOJdRj/gqKCAoMHMKxGLRhBKTzcCBOKABk3o8noxETS5XQUFB8cGDZ6eHCIm47PdFoVNwOCSrDRM9SSkS8ajFbLGarawuoAmKUaY4Yyy4zgt5S0QRFBAUSFEAy3umazChjI2NKYpix1jmYzf3llOO8Bd/8u3t27fefMuG2vpSqx38RyIaDVitZtksQ2jJmAPcWxdNZMgRpg0TTI4wXRGC/lgzUFteJwaJywUF8p0CkoQxG04k4i6XKx5PWMxQN0AtaDp96uL+/YfXrFn74PvvGv8MOceSZLJEo3EoMCTIJSCdMCXNZjqiQGggWSTJyj5lrUhsM0myVrAvQe2Bwnf0z4yv/CdeZrTRpVMWVogzBQVuIArIGLOybI5GYxaLFYMV4zeRSCRNCgAilw1RbkSQTMwkKW42s/EmJcGD8MWCTDJKSClMkFlgOIInAQeRTMZlOYnChIIJ/A6bBTJbkJWklEhKkEECS6hoByGhjCdR6Cd2pimBu6A2DiWc29FgRf3KD4oiKCAoMCkFMMFaLDBEcPCgSOyTpnZi+OMJTMHTkyNAjmi3y2YLLkzKZhrqGJxgPwA2wALIGgEzqJlhAeqPJBIxuhFkF7ghjicx2gEE4C6ASbwY9pN0JJGMJdhpgAlAA6QgqEozqyCxBfZxRFGoTi7IyFJUNccNhPyCIxIUmBIFCAHAGVjsdie3T3Q4SLYA0YLFwmf3LFvuFTimbprSuYEwt1DkFoQSwwLFbid9BvgIDFe7zWa2WKKxeCAQSmDqT6BAvgmJA5SW4DFg0oQdfFpRlKSFzAwlm9lsh0ZDkrC8oRPA4QBnAAHMyorjGaAlHo3hFlyvIYqggKDA1CmgD3h9YT257GMCmRyx8ekVqPJCMyCGqRuAC1hCYIcQIpE0yzZ3QSFEDGazzWSyKQpGOLNxJgEkLTTAqkRjUjyBI4AoEopiRYGDOA0rDZyDakiDmm6lBFgjEcUk29TJJM4UFLgRKDDZiMmxasipa/irP//6xk1rdu3aWb+sUqZFPgo2C+ZvSA+wOogn4jCBkmg1gckbMkxIFqQxf+TosQvBcDQUCMMKAmMbagmw/rQCMJkwtlFFFMexzgAASBIUo/X1DStW1FZVuWRqS5yGPgMAXIA/uA+Mopj8coInnBQvJqWOOEFQYIlRACMPI4o9lDY+OOd98sT5V14+vGHD5gfef8f4Z86NCF8EIqzbtXt7/bIqkhcCEah21c0RIktwBdB2YpGPad0sW4cGfZcutp0733Ti9FV/MBIOhYEZWLGYmXiQhJC4GN6UJFFQwA8QxsQTNrutpqZ21cq6zZsb7r5rB2wf9JHPBSGRSNRut5FSVWyCAoIC06AAmQhMiAhbHnj/7dNChG9s3LR+1+5tGiJwXp4WDoAA7DKYSMTiMQzwpGI5eezSE4+/fPjIWW8gHo7gOOAAok4LjCSACFgNUPtYGyVZxkF8xqAVicMCylFS7Nm+bcXvfuaDq1bXQJzA1Ikc3pRwKOpw2sCK5CSF4A+m0UvEqTcSBVKIoFr6kH5B5RGObNgARLhtPDkmmHuNQ00XK1INGKtsyscH9IWwgrL6fZFLF1tPHD/f0zOiKNB82q02t81eYLPDEcKZTFoBGXFrZUOl3STZ4wkzTCljMVwKZYYDkoWhYV9jU9vhI8fAEcSJ5yAPKiagkCBunELwhRthWSieUVBgWhTIGOwqKEyKiLkRgca9UbrPv9AGCwWzGdKBWFyJYEbH4e6unkuXrvb0DDqcHmgZNMUAUx5SIf+r6vf9xjc+s9GJhQOkA4lEOBaNxKJ8KQKRxMDQ0MnTp2BipdDV3MGafrLZOcvAHVeyqRhvXAUEfxv8peifxh227uIAru7oX/lBY+F0zLg8owvyG+U6R/91Wh1XnDx3FNAGTuqtTQoIE2VwMUZG4ioDfcMQh+0TjBxIgxAIRWMJk9nikM12CA2tdhuWCjg9nlQw7AORED6jUvWHPrx53bvfdl+pZLFZrU67ZIbFEhNXmiWsIvAXMV7AbuBHLkUkDiTBIzWlwGjyB7rhzuCsnP45fhGlW5RPZX1lrC0rKfXabjhCL9oHnt7wyckjyArEhmZmPUj2AVpRZwgs7KFiBM8PKwOr3QrmPiGZFagkLdaYAtMjJQmmn9SLEka+bDG7777/A+stctGWDz9QRmgCRgA/WWB+CA0nCSdJdynZVJNFLQQLE0piYcL9LHV9x/hXk5V5WDoHIYRBMTJIWFexpRWTJytSIo4CyzCS0hBxYROicQ5kMQoneRTGZREpua0Y7MNgV8IOgtnDJfgajsTwE76S2bq6YU+tTYMeI7KoUXoMPy0dsi9yozc+TfDXNx4UcCTDtkB93xP4NWA9IEtwa1ANBeHewIr68snwCWMabgxY6sOkEUOcDBvNZhgeskhOzMyIIYJkKXnP+7cU0NLBtuO/v22LhZYSXFSAc7Q+BQWjHd91ngBiBm7sYOiaWddCS78Lcn8P0uFyl3fDeIXIFsJdjGvuV6LSnk5OYvkGJxSUBAzG4vTJriNyMVNToAHgg1VG7iiMjAz/DZ4iRvDlAMR7Vy5OYem/i0UFE3row/GTaM6fJtbqTcwiGoYrOSpxqMjCmppX3XWf/6l/fD2AVliW3/Hr98CmMmPjNxIqxlycKYcDzOSEpRrkk0FnHFqdeJQMRiT8GsMR/gbIGESTH3DxgMpoMOjQHMtgIUYyHwiDGECbZDMMxuBmwl/jeDjOisiLlpsWDc9GgQkGIet55LaUDosZc3aGSIuhgja8+Y7jjg+sanzi2FOPnehB95OL7v/wrlrSJnII0D85h2NgP4X4wMggMQZBjZvHKENMQAIhMaKkDmaOJDD3ZpIX4hSgtYHkdmTENzAw3N8/0E//h0ZH/OFwDHwBfNVQSIkskbCG+adgvYBrlWg8ApnxuAjd49lO/uKMRYywpUCBnIjAJphMg2L2xOq4Hcc/6HOX/gvtSGU3f6D60qMX4sHDbzzZDL8myX3rPR9ey7FAn4g0XDFWOjGDohJ/elKTRfvGyPWTTMdJBEum3jS3S2QD6rA7UWKxuCxZnY4CrLxgIEKzvuy8eqXjicde/ea/PvrVrzzylb/93ne+/YtX9h5tbuz3jcVI6ECiBACD1R8MRGIh8BpYY0AR5LRb46hC1zQtWpKJhs+MAhMggj5lZ9TMR2+W1YF21KhNMa163+7K1sGanWtv3+FoOdNPkGCt/8BDG1xpWsOZNZ5ftfRZWbIZp1FKoiDYdGODbAaAgEUYRIbRCBzV7VgJxHg+DZN5aCDw3NOv//THzx5662J765hv1Bz02dqavS8899ZPf/zM/ldO9nSPkA0qlEUmxNhy26AfIucR7v9uYvs6Xmd/0dfzwsS1+UyBCWwBaWmqNl0VGGE08yOp6VvrOFiHqoLHtB7kWPvQjuHXOtwN9eUN9WWW8ycODKEGueZX3vbusvHLVKNMeypEm0BwMpXLF805WOcTCKgSABalhksCKJwNRLyIfxdvbxtqbuxuvzZyrc175mTLkcPnu7tGIyEpGjYFfLGAPx4JKaGA0t/vbbx67eyZlvNnrzU1tl9r7W1t7hge9pN0EnJikwUCyFhMs35NWYAsGlqJhl4nBSZeNXCVwUScuSZc1pUEmjaCSaRL335X3eFnfvDEgceeZOXx5769ZwCrVblwy0cfrCIzaK2QFHuSqGpTWkVcJzny8nIsGUjtQpIDyP2IuyctI3QF2IGR10C/74XnXt33yoEjR868vv/InudfO378YiJudjkL3W6X02V3umxut8PtccNgPBaNdXb2nDt7+eiRs4cPndy//9Cbrx95/bXDra19iRiQB06rpGOaNQYuLwkqGjUBBXLzCDwakmosaAy+rgGEPp45604Kb+ZATb2VYiBJct1HPlrfcdaL6G70lYpyZs/pdkCCZNn2/rffbNePsy5I2Zn0fA83iIBgKp1TJTQQgekLIAs0BfyRnu6hK1eunTpx+dCB06+/dvDKlebengGM9t6efqvFtnbturXr1qxc1bByVe2qNXXLV9bW1VdUVpcWlxTa7VbgQjAYikTikCHE4/KJ4+cOvnXyzOnGpsbO3u5Rk2LByzLIi7j4kPF0OmOnvh/DT1N5FHFO3lPA/KUvfSlrI/e/eqyisrS+obqwyM201OgL+ihlbkhMc81NDwaHvOfOXmm82gIvB4x/DGu5dPXH/+rh37+7usKthIaHm7qCWAS7l6971zu2ve22akjA5OL6rdWBi6fa+0LofYrDZmqoK77/vrtsNkRVAV/Mw8yDLeZ9MEMSyZusSxCW9lqXaxZAZjiSIgCONDLsa2nuOXP66vGj506dunDtWntZWfnKFasqqyqX33TTtm1bNm7aUFxcUFtXU1dXUVWLH4uKSzxFRe6ysuLa2qplN9XWNdQsX37T5s2btm3fsnXrluam1qtXWlqaOtva+oYGgw6HE3anEGRy+wPohTTVA1u3GLelTfi8H72TNTBDxEaLTVzS09Pf0tJRUVG5bkPD+BpyekP/5Re/tXHTavg+NiyrgKESG5M6IlAoBLJLlOVIzITwKB0dAz/8wWOPPfqCzVYSjOJsurcugdThBPbKkIND10UsBblGM5MY2NyZ4uWl1nffv/O3P/XRsrJCRHxG2EVo1yEAt9vs6YhgZGp0ucPSNmRgjuNQESomTP6xaPxHP3oC+GuzOJYtW7FsWYPH45bJ0wSe59A+mG3wMLciuwaFo4NVAlSUFKwf5kmaXRPFybTALRVnIgqf1W63+/3BgYGRgb6h/v7hnp6e9vZrv/6R/7579+aCIicucrrMzPCJcJlZQRl6kUCEyQblgv5O+mrDxIn1oO77eJDFR9g9vnkT+z7meuHQSyJqGom+bRbybaisKLnt1m1bt27y+UcQac0qxyzsU9/hXxEMVkqG4eJsMkXMUlRJBKNhbzzmt1oStbUVd929u6QEnRuxGUm9xuJGWvBI6Nbo3KzpxvZkxFxcUMrP8c0pdR+Gu0nu7xt5ee+h9raejeu23Hffe26/7c76uuWlJWUlxWWFhQVutxO5/axWADI0kJG4gpR8Zk+Bw1PgdHucLjfGPsa/Fd7lLpcTIfdgdxCJBkNhP2xNy8qKVq9ZccutO+68c/edd97Z1NTa1zcEvxUABwksyE4Siz0tZ88cP6+ofgEpkBMR0K0046QsloiQdsuYyVkg5mgsCnXVtm0bHnjgXTt3bpTlsCwHs5Zkcsxk8tvsUZcrYbNFJMkPUdfKlRX33XfH+9//rq1bV1kBMJolNi0dWFgEzZj5hpUsqrZJFHvGlOztHRjzhuBgHgkm+npH2q/1dnUOIJlff9/Q0NCId3TMHwhGIiHK5xOP+3zB0RHfyPDYyPDo4MBIX99gby+MlQZHhofD4ZDDYSsodBUVeZDy2+m0Op0Wj8eOJUbDsrqOzo6RES9eAVQcfH3GpBhszsnQES1g5xW3ngMK5Fw1/PkXv4tVA1jHZVg1kFaAFrOcA4GFG41TNbOTKRwJI/AiIiAgOMKpUxdbrjVnTudau+OIvYzYagijYgUjmozCJVKyYD2zcsWyFSvqaqsLWc/jdrjcxYr3RnRCcpBI5xFUz0nN6nEJLxywZMCcT0F1R4bGnnri1VMnrtTXrXQ5i4GZlLbHSkm3bHYUGaPa7SE5AOADBs8B2ChG4vBcwuohjFB3yAeaiDudNkAARn5lVWlRUSF4h0g4OuoNBPwh5PuAuNHvDz3z5FO//rEH7rr7FrAmZAONBH9kwEAJOWgWyAhgI9YOczAyZ6PKmawaJkCE/9AQoTwDEbDABziYLdBUUXeB8BvTeDJphk80ZALqwj/bA2k+fGSBhwsxyilsPGWzJicpcoKmBBC0z8xySazIRVlgX8chAneU5htx1LNBwfysg0QqWM/DahFmyE88tu/Mqcby0jpZdsDHzOMpQJAqwIHdIdsdZpfLjsy9DhfFycYlPgzuMAJVIbdPLBSMQF4AJwiX2wFBY0VFSWVVWXl5qdtjh8nz6Kjf5w0GAlFoH4LByJ5nn//EJ967a/dOBgcsDzDnVFgoXST2SqOUQIT87DgU3XQW5QgsmCoGoxarJP2h0TcoQQM52/DELSxiu2KzpXKu6MlXDFlYFItFQbQVmNaDp0VzwVvYrOQAiVCsxJVCAsbk6pSqgTJBsEPk3pOnJJ+fZpGfKUkOIdBVEP8eb8Rud0AqgBcEGQuUkeR/jimcwtshnjXoa0EQzASLa8fi1jJHVOZLwt2fgLCwXzYTlyfHYxASm+1Wl9td5HYVWsxOGEEjoxcuocQccXKR4n5WBAaQSuJHsS1dCsxEsog1AsY9mFGwBmyZydSEzFOamdujYOrHV3zqO/Q1Dq40BpmiYreaUExKDJ41CKGEOAk2hGKD/S3rbRTBmfVZGgSkh1y65J/ak2HQY4VFXs80JqEjIO6MreIoNy+zbmbhE8BH0YqM0vigIG8Hvmkcvspqcd8kJqKhf0zdQMIg5i5BegnsYE1HKAzhLouXxZN9YG0IL8uMwPlTa744azFRYAKbRd3nkbHtBoESsfLomDT5kDkdEjrBlA79hmImg53kSgAe5SS9QDUGbx1ER4gj/xzCLaIOiK7A8/MpiKV+ZMGdmXUuRWSnjcVivXHFiqA8VgdI10U5/CRIChxgBuCrEA4jMa/J6cZ7SMjmOIrEVAyJRBCZdCLRAE4gd4hYIhoBoJCxI8W9wqDHsXgkgsVBeCyhRCQzeAbk84S/01g0NpY0BW0O3JE6McsjRpRnzlVaFJYbHqAX0/ieflsn9mvIMBzUTJbZdCTBqZ64e4ACpYLjsxb6GzuJD2aeJ5bvMBTBrM9s8tn0j6tkTG9AADa/qUtTjgL4CVVTZgf2E5cmpG83Du/KScfYJSa1wZIL7D/0MtDUYmwj+hHWbvhkeTR5Gi5AKk/JSXQm32diuSxgCIDIFixBCM8JnnEauAywIBDlQGEkm7FGi4SDPnZtynwdLQDjgUu40iHzVQiMmP7Ay9srciICrIbAz6fZBWqRNmjIE8vJAmugF8mInq6CAouKpGOBnjk6lUKaBjjjL9BB2cSv+uywjAzsO3V9StnCDOy5fiErg6AfX/LQwNb+LIoahh6LawsKWrF2w0sAa095sWAwxrCTCX3MJiYjIEKS5pYEgaxgcQYUNyPQFcW6wmoACb55mCzGDeAywmtUiHyd/L1oGw7DzkFkzcjbYTyLDcuJCIicihiIXDqgBtOiLsnFjWzKYrIu/OGhFBkDAEkhGSJOUBjfgO7HGQhkmgUvzMQFGo5ocEAWu3Dy1b6OH/bcol4vs0iT/KpKC4nNLEZBfuLOYF9shgoYfiBmix0qSMqpKUO4gwUAlI5gr5Bpi51AAS7oC5mQgrtgAS1ZVl3IIBGaEQBDgG6Bg1MS7AHeNl4nmA8HC5LJLE9J/8PfJyEE51Xyi0CiNbNKgQl4BGAByZa0LZ01TOsV1FU0QcP1c5AZQ12vefxzL304SHtmleYs4D1MCLFCg1QAKwgS3qgRKnkubYx8BEWhuCjMhIB4DCiGcQ3QgQY1YBgSR8RWoGUfqReZUBL6BXAQwBSgxvT6mICI6dErr89ewmr8vKb7dBo3ftFEyh0WVBlyFmh/GbuPJYEFobDB3pOpkt1uRkkis3Y8AtliPAnjMI4ATPNLYGGyIhkGjEoIcukWXGjEqs6QH02nseLcRU4BgQj5/wI5C6a/KaPIlmZnSsqbueEIiRvVmEos4AoUkVbSV8CLjHQ7KFyGCyYDblSog0dlpsWCyLKZ/51izlooEGHOSDubFWvCHFrbQ2SDwtJgMD0CH8aG9EzcxItsuyDwJXkieahgcaEWSuDAbJqw+gAOUPoGJjMg2yNVIoRlBItVkX0Ti4TZfLX5VpdAhHx7I1nao492JlckqwRe2OIfHiIQE2Leh2oQggCKjIbC7b7JhAGaR8SfoMQuZEROEbEIXkiuCxjgsdpJwEv2DlZIi/EboQRfQ2QZ+1n1PouAhqKJU6SAQIQpEmpBT0ut62kFAT0k9xCBNADxlAkFklYUKQlbRigUeUEsVopeQzGXyRqcTEe42hgqCcAKLAxg/chNRXAV/NoREldBKNekTOblaVEQ+LMb5ccGagiOYUG7xqzfXCDCrJN09itMmWSwwBSY7klOAIEhWSLCT8RhlqEvdCYVWzxmiUWkSDgZDiWCgZjPF/L6QoFAhDwgcSFGuyLH4qZQJBEMx0MhxR+IjI1FRr1hFJ8fzpGok3kwsFQO2Z/EeFjAwey/7QWuMafv41998d82blqLGEr1y6qY7yM5K6YamxaOlfdYLgDHJ7ODF9ssUYAGoCb9Hxoce/SXr1883+JwFCBWEhlrECOANYIJSgMrZn1mIQJjIuggguEAVgMs7xNittNxSBBDoQi4AvKXtoNBkIqKPWARQuEQkvXyCAgxOEokwi2NF3/ntz+8e/fN6os3G2JwG1XSAhFm6S3PTTWz6/s4N20Utc6MAmD+IxFTJCojrkE8Dp8EHxwTotFwKBzEfwQ+gN/z2GgATs3DQ16EP0IqJ4RLgYMzAreHgorfHwMvEPAjkEoS+R18Y+HhIf/QoK+psautpW+gz9fdNdzbM+z3hb2jgcGB0YJCpOm0RKLkuMbiLJoCAXhSw1xSYMDMXuCiuUqsGhbDq2IGgzA38BTY1m9YuWxFtdWuBIKjY74hQAGiIYXxPxjy+wO+Mf/YmA+RlPAZDAS9o77RUXz1jY36vSO+Ma/P7wug+Lz+MW/APxbyj4URhWWgD1gQCgXDQ0PDA319sFbYtHFjZWU5DBiZHwOxKVxVScYMmsvTYiCcaOO0KSAQYdokW6ALkrIl6fZYl6+ouvueHTt2rq9rKC8uQToGM9wcY7EwoqKQbCEOr+kIOIEYPuFBHY1EI6EoYiThMxqMRYKxKPsahXNzKBIOY8aHb9OYdxQ6yuKigtKSwhXLa++8c+vu3TtqakqhjmSR1GgxCL8GIIKaXZbLGZnS0xCPd4EII247qxQQcoRZJeccVEZjjoeQYVGnSDuYMCFrS1tL1+Dg6EDf6LGjV20Wt91hg6qRhTYhUwMJztEk6+HRpdRQ93wEc+8IHqbNbnNAF9Hd3bFsed369SvLKgqrKos2bqq1QmdJl5GOgkXE4RgAI0huwqSvHjJzfM0BAUSVM6bATOQIAhFmTO55upAEtgoZHZNToqJYZGgKyeUMudgwvtvbun70w5cLPWWFRUWIswzxIQ1iJaqYWCgas52FrKDRDTcmpj5gSkQwHBYKqRKCviERv9J4ad36lbt3b6trKHYCIrigmIMHzB0oOBeQgAwfmAcE/88fXyDCPHWDGd1mJoggVg0zIvUCXYSRGYoECSOYCpDZIyP1WwQmhizaImIiMacGB5waENEANksxJR6G7sCUDCEivskURbZXswykgJtU0DvSHwqM4HgiFkCkfEmKIWkLtnAE8fLgGMWtGQmLKHIb4zSg8oTCYoGeXtx2PiggEGE+qHyd96BwMghKx0R6dsRdZtVh7sdUTTEoWbhaij6F0JeIjxRDGCVaMuBXRGpGjhZsCK+mRqmjoBZktQRUges6EjfQz1YL4qjACpJpH+OAEsgUmdcz4QI27umghtATUe6u83Xm9+UCEfL7/XCOn0WmoKCn5NFA6ZsxUbPoVfQjxixTBagrf54+k8KksJgV5ONMgVLUFJskQWBhGeHDgHxOtPqIxHlEbURQsFp4ggbiC3Azkl+wSPwsvA0LZcMMHnijtPh5eiqdRUBJ0cRJKSAQYVISzf8JWZyRCRTIVYHggE/SkDQODnrbWrugYGApsFgQGwrJCAslFMSbgXyQOAMcsMHz2e5wOpxulxsB3bEhU0NxUVFBgae4uBAShaHBoa7ObigsKaoli9esbzy8FXOw5Fmqc/QZoXaY/54yB3cUiDAHRM1VZeaYSX0n1p9tKcWCQbHHXBPIWxnrBlgNwR0JTP3woO/40UuHDp7DYGfxKymSNcv7SCsFhEVE+HYkdHO7bcjUVFjoLikpKi0vqqoqr6+vWr68duWqmuUrK1evqdu4aeXqNctg13D27IVzZxuHBrxgHyhcArQRWmhMFq+VIuKm4v/zgFp6DCujPes8UlTcatYpIBBh1kk6lQp1LOAsN99ScMAjn3FdITaYDyAgKvh+BEcKh6LxqDI4EH1134kX97w5POxfvXp1aWkhJcVBOixZQRwEgILd5nS5XIVF9sJia3GprbjUXlRiLyiyFZXYqmsLV60t37C5Yv2mspVryupvKvyVd9915123+gP+p5564aUXD8E8Uc39wZuVRAOiwBdwH4jDBE7B8IQcFIQh41Re+uI4RyDCQr0nPq6MoyvVEp7nTv9OKVxtNv69qNBx+XLP97//k2NHT5eWVK1evTb9AYwrDh4kn0fQVePkI+xSIolo+oinglCMJrvThEQwCPG+fGXDbbffsm7t+ra2zn/+p++3tQ4g3gpbdMAwyexwuCCoQDh3sCoI2LpQJBP3nQcKCESYByJP6RaYinkkJJzNPJQp+jLlZSZewQztAQKlIovjG6+fevyxZ8a8/vKKyrKyMjgs8ZBq5I2GMCc0udNEToUSZJGKUmVI1ARZLAoj00kguBrF00b0BCXucjqXL1++efOmurracDj2y18+0dTUTIFTKEArmR/AyRJaC66PILSikCopLmZKTyhOWgwUEIiQV29J5QtYbjsqPA4yz7Y4PDT6xuvHXtzzms8XLikpL/AUcv0Cy+RAA58ZKaqgwCOw8mdjod1ZkCUWnRkyQsAB5YhC1k3mMYHlAJDF43ZVVJStWLF806ZN3lH/q/sOHTpwZmTIj+EfjzO/BjVitgo9aSbMusO2YCDyqkNNvzECEaZPszm4gvsRadyBmmdRXThgQMZM3Z1DRw6fffP1E15vqLy02uX0UHwkiBbIGEHNtanl6GQWTBSxWYt7oud7oBjt4ETgIE2aAwILTPgItEKSSLJBgAyitKx47do1GzZshjfk/v3Hjh+7MNjvRQwmnnqHx9bXZBzGFYqujMy+DpoDmokq54QCAhHmhKwzq5RnQ+CGQBh6sALAH6Rv7+0ZffON06/sPTLmjaxfu9lqdSJWCvK+OZ1OlurCKKfU9/nIJI0AX31oegFK0ML1BlBVUpxFsjjAiOcpXCivi8vl2Lp127q1m8a84TffOHHowHk4U9JpLLGLgTUwDn6OCJTIN5dwZGY0EVfNMwUEIswzwTNupwvq9YGEHZboEQkyMdHHkj3dY3v2vHb40CkESquvW46ASBjbxUWlsCmCCgBGhzzFC4+fqm987GpaAFp0sNR7dDsmsGA5IFk2R5ZmllgGYIHTZUehtDpmy5rVa2+/bZfN6n7yyRdfeP5YMBBiJsyqipQNe6Zo4KmmaJtIVrqwVBZ3nzoFBCJMnVZzfaYaiUC/DYZse3vf4cPH2q91O+2e8rIas2wvLa2ErcHw8DDlbjGZRkaHs83JHGh01aC6ymeZmthPSBFJGWKjlP0RqkqH1eGghQNLAIslRSQaDUHa4HS61qxev2Xz9qNHTv7sZ3sGB4cBIIAPzRdayAzmukssQP0CEead6LnHkZ51QTVGiiTar3UdPXoyFIx4PMVQAcJbEcMY63mny0GTcjLpcDhU0yYyauSF8wIUi5mni2T2jtzkkQqxCQxFgDhIEQ1Gg8wfWMpIiuJqkR1OGDxKZH9gQSYYe1VVFQSZne19cMGOx5GqG/FdUQmLCm+MsKbaNc87PcUNZ5UCAhFmlZwTV8YHZraNFgjkUMSjndJ5EPlh8J88eSYSitntLkqBSSk2ZRIAmBBtlcQHbACrWTP5+ORB2Vkhfp4jC8cOrr9giRxY7FZESopD3cACLzN9JypCykcbQiY4bPCeRIAWsAzABbfbXV9XB47kyuWWocERcq/m6T+FDHEe+8683UogwryRWr/ReNmbeoSNcxqdcGLCiPV6/Y1XW8AduBxuJhegcQ1TZaYiYN6NzNSACRf5MoE0hJQbniKysiPMLJrfmIMCN5UGLjAdpOoQwRABRtDM/wFWBzaz3QFZgmKxSeAXcKSwsBAm0a2t7YMDwyzDpM6PzD/1xB3nlgICEeaWvlOvnTsU6eeHgtGuzoFYDFwAuAMe3tqo4dPMn1Xdgu5lYByrPMJ6RlHvwNWQlC2aOyuQKRP5O5N/pUXCegFJIVleSDAOhDgI3xwIIKBjRDhDT/2dLsYzBSLkxVujxEoUuYBCH/MxjehG1651wU4R63YGFhocqJaCxoRLBo8jY5JuzWBJc1vWuXxV4wAzRG4HhZUFN4UCdwHhATlNmpMAAqsVeEQ7CPoKNgH+DoFAOFvgVQ46XJYptsVNAfEK8+z9aVwCYpeMjnghPjAwDtNS9WdnDbI8bbo4QLeV0s5UbwpEAIKAqcjmDC0kCnnWi66jOQIRroN40740zaPReDULZkjhDLkgga8eIP9z2D3kWaCaI+cUTLKquJcBNxNCngXVtYl91X/S76kKHVRlZCbU0K/MNBqtIhcJyCzgbAXhBWWXTROOsidSj3AeQagkp90t8uoCgQh59TrUtAhsvGI9T1EO4NTAtQGTNJR+11cWzOVRQmH+SKl8bSkrJlqekPJClTvovg/M4gi4xDJQU3pIKCwIEbiywpAPktSXmr8TRxwdESZran6RXLQmjQICEfKrQ9CQYyESKQk0OR7z0aXpLY3seZY1BDtEggbGIwARtNCpmogx+8MahIX8RjBwhCyTpY4n+wViGOAtyc0iDSdr/Ih6F6GAyK++NLPWCESYGd1m5So+qdIr4DJFGtDcSVEb7fBQ5C6HDArUk9m9jdJE45zM2AQOCmrYFd5UXRKpyhfoJkzNoGokVasEEnCyEO8m6DeZXyUhAkSNCOiqN1JzqcJdeOQF4RY9K/0hLyoRiJAXr0FfFLD8ScizZEI6Bjg1RCIxGAqQYjC1afxC6kgWwR7TWehWzBnPmLJQUBWPxtoJEcjGGdYKkGzwX8CtwICK4q+q2R8YxNCm8wXjW5UnhBXNmB4FBCJMj17XdTa37dHHr64NYMFRIEEkOCAuHYOS/mLyRdR0St3O9Iga68DsjVnhjWFjkdwbWe1gJ5CbzSIpNhRTEhbHyPiCJYBqYsjzOPLEbWTNpIY90B6L4qHAHzIKdaMZdSQR8hnKBQm+DDYr/CzJMkGVV6hSA1TOC24hxAfX1Tvy5GKBCPP5InKstFWMoCmdi/rU/xhjbE4m6Mi8NPU9NU2rrgmwhbaoBUbNVMjxURuxKofPRRXGTSOE6hytO1njTEAIWUZSPVzVoIob0p2p5pOS4l5zRQGBCHNF2WnWa2S/jUz8+Il3AgEeRxI+/rOaLU2zUVlON7YnR5uv/yaihoWjgECEhaO9uLOgQP5RQCBC/r0T0SJBgYWjgECEhaO9uLOgQP5RQCBC/r0T0SJBgYWjgECEhaO9uLOgQP5RQCBC/r0T0SJBgYWjgECEhaN9Pt9ZTUub2cTM4LD5/AiibTOigECEGZHthrmIZXJSLRVvmIe+oR9UIMIN/frFwwsKZFBAIILoEoICggIpCghEEL1BUEBQQCCC6AOCAoIC2SggeATRLwQFBAUEjyD6gKCAoIDgEUQfEBQQFJiYAmLVIHqIoICggFg1iD4wTQrwYGxqVNhpXitOX0QUEDzCInpZ89hUQ7i1ebyruNXCU0AgwsK/A9ECQYH8oYBAhPx5F6IlggILTwGBCAv/DkQLBAXyhwICEfLnXYiWCAosPAUEIiz8OxAtEBTIHwoIRMifdyFaIiiw8BQQiLDw70C0QFAgfyggECF/3kU+tUTLCa+aJbGmGffzqa2iLbNJAYEIs0nNJVUXz/CI1LGUOo7lf9VgYkk9pniYdAoIRBA9IjsFuNUi/y19X1BsKVNAIMJSfrvi2QQFpksBgQjTpZg4X1BgKVNAIMJSfrvi2QQFpksBgQjTpZg4X1BgKVNAIMJSfrvi2QQFpksBgQjTpZg4X1BgKVNAIMJSfrvi2QQFpksBgQjTpdiNdb4WTE2kgL1R3rtAhBvlTU/vOTXjJDJZNJgqwmRJNVqaXnXi7EVDAYEIi+ZViYYKCswDBQQizAORxS0EBRYNBQQiLJpXJRoqKDAPFBCIMA9EFrcQFFg0FBCIsGhelWiooMA8UEAgwjwQWdxCUGDRUEAgwqJ5VaKhggLzQAGBCPNAZHELQYFFQwGBCIvmVYmGCgrMAwUEIswDkcUtBAUWDQUEIiyaVyUaKigwDxQQiDAPRBa3EBRYNBQQiLBoXpVoqKDAPFBAIMI8EFncQlBg0VBAIMKieVWioYIC80ABgQjzQGRxC0GBRUMBgQiL5lWJhgoKzAMFBCLMA5HFLQQFFg0FBCIsmlclGiooMA8UEIgwD0QWtxAUWDQUEIiwaF6VaKigwDxQQCDCPBBZ3EJQYNFQQCDConlVoqGCAvNAAYEI80BkcQtBgUVDAYEIi+ZViYYKCswDBQQizAORxS0EBRYNBQQiLJpXJRoqKDAPFBCIMA9EXoS3SCYVRUH6VzQdKSD1HXylQ2JbuhQQiLB03+31PRnPCi2zjeMCdrQEsddXtbg6jykgECGPX45omqDAvFNAIMK8k1zcUFAgjykgECGPX45omqDAvFNAIMK8k1zcUFAgjykgECGPX45omqDAvFNAIMK8k1zcUFAgjykgECGPX45omqDAvFNAIMK8k1zcUFAgjykgECGPX86CNo3bI8FyMZFIoCGwVsION14U2xKmgECEJfxyr+PRAAZs41UYTRXVQ9dRt7g0nykgECGf345om6DAfFNAIMJ8U1zcT1AgnykgECGf345om6DAfFNAIMJ8U1zcT1AgnykgECGf345om6DAfFNAIMJ8U1zcT1AgnykgECGf345om6DAfFNAIMJ8U1zcT1AgnykgECGf345om6DAfFNAIMJ8U1zcT1AgnykgECGf345om6DAfFNAIMJ8U1zcT1AgnykgECGf345om6DAfFNAIMJ8U1zcT1AgnykgECGf345om6DAfFNAIMJ8U1zcT1AgnykgEGEW3w7iCyksMSL/5DvjS9YwRPzkCTZEKuEl16aewG9s2IwH+C/jTslepeFeLP/jLFJKVJW3FBCIMINXw0fUbBV9rGkVpga+NnSTkikps4Id3mD+BzlaJSVpUuhTTpp4kfhZrPDsjeqG1K6IkpaxIVYajugwglPpK12BDwRRooSP2GGtpN5iiKumU0BHmSlizQxoLi6ZJwoIRJgZoWcDDqQMZmH8cFKPSCZZSpqlpKzxCTTkNWxALRwIzKzIGMXACHziDD6g2ShO4UIKy9Rhz/7QFRr/wAY9kAEfeiZYIAICLxIGpQhmJMLUWY+ZEVxcNU8UEIgwM0JPPBmCqhMy+cbJdfz9UwONvx0a0uOKvjBR53EeCpHOY8NbMSVQMIYtFslsxrhOymaT2Uz7Zosk0xEKrSrjAPtZZVTAYJjMGtPC1juEAMaFTwaKzYx64qr8pYBAhBm/m6xjQwcCnc3GADMWHSywk0H8rGICffWeiytR4vFoPB5LJOKKEk+i0NyubgklFotHlGQsNaol9VcsDWLahnVDNirgIKIwoxgRYcbkEhcuDgoIRJjue0otucddyQd5BihwBp+V1E9ZmYisbAVHBMzdmK71SZvfmc3eUtJqs1is4AVki8XMPokLAGuAgwkKrc6kBLR6IDZCSSQJJCIR/GBnm9VqA5ug1pg0xeOJeBywkiDugO6InbhWGMugLh10EJlY3jld8orzF5gCAhGu5wXwyVNnFgxDOmOJnboJZ8L5z8Zr8VWfkLUKOQTQsNd3UJHhoKRAXACWH4XEf5AwYsgTCrDZPwrWwCxJVpPJkmQFO2yVYCEIkc3xhBJX2EcykYSMknAjKZmxvoD4If3WhEeABpRcChGBC9fTkfLoWoEI8/kyNOkDzbSsGAUE+pE0NSI/LX1LG31QDSCxCmVawcSufXJ9gsksY/63AxQURU7EMf9DwIC8LMAEK/6TAJKrFHj1rFrAAQqAJoV0aU2dT3KJey0ABQQiTJfomhAuy3WGEZ59ytTHNjtT/TaBrG4cHNC5XAfJlJGkfaRNgV4xSbpFXilbINDIj0bjoWAsGIwGA5FgMBIKxbBciMclJYFrIVG0yLJVli04k1VL6kZUy0DCzOtnqxNd5TldWonzFx8FBCLM7J1x5bwuOOCV6BI4DRp0XkCdZnWzAj6etUIiBm5uMHFj9NP4cOWVQFOAgU0KAuCCkjAl4pAUKLGoEonEBvqHurt7+3oHBgeGR0bGxsb8vrEQythY0D8WCgZiIZRgPBKGaJKxF8ACskXAjSymJApuxMAip3mSWCzMrP/k71UCEWb33fAxrUvpuWhAFxAYuPMsY2z86NIVDRpPnymbJH4BjEA0Gg0GQz6ff3h4uLe3v7urp729s/1aZzQag8wAykUsIYKB0ED/YEtL6+nT544cPvHWW0cPHjh69Oipc2eutDT19PUE/X5IISSb1epxeWSTzaQWSB+4PlLXShqfYnapJ2pbeAoIRLj+d5Chroc6EEK9CCT2RmiIJ6AgTKT0DpiHFRQ+J5uw5oeAX5Jo+GEfhdkWWTB1U/pVRUJR8EkCQKwFlGg0GY0o4XA84I/4fUG/DxN+BF8hLLCY7S6Xp6iotLS0rKikqLC4oKikoKi0qKSspLS8rLSsvLyysqKyuqCoTElaR0YjjU3dhw+ff+mlg888/dYzTx/du/fsW69f7usJBPyJaBgcB5pkkyWHLNlY83QTiQzNiEHucP0UFTUsHAUEIswm7cF2R2NRsN5k/CNjYCei0QjQAcJ82PtpeVWz3BE/wXyImRhydoB/kDLCbKEczarcL4nZHlIACeuCcDgGIPD5AqFQNBKJkk0BxA6SxWyG1NButUCmaLNa6B99oGD2t9lRbDaXze5y2D0OR6HV4pElVyJhDYWSoyORvr5gV8fYtfaRc+eazp9tbG5q7+7qHxkaA9yQuQMATdeTqE008jW6LZOwYprNTjXPdc0FIiSv7Xtl1x888b5vvPmnj+x74P/84tbP//Ler77xpz964zf+8tHbv3j4VSjFlvRGYj2yCqTRgl08Ky3QMdqZKDC9cENjsjlmNgG0voAVMhf1J2FZJCdwnFeFMRkKRXzeQCBAHEEoCLSJ0ZIhAk0jOJI4QAFsCP7GorA4gHQgFgpHQ2EIFCMh2o9FonESMTApQyxuSiTAcQBv7GbZCS4gkbBEworPFxkdCfb3eXt7h3p7hvp6h/r6BoeHR1EJJBSp95aysODHBI+wRPr0nCBCxBv03HHXTz9391c+Um9vHzrXNjRSu+7Ln7znR/9r+4ag37vUphCdhjRuodWDDB+rA1oiJGEphInajrUAE9fpcMBMDAzoABQAFiRNsWQyLsuwPibLgrgCO6KoAiRIYqSD3YgFAsGRkdGAPxQOAQagawQbAjkicAFKBIz8ENDC5/ONjnp56e8f6u0d6O0d7Osd7O8bGhgYGRryDg97h0foE/sQN3rHfGO+gM8POQI4DhI6omD1EYkoAX94dGSsv39wcHAItwbuMO1letcXULBEoEB9jLlABJO5cPnvvbfSPY5SlopVf3hfBcbH4t/STQlSegcY96iygFgUczUGLQaQFYtwWbKCDzBoEwz6CFgWMd0hZncliYmYpAhkawQ4UDDuSSqBxQgzP0zE4jGV72A4gVEKsWI4HA6Fgj7f2MjIyMDAQH9/X29vb19f37VrHS3N7U1NbU2Nrc3N7a0t7W1tHTh4ra2zo72rq6u3u7sHBRtOxrgfHR31+/0QIYx6ARajAJdgEBAz5vf7yFY6geUPoCrrJpQOi79Tsycwf+lLX8r6KK+9erSisqyhobqwyKMtgA2zQ9pEofcG3lvMpSur1kNWTVzw0C+faL2qSBUbNvz2No/ZJFWurV7DTWYTgcNvXPjBW+1HepXK2qIyWNbFfIdPdJ3oGLnaE3W6g3v2nH/iSshTW1prl6L9vXvO91/qHGkOWopGrn3nxeYjo9a1DW6X2ozkUEvz915q3N8RL68vLreafF1dey8NXu4c7TM5Hd1N33qp+WTEvbnOyRtl3AK9XY/tv/ro4fajg9KyhsIic3L4WufLl4cud45c6fIGXEXV4cG9Z/sudoet5QUlGOzqZpwZ9cen1oBdhzMRVg20fLfgqWSSC2JZwKQEdLV6unYVHaPaAAkY4bgU1gEwFIKMoLWlOxRKVFZUe9wFDrsTdWLkY8ADAjBug6FgOBwEZwB3BrI7xGcC6ABeAegAhMCfCASQWCBEowkIHcJhiB7BR4SDgXAwSIWzFUFoKfgFkTBwBwxHPBbBSQCoktKimpqKktLC0tKS8orSru6OdeuWr1mzXBVr8Gfhm/oU+uNlMBJZu5g4ONcUyEBvkmXhlj09/S0tHRUVles2NIxvwVwggoHvyEQErQGxoW/+/ROfPOb5489uc7z4wq/91+BNty7fXGh3th5/8J+PPnKo+3hfIB4Y/OkzZ//jWGTnPTetLbKc+eVzv/7zy09c6G8dUsaar3ztuQvPByof2lnkNClNr758/zd67/jkrk1H977/idDtd9avKYj+8l+f/dyzTftbvC0j/iOvn//h/vbRtRt+tVo14GftSHYdfO3e/9dz18O73us9/zv/fuxnvUUfur2s3Or73tf2fOGFxmf9NX/2rqoCl7X52Vf/w7ru4Q1OBghpsjVtNLDhTesCrPnlREyKQ1YC52QMbRbCgAQKDAlUSDC6OXBjBPg7k8Ux4MAC86FYTBobC19r7Y3HzBXlNSUl5Z4CD2oG697X14taABwFBe6yMhqoGLTV1ZX1DXX19XW1dTVV1dUVFRXl5SiVZfgZGgeoHIqKCwoKPZ4Cl8vldLocDofNBncIC/NssLlcDhx3u51uNz7pjOLiQtS5adPazVvX19fXVJSXAh1aW5tWrWpYufomJhAZZ6NAsg9NAirCq8z1YJ9S/TNBhDlZNUzW2mTH/kNfPhUqWdewq9D9rh2VyZ7GP/l5G/pTQbmnhAaN870fu/drv/fOz6+Tw50Xv/LyiEm2NpTbqa2Fy7/8v+759/+9/Q5L4vLe4z/sUpTRxj/7UXPXilUfrnfdtbks1nzmn94KKDZPfREb9DVr//l33/bZjRZTwn/o4ij0gaktMfaLZ69cGex+vUVqWFlaKSndp9qOxk2yp+4PHmwokkyx9v4TESBA5Jq87A/uLzEsdvQlg16ZCgcABSUuX7nSvH//geeefeXJJ/c+8fhLTz/58vPPvf7sM/uffXrfc0/ve/apV555mpd92s4rz+DgUy89+wzO3PfC86++tOe11/cfPX3qclNjV0tzVyOk/k2NHZ3X+vt7BwcHwMNjagdHAHWG1WrG2Ha5HYWFHgxaYERZWXFpaXFRUQGOFBS43B6MdbvDAUUDWBYm5WCSAM3wWQHrAfUEKrGRGoIVuw2IUVDoLK8oqK4G6JQUFnvcHugpoEGZQGMi4GCyjr8Yfl8QRIi8drx7DOPfQ4Pc6rQ6pGT/2Wsa8wl7OVdDuWwye7Y0uGRT4vTFPpUthWa8pKAOfv5l5RtpyA6+dSUWvnjtDb8pOdj+Lz8+9DdHvJDYXWwZiqlzlFRZVViAW1hxn2QoHE9z0zF7fvX+jQ/ctu7ddeHjF4ZGcQa4a2YEXHvnpveXSspIyw8OBqI9LY3Va3ePX2/kfrtYgff09Pb0DPR0D3V29Le392GnG6VzsIvKQHeq4OsQO9jf2dmHz+5u7Pd1dkISMOIdCcKm0A/x3uiY1zsaDPohMYhEQ7B3UD2gYWYI0QKzWGAhT6DjUMMekPqTqTMBaczKmbweyKNRk1lol2hOkfSXFju8BggoIMKQzYrNxjkdaEAYDpJaJOuTCznCYhjuU2jjQiBCIjrkp7GJ6Yq3EL1JCWI6ztw8Tgt+ioej436xemjKVgLBiH8sEkBfLa773G/s+oc/fGjw8c80/e6yrMJLFkrEuJk33Lv7H+61/PxfXvrBmM3DWAr1DGfDp95eYklGX9l76ckDgY13GgQIKdzS254y8kVrrVZTVXX5+g1rdu7ccutt22+5ddvOmzfv2Llxx85NO27esv3mLTtu2YqdHTdv3bFzy46dW3eqZdvOndu379i+ffu27du3bN2yYd26Vctvuqm+FuuA2oZ6WhFUV1eVlIL5d8F92WaHfQHFOqF1Bg18OCNQ7DNeNN9nPna5lQP3dKCm8h3ydiK2AfYLhALcWVoziIC5FEAH1lFkHwU4ISigWzACZRSVDFNQOYy/djyzNYUuK06ZUwosBCKYncvKrYQCbABCIgabHnMp5vLMLcYmdXfJeK2FEsUvkrWq1OkutLslU7yj/1gWSJmYdPHTTz5/z1dPD9917zd2FaQzAeYd9228026KNJ7+m+Hq95Ubp0XujMCDoBj8GgwsM8Rvu3dvu2M3EGHDnXdvveft22+7Y/3tu9bfvnvD7bs33r570+27N7NPXjbevmsTTt61e/utt25C2b17+913b7/lljV1DRUlxe7KipJly+qWLWuAdKCwsKCoqNBmM3s8Tiz3wQVA9QgqQtMJyQVKgryYYOCISR5aSdJOsPgpJK0khWg8idAqMFggDwhmK8kQRIvCCD0nBUegwlylzJBK+v1RmEXGYuT7xEwnNdRMIUCGE2c2mk8BLua0l4vKp06BOUYEcKusLTTPpDbr/W9b2SAnYfYCBfeoNxwxyRt3r079nlQiZMUUbx8MJSTHvbfU6D9BHE8DP+rr9Calgvr3bLQ4Ny5/h8eU9Lb+36d6vbimt+mbb3nJFIDfl/3hUYUyeYRY13ee6x4yObesKgiPBHGtfj52zNVrP3WLU5Kc77p7WUkWcuoAMHVSoykgBkQZesm8llszGY7GfYGRgf6ea61tLS1tUBFCLWC3Q/4HhkaGfsA76hsZHhvoH+ntGexo72lt6Wxp7mhr7ers6IVx0eDAaF/fcF/f0OAglJJjzLoRY5sHUKENeMGUl7BlgP6S1BBM9UAFStPREd+FCy0HD5w6dOjEW28eOnrkhNfrS3lsGt5WeqilqRNEnJmPFJhDXYOvq/uZVy785LzXlzSFYnJ1ibu6xl3Aplt7dc1WU/9zh/r9BYm9LzeNrL/jxw+vrIL4b6jju/t6h0xmly3h7Wr93t4B1+67v/PBmlI52XXmwiOXwyabxRGLXjly4fst1g986t4/Xu8wO0puqQi8errv9NmrP3nr2uve8t/5b/XOzqv/+nzbpUAyKnvuWR557IWmM75kxOS8fUfdSk1jCbhoOn51X3/oYouveG1p7Hzn1XCoT6p6cFMhO8WyqtD/VGf13z5UX5kJm0YRWvqqOuOXtK/cPEnvBMyGUV+Us+Ms9gkLr6xIGO3nzze2tnRAceiDq6IPCsMYVvdYyHvchRazVZ/zIyH4L4aDsC/y+r2jY2MwIxjzh2DUGIIfNAZ5FFpFjPloBAaLbCmAhUCCuU4wNSeaATWHvuLASgHSiVAwgqqGhkZgrQgbpv6+/jGIMsZGN25au2LFMi3kEtg0Fl6JME735uIOUdmFDTlHwDRPz8eRlI9tmomugZjGrM/yV1/8N7z+Xbu31S+rQtxO5s9vGBnGiBpqD8A5XDOX0tpPTKXw8NDJrrClvGxnjYNfE71y8JY/O33VtvKRH7zjlo6hfmfxzgYXEwokjjzyi3ufGnXccf+1/1l5sS1YUFe5oTilSkz4vSfbAsmyUr2qKb2gsO9kS7B0ReVypxQcGjw5YN64pqRUr1UJtQzIy6uYjmMWNk4fAyJwunEuRrMCBkTQ4FSk7s7+p5/ef/zIxQJPGWyNISaA2A/zO6ZxaAqxw8WGdC17gyx6qhpxGTsUKM1sJpsm9fXiZP1F04XaeyeVIXemUAM301lJyG9igJB4BF4VNpsciQTM5uRYYPijH3vwV951twVvS5VRgJczhn4C7RwTek/PAh1FFVOmAIXNMLx3io2FXnDyxPlXXj64YcPmB96/e3xVs9Tbp9xG44mO0rLdW+pu0+AgrQ7Zvmpt7S4VDtJ/cRfdtqnGCAc0ADxFt26uzV7VBG1zFOzcWAU4wCmusvK71hvggAaZc+WswQENuSzFgMb85XEVAD8XKhKny1pU5MYnNH8oGOYwc04oELWS+wOQGoERcQROD5JMX2Uz+UcwBIdmgaZu5iWhFwrdjjNRcAkMoFmBlTQMJakeeFJAKIF91EO3LvYUF3sKC10VlaXFJZBfWCELTrdi1h/KIFKZUWcQF+UJBRYSEcaTIBmJh3E0EfePExMGw+RnE4/GQnlCuZk0gw8bbfCkM2ecV2PMAjgAshaGrUFxcUFFZUlVdWlVDewCIFe0W+0Y9nF8OpySwwXIMBcU2opLXKVlnvJKnFxUVl5QWuYuLHYWFtoLix24xFNoc3usLo8FJ8P00W432WxJmz1pd0gOVpxO2ek0O90WFJzmpjPlsnLPqtV1Gzev3LBp5fadmzduXltZWQLnybQFAQvZwrhCWGdCODtV9lAjXla9xUwoK66ZLQos5Koh8xliY3v3Xn61P5aU5Iplyz94V81yTQEQ7Wv/j1c728PwHHJuunn1hzYWgjdd9JsBEZjaBTM5uTOAtYPKoL9/9NTJCz1dQ1WV9UUlJRD9IwRSV2d3c0sTkiw4nPbCwiJYGDqcjuKiYqgRbVYoJIktJA9IhGiIk0gXAoQYdAdQIsA+Gf8jcE6g/zB4xiIBVtZMlskTN5D/Nkk2GBNgM0swdqqproSlE1pld9ggnzh46MDWrRtvvnkrNKzpgoL01VBOr+/x69OMgM5CnDC7nXomq4Z8QoTZpUb+15aOCBimVqaT5YsLOCYPDcI6MVpYUEjezgm4RUP+p8D1CAFRGHywAKmQEsYVixVB2a08jALP5MafHj4NEFMyxQuwgkmCKNUTLWG4HIEjAtkzcMMGhgj4H/SN2aw2mDPDXgHnAoNQ7bX2a5WVMJquZGIHI33Th3pORBgfx1k/ktUuOv9fYZ63UCBCnr+gNNFemp6RZ2SECIDGOLSlCJeYMEXCyXCQVALMXpCFVcK6KRGHYwK8knA+t09kKd1oitctC3AeszsCGFBGSHUxouIC4QPqwaUwT9IHNkcEdgsa0GAycHkCIgtINS1mqCpgyQT1JHeCIJiYeMs+2WcgQsbXjKhtef4uF0XzZoII+SVHWBRknotGsiHKZvhUMGUGBEiRwCyIIeqTmPgQnD4CNUF2yJQJcHnCiMUOVloK9kmyaDGxzG4kX6RzmGUyYi1iSFPkBkRfxqdZtiL6mo0cHaxmC0wXITSETsFmxXHKAYORj5BL+Bn7LL4T5YOgrBBsqDPbRV5YGtrUV3aQh29VLaD4b3xTrUSwR/EeeAR5QwaquSCsqHO6FBCIMF2Kzd75RrU9NyHWNj72YBgAH2dmZqW6JLDFAoYT+TjB3YCdpgvn1GwuxuPqKKSxyCd/KqrAgCV7wXEyaSYRAq0Y1CGv8TLkBMW8I1j4Vign4C8C3GGYwCSgmr7ZGIR6AvroigkOG3gwNU/19dCUnmLOtjmtfIJW+9ub/9/Pjv77Gd94A/45e1a14nlGBJjHzPUTZdSvtJ89/htfQGS3x/7g6GTh3CCTm9PWGUaEwT2A3ZKGGDEKafng1TxrbLzlMBvJ3d4UUhjCxqeCxPJ5Gnc1m7FaIfWkPpfjII8KyWCKIQbL/qDtcNMGVhVvoZ6Bjo3z1KY3QbNZ0tgEijQFuMFSqaux7bvf27Pr84/d+vlH3/n1k49d9PZ2dT/62L77/gCv7Be7/u7A94/29+Qc8krz3hdWfeR7277X7k3dNaOPTbfL6ecbK4+ee2X/u9CkP3z5+73TAKDMhJq8gyV8rz22922f/8Vtf3LwpaxdMtb9948N3/Nrm+uOHP1u7ocf/+oTQ72P/PC5Oz7/izv+7tTpmXbleUUE/4Wjf7QvMA2KzsL4lJdtalgRGTnXNtiG6OMTbbE3f37gh8MTnzMLDcqcYDNTNjFcUAuDClgQpIVw5gkk9WSSxqySqYMazIDFwMSepWCh4XCAA0CnhbSArBIgo2A2DszMgTP5nPNnfpV8NZPt+Y0axBz0YafAVpIvFVKskGStX7PqE7cWDrYPn2sbKdm25YMbi6rraj/07hp3B4LxDXurVnz8tsqa3J006A2OxhPDowgBp9aa0cem2+WM5xsqt226uVymJo32TzatpEgQ6v7SDy8ZRrTWwcwFd+0o8ncMnb02Npp1MCRjYdlZ4bBVuE2B6TAJ5rLqD62xtrQNnesMMF/CmWzzhwjKaOsff+vcxakTdCaPk/UazEeT1pXsO3bgs88PT4f+k9Y5wQkT6OEn1cBxzNKRy/g14yBvQMa91K80QrEKUDl/9UzgAlwcgBHjcFHHKc7n6GYIPJuDXiYmNOk0uG0lNsSMBdyQJSakFXRASr0mK4y0aUNK2wmpLG/50INnvv6R47+/hluaZ/Sx6Xa59PPTKidB7LReuBJ8/kevfbtd9+dJ72Aw9JqgNlvD5++JfetHh1+o2Pzphsn7blpNJPa5rm2u/Bp87S3feeHKvm6lMDLW5iysHmv7wlf2fbc9UVhRWpWIWmBFYzEpYwOPv3Th0bMjocKSNUVmU8R74GT3qY6RxmGl1OZ7es+FR8/77DVlDRb/G/vP/+Bw74C7ZEOJJTZJhLVx1SaDr++9+Naoac3tOx5aQYvgzPualPajBz/49fMXorZlDa5EUF5XOXfmDvryW39tRnECn4aJWaeQqjAc4G6ILFgzzdT0K5usGWehfx1/kOkN+OBX1yqkVmT7fIekggnIHZnMkbK8qZwHVs4sGBxVwBWUekHINRg+QN7IksFNULKjEK1AuPSUosjTJ4/FoAx0fGd//0hSXr9rxwdvYloMLfRW2fr1n97u8eaIcyebgocuDXX7wj1hy6pyuzLQauxjJtPgP/xjZpczjJXMSHzx9MslKXjYULkcGfj5M9daTO63v3vjnQoF2rvQOXK1N1ZYTa46mT0q4XvuR3sefnE45CzYUJIcM7ukS4eNHWyNdfD7L/f0m0sefLvn/L6LT14KuGpK6hzaWA6PnWn29gWR4SPpqSy9yY33Fb16vv1Ay8jlrqBUbGk6cPY/Dg0ES8vWFqpKn2Bvx49fuPxcS6zCMvyfR4ajnqqP/+qyZeYMYJ9SVLVpItDU0EcZuPTwX75+qGbzp9f6vvrNI/uG45cv9zZ6YSGb9A8Nn2kbHYBbbs/lj3/huR/Kaz6zcvAP/+zpL12ImOwF1d1nfuOrL374X175re9dOHCp6Rs/2//ev3/18988+NNLnf/5+OHf/PJrvxhN2sqLQ2+9/pGvvviRr738+ed6L5+98MX/++Q7f9A+wtqWpdr0Nmc5ITZy+PLIIIwlk7Gu9sGzPcGpPeUMzkot4w3R2TJeW0rYYODS04SQ7Mb6TMB3jJ/GryxYW9JQtK8yssmzMJBwkSbPaAXxIGUEfW9tbr908eqVy02IBHWVSlPjVb00N15tvXKl5dKlJkNpvnSJlYs4zvexo+/rZzZevHjl3LkLZ8+eb21tB9JBPwqIiMcRJ37ilZpUXCa98bO9D331xU+86K8rluSSItPJ4z8YcCyrKYoffvOjX33xY491BU2J9D42fOJSZpczvDBE4tt7119fNN+1ZUfbgXf85ZE3AxmXjw4XFBoqT5+GS4rsZw/95iPN3qqSKjlLl4t09h7qCmGRmgwHLrYONg0NZe9gsd5vfP/CkY6uH/7klXf+6WtPshWrMtT8mT96+t9Nqz/3zoLzT+9/z5/u+yUdty1zD3zln1986B9f+Z1vHvrPM23ff+zAQ39z8BVmwBtuOvngHz3/d11ln7rL+uKbvdfZfecEEXznWl/2hg/uv3KpdMPXP768ICJv3r3xnjLq1su2b/vzhzbucoV+8ciBJ4bK33d3SdWmuq3x/n99vKlbkWvKnPBrkiwVn/nsvd/4xLpNZlOobcjz3nd+5zM731MiJf19B9qUCSKsIe5KtmqNPSHbCeayD9xfV0u8cMF9D976xftSztczGPS5L8nOvU/tFhkTMl/YT+UgD/fG+XwuuVSFFDA6sphhE0qIAJNp4giUJPwdMWgPHTwC3+djR0+lyrFTx1g5fuzMsaNnjhw+maUc4QdPpQqOUDnBynHUic9jx040NjbBHZPzOkyByRFBuXTw2Bd/fIjKz5uvGJbBOePcybYVFQ6tB5vT+9jmX783vct5Utx0tkh84Y0ZXbTQbqg8/S2Fhva1uD7/+2//eINVztblhhpW/dZmmtnliobPPXTrb22uzd7BLJW/9/vv/Npn7//CJnO09+qXn+sHEVrfOPOTTv+B8wOW8ooNxVJ8uOOFKyQkdFR4mGWYafXb7vzmZ7beZTfFB3vfgpRC8f/k5yffCljvvP2m2pL6T91ZPp1wX1l635wggqPSUyMn+84eee8XXnykaNP/XDvOoCXW89L5SNLkf/nJQ1/8r5ZmmOi1D5zHg3MvPIejDI9lNZPXo+SoKqFlqg3zWTLu52HP2IOMj7BmylWt/uCTnjC1ATqjs1KSd3Y5/2rcyVVriu1nJsbkM813jGX8QYOE0uBMoa0dsCohS2fYMagbaQSxSjFGSeCxEihWM7yqEfk5RNkl8Z2CPWcpFBs6rfDLWMxoChsNCQVTNVFmezK0JvsZSlANDoYeXd6w+9a/+8QuKh9dtS6tY15vnLsMyuaIxDelt5oM9v3zP73V/d5f+fP1TNZxPT1Kkm2UN8+5rs6JBGDNTUAEueGWjf/jthUfvblkqKnrvB99JBECb613esm5vNoGNbEN9EnGAxgO0d79l6MmyV5RSCRzwnxsSs+R86TrvDx7vfaNt3ztwf7ffLp/tL/tL/72+fCX3vfnq9LOhE/vMPkyud724B2/Vyr93SfVXydleLLp4PQIa9Hs1SYGD2k3z3XfmWpqZkz7DNkBJsQMaDaKhzQfKHYMszl1BhU8VTkBvgIeUge1cwzt4wIFDkDYweCncCkutwsW0GTdqJCZY11dzQMPvBcRXJU4nUxp3VhfhLoBWI0ULw6n2ZUlxv3U6MDuz1LOJOx2RJqPwf4B3lxTkoWxOHc/eXyY4twNRTfemxHnbmoNUM9KGiLxba2Vd/0DP57wTl5L0v/kd/Zeag24I1fO37Zzm82Uo0cpTZPXlTrDTg4peCdEbFvD+q9+0v6Pj+z9mKu+gYmzcuudmTNMODxK8vBcUQ2m0w527pzwCIovue1jv7b/cxt3uBDwdODnb/ajzcY+LjucpWAAEsMnrl6/7kGPsOaYtNoJTjA2b9pUnNIFOveuz9ick+ejdHIjH24ayHqIym4Yv+r7GefkahrE+OTIqIVsgN0RCowUkZ6DQIDbKhmIwm7Jctvqgo4Z7eAuNjtMIOE9BU+rqXe/CeLcpR4x4yXmeKdSrkh8k/cByfNrv/22h2tl78VjD/+0cxTjJ1dPHifyn6DycBQe6FJtfSmeJNxy6tf++MWv+1Z/99Mrl3ONy4QbGlCGoZSMDI7NVN+YXv/UX8lkTTP8Hms5++X9obVvf/ue/7NxhSyVFDlgX+fgTFY87rs2cEWqec9WRGAOPfPU6SMBgufHnm9q5oGCdVhUrV04+Kn9XFtzspPGRVgz2bJWq15EwUOyn4CIjRY7TZxIdhK90MJllLO+8cV8Bhzo/URHBA0iVHGbdoJh+OkGCcbBqYoLMkZpdgsCuoUm+We3U42RSKtBoVa4poEKWS4ZEt6TRZP2k37OdHeYgSTTO2hmmpogQSe5ZttsNHHOGucOI4n3F+LyMvpYPL3LGaae7JH4Mi5H0EpD5dxDgG7iWvbXn9601pK48Pzrf3UKQb2ydjmJT/uIZREODZ3uTGTvYIl4kPS/kdb+cNJe8clfgQAr8fqes2/6TBXLK26KBnoxNAyhbdShwYYDH/1k22GrefcWu5SMHT3T7VUiJ64MM0Z75sbhc6J9VEY6/uXnl06GTJH+njf9DX/z8Lp1TmtBqPeJ096mpo4TcvVDOypuXevpPttxrKXz5/ub9pwPbnvX1rc7vU8+f+7xtnAiZipdV1188eJ3TnsDyYSlrHZTsPFb+/p7YeLiLL9/R3HoXPYIa8iktmFNRrWbV3Rc/LeXu9tjpqjZvWtr3Tu3FGTetxjJUK1jl5v39XhPnOo3r1v7zropgPNMEMM47VKHSdWhj2S2zsdgZNw1Fttc+8gHD40jrgvUoyobtYPGg2yfWUBywQEbg9q1hDLcnJmZIWpOTmlPxLSXqVTQZKWEwGzkdg2Jzoy4g2wEU7qb2h595fLjLSEsUIKKta7MVRof3vPShf+84IWsnoLxlbpq1GB8mXHuEv2d33r24sHBBHJl1q6vu7XcmdHHqsOGLre9WJctStki8VVa0rroB2v9jzynV17pvHDh28dHvMmEubT2gdtLh49dPTwSPnNxxLl6+cO7S8b3KLczevhgR1NP/94m+Y57GtYW2Ywd7B2u/kcOxbatU861meyDV/7toPLu/3HfX+9wYQ0f67n2szO+vo7Bdnf1hkTX/q5Y36h0620V/iNnv31sZDSpWMrrtgSavv3m4DAWdYXVD+8o37DK1XKq48C5tiePdQ2Y5eYOPwy7nTXV9yzjs7C+TUn7ODfe0KFgr8nhHBs4O2xdu7q0Sm2XMtTZfzni3r6qQA2unAg3Nw91mzybVhWlYplNPtImibBmmrTarCckwlcaRwJl5Tsr5ggO9AfTZYopNi9l/YvckAwRgAXBYBSxUvXQ6XwY81lf9VI0sgCpQ9qeugRl0EMWDSq7wa0YGDugpnfgierpaGrVSmjFMkFoXkomyBH8TqfD7R4fGnvydzY7Z0we5y6jj43rcoZ2ZIvEN9H5Ez1Cth4VHxs53hmrXVm5jFu3GDtYyNcSdq0sMfW191/2W5avKL+JBfJiW6y9ebC/oGxnJaLZ+c80+50NlWsLJuPlY8ELjSOh8ood9uCFoG11lQuZThjLrXc2fJ1SVLW5QYTZef+5akkhQscfr3HN7b3movaZIQLhABvrmhiRRjFnNPiYZ7JFfpCCIDCHJJXVzUAEJi7MRATOFOgCKkIrhgip2I0MERAJeuEQYS7exlKucyaIMBn25CW9lkSEtWlRloMI8ylSd7Svqq8R/2o4B27UVFisZHKpThcHqL9yJyWcZsy5wGMrG+eWaTVVnLy4KbAYEcH8jk9/IvjkZ71/sbFscRN/xq03CCBSdWQ9mHELVUmhDfisX/VLuBA0U1Y540aLCxcFBRYjIiwKwuZPI9P1minhpq7y5E3l3s1MuUjrDe6XjU+Ef9aL5qw9FfDJHwKIlkyHAgIRpkOthTx3xvL99AuNierH6wzUX/nI1wuzfVbNnzUBmFhVLGRnmMN7C0SYQ+JOo2qY90PfyE0vNPke84AkCR9leUIWJhZ8USuwxkjCJYFKtoNx+JKxn5AGkmdwYuEJUgU2i9FoAi7JSNQSiSDRm7HEQ+FYBFrgmAlpJXEaMspEIhTA2RDQhbMS+iMaFyDTeG5xar5RQCBCvrwRHRHYQCPtILZAIIDc8z4fIjBHgoFo0I9PKgE/9ilHa4B91Q7ieATZ5an4Qigh0l/Gw2EqGNLRCCAgQZ8RBQMeaeOQjR7VUj2sKrVQDagnEQoq4RA+o4FAqLOzB34NSCWVps9KI55gG/KlL11POxaj9vF6njcfrs2mfaRUTYieCEM+lguBxTMZGho9ePDIhQtXVi5fU11dy3wXEGCEVgHM4I8ZnFA09pzLehuCqyLKKjyfWVZ4fMJwmMI0I/KqFenb7Bx3KKIzC8Wsb3abKRgw+QNRCvoqK6dPnz979vQ999y1es1Kj8dhgx+afrK6oz+U0QorH6h9I7dhJtpHgQjz32OyIwKPY4Yop8i/gDbBJxCOhvAmPnzouMNW7HaVIGMShwGTBO8gHgSR/mDE53oGQgRuhwQYQFwUBgrMLInMkyxABfJfoOMcEXhsRbq7BWsNJRzBFkJi6dOnT0Hu+NGPvm/lqpvY5QIR5r/bzOCOAhFmQLQFuCQLInDxAWuLDNdAiBQwi2N+Hh4eQSSS82dbh4f8kPnrxvUYtiwS0SStB2fAbJQ5fHBTZu5wzm6oRliVgBe6twKrMRmLx+A3ghPilAEqXlxceOttW9evW2Wzk/2dzUauSuomeIQF6EJTvKVAhCkSaoFPy84jIE4vzd0mC6VpS5DTMw08k2l42N/S1D466gMDwS0IefM1MaQaYS3rM6l8hNGBgl3KzRNZgmlmvcgZg9TYNgWDEXg8gZ9g58j19TXr1q0kdWWCDlpZwwQiLHA/mvz2AhEmp1E+nJEFETDwMC0T9y6BNcA4xNjDAp4yMrBhyyMs8tGs/tGFB7kXDWm+VGlukKpzBK+Pm0JrlTPEQWxjjHxKIackEWrJbKE96CPAdJCnUyYc5ANVRRvGU2AmiCB0DXnRk5h4j/mmUNYWhGOnmRsKQsYLcOMh+CESUKgWx5QYniIaoGSmVDJkWGJXqZfrp/ElA7nBaIUnXEhKlCdeYcVqI1ECoh5FoyGzhYIeIY2sDblmbYjmqbUhM658XlBSNOI6KSAQ4ToJOGuXWygJmxkSBJ5YBUwBxwjKsDbhTTjXn3VjSZ959LXUxiozagR0EyZ+G7pbKOyPx4PILo8088kk0j4G4OlPSSeVKIvpLhSNs/be862iCRBBdX/hIqipGMSzc1JZx6Z8iRYSaEJr+6VVG6dtWqGAyJiY2aZLAikOOkUy4EJBtopgg5kSvyEsACtwhs9V6LWlZIbjrR5RGzlfI046CnQZCG4JZQeKw+FkOlDGqrDoGw6HAxnncVNEc8/yovUATzfQS8zrfmvA/QzE5xxiTkzPiQjonQh7zHot8atkU6e63al2a6mvWkgwlvELlxCbyj8zzuGtmMrB8ecsodp0d0UZ5GIUYwMSGdnZ6KfcDMQh4AANfxqObFTz6EV6DKNU+jX2xpmMMLWjf81NN9YMVmFqGaDeAtpKmyTDWoEC4OLTanXKZqwZHEi3glitPLUb+xQvOk+7NI011Q5dD9ulsyMswzB5xGbZJkAEmo7U7F6a6IkLoPgUweYWdl8Nb9iv6uJSl3vpl+jQxHeMnxlfeTOncnD8OTr0GX/K19rUQcyBgGIspwY8wS6OkTOB5l6gPgX7yhcDHBT4TtavDD7UGng9qdr4VwOdNYrxNwt+BLGSLElkWpKtsgXxf2HMYJMp/RJhQQZJ1cqz1CZedErTM59dWhuA6a+cLwrVt6eP0TRcyI0ImqMLH/xpF1FVGVx8VrgRBwUFBAXyhgIZk2SOduVEBJ47nDEcfP6iJayhYPZSNJ843TNOndXSz8yMNyp+FRQQFJhrCkwkjSZo4PfPsk0gWcwpe9CqMa4MjCxD3oCiaIiggKBAdgqMY/y10yZFBJ3VgCyJxecioRIPvMUykasRuPSwHLokS7wKQQFBgQWnQNZ53SCaGtfAnIiQknrxsJ2qFouE31oZnzeAn6ZLr/iZOM34mfGV/zT+4PgLRW1TIebs0k28mqn0zHzt0szwzFB0pn68PjIFDLl5BAIXPYoWD7BlDJiBSrWlEBcj6CF38lpNmyEQFV8FBZYwBSZPFDaeh5mQR0jKxB2oFDNAgIoFlKA1VSgaH9eVMY2kwAVBAUGBBadAWpRtffjrw3M6kkWE8ICVO/e101KR8nBfGUJE7idjZEg476AjCN/RPzO+qkZ46ecYazCeb6wn14WcI8o4c/yFWW8h2jYVCgtiLoouzUZ7ylmWmQyopqUUpm/aFkqxpD8S9ykmSlIZhQyRbYlkNKlKE2HwxLMA8EQA3GhF3/SFitgRFBAUWBAKMIvXtCFJQTpZwC38ZyqCbFtuewRz3B8cRTxOeNfB2Qa++Yi/GQwGET8j3SCfnHJSYXtV1wZ48osiKCAosGAUwLCMx7krPaBBjsdpOU8DGdk0QxGk8KypqZweImzctNY7Ntw/MBiOgE1IBJDFFgbuNjt8ZWOU+wsG+bDDh+8DPrHPTNyZET7wR5i783XUYvfgyPoUS9rlZJLeu4ica/DuYNyOUN3hMCLwkLVhNEq+SX5/oK+v3x8YW7mybnqIcOvtNwdCgctXW3t6B0lcCKFCXDJbHDB3TybNiPpl+ERoDYm772cMg/GjQvSnSUmUP+NwEQ0A3q+WAArP1gChepIIvSMnE1IiTqwKZmy/L9zU2NrZ1V1UVFBSWpQVEXJGXsXa4Nv//qPR4cjaNatWrmqA934sIVmt3N2ZCy3GOztkOkAsuH2GaICgwI1JAQxOBRaFtGxAkD4E48baITY87Gtsag4EvZs2rb3//neQk8K4LSci3Jh0FE8tKHCDU2ACK+YbnDLi8QUFbkQKCES4Ed+6eGZBgVwUEIgg+oaggKBAigICEURvEBQQFBCIIPqAoICgQDYKCB5B9AtBAUEBwSOIPiAoICggeATRBwQFBAUmpsD/B7J8oHVsURdGAAAAAElFTkSuQmCC"
      }],
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "637674"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-92"
      }],
      "date" : "2023-03-20",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "NovoRapid PumpCart Novo Nordisk sylinderampuller til bruk i et pumpesystem for insulininfusjon som Accu-Chek Insight og YpsoPump insulinpumper",
      "section" : [{
        "title" : "Pakningsvedlegg: Informasjon til brukeren",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: Informasjon til brukeren</h1><h2>NovoRapid PumpCart 100 enheter/ml injeksjonsvæske, oppløsning i sylinderampulle</h2><h3>insulin aspart</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.</li><li>Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.</li><li>Kontakt lege, sykepleier eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om:",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om:</h2><div class=\"paragraph\"><ol><li>Hva NovoRapid PumpCart er og hva det brukes mot</li><li>Hva du må vite før du bruker NovoRapid PumpCart</li><li>Hvordan du bruker NovoRapid PumpCart</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer NovoRapid PumpCart</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "1. Hva NovoRapid PumpCart er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>1. Hva NovoRapid PumpCart er og hva det brukes mot</h2><div class=\"paragraph\">NovoRapid er et moderne insulin (insulinanalog) med en hurtigvirkende effekt. Moderne insulinpreparater er forbedrete versjoner av humant insulin.</div><div class=\"paragraph\">NovoRapid brukes til å senke det høye blodsukkernivået hos voksne, ungdom og barn fra 1 år og oppover med diabetes mellitus (diabetes). Diabetes er en sykdom hvor kroppen ikke produserer nok insulin til å kontrollere blodsukkernivået. Behandling med NovoRapid hjelper med å forhindre komplikasjoner fra din diabetes.</div><div class=\"paragraph\">NovoRapid PumpCart er til bruk i en pumpe og dekker hele ditt daglige insulinbehov: både ditt behov for insulin i løpet av dagen (basalinsulin) og ditt behov for måltidsinsulin (bolusinsulin). Før du bruker NovoRapid PumpCart i pumpen skal du ha fått en omfattende instruksjon av din lege eller sykepleier.</div><div class=\"paragraph\"><b>Basalinsulin-behov (behov for insulin i løpet av dagen)</b>: Når du bruker NovoRapid PumpCart i en pumpe avgis insulinet konstant slik at den dekker ditt behov for basalinsulin. Dersom du endrer innstillingen av basalinsulinet, vil endringen begynne å påvirke deg innen 10-20 minutter. Hvis du stopper pumpen, vil insulinets effekt vare i 3 til 5 timer. Før du stiller inn eller endrer dosen med basalinsulin, les omhyggelig pumpens bruksanvisning.</div><div class=\"paragraph\"><b>Bolusinsulin-behov (måltidsinsulinbehov)</b>: NovoRapid vil begynne å senke blodsukkeret ditt innen 10-20 minutter etter at du har startet en bolusinjeksjon (se avsnitt 3, Hvordan du bruker NovoRapid PumpCart, for mer informasjon om hvordan du justerer din bolusdose). Maksimal effekt inntreffer mellom 1 og 3 timer etter bolusinjeksjonen og effekten varer i 3 til 5 timer.</div></div>"
          }
        },
        {
          "title" : "2. Hva du må vite før du bruker NovoRapid PumpCart",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>2. Hva du må vite før du bruker NovoRapid PumpCart</h2></div>"
          },
          "section" : [{
            "title" : "Bruk ikke NovoRapid PumpCart",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Bruk ikke NovoRapid PumpCart</h3><div class=\"paragraph\"><ul><li>Dersom du er allergisk overfor insulin aspart eller noen av de andre innholdsstoffene i dette legemidlet (listet opp i avsnitt 6, Innholdet i pakningen og ytterligere informasjon).</li><li>Dersom du tror at du begynner å få føling (hypoglykemi, lavt blodsukker) (se a) Sammendrag av alvorlige og svært vanlige bivirkninger under avsnitt 4).</li><li>Dersom sylinderampullen eller injeksjonssystemet som inneholder sylinderampullen utsettes for støt, skades eller klemmes.</li><li>Dersom det ikke har vært riktig oppbevart, eller dersom det har vært frosset (se avsnitt 5, Hvordan du oppbevarer NovoRapid PumpCart).</li><li>Dersom insulinet ikke fremstår som klart og fargeløst.</li></ul></div><div class=\"paragraph\">Bruk ikke NovoRapid PumpCart hvis noe av dette forekommer. Snakk med lege, sykepleier eller apotek.</div><span class=\"inline-title\">Før du bruker NovoRapid PumpCart</span><div class=\"paragraph\"><ul><li>Kontroller etiketten for å forsikre deg om at det er riktig type insulin.</li><li>Du må alltid kontrollere sylinderampullen samt gummistemplet i bunnen av sylinderampullen. Ikke bruk den hvis det er synlig skade på den eller det er sett lekkasje eller hvis gummistemplet er trukket over det hvite etikettbåndet i bunnen av sylinderampullen. Dette kan være et resultat av insulinlekkasje. Hvis du tror sylinderampullen er skadet, returneres preparatet til apoteket.</li><li>Infusjonssett (kateter og nål) og NovoRapid PumpCart må ikke deles med andre.</li><li>NovoRapid PumpCart er kun tilpasset injeksjon under huden (subkutant) ved bruk av en pumpe. Snakk med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler</h3><div class=\"paragraph\">Noen tilstander og aktiviteter kan påvirke insulinbehovet ditt. Rådfør deg med lege:<ul><li>Dersom du har nyre- eller leverproblemer, eller problemer med binyrene, hypofysen eller skjoldbruskkjertelen.</li><li>Dersom du mosjonerer mer enn vanlig eller hvis du ønsker å endre ditt vanlige kosthold, da dette kan påvirke blodsukkernivået ditt.</li><li>Dersom du er syk, fortsett å ta insulin og rådfør deg med lege.</li><li>Dersom du skal reise utenlands, tidsforskjellen mellom ulike land kan påvirke insulinbehovet og tidspunktene for dine injeksjoner.</li></ul></div><span class=\"inline-title\">Hudforandringer på injeksjonsstedet</span><div class=\"paragraph\">Injeksjonsstedet bør roteres for å bidra til å forebygge forandringer i fettvevet under huden, som f.eks. fortykning av huden, innskrumping av huden eller kuler under huden. Det kan hende at insulinet ikke virker så godt hvis du injiserer det på et klumpete, innskrumpet eller fortykket sted på huden (se avsnitt 3, ”Hvordan du bruker NovoRapid”). Snakk med legen din hvis du merker noen hudforandringer på injeksjonsstedet. Hvis du pleier å injisere på områder med reaksjoner og vil endre injeksjonssted til et annet område, må du snakke med legen din først. Legen din kan gi deg beskjed om å kontrollere blodsukkeret ditt mer nøye og å justere dosen på insulinet ditt eller andre legemidler du bruker mot diabetes.</div></div>"
            }
          },
          {
            "title" : "Barn og ungdom",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029899"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Barn og ungdom</h3><div class=\"paragraph\">Ikke gi dette legemidlet til barn under 1 år, da det ikke er utført kliniske studier hos barn under 1 år.</div></div>"
            }
          },
          {
            "title" : "Andre legemidler og NovoRapid PumpCart",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og NovoRapid PumpCart</h3><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler.<br/>Noen legemidler påvirker blodsukkernivået, og dette kan bety at insulindosen må endres. Nedenfor følger en oversikt over de vanligste legemidlene som kan påvirke insulinbehandlingen din.</div><div class=\"paragraph\"><span class=\"underline\">Blodsukkernivået ditt kan synke (hypoglykemi, føling) dersom du bruker:</span><ul><li>Andre medisiner til behandling av diabetes</li><li>Monoaminoksidasehemmere (MAOH) (brukes til behandling av depresjon)</li><li>Betablokkere (brukes til behandling av høyt blodtrykk)</li><li>Angiotensinkonverterende enzym (ACE)-hemmere (brukes til behandling av visse hjertelidelser eller høyt blodtrykk)</li><li>Salisylater (brukes til å lindre smerte og som febernedsettende)</li><li>Anabole steroider (slik som testosteron)</li><li>Sulfonamider (brukes til behandling av infeksjoner).</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Blodsukkernivået ditt kan stige (hyperglykemi) dersom du bruker:</span><ul><li>Orale antikonsepsjonsmidler (p-piller)</li><li>Tiazider (brukes til behandling av høyt blodtrykk eller ved omfattende væskeopphopning)</li><li>Glukokortikoider (slik som ”kortison”, som brukes til behandling av inflammasjon)</li><li>Thyreoideahormoner (brukes til behandling av sykdommer i skjoldbruskkjertelen)</li><li>Sympatomimetika (som adrenalin eller salbutamol, terbutalin som brukes til behandling av astma)</li><li>Veksthormon (legemiddel til stimulering av skjelett- og kroppslig vekst og med omfattende påvirkning på kroppens stoffskifteprosesser)</li><li>Danazol (legemiddel som påvirker eggløsningen).</li></ul></div><div class=\"paragraph\">Oktreotid og lanreotid (brukes til behandling av akromegali, en sjelden hormonell sykdom som vanligvis oppstår hos middelaldrende voksne og som kommer av at hypofysen produserer for mye veksthormon) kan enten øke eller senke blodsukkernivået ditt.</div><div class=\"paragraph\">Betablokkere (brukes til behandling av høyt blodtrykk) kan svekke eller fullstendig dempe de første varselsymptomene som hjelper deg til å gjenkjenne lavt blodsukker.</div><div class=\"paragraph\"><span class=\"underline\">Pioglitazon (tabletter brukt til behandling av type 2 diabetes)</span><br/>Noen pasienter med mangeårig type 2 diabetes og hjertesykdom eller som har hatt slag og som ble behandlet med pioglitazon og insulin, utviklet hjertesvikt. Snakk med lege så snart som mulig hvis du opplever tegn på hjertesvikt slik som uvanlig kortpustethet eller rask vektøkning eller lokale væskeansamlinger (hevelse i bena, ødem).</div><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek dersom du bruker noen av legemidlene som er nevnt her.</div></div>"
            }
          },
          {
            "title" : "Inntak av alkohol sammen med NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029901"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Inntak av alkohol sammen med NovoRapid</h3><div class=\"paragraph\"><ul><li>Dersom du drikker alkohol, kan behovet for insulin endre seg fordi blodsukkernivået enten kan stige eller synke. Nøye blodsukkerkontroll anbefales.</li></ul></div></div>"
            }
          },
          {
            "title" : "Graviditet og amming",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet og amming</h3><div class=\"paragraph\"><ul><li>Snakk med lege før du tar dette legemidlet dersom du er gravid, tror at du kan være gravid eller planlegger å bli gravid. NovoRapid kan brukes under graviditet. Det kan være behov for å endre insulindosen under svangerskapet og etter fødselen. Det er viktig med nøye kontroll av din diabetes, særlig er det viktig å forhindre føling, dette for ditt barns helse.</li><li>Det er ingen restriksjoner for behandling med NovoRapid under amming.</li></ul></div><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek før du tar dette legemidlet dersom du er gravid eller ammer.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\"><ul><li>Spør legen om du kan kjøre bil eller betjene en maskin:<ul><li>Dersom du ofte får føling.</li><li>Dersom du har problemer med å gjenkjenne føling.</li></ul></li></ul></div><div class=\"paragraph\">Dersom blodsukkeret ditt er lavt eller høyt, kan det påvirke konsentrasjons- og reaksjonsevnen og derfor også evnen til å kjøre eller betjene en maskin. Tenk på at du kan utsette deg selv eller andre for fare.</div></div>"
            }
          },
          {
            "title" : "Viktig informasjon om noen av innholdsstoffene i NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Viktig informasjon om noen av innholdsstoffene i NovoRapid</h3><div class=\"paragraph\">NovoRapid inneholder mindre enn 1 mmol natrium (23 mg) pr. dose, det vil si at NovoRapid praktisk talt er ”natriumfritt”.</div></div>"
            }
          }]
        },
        {
          "title" : "3. Hvordan du bruker NovoRapid PumpCart",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>3. Hvordan du bruker NovoRapid PumpCart</h2><span class=\"inline-title\">Dose og når skal du ta insulin</span><div class=\"paragraph\">Bruk alltid insulinet og innstill basal- og bolusdoser (måltidsdoser) nøyaktig slik legen din har fortalt deg. Kontakt lege, sykepleier eller apotek hvis du er usikker. Ditt bolusinsulin (måltidsinsulin) må justeres basert på din blodsukkermåling og matinntak. Spis et måltid eller mellommåltid innen 10 minutter etter bolusdosen for å unngå lavt blodsukker. Ved behov kan du ta bolusdosen rett etter at du er ferdig med å spise.</div><div class=\"paragraph\">Ikke skift insulinet ditt med mindre legen din har gitt deg beskjed om det. Skifte av insulintype eller - merke kan medføre at legen vil justere dosen.</div><span class=\"inline-title\">Bruk hos barn og ungdom</span><div class=\"paragraph\">NovoRapid kan brukes til ungdom og barn fra 1 år og oppover.</div><span class=\"inline-title\">Bruk hos spesielle pasientgrupper</span><div class=\"paragraph\">Dersom du har redusert nyre- eller leverfunksjon eller dersom du er over 65 år, må du kontrollere blodsukkeret ditt mer regelmessig og diskutere endringer av insulindosen med legen.</div><span class=\"inline-title\">Hvordan og hvor skal det injiseres</span><div class=\"paragraph\">NovoRapid PumpCart er kun tilpasset injisering under huden (subkutant) ved bruk av en pumpe. Du må aldri injisere direkte i en blodåre (intravenøst) eller muskel (intramuskulært). Snakk med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.</div><div class=\"paragraph\">Før NovoRapid PumpCart brukes i en pumpe skal du ha en omfattende opplæring i bruk av pumpen, og du skal ha informasjon om hva som skal gjøres i tilfelle sykdom, hva som skal gjøres ved for høyt eller for lavt blodsukker eller hva som skal gjøres ved feil med pumpen. Følg legens instruksjoner og råd vedrørende bruk av NovoRapid PumpCart i pumpen.</div><div class=\"paragraph\">Vanligvis injiserer du insulinet foran ved midjen (magen). Alternativt, hvis legen har anbefalt det, kan du bruke låret eller overarmen. Når du bytter infusjonssettet (kateter og nål), pass på at du bytter sted for innsetting av nålen (injeksjonssted). Dette kan redusere risikoen for utvikling av kuler eller fordypninger i huden (se avsnitt 4, Mulige bivirkninger). Bytte av infusjonssettet må utføres i henhold til instruksjonene i bruksanvisningen vedlagt infusjonssettet.</div><span class=\"inline-title\"><span class=\"underline\">Når du bruker en insulinpumpe</span></span><div class=\"paragraph\">For å få størst utbytte av insulininjeksjonen, og for å være sikker på at pumpen fungerer ordentlig, er det best at du måler blodsukkernivået regelmessig. Hvis du får problemer kontakt legen din.</div><div class=\"paragraph\"><ul><li>NovoRapid PumpCart skal kun brukes sammen med en pumpe som er utformet til bruk sammen med denne sylinderampullen, som Accu-Chek Insight og YpsoPump insulinpumper.</li><li>NovoRapid PumpCart er en ferdigfylt sylinderampulle klar til bruk direkte i pumpen. Følg bruksanvisningen til pumpen.</li><li>For å sikre korrekt dosering, skal NovoRapid PumpCart aldri brukes i en insulinpenn.</li><li>Når NovoRapid brukes i en pumpe, skal den aldri blandes med noe annet legemiddel inkludert andre insulinpreparater.</li><li>Sylinderampullen må ikke etterfylles. Når den er tom, skal den kastes.</li><li>Ha alltid med deg en ekstra NovoRapid PumpCart.</li></ul></div><div class=\"paragraph\">Les nøye bruksanvisningen til NovoRapid PumpCart som inngår i dette pakningsvedlegget.</div><span class=\"inline-title\">Hva skal gjøres hvis det oppstår feil med pumpen</span><div class=\"paragraph\">Sørg for at du har en alternativ metode tilgjengelig for å kunne injisere insulinet under huden (for eksempel en injeksjonspenn) i tilfelle pumpen skulle slutte å virke.</div></div>"
          },
          "section" : [{
            "title" : "Dersom du tar for mye insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029907"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du tar for mye insulin</h3><div class=\"paragraph\">Dersom du tar for mye insulin blir blodsukkeret for lavt (hypoglykemi). Se a) Sammendrag av alvorlige og svært vanlige bivirkninger under avsnitt 4.</div></div>"
            }
          },
          {
            "title" : "Dersom du har glemt å ta insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029908"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du har glemt å ta insulin</h3><div class=\"paragraph\">Dersom du glemmer å ta insulinet ditt kan blodsukkeret bli for høyt (hyperglykemi). Se c) Følger ved diabetes under avsnitt 4.</div></div>"
            }
          },
          {
            "title" : "Dersom du avbryter behandling med insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029909"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du avbryter behandling med insulin</h3><div class=\"paragraph\">Ikke slutt med å ta insulin uten å snakke med en lege, som vil fortelle deg hva som må gjøres. Dette kan føre til veldig høyt blodsukker (alvorlig hyperglykemi) og ketoacidose. Se c) Følger ved diabetes under avsnitt 4.</div><div class=\"paragraph\">Spør lege, sykepleier eller apotek dersom du har noen spørsmål om bruken av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "4. Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>4. Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.</div><span class=\"inline-title\">a) Sammendrag av alvorlige og svært vanlige bivirkninger</span><div class=\"paragraph\"><b>Lavt blodsukker (føling, hypoglykemi) </b>er en svært vanlig bivirkning. Den kan berøre flere enn 1 av 10 personer.</div><div class=\"paragraph\"><span class=\"underline\">Lavt blodsukker kan inntreffe hvis du:</span><ul><li>Injiserer for mye insulin.</li><li>Spiser for lite eller hopper over et måltid.</li><li>Mosjonerer mer enn vanlig.</li><li>Drikker alkohol (se Inntak av alkohol sammen med NovoRapid under avsnitt 2).</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Symptomer på lavt blodsukker:</span> Kaldsvetting, kald og blek hud, hodepine, hjertebank, kvalme, usedvanlig stor sultfølelse, forbigående synsforstyrrelser, døsighet, unormal tretthet og svakhet, nervøsitet eller skjelving, angst, forvirring og konsentrasjonsproblemer.</div><div class=\"paragraph\">Alvorlig lavt blodsukker kan føre til bevisstløshet. Dersom langvarig alvorlig lavt blodsukker ikke behandles, kan det føre til hjerneskade (midlertidig eller livsvarig) og til og med død. Du kan komme raskere til bevissthet igjen hvis du får en injeksjon av hormonet glukagon av en person som er blitt instruert i hvordan det skal brukes. Dersom glukagon er injisert, må du så snart du kommer til bevissthet få glukose eller et sukkerholdig mellommåltid. Hvis du ikke reagerer på glukagonbehandling, må du behandles ved et sykehus.</div><div class=\"paragraph\"><span class=\"underline\">Hva skal du gjøre hvis du får lavt blodsukker:</span><ul><li>Dersom du opplever lavt blodsukker, spis glukosetabletter eller et annet mellommåltid med høyt sukkerinnhold (for eksempel søtsaker, kjeks, fruktjuice) og juster insulintilførselen eller stopp pumpen. Hvis mulig, mål blodsukkeret ditt og ta en hvil. For sikkerhets skyld må du alltid ha med deg glukosetabletter eller et mellommåltid med høyt sukkerinnhold.</li><li>Når symptomer på lavt blodsukker har forsvunnet, eller når blodsukkernivået er stabilisert, fortsettes insulinbehandlingen som vanlig.</li><li>Dersom du får et så lavt blodsukker at du besvimer, dersom du har hatt behov for en injeksjon av glukagon, eller dersom du har hatt gjentatte episoder med lavt blodsukker skal du snakke med legen. Det kan være nødvendig å justere insulindosen, tidspunktet for insulindosering, matinntak eller mengde fysisk aktivitet.</li></ul></div><div class=\"paragraph\">Fortell relevante personer at du har diabetes og hva konsekvensene kan være, inkludert risikoen for å besvime (bli bevisstløs) på grunn av lavt blodsukker. La dem få vite at hvis du besvimer må de legge deg i stabilt sideleie og tilkalle lege med det samme. De må ikke gi deg noe å spise eller drikke på grunn av risiko for kvelning.</div><div class=\"paragraph\"><b>Alvorlige allergiske reaksjoner </b>overfor NovoRapid eller et av innholdsstoffene i preparatet (en såkalt systemisk allergisk reaksjon) er en svært sjelden bivirkning, men kan potensielt være livstruende. Den kan berøre færre enn 1 av 10 000 personer.</div><div class=\"paragraph\">Søk råd hos helsepersonell omgående:<ul><li>Dersom symptomene på allergi sprer seg til andre deler av kroppen.</li><li>Dersom du plutselig føler deg dårlig og du: begynner å svette, blir kvalm (kaster opp), får pustebesvær, får hjertebank, føler deg svimmel.<ul><li>Dersom du merker noen av disse symptomene, søk råd hos helsepersonell omgående.</li></ul></li></ul></div><div class=\"paragraph\"><b>Hudforandringer på injeksjonsstedet: </b>Fettvevet kan skrumpe (lipoatrofi) eller fortykkes (lipohypertrofi) (kan berøre færre enn 1 av 100 personer) hvis du injiserer insulin på samme sted. Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete, innskrumpet eller fortykket område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.</div><span class=\"inline-title\">b) Liste over andre bivirkninger</span><div class=\"paragraph\"><b>Mindre vanlige bivirkninger</b><br/>Kan berøre færre enn 1 av 100 personer.</div><div class=\"paragraph\"><span class=\"underline\">Symptomer på allergi:</span> Lokale allergiske reaksjoner (smerte, rødhet, elveblest, inflammasjon, blåmerker, hevelse og kløe) på injeksjonsstedet kan forekomme. Disse forsvinner vanligvis i løpet av få uker ved fortsatt bruk av insulinet. Hvis de ikke forsvinner, eller det sprer seg over hele kroppen, snakk med lege omgående. Se også Alvorlige allergiske reaksjoner ovenfor.</div><div class=\"paragraph\"><span class=\"underline\">Synsforstyrrelser:</span> Synsforstyrrelser kan oppstå i begynnelsen av en insulinbehandling, men er vanligvis av forbigående karakter.</div><div class=\"paragraph\"><span class=\"underline\">Hovne ledd:</span> Når du begynner insulinbehandlingen, kan væskeansamling forårsake hevelse rundt ankler og andre ledd. Dette er normalt av forbigående karakter, hvis ikke, snakk med legen.</div><div class=\"paragraph\"><span class=\"underline\">Diabetisk retinopati</span> (en øyesykdom relatert til diabetes som kan føre til synstap): Dersom du har diabetisk retinopati og blodsukkernivået ditt forbedres veldig raskt, kan retinopatien bli verre. Spør legen om dette.</div><span class=\"inline-title\">Sjeldne bivirkninger</span><div class=\"paragraph\">Kan berøre færre enn 1 av 1000 personer.</div><div class=\"paragraph\"><span class=\"underline\">Smertefull neuropati</span> (smerte som skyldes nerveskade): Hvis blodsukkernivået ditt forbedres veldig raskt kan du få en nerverelatert smerte. Dette kalles akutt smertefull neuropati og er vanligvis forbigående.</div><span class=\"inline-title\">c) Følger ved diabetes</span> <span class=\"inline-title\">Høyt blodsukker (hyperglykemi)</span><div class=\"paragraph\"><span class=\"underline\">Høyt blodsukker kan inntreffe hvis du:</span><ul><li>Ikke har injisert nok insulin.</li><li>Glemmer å ta insulin eller avbryter behandlingen med insulin.</li><li>Gjentatte ganger tar mindre insulin enn det du trenger.</li><li>Får en infeksjon og/eller feber.</li><li>Spiser mer enn vanlig.</li><li>Mosjonerer mindre enn vanlig.</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Varselsymptomer på høyt blodsukker:</span><br/>Varselsymptomene utvikler seg gradvis. De inkluderer: økt vannlating, tørste, manglende appetitt, uvelhet (kvalme eller oppkast), døsighet eller tretthet, rødmende hud, tørr hud, munntørrhet og fruktluktende (acetonluktende) ånde.</div><div class=\"paragraph\"><span class=\"underline\">Hva gjør du hvis du får høyt blodsukker:</span><ul><li>Dersom du får noen av symptomene nevnt ovenfor: kontroller blodsukkernivået, hvis mulig kontroller urinen for ketoner, søk deretter råd hos helsepersonell omgående.</li><li>Dette kan være symptomer på en meget alvorlig tilstand kalt diabetisk ketoacidose (opphopning av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Dersom den ikke behandles, kan den føre til diabetisk koma og til slutt død.</li></ul></div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger. Dette gjelder også bivirkninger som ikke er nevnt i pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "5. Hvordan du oppbevarer NovoRapid PumpCart",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>5. Hvordan du oppbevarer NovoRapid PumpCart</h2><div class=\"paragraph\">Oppbevares utilgjengelig for barn.<br/>Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på sylinderampullens etikett og eske etter “EXP”. Utløpsdatoen er den siste dagen i den angitte måneden.<br/>Oppbevar alltid sylinderampullen i ytteremballasjen når den ikke er i bruk for å beskytte mot lys.<br/>NovoRapid PumpCart skal ved oppbevaring og bruk beskyttes mot sterk varme og lys.</div><div class=\"paragraph\"><b><span class=\"underline\">Før anbrudd:</span> </b>NovoRapid PumpCart som ikke er tatt i bruk skal oppbevares i kjøleskap ved 2-8ºC, borte fra kjøleelementet. Skal ikke fryses.</div><div class=\"paragraph\"><b><span class=\"underline\">Under bruk eller medbrakt som reserve:</span> </b>NovoRapid PumpCart som er tatt i bruk skal ikke oppbevares i kjøleskap. NovoRapid PumpCart som er medbrakt som reserve kan oppbevares i opptil 2 uker ved høyst 30ºC. Deretter kan den brukes i opptil 7 dager ved høyst 37ºC i en pumpe som er utformet til bruk sammen med denne sylinderampullen, som Accu-Chek Insight og YpsoPump insulinpumper. Oppbevar NovoRapid PumpCart i blisterpakningen til den skal brukes, for å beskytte den mot skade. Beskytt alltid sylinderampullen mot lys under bruk.</div><div class=\"paragraph\">Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.</div></div>"
          }
        },
        {
          "title" : "6. Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>6. Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av NovoRapid PumpCart",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av NovoRapid PumpCart</h3><div class=\"paragraph\"><ul><li>Virkestoff er insulin aspart. Hver ml inneholder 100 enheter insulin aspart. Hver sylinderampulle inneholder 160 enheter insulin aspart i 1,6 ml oppløsning til injeksjon.</li><li>Andre innholdstoffer er glyserol, fenol, metakresol, sinkklorid, dinatriumfosfatdihydrat, natriumklorid, saltsyre, natriumhydroksid og vann til injeksjonsvæsker.</li></ul></div></div>"
            }
          },
          {
            "title" : "Hvordan NovoRapid PumpCart ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan NovoRapid PumpCart ser ut og innholdet i pakningen</h3><div class=\"paragraph\">NovoRapid PumpCart finnes som injeksjonsvæske, oppløsning.</div><div class=\"paragraph\">Pakningsstørrelse på 5 sylinderampuller og en flerpakning inneholdende 25 (5 pakker à 5) sylinderampuller à 1,6 ml. Ikke alle pakningstørrelser vil nødvendigvis bli markedsført.</div><div class=\"paragraph\">Oppløsningen er klar og fargeløs.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen og tilvirker",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen og tilvirker</h3><div class=\"paragraph\">Novo Nordisk A/S, Novo Allé, DK-2880 Bagsværd, Danmark</div><div class=\"paragraph\"><b>Vennligst fortsett til informasjonen i «Bruksanvisning for NovoRapid PumpCart ferdigfylt sylinderampulle»</b>.</div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 20.03.2023",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 20.03.2023</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre informasjonskilder</h3><div class=\"paragraph\">Detaljert informasjon om dette legemidlet er tilgjengelig på nettstedet til Det europeiske legemiddelkontoret (the European Medicines Agency): <a href=\"http://www.ema.europa.eu/\" title=\"\n               \n                  http://www.ema.europa.eu\n               \n            \">http://www.ema.europa.eu </a>og på nettstedet til <a href=\"http://www.felleskatalogen.no\" title=\"\n               \n                  www.felleskatalogen.no\n               \n            \">www.felleskatalogen.no</a></div></div>"
            }
          },
          {
            "title" : "Bruksanvisning for NovoRapid PumpCart ferdigfylt sylinderampulle.",
            "code" : {
              "coding" : [{
                "system" : "https://gravitatehealth.eu/section",
                "code" : "patient-info"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3><b>Bruksanvisning for NovoRapid PumpCart ferdigfylt sylinderampulle.</b></h3><span class=\"inline-title\">NovoRapid PumpCart skal kun brukes sammen med et pumpesystem for insulininfusjon utformet til bruk sammen med denne sylinderampullen, som Accu-Chek Insight og YpsoPump insulinpumper. Den må ikke brukes sammen med annet utstyr som ikke er utformet til bruk sammen med NovoRapid PumpCart, da dette kan føre til feil insulindose og påfølgende hyper- eller hypoglykemi.</span><div class=\"paragraph\"><b>Les nøye gjennom disse instruksjonene </b>før du tar i bruk NovoRapid PumpCart.</div><div class=\"paragraph\"><b>Les også nøye gjennom bruksanvisningen til pumpen </b>som følger med insulinpumpen din.<br/><img src=\"#15636649\" alt=\"null\"/>Vær særlig oppmerksom på disse merknadene, da de er viktige for sikker bruk av NovoRapid PumpCart.<ul><li>Behandle pumpen og sylinderampullen med forsiktighet, og følg instruksjonene nøye. Røff håndtering eller feilbruk kan forårsake unøyaktig dosering, og kan føre til for høyt eller for lavt blodsukkernivå.</li></ul></div><div class=\"paragraph\"><ul><li>NovoRapid PumpCart er klar til bruk direkte i pumpen.</li></ul></div><div class=\"paragraph\"><ul><li>NovoRapid PumpCart inneholder 1,6 ml insulin aspart oppløsning, tilsvarende 160 enheter.</li></ul></div><div class=\"paragraph\"><ul><li>Dette legemidlet skal aldri blandes med noen andre preparater.</li></ul></div><div class=\"paragraph\"><ul><li>Du må ikke etterfylle NovoRapid PumpCart. Når den er tom, skal den kastes.</li></ul></div><div class=\"paragraph\"><ul><li>Sørg for at du alltid har tilgjengelig en ekstra NovoRapid PumpCart.</li></ul></div><div class=\"paragraph\"><ul><li>For å sikre korrekt dosering skal NovoRapid PumpCart ikke brukes i en insulinpenn.</li></ul></div><div class=\"paragraph\"><ul><li>NovoRapid PumpCart skal beskyttes mot sterk varme og lys under oppbevaring og bruk.</li></ul></div><div class=\"paragraph\"><ul><li>NovoRapid PumpCart skal oppbevares utilgjengelig for andre, spesielt barn.</li></ul></div><div class=\"paragraph\"><img src=\"#15636648\" alt=\"null\"/></div><span class=\"inline-title\">1. Før innsetting av en NovoRapid PumpCart sylinderampulle i din pumpe</span><div class=\"paragraph\"><ul><li>La NovoRapid PumpCart få romtemperatur.</li></ul></div><div class=\"paragraph\"><ul><li>Ta NovoRapid PumpCart ut av blisterpakningen.</li></ul></div><div class=\"paragraph\"><ul><li>Kontroller etiketten for å forsikre deg om at det er NovoRapid PumpCart.</li></ul></div><div class=\"paragraph\"><ul><li>Kontroller utløpsdatoen, som er angitt på etiketten og kartongen.</li></ul></div><div class=\"paragraph\"><img src=\"#15636649\" alt=\"null\"/>Kontroller alltid at NovoRapid PumpCart ser ut som den skal. Se bilde A. Kun toppen av stempelet skal være synlig over det hvite etikettbåndet. Hvis du tror NovoRapid PumpCart er skadet, returneres preparatet til apoteket.<b>Ikke bruk den</b> hvis det er synlig skade eller det er sett lekkasje på den, eller hvis stempelet har flyttet seg slik at bunnen av stempelet er synlig over det hvite etikettbåndet. Dette kan være et resultat av insulinlekkasje.</div><div class=\"paragraph\"><img src=\"#15636649\" alt=\"null\"/>Kontroller at insulinet i NovoRapid PumpCart er klart og fargeløst. Hvis insulinet ser uklart ut, skal NovoRapid PumpCart ikke brukes. Sylinderampullen kan inneholde en liten mengde med luft i form av små bobler.</div><span class=\"inline-title\">2. Innsetting av en ny NovoRapid PumpCart sylinderampulle i din pumpe</span><div class=\"paragraph\"><ul><li>For å sette inn en ny NovoRapid PumpCart sylinderampulle i pumpen din, følg instruksjonene i bruksanvisningen som kommer sammen med pumpen.</li></ul></div><div class=\"paragraph\"><ul><li>Sett NovoRapid PumpCart inn i sylinderampullerommet i pumpen. Stempelet settes inn først.</li></ul></div><div class=\"paragraph\"><ul><li>Koble infusjonssettet med NovoRapid PumpCart ved å feste adapteren på pumpen.</li></ul></div><div class=\"paragraph\"><img src=\"#15636649\" alt=\"null\"/>Kontroller pumpen og sylinderampullen regelmessig for skader, for eksempel sprekker eller lekkasje. Dersom det lukter insulin, kan dette også indikere en lekkasje. <b>Ikke bruk</b> sylinderampullen dersom det er synlige sprekker eller lekkasje. Følg instruksjonene i pumpens bruksanvisning for bytte av sylinderampullen og for å rengjøre sylinderampullerommet i pumpen. Lekkasje av insulin kan forårsake unøyaktig dosering, og kan føre til høyt blodsukker. Se avsnitt 4 c) i pakningsvedlegget.</div><div class=\"paragraph\"><img src=\"#15636649\" alt=\"null\"/>I løpet av dagen og før leggetid må du sjekke nøye at pumpen leverer insulin og at det ikke er noen lekkasjer. Problemer med insulintilførselen medfører <b>ikke nødvendigvis</b> en varsling fra pumpen, og du kan være uvitende om at det er et problem. Det kan hende at du må sjekke blodsukkernivået ditt. Informer lege eller diabetessykepleier dersom du mistenker at det er problemer med insulintilførselen.<br/>Sørg alltid for at du har et alternativt injeksjonssystem for insulin tilgjengelig (for eksempel en injeksjonspenn) i tilfelle insulinpumpen slutter å virke. <b>Søk råd hos helsepersonell dersom du tror du kan ha svært høyt blodsukker eller diabetisk ketoacidose.</b></div><span class=\"inline-title\">3. Fjerning av en tom NovoRapid PumpCart sylinderampulle fra pumpen din</span><div class=\"paragraph\"><ul><li>Følg instruksjonene i pumpens bruksanvisning for å fjerne en tom NovoRapid PumpCart sylinderampulle fra pumpen din.</li></ul></div><div class=\"paragraph\"><ul><li>Fjern adapteren til infusjonssettet fra den tomme NovoRapid PumpCart sylinderampullen.</li></ul></div><div class=\"paragraph\"><ul><li>Kast den tomme NovoRapid PumpCart sylinderampullen og det brukte infusjonssettet som instruert av legen eller sykepleieren.</li></ul></div><div class=\"paragraph\"><ul><li>For klargjøring og innsetting av en ny NovoRapid PumpCart sylinderampulle i din pumpe, følg trinnene som beskrevet under avsnitt 1 og 2.</li></ul></div></div>"
            },
            "entry" : [{
              "reference" : "15636649"
            },
            {
              "reference" : "15636648"
            },
            {
              "reference" : "15636649"
            },
            {
              "reference" : "15636649"
            },
            {
              "reference" : "15636649"
            },
            {
              "reference" : "15636649"
            }]
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-92",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-92",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-92\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-92</b></p><a name=\"Diabetes-MPD-92\"> </a><a name=\"hcDiabetes-MPD-92\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_B6BB9798-15DA-4B87-99F9-A70679C1CA6C</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>NovoRapid PumpCart inj, oppl 100 E/ml</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_B6BB9798-15DA-4B87-99F9-A70679C1CA6C"
      }],
      "name" : [{
        "productName" : "NovoRapid PumpCart inj, oppl 100 E/ml"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-118",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-118",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-118\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-118</b></p><a name=\"Diabetes-PPD-118\"> </a><a name=\"hcDiabetes-PPD-118\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_6AAECC05-331B-4149-919F-F8728DB42C2D, <code>https://farmalogg.no/varenummer</code>/043207</p><p><b>name</b>: NovoRapid PumpCart inj, oppl 100 E/ml</p><p><b>packageFor</b>: <a href=\"Bundle-FK637674.html#MedicinalProductDefinition_Diabetes-MPD-92\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_B6BB9798-15DA-4B87-99F9-A70679C1CA6C</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_6AAECC05-331B-4149-919F-F8728DB42C2D"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "043207"
      }],
      "name" : "NovoRapid PumpCart inj, oppl 100 E/ml",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-92"
      }]
    }
  }]
}

```
