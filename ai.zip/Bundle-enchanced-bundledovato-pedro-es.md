# [Enhanced-pedro] ePI document for Dovato 50 mg/300 mg tablets Package Leaflet ES - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **[Enhanced-pedro] ePI document for Dovato 50 mg/300 mg tablets Package Leaflet ES**

## Example Bundle: [Enhanced-pedro] ePI document for Dovato 50 mg/300 mg tablets Package Leaflet ES

**Composition category:**

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

Prospecto: información para el paciente Dovato 50 mg/300 mg comprimidos recubiertos con película dolutegravir/lamivudina
**Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.**
* Conserve este prospecto, ya que puede tener que volver a leerlo.
* Si tiene alguna duda, consulte a su médico o farmacéutico.
* Este medicamento se le ha recetado solamente a usted, y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.
* Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver sección 4.


#### What is in this leaflet

 

Contenido del prospecto
1. Qué es Dovato y para qué se utiliza
1. Qué necesita saber antes de empezar a tomar Dovato
1. Cómo tomar Dovato
1. Posibles efectos adversos
1. Conservación de Dovato
1. Contenido del envase e información adicional


#### 1. What Dovato 50 mg/300 mg comprimidos recubiertos con película is and what it is used for

 

**1. Qué es Dovato y para qué se utiliza**Dovato es un medicamento que contiene dos principios activos usados para tratar la infección por el virus de la inmunodeficiencia humana (VIH): dolutegravir y lamivudina. Dolutegravir pertenece al grupo de medicamentos antirretrovirales llamados inhibidores de la integrasa (INI) y lamivudina pertenece a un grupo de medicamentos antirretrovirales denominados inhibidores de la transcriptasa inversa análogos de nucleósido (ITIAN).


#### 2. What you need to know before you take Dovato 50 mg/300 mg comprimidos recubiertos con película

 

**2. Qué necesita saber antes de empezar a tomar Dovato**
**No tome Dovato**
* si es **alérgico** (hipersensible) a dolutegravir o lamivudina o a alguno de los demás componentes de este medicamento (incluidos en la sección 6)
* si está tomando un medicamento llamado **fampridina** (también conocido como dalfampridina; utilizado para tratar la esclerosis múltiple).


#### 3. How to take Dovato 50 mg/300 mg comprimidos recubiertos con película

 

**3. Cómo tomar Dovato**
Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico. En caso de duda, consulte de nuevo a su médico o farmacéutico.

* La dosis recomendada de Dovato es **un comprimido una vez al día.**

Trague el comprimido con un poco de líquido. Dovato se puede tomar con o sin alimentos.


#### 4. Possible side effects

 

**4. Posibles efectos adversos**

Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran, **por lo que es muy importante que le comente a su médico cualquier cambio en su estado de salud.**


#### 5. How to store Dovato 50 mg/300 mg comprimidos recubiertos con película

 

**5. Conservación de Dovato**
Mantener este medicamento fuera de la vista y del alcance de los niños

No utilice este medicamento después de la fecha de caducidad que aparece en la caja y el frasco después de CAD. La fecha de caducidad es el último día del mes que se indica.

Este medicamento no requiere ninguna condición especial de conservación.

Los medicamentos no se deben tirar por los desagües ni a la basura. Pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudará a proteger el medio ambiente.


#### 6. Contents of the pack and other information

 

**6. Contenido del envase e información adicional**
**Composición de Dovato**
* Los principios activos son dolutegravir y lamivudina. Cada comprimido contiene dolutegravir sódico equivalente a 50 mg de dolutegravir y 300 mg de lamivudina.
* Los demás componentes son celulosa microcristalina, carboximetilalmidón sódico, estearato de magnesio, manitol (E421), povidona (K29/32), fumarato estearilo de sodio, hipromelosa (E464), macrogol, dióxido de titanio (E171).
* Este medicamento contiene menos de 1 mmol de sodio (23 mg) por comprimido; esto es, esencialmente “exento de sodio”.


####  Dovato 50 mg/300 mg film-coated tablets 
PMSWI:
** EU/1/19/1370/001 **PHPID:
** 0x073AF2E5B92AE19E8B67635AFFB3D6CA **
-------

Full name: **Dovato 50 mg/300 mg film-coated tablets**

 - Invented name part: ** Dovato ** 

 - Scientific name part: ** dolutegravir/lamivudine ** 

 - Strength part: ** 50 mg/300 mg ** 

 - Pharmaceutical dose form part: ** film-coated tablets ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/19/1370/001 ** 

 Region: ** ** 

Marketing authorisation holder: **ViiV Healthcare BV** 

 Identifier: 
*  **ORG-100012958** 
 

 Status: ** Active (2019-07-01T13:28:17Z) ** 

 Package 1 of 1

PMSWI: ** EU/1/19/1370/001 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Child-resistant closure** **(Glass)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Film-coated tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** DOLUTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** lamivudine ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** sodium starch glycolate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** mannitol ** 

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Active ** 

 Substance: ** DOLUTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** lamivudine ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** sodium starch glycolate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** mannitol ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "enchanced-bundledovato-pedro-es",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/97/049/001"
  },
  "type" : "document",
  "timestamp" : "2023-04-25T11:55:27Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/compositione722f6782d3f34f86982e14386c8811dhh",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "compositione722f6782d3f34f86982e14386c8811dhh",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"es\" lang=\"es\"><a name=\"Composition_compositione722f6782d3f34f86982e14386c8811dhh\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition compositione722f6782d3f34f86982e14386c8811dhh</b></p><a name=\"compositione722f6782d3f34f86982e14386c8811dhh\"> </a><a name=\"hccompositione722f6782d3f34f86982e14386c8811dhh\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: es</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/yy</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>date</b>: 2022-04-29 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mra-7c9b97127f73ff3605a10eb1c2cc24d1\">Organization European Medicines Agency</a></p><p><b>title</b>: TEST PURPOSES ONLY - Dovato 50 mg/300 mg comprimidos recubiertos con película</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-04-29 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "yy"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "date" : "2022-04-29T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mra-7c9b97127f73ff3605a10eb1c2cc24d1"
      }],
      "title" : "TEST PURPOSES ONLY - Dovato 50 mg/300 mg comprimidos recubiertos con película",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-04-29T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PACKAGE LEAFLET"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Prospecto: información para el paciente Dovato 50 mg/300 mg comprimidos recubiertos con película dolutegravir/lamivudina <b>Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.</b><ul><li>Conserve este prospecto, ya que puede tener que volver a leerlo.</li><li>Si tiene alguna duda, consulte a su médico o farmacéutico.</li><li>Este medicamento se le ha recetado solamente a usted, y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.</li><li>Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver sección 4.</li></ul></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Contenido del prospecto<ol><li>Qué es Dovato y para qué se utiliza</li><li>Qué necesita saber antes de empezar a tomar Dovato</li><li>Cómo tomar Dovato</li><li>Posibles efectos adversos</li><li>Conservación de Dovato</li><li>Contenido del envase e información adicional</li></ol></div>"
          }
        },
        {
          "title" : "1. What Dovato 50 mg/300 mg comprimidos recubiertos con película is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What Dovato 50 mg/300 mg comprimidos recubiertos con película is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><b>1. Qué es Dovato y para qué se utiliza</b> Dovato es un medicamento que contiene dos principios activos usados para tratar la infección por el virus de la inmunodeficiencia humana (VIH): dolutegravir y lamivudina. Dolutegravir pertenece al grupo de medicamentos antirretrovirales llamados inhibidores de la integrasa (INI) y lamivudina pertenece a un grupo de medicamentos antirretrovirales denominados inhibidores de la transcriptasa inversa análogos de nucleósido (ITIAN).</div>"
          }
        },
        {
          "title" : "2. What you need to know before you take Dovato 50 mg/300 mg comprimidos recubiertos con película",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take Dovato 50 mg/300 mg comprimidos recubiertos con película"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><b>2. Qué necesita saber antes de empezar a tomar Dovato</b> <b>No tome Dovato</b><ul><li>si es <b>alérgico</b> (hipersensible) a dolutegravir o lamivudina o a alguno de los demás componentes de este medicamento (incluidos en la sección 6)</li><li>si está tomando un medicamento llamado <b>fampridina</b> (también conocido como dalfampridina; utilizado para tratar la esclerosis múltiple).</li></ul></div>"
          }
        },
        {
          "title" : "3. How to take Dovato 50 mg/300 mg comprimidos recubiertos con película",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take Dovato 50 mg/300 mg comprimidos recubiertos con película"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><b>3. Cómo tomar Dovato</b><p>Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico. En caso de duda, consulte de nuevo a su médico o farmacéutico.</p><ul><li>La dosis recomendada de Dovato es <b>un comprimido una vez al día.</b></li></ul><p>Trague el comprimido con un poco de líquido. Dovato se puede tomar con o sin alimentos.</p></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><b>4. Posibles efectos adversos</b></p><p>Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran, <b>por lo que es muy importante que le comente a su médico cualquier cambio en su estado de salud.</b></p></div>"
          }
        },
        {
          "title" : "5. How to store Dovato 50 mg/300 mg comprimidos recubiertos con película",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store Dovato 50 mg/300 mg comprimidos recubiertos con película"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><b>5. Conservación de Dovato</b><p>Mantener este medicamento fuera de la vista y del alcance de los niños</p><p>No utilice este medicamento después de la fecha de caducidad que aparece en la caja y el frasco después de CAD. La fecha de caducidad es el último día del mes que se indica.</p><p>Este medicamento no requiere ninguna condición especial de conservación.</p><p>Los medicamentos no se deben tirar por los desagües ni a la basura. Pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudará a proteger el medio ambiente.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><b>6. Contenido del envase e información adicional</b> <b>Composición de Dovato</b><ul><li>Los principios activos son dolutegravir y lamivudina. Cada comprimido contiene dolutegravir sódico equivalente a 50 mg de dolutegravir y 300 mg de lamivudina.</li><li>Los demás componentes son celulosa microcristalina, carboximetilalmidón sódico, estearato de magnesio, manitol (E421), povidona (K29/32), fumarato estearilo de sodio, hipromelosa (E464), macrogol, dióxido de titanio (E171).</li><li>Este medicamento contiene menos de 1 mmol de sodio (23 mg) por comprimido; esto es, esencialmente “exento de sodio”.</li></ul></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-dolutegravirsodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-dolutegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-dolutegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-dolutegravirsodium</b></p><a name=\"ingredient-for-dovato-dolutegravirsodium\"> </a><a name=\"hcingredient-for-dovato-dolutegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/1Q1V9V5WYQ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 1Q1V9V5WYQ}\">DOLUTEGRAVIR SODIUM</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>50 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "1Q1V9V5WYQ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "1Q1V9V5WYQ",
              "display" : "DOLUTEGRAVIR SODIUM"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 50,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-lamivudine",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-lamivudine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-lamivudine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-lamivudine</b></p><a name=\"ingredient-for-dovato-lamivudine\"> </a><a name=\"hcingredient-for-dovato-lamivudine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/2T8Q726O95 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 2T8Q726O95}\">lamivudine</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>300 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "2T8Q726O95"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "2T8Q726O95",
              "display" : "lamivudine"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 300,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-microcrystallinecellulose</b></p><a name=\"ingredient-for-dovato-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-dovato-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-sodiumstarchglycolate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-sodiumstarchglycolate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-sodiumstarchglycolate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-sodiumstarchglycolate</b></p><a name=\"ingredient-for-dovato-sodiumstarchglycolate\"> </a><a name=\"hcingredient-for-dovato-sodiumstarchglycolate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/H8AV0SQX4D (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta H8AV0SQX4D}\">sodium starch glycolate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "H8AV0SQX4D"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "H8AV0SQX4D",
              "display" : "sodium starch glycolate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-magnesiumstearate</b></p><a name=\"ingredient-for-dovato-magnesiumstearate\"> </a><a name=\"hcingredient-for-dovato-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-mannitol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-mannitol",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-mannitol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-mannitol</b></p><a name=\"ingredient-for-dovato-mannitol\"> </a><a name=\"hcingredient-for-dovato-mannitol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/3OWL53L36A (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 3OWL53L36A}\">mannitol</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "3OWL53L36A"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "3OWL53L36A",
              "display" : "mannitol"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-dolutegravirsodium",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-dolutegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-dolutegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-dolutegravirsodium</b></p><a name=\"substance-dolutegravirsodium\"> </a><a name=\"hcsubstance-dolutegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/1Q1V9V5WYQ (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>441.36</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C20H18F2N305.Na</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(4R,12.ALPHA.S)-N-((2,4-DIFLUOROPHENYL)METHYL)-7-HYDROXY-4-METHYL-6,8-DIOXO-3,4,6,8,12,12.ALPHA.-HEXAHYDRO-2H-PYRIDO(1',2':4,5)PYRAZINO(2,1-.BETA.)(1,3)OXAZINE-9-CARBOXAMIDE</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "1Q1V9V5WYQ"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 441.36
        }
      }],
      "structure" : {
        "molecularFormula" : "C20H18F2N305.Na"
      },
      "name" : [{
        "name" : "(4R,12.ALPHA.S)-N-((2,4-DIFLUOROPHENYL)METHYL)-7-HYDROXY-4-METHYL-6,8-DIOXO-3,4,6,8,12,12.ALPHA.-HEXAHYDRO-2H-PYRIDO(1',2':4,5)PYRAZINO(2,1-.BETA.)(1,3)OXAZINE-9-CARBOXAMIDE",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-lamivudine",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-lamivudine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-lamivudine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-lamivudine</b></p><a name=\"substance-lamivudine\"> </a><a name=\"hcsubstance-lamivudine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/2T8Q726O95 (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>229.26</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C8H11N303S</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(-)-1-((2R,5S)-2-(HYDROXYMETHYL)-1,3-OXATHIOLAN-5-YL)CYTOSINE</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "2T8Q726O95"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 229.26
        }
      }],
      "structure" : {
        "molecularFormula" : "C8H11N303S"
      },
      "name" : [{
        "name" : "(-)-1-((2R,5S)-2-(HYDROXYMETHYL)-1,3-OXATHIOLAN-5-YL)CYTOSINE",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-49178f16170ee8a6bc2a4361c1748d5f",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-49178f16170ee8a6bc2a4361c1748d5f</b></p><a name=\"ap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><a name=\"hcap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "123456"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization49178f16170ee8a6bc2a4361c1748d5f0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization49178f16170ee8a6bc2a4361c1748d5f0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization49178f16170ee8a6bc2a4361c1748d5f0</b></p><a name=\"authorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><a name=\"hcauthorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2019-07-01 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mah-31ff1af739c7dcf77386a86f8dd83d29\">Organization ViiV Healthcare BV</a></p><p><b>regulator</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mra-7c9b97127f73ff3605a10eb1c2cc24d1\">Organization European Medicines Agency</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2019-07-01T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-31ff1af739c7dcf77386a86f8dd83d29"
      },
      "regulator" : {
        "reference" : "Organization/mra-7c9b97127f73ff3605a10eb1c2cc24d1"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/man-173fde4cb6b1018cb7ec8ab708d3961c",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "man-173fde4cb6b1018cb7ec8ab708d3961c",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization man-173fde4cb6b1018cb7ec8ab708d3961c</b></p><a name=\"man-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><a name=\"hcman-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100004538 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000033}\">Manufacturer</span></p><p><b>name</b>: GLAXO WELLCOME, S.A.</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Avda. Extremadura 3, 09400 Aranda De Duero Aranda De Duero ES(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100004538"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000033",
          "display" : "Manufacturer"
        }]
      }],
      "name" : "GLAXO WELLCOME, S.A.",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Avda. Extremadura 3, 09400 Aranda De Duero Aranda De Duero ES",
          "line" : ["Avda. Extremadura 3, 09400 Aranda De Duero"],
          "city" : "Aranda De Duero",
          "country" : "ES"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-31ff1af739c7dcf77386a86f8dd83d29",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-31ff1af739c7dcf77386a86f8dd83d29",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-31ff1af739c7dcf77386a86f8dd83d29</b></p><a name=\"mah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><a name=\"hcmah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100012958 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: ViiV Healthcare BV</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Van Asch van Wijckstraat 55H Amersfoort NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100012958"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "ViiV Healthcare BV",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Van Asch van Wijckstraat 55H Amersfoort NL",
          "line" : ["Van Asch van Wijckstraat 55H"],
          "city" : "Amersfoort",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mra-7c9b97127f73ff3605a10eb1c2cc24d1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mra-7c9b97127f73ff3605a10eb1c2cc24d1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mra-7c9b97127f73ff3605a10eb1c2cc24d1</b></p><a name=\"mra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><a name=\"hcmra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100013412 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000032}\">Medicines Regulatory Authority</span></p><p><b>name</b>: European Medicines Agency</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100013412"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000032",
          "display" : "Medicines Regulatory Authority"
        }]
      }],
      "name" : "European Medicines Agency",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL",
          "line" : ["Carretera De Martorell 41 61, Poligono Industrial Nord-Est"],
          "city" : "Amsterdam",
          "postalCode" : "1083 HS",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-2977a2afce16a0bd914b8d242dd126b5",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-2977a2afce16a0bd914b8d242dd126b5",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-2977a2afce16a0bd914b8d242dd126b5</b></p><a name=\"ppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><a name=\"hcppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>name</b>: Dovato 50 mg/300 mg film-coated tablets 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003203}\">Glass</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "name" : "Dovato 50 mg/300 mg film-coated tablets 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003203",
              "display" : "Glass"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp16598f252d07b4784b82ba43cf9e847e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp16598f252d07b4784b82ba43cf9e847e</b></p><a name=\"mp16598f252d07b4784b82ba43cf9e847e\"> </a><a name=\"hcmp16598f252d07b4784b82ba43cf9e847e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001, <code>https://www.who-umc.org/phpid</code>/0x073AF2E5B92AE19E8B67635AFFB3D6CA</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Dovato 50 mg/300 mg film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Dovato</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: dolutegravir/lamivudine</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 50 mg/300 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0x073AF2E5B92AE19E8B67635AFFB3D6CA"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Dovato 50 mg/300 mg film-coated tablets",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Dovato",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "dolutegravir/lamivudine",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "50 mg/300 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "film-coated tablets",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-49178f16170ee8a6bc2a4361c1748d5f",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-49178f16170ee8a6bc2a4361c1748d5f</b></p><a name=\"mid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><a name=\"hcmid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073665}\">Film-coated tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073665",
          "display" : "Film-coated tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }]
    }
  }]
}

```
