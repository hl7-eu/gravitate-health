# ePI document Bundle for Karvea 75 mg tablet Package Leaflet for language es - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Karvea 75 mg tablet Package Leaflet for language es**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **14 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

## Example Bundle: ePI document Bundle for Karvea 75 mg tablet Package Leaflet for language es

**Composition category:**Raw

**Composition status:**final

### B. PROSPECTO

 

unavailable


#### PROSPECTO: INFORMACIÓN PARA EL USUARIO

 

**Prospecto: información para el usuario**

 

**Biktarvy 50 mg/200 mg/25 mg comprimidos recubiertos con película**

 

bictegravir/emtricitabina/tenofovir alafenamida

 

 

**Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.**

 

* Conserve este prospecto, ya que puede tener que volver a leerlo.
* Si tiene alguna duda, consulte a su médico o farmacéutico.
* Este medicamento se le ha recetado solamente a usted, y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.
* Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver sección 4.

 


#### Contenido del prospecto

 

**Contenido del prospecto**

 

1. Qué es Biktarvy y para qué se utiliza
1. Qué necesita saber antes de empezar a tomar Biktarvy
1. Cómo tomar Biktarvy
1. Posibles efectos adversos
1. Conservación de Biktarvy
1. Contenido del envase e información adicional

 

 


#### 1. Qué es Karvea y para qué se utiliza

 

 

Biktarvy contiene tres principios activos:

* **bictegravir,** un medicamento antirretroviral conocido como inhibidor de la transferencia de las hebras de la integrasa (INI)
* **emtricitabina,** un medicamento antirretroviral de un tipo conocido como nucleósido inhibidor de la transcriptasa inversa (ITIAN)
* **tenofovir alafenamida,** un medicamento antirretroviral de un tipo conocido como nucleótido inhibidor de la transcriptasa inversa (ITIANt)

 

Biktarvy es un comprimido único para el tratamiento de la infección por el virus de la inmunodeficiencia humana 1 (VIH-1) en adultos.

 

Biktarvy reduce la cantidad de VIH presente en el organismo. Esto mejora el sistema inmunitario y disminuye el riesgo de desarrollar enfermedades asociadas con la infección por el VIH.

 


#### 2. Qué necesita saber antes de empezar a tomar Karvea

 

 

**No tome Biktarvy**

* **Si es alérgico a bictegravir, emtricitabina, tenofovir alafenamida** o a alguno de los demás componentes de este medicamento (incluidos en la sección 6 de este prospecto).

* **Si actualmente está tomando alguno de los siguientes medicamentos:**
* 
* **rifampicina** utilizada para tratar algunas infecciones bacterianas como la tuberculosis
* **hierba de San Juan** (**Hypericum perforatum**, hipérico), un medicamento a base de plantas utilizado para la depresión y la ansiedad, o productos que la contengan.

 

* Si está tomando alguno de estos medicamentos, **no tome Biktarvy y consulte a su médico** **inmediatamente.**

 

**Advertencias y precauciones**

 

**Consulte a su médico antes de empezar a tomar Biktarvy:**

 

* **Si tiene problemas hepáticos o antecedentes de enfermedad hepática, incluida la hepatitis.** Los pacientes que padecen de enfermedades hepáticas, como la hepatitis B o C crónica, y están en tratamiento con antirretrovirales tienen más riesgo de presentar complicaciones hepáticas graves y potencialmente mortales. Si tiene infección por el virus de la hepatitis B, su médico evaluará detenidamente la mejor pauta terapéutica para usted.

* **Si tiene hepatitis B.** Los problemas hepáticos pueden empeorar después de dejar de tomar Biktarvy.

* No deje de tomar Biktarvy si tiene hepatitis B. Hable antes con su médico. Puede consultar más detalles en la sección 3, **No interrumpa el tratamiento con Biktarvy.**

 

**Mientras esté tomando Biktarvy**

 

Una vez que empiece a tomar Biktarvy, esté atento a:

 

* **Signos de inflamación o infección**
* **Dolor articular, rigidez o problemas óseos**

 

* **Si nota cualquiera de estos síntomas, informe a su médico inmediatamente.** Puede consultar más información en la sección 4, **Posibles efectos adversos**.

 

Aunque no se han observado problemas renales con Biktarvy, existe la posibilidad de que pueda experimentar problemas renales si toma Biktarvy durante un periodo de tiempo prolongado.

 

Mientras esté tomando este medicamento **aún puede transmitir el VIH a los demás,** aunque un tratamiento antirretroviral eficaz reduzca el riesgo. Consulte a su médico sobre qué precauciones son necesarias para no infectar a otras personas. Este medicamento no es una cura para la infección por el VIH. Mientras usted esté tomando Biktarvy podrá seguir padeciendo infecciones u otras enfermedades asociadas con la infección por el VIH.

 

**Niños y adolescentes**

 

**No administre este medicamento a niños y adolescentes menores de 18 años de edad.** No se ha estudiado todavía el uso de Biktarvy en niños y adolescentes menores de 18 años de edad.

 

**Otros medicamentos y Biktarvy**

 

**Informe a su médico o farmacéutico si está tomando, ha tomado recientemente o pudiera tener que tomar cualquier otro medicamento.** Biktarvy puede interaccionar con otros medicamentos. Como consecuencia, los niveles sanguíneos de Biktarvy o de otros medicamentos se pueden ver afectados. Esto puede impedir que sus medicamentos funcionen correctamente o empeorar sus posibles efectos adversos. En algunos casos, su médico puede tener que ajustar la dosis o comprobar sus concentraciones sanguíneas.

 

**Medicamentos que nunca se deben tomar con Biktarvy:**

 

* **rifampicina** utilizada para tratar algunas infecciones bacterianas como la tuberculosis
* **hierba de San Juan** (**Hypericum perforatum**, hipérico), un medicamento a base de plantas utilizado para la depresión y la ansiedad, o productos que lo contengan**.**

 

* Si está tomando alguno de estos medicamentos, **no tome Biktarvy e informe a su médico** **inmediatamente.**

 

**Consulte con su médico si está tomando:**

 

* **medicamentos utilizados para tratar el VIH y/o la hepatitis B** que contengan:
* 
* adefovir dipivoxil, atazanavir, bictegravir, emtricitabina, lamivudina, tenofovir alafenamida o tenofovir disoproxilo

* **antibióticos, utilizados para tratar las infecciones bacterianas**, que contengan:
* 

* azitromicina, claritromicina, rifabutina o rifapentina


* **antiepilépticos,** utilizados para tratar la epilepsia, que contengan:
* 
* carbamazepina, oxcarbazepina, fenobarbital o fenitoína

* **inmunosupresores,** utilizados para controlar la respuesta inmunitaria del organismo tras un trasplante, que contengan ciclosporina
* **medicamentos para la curación de úlceras** que contengan sucralfato

* **Informe a su médico si está tomando alguno de estos medicamentos.** No interrumpa su tratamiento sin consultar con su médico.

 

**Consulte a su médico o farmacéutico si está tomando:**

* **antiácidos** para tratar úlceras estomacales, acidez estomacal o reflujo ácido, que contengan hidróxido de aluminio y/o de magnesio
* **suplementos de minerales** o **de vitaminas,** que contengan magnesio o hierro

* **Consulte a su médico o farmacéutico antes de tomar Biktarvy** si está tomando alguno de estos medicamentos.

**Antiácidos y suplementos de magnesio:** tendrá que tomar Biktarvy al menos 2 horas **antes** de tomar los antiácidos o suplementos que contengan aluminio y/o magnesio. O puede tomar Biktarvy junto con alimentos al menos 2 horas **después** de la toma del antiácido o suplemento que contenga aluminio y/o magnesio.

**Suplementos de hierro:** tendrá que tomar Biktarvy al menos 2 horas **antes** de tomar los suplementos de hierro o puede tomarlos todos juntos con alimentos.

 

**Embarazo y lactancia**

* Si está embarazada o en periodo de lactancia, cree que podría estar embarazada o tiene intención de quedarse embarazada, consulte a su médico o farmacéutico antes de utilizar este medicamento.
* Informe a su médico inmediatamente si se queda embarazada y pregunte sobre los posibles beneficios y riesgos de su tratamiento antirretroviral para usted y para su hijo.

 

Si ha tomado Biktarvy durante su embarazo su médico puede solicitar que se haga análisis de sangre periódicos y otras pruebas diagnósticas para controlar el desarrollo de su niño. En niños cuyas madres tomaron nucleósidos inhibidores de la transcriptasa inversa (ITIAN) durante el embarazo, el beneficio de la protección frente al VIH fue mayor que el riesgo de que se produjeran efectos adversos.

 

**No dé el pecho a su hijo durante el tratamiento con Biktarvy.** Esto se debe a que algunos de los principios activos de este medicamento pasan a la leche materna. Se recomienda que no dé el pecho para evitar que transmita el virus al niño a través de la leche materna. Si realmente desea amamantar, hable primero con su médico.

 

**Conducción y uso de máquinas**

 

Biktarvy puede causar mareo. Si nota mareo durante el tratamiento con Biktarvy, no conduzca ni maneje herramientas o máquinas.

 

**Biktarvy contiene sodio**

 

Este medicamento contiene menos de 1 mmol de sodio (23 mg) por comprimido; esto es, esencialmente “exento de sodio”.

 


#### 3. Cómo tomar Karvea

 

Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico.

En caso de duda, consulte de nuevo a su médico o farmacéutico.

 

**La dosis recomendada es:**

 

**Adultos:** un comprimido al día, con o sin alimentos

No mastique, triture ni divida el comprimido.

 

* **Consulte a su médico o farmacéutico si está tomando:**

* **antiácidos** para tratar úlceras estomacales, acidez estomacal o reflujo ácido, que contengan hidróxido de aluminio y/o de magnesio
* **suplementos de minerales** o **vitaminas** que contengan magnesio o hierro

* **Vea la sección 2 para más información** sobre cómo tomar estos medicamentos con Biktarvy.

 

**Si toma más Biktarvy del que debe**

 

Si toma más cantidad de la dosis recomendada de Biktarvy puede correr mayor riesgo de experimentar posibles efectos adversos con este medicamento (ver sección 4, **Posibles efectos adversos**).

 

Consulte inmediatamente a su médico o acuda al servicio de urgencias más cercano. Lleve consigo el frasco de comprimidos para que pueda describir fácilmente qué ha tomado.

 

**Si olvidó tomar Biktarvy**

 

Es importante que no olvide una dosis de Biktarvy.

 

Si olvida una dosis:

* **Si se da cuenta en las 18 horas** posteriores a la hora a la que normalmente toma Biktarvy, debe tomar el comprimido tan pronto como sea posible. Luego tome la dosis siguiente de la forma habitual.
* **Si se da cuenta después de 18 horas o más** de la hora a la que normalmente toma Biktarvy, no tome la dosis olvidada. Espere y tome la siguiente dosis a la hora habitual.

 

**Si vomita** antes de que transcurra 1 hora tras haber tomado Biktarvy, tome otro comprimido. Si vomita transcurrida 1 hora de haber tomado Biktarvy, no necesita tomar otro comprimido hasta el momento de la hora habitual.

 

**No interrumpa el tratamiento con Biktarvy**

 

**No interrumpa el tratamiento con Biktarvy sin hablar antes con su médico.** Interrumpir Biktarvy puede afectar gravemente el funcionamiento de tratamientos futuros. Si se interrumpe Biktarvy por algún motivo, consulte con su médico antes de reiniciar la toma de comprimidos de Biktarvy.

 

**Cuando vea que le queda poca cantidad de Biktarvy,** acuda a su médico o farmacéutico para que le proporcione más. Esto es muy importante, ya que la cantidad de virus puede empezar a aumentar si el medicamento se interrumpe incluso durante un corto periodo de tiempo. Es posible que entonces la enfermedad se vuelva más difícil de tratar.

 

**Si tiene infección por VIH y hepatitis B** es especialmente importante no suspender su tratamiento con Biktarvy sin antes hablar con su médico. Puede necesitar hacerse análisis de sangre durante varios meses tras suspender el tratamiento. En algunos pacientes con enfermedad hepática avanzada o cirrosis no se recomienda suspender el tratamiento ya que esto puede producir un empeoramiento de su hepatitis, situación que puede ser potencialmente mortal.

 

* **Hable con su médico inmediatamente** acerca de síntomas nuevos o inusuales tras suspender su tratamiento, particularmente síntomas que asocie con la infección por el virus de la hepatitis B.

 

Si tiene cualquier otra duda sobre el uso de este medicamento, pregunte a su médico o farmacéutico.

 


#### 4. Posibles efectos adversos

 

 

Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.

 

**Posibles efectos adversos: informe a un médico inmediatamente**

 

* **Cualquier signo de inflamación o de infección.** En algunos pacientes con infección avanzada por el VIH (sida) y antecedentes de infecciones oportunistas (infecciones que ocurren en personas con un sistema inmunitario débil), se pueden producir signos y síntomas de inflamación por infecciones previas poco después de iniciar el tratamiento contra el VIH. Se cree que estos síntomas se deben a una mejoría de la respuesta inmunitaria del organismo, que le permite combatir infecciones que podrían haber estado presentes sin síntomas obvios.

* Se pueden producir también **trastornos autoinmunitarios,** en los que el sistema inmunitario ataca a los tejidos sanos del organismo, después de que empiece a tomar medicamentos para la infección por el VIH. Los trastornos autoinmunitarios se pueden producir muchos meses después del inicio del tratamiento. Esté atento a cualquier síntoma de infección u otros síntomas, como:

* debilidad muscular
* debilidad que se inicia en las manos y los pies y se desplaza hacia el tronco
* palpitaciones, temblor o hiperactividad

 

* **Si nota cualquiera de estos síntomas o cualquier síntoma de inflamación o infección, informe a su médico inmediatamente.**

 

**Efectos adversos frecuentes**

**(pueden afectar hasta 1 de cada 10 personas)**

* depresión
* sueños anormales
* dolor de cabeza
* mareo
* diarrea
* ganas de vomitar (**náuseas**)
* cansancio (**fatiga**)

 

**Efectos adversos poco frecuentes**

(**pueden afectar hasta 1 de cada 100 personas**)

* anemia

* vómitos

* dolor de estómago

* problemas digestivos que generan molestias después de las comidas (**dispepsia**)

* gases (**flatulencia**)

* hinchazón de la cara, labios, lengua o garganta (**angioedema**)

* picazón (**prurito**)

* erupción

* habones (**urticaria**)

* dolor en las articulaciones (**artralgia**)

* comportamiento suicida

* ansiedad

* trastornos del sueño

 

**Los análisis de sangre también pueden mostrar:**

*              Concentraciones más altas de sustancias llamadas bilirrubina y/o creatinina sérica en la sangre

 

*          **Si considera que alguno de los efectos adversos que sufre es grave, informe a su médico.**

**Otros efectos que se pueden observar durante el tratamiento contra el VIH**

 

La frecuencia de los siguientes efectos adversos se considera no conocida (la frecuencia no se puede estimar a partir de los datos disponibles).

 

* **Problemas óseos.** Algunos pacientes tratados con medicamentos antirretrovirales combinados como Biktarvy pueden desarrollar una enfermedad de los huesos llamada **osteonecrosis** (muerte del tejido óseo debida a una pérdida del suministro de sangre al hueso). Tomar este tipo de medicamentos durante un tiempo prolongado, tomar corticosteroides, beber alcohol, tener un sistema inmunitario muy débil y tener sobrepeso, pueden ser algunos de los muchos factores de riesgo para desarrollar esta enfermedad. Los signos de osteonecrosis son:
* 
* rigidez articular
* molestias y dolores articulares (especialmente de la cadera, la rodilla y el hombro)
* dificultad para moverse

 

* **Si nota cualquiera de estos síntomas, informe a su médico.**

 

Durante el tratamiento del VIH puede haber un aumento en el peso y en los niveles de glucosa y lípidos en la sangre. Esto puede estar en parte relacionado con la recuperación de la salud y con el estilo de vida y, en el caso de los lípidos en la sangre, algunas veces con los medicamentos contra el VIH por sí mismos. Su médico le controlará estos cambios.

 

**Comunicación de efectos adversos**

 

Si experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del sistema nacional de notificación incluido en el [Apéndice V.](http://www.ema.europa.eu/docs/en_GB/document_library/Template_or_form/2013/03/WC500139752.doc) Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.

 

 


#### 5. Conservación de Karvea

 

Mantener este medicamento fuera de la vista y del alcance de los niños.

 

No utilice este medicamento después de la fecha de caducidad que aparece en la caja y en el frasco después de {CAD}. La fecha de caducidad es el último día del mes que se indica.

 

Conservar en el embalaje original para protegerlo de la humedad. Mantener el frasco perfectamente cerrado. No utilizar si falta el sello del frasco o está roto.

 

Los medicamentos no se deben tirar por los desagües ni a la basura. Pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudará a proteger el medio ambiente.

 


#### 6. Contenido del envase e información adicional

 

Karvea indeholder:

* Aktivt stof: irbesartan. Hver Karvea-tablet 75 mg indeholder 75 mg irbesartan.
* Øvrige indholdsstoffer: lactosemonohydrat, mikrokrystallinsk cellulose, croscarmellosenatrium, magnesiumstearat, kolloid silica, prægelatineret majsstivelse, poloaxamer 188.
Se punkt 2 ”Aprovel indeholder lactose”

Udseende og pakningstørrelser Karvea 75 mg tabletter er hvide til mathvide, bikonvekse og ovale med et hjerte præget på den ene side og nummeret 2771 på den anden side.

Karvea 75 mg tabletter leveres i blisterpakninger af 14, 28, 56 eller 98 tabletter. Der fås også enkeltdosisblisterpakninger med 56 x 1 tablet til hospitalsbrug.

Ikke alle pakningsstørrelser er nødvendigvis markedsført.

Indehaveren af markedsføringstilladelsen:

Sanofi Winthrop Industrie 82 avenue Raspail 94250 Gentilly Frankrig

Fremstiller:

SANOFI WINTHROP INDUSTRIE 1, rue de la Vierge Ambarès & Lagrave F-33565 Carbon Blanc Cedex - Frankrig

SANOFI WINTHROP INDUSTRIE 30-36 Avenue Gustave Eiffel, BP 7F-37071 Tours Cedex 2 - Frankrig

Hvis du vil have yderligere oplysninger om Karvea, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:

België/Belgique/Belgien Sanofi Belgium Tél/Tel: +32 (0)2 710 54
Lietuva Swixx Biopharma UAB Tel: +370 5 236 91
България Swixx Biopharma EOOD Тел.: +359 (0)2 4942
Luxembourg/Luxemburg Sanofi Belgium
Tél/Tel: +32 (0)2 710 54 00 (Belgique/Belgien)

Česká republika sanofi-aventis, s.r.o. Tel: +420 233 086
Magyarország SANOFI-AVENTIS Zrt. Tel.: +36 1 505 0 Danmark Sanofi A/S Tlf: +45 45 16 70
Malta Sanofi S.r.l. Tel: +39 02 39394

Deutschland Sanofi-Aventis Deutschland GmbH Tel: 0800 52 52 Tel. aus dem Ausland: +49 69 305 21
Nederland Sanofi B.V. Tel: +31 20 245 4 Eesti Swixx Biopharma OÜ Tel: +372 640 10
Norge sanofi-aventis Norge AS Tlf: +47 67 10 71
Ελλάδα Sanofi-Aventis Μονοπρόσωπη AEBE Τηλ: +30 210 900 16
Österreich sanofi-aventis GmbH Tel: +43 1 80 185 – 0

España sanofi-aventis, S.A. Tel: +34 93 485 94
Polska sanofi-aventis Sp. z o.o. Tel.: +48 22 280 00
France Sanofi Winthrop Industrie Tél:
0 800 222 Appel depuis l’étranger : +33 1 57 63 23
Portugal Sanofi - Produtos Farmacêuticos, Lda Tel: +351 21 35 89
Hrvatska Swixx Biopharma d.o.o. Tel: +385 1 2078 România Sanofi Romania SRL Tel: +40 (0) 21 317 31
Ireland sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +353 (0) 1 403 56
Slovenija Swixx Biopharma d.o.o. Tel: +386 1 235 51
Ísland Vistor hf. Sími: +354 535 7 Slovenská republika Swixx Biopharma s.r.o. Tel: +421 2 208 33
Italia Sanofi S.r.l. Tel: 800.536 Suomi/Finland Sanofi Oy Puh/Tel: +358 (0) 201 200
Κύπρος C.A. Papaellinas Ltd. Τηλ: +357 22 741 Sverige Sanofi AB Tel: +46 (0)8 634 50
Latvija Swixx Biopharma SIA Tel: +371 6 616 47
United Kingdom (Northern Ireland) sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +44 (0) 800 035 2 Denne indlægsseddel blev senest ændret

Du kan finde yderligere information om Karvea på Det Europæiske Lægemiddelagenturs hjemmeside


####  Karvea 75 mg tablet 
PMSWI:
** EU/1/97/049/001 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E82719 **
-------

Full name: **Karvea 75 mg tablet**

 - Invented name part: ** Karvea ** 

 - Scientific name part: ** irbesartan ** 

 - Strength part: ** 75 mg ** 

 - Pharmaceutical dose form part: ** tablet ** 

 Name usage: **English (Denmark)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 Package 1 of 4

PMSWI: ** EU/1/97/049/010 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **28 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 2 of 4

PMSWI: ** EU/1/97/049/001 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **56 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 3 of 4

PMSWI: ** EU/1/97/049/002 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **98 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 4 of 4

PMSWI: ** EU/1/97/049/003 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-es-dcaa4d32aa6658a8df831551503e52ee",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "es",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/97/049/001"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-es-873a1a47330e628770640f9c96c0761e",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-es-873a1a47330e628770640f9c96c0761e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"es\" lang=\"es\"><a name=\"Composition_composition-es-873a1a47330e628770640f9c96c0761e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-es-873a1a47330e628770640f9c96c0761e</b></p><a name=\"composition-es-873a1a47330e628770640f9c96c0761e\"> </a><a name=\"hccomposition-es-873a1a47330e628770640f9c96c0761e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: es</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/EU/1/97/049/001</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p><p><b>title</b>: TEST PURPOSES ONLY - Karvea 75 mg tablet</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "EU/1/97/049/001"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }],
      "title" : "TEST PURPOSES ONLY - Karvea 75 mg tablet",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. PROSPECTO",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PROSPECTO"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><a name=\"page1\" id=\"page1\"></a><strong><span>Prospecto: informaci&#243;n para el usuario</span></strong></p><p><span>&#xa0;</span></p><p><strong><span>Biktarvy 50 mg/200 mg/25 mg comprimidos recubiertos con pel&#237;cula</span></strong></p><p><span>&#xa0;</span></p><p><span>bictegravir/emtricitabina/tenofovir alafenamida</span></p><p><span>&#xa0;</span></p><p><span>&#xa0;</span></p><p><strong><span>Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene informaci&#243;n importante para usted.</span></strong></p><p><span>&#xa0;</span></p><ul><li><span>Conserve este prospecto, ya que puede tener que volver a leerlo.</span></li><li><span>Si tiene alguna duda, consulte a su m&#233;dico o farmac&#233;utico.</span></li><li><span>Este medicamento se le ha recetado solamente a usted, y no debe d&#225;rselo a otras personas aunque tengan los mismos s&#237;ntomas que usted, ya que puede perjudicarles.</span></li><li><span>Si experimenta efectos adversos, consulte a su m&#233;dico o farmac&#233;utico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver secci&#243;n 4.</span></li></ul><p><span>&#xa0;</span></p></div>"
          }
        },
        {
          "title" : "Contenido del prospecto",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Contenido del prospecto"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Contenido del prospecto</span></strong></p><p><span>&#xa0;</span></p><ol><li><span>Qu&#233; es Biktarvy y para qu&#233; se utiliza</span></li><li><span>Qu&#233; necesita saber antes de empezar a tomar Biktarvy</span></li><li><span>C&#243;mo tomar Biktarvy</span></li><li><span>Posibles efectos adversos</span></li><li><span>Conservaci&#243;n de Biktarvy</span></li><li><span>Contenido del envase e informaci&#243;n adicional</span></li></ol><p><span>&#xa0;</span></p><p><span>&#xa0;</span></p></div>"
          }
        },
        {
          "title" : "1. Qué es Karvea y para qué se utiliza",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Qué es Karvea y para qué se utiliza"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>&#xa0;</span></p><p><span>Biktarvy contiene tres principios activos:</span></p><ul><li><strong><span>bictegravir,</span></strong> <span>un medicamento antirretroviral conocido como inhibidor de la transferencia de las</span> <span>hebras de la integrasa (INI)</span></li><li><strong><span>emtricitabina,</span></strong> <span>un medicamento antirretroviral de un tipo conocido como nucle&#243;sido inhibidor</span> <span>de la transcriptasa inversa (ITIAN)</span></li><li><strong><span>tenofovir alafenamida,</span></strong> <span>un medicamento antirretroviral de un tipo conocido como nucle&#243;tido</span> <span>inhibidor de la transcriptasa inversa (ITIANt)</span></li></ul><p><span>&#xa0;</span></p><p><span>Biktarvy es un comprimido &#250;nico para el tratamiento de la infecci&#243;n por el virus de la inmunodeficiencia humana 1 (VIH-1) en adultos.</span></p><p><span>&#xa0;</span></p><p><span>Biktarvy reduce la cantidad de VIH presente en el organismo. Esto mejora el sistema inmunitario y disminuye el riesgo de desarrollar enfermedades asociadas con la infecci&#243;n por el VIH.</span></p><p><span>&#xa0;</span></p></div>"
          }
        },
        {
          "title" : "2. Qué necesita saber antes de empezar a tomar Karvea",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Qué necesita saber antes de empezar a tomar Karvea"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>&#xa0;</span></p><p><strong><span>No tome Biktarvy</span></strong></p><ul><li><strong><span>Si es al&#233;rgico a bictegravir, emtricitabina, tenofovir alafenamida</span></strong> <span>o a alguno de los dem&#225;s</span> <span>componentes de este medicamento (incluidos en la secci&#243;n 6 de este prospecto).</span></li></ul><ul><li><a name=\"page2\" id=\"page2\"></a><strong><span>Si actualmente est&#225; tomando alguno de los siguientes medicamentos:</span></strong></li><li><ul><li><strong><span>rifampicina</span></strong> <span>utilizada para tratar algunas infecciones bacterianas como la tuberculosis</span></li><li><strong><span>hierba de San Juan</span></strong> <span>(</span><em><span>Hypericum perforatum</span></em><span>, hip&#233;rico), un medicamento a base de</span> <span>plantas utilizado para la depresi&#243;n y la ansiedad, o productos que la contengan.</span></li></ul></li></ul><p><span>&#xa0;</span></p><ul><li><span>Si est&#225; tomando alguno de estos medicamentos,</span> <strong><span>no tome Biktarvy y consulte a su m&#233;dico</span></strong> <strong><span>inmediatamente.</span></strong></li></ul><p><span>&#xa0;</span></p><p><strong><span>Advertencias y precauciones</span></strong></p><p><span>&#xa0;</span></p><p><strong><span>Consulte a su m&#233;dico antes de empezar a tomar Biktarvy:</span></strong></p><p><span>&#xa0;</span></p><ul><li><strong><span>Si tiene problemas hep&#225;ticos o antecedentes de enfermedad hep&#225;tica, incluida la hepatitis.</span></strong> <span>Los pacientes que padecen de enfermedades hep&#225;ticas, como la hepatitis B o C cr&#243;nica, y est&#225;n en tratamiento con antirretrovirales tienen m&#225;s riesgo de presentar complicaciones hep&#225;ticas graves y potencialmente mortales. Si tiene infecci&#243;n por el virus de la hepatitis B, su m&#233;dico evaluar&#225; detenidamente la mejor pauta terap&#233;utica para usted.</span></li></ul><ul><li><strong><span>Si tiene hepatitis B.</span></strong> <span>Los problemas hep&#225;ticos pueden empeorar despu&#233;s de dejar de tomar</span> <span>Biktarvy.</span></li></ul><ul><li><span>No deje de tomar Biktarvy si tiene hepatitis B. Hable antes con su m&#233;dico. Puede consultar m&#225;s detalles en la secci&#243;n 3,</span> <em><span>No interrumpa el tratamiento con Biktarvy.</span></em></li></ul><p><span>&#xa0;</span></p><p><strong><span>Mientras est&#233; tomando Biktarvy</span></strong></p><p><span>&#xa0;</span></p><p><span>Una vez que empiece a tomar Biktarvy, est&#233; atento a:</span></p><p><span>&#xa0;</span></p><ul><li><strong><span>Signos de inflamaci&#243;n o infecci&#243;n</span></strong></li><li><strong><span>Dolor articular, rigidez o problemas &#243;seos</span></strong></li></ul><p><span>&#xa0;</span></p><ul><li><strong><span>Si nota cualquiera de estos s&#237;ntomas, informe a su m&#233;dico inmediatamente.</span></strong> <span>Puede consultar</span> <span>m&#225;s informaci&#243;n en la secci&#243;n 4,</span> <em><span>Posibles efectos adversos</span></em><span>.</span></li></ul><p><span>&#xa0;</span></p><p><span>Aunque no se han observado problemas renales con Biktarvy, existe la posibilidad de que pueda experimentar problemas renales si toma Biktarvy durante un periodo de tiempo prolongado.</span></p><p><span>&#xa0;</span></p><p><span>Mientras est&#233; tomando este medicamento</span> <strong><span>a&#250;n puede transmitir el VIH a los dem&#225;s,</span></strong> <span>aunque un tratamiento antirretroviral eficaz reduzca el riesgo. Consulte a su m&#233;dico sobre qu&#233; precauciones son necesarias para no infectar a otras personas. Este medicamento no es una cura para la infecci&#243;n por el VIH. Mientras usted est&#233; tomando Biktarvy podr&#225; seguir padeciendo infecciones u otras enfermedades asociadas con la infecci&#243;n por el VIH.</span></p><p><span>&#xa0;</span></p><p><strong><span>Ni&#241;os y adolescentes</span></strong></p><p><span>&#xa0;</span></p><p><strong><span>No administre este medicamento a ni&#241;os y adolescentes menores de 18 a&#241;os de edad.</span></strong> <span>No se ha</span> <span>estudiado todav&#237;a el uso de Biktarvy en ni&#241;os y adolescentes menores de 18 a&#241;os de edad.</span></p><p><span>&#xa0;</span></p><p><strong><span>Otros medicamentos y Biktarvy</span></strong></p><p><span>&#xa0;</span></p><p><strong><span>Informe a su m&#233;dico o farmac&#233;utico si est&#225; tomando, ha tomado recientemente o pudiera tener que tomar cualquier otro medicamento.</span></strong> <span>Biktarvy puede interaccionar con otros medicamentos.</span> <span>Como consecuencia, los niveles sangu&#237;neos de Biktarvy o de otros medicamentos se pueden ver afectados. Esto puede impedir que sus medicamentos funcionen correctamente o empeorar sus posibles efectos adversos. En algunos casos, su m&#233;dico puede tener que ajustar la dosis o comprobar sus concentraciones sangu&#237;neas.</span></p><p><span>&#xa0;</span></p><p><a name=\"page3\" id=\"page3\"></a><strong><span>Medicamentos que nunca se deben tomar con Biktarvy:</span></strong></p><p><span>&#xa0;</span></p><ul><li><strong><span>rifampicina</span></strong> <span>utilizada para tratar algunas infecciones bacterianas como la tuberculosis</span></li><li><strong><span>hierba de San Juan</span></strong> <span>(</span><em><span>Hypericum perforatum</span></em><span>, hip&#233;rico), un medicamento a base de plantas</span> <span>utilizado para la depresi&#243;n y la ansiedad, o productos que lo contengan</span><strong><span>.</span></strong></li></ul><p><span>&#xa0;</span></p><ul><li><span>Si est&#225; tomando alguno de estos medicamentos,</span> <strong><span>no tome Biktarvy e informe a su m&#233;dico</span></strong> <strong><span>inmediatamente.</span></strong></li></ul><p><span>&#xa0;</span></p><p><strong><span>Consulte con su m&#233;dico si est&#225; tomando:</span></strong></p><p><span>&#xa0;</span></p><ul><li><strong><span>medicamentos utilizados para tratar el VIH y/o la hepatitis B</span></strong> <span>que contengan:</span></li><li><ul><li><span>adefovir dipivoxil, atazanavir, bictegravir, emtricitabina, lamivudina, tenofovir alafenamida o tenofovir disoproxilo</span></li></ul></li><li><strong><span>antibi&#243;ticos, utilizados para tratar las infecciones bacterianas</span></strong><span>, que contengan:</span></li><li><div type=\"square\"><ul><li><span>azitromicina, claritromicina, rifabutina o rifapentina</span></li></ul></div></li><li><strong><span>antiepil&#233;pticos,</span></strong> <span>utilizados para tratar la epilepsia, que contengan:</span></li><li><ul><li><span>carbamazepina, oxcarbazepina, fenobarbital o fenito&#237;na</span></li></ul></li><li><strong><span>inmunosupresores,</span></strong> <span>utilizados para controlar la respuesta inmunitaria del organismo tras un</span> <span>trasplante, que contengan ciclosporina</span></li><li><strong><span>medicamentos para la curaci&#243;n de &#250;lceras</span></strong> <span>que contengan sucralfato</span></li></ul><ul><li><strong><span>Informe a su m&#233;dico si est&#225; tomando alguno de estos medicamentos.</span></strong> <span>No interrumpa su</span> <span>tratamiento sin consultar con su m&#233;dico.</span></li></ul><p><span>&#xa0;</span></p><p><strong><span>Consulte a su m&#233;dico o farmac&#233;utico si est&#225; tomando:</span></strong></p><ul><li><strong><span>anti&#225;cidos</span></strong> <span>para tratar &#250;lceras estomacales, acidez estomacal o reflujo &#225;cido, que contengan</span> <span>hidr&#243;xido de aluminio y/o de magnesio</span></li><li><strong><span>suplementos de minerales</span></strong> <span>o</span> <strong><span>de vitaminas,</span></strong> <span>que contengan magnesio o hierro</span></li></ul><div type=\"circle\"><ul><li><strong><span>Consulte a su m&#233;dico o farmac&#233;utico antes de tomar Biktarvy</span></strong> <span>si est&#225; tomando alguno de estos</span> <span>medicamentos.</span></li></ul></div><p><strong><span>Anti&#225;cidos y suplementos de magnesio:</span></strong> <span>tendr&#225; que tomar Biktarvy al menos 2 horas</span> <strong><span>antes</span></strong> <span>de</span> <span>tomar los anti&#225;cidos o suplementos que contengan aluminio y/o magnesio. O puede tomar Biktarvy junto con alimentos al menos 2 horas</span> <strong><span>despu&#233;s</span></strong> <span>de la toma del anti&#225;cido o suplemento que contenga aluminio y/o magnesio.</span></p><p><strong><span>Suplementos de hierro:</span></strong> <span>tendr&#225; que tomar Biktarvy al menos 2 horas</span> <strong><span>antes</span></strong> <span>de tomar los</span> <span>suplementos de hierro o puede tomarlos todos juntos con alimentos.</span></p><p><span>&#xa0;</span></p><p><strong><span>Embarazo y lactancia</span></strong></p><ul><li><span>Si est&#225; embarazada o en periodo de lactancia, cree que podr&#237;a estar embarazada o tiene intenci&#243;n de quedarse embarazada, consulte a su m&#233;dico o farmac&#233;utico antes de utilizar este medicamento.</span></li><li><span>Informe a su m&#233;dico inmediatamente si se queda embarazada y pregunte sobre los posibles beneficios y riesgos de su tratamiento antirretroviral para usted y para su hijo.</span></li></ul><p><span>&#xa0;</span></p><p><span>Si ha tomado Biktarvy durante su embarazo su m&#233;dico puede solicitar que se haga an&#225;lisis de sangre peri&#243;dicos y otras pruebas diagn&#243;sticas para controlar el desarrollo de su ni&#241;o. En ni&#241;os cuyas madres tomaron nucle&#243;sidos inhibidores de la transcriptasa inversa (ITIAN) durante el embarazo, el beneficio de la protecci&#243;n frente al VIH fue mayor que el riesgo de que se produjeran efectos adversos.</span></p><p><span>&#xa0;</span></p><p><strong><span>No d&#233; el pecho a su hijo durante el tratamiento con Biktarvy.</span></strong> <span>Esto se debe a que algunos de los</span> <span>principios activos de este medicamento pasan a la leche materna. Se recomienda que no d&#233; el pecho para evitar que transmita el virus al ni&#241;o a trav&#233;s de la leche materna. Si realmente desea amamantar, hable primero con su m&#233;dico.</span></p><p><span>&#xa0;</span></p><p><a name=\"page4\" id=\"page4\"></a><strong><span>Conducci&#243;n y uso de m&#225;quinas</span></strong></p><p><span>&#xa0;</span></p><p><span>Biktarvy puede causar mareo. Si nota mareo durante el tratamiento con Biktarvy, no conduzca ni maneje herramientas o m&#225;quinas.</span></p><p><span>&#xa0;</span></p><p><strong><span>Biktarvy contiene sodio</span></strong></p><p><span>&#xa0;</span></p><p><span>Este medicamento contiene menos de 1 mmol de sodio (23 mg) por comprimido; esto es, esencialmente &#8220;exento de sodio&#8221;.</span></p><p><span>&#xa0;</span></p></div>"
          }
        },
        {
          "title" : "3. Cómo tomar Karvea",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Cómo tomar Karvea"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Siga exactamente las instrucciones de administraci&#243;n de este medicamento indicadas por su m&#233;dico.</span></p><p><span>En caso de duda, consulte de nuevo a su m&#233;dico o farmac&#233;utico.</span></p><p><span>&#xa0;</span></p><p><strong><span>La dosis recomendada es:</span></strong></p><p><span>&#xa0;</span></p><p><strong><span>Adultos:</span></strong> <span>un comprimido al d&#237;a, con o sin alimentos</span></p><p><span>No mastique, triture ni divida el comprimido.</span></p><p><span>&#xa0;</span></p><ul><li><strong><span>Consulte a su m&#233;dico o farmac&#233;utico si est&#225; tomando:</span></strong></li></ul><ul><li><strong><span>anti&#225;cidos</span></strong> <span>para tratar &#250;lceras estomacales, acidez estomacal o reflujo &#225;cido, que contengan</span> <span>hidr&#243;xido de aluminio y/o de magnesio</span></li><li><strong><span>suplementos de minerales</span></strong> <span>o</span> <strong><span>vitaminas</span></strong> <span>que contengan magnesio o hierro</span></li></ul><ul><li><strong><span>Vea la secci&#243;n 2 para m&#225;s informaci&#243;n</span></strong> <span>sobre c&#243;mo tomar estos medicamentos con Biktarvy.</span></li></ul><p><span>&#xa0;</span></p><p><strong><span>Si toma m&#225;s Biktarvy del que debe</span></strong></p><p><span>&#xa0;</span></p><p><span>Si toma m&#225;s cantidad de la dosis recomendada de Biktarvy puede correr mayor riesgo de experimentar posibles efectos adversos con este medicamento (ver secci&#243;n 4,</span> <em><span>Posibles efectos adversos</span></em><span>).</span></p><p><span>&#xa0;</span></p><p><span>Consulte inmediatamente a su m&#233;dico o acuda al servicio de urgencias m&#225;s cercano. Lleve consigo el frasco de comprimidos para que pueda describir f&#225;cilmente qu&#233; ha tomado.</span></p><p><span>&#xa0;</span></p><p><strong><span>Si olvid&#243; tomar Biktarvy</span></strong></p><p><span>&#xa0;</span></p><p><span>Es importante que no olvide una dosis de Biktarvy.</span></p><p><span>&#xa0;</span></p><p><span>Si olvida una dosis:</span></p><ul><li><strong><span>Si se da cuenta en las 18 horas</span></strong> <span>posteriores a la hora a la que normalmente toma Biktarvy, debe</span> <span>tomar el comprimido tan pronto como sea posible. Luego tome la dosis siguiente de la forma habitual.</span></li><li><strong><span>Si se da cuenta despu&#233;s de 18 horas o m&#225;s</span></strong> <span>de la hora a la que normalmente toma Biktarvy, no</span> <span>tome la dosis olvidada. Espere y tome la siguiente dosis a la hora habitual.</span></li></ul><p><span>&#xa0;</span></p><p><strong><span>Si vomita</span></strong> <span>antes de que transcurra 1 hora tras haber tomado Biktarvy, tome otro comprimido. Si</span> <span>vomita transcurrida 1 hora de haber tomado Biktarvy, no necesita tomar otro comprimido hasta el momento de la hora habitual.</span></p><p><span>&#xa0;</span></p><p><strong><span>No interrumpa el tratamiento con Biktarvy</span></strong></p><p><span>&#xa0;</span></p><p><strong><span>No interrumpa el tratamiento con Biktarvy sin hablar antes con su m&#233;dico.</span></strong> <span>Interrumpir Biktarvy</span> <span>puede afectar gravemente el funcionamiento de tratamientos futuros. Si se interrumpe Biktarvy por alg&#250;n motivo, consulte con su m&#233;dico antes de reiniciar la toma de comprimidos de Biktarvy.</span></p><p><span>&#xa0;</span></p><p><a name=\"page5\" id=\"page5\"></a><strong><span>Cuando vea que le queda poca cantidad de Biktarvy,</span></strong> <span>acuda a su m&#233;dico o farmac&#233;utico para que le</span> <span>proporcione m&#225;s. Esto es muy importante, ya que la cantidad de virus puede empezar a aumentar si el medicamento se interrumpe incluso durante un corto periodo de tiempo. Es posible que entonces la enfermedad se vuelva m&#225;s dif&#237;cil de tratar.</span></p><p><span>&#xa0;</span></p><p><strong><span>Si tiene infecci&#243;n por VIH y hepatitis B</span></strong> <span>es especialmente importante no suspender su tratamiento</span> <span>con Biktarvy sin antes hablar con su m&#233;dico. Puede necesitar hacerse an&#225;lisis de sangre durante varios meses tras suspender el tratamiento. En algunos pacientes con enfermedad hep&#225;tica avanzada o cirrosis no se recomienda suspender el tratamiento ya que esto puede producir un empeoramiento de su hepatitis, situaci&#243;n que puede ser potencialmente mortal.</span></p><p><span>&#xa0;</span></p><ul><li><strong><span>Hable con su m&#233;dico inmediatamente</span></strong> <span>acerca de s&#237;ntomas nuevos o inusuales tras suspender su</span> <span>tratamiento, particularmente s&#237;ntomas que asocie con la infecci&#243;n por el virus de la hepatitis B.</span></li></ul><p><span>&#xa0;</span></p><p><span>Si tiene cualquier otra duda sobre el uso de este medicamento, pregunte a su m&#233;dico o farmac&#233;utico.</span></p><p><span>&#xa0;</span></p></div>"
          }
        },
        {
          "title" : "4. Posibles efectos adversos",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Posibles efectos adversos"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>&#xa0;</span></p><p><span>Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.</span></p><p><span>&#xa0;</span></p><p><strong><span>Posibles efectos adversos: informe a un m&#233;dico inmediatamente</span></strong></p><p><span>&#xa0;</span></p><ul><li><strong><span>Cualquier signo de inflamaci&#243;n o de infecci&#243;n.</span></strong> <span>En algunos pacientes con infecci&#243;n avanzada</span> <span>por el VIH (sida) y antecedentes de infecciones oportunistas (infecciones que ocurren en personas con un sistema inmunitario d&#233;bil), se pueden producir signos y s&#237;ntomas de inflamaci&#243;n por infecciones previas poco despu&#233;s de iniciar el tratamiento contra el VIH. Se cree que estos s&#237;ntomas se deben a una mejor&#237;a de la respuesta inmunitaria del organismo, que le permite combatir infecciones que podr&#237;an haber estado presentes sin s&#237;ntomas obvios.</span></li></ul><ul><li><span>Se pueden producir tambi&#233;n</span> <strong><span>trastornos autoinmunitarios,</span></strong> <span>en los que el sistema inmunitario ataca a los tejidos sanos del organismo, despu&#233;s de que empiece a tomar medicamentos para la infecci&#243;n por el VIH. Los trastornos autoinmunitarios se pueden producir muchos meses despu&#233;s del inicio del tratamiento. Est&#233; atento a cualquier s&#237;ntoma de infecci&#243;n u otros s&#237;ntomas, como:</span></li></ul><div type=\"circle\"><ul><li><span>debilidad muscular</span></li><li><span>debilidad que se inicia en las manos y los pies y se desplaza hacia el tronco</span></li><li><span>palpitaciones, temblor o hiperactividad</span></li></ul></div><p><span>&#xa0;</span></p><ul><li><strong><span>Si nota cualquiera de estos s&#237;ntomas o cualquier s&#237;ntoma de inflamaci&#243;n o infecci&#243;n, informe a su m&#233;dico inmediatamente.</span></strong></li></ul><p><span>&#xa0;</span></p><p><strong><span>Efectos adversos frecuentes</span></strong></p><p><em><span>(pueden afectar hasta 1 de cada 10 personas)</span></em></p><ul><li><span>depresi&#243;n</span></li><li><span>sue&#241;os anormales</span></li><li><span>dolor de cabeza</span></li><li><span>mareo</span></li><li><span>diarrea</span></li><li><span>ganas de vomitar (</span><em><span>n&#225;useas</span></em><span>)</span></li><li><span>cansancio (</span><em><span>fatiga</span></em><span>)</span></li></ul><p><span>&#xa0;</span></p><p><strong><span>Efectos adversos poco frecuentes</span></strong></p><p><span>(</span><em><span>pueden afectar hasta 1 de cada 100 personas</span></em><span>)</span></p><ul><li><span>anemia</span></li></ul><ul><li><a name=\"page6\" id=\"page6\"></a><span>v&#243;mitos</span></li></ul><ul><li><span>dolor de est&#243;mago</span></li></ul><ul><li><span>problemas digestivos que generan molestias despu&#233;s de las comidas (</span><em><span>dispepsia</span></em><span>)</span></li></ul><ul><li><span>gases (</span><em><span>flatulencia</span></em><span>)</span></li></ul><ul><li><span>hinchaz&#243;n de la cara, labios, lengua o garganta (</span><em><span>angioedema</span></em><span>)</span></li></ul><ul><li><span>picaz&#243;n (</span><em><span>prurito</span></em><span>)</span></li></ul><ul><li><span>erupci&#243;n</span></li></ul><ul><li><span>habones (</span><em><span>urticaria</span></em><span>)</span></li></ul><ul><li><span>dolor en las articulaciones (</span><em><span>artralgia</span></em><span>)</span></li></ul><ul><li><span>comportamiento suicida</span></li></ul><ul><li><span>ansiedad</span></li></ul><ul><li><span>trastornos del sue&#241;o</span></li></ul><p><span>&#xa0;</span></p><p><em><span>Los an&#225;lisis de sangre tambi&#233;n pueden mostrar:</span></em></p><ul><li><span>&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;</span> <span>Concentraciones m&#225;s altas de sustancias llamadas bilirrubina y/o creatinina s&#233;rica en la sangre</span></li></ul><p><span>&#xa0;</span></p><ul><li><span>&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;</span> <strong><span>Si considera que alguno de los efectos adversos que sufre es grave, informe a su m&#233;dico.</span></strong></li></ul><p><strong><span>Otros efectos que se pueden observar durante el tratamiento contra el VIH</span></strong></p><p><span>&#xa0;</span></p><p><span>La frecuencia de los siguientes efectos adversos se considera no conocida (la frecuencia no se puede estimar a partir de los datos disponibles).</span></p><p><span>&#xa0;</span></p><ul><li><strong><span>Problemas &#243;seos.</span></strong> <span>Algunos pacientes tratados con medicamentos antirretrovirales combinados</span> <span>como Biktarvy pueden desarrollar una enfermedad de los huesos llamada</span> <em><span>osteonecrosis</span></em> <span>(muerte del tejido &#243;seo debida a una p&#233;rdida del suministro de sangre al hueso). Tomar este tipo de medicamentos durante un tiempo prolongado, tomar corticosteroides, beber alcohol, tener un sistema inmunitario muy d&#233;bil y tener sobrepeso, pueden ser algunos de los muchos factores de riesgo para desarrollar esta enfermedad. Los signos de osteonecrosis son:</span></li><li><ul><li><span>rigidez articular</span></li><li><span>molestias y dolores articulares (especialmente de la cadera, la rodilla y el hombro)</span></li><li><span>dificultad para moverse</span></li></ul></li></ul><p><span>&#xa0;</span></p><ul><li><strong><span>Si nota cualquiera de estos s&#237;ntomas, informe a su m&#233;dico.</span></strong></li></ul><p><span>&#xa0;</span></p><p><span>Durante el tratamiento del VIH puede haber un aumento en el peso y en los niveles de glucosa y l&#237;pidos en la sangre. Esto puede estar en parte relacionado con la recuperaci&#243;n de la salud y con el estilo de vida y, en el caso de los l&#237;pidos en la sangre, algunas veces con los medicamentos contra el VIH por s&#237; mismos. Su m&#233;dico le controlar&#225; estos cambios.</span></p><p><span>&#xa0;</span></p><p><strong><span>Comunicaci&#243;n de efectos adversos</span></strong></p><p><span>&#xa0;</span></p><p><span>Si experimenta cualquier tipo de efecto adverso, consulte a su m&#233;dico o farmac&#233;utico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. Tambi&#233;n puede comunicarlos directamente</span> <span>a trav&#233;s del sistema nacional de notificaci&#243;n incluido en el</span> <a href=\"http://www.ema.europa.eu/docs/en_GB/document_library/Template_or_form/2013/03/WC500139752.doc\"><span>Ap&#233;ndice V.</span></a> <span>Mediante la comunicaci&#243;n de efectos adversos usted puede contribuir a proporcionar m&#225;s informaci&#243;n sobre la seguridad de este medicamento.</span></p><p><span>&#xa0;</span></p><p><span>&#xa0;</span></p></div>"
          }
        },
        {
          "title" : "5. Conservación de Karvea",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Conservación de Karvea"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Mantener este medicamento fuera de la vista y del alcance de los ni&#241;os.</span></p><p><span>&#xa0;</span></p><p><span>No utilice este medicamento despu&#233;s de la fecha de caducidad que aparece en la caja y en el frasco despu&#233;s de {CAD}. La fecha de caducidad es el &#250;ltimo d&#237;a del mes que se indica.</span></p><p><span>&#xa0;</span></p><p><span>Conservar en el embalaje original para protegerlo de la humedad. Mantener el frasco perfectamente cerrado. No utilizar si falta el sello del frasco o est&#225; roto.</span></p><p><span>&#xa0;</span></p><p><a name=\"page7\" id=\"page7\"></a><span>Los medicamentos no se deben tirar por los desag&#252;es ni a la basura. Pregunte a su farmac&#233;utico c&#243;mo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudar&#225; a proteger el medio ambiente.</span></p><p><span>&#xa0;</span></p></div>"
          }
        },
        {
          "title" : "6. Contenido del envase e información adicional",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contenido del envase e información adicional"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Karvea indeholder:</p><ul><li>Aktivt stof: irbesartan. Hver Karvea-tablet 75 mg indeholder 75 mg irbesartan.</li><li>Øvrige indholdsstoffer: lactosemonohydrat, mikrokrystallinsk cellulose, croscarmellosenatrium, magnesiumstearat, kolloid silica, prægelatineret majsstivelse, poloaxamer 188.<br/>Se punkt 2 ”Aprovel indeholder lactose”</li></ul><p>Udseende og pakningstørrelser Karvea 75 mg tabletter er hvide til mathvide, bikonvekse og ovale med et hjerte præget på den ene side og nummeret 2771 på den anden side.</p><p>Karvea 75 mg tabletter leveres i blisterpakninger af 14, 28, 56 eller 98 tabletter. Der fås også enkeltdosisblisterpakninger med 56 x 1 tablet til hospitalsbrug.</p><p>Ikke alle pakningsstørrelser er nødvendigvis markedsført.</p><p>Indehaveren af markedsføringstilladelsen:</p><p>Sanofi Winthrop Industrie 82 avenue Raspail 94250 Gentilly Frankrig</p><p>Fremstiller:</p><p>SANOFI WINTHROP INDUSTRIE 1, rue de la Vierge Ambarès &amp; Lagrave F-33565 Carbon Blanc Cedex - Frankrig</p><p>SANOFI WINTHROP INDUSTRIE 30-36 Avenue Gustave Eiffel, BP 7F-37071 Tours Cedex 2 - Frankrig</p><p>Hvis du vil have yderligere oplysninger om Karvea, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:</p><p>België/Belgique/Belgien Sanofi Belgium Tél/Tel: +32 (0)2 710 54<br/>Lietuva Swixx Biopharma UAB Tel: +370 5 236 91<br/>България Swixx Biopharma EOOD Тел.: +359 (0)2 4942<br/>Luxembourg/Luxemburg Sanofi Belgium<br/>Tél/Tel: +32 (0)2 710 54 00 (Belgique/Belgien)</p><p>Česká republika sanofi-aventis, s.r.o. Tel: +420 233 086<br/>Magyarország SANOFI-AVENTIS Zrt. Tel.: +36 1 505 0 Danmark Sanofi A/S Tlf: +45 45 16 70<br/>Malta Sanofi S.r.l. Tel: +39 02 39394</p><p>Deutschland Sanofi-Aventis Deutschland GmbH Tel: 0800 52 52 Tel. aus dem Ausland: +49 69 305 21<br/>Nederland Sanofi B.V. Tel: +31 20 245 4 Eesti Swixx Biopharma OÜ Tel: +372 640 10<br/>Norge sanofi-aventis Norge AS Tlf: +47 67 10 71<br/>Ελλάδα Sanofi-Aventis Μονοπρόσωπη AEBE Τηλ: +30 210 900 16<br/>Österreich sanofi-aventis GmbH Tel: +43 1 80 185 – 0</p><p>España sanofi-aventis, S.A. Tel: +34 93 485 94<br/>Polska sanofi-aventis Sp. z o.o. Tel.: +48 22 280 00<br/>France Sanofi Winthrop Industrie Tél:<br/>0 800 222 Appel depuis l’étranger : +33 1 57 63 23<br/>Portugal Sanofi - Produtos Farmacêuticos, Lda Tel: +351 21 35 89<br/>Hrvatska Swixx Biopharma d.o.o. Tel: +385 1 2078 România Sanofi Romania SRL Tel: +40 (0) 21 317 31<br/>Ireland sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +353 (0) 1 403 56<br/>Slovenija Swixx Biopharma d.o.o. Tel: +386 1 235 51<br/>Ísland Vistor hf. Sími: +354 535 7 Slovenská republika Swixx Biopharma s.r.o. Tel: +421 2 208 33<br/>Italia Sanofi S.r.l. Tel: 800.536 Suomi/Finland Sanofi Oy Puh/Tel: +358 (0) 201 200<br/>Κύπρος C.A. Papaellinas Ltd. Τηλ: +357 22 741 Sverige Sanofi AB Tel: +46 (0)8 634 50<br/>Latvija Swixx Biopharma SIA Tel: +371 6 616 47<br/>United Kingdom (Northern Ireland) sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +44 (0) 800 035 2 Denne indlægsseddel blev senest ændret</p><p>Du kan finde yderligere information om Karvea på Det Europæiske Lægemiddelagenturs hjemmeside</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-a40c2367ed3c1c715eacd432105752a0",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-a40c2367ed3c1c715eacd432105752a0",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-a40c2367ed3c1c715eacd432105752a0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-a40c2367ed3c1c715eacd432105752a0</b></p><a name=\"cud-a40c2367ed3c1c715eacd432105752a0\"> </a><a name=\"hccud-a40c2367ed3c1c715eacd432105752a0\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr 10012601}\">Diabetis Mellitus</span></td></tr></table></blockquote></div>"
      },
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "10012601",
              "display" : "Diabetis Mellitus"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-585e364c14debe29f6c6b564138aa400",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-585e364c14debe29f6c6b564138aa400",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-indication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-585e364c14debe29f6c6b564138aa400\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-585e364c14debe29f6c6b564138aa400</b></p><a name=\"cud-585e364c14debe29f6c6b564138aa400\"> </a><a name=\"hccud-585e364c14debe29f6c6b564138aa400\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-indication-uv-epi.html\">ClinicalUseDefinition Indication (ePI)</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr 10020772}\">Hypertension</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "10020772",
              "display" : "Hypertension"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-4fce9d5258f70f7d605059f97c24efa8",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-4fce9d5258f70f7d605059f97c24efa8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-interaction-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-4fce9d5258f70f7d605059f97c24efa8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-4fce9d5258f70f7d605059f97c24efa8</b></p><a name=\"cud-4fce9d5258f70f7d605059f97c24efa8\"> </a><a name=\"hccud-4fce9d5258f70f7d605059f97c24efa8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-interaction-uv-epi.html\">ClinicalUseDefinition Interaction (ePI)</a></p></div><p><b>type</b>: Interaction</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>interaction</b></p><h3>Interactants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ YL5FZ2Y5U1}\">METHOTREXATE</span></td></tr></table></blockquote></div>"
      },
      "type" : "interaction",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "interaction" : {
        "interactant" : [{
          "itemCodeableConcept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "YL5FZ2Y5U1",
              "display" : "METHOTREXATE"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-hypromellose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-hypromellose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-hypromellose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-hypromellose</b></p><a name=\"ingredient-for-karvea-hypromellose\"> </a><a name=\"hcingredient-for-karvea-hypromellose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/3NXW29V3WO (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 3NXW29V3WO}\">Hypromellose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "3NXW29V3WO"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "3NXW29V3WO",
              "display" : "Hypromellose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-macrogol3000",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-macrogol3000",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-macrogol3000\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-macrogol3000</b></p><a name=\"ingredient-for-karvea-macrogol3000\"> </a><a name=\"hcingredient-for-karvea-macrogol3000\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/SA1B764746 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta SA1B764746}\">Macrogol 3000</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "SA1B764746"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "SA1B764746",
              "display" : "Macrogol 3000"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-lactosemonohydrate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-lactosemonohydrate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-lactosemonohydrate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-lactosemonohydrate</b></p><a name=\"ingredient-for-karvea-lactosemonohydrate\"> </a><a name=\"hcingredient-for-karvea-lactosemonohydrate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EWQ57Q8I5X (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EWQ57Q8I5X}\">Lactose Monohydrate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EWQ57Q8I5X"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EWQ57Q8I5X",
              "display" : "Lactose Monohydrate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-silicondioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-silicondioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-silicondioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-silicondioxide</b></p><a name=\"ingredient-for-karvea-silicondioxide\"> </a><a name=\"hcingredient-for-karvea-silicondioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/ETJ7Z6XBU4 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta ETJ7Z6XBU4}\">Silicon dioxide</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "ETJ7Z6XBU4"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "ETJ7Z6XBU4",
              "display" : "Silicon dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-titaniumdioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-titaniumdioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-titaniumdioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-titaniumdioxide</b></p><a name=\"ingredient-for-karvea-titaniumdioxide\"> </a><a name=\"hcingredient-for-karvea-titaniumdioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/15FIX9V2JP (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 15FIX9V2JP}\">Titanium Dioxide</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "15FIX9V2JP"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "15FIX9V2JP",
              "display" : "Titanium Dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-irbesartan",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-irbesartan",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-irbesartan\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-irbesartan</b></p><a name=\"ingredient-for-karvea-irbesartan\"> </a><a name=\"hcingredient-for-karvea-irbesartan\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/J0E2756Z7N (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta J0E2756Z7N}\">irbesartan</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "J0E2756Z7N"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "J0E2756Z7N",
              "display" : "irbesartan"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 75,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-croscarmellosesodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-croscarmellosesodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-croscarmellosesodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-croscarmellosesodium</b></p><a name=\"ingredient-for-karvea-croscarmellosesodium\"> </a><a name=\"hcingredient-for-karvea-croscarmellosesodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/M28OL1HH48 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta M28OL1HH48}\">Croscarmellose sodium</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "M28OL1HH48"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "M28OL1HH48",
              "display" : "Croscarmellose sodium"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-microcrystallinecellulose</b></p><a name=\"ingredient-for-karvea-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-karvea-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">Microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "Microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-magnesiumstearate</b></p><a name=\"ingredient-for-karvea-magnesiumstearate\"> </a><a name=\"hcingredient-for-karvea-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-carnaubawax",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-carnaubawax",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-carnaubawax\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-carnaubawax</b></p><a name=\"ingredient-for-karvea-carnaubawax\"> </a><a name=\"hcingredient-for-karvea-carnaubawax\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/R12CBM0EIZ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta R12CBM0EIZ}\">Carnauba wax</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "R12CBM0EIZ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "R12CBM0EIZ",
              "display" : "Carnauba wax"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-irbesartan",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-irbesartan",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-irbesartan\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-irbesartan</b></p><a name=\"substance-irbesartan\"> </a><a name=\"hcsubstance-irbesartan\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/J0E2756Z7N (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>description</b>: </p><div><p>White to off-white, biconvex, and oval-shaped with a heart debossed on one side and the number 2771 engraved on the other side.</p>\n</div><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>428.53</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C25H28N6O</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(+)-6-methyleneandrosta-1,4-diene-3,17-dione</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "J0E2756Z7N"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "description" : "White to off-white, biconvex, and oval-shaped with a heart debossed on one side and the number 2771 engraved on the other side.",
      "manufacturer" : [{
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 428.53
        }
      }],
      "structure" : {
        "molecularFormula" : "C25H28N6O"
      },
      "name" : [{
        "name" : "(+)-6-methyleneandrosta-1,4-diene-3,17-dione",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-dcaa4d32aa6658a8df831551503e52ee",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-dcaa4d32aa6658a8df831551503e52ee</b></p><a name=\"ap-dcaa4d32aa6658a8df831551503e52ee\"> </a><a name=\"hcap-dcaa4d32aa6658a8df831551503e52ee\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee0</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/010 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-d91b269b209aaa5538a1bfafd1a7434d\">PackagedProductDefinition Karvea 75 mg tablet 14</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/010"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-d91b269b209aaa5538a1bfafd1a7434d"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee1",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee1",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee1</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-f3f2f89544dfc5d20216861bcf90c0c5\">PackagedProductDefinition Karvea 75 mg tablet 28</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-f3f2f89544dfc5d20216861bcf90c0c5"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee2",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee2",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee2</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/002 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-5763619e2b501aeeab53677bd09d5cbf\">PackagedProductDefinition Karvea 75 mg tablet 56</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/002"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-5763619e2b501aeeab53677bd09d5cbf"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee3",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee3",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee3</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/003 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-9b1d5d261d22694685deb35714ec08ea\">PackagedProductDefinition Karvea 75 mg tablet 98</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/003"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-9b1d5d261d22694685deb35714ec08ea"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-511671db37e83e520b00f8a0d817dc96",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-511671db37e83e520b00f8a0d817dc96",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-511671db37e83e520b00f8a0d817dc96\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-511671db37e83e520b00f8a0d817dc96</b></p><a name=\"mah-511671db37e83e520b00f8a0d817dc96\"> </a><a name=\"hcmah-511671db37e83e520b00f8a0d817dc96\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100011564 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Sanofi Winthrop Industrie\t</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>82 avenue Raspail Gentilly FR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100011564"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Sanofi Winthrop Industrie\t",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "82 avenue Raspail Gentilly FR",
          "line" : ["82 avenue Raspail"],
          "city" : "Gentilly",
          "postalCode" : "94250",
          "country" : "FR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/man-4bb7a752921434fd5f9921b5b9473eda",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "man-4bb7a752921434fd5f9921b5b9473eda",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_man-4bb7a752921434fd5f9921b5b9473eda\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization man-4bb7a752921434fd5f9921b5b9473eda</b></p><a name=\"man-4bb7a752921434fd5f9921b5b9473eda\"> </a><a name=\"hcman-4bb7a752921434fd5f9921b5b9473eda\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100011564 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000033}\">Manufacturer</span></p><p><b>name</b>: Sanofi Winthrop Industrie</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>1, rue de la Vierge Ambarès &amp; Lagrave FR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100011564"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000033",
          "display" : "Manufacturer"
        }]
      }],
      "name" : "Sanofi Winthrop Industrie",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "1, rue de la Vierge Ambarès & Lagrave FR",
          "line" : ["1, rue de la Vierge"],
          "city" : "Ambarès & Lagrave",
          "postalCode" : "33565",
          "country" : "FR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-d91b269b209aaa5538a1bfafd1a7434d",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-d91b269b209aaa5538a1bfafd1a7434d",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-d91b269b209aaa5538a1bfafd1a7434d</b></p><a name=\"ppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><a name=\"hcppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/010 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 14</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 14</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/010"
      }],
      "name" : "Karvea 75 mg tablet 14",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 14,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-f3f2f89544dfc5d20216861bcf90c0c5",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-f3f2f89544dfc5d20216861bcf90c0c5",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-f3f2f89544dfc5d20216861bcf90c0c5</b></p><a name=\"ppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><a name=\"hcppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 28</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 28</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "name" : "Karvea 75 mg tablet 28",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 28,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-5763619e2b501aeeab53677bd09d5cbf",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-5763619e2b501aeeab53677bd09d5cbf",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-5763619e2b501aeeab53677bd09d5cbf</b></p><a name=\"ppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><a name=\"hcppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/002 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 56</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 56</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/002"
      }],
      "name" : "Karvea 75 mg tablet 56",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 56,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-9b1d5d261d22694685deb35714ec08ea",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-9b1d5d261d22694685deb35714ec08ea",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-9b1d5d261d22694685deb35714ec08ea\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-9b1d5d261d22694685deb35714ec08ea</b></p><a name=\"ppd-9b1d5d261d22694685deb35714ec08ea\"> </a><a name=\"hcppd-9b1d5d261d22694685deb35714ec08ea\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/003 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 98</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 98</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/003"
      }],
      "name" : "Karvea 75 mg tablet 98",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 98,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp873a1a47330e628770640f9c96c0761e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp873a1a47330e628770640f9c96c0761e</b></p><a name=\"mp873a1a47330e628770640f9c96c0761e\"> </a><a name=\"hcmp873a1a47330e628770640f9c96c0761e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E82719</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Karvea 75 mg tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Karvea</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: irbesartan</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 75 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 DK}\">Denmark</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 DK}\">Denmark</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E82719"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Karvea 75 mg tablet",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Karvea",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "irbesartan",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "75 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "tablet",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "DK",
              "display" : "Denmark"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "DK",
              "display" : "Denmark"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-dcaa4d32aa6658a8df831551503e52ee",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-dcaa4d32aa6658a8df831551503e52ee</b></p><a name=\"mid-dcaa4d32aa6658a8df831551503e52ee\"> </a><a name=\"hcmid-dcaa4d32aa6658a8df831551503e52ee\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }]
    }
  }]
}

```
