# ePI document Bundle for Remsima 100 mg powder for concentrate for solution for infusion Package Leaflet for language en - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Remsima 100 mg powder for concentrate for solution for infusion Package Leaflet for language en**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **1 Child-resistant closure** **(Cardboard)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Powder for concentrate for solution for infusion ** 

 Unit of presentation: ** Vial ** 

Ingredient

 Role: ** active ** 

 Substance: ** INFLIXIMAB ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Disodium phosphate dihydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Sodium dihydrogen phosphate monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** POLYSORBATE 80 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Sucrose ** 

## Example Bundle: ePI document Bundle for Remsima 100 mg powder for concentrate for solution for infusion Package Leaflet for language en

**Composition category:**Raw

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

Read all of this leaflet carefully before you start using this medicine because it contains important information for you.

* Keep this leaflet. You may need to read it again.
* Your doctor will also give you a patient reminder card, which contains important safety information you need to be aware of before and during your treatment with Remsima.
* When starting a new card, keep this card as a reference for 4 months after your last dose of Remsima.
* If you have any further questions, ask your doctor, pharmacist or nurse.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.
* If you get any side effects, talk to your doctor, pharmacist or nurse. This includes any possible side efects not listed in this leaflet. See section 4.


#### What is in this leaflet

 

What is in this leaflet

1. What Remsima is and what it is used for
1. What you need to know before you use Remsima
1. How to use Remsima
1. Possible side effects
1. How to store Remsima
1. Contents of the pack and other information
1. Instructions for use


#### 1. What Remsima 100 mg powder for concentrate for solution for infusion is and what it is used for

 

Remsima contains the active substance infliximab. Infliximab is a monoclonal antibody - a type of protein that attaches to a specific target in the body called TNF (tumour necrosis factor) alpha. Remsima belongs to a group of medicines called ‘TNF blockers’. It is used in adults for the following inflammatory diseases:

* Rheumatoid arthritis
* Psoriatic arthritis
* Ankylosing spondylitis (Bechterew’s disease)
* Psoriasis
* Crohn’s disease
* Ulcerative colitis.

Remsima works by selectively attaching to TNF alpha and blocking its action. TNF alpha is involved in inflammatory processes of the body so blocking it can reduce the inflammation in your body.

**Rheumatoid arthritis**Rheumatoid arthritis is an inflammatory disease of the joints. If you have active rheumatoid arthritis you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima which you will take with another medicine called methotrexate to:

* reduce the signs and symptoms of your disease,
* slow down the damage in your joints,
* improve your physical function.

**Psoriatic arthritis**Psoriatic arthritis is an inflammatory disease of the joints, usually accompanied by psoriasis. If you have active psoriatic arthritis you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima to:

* reduce the signs and symptoms of your disease,
* slow down the damage in your joints,
* improve your physical function.

**Ankylosing spondylitis (Bechterew’s disease)**Ankylosing spondylitis is an inflammatory disease of the spine. If you have ankylosing spondylitis you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima to:

* reduce the signs and symptoms of your disease,
* improve your physical function.

**Psoriasis**Psoriasis is an inflammatory disease of the skin. If you have moderate to severe plaque psoriasis, you will first be given other medicines or treatments, such as phototherapy. If these medicines or treatments do not work well enough, you will be given Remsima to reduce the signs and symptoms of your disease. Ulcerative colitis Ulcerative colitis is an inflammatory disease of the bowel. If you have ulcerative colitis you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima to treat your disease.

**Crohn’s disease**

Crohn’s disease is an inflammatory disease of the bowel. If you have Crohn’s disease you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima to:

* treat active Crohn’s disease,
* reduce the number of abnormal openings (fistulae) between your bowel and your skin that have not been controlled by other medicines or surgery


#### 2. What you need to know before you take Remsima 100 mg powder for concentrate for solution for infusion

 

**You must not use Remsima if**

* you are allergic to infliximab or any of the other ingredients of this medicine (listed in section 6),
* you are allergic to proteins that come from mice,
* you have tuberculosis (TB) or another serious infection such as pneumonia or sepsis (serious bacterial infection of the blood),
* you have heart failure that is moderate or severe. Do not use Remsima if any of the above applies to you. If you are not sure, talk to your doctor before you are given Remsima.

**Warnings and precautions**

Talk to your doctor before or during treatment with Remsima if you have:

**Had treatment with any medicine containing infliximab before**

* Tell your doctor if you have had treatment with medicines containing infliximab in the past and are now starting Remsima treatment again.
* If you have had a break in your treatment with infliximab of more than 16 weeks, there is a higher risk for allergic reactions when you start the treatment again.

**Local injection site reactions**

* Some patients receiving infliximab via injection under the skin have experienced local injection site reactions. Signs of a local injection site reaction can include redness, pain, itching, swelling, hardness, bruising, bleeding, cold sensation, tingling sensation, irritation, rash, ulcer, hives, blisters and scab on the skin of the injection site.
* Most of these reactions are mild to moderate and mostly resolve on their own within a day.

**Infections**

* Tell your doctor before you are given Remsima if you have an infection even if it is a very minor one.
* Tell your doctor before you are given Remsima if you have ever lived in or travelled to an area where infections called histoplasmosis, coccidioidomycosis, or blastomycosis are common. These infections are caused by specific types of fungi that can affect the lungs or other parts of your body.
* You may get infections more easily when you are being treated with Remsima. If you are 65 years of age or older, you have a greater risk.
* These infections may be serious and include tuberculosis, infections caused by viruses, fungi, bacteria or other organisms in the environment and sepsis that may be life-threatening. Tell your doctor straight away if you get signs of infection during treatment with Remsima. Signs include fever, cough, flu-like signs, feeling unwell, red or hot skin, wounds or dental problems. Your doctor may recommend temporarily stopping Remsima.

**Tuberculosis (TB)**

* It is very important that you tell your doctor if you have ever had TB or if you have been in close contact with someone who has had or has TB.
* Your doctor will test you to see if you have TB. Cases of TB have been reported in patients treated with infliximab, even in patients who have already been treated with medicines for TB. Your doctor will record these tests on your patient reminder card.
* If your doctor feels that you are at risk for TB, you may be treated with medicines for TB before you are given Remsima. Tell your doctor straight away if you get signs of TB during treatment with Remsima. Signs include persistent cough, weight loss, feeling tired, fever, night sweats.

**Hepatitis B virus**

* Tell your doctor before you are using Remsima if you are a carrier of hepatitis B or have ever had it.
* Tell your doctor if you think you might be at risk of contracting hepatitis B.
* Your doctor should test you for hepatitis B virus.
* Treatment with TNF blockers such as Remsima may result in reactivation of hepatitis B virus in patients who carry this virus, which can be life-threatening in some cases.
* If you experience reactivation of hepatitis B, your doctor may need to stop your treatment and may give you medicines such as effective antiviral therapy with supportive treatment.

**Heart problems**

* Tell your doctor if you have any heart problems, such as mild heart failure.
* Your doctor will want to closely monitor your heart. Tell your doctor straight away if you get new or worsening signs of heart failure during treatment with Remsima. Signs include shortness of breath or swelling of your feet.

**Cancer and lymphoma**

* Tell your doctor before you are given Remsima if you have or have ever had lymphoma (a type of blood cancer) or any other cancer.
* Patients with severe rheumatoid arthritis, who have had the disease for a long time, may be at higher risk of developing lymphoma.
* Patients taking Remsima may have an increased risk of developing lymphoma or another cancer.
* Some patients who have received TNF-blockers, including infliximab have developed a rare type of cancer called hepatosplenic T-cell lymphoma. Of these patients, most were teenage boys or young men and most had either Crohn’s disease or ulcerative colitis. This type of cancer has usually resulted in death. Almost all patients had also received medicines containing azathioprine or mercaptopurine in addition to TNF-blockers.
* Some patients treated with infliximab have developed certain kinds of skin cancer. If there are any changes in your skin or growths on the skin during or after therapy, tell your doctor.
* Some women being treated for rheumatoid arthritis with infliximab have developed cervical cancer. For women taking Remsima including those over 60 years of age, your doctor may recommend regular screening for cervical cancer.

**Lung disease or heavy smoking**

* Tell your doctor before you are given Remsima if you have a lung disease called chronic obstructive pulmonary disease (COPD) or if you are a heavy smoker.
* Patients with COPD and patients who are heavy smokers may have a higher risk of developing cancer with Remsima treatment.

**Nervous system disease**

* Tell your doctor before you are given Remsima if you have or have ever had a problem that affects your nervous system. This includes multiple sclerosis, Guillain-Barré syndrome, if you have fits or have been diagnosed with ‘optic neuritis’.

Tell your doctor straight away if you get symptoms of a nerve disease during treatment with Remsima. Signs include changes in your vision, weakness in your arms or legs, numbness or tingling in any part of your body.

**Abnormal skin openings**

* Tell your doctor if you have any abnormal skin openings (fistulae) before you are given Remsima.

**Vaccinations**

* Talk to your doctor if you recently have had or are due to have a vaccine.
* You should receive recommended vaccinations before starting Remsima treatment. You may receive some vaccines during treatment with Remsima but you should not receive live vaccines (vaccines that contain a living but weakened infectious agent) while using Remsima because they may cause infections.
* If you received Remsima while you were pregnant, your baby may also be at higher risk for getting an infection as a result of receiving a live vaccine during the first year of life. It is important that you tell your baby's doctors and other health care professionals about your Remsima use so they can decide when your baby should receive any vaccine, including live vaccines such as the BCG vaccine (used to prevent tuberculosis).
* If you are breast-feeding, it is important that you tell your baby’s doctors and other healthcare professionals about your Remsima use before your baby is given any vaccine. For more information see section on Pregnancy and breast-feeding.

**Therapeutic infectious agents**

* Talk to your doctor if you have recently received or are scheduled to receive treatment with a therapeutic infectious agent (such as BCG instillation used for the treatment of cancer)

**Operations or dental procedures**

* Tell your doctor if you are going to have any operations or dental procedures.
* Tell your surgeon or dentist that you are having treatment with Remsima by showing them your patient reminder card.

**Liver problems**

* Some patients receiving infliximab have developed serious liver problems.
* Tell your doctor straight away if you get symptoms of liver problems during treatment with Remsima. Signs include yellowing of the skin and eyes, dark-brown coloured urine, pain or swelling in the upper right side of the stomach area, joint pain, skin rashes, or fever.

**Low blood counts**

* In some patients receiving infliximab, the body may not make enough of the blood cells that help fight infections or help stop bleeding.
* Tell your doctor straight away if you get symptoms of low blood counts during treatment with Remsima. Signs include persistent fever, bleeding or bruising more easily, small red or purple spots caused by bleeding under the skin, or looking pale.

**Immune system disorder**

* Some patients receiving infliximab have developed symptoms of an immune system disorder called lupus.
* Tell your doctor straight away if you develop symptoms of lupus during treatment with Remsima. Signs include joint pain or a rash on cheeks or arms that is sensitive to the sun.

**Children and adolescents**

Do not give this medicine to children and adolescents under 18 years of age because there are no data that show that this medicine is safe and works in this age group.

**Other medicines and Remsima**

Patients who have inflammatory diseases already take medicines to treat their problem. These medicines may cause side effects. Your doctor will advise you what other medicines you must keep using while you are having Remsima.

Tell your doctor if you are using, have recently used or might use any other medicines, including any other medicines to treat Crohn’s disease, ulcerative colitis, rheumatoid arthritis, ankylosing spondylitis, psoriatic arthritis or psoriasis or medicines obtained without a prescription, such as vitamins and herbal medicines.

In particular, tell your doctor if you are using any of the following medicines:

* Medicines that affect your immune system.
* Kineret (which contains anakinra). Remsima and Kineret should not be used together.
* Orencia (which contains abatacept). Remsima and Orencia should not be used together. While using Remsima you should not receive live vaccines. If you were using Remsima during pregnancy or if you are receiving Remsima while breast-feeding, tell your baby’s doctor and other health care professionals caring for your baby about your Remsima use before the baby receives any vaccines.

If you are not sure if any of the above applies to you, talk to your doctor, pharmacist or nurse before using Remsima.

**Pregnancy, breast-feeding and fertility**

* If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor for advice before taking this medicine. Remsima should only be used during pregnancy or while breast-feeding if your doctor feels it is necessary for you.
* You should avoid getting pregnant when you are being treated with Remsima and for 6 months after you stop being treated with it. Discuss the use of contraception during this time with your doctor.
* If you received Remsima during your pregnancy, your baby may have a higher risk for getting an infection.
* It is important that you tell your baby’s doctors and other healthcare professionals about your Remsima use before your baby is given any vaccine. If you received Remsima while pregnant, giving BCG vaccine (used to prevent tuberculosis) to your baby within 12 months after birth may result in infection with serious complications, including death. Live vaccines such as the BCG vaccine should not be given to your baby within 12 months after birth, unless your baby’s doctor recommends otherwise. For more information see section on vaccination.
* If you are breast-feeding, it is important that you tell your baby’s doctors and other healthcare professionals about your Remsima use before your baby is given any vaccine. Live vaccines should not be given to your baby while you are breast-feeding unless your baby’s doctor recommends otherwise.
* Severely decreased numbers of white blood cells have been reported in infants born to women treated with infliximab during pregnancy. If your baby has continual fevers or infections, contact your baby’s doctor immediately.

**Driving and using machines**

Remsima is not likely to affect your ability to drive or use tools or machines. If you feel tired, dizzy, or unwell after having Remsima, do not drive or use any tools or machines.

**Remsima contains sodium and sorbitol**

This medicine contains less than 1 mmol sodium (23 mg) per dose, i.e. essentially ‘sodium-free’ and 45 mg sorbitol in each 120 mg dose.


#### 3. How to take Remsima 100 mg powder for concentrate for solution for infusion

 

Always use this medicine exactly as your doctor has told you. Check with your doctor if you are not sure.

**Rheumatoid arthritis**

Your doctor will start your treatment with or without two Remsima intravenous infusion doses of 3 mg for every kg of body weight (given to you into a vein, usually in your arm, over a period of 2 hours). If Remsima intravenous infusion doses are given to start the treatment, they are administered 2 weeks apart via intravenous infusion. After 4 weeks from the last intravenous infusion, you will be given Remsima via injection under the skin (subcutaneous injection). The usual recommended dose of Remsima subcutaneous injection is 120 mg once every 2 weeks regardless of weight.

**Psoriatic arthritis, ankylosing spondylitis (Bechterew’s disease) and psoriasis**

Your doctor will start your treatment with two Remsima intravenous infusion doses of 5 mg for every kg of body weight (given to you into a vein, usually in your arm, over a period of 2 hours). They are administered 2 weeks apart via intravenous infusion. After 4 weeks from the last intravenous infusion, you will be given Remsima via injection under the skin (subcutaneous injection). The usual recommended dose of Remsima subcutaneous injection is 120 mg once every 2 weeks regardless of weight.

**Crohn’s disease and ulcerative colitis**

Your doctor will start your treatment with two Remsima intravenous infusion doses of 5 mg for every kg of body weight (given to you into a vein, usually in your arm, over a period of 2 hours). They are administered 2 weeks apart via intravenous infusion. After 4 weeks from the last intravenous infusion, you will be given Remsima via injection under the skin (subcutaneous injection). The usual recommended dose of Remsima subcutaneous injection is 120 mg once every 2 weeks regardless of weight.

**How Remsima is given**

* Remsima 120 mg solution for injection is administered by injection under the skin (subcutaneous use) only. It is important to check the product labels to ensure that the correct formulation is being given as prescribed.
* For patients with rheumatoid arthritis, your doctor may start your Remsima treatment with or without two Remsima intravenous infusion doses. For patients with Crohn’s disease, ulcerative colitis, ankylosing spondylitis, psoriatic arthritis or psoriasis, two Remsima infusion doses will be given to start your Remsima treatment.
* If Remsima treatment is initiated without two Remsima intravenous infusion doses, the table below shows how often you will usually have this medicine after your first dose.
* If two Remsima intravenous infusion doses are given by your doctor or nurse to start the treatment, they will be given 2 weeks apart and the first Remsima subcutaneous injection will be given 4 weeks after the last intravenous infusion followed by Remsima subcutaneous injections given every 2 weeks.
* The first subcutaneous injection of Remsima will be administered under the supervision of your doctor.
* After proper training, if you feel you are well-trained and confident to inject Remsima yourself, your doctor may allow you to inject subsequent doses of Remsima yourself at home.
* Talk to your doctor if you have any questions about giving yourself an injection. You will find detailed “Instructions for Use” at the end of this leaflet.

**If you use more Remsima than you should**

If you have used more Remsima than you should (either by injecting too much on a single occasion or by using it too frequently), talk to a doctor, pharmacist or nurse immediately. Always have the outer carton of the medicine with you, even if it is empty.

**If you forget to use Remsima**

**Missed dose for up to 7 days**

If you miss a dose of Remsima for up to 7 days, after the original scheduled dose, you should take the missed dose immediately. Take your next dose on the next originally planned date and then follow the original dosing schedule.

**Missed dose for 8 days or more**

If you miss a dose of Remsima for 8 days or more, after the original scheduled dose, you should not take the missed dose. Take your next dose on the next originally planned date and then follow the original dosing schedule. If you are not sure when to inject Remsima, call your doctor.

If you have any further questions on the use of this medicine, ask your doctor, pharmacist or nurse.


#### 4. Possible side effects

 

Like all medicines, this medicine can cause side effects, although not everybody gets them. Most side effects are mild to moderate. However some patients may experience serious side effects and may require treatment. Side effects may also occur after your treatment with Remsima has stopped.

**Tell your doctor straight away if you notice any of the following:**

* **Signs of an allergic reaction** such as swelling of your face, lips, mouth or throat which may cause difficulty in swallowing or breathing, skin rash, hives, swelling of the hands, feet or ankles. Some of these reactions may be serious or life-threatening. An allergic reaction could happen within 2 hours of your injection or later. More signs of allergic side effects that may happen up to 12 days after your injection include pain in the muscles, fever, joint or jaw pain, sore throat or headache.
* **Signs of a local injection site** reaction such as redness, pain, itching, swelling, hardness, bruising, bleeding, cold sensation, tingling sensation, irritation, rash, ulcer, hives, blisters and scab.
* Signs of a heart problem such as chest discomfort or pain, arm pain, stomach pain, shortness of breath, anxiety, lightheadedness, dizziness, fainting, sweating, nausea (feeling sick), vomiting, fluttering or pounding in your chest, a fast or a slow heartbeat, and swelling of your feet.
* Signs of infection (including TB) such as fever, feeling tired, cough which may be persistent, shortness of breath, flu-like symptoms, weight loss, night sweats, diarrhoea, wounds, collection of pus in the gut or around the anus (abscess), dental problems or burning sensation when urinating.
* Possible signs of cancer including but not limited to swelling of lymph nodes, weight loss, fever, unusual skin nodules, changes in moles or skin colouring, or unusual vaginal bleeding.
* Signs of a lung problem such as coughing, breathing difficulties or tightness in the chest.
* Signs of a nervous system problem (including eye problems) such as signs of a stroke (sudden numbness or weakness of your face, arm or leg, especially on one side of your body; sudden confusion, trouble speaking or understanding; trouble seeing in one or both eyes, trouble walking, dizziness, loss of balance or coordination or a severe headache), fits, tingling/numbness in any part of your body, or weakness in arms or legs, changes in eyesight such as double vision or other eye problems.
* Signs of a liver problem (including hepatitis B infection when you have had hepatitis B in the past) such as yellowing of the skin or eyes, dark-brown coloured urine, pain or swelling in the upper right side of the stomach area, joint pain, skin rashes, or fever.
* Signs of an immune system disorder called lupus such as joint pain or a rash on cheeks or arms that is sensitive to the sun (lupus) or cough, shortness of breath, fever or skin rash (sarcoidosis).
* Signs of low blood counts such as persistent fever, bleeding or bruising more easily, small red or purple spots caused by bleeding under the skin, or looking pale.
* Signs of serious skin problems such as reddish-target-like spots or circular patches often with central blisters on the trunk, large areas of peeling and shedding (exfoliating) skin, ulcers of mouth, throat, nose, genitals and eyes or small pus-filled bumps that can spread over the body. These skin reactions can be accompanied by fever. Tell your doctor straight away if you notice any of the above. The following side effects have been observed with Remsima:

**Very common:** may affect more than 1 in 10 people

* Stomach pain, feeling sick Viral infections such as herpes or flu
* Upper respiratory infections such as sinusitis
* Headache
* Side effect due to an injection
* Pain.

**Common:** may affect up to 1 in 10 people

* Changes in how your liver works, increase in liver enzymes (shown in blood tests)
* Lung or chest infections such as bronchitis or pneumonia
* Difficult or painful breathing, chest pain
* Bleeding in the stomach or intestines, diarrhoea, indigestion, heartburn, constipation
* Nettle-type rash (hives), itchy rash or dry skin
* Balance problems or feeling dizzy
* Fever, increased sweating
* Circulation problems such as low or high blood pressure
* Bruising, hot flush or nosebleed, warm, red skin (flushing)
* Feeling tired or weak
* Bacterial infections such as blood poisoning, abscess or infection of the skin (cellulitis)
* Infection of the skin due to a fungus
* Blood problems such as anaemia or low white blood cell count
* Swollen lymph nodes
* Depression, problems sleeping
* Eye problems, including red eyes and infections
* Fast heart beat (tachycardia) or palpitations
* Pain in the joints, muscles or back
* Urinary tract infection
* Psoriasis, skin problems such as eczema and hair loss
* Reactions at the injection site such as pain, swelling, redness or itching
* Chills, a build-up of fluid under the skin causing swelling
* Feeling numb or having a tingling feeling.

**Uncommon:** may affect up to 1 in 100 people

* Shortage of blood supply, swelling of a vein
* Collection of blood outside the blood vessels (haematoma) or bruising
* Skin problems such as blistering, warts, abnormal skin colouration or pigmentation, or swollen lips, or thickening of the skin, or red, scaly, and flaky skin
* Severe allergic reactions (e.g. anaphylaxis), an immune system disorder called lupus, allergic reactions to foreign proteins
* Wounds taking longer to heal
* Swelling of the liver (hepatitis) or gall bladder, liver damage
* Feeling forgetful, irritable, confused, nervous
* Eye problems including blurred or reduced vision, puffy eyes or sties
* New or worsening heart failure, slow heart rate
* Fainting
* Convulsions, nerve problems
* A hole in the bowel or blockage of the intestine, stomach pain or cramps
* Swelling of your pancreas (pancreatitis)
* Fungal infections such as yeast infection, or fungal infection of the nails
* Lung problems (such as oedema)
* Fluid around the lungs (pleural effusion)
* Narrowed airway in the lungs, causing difficulty breathing
* Inflamed lining of the lung, causing sharp chest pains that feel worse with breathing (pleurisy)
* Tuberculosis
* Kidney infections Low platelet count, too many white blood cells
* Infections of the vagina
* Blood test result showing ‘antibodies’ against your own body
* Changes in cholesterol and fat levels in the blood.

**Rare:** may affect up to 1 in 1,000 people

* A type of blood cancer (lymphoma)
* Your blood not supplying enough oxygen to your body, circulation problems such as narrowing of a blood vessel
* Inflammation of the lining of the brain (meningitis)
* Infections due to a weakened immune system
* Hepatitis B infection when you have had hepatitis B in the past
* Inflamed liver caused by a problem with the immune system (autoimmune hepatitis)
* Liver problem that causes yellowing of the skin or eyes (jaundice)
* Abnormal tissue swelling or growth
* Severe allergic reaction that may cause loss of consciousness and could be life-threatening (anaphylactic shock)
* Swelling of small blood vessels (vasculitis)
* Immune disorders that could affect the lungs, skin and lymph nodes (such as sarcoidosis)
* Collections of immune cells resulting from an inflammatory response (granulomatous lesions)
* Lack of interest or emotion
* Serious skin problems such as toxic epidermal necrolysis, Stevens-Johnson syndrome and acute generalised exanthematous pustulosis
* Other skin problems such as erythema multiforme, blisters and peeling skin, or boils (furunculosis)
* Serious nervous system disorders such as transverse myelitis, multiple sclerosis-like disease, optic neuritis and Guillain-Barré syndrome
* Inflammation in the eye that may cause changes in the vision, including blindness
* Fluid in the lining of the heart (pericardial effusion)
* Serious lung problems (such as interstitial lung disease)
* Melanoma (a type of skin cancer)
* Cervical cancer
* Low blood counts, including a severely decreased number of white blood cells
* Small red or purple spots caused by bleeding under the skin
* Abnormal values of a blood protein called ‘complement factor’ which is part of the immune system
* Lichenoid reactions (itchy reddish-purple skin rash and/or threadlike white-grey lines on mucous membranes).

**Not known:** frequency cannot be estimated from the available data

* Cancer
* A rare blood cancer affecting mostly young men (hepatosplenic T-cell lymphoma)
* Liver failure
* Merkel cell carcinoma (a type of skin cancer)
* Kaposi’s sarcoma, a rare cancer related to infection with human herpes virus 8. Kaposi’s sarcoma most commonly appears as purple lesions on the skin.
* Worsening of a condition called dermatomyositis (seen as a skin rash accompanying muscle weakness)
* Heart attack
* Stroke
* Temporary loss of sight during or within 2 hours of infusion
* Infection due to a live vaccine because of a weakened immune system.
* **Reporting of side effects**

If you get any side effects, talk to your doctor, pharmacist, or nurse. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the national reporting system listed in Appendix V. By reporting side effects you can help provide more information on the safety of this medicine.


#### 5. How to store Remsima 100 mg powder for concentrate for solution for infusion

 

* Keep this medicine out of the sight and reach of children.
* Do not use this medicine after the expiry date which is stated on the label and the carton after “EXP”. The expiry date refers to the last day of that month.
* Store in a refrigerator (2°C - 8°C). Do not freeze. Keep the medicinal product in its outer carton to protect from light.
* This medicine can also be stored in the original carton outside of refrigerated storage up to a maximum of 25°C for a single period of up to 28 days, but not beyond the original expiry date. In this situation, do not return to refrigerated storage again. Write the new expiry date on the carton including day/month/year. Discard this medicine if not used by the new expiry date or the expiry date printed on the carton, whichever is earlier.
* Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.


#### 6. Contents of the pack and other information

 

**What Remsima contains**

* The active substance is infliximab. Each 1 ml single dose pre-filled syringe contains 120 mg of infliximab.
* The other ingredients are acetic acid, sodium acetate trihydrate, sorbitol, polysorbate 80 and water for injections.

**What Remsima looks like and contents of the pack**

Remsima is a clear to opalescent, colourless to pale brown solution which is supplied as a single use pre-filled syringe.

Each pack contains 1 pre-filled syringe with 2 alcohol pads, 2 pre-filled syringes with 2 alcohol pads, 4 pre-filled syringes with 4 alcohol pads or 6 pre-filled syringes with 6 alcohol pads.

Each pack contains 1 pre-filled syringe with automatic needle guard with 2 alcohol pads, 2 pre-filled syringes with automatic needle guard with 2 alcohol pads, 4 pre-filled syringes with automatic needle guard with 4 alcohol pads or 6 pre-filled syringes with automatic needle guard with 6 alcohol pads.

Not all pack sizes may be marketed


####  Remsima 100 mg powder for concentrate for solution for infusion 
PMSWI:
** EU/1/13/853/001 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E82718 **
-------

Full name: **Remsima 100 mg powder for concentrate for solution for infusion**

 - Invented name part: ** Remsima ** 

 - Scientific name part: ** Infliximab ** 

 - Strength part: ** 100 mg ** 

 - Pharmaceutical dose form part: ** powder for concentrate for solution for infusion ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/13/853/001 ** 

 Region: ** ** 

Marketing authorisation holder: **Celltrion Healthcare Hungary Kft.** 

 Identifier: 
*  **ORG-100000826** 
 

 Status: ** Active (2018-06-21) ** 

 Package 1 of 1

PMSWI: ** EU/1/13/853/001 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****1 

Administrable Product (1 of 1)

 Dose form: ** Powder for concentrate for solution for infusion ** 

 Unit of presentation: ** Vial ** 

 Route of administration: 
*  ** Intravenous use ** 
 
Ingredients:

Ingredient

 Role: ** active ** 

 Substance: ** INFLIXIMAB ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Disodium phosphate dihydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Sodium dihydrogen phosphate monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** POLYSORBATE 80 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Sucrose ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/13/853/001"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-en-be76bdf784deea6950583b234f789db2",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-en-be76bdf784deea6950583b234f789db2",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_composition-en-be76bdf784deea6950583b234f789db2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-en-be76bdf784deea6950583b234f789db2</b></p><a name=\"composition-en-be76bdf784deea6950583b234f789db2\"> </a><a name=\"hccomposition-en-be76bdf784deea6950583b234f789db2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/00c7ed1895dfbadd44fa4ec19f02fe0e</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#Organization_mah-3c850a69e5187931f2198c5e63f933fe\">Organization Celltrion Healthcare Hungary Kft.</a></p><p><b>title</b>: TEST PURPOSES ONLY - Remsima 100 mg powder for concentrate for solution for infusion</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "00c7ed1895dfbadd44fa4ec19f02fe0e"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-3c850a69e5187931f2198c5e63f933fe"
      }],
      "title" : "TEST PURPOSES ONLY - Remsima 100 mg powder for concentrate for solution for infusion",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. Package Leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Read all of this leaflet carefully before you start using this medicine because it contains important information for you.</p><ul><li>Keep this leaflet. You may need to read it again.</li><li>Your doctor will also give you a patient reminder card, which contains important safety information you need to be aware of before and during your treatment with Remsima.</li><li>When starting a new card, keep this card as a reference for 4 months after your last dose of Remsima.</li><li>If you have any further questions, ask your doctor, pharmacist or nurse.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.</li><li>If you get any side effects, talk to your doctor, pharmacist or nurse. This includes any possible side efects not listed in this leaflet. See section 4.</li></ul></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>What is in this leaflet</p><ol><li>What Remsima is and what it is used for</li><li>What you need to know before you use Remsima</li><li>How to use Remsima</li><li>Possible side effects</li><li>How to store Remsima</li><li>Contents of the pack and other information</li><li>Instructions for use</li></ol></div>"
          }
        },
        {
          "title" : "1. What Remsima 100 mg powder for concentrate for solution for infusion is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What Remsima 100 mg powder for concentrate for solution for infusion is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Remsima contains the active substance infliximab. Infliximab is a monoclonal antibody - a type of protein that attaches to a specific target in the body called TNF (tumour necrosis factor) alpha. Remsima belongs to a group of medicines called ‘TNF blockers’. It is used in adults for the following inflammatory diseases:</p><ul><li>Rheumatoid arthritis</li><li>Psoriatic arthritis</li><li>Ankylosing spondylitis (Bechterew’s disease)</li><li>Psoriasis</li><li>Crohn’s disease</li><li>Ulcerative colitis.</li></ul><p>Remsima works by selectively attaching to TNF alpha and blocking its action. TNF alpha is involved in inflammatory processes of the body so blocking it can reduce the inflammation in your body.</p><p><strong>Rheumatoid arthritis</strong>Rheumatoid arthritis is an inflammatory disease of the joints. If you have active rheumatoid arthritis you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima which you will take with another medicine called methotrexate to:</p><ul><li>reduce the signs and symptoms of your disease,</li><li>slow down the damage in your joints,</li><li>improve your physical function.</li></ul><p><strong>Psoriatic arthritis</strong>Psoriatic arthritis is an inflammatory disease of the joints, usually accompanied by psoriasis. If you have active psoriatic arthritis you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima to:</p><ul><li>reduce the signs and symptoms of your disease,</li><li>slow down the damage in your joints,</li><li>improve your physical function.</li></ul><p><strong>Ankylosing spondylitis (Bechterew’s disease)</strong>Ankylosing spondylitis is an inflammatory disease of the spine. If you have ankylosing spondylitis you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima to:</p><ul><li>reduce the signs and symptoms of your disease,</li><li>improve your physical function.</li></ul><p><strong>Psoriasis</strong>Psoriasis is an inflammatory disease of the skin. If you have moderate to severe plaque psoriasis, you will first be given other medicines or treatments, such as phototherapy. If these medicines or treatments do not work well enough, you will be given Remsima to reduce the signs and symptoms of your disease. Ulcerative colitis Ulcerative colitis is an inflammatory disease of the bowel. If you have ulcerative colitis you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima to treat your disease.</p><p><strong>Crohn’s disease</strong></p><p>Crohn’s disease is an inflammatory disease of the bowel. If you have Crohn’s disease you will first be given other medicines. If these medicines do not work well enough, you will be given Remsima to:</p><ul><li>treat active Crohn’s disease,</li><li>reduce the number of abnormal openings (fistulae) between your bowel and your skin that have not been controlled by other medicines or surgery</li></ul></div>"
          }
        },
        {
          "title" : "2. What you need to know before you take Remsima 100 mg powder for concentrate for solution for infusion",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take Remsima 100 mg powder for concentrate for solution for infusion"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>You must not use Remsima if</strong></p><ul><li>you are allergic to infliximab or any of the other ingredients of this medicine (listed in section 6),</li><li>you are allergic to proteins that come from mice,</li><li>you have tuberculosis (TB) or another serious infection such as pneumonia or sepsis (serious bacterial infection of the blood),</li><li>you have heart failure that is moderate or severe. Do not use Remsima if any of the above applies to you. If you are not sure, talk to your doctor before you are given Remsima.</li></ul><p><strong>Warnings and precautions</strong></p><p>Talk to your doctor before or during treatment with Remsima if you have:</p><p><strong>Had treatment with any medicine containing infliximab before</strong></p><ul><li>Tell your doctor if you have had treatment with medicines containing infliximab in the past and are now starting Remsima treatment again.</li><li>If you have had a break in your treatment with infliximab of more than 16 weeks, there is a higher risk for allergic reactions when you start the treatment again.</li></ul><p><strong>Local injection site reactions</strong></p><ul><li>Some patients receiving infliximab via injection under the skin have experienced local injection site reactions. Signs of a local injection site reaction can include redness, pain, itching, swelling, hardness, bruising, bleeding, cold sensation, tingling sensation, irritation, rash, ulcer, hives, blisters and scab on the skin of the injection site.</li><li>Most of these reactions are mild to moderate and mostly resolve on their own within a day.</li></ul><p><strong>Infections</strong></p><ul><li>Tell your doctor before you are given Remsima if you have an infection even if it is a very minor one.</li><li>Tell your doctor before you are given Remsima if you have ever lived in or travelled to an area where infections called histoplasmosis, coccidioidomycosis, or blastomycosis are common. These infections are caused by specific types of fungi that can affect the lungs or other parts of your body.</li><li>You may get infections more easily when you are being treated with Remsima. If you are 65 years of age or older, you have a greater risk.</li><li>These infections may be serious and include tuberculosis, infections caused by viruses, fungi, bacteria or other organisms in the environment and sepsis that may be life-threatening. Tell your doctor straight away if you get signs of infection during treatment with Remsima. Signs include fever, cough, flu-like signs, feeling unwell, red or hot skin, wounds or dental problems. Your doctor may recommend temporarily stopping Remsima.</li></ul><p><strong>Tuberculosis (TB)</strong></p><ul><li>It is very important that you tell your doctor if you have ever had TB or if you have been in close contact with someone who has had or has TB.</li><li>Your doctor will test you to see if you have TB. Cases of TB have been reported in patients treated with infliximab, even in patients who have already been treated with medicines for TB. Your doctor will record these tests on your patient reminder card.</li><li>If your doctor feels that you are at risk for TB, you may be treated with medicines for TB before you are given Remsima. Tell your doctor straight away if you get signs of TB during treatment with Remsima. Signs include persistent cough, weight loss, feeling tired, fever, night sweats.</li></ul><p><strong>Hepatitis B virus</strong></p><ul><li>Tell your doctor before you are using Remsima if you are a carrier of hepatitis B or have ever had it.</li><li>Tell your doctor if you think you might be at risk of contracting hepatitis B.</li><li>Your doctor should test you for hepatitis B virus.</li><li>Treatment with TNF blockers such as Remsima may result in reactivation of hepatitis B virus in patients who carry this virus, which can be life-threatening in some cases.</li><li>If you experience reactivation of hepatitis B, your doctor may need to stop your treatment and may give you medicines such as effective antiviral therapy with supportive treatment.</li></ul><p><strong>Heart problems</strong></p><ul><li>Tell your doctor if you have any heart problems, such as mild heart failure.</li><li>Your doctor will want to closely monitor your heart. Tell your doctor straight away if you get new or worsening signs of heart failure during treatment with Remsima. Signs include shortness of breath or swelling of your feet.</li></ul><p><strong>Cancer and lymphoma</strong></p><ul><li>Tell your doctor before you are given Remsima if you have or have ever had lymphoma (a type of blood cancer) or any other cancer.</li><li>Patients with severe rheumatoid arthritis, who have had the disease for a long time, may be at higher risk of developing lymphoma.</li><li>Patients taking Remsima may have an increased risk of developing lymphoma or another cancer.</li><li>Some patients who have received TNF-blockers, including infliximab have developed a rare type of cancer called hepatosplenic T-cell lymphoma. Of these patients, most were teenage boys or young men and most had either Crohn’s disease or ulcerative colitis. This type of cancer has usually resulted in death. Almost all patients had also received medicines containing azathioprine or mercaptopurine in addition to TNF-blockers.</li><li>Some patients treated with infliximab have developed certain kinds of skin cancer. If there are any changes in your skin or growths on the skin during or after therapy, tell your doctor.</li><li>Some women being treated for rheumatoid arthritis with infliximab have developed cervical cancer. For women taking Remsima including those over 60 years of age, your doctor may recommend regular screening for cervical cancer.</li></ul><p><strong>Lung disease or heavy smoking</strong></p><ul><li>Tell your doctor before you are given Remsima if you have a lung disease called chronic obstructive pulmonary disease (COPD) or if you are a heavy smoker.</li><li>Patients with COPD and patients who are heavy smokers may have a higher risk of developing cancer with Remsima treatment.</li></ul><p><strong>Nervous system disease</strong></p><ul><li>Tell your doctor before you are given Remsima if you have or have ever had a problem that affects your nervous system. This includes multiple sclerosis, Guillain-Barré syndrome, if you have fits or have been diagnosed with ‘optic neuritis’.</li></ul><p>Tell your doctor straight away if you get symptoms of a nerve disease during treatment with Remsima. Signs include changes in your vision, weakness in your arms or legs, numbness or tingling in any part of your body.</p><p><strong>Abnormal skin openings</strong></p><ul><li>Tell your doctor if you have any abnormal skin openings (fistulae) before you are given Remsima.</li></ul><p><strong>Vaccinations</strong></p><ul><li>Talk to your doctor if you recently have had or are due to have a vaccine.</li><li>You should receive recommended vaccinations before starting Remsima treatment. You may receive some vaccines during treatment with Remsima but you should not receive live vaccines (vaccines that contain a living but weakened infectious agent) while using Remsima because they may cause infections.</li><li>If you received Remsima while you were pregnant, your baby may also be at higher risk for getting an infection as a result of receiving a live vaccine during the first year of life. It is important that you tell your baby&#39;s doctors and other health care professionals about your Remsima use so they can decide when your baby should receive any vaccine, including live vaccines such as the BCG vaccine (used to prevent tuberculosis).</li><li>If you are breast-feeding, it is important that you tell your baby’s doctors and other healthcare professionals about your Remsima use before your baby is given any vaccine. For more information see section on Pregnancy and breast-feeding.</li></ul><p><strong>Therapeutic infectious agents</strong></p><ul><li>Talk to your doctor if you have recently received or are scheduled to receive treatment with a therapeutic infectious agent (such as BCG instillation used for the treatment of cancer)</li></ul><p><strong>Operations or dental procedures</strong></p><ul><li>Tell your doctor if you are going to have any operations or dental procedures.</li><li>Tell your surgeon or dentist that you are having treatment with Remsima by showing them your patient reminder card.</li></ul><p><strong>Liver problems</strong></p><ul><li>Some patients receiving infliximab have developed serious liver problems.</li><li>Tell your doctor straight away if you get symptoms of liver problems during treatment with Remsima. Signs include yellowing of the skin and eyes, dark-brown coloured urine, pain or swelling in the upper right side of the stomach area, joint pain, skin rashes, or fever.</li></ul><p><strong>Low blood counts</strong></p><ul><li>In some patients receiving infliximab, the body may not make enough of the blood cells that help fight infections or help stop bleeding.</li><li>Tell your doctor straight away if you get symptoms of low blood counts during treatment with Remsima. Signs include persistent fever, bleeding or bruising more easily, small red or purple spots caused by bleeding under the skin, or looking pale.</li></ul><p><strong>Immune system disorder</strong></p><ul><li>Some patients receiving infliximab have developed symptoms of an immune system disorder called lupus.</li><li>Tell your doctor straight away if you develop symptoms of lupus during treatment with Remsima. Signs include joint pain or a rash on cheeks or arms that is sensitive to the sun.</li></ul><p><strong>Children and adolescents</strong></p><p>Do not give this medicine to children and adolescents under 18 years of age because there are no data that show that this medicine is safe and works in this age group.</p><p><strong>Other medicines and Remsima</strong></p><p>Patients who have inflammatory diseases already take medicines to treat their problem. These medicines may cause side effects. Your doctor will advise you what other medicines you must keep using while you are having Remsima.</p><p>Tell your doctor if you are using, have recently used or might use any other medicines, including any other medicines to treat Crohn’s disease, ulcerative colitis, rheumatoid arthritis, ankylosing spondylitis, psoriatic arthritis or psoriasis or medicines obtained without a prescription, such as vitamins and herbal medicines.</p><p>In particular, tell your doctor if you are using any of the following medicines:</p><ul><li>Medicines that affect your immune system.</li><li>Kineret (which contains anakinra). Remsima and Kineret should not be used together.</li><li>Orencia (which contains abatacept). Remsima and Orencia should not be used together. While using Remsima you should not receive live vaccines. If you were using Remsima during pregnancy or if you are receiving Remsima while breast-feeding, tell your baby’s doctor and other health care professionals caring for your baby about your Remsima use before the baby receives any vaccines.</li></ul><p>If you are not sure if any of the above applies to you, talk to your doctor, pharmacist or nurse before using Remsima.</p><p><strong>Pregnancy, breast-feeding and fertility</strong></p><ul><li>If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor for advice before taking this medicine. Remsima should only be used during pregnancy or while breast-feeding if your doctor feels it is necessary for you.</li><li>You should avoid getting pregnant when you are being treated with Remsima and for 6 months after you stop being treated with it. Discuss the use of contraception during this time with your doctor.</li><li>If you received Remsima during your pregnancy, your baby may have a higher risk for getting an infection.</li><li>It is important that you tell your baby’s doctors and other healthcare professionals about your Remsima use before your baby is given any vaccine. If you received Remsima while pregnant, giving BCG vaccine (used to prevent tuberculosis) to your baby within 12 months after birth may result in infection with serious complications, including death. Live vaccines such as the BCG vaccine should not be given to your baby within 12 months after birth, unless your baby’s doctor recommends otherwise. For more information see section on vaccination.</li><li>If you are breast-feeding, it is important that you tell your baby’s doctors and other healthcare professionals about your Remsima use before your baby is given any vaccine. Live vaccines should not be given to your baby while you are breast-feeding unless your baby’s doctor recommends otherwise.</li><li>Severely decreased numbers of white blood cells have been reported in infants born to women treated with infliximab during pregnancy. If your baby has continual fevers or infections, contact your baby’s doctor immediately.</li></ul><p><strong>Driving and using machines</strong></p><p>Remsima is not likely to affect your ability to drive or use tools or machines. If you feel tired, dizzy, or unwell after having Remsima, do not drive or use any tools or machines.</p><p><strong>Remsima contains sodium and sorbitol</strong></p><p>This medicine contains less than 1 mmol sodium (23 mg) per dose, i.e. essentially ‘sodium-free’ and 45 mg sorbitol in each 120 mg dose.</p></div>"
          }
        },
        {
          "title" : "3. How to take Remsima 100 mg powder for concentrate for solution for infusion",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take Remsima 100 mg powder for concentrate for solution for infusion"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Always use this medicine exactly as your doctor has told you. Check with your doctor if you are not sure.</p><p><strong>Rheumatoid arthritis</strong></p><p>Your doctor will start your treatment with or without two Remsima intravenous infusion doses of 3 mg for every kg of body weight (given to you into a vein, usually in your arm, over a period of 2 hours). If Remsima intravenous infusion doses are given to start the treatment, they are administered 2 weeks apart via intravenous infusion. After 4 weeks from the last intravenous infusion, you will be given Remsima via injection under the skin (subcutaneous injection). The usual recommended dose of Remsima subcutaneous injection is 120 mg once every 2 weeks regardless of weight.</p><p><strong>Psoriatic arthritis, ankylosing spondylitis (Bechterew’s disease) and psoriasis</strong></p><p>Your doctor will start your treatment with two Remsima intravenous infusion doses of 5 mg for every kg of body weight (given to you into a vein, usually in your arm, over a period of 2 hours). They are administered 2 weeks apart via intravenous infusion. After 4 weeks from the last intravenous infusion, you will be given Remsima via injection under the skin (subcutaneous injection). The usual recommended dose of Remsima subcutaneous injection is 120 mg once every 2 weeks regardless of weight.</p><p><strong>Crohn’s disease and ulcerative colitis</strong></p><p>Your doctor will start your treatment with two Remsima intravenous infusion doses of 5 mg for every kg of body weight (given to you into a vein, usually in your arm, over a period of 2 hours). They are administered 2 weeks apart via intravenous infusion. After 4 weeks from the last intravenous infusion, you will be given Remsima via injection under the skin (subcutaneous injection). The usual recommended dose of Remsima subcutaneous injection is 120 mg once every 2 weeks regardless of weight.</p><p><strong>How Remsima is given</strong></p><ul><li>Remsima 120 mg solution for injection is administered by injection under the skin (subcutaneous use) only. It is important to check the product labels to ensure that the correct formulation is being given as prescribed.</li><li>For patients with rheumatoid arthritis, your doctor may start your Remsima treatment with or without two Remsima intravenous infusion doses. For patients with Crohn’s disease, ulcerative colitis, ankylosing spondylitis, psoriatic arthritis or psoriasis, two Remsima infusion doses will be given to start your Remsima treatment.</li><li><p>If Remsima treatment is initiated without two Remsima intravenous infusion doses, the table below shows how often you will usually have this medicine after your first dose.</p></li><li><p>If two Remsima intravenous infusion doses are given by your doctor or nurse to start the treatment, they will be given 2 weeks apart and the first Remsima subcutaneous injection will be given 4 weeks after the last intravenous infusion followed by Remsima subcutaneous injections given every 2 weeks.</p></li><li>The first subcutaneous injection of Remsima will be administered under the supervision of your doctor.</li><li>After proper training, if you feel you are well-trained and confident to inject Remsima yourself, your doctor may allow you to inject subsequent doses of Remsima yourself at home.</li><li>Talk to your doctor if you have any questions about giving yourself an injection. You will find detailed “Instructions for Use” at the end of this leaflet.</li></ul><p><strong>If you use more Remsima than you should</strong></p><p>If you have used more Remsima than you should (either by injecting too much on a single occasion or by using it too frequently), talk to a doctor, pharmacist or nurse immediately. Always have the outer carton of the medicine with you, even if it is empty.</p><p><strong>If you forget to use Remsima</strong></p><p><em>Missed dose for up to 7 days</em></p><p>If you miss a dose of Remsima for up to 7 days, after the original scheduled dose, you should take the missed dose immediately. Take your next dose on the next originally planned date and then follow the original dosing schedule.</p><p><em>Missed dose for 8 days or more</em></p><p>If you miss a dose of Remsima for 8 days or more, after the original scheduled dose, you should not take the missed dose. Take your next dose on the next originally planned date and then follow the original dosing schedule. If you are not sure when to inject Remsima, call your doctor.</p><p>If you have any further questions on the use of this medicine, ask your doctor, pharmacist or nurse.</p></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Like all medicines, this medicine can cause side effects, although not everybody gets them. Most side effects are mild to moderate. However some patients may experience serious side effects and may require treatment. Side effects may also occur after your treatment with Remsima has stopped.</p><p><strong>Tell your doctor straight away if you notice any of the following:</strong></p><ul><li><strong>Signs of an allergic reaction</strong> such as swelling of your face, lips, mouth or throat which may cause difficulty in swallowing or breathing, skin rash, hives, swelling of the hands, feet or ankles. Some of these reactions may be serious or life-threatening. An allergic reaction could happen within 2 hours of your injection or later. More signs of allergic side effects that may happen up to 12 days after your injection include pain in the muscles, fever, joint or jaw pain, sore throat or headache.</li><li><strong>Signs of a local injection site</strong> reaction such as redness, pain, itching, swelling, hardness, bruising, bleeding, cold sensation, tingling sensation, irritation, rash, ulcer, hives, blisters and scab.</li><li>Signs of a heart problem such as chest discomfort or pain, arm pain, stomach pain, shortness of breath, anxiety, lightheadedness, dizziness, fainting, sweating, nausea (feeling sick), vomiting, fluttering or pounding in your chest, a fast or a slow heartbeat, and swelling of your feet.</li><li>Signs of infection (including TB) such as fever, feeling tired, cough which may be persistent, shortness of breath, flu-like symptoms, weight loss, night sweats, diarrhoea, wounds, collection of pus in the gut or around the anus (abscess), dental problems or burning sensation when urinating.</li><li>Possible signs of cancer including but not limited to swelling of lymph nodes, weight loss, fever, unusual skin nodules, changes in moles or skin colouring, or unusual vaginal bleeding.</li><li>Signs of a lung problem such as coughing, breathing difficulties or tightness in the chest.</li><li>Signs of a nervous system problem (including eye problems) such as signs of a stroke (sudden numbness or weakness of your face, arm or leg, especially on one side of your body; sudden confusion, trouble speaking or understanding; trouble seeing in one or both eyes, trouble walking, dizziness, loss of balance or coordination or a severe headache), fits, tingling/numbness in any part of your body, or weakness in arms or legs, changes in eyesight such as double vision or other eye problems.</li><li>Signs of a liver problem (including hepatitis B infection when you have had hepatitis B in the past) such as yellowing of the skin or eyes, dark-brown coloured urine, pain or swelling in the upper right side of the stomach area, joint pain, skin rashes, or fever.</li><li>Signs of an immune system disorder called lupus such as joint pain or a rash on cheeks or arms that is sensitive to the sun (lupus) or cough, shortness of breath, fever or skin rash (sarcoidosis).</li><li>Signs of low blood counts such as persistent fever, bleeding or bruising more easily, small red or purple spots caused by bleeding under the skin, or looking pale.</li><li>Signs of serious skin problems such as reddish-target-like spots or circular patches often with central blisters on the trunk, large areas of peeling and shedding (exfoliating) skin, ulcers of mouth, throat, nose, genitals and eyes or small pus-filled bumps that can spread over the body. These skin reactions can be accompanied by fever. Tell your doctor straight away if you notice any of the above. The following side effects have been observed with Remsima:</li></ul><p><strong>Very common:</strong> may affect more than 1 in 10 people</p><ul><li>Stomach pain, feeling sick Viral infections such as herpes or flu</li><li>Upper respiratory infections such as sinusitis</li><li>Headache</li><li>Side effect due to an injection</li><li>Pain.</li></ul><p><strong>Common:</strong> may affect up to 1 in 10 people</p><ul><li>Changes in how your liver works, increase in liver enzymes (shown in blood tests)</li><li>Lung or chest infections such as bronchitis or pneumonia</li><li>Difficult or painful breathing, chest pain</li><li>Bleeding in the stomach or intestines, diarrhoea, indigestion, heartburn, constipation</li><li>Nettle-type rash (hives), itchy rash or dry skin</li><li>Balance problems or feeling dizzy</li><li>Fever, increased sweating</li><li>Circulation problems such as low or high blood pressure</li><li>Bruising, hot flush or nosebleed, warm, red skin (flushing)</li><li>Feeling tired or weak</li><li>Bacterial infections such as blood poisoning, abscess or infection of the skin (cellulitis)</li><li>Infection of the skin due to a fungus</li><li>Blood problems such as anaemia or low white blood cell count</li><li>Swollen lymph nodes</li><li>Depression, problems sleeping</li><li>Eye problems, including red eyes and infections</li><li>Fast heart beat (tachycardia) or palpitations</li><li>Pain in the joints, muscles or back</li><li>Urinary tract infection</li><li>Psoriasis, skin problems such as eczema and hair loss</li><li>Reactions at the injection site such as pain, swelling, redness or itching</li><li>Chills, a build-up of fluid under the skin causing swelling</li><li>Feeling numb or having a tingling feeling.</li></ul><p><strong>Uncommon:</strong> may affect up to 1 in 100 people</p><ul><li>Shortage of blood supply, swelling of a vein</li><li>Collection of blood outside the blood vessels (haematoma) or bruising</li><li>Skin problems such as blistering, warts, abnormal skin colouration or pigmentation, or swollen lips, or thickening of the skin, or red, scaly, and flaky skin</li><li>Severe allergic reactions (e.g. anaphylaxis), an immune system disorder called lupus, allergic reactions to foreign proteins</li><li>Wounds taking longer to heal</li><li>Swelling of the liver (hepatitis) or gall bladder, liver damage</li><li>Feeling forgetful, irritable, confused, nervous</li><li>Eye problems including blurred or reduced vision, puffy eyes or sties</li><li>New or worsening heart failure, slow heart rate</li><li>Fainting</li><li>Convulsions, nerve problems</li><li>A hole in the bowel or blockage of the intestine, stomach pain or cramps</li><li>Swelling of your pancreas (pancreatitis)</li><li>Fungal infections such as yeast infection, or fungal infection of the nails</li><li>Lung problems (such as oedema)</li><li>Fluid around the lungs (pleural effusion)</li><li>Narrowed airway in the lungs, causing difficulty breathing</li><li>Inflamed lining of the lung, causing sharp chest pains that feel worse with breathing (pleurisy)</li><li>Tuberculosis</li><li>Kidney infections Low platelet count, too many white blood cells</li><li>Infections of the vagina</li><li>Blood test result showing ‘antibodies’ against your own body</li><li>Changes in cholesterol and fat levels in the blood.</li></ul><p><strong>Rare:</strong> may affect up to 1 in 1,000 people</p><ul><li>A type of blood cancer (lymphoma)</li><li>Your blood not supplying enough oxygen to your body, circulation problems such as narrowing of a blood vessel</li><li>Inflammation of the lining of the brain (meningitis)</li><li>Infections due to a weakened immune system</li><li>Hepatitis B infection when you have had hepatitis B in the past</li><li>Inflamed liver caused by a problem with the immune system (autoimmune hepatitis)</li><li>Liver problem that causes yellowing of the skin or eyes (jaundice)</li><li>Abnormal tissue swelling or growth</li><li>Severe allergic reaction that may cause loss of consciousness and could be life-threatening (anaphylactic shock)</li><li>Swelling of small blood vessels (vasculitis)</li><li>Immune disorders that could affect the lungs, skin and lymph nodes (such as sarcoidosis)</li><li>Collections of immune cells resulting from an inflammatory response (granulomatous lesions)</li><li>Lack of interest or emotion</li><li>Serious skin problems such as toxic epidermal necrolysis, Stevens-Johnson syndrome and acute generalised exanthematous pustulosis</li><li>Other skin problems such as erythema multiforme, blisters and peeling skin, or boils (furunculosis)</li><li>Serious nervous system disorders such as transverse myelitis, multiple sclerosis-like disease, optic neuritis and Guillain-Barré syndrome</li><li>Inflammation in the eye that may cause changes in the vision, including blindness</li><li>Fluid in the lining of the heart (pericardial effusion)</li><li>Serious lung problems (such as interstitial lung disease)</li><li>Melanoma (a type of skin cancer)</li><li>Cervical cancer</li><li>Low blood counts, including a severely decreased number of white blood cells</li><li>Small red or purple spots caused by bleeding under the skin</li><li>Abnormal values of a blood protein called ‘complement factor’ which is part of the immune system</li><li>Lichenoid reactions (itchy reddish-purple skin rash and/or threadlike white-grey lines on mucous membranes).</li></ul><p><strong>Not known:</strong> frequency cannot be estimated from the available data</p><ul><li>Cancer</li><li>A rare blood cancer affecting mostly young men (hepatosplenic T-cell lymphoma)</li><li>Liver failure</li><li>Merkel cell carcinoma (a type of skin cancer)</li><li>Kaposi’s sarcoma, a rare cancer related to infection with human herpes virus 8. Kaposi’s sarcoma most commonly appears as purple lesions on the skin.</li><li>Worsening of a condition called dermatomyositis (seen as a skin rash accompanying muscle weakness)</li><li>Heart attack</li><li>Stroke</li><li>Temporary loss of sight during or within 2 hours of infusion</li><li>Infection due to a live vaccine because of a weakened immune system.</li><li><strong>Reporting of side effects</strong></li></ul><p>If you get any side effects, talk to your doctor, pharmacist, or nurse. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the national reporting system listed in Appendix V. By reporting side effects you can help provide more information on the safety of this medicine.</p></div>"
          }
        },
        {
          "title" : "5. How to store Remsima 100 mg powder for concentrate for solution for infusion",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store Remsima 100 mg powder for concentrate for solution for infusion"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ul><li>Keep this medicine out of the sight and reach of children.</li><li>Do not use this medicine after the expiry date which is stated on the label and the carton after “EXP”. The expiry date refers to the last day of that month.</li><li>Store in a refrigerator (2°C - 8°C). Do not freeze. Keep the medicinal product in its outer carton to protect from light.</li><li>This medicine can also be stored in the original carton outside of refrigerated storage up to a maximum of 25°C for a single period of up to 28 days, but not beyond the original expiry date. In this situation, do not return to refrigerated storage again. Write the new expiry date on the carton including day/month/year. Discard this medicine if not used by the new expiry date or the expiry date printed on the carton, whichever is earlier.</li><li>Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.</li></ul></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>What Remsima contains</strong></p><ul><li>The active substance is infliximab. Each 1 ml single dose pre-filled syringe contains 120 mg of infliximab.</li><li>The other ingredients are acetic acid, sodium acetate trihydrate, sorbitol, polysorbate 80 and water for injections.</li></ul><p><strong>What Remsima looks like and contents of the pack</strong></p><p>Remsima is a clear to opalescent, colourless to pale brown solution which is supplied as a single use pre-filled syringe.</p><p>Each pack contains 1 pre-filled syringe with 2 alcohol pads, 2 pre-filled syringes with 2 alcohol pads, 4 pre-filled syringes with 4 alcohol pads or 6 pre-filled syringes with 6 alcohol pads.</p><p>Each pack contains 1 pre-filled syringe with automatic needle guard with 2 alcohol pads, 2 pre-filled syringes with automatic needle guard with 2 alcohol pads, 4 pre-filled syringes with automatic needle guard with 4 alcohol pads or 6 pre-filled syringes with automatic needle guard with 6 alcohol pads.</p><p>Not all pack sizes may be marketed</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-remsima-infliximab",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-remsima-infliximab",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-remsima-infliximab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-remsima-infliximab</b></p><a name=\"ingredient-for-remsima-infliximab\"> </a><a name=\"hcingredient-for-remsima-infliximab\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/B72HH48FLU (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#ManufacturedItemDefinition_mid-e3e5e78d4e002ed9e15b925cd546e20b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82718; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#AdministrableProductDefinition_ap-e3e5e78d4e002ed9e15b925cd546e20b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001; status = active; administrableDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 72072}\">active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta B72HH48FLU}\">INFLIXIMAB</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>100 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "B72HH48FLU"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e3e5e78d4e002ed9e15b925cd546e20b"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e3e5e78d4e002ed9e15b925cd546e20b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "72072",
          "display" : "active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "B72HH48FLU",
              "display" : "INFLIXIMAB"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 100,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-remsima-disodiumphosphatedihydrate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-remsima-disodiumphosphatedihydrate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-remsima-disodiumphosphatedihydrate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-remsima-disodiumphosphatedihydrate</b></p><a name=\"ingredient-for-remsima-disodiumphosphatedihydrate\"> </a><a name=\"hcingredient-for-remsima-disodiumphosphatedihydrate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/94255I6E2T (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#ManufacturedItemDefinition_mid-e3e5e78d4e002ed9e15b925cd546e20b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82718; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#AdministrableProductDefinition_ap-e3e5e78d4e002ed9e15b925cd546e20b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001; status = active; administrableDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 94255I6E2T}\">Disodium phosphate dihydrate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "94255I6E2T"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e3e5e78d4e002ed9e15b925cd546e20b"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e3e5e78d4e002ed9e15b925cd546e20b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "94255I6E2T",
              "display" : "Disodium phosphate dihydrate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-remsima-sodiumdihydrogenphosphatemonohydrate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-remsima-sodiumdihydrogenphosphatemonohydrate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-remsima-sodiumdihydrogenphosphatemonohydrate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-remsima-sodiumdihydrogenphosphatemonohydrate</b></p><a name=\"ingredient-for-remsima-sodiumdihydrogenphosphatemonohydrate\"> </a><a name=\"hcingredient-for-remsima-sodiumdihydrogenphosphatemonohydrate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/593YOG76RN (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#ManufacturedItemDefinition_mid-e3e5e78d4e002ed9e15b925cd546e20b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82718; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#AdministrableProductDefinition_ap-e3e5e78d4e002ed9e15b925cd546e20b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001; status = active; administrableDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 593YOG76RN}\">Sodium dihydrogen phosphate monohydrate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "593YOG76RN"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e3e5e78d4e002ed9e15b925cd546e20b"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e3e5e78d4e002ed9e15b925cd546e20b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "593YOG76RN",
              "display" : "Sodium dihydrogen phosphate monohydrate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-remsima-polysorbate80",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-remsima-polysorbate80",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-remsima-polysorbate80\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-remsima-polysorbate80</b></p><a name=\"ingredient-for-remsima-polysorbate80\"> </a><a name=\"hcingredient-for-remsima-polysorbate80\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/6OZP39ZG8H (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#ManufacturedItemDefinition_mid-e3e5e78d4e002ed9e15b925cd546e20b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82718; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#AdministrableProductDefinition_ap-e3e5e78d4e002ed9e15b925cd546e20b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001; status = active; administrableDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 6OZP39ZG8H}\">POLYSORBATE 80</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "6OZP39ZG8H"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e3e5e78d4e002ed9e15b925cd546e20b"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e3e5e78d4e002ed9e15b925cd546e20b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "6OZP39ZG8H",
              "display" : "POLYSORBATE 80"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-remsima-sucrose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-remsima-sucrose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-remsima-sucrose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-remsima-sucrose</b></p><a name=\"ingredient-for-remsima-sucrose\"> </a><a name=\"hcingredient-for-remsima-sucrose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/C151H8M554 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#ManufacturedItemDefinition_mid-e3e5e78d4e002ed9e15b925cd546e20b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82718; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#AdministrableProductDefinition_ap-e3e5e78d4e002ed9e15b925cd546e20b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001; status = active; administrableDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta C151H8M554}\">Sucrose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "C151H8M554"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e3e5e78d4e002ed9e15b925cd546e20b"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e3e5e78d4e002ed9e15b925cd546e20b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "C151H8M554",
              "display" : "Sucrose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-infliximab",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-infliximab",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-infliximab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-infliximab</b></p><a name=\"substance-infliximab\"> </a><a name=\"hcsubstance-infliximab\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/B72HH48FLU (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#Organization_mah-3c850a69e5187931f2198c5e63f933fe\">Organization Celltrion Healthcare Hungary Kft.</a></p><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C6458H9934N1728O2040S44</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>IMMUNOGLOBULIN G (HUMAN-MOUSE MONOCLONAL CA2 HEAVY CHAIN ANTI-HUMAN TUMOR NECROSIS FACTOR), DISULFIDE WITH HUMAN-MOUSE MONOCLONAL CA2 LIGHT CHAIN, DIMER</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "B72HH48FLU"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/mah-3c850a69e5187931f2198c5e63f933fe"
      }],
      "structure" : {
        "molecularFormula" : "C6458H9934N1728O2040S44"
      },
      "name" : [{
        "name" : "IMMUNOGLOBULIN G (HUMAN-MOUSE MONOCLONAL CA2 HEAVY CHAIN ANTI-HUMAN TUMOR NECROSIS FACTOR), DISULFIDE WITH HUMAN-MOUSE MONOCLONAL CA2 LIGHT CHAIN, DIMER",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-e3e5e78d4e002ed9e15b925cd546e20b",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-e3e5e78d4e002ed9e15b925cd546e20b",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-e3e5e78d4e002ed9e15b925cd546e20b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-e3e5e78d4e002ed9e15b925cd546e20b</b></p><a name=\"ap-e3e5e78d4e002ed9e15b925cd546e20b\"> </a><a name=\"hcap-e3e5e78d4e002ed9e15b925cd546e20b\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/13/853/001</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82718; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000074029}\">Powder for concentrate for solution for infusion</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002158}\">Vial</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#ManufacturedItemDefinition_mid-e3e5e78d4e002ed9e15b925cd546e20b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073611}\">Intravenous use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/13/853/001"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000074029",
          "display" : "Powder for concentrate for solution for infusion"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002158",
          "display" : "Vial"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-e3e5e78d4e002ed9e15b925cd546e20b"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073611",
            "display" : "Intravenous use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizatione3e5e78d4e002ed9e15b925cd546e20b0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizatione3e5e78d4e002ed9e15b925cd546e20b0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizatione3e5e78d4e002ed9e15b925cd546e20b0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizatione3e5e78d4e002ed9e15b925cd546e20b0</b></p><a name=\"authorizatione3e5e78d4e002ed9e15b925cd546e20b0\"> </a><a name=\"hcauthorizatione3e5e78d4e002ed9e15b925cd546e20b0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/13/853/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82718; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072062}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2018-06-21</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#Organization_mah-3c850a69e5187931f2198c5e63f933fe\">Organization Celltrion Healthcare Hungary Kft.</a></p><p><b>regulator</b>: <a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#Organization_mra-e3da03c458d6c0f3c5f1c39a2c6a1084\">Organization European Medicines Agency</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/13/853/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072062",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2018-06-21",
      "holder" : {
        "reference" : "Organization/mah-3c850a69e5187931f2198c5e63f933fe"
      },
      "regulator" : {
        "reference" : "Organization/mra-e3da03c458d6c0f3c5f1c39a2c6a1084"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-3c850a69e5187931f2198c5e63f933fe",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-3c850a69e5187931f2198c5e63f933fe",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-3c850a69e5187931f2198c5e63f933fe\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-3c850a69e5187931f2198c5e63f933fe</b></p><a name=\"mah-3c850a69e5187931f2198c5e63f933fe\"> </a><a name=\"hcmah-3c850a69e5187931f2198c5e63f933fe\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100000826 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034.0}\">Marketing authorisation holder</span></p><p><b>name</b>: Celltrion Healthcare Hungary Kft.</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Váci út 1-3. WestEnd Office Building B torony Budapest HU(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100000826"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034.0",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Celltrion Healthcare Hungary Kft.",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Váci út 1-3. WestEnd Office Building B torony Budapest HU",
          "line" : ["Váci út 1-3. WestEnd Office Building B torony"],
          "city" : "Budapest",
          "postalCode" : "1062",
          "country" : "HU"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mra-e3da03c458d6c0f3c5f1c39a2c6a1084",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mra-e3da03c458d6c0f3c5f1c39a2c6a1084",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mra-e3da03c458d6c0f3c5f1c39a2c6a1084\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mra-e3da03c458d6c0f3c5f1c39a2c6a1084</b></p><a name=\"mra-e3da03c458d6c0f3c5f1c39a2c6a1084\"> </a><a name=\"hcmra-e3da03c458d6c0f3c5f1c39a2c6a1084\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100013412 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi nan}\">Medicines Regulatory Authority</span></p><p><b>name</b>: European Medicines Agency</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100013412"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "nan",
          "display" : "Medicines Regulatory Authority"
        }]
      }],
      "name" : "European Medicines Agency",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL",
          "line" : ["Carretera De Martorell 41 61, Poligono Industrial Nord-Est"],
          "city" : "Amsterdam",
          "postalCode" : "1083 HS",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-515e8ffbb9f74e0d03d7ec46f9b79d8f",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-515e8ffbb9f74e0d03d7ec46f9b79d8f",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-515e8ffbb9f74e0d03d7ec46f9b79d8f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-515e8ffbb9f74e0d03d7ec46f9b79d8f</b></p><a name=\"ppd-515e8ffbb9f74e0d03d7ec46f9b79d8f\"> </a><a name=\"hcppd-515e8ffbb9f74e0d03d7ec46f9b79d8f\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/13/853/001 (use: official, )</p><p><b>name</b>: Remsima 100 mg powder for concentrate for solution for infusion 1</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Prodcut</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82718; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 1 {vial}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{vial} = '{vial}')</span></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-en-e3e5e78d4e002ed9e15b925cd546e20b.html#ManufacturedItemDefinition_mid-e3e5e78d4e002ed9e15b925cd546e20b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/13/853/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/13/853/001"
      }],
      "name" : "Remsima 100 mg powder for concentrate for solution for infusion 1",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Prodcut"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 1,
        "system" : "http://unitsofmeasure.org",
        "code" : "{vial}"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 1,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003529",
              "display" : "Cardboard"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-e3e5e78d4e002ed9e15b925cd546e20b"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mpbe76bdf784deea6950583b234f789db2",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mpbe76bdf784deea6950583b234f789db2",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mpbe76bdf784deea6950583b234f789db2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mpbe76bdf784deea6950583b234f789db2</b></p><a name=\"mpbe76bdf784deea6950583b234f789db2\"> </a><a name=\"hcmpbe76bdf784deea6950583b234f789db2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/13/853/001, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E82718</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Remsima 100 mg powder for concentrate for solution for infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Remsima</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Infliximab</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 100 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: powder for concentrate for solution for infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/13/853/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E82718"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Remsima 100 mg powder for concentrate for solution for infusion",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Remsima",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "Infliximab",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "100 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "powder for concentrate for solution for infusion",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-e3e5e78d4e002ed9e15b925cd546e20b",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-e3e5e78d4e002ed9e15b925cd546e20b",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-e3e5e78d4e002ed9e15b925cd546e20b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-e3e5e78d4e002ed9e15b925cd546e20b</b></p><a name=\"mid-e3e5e78d4e002ed9e15b925cd546e20b\"> </a><a name=\"hcmid-e3e5e78d4e002ed9e15b925cd546e20b\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/13/853/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000074029}\">Powder for concentrate for solution for infusion</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002158}\">Vial</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/13/853/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000074029",
          "display" : "Powder for concentrate for solution for infusion"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002158",
          "display" : "Vial"
        }]
      }
    }
  }]
}

```
