# FK39664 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK39664**

## Example Bundle: FK39664

**Composition category:**

**Composition status:**final

### Indlægsseddel: Information til patienten

 

## Indlægsseddel: Information til brugeren

### Prednisolon DAK tabletter 2,5 mg, 5 mg og 25 mg

prednisolon

### Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger.

* Gem indlægssedlen. Du kan få brug for at læse den igen.
* Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide.
* Lægen har ordineret Prednisolon DAK til dig personligt. Lad derfor være med at give det til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.
* Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt her. Se [afsnit 4](#Section4).

Se den nyeste indlægsseddel på
[www.indlaegsseddel.dk](https://www.indlaegsseddel.dk).

### Oversigt over indlægssedlen

1. Virkning og anvendelse
1. Det skal du vide, før du begynder at tage Prednisolon DAK
1. Sådan skal du tage Prednisolon DAK
1. Bivirkninger
1. Opbevaring
1. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

 

## 1. Virkning og anvendelse

Prednisolon er et binyrebarkhormon (glukokortikoid). Prednisolon påvirker immunforsvaret, betændelsestilstande og allergiske sygdomme.

Prednisolon DAK tabletter (herefter kaldet Prednisolon) bruges i en lang række tilfælde, hvor binyrebarkhormon virker, f.eks. ved leddegigt, visse blodsygdomme og betændelse i selve blodårerne, andre bindevævssygdomme, astma, overfølsomhedssygdomme, visse nyresygdomme, sygdomme i mave-tarmkanalen, visse kræftsygdomme, sygdomme i immunforsvaret og efter transplantationer.


#### 2. Det skal du vide, før du begynder at tage Prednisolon DAK

 

 

## 2. Det skal du vide, før du begynder at tage Prednisolon DAK

Lægen kan have foreskrevet anden anvendelse eller dosering end angivet i denne information. Følg altid lægens anvisning og oplysningerne på doseringsetiketten.

### Tag ikke Prednisolon, hvis du

* er allergisk over for prednisolon eller et af de øvrige indholdsstoffer (angivet i [afsnit 6](#Section6))
* har en udbredt svampeinfektion, bortset fra lokale svampeinfektioner f.eks. i huden eller i mundhulen
* skal vaccineres, tal med din læge.

### Advarsler og forsigtighedsregler

Kontakt lægen før du tager Prednisolon, hvis du har:

* sukkersyge, da du kan få øget behov for insulin eller anden medicinsk behandling
* for lavt stofskifte
* skrumpelever
* virusinfektion i øjet (*herpes simplex*)
* mavesår, alvorlig tarmsygdom med tendens til blødning eller betændelse i tyktarmen
* en nyligt overstået tarmoperation
* en infektion
* tuberkulose eller hvis du har haft tuberkulose
* forhøjet blodtryk
* nedsat hjertefunktion
* knogleskørhed
* ekstrem muskeltræthed (myasthenia gravis)
* lymfekræft (lymfoide tumorer)
* humørsvingninger eller psykotiske tendenser, idet disse kan forværres
* sklerodermi (også kendt som systemisk sklerose, en autoimmun sygdom), da daglige doser på 15 mg eller derover kan øge risikoen for en alvorlig komplikation kaldet sklerodermisk nyrekrise. Tegn på sklerodermisk nyrekrise omfatter forhøjet blodtryk og nedsat urinproduktion. Lægen kan råde dig til at få dit blodtryk og din urin kontrolleret regelmæssigt.

 

Du skal være opmærksom på følgende:

* Kontakt lægen hvis du får problemer med synet og du f.eks. oplever sløret syn eller andre synsforstyrrelser (specielt hos børn). Ved længerevarende behandling kan der opstå grå stær (især hos børn) og grøn stær (forhøjet tryk i øjet) med risiko for skade på synsnerven samt risiko for infektion med svamp eller virus i øjet. Lægen vil evt. kontrollere dit syn, hvis du behandles gennem længere tid .
* Fortæl altid lægen at du er i behandling med prednisolon, hvis du skal vaccineres. Det kan være, at du skal holde pause med prednisolon-behandlingen.
* Nogle lægemidler kan øge virkningen af prednisolon, og din læge vil overvåge dig omhyggeligt, hvis du tager sådanne lægemidler (inklusive visse former for HIV medicin, herunder ritonavir og cobistat).
* Du skal undgå at blive smittet med skoldkopper eller mæslinger så længe du behandles med prednisolon. Hvis du alligevel udsættes for smitte, skal du kontakte lægen. Dette er særlig vigtigt ved behandling af børn.
* Længerevarende behandling med prednisolon kan nedsætte udviklingen og væksten hos nyfødte og børn.
* Prednisolon kan nedsætte frugtbarheden hos mænd.
* Kontakt lægen, hvis du får en infektion. Prednisolon kan skjule tegn på infektion, og infektionen kan blive værre. Du kan endvidere lettere få en infektion under behandlingen, fordi kroppens naturlige modstandskraft er nedsat.
* Lægen kan anbefale en saltfattig og kaliumrig diæt, da prednisolon kan påvirke din salt- og kaliumbalance.
* Behandling med prednisolon kan have en negativ virkning på den måde, kalcium omsættes i dine knogler. Derfor skal du afklare risikoen for knogleskørhed (knogletab og -brud) med din læge, specielt hvis du har familiemedlemmer der tidligere har haft knoglebrud, hvis du ikke dyrker motion regelmæssigt, hvis du er kvinde i overgangsalderen eller har overstået overgangsalderen, eller hvis du er ældre.

 

Oplys altid at du er i behandling med prednisolon, hvis du skal opereres.

Hvis du skal behandles med prednisolon i længere tid, bør du bære et kort, som fortæller, hvornår behandlingen begyndte, hvilken dosis du tager, hvilket lægemiddel du er i behandling med samt navnet på den læge eller afdeling, som har ordineret behandlingen. Dette kort skal sikre, at du får tilført glukokortikoider, hvis du bliver indlagt eller kommer ud for en alvorlig ulykke, og du ikke selv er i stand til at oplyse, at du er i denne behandling.

Du skal have kortet på dig op til 1 år efter afsluttet behandling.

Oplys altid ved blod- og urinprøvekontrol at du er i behandling med prednisolon. Prednisolon står på dopinglisten og kan medføre udelukkelse ved sportsstævner.

Prednisolon kan påvirke blodsukkermålinger.

### Brug af anden medicin sammen med Prednisolon DAK

Fortæl det altid lægen eller apotekspersonalet, hvis du bruger anden medicin eller har gjort det for nylig. Dette gælder også medicin, som ikke er købt på recept. Det kan være nødvendigt at justere dosis eller skifte til anden behandling.

Fortæl din læge, hvis du tager:

* medicin, der bruges i forbindelse med organtransplantation (ciclosporin)
* medicin mod epilepsi og kramper (carbamazepin, phenytoin, phenobarbital)
* medicin mod tuberkulose (rifampicin)
* blodfortyndende lægemidler, som hæmmer blodets evne til at størkne (warfarin)
* smertestillende lægemidler (acetylsalicylsyre og NSAID)
* p-piller
* visse typer af vanddrivende medicin (ikke-kaliumbesparende)
* hjertemedicin (digoxin)
* medicin mod svampeinfektion (amphotericin B)
* medicin mod infektion (fluoroquinoloner)
* medicin mod sukkersyge
* celledræbende medicin (mod kræft) og medicin mod visse gigtlidelser (methotrexat)
* muskelafslappende medicin
* medicin mod psykiske lidelser (quetiapin)
* visse typer af HIV medicin (herunder ritonavir, cobistat)
* skal vaccineres
* lakrids (for eksempel i hostesaft).

### Brug af Prednisolon sammen med mad og drikke

Du kan tage Prednisolon i forbindelse med et måltid, men det er ikke nødvendigt. Tag tabletten med rigelig væske.

### Graviditet, amning og frugtbarhed

Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge eller apotekspersonalet til råds, før tager dette lægemiddel.

 

**Graviditet**

Hvis du er gravid, skal du normalt ikke tage Prednisolon, Tal med lægen.

Langtidsbehandling med prednisolon har medført let nedsat fødselsvægt. Sent i graviditeten er brug af prednisolon forbundet med risiko for bivirkninger som øget risiko for infektioner og nedsat binyrebarkfunktion hos fostre.

 

**Amning**

Du kan tage Prednisolon, selv om du ammer. Følg lægens anvisning.

Da Prednisolon udskilles i modermælken, er det ved længerevarende behandling vigtigt, at sundhedsplejersken/lægen nøje følger dit barns vækst og binyrebarkfunktion.

Du kan mindske mængden af prednisolon, der overføres til dit barn under amning ved at udsætte amningen til 3 - 4 timer efter, at du har taget din prednisolon-dosis.

 

**Frugtbarhed**

Nogle kvinder kan opleve uregelmæssig eller udeblivende menstruation.

Enkelte mænd kan få nedsat fertilitet under behandlingen.

### Trafik- og arbejdssikkerhed

Prednisolon påvirker ikke arbejdssikkerheden og evnen til at færdes sikkert i trafikken.

### Prednisolon indeholder lactose

Kontakt lægen før du tager dette lægemiddel, hvis lægen har fortalt dig, at du ikke tåler visse sukkerarter.


#### 3. Sådan skal du tage Prednisolon DAK

 

 

## 3. Sådan skal du tage Prednisolon DAK

Tag altid Prednisolon nøjagtigt efter lægens anvisning. Er du i tvivl, så spørg lægen eller apotekspersonalet.

 

Tag tabletten med rigelig væske. Tabletten kan deles eller knuses.

### Den sædvanlige dosis er

Prednisolon er doseret specielt til dig, og er afhængig af din sygdom.

### Brug til børn

Lægen bestemmer doseringen til dit barn ud fra barnets kropsvægt. Følg lægen anvisninger og oplysningerne på doseringsetiketten. Kontakt lægen, hvis du er i tvivl, om dit barn får den rette dosis.

### Hvis du har taget for mange Prednisolon

Kontakt lægen, skadestuen eller apotekspersonalet, hvis du har taget flere Prednisolon, end der står her, eller flere end lægen har foreskrevet, og du føler dig utilpas. Tag pakningen med.

 

Akut overdosering med prednisolon medfører ingen kendte symptomer. Hyppig dosering over en længere periode kan fremkalde Cushings syndrom (måneansigt og øget fedtmængde på mave og nakke). Dette forsvinder efter afsluttet behandling.

### Hvis du har glemt at tage Prednisolon

Har du glemt en dosis Prednisolon, så tag den så snart du kommer i tanke om det. Hvis du snart skal tage den næste dosis, så spring den glemte dosis over.

Du må ikke tage en dobbeltdosis som erstatning for den glemte dosis.

### Hvis du holder op med at tage Prednisolon

Du må kun ændre dosis eller stoppe behandlingen efter aftale med lægen. Skal du have en mindre dosis, skal nedtrapning ske langsomt. Hvis behandlingen pludseligt ophører eller din dosis bliver sat stærkt ned, kan du få en række ubehagelige symptomer som feber, led- og muskelsmerter og dårlig almentilstand. Den sygdom, du fik Prednisolon for, kan blusse voldsomt op.

 

Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.


#### 4. Bivirkninger

 

 

## 4. Bivirkninger

Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger.

 

Bivirkningerne afhænger af dosis og behandlingens varighed. De fleste bivirkninger forsvinder, når behandlingen ophører og bliver sædvanligvis mindre udtalte, hvis dosis bliver mindre.

 

Ring 112 eller søg omgående læge ved tegn på alvorlige bivirkninger.

 

**Meget almindelige bivirkninger**(forekommer hos flere end 1 ud af 10 behandlede):

**Alvorlige:**Forhøjet tryk i øjnene, som kan give hovedpine, kvalme og regnbuesyn, lungebyld hos personer med lungekræft, væksthæmning hos børn. Efter længerevarende behandling øges risikoen for knoglebrud pga. knogleskørhed med symptomer såsom rygsmerte, nedsat bevægelighed og akut smerte.

**Ikke alvorlige:**Øget risiko for infektioner, sløring eller forværring af eksisterende infektionssygdomme, tegn på nedsat binyrebarkfunktion (hovedpine, kvalme, svimmelhed, anoreksi, svaghed, følelsesmæssige forandringer, apati, uhensigtsmæssige reaktioner på stress), knogleskørhed ved længerevarende behandling (kan blive alvorlig), muskelsvaghed (ved høje doser), grå stær (uklart syn) ved længerevarende behandling, sukkersyge, øget sukkerindhold i blodet (hos personer med sukkersyge), nedsat vækst hos børn.

 

**Almindelige bivirkninger**(forekommer hos 1 - 10 ud af 100 behandlede):

**Alvorlige: **Forværring af eksisterende nedsat hjertefunktion, psykose, øget risiko for tuberkulose.

**Ikke alvorlige: **Påvirkninger i huden i form af røde streger, pletter, karsprængninger, sår, udslæt på kroppen og i ansigtet, Cushings syndrom (måneansigt og øget fedtmængde på kroppen), for lavt kalium i blodet, som viser sig ved svaghed, nedsat muskelkraft og forstyrrelser i hjerterytmen (kan blive alvorligt), manglende menstruation hos fertile kvinder, nedsat udskillelse af salt og væskeophobning i kroppen, opstemthed, depression, forhøjet blodtryk, forværrede symptomer ved tarmbetændelse, øget svedtendens, natlig vandladning, nedsat sårheling, trøske, mund- eller hudsvamp, vægtøgning, øget appetit.

 

**Ikke almindelige bivirkninger **(forekommer hos 1 - 10 ud af 1.000 behandlede):

**Alvorlige: **Mavesår og blødning fra mave-tarmkanalen eller hul på tarmen, forandring af knoglemassen, åndedrætsbesvær på grund af svækket åndedrætsmuskulatur, Tørst, træthed, øget vandladning pga. sukkersyge. Øget sukker (glukose) i blodet (både hos diabetikere og ikke-diabetikere), muskelsvaghed med påvirkning af åndedrætsmusklerne, Mørkerød urin, kraftige mavesmerter, psykiske forstyrrelser som f.eks. angst.

**Ikke alvorlige:**Allergiske reaktioner, sukkersyge (lave doser), søvnløshed, humørsvingninger, ændringer i personlighed, mani, hallucinationer, urinsten.

 

**Sjældne bivirkninger**(forekommer hos 1 - 10 ud af 10.000 behandlede):

**Alvorlige:**Øget risiko for blodpropper.

**Ikke alvorlige:**Hukommelsessvigt, dannelse af fedtvæv i rygsøjlen, forstyrrelser i stofskiftet, grøn stær efter længerevarende behandling, nedsat reaktion på hudtest, sprængte sener.

 

**Meget sjældne bivirkninger**(forekommer hos færre end 1 ud af 10.000 behandlede):

**Alvorlige: **For højt blodsukker med sløret bevidsthed eller bevidstløshed, anfald hos personer med ikke kendt epilepsi, forhøjet tryk i hjernen (især hos børn), sygdom i hjertemuskulaturen med åndenød, trykken for brystet og tendens til væske i kroppen, betændelse i bugspytkirtlen med voldsomme mavesmerter og feber efter længerevarende og højdosis behandling, alvorlig hudlidelse med blæreformet udslæt og betændelse i huden, især på hænder og fødder samt i og omkring munden ledsaget af feber (Stevens-Johnson syndrom), tumorlysesyndrom (ved kræftsygdom), reaktionsløs/stiv tilstand i kroppen (katatonisk stupor), Besvimelse med svag puls, bleghed, blåfarvning af læber og negle.

**Ikke alvorlige:**Øjenforandringer, betændelse i sener (akillessene og knæskal), udstående øjne (langvarig behandling), forhøjet produktion af biskjoldbruskkirtelhormoner (hyperparathyroidisme), anfald af porfyri (sjælden arvelig stofskiftesygdom), halsbrand og forværring af eksisterende mavesår.

 

**Bivirkninger, hvor hyppigheden ikke er kendt**

**Alvorlige: **Åndenød, angst, brystsmerter med udstråling til hals eller arme pga. blodprop i hjertet. Sklerodermisk nyrekrise hos patienter, som allerede lider af sklerodermi (en autoimmun sygdom). Tegn på sklerodermisk nyrekrise omfatter forhøjet blodtryk og nedsat urinproduktion.

**Ikke alvorlige: **Sløret syn.

 

Prednisolon kan herudover give bivirkninger, som du normalt ikke mærker noget til. Det drejer sig om ændringer i visse laboratorieprøver, f.eks. forandringer i mængden af hvide blodlegemer og blodplader, for lavt kalium i blodet og forhøjet kolesterol, triglycerid og lipoprotein. Det kan hos enkelte udvikle sig til en alvorlig bivirkning. Tal med lægen.

### Indberetning af bivirkninger

Hvis du oplever bivirkninger, bør du tale med din læge, sygeplejerske eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til:

Lægemiddelstyrelsen, Axel Heides Gade 1, DK-2300 København S,

Websted: www.meldenbivirkning.dk.

Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.

[Meld en bivirkning.](https://www.meldenbivirkning.dk)


#### 5. Opbevaring

 

 

## 5. Opbevaring

Prednisolon skal opbevares utilgængeligt for børn.

 

Brug ikke medicinen efter den udløbsdato, der står på pakningen.

 

Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

 

## 6. Pakningsstørrelser og yderligere oplysninger

### Prednisolon DAK tabletter 2,5 mg, 5 mg og 25 mg indeholder

Det virksomme indholdsstof er prednisolon. De øvrige indholdsstoffer er gelatine, kartoffelstivelse, lactosemonohydrat, magnesiumstearat (E 470b) og talcum (E 553b). Prednisolon DAK 2,5 mg indeholder desuden farvestoffet indigotin I (E 132).

### Udseende og pakningsstørrelser

Prednisolon DAK 2,5 mg er en lyseblå tablet med delekærv på den ene side.

Prednisolon DAK 5 mg og 25 mg er hvide tabletter med delekærv på den ene side.

 

Prednisolon DAK 2,5 mg findes i pakningsstørrelser à 100 stk.

Prednisolon DAK 5 mg findes i pakningsstørrelser à 25 og 100 stk.

Prednisolon DAK 25 mg findes i pakningsstørrelser à 10 og 100 stk.

Ikke alle pakningsstørrelser er nødvendigvis markedsført.


####  

-------

Full name: ****

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK39664",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
    "value" : "39664"
  },
  "type" : "document",
  "timestamp" : "2022-01-29T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK39664-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK39664-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_FK39664-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK39664-COMP</b></p><a name=\"FK39664-COMP\"> </a><a name=\"hcFK39664-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/</code>/39664</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2022-01-29</p><p><b>author</b>: Identifier: <code>https://medicin.dk</code>/medicin.dk</p><p><b>title</b>: Prednisolon &quot;DAK&quot; 5 mg og 25 mg tabletter</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
        "value" : "39664"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "date" : "2022-01-29",
      "author" : [{
        "identifier" : {
          "system" : "https://medicin.dk",
          "value" : "medicin.dk"
        }
      }],
      "title" : "Prednisolon \"DAK\" 5 mg og 25 mg tabletter",
      "section" : [{
        "title" : "Indlægsseddel: Information til patienten",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section0\"/><h2>Indlægsseddel: Information til brugeren</h2><h3>Prednisolon DAK tabletter 2,5 mg, 5 mg og 25 mg</h3><div class=\"paragraph\">prednisolon</div><h3>Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger.</h3><ul><li>Gem indlægssedlen. Du kan få brug for at læse den igen.</li><li>Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide.</li><li>Lægen har ordineret Prednisolon DAK til dig personligt. Lad derfor være med at give det til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.</li><li>Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt her. Se <a href=\"#Section4\" title=\"Anchor link til afsnit - afsnit 4\">afsnit 4</a>.</li></ul><div class=\"paragraph\">Se den nyeste indlægsseddel på <a href=\"https://www.indlaegsseddel.dk\" title=\"null\">www.indlaegsseddel.dk</a>.</div><h3>Oversigt over indlægssedlen</h3><ol><li>Virkning og anvendelse</li><li>Det skal du vide, før du begynder at tage Prednisolon DAK</li><li>Sådan skal du tage Prednisolon DAK</li><li>Bivirkninger</li><li>Opbevaring</li><li>Pakningsstørrelser og yderligere oplysninger</li></ol></div>"
        },
        "section" : [{
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section1\"/><div> </div><h2>1. Virkning og anvendelse</h2><div class=\"paragraph\">Prednisolon er et binyrebarkhormon (glukokortikoid). Prednisolon påvirker immunforsvaret, betændelsestilstande og allergiske sygdomme.<br/><br/>Prednisolon DAK tabletter (herefter kaldet Prednisolon) bruges i en lang række tilfælde, hvor binyrebarkhormon virker, f.eks. ved leddegigt, visse blodsygdomme og betændelse i selve blodårerne, andre bindevævssygdomme, astma, overfølsomhedssygdomme, visse nyresygdomme, sygdomme i mave-tarmkanalen, visse kræftsygdomme, sygdomme i immunforsvaret og efter transplantationer.</div></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du begynder at tage Prednisolon DAK",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section2\"/><div> </div><h2>2. Det skal du vide, før du begynder at tage Prednisolon DAK</h2><div class=\"paragraph\">Lægen kan have foreskrevet anden anvendelse eller dosering end angivet i denne information. Følg altid lægens anvisning og oplysningerne på doseringsetiketten.</div><h3>Tag ikke Prednisolon, hvis du</h3><ul><li>er allergisk over for prednisolon eller et af de øvrige indholdsstoffer (angivet i <a href=\"#Section6\" title=\"Anchor link til afsnit - afsnit 6\">afsnit 6</a>)</li><li>har en udbredt svampeinfektion, bortset fra lokale svampeinfektioner f.eks. i huden eller i mundhulen</li><li>skal vaccineres, tal med din læge.</li></ul><h3>Advarsler og forsigtighedsregler</h3><div class=\"paragraph\">Kontakt lægen før du tager Prednisolon, hvis du har:</div><ul><li>sukkersyge, da du kan få øget behov for insulin eller anden medicinsk behandling</li><li>for lavt stofskifte</li><li>skrumpelever</li><li>virusinfektion i øjet (<i>herpes simplex</i>)</li><li>mavesår, alvorlig tarmsygdom med tendens til blødning eller betændelse i tyktarmen</li><li>en nyligt overstået tarmoperation</li><li>en infektion</li><li>tuberkulose eller hvis du har haft tuberkulose</li><li>forhøjet blodtryk</li><li>nedsat hjertefunktion</li><li>knogleskørhed</li><li>ekstrem muskeltræthed (myasthenia gravis)</li><li>lymfekræft (lymfoide tumorer)</li><li>humørsvingninger eller psykotiske tendenser, idet disse kan forværres</li><li>sklerodermi (også kendt som systemisk sklerose, en autoimmun sygdom), da daglige doser på 15 mg eller derover kan øge risikoen for en alvorlig komplikation kaldet sklerodermisk nyrekrise. Tegn på sklerodermisk nyrekrise omfatter forhøjet blodtryk og nedsat urinproduktion. Lægen kan råde dig til at få dit blodtryk og din urin kontrolleret regelmæssigt.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Du skal være opmærksom på følgende:</div><ul><li>Kontakt lægen hvis du får problemer med synet og du f.eks. oplever sløret syn eller andre synsforstyrrelser (specielt hos børn). Ved længerevarende behandling kan der opstå grå stær (især hos børn) og grøn stær (forhøjet tryk i øjet) med risiko for skade på synsnerven samt risiko for infektion med svamp eller virus i øjet. Lægen vil evt. kontrollere dit syn, hvis du behandles gennem længere tid .</li><li>Fortæl altid lægen at du er i behandling med prednisolon, hvis du skal vaccineres. Det kan være, at du skal holde pause med prednisolon-behandlingen.</li><li>Nogle lægemidler kan øge virkningen af prednisolon, og din læge vil overvåge dig omhyggeligt, hvis du tager sådanne lægemidler (inklusive visse former for HIV medicin, herunder ritonavir og cobistat).</li><li>Du skal undgå at blive smittet med skoldkopper eller mæslinger så længe du behandles med prednisolon. Hvis du alligevel udsættes for smitte, skal du kontakte lægen. Dette er særlig vigtigt ved behandling af børn.</li><li>Længerevarende behandling med prednisolon kan nedsætte udviklingen og væksten hos nyfødte og børn.</li><li>Prednisolon kan nedsætte frugtbarheden hos mænd.</li><li>Kontakt lægen, hvis du får en infektion. Prednisolon kan skjule tegn på infektion, og infektionen kan blive værre. Du kan endvidere lettere få en infektion under behandlingen, fordi kroppens naturlige modstandskraft er nedsat.</li><li>Lægen kan anbefale en saltfattig og kaliumrig diæt, da prednisolon kan påvirke din salt- og kaliumbalance.</li><li>Behandling med prednisolon kan have en negativ virkning på den måde, kalcium omsættes i dine knogler. Derfor skal du afklare risikoen for knogleskørhed (knogletab og -brud) med din læge, specielt hvis du har familiemedlemmer der tidligere har haft knoglebrud, hvis du ikke dyrker motion regelmæssigt, hvis du er kvinde i overgangsalderen eller har overstået overgangsalderen, eller hvis du er ældre.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Oplys altid at du er i behandling med prednisolon, hvis du skal opereres.</div><div class=\"paragraph\"><br/>Hvis du skal behandles med prednisolon i længere tid, bør du bære et kort, som fortæller, hvornår behandlingen begyndte, hvilken dosis du tager, hvilket lægemiddel du er i behandling med samt navnet på den læge eller afdeling, som har ordineret behandlingen. Dette kort skal sikre, at du får tilført glukokortikoider, hvis du bliver indlagt eller kommer ud for en alvorlig ulykke, og du ikke selv er i stand til at oplyse, at du er i denne behandling.<br/>Du skal have kortet på dig op til 1 år efter afsluttet behandling.</div><div class=\"paragraph\"><br/>Oplys altid ved blod- og urinprøvekontrol at du er i behandling med prednisolon. Prednisolon står på dopinglisten og kan medføre udelukkelse ved sportsstævner.</div><div class=\"paragraph\"><br/>Prednisolon kan påvirke blodsukkermålinger.</div><h3>Brug af anden medicin sammen med Prednisolon DAK</h3><div class=\"paragraph\">Fortæl det altid lægen eller apotekspersonalet, hvis du bruger anden medicin eller har gjort det for nylig. Dette gælder også medicin, som ikke er købt på recept. Det kan være nødvendigt at justere dosis eller skifte til anden behandling.</div><div class=\"paragraph\"><br/>Fortæl din læge, hvis du tager:</div><ul><li>medicin, der bruges i forbindelse med organtransplantation (ciclosporin)</li><li>medicin mod epilepsi og kramper (carbamazepin, phenytoin, phenobarbital)</li><li>medicin mod tuberkulose (rifampicin)</li><li>blodfortyndende lægemidler, som hæmmer blodets evne til at størkne (warfarin)</li><li>smertestillende lægemidler (acetylsalicylsyre og NSAID)</li><li>p-piller</li><li>visse typer af vanddrivende medicin (ikke-kaliumbesparende)</li><li>hjertemedicin (digoxin)</li><li>medicin mod svampeinfektion (amphotericin B)</li><li>medicin mod infektion (fluoroquinoloner)</li><li>medicin mod sukkersyge</li><li>celledræbende medicin (mod kræft) og medicin mod visse gigtlidelser (methotrexat)</li><li>muskelafslappende medicin</li><li>medicin mod psykiske lidelser (quetiapin)</li><li>visse typer af HIV medicin (herunder ritonavir, cobistat)</li><li>skal vaccineres</li><li>lakrids (for eksempel i hostesaft).</li></ul><h3>Brug af Prednisolon sammen med mad og drikke</h3><div class=\"paragraph\">Du kan tage Prednisolon i forbindelse med et måltid, men det er ikke nødvendigt. Tag tabletten med rigelig væske.</div><h3>Graviditet, amning og frugtbarhed</h3><div class=\"paragraph\">Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge eller apotekspersonalet til råds, før tager dette lægemiddel.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Graviditet</b></div><div class=\"paragraph\">Hvis du er gravid, skal du normalt ikke tage Prednisolon, Tal med lægen.</div><div class=\"paragraph\">Langtidsbehandling med prednisolon har medført let nedsat fødselsvægt. Sent i graviditeten er brug af prednisolon forbundet med risiko for bivirkninger som øget risiko for infektioner og nedsat binyrebarkfunktion hos fostre.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Amning</b></div><div class=\"paragraph\">Du kan tage Prednisolon, selv om du ammer. Følg lægens anvisning.</div><div class=\"paragraph\">Da Prednisolon udskilles i modermælken, er det ved længerevarende behandling vigtigt, at sundhedsplejersken/lægen nøje følger dit barns vækst og binyrebarkfunktion.</div><div class=\"paragraph\">Du kan mindske mængden af prednisolon, der overføres til dit barn under amning ved at udsætte amningen til 3 - 4 timer efter, at du har taget din prednisolon-dosis.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Frugtbarhed</b></div><div class=\"paragraph\">Nogle kvinder kan opleve uregelmæssig eller udeblivende menstruation.<br/>Enkelte mænd kan få nedsat fertilitet under behandlingen.</div><h3>Trafik- og arbejdssikkerhed</h3><div class=\"paragraph\">Prednisolon påvirker ikke arbejdssikkerheden og evnen til at færdes sikkert i trafikken.</div><h3>Prednisolon indeholder lactose</h3><div class=\"paragraph\">Kontakt lægen før du tager dette lægemiddel, hvis lægen har fortalt dig, at du ikke tåler visse sukkerarter.</div></div>"
          }
        },
        {
          "title" : "3. Sådan skal du tage Prednisolon DAK",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section3\"/><div> </div><h2>3. Sådan skal du tage Prednisolon DAK</h2><div class=\"paragraph\">Tag altid Prednisolon nøjagtigt efter lægens anvisning. Er du i tvivl, så spørg lægen eller apotekspersonalet.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Tag tabletten med rigelig væske. Tabletten kan deles eller knuses.</div><h3>Den sædvanlige dosis er</h3><div class=\"paragraph\">Prednisolon er doseret specielt til dig, og er afhængig af din sygdom.</div><h3>Brug til børn</h3><div class=\"paragraph\">Lægen bestemmer doseringen til dit barn ud fra barnets kropsvægt. Følg lægen anvisninger og oplysningerne på doseringsetiketten. Kontakt lægen, hvis du er i tvivl, om dit barn får den rette dosis.</div><h3>Hvis du har taget for mange Prednisolon</h3><div class=\"paragraph\">Kontakt lægen, skadestuen eller apotekspersonalet, hvis du har taget flere Prednisolon, end der står her, eller flere end lægen har foreskrevet, og du føler dig utilpas. Tag pakningen med.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Akut overdosering med prednisolon medfører ingen kendte symptomer. Hyppig dosering over en længere periode kan fremkalde Cushings syndrom (måneansigt og øget fedtmængde på mave og nakke). Dette forsvinder efter afsluttet behandling.</div><h3>Hvis du har glemt at tage Prednisolon</h3><div class=\"paragraph\">Har du glemt en dosis Prednisolon, så tag den så snart du kommer i tanke om det. Hvis du snart skal tage den næste dosis, så spring den glemte dosis over.</div><div class=\"paragraph\">Du må ikke tage en dobbeltdosis som erstatning for den glemte dosis.</div><h3>Hvis du holder op med at tage Prednisolon</h3><div class=\"paragraph\">Du må kun ændre dosis eller stoppe behandlingen efter aftale med lægen. Skal du have en mindre dosis, skal nedtrapning ske langsomt. Hvis behandlingen pludseligt ophører eller din dosis bliver sat stærkt ned, kan du få en række ubehagelige symptomer som feber, led- og muskelsmerter og dårlig almentilstand. Den sygdom, du fik Prednisolon for, kan blusse voldsomt op.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.</div></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section4\"/><div> </div><h2>4. Bivirkninger</h2><div class=\"paragraph\">Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Bivirkningerne afhænger af dosis og behandlingens varighed. De fleste bivirkninger forsvinder, når behandlingen ophører og bliver sædvanligvis mindre udtalte, hvis dosis bliver mindre.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Ring 112 eller søg omgående læge ved tegn på alvorlige bivirkninger.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Meget almindelige bivirkninger</b> (forekommer hos flere end 1 ud af 10 behandlede):</div><div class=\"paragraph\"><b>Alvorlige:</b> Forhøjet tryk i øjnene, som kan give hovedpine, kvalme og regnbuesyn, lungebyld hos personer med lungekræft, væksthæmning hos børn. Efter længerevarende behandling øges risikoen for knoglebrud pga. knogleskørhed med symptomer såsom rygsmerte, nedsat bevægelighed og akut smerte.</div><div class=\"paragraph\"><b>Ikke alvorlige:</b> Øget risiko for infektioner, sløring eller forværring af eksisterende infektionssygdomme, tegn på nedsat binyrebarkfunktion (hovedpine, kvalme, svimmelhed, anoreksi, svaghed, følelsesmæssige forandringer, apati, uhensigtsmæssige reaktioner på stress), knogleskørhed ved længerevarende behandling (kan blive alvorlig), muskelsvaghed (ved høje doser), grå stær (uklart syn) ved længerevarende behandling, sukkersyge, øget sukkerindhold i blodet (hos personer med sukkersyge), nedsat vækst hos børn.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Almindelige bivirkninger</b> (forekommer hos 1 - 10 ud af 100 behandlede):</div><div class=\"paragraph\"><b>Alvorlige: </b>Forværring af eksisterende nedsat hjertefunktion, psykose, øget risiko for tuberkulose.</div><div class=\"paragraph\"><b>Ikke alvorlige: </b>Påvirkninger i huden i form af røde streger, pletter, karsprængninger, sår, udslæt på kroppen og i ansigtet, Cushings syndrom (måneansigt og øget fedtmængde på kroppen), for lavt kalium i blodet, som viser sig ved svaghed, nedsat muskelkraft og forstyrrelser i hjerterytmen (kan blive alvorligt), manglende menstruation hos fertile kvinder, nedsat udskillelse af salt og væskeophobning i kroppen, opstemthed, depression, forhøjet blodtryk, forværrede symptomer ved tarmbetændelse, øget svedtendens, natlig vandladning, nedsat sårheling, trøske, mund- eller hudsvamp, vægtøgning, øget appetit.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ikke almindelige bivirkninger </b>(forekommer hos 1 - 10 ud af 1.000 behandlede):</div><div class=\"paragraph\"><b>Alvorlige: </b>Mavesår og blødning fra mave-tarmkanalen eller hul på tarmen, forandring af knoglemassen, åndedrætsbesvær på grund af svækket åndedrætsmuskulatur, Tørst, træthed, øget vandladning pga. sukkersyge. Øget sukker (glukose) i blodet (både hos diabetikere og ikke-diabetikere), muskelsvaghed med påvirkning af åndedrætsmusklerne, Mørkerød urin, kraftige mavesmerter, psykiske forstyrrelser som f.eks. angst.</div><div class=\"paragraph\"><b>Ikke alvorlige:</b> Allergiske reaktioner, sukkersyge (lave doser), søvnløshed, humørsvingninger, ændringer i personlighed, mani, hallucinationer, urinsten.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Sjældne bivirkninger</b> (forekommer hos 1 - 10 ud af 10.000 behandlede):</div><div class=\"paragraph\"><b>Alvorlige:</b> Øget risiko for blodpropper.</div><div class=\"paragraph\"><b>Ikke alvorlige:</b> Hukommelsessvigt, dannelse af fedtvæv i rygsøjlen, forstyrrelser i stofskiftet, grøn stær efter længerevarende behandling, nedsat reaktion på hudtest, sprængte sener.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Meget sjældne bivirkninger</b> (forekommer hos færre end 1 ud af 10.000 behandlede):</div><div class=\"paragraph\"><b>Alvorlige: </b>For højt blodsukker med sløret bevidsthed eller bevidstløshed, anfald hos personer med ikke kendt epilepsi, forhøjet tryk i hjernen (især hos børn), sygdom i hjertemuskulaturen med åndenød, trykken for brystet og tendens til væske i kroppen, betændelse i bugspytkirtlen med voldsomme mavesmerter og feber efter længerevarende og højdosis behandling, alvorlig hudlidelse med blæreformet udslæt og betændelse i huden, især på hænder og fødder samt i og omkring munden ledsaget af feber (Stevens-Johnson syndrom), tumorlysesyndrom (ved kræftsygdom), reaktionsløs/stiv tilstand i kroppen (katatonisk stupor), Besvimelse med svag puls, bleghed, blåfarvning af læber og negle.</div><div class=\"paragraph\"><b>Ikke alvorlige:</b> Øjenforandringer, betændelse i sener (akillessene og knæskal), udstående øjne (langvarig behandling), forhøjet produktion af biskjoldbruskkirtelhormoner (hyperparathyroidisme), anfald af porfyri (sjælden arvelig stofskiftesygdom), halsbrand og forværring af eksisterende mavesår.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Bivirkninger, hvor hyppigheden ikke er kendt</b></div><div class=\"paragraph\"><b>Alvorlige: </b>Åndenød, angst, brystsmerter med udstråling til hals eller arme pga. blodprop i hjertet. Sklerodermisk nyrekrise hos patienter, som allerede lider af sklerodermi (en autoimmun sygdom). Tegn på sklerodermisk nyrekrise omfatter forhøjet blodtryk og nedsat urinproduktion.</div><div class=\"paragraph\"><b>Ikke alvorlige: </b>Sløret syn.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Prednisolon kan herudover give bivirkninger, som du normalt ikke mærker noget til. Det drejer sig om ændringer i visse laboratorieprøver, f.eks. forandringer i mængden af hvide blodlegemer og blodplader, for lavt kalium i blodet og forhøjet kolesterol, triglycerid og lipoprotein. Det kan hos enkelte udvikle sig til en alvorlig bivirkning. Tal med lægen.</div><h3>Indberetning af bivirkninger</h3><div class=\"paragraph\">Hvis du oplever bivirkninger, bør du tale med din læge, sygeplejerske eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til:</div><div class=\"paragraph\">Lægemiddelstyrelsen, Axel Heides Gade 1, DK-2300 København S,</div><div class=\"paragraph\">Websted: www.meldenbivirkning.dk.</div><div class=\"paragraph\"><br/>Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</div><div class=\"paragraph\"><a href=\"https://www.meldenbivirkning.dk\" title=\"Meld en bivirkning\">Meld en bivirkning.</a></div></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section5\"/><div> </div><h2>5. Opbevaring</h2><div class=\"paragraph\">Prednisolon skal opbevares utilgængeligt for børn.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Brug ikke medicinen efter den udløbsdato, der står på pakningen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.</div></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section6\"/><div> </div><h2>6. Pakningsstørrelser og yderligere oplysninger</h2><h3>Prednisolon DAK tabletter 2,5 mg, 5 mg og 25 mg indeholder</h3><div class=\"paragraph\">Det virksomme indholdsstof er prednisolon. De øvrige indholdsstoffer er gelatine, kartoffelstivelse, lactosemonohydrat, magnesiumstearat (E 470b) og talcum (E 553b). Prednisolon DAK 2,5 mg indeholder desuden farvestoffet indigotin I (E 132).</div><h3>Udseende og pakningsstørrelser</h3><div class=\"paragraph\">Prednisolon DAK 2,5 mg er en lyseblå tablet med delekærv på den ene side.</div><div class=\"paragraph\">Prednisolon DAK 5 mg og 25 mg er hvide tabletter med delekærv på den ene side.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Prednisolon DAK 2,5 mg findes i pakningsstørrelser à 100 stk.</div><div class=\"paragraph\">Prednisolon DAK 5 mg findes i pakningsstørrelser à 25 og 100 stk.</div><div class=\"paragraph\">Prednisolon DAK 25 mg findes i pakningsstørrelser à 10 og 100 stk.</div><div class=\"paragraph\">Ikke alle pakningsstørrelser er nødvendigvis markedsført.</div></div>"
          },
          "section" : [{
            "title" : "Indehaver af markedsføringstilladelsen og fremstiller",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Indehaver af markedsføringstilladelsen og fremstiller</h2><h3>Indehaver af markedsføringstilladelsen</h3><div class=\"paragraph\">Orifarm Healthcare A/S<br/>Energivej 15<br/>5260 Odense S<br/>info@orifarm.com</div><h3>Fremstiller</h3><div class=\"paragraph\">Orifarm Manufacturing Poland Sp. z o.o.<br/>Ul. Księstwa Łowickiego 12<br/>99-420 Łyszkowice<br/>Polen</div></div>"
            }
          },
          {
            "title" : "Denne indlægsseddel blev sidst ændret 09/2021.",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Denne indlægsseddel blev sidst ændret 09/2021.</h2></div>"
            }
          }]
        }]
      }]
    }
  }]
}

```
