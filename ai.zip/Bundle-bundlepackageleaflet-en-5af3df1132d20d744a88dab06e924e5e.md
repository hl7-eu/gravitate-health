# ePI document Bundle for Ogivri 150 mg powder for concentrate for solution for infusion Package Leaflet for language en - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Ogivri 150 mg powder for concentrate for solution for infusion Package Leaflet for language en**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **1 Vial** **(Glass type I)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Powder for concentrate for solution for infusion ** 

 Unit of presentation: ** Vial ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** SORBITOL ** 

Ingredient

 Role: ** Active ** 

 Substance: ** trastuzumab ** 

## Example Bundle: ePI document Bundle for Ogivri 150 mg powder for concentrate for solution for infusion Package Leaflet for language en

**Composition category:**Raw

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

unavailable


#### What is in this leaflet

 

unavailable


#### 1. What 0 is and what it is used for

 

unavailable


#### 2. What you need to know before you take 0

 

unavailable


#### 3. How to take 0

 

unavailable


#### 4. Possible side effects

 

unavailable


#### 5. How to store 0

 

unavailable


#### 6. Contents of the pack and other information

 

unavailable


####  Ogivri 150 mg powder for concentrate for solution for infusion 
4:
** 7532F47F36A3585D1F348BBDDA057862 **
-------

Full name: **Ogivri 150 mg powder for concentrate for solution for infusion**

 - Invented name part: ** Ogivri ** 

 - Scientific name part: ** trastuzumab ** 

 - Strength part: ** 150 mg ** 

 - Pharmaceutical dose form part: ** powder for concentrate for solution for infusion ** 

 Name usage: **English (Norway)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/18/1341/001 ** 

 Region: ** ** 

Marketing authorisation holder: **Viatris Limited** 

 Identifier: 
*  **ORG-100034260** 
 

 Status: ** Active (2018-12-12T00:00:00Z) ** 

 Package 1 of 1

PMSWI: ** EU/1/18/1341/001 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****150 

Administrable Product (1 of 1)

 Dose form: ** Solution for injection ** 

 Unit of presentation: ** Vial ** 

 Route of administration: 
*  ** Intravenous use ** 
 
Ingredients:

Ingredient

 Role: ** Excipient ** 

 Substance: ** SORBITOL ** 

Ingredient

 Role: ** Active ** 

 Substance: ** trastuzumab ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "7027e635478c3b3a26b4c7ea7238a57c"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-en-aae8d931abe2f2d9085b87555b9bb088",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-en-aae8d931abe2f2d9085b87555b9bb088",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_composition-en-aae8d931abe2f2d9085b87555b9bb088\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-en-aae8d931abe2f2d9085b87555b9bb088</b></p><a name=\"composition-en-aae8d931abe2f2d9085b87555b9bb088\"> </a><a name=\"hccomposition-en-aae8d931abe2f2d9085b87555b9bb088\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>nan</code>/eb2d55ad5005be64271cb8d7a8411595</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#Organization_mah-5192019d531d0f82a0e8d8ffcb39b68a\">Organization Viatris Limited</a></p><p><b>title</b>: TEST PURPOSES ONLY - Ogivri 150 mg powder for concentrate for solution for infusion </p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "nan",
        "value" : "eb2d55ad5005be64271cb8d7a8411595"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpaae8d931abe2f2d9085b87555b9bb088"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-5192019d531d0f82a0e8d8ffcb39b68a"
      }],
      "title" : "TEST PURPOSES ONLY - Ogivri 150 mg powder for concentrate for solution for infusion ",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. Package Leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "1. What 0 is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What 0 is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "2. What you need to know before you take 0",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take 0"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "3. How to take 0",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take 0"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "5. How to store 0",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store 0"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-trastuzumab-sorbitol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-trastuzumab-sorbitol",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-trastuzumab-sorbitol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-trastuzumab-sorbitol</b></p><a name=\"ingredient-for-trastuzumab-sorbitol\"> </a><a name=\"hcingredient-for-trastuzumab-sorbitol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/506T60A25R (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#ManufacturedItemDefinition_mid-5af3df1132d20d744a88dab06e924e5e\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1341/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#MedicinalProductDefinition_mpaae8d931abe2f2d9085b87555b9bb088\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/4#7532F47F36A3585D1F348BBDDA057862; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#AdministrableProductDefinition_ap-5af3df1132d20d744a88dab06e924e5e\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#id; status = active; administrableDoseForm = Solution for injection; unitOfPresentation = Vial</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 506T60A25R}\">SORBITOL</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "506T60A25R"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-5af3df1132d20d744a88dab06e924e5e"
      },
      {
        "reference" : "MedicinalProductDefinition/mpaae8d931abe2f2d9085b87555b9bb088"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-5af3df1132d20d744a88dab06e924e5e"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "506T60A25R",
              "display" : "SORBITOL"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-trastuzumab-trastuzumab",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-trastuzumab-trastuzumab",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-trastuzumab-trastuzumab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-trastuzumab-trastuzumab</b></p><a name=\"ingredient-for-trastuzumab-trastuzumab\"> </a><a name=\"hcingredient-for-trastuzumab-trastuzumab\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/P188ANX8CK (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#ManufacturedItemDefinition_mid-5af3df1132d20d744a88dab06e924e5e\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1341/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#MedicinalProductDefinition_mpaae8d931abe2f2d9085b87555b9bb088\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/4#7532F47F36A3585D1F348BBDDA057862; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#AdministrableProductDefinition_ap-5af3df1132d20d744a88dab06e924e5e\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#id; status = active; administrableDoseForm = Solution for injection; unitOfPresentation = Vial</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta P188ANX8CK}\">trastuzumab</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>150 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "P188ANX8CK"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-5af3df1132d20d744a88dab06e924e5e"
      },
      {
        "reference" : "MedicinalProductDefinition/mpaae8d931abe2f2d9085b87555b9bb088"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-5af3df1132d20d744a88dab06e924e5e"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "P188ANX8CK",
              "display" : "trastuzumab"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 150,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-trastuzumab",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-trastuzumab",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-trastuzumab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-trastuzumab</b></p><a name=\"substance-trastuzumab\"> </a><a name=\"hcsubstance-trastuzumab\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/P188ANX8CK (use: official, )</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#Organization_mah-5192019d531d0f82a0e8d8ffcb39b68a\">Organization Viatris Limited</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "P188ANX8CK"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/mah-5192019d531d0f82a0e8d8ffcb39b68a"
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-5af3df1132d20d744a88dab06e924e5e",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-5af3df1132d20d744a88dab06e924e5e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-5af3df1132d20d744a88dab06e924e5e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-5af3df1132d20d744a88dab06e924e5e</b></p><a name=\"ap-5af3df1132d20d744a88dab06e924e5e\"> </a><a name=\"hcap-5af3df1132d20d744a88dab06e924e5e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/id</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#MedicinalProductDefinition_mpaae8d931abe2f2d9085b87555b9bb088\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/4#7532F47F36A3585D1F348BBDDA057862; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073863}\">Solution for injection</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002158}\">Vial</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#ManufacturedItemDefinition_mid-5af3df1132d20d744a88dab06e924e5e\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1341/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073611}\">Intravenous use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "id"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mpaae8d931abe2f2d9085b87555b9bb088"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073863",
          "display" : "Solution for injection"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002158",
          "display" : "Vial"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-5af3df1132d20d744a88dab06e924e5e"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073611",
            "display" : "Intravenous use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization5af3df1132d20d744a88dab06e924e5e0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization5af3df1132d20d744a88dab06e924e5e0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization5af3df1132d20d744a88dab06e924e5e0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization5af3df1132d20d744a88dab06e924e5e0</b></p><a name=\"authorization5af3df1132d20d744a88dab06e924e5e0\"> </a><a name=\"hcauthorization5af3df1132d20d744a88dab06e924e5e0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1341/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#MedicinalProductDefinition_mpaae8d931abe2f2d9085b87555b9bb088\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/4#7532F47F36A3585D1F348BBDDA057862; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2018-12-12 00:00:00+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#Organization_mah-5192019d531d0f82a0e8d8ffcb39b68a\">Organization Viatris Limited</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1341/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpaae8d931abe2f2d9085b87555b9bb088"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2018-12-12T00:00:00Z",
      "holder" : {
        "reference" : "Organization/mah-5192019d531d0f82a0e8d8ffcb39b68a"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-5192019d531d0f82a0e8d8ffcb39b68a",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-5192019d531d0f82a0e8d8ffcb39b68a",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-5192019d531d0f82a0e8d8ffcb39b68a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-5192019d531d0f82a0e8d8ffcb39b68a</b></p><a name=\"mah-5192019d531d0f82a0e8d8ffcb39b68a\"> </a><a name=\"hcmah-5192019d531d0f82a0e8d8ffcb39b68a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100034260 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Viatris Limited</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Damastown Industrial Park, Mulhuddart, Dublin 15 Dublin IR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100034260"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Viatris Limited",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Damastown Industrial Park, Mulhuddart, Dublin 15 Dublin IR",
          "line" : ["Damastown Industrial Park, Mulhuddart, Dublin 15"],
          "city" : "Dublin",
          "country" : "IR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-e7c391536e9fc6ff50198d09558da8c0",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-e7c391536e9fc6ff50198d09558da8c0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-e7c391536e9fc6ff50198d09558da8c0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-e7c391536e9fc6ff50198d09558da8c0</b></p><a name=\"ppd-e7c391536e9fc6ff50198d09558da8c0\"> </a><a name=\"hcppd-e7c391536e9fc6ff50198d09558da8c0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1341/001 (use: official, )</p><p><b>name</b>: Ogivri 150 mg powder for concentrate for solution for infusion  1</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#MedicinalProductDefinition_mpaae8d931abe2f2d9085b87555b9bb088\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/4#7532F47F36A3585D1F348BBDDA057862; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 150 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073563}\">Vial</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003204}\">Glass type I</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-en-5af3df1132d20d744a88dab06e924e5e.html#ManufacturedItemDefinition_mid-5af3df1132d20d744a88dab06e924e5e\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1341/001 (use: official, ); status = active; manufacturedDoseForm = Powder for concentrate for solution for infusion; unitOfPresentation = Vial</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1341/001"
      }],
      "name" : "Ogivri 150 mg powder for concentrate for solution for infusion  1",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mpaae8d931abe2f2d9085b87555b9bb088"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 150,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073563",
              "display" : "Vial"
            }]
          },
          "quantity" : 1,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003204",
              "display" : "Glass type I"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-5af3df1132d20d744a88dab06e924e5e"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mpaae8d931abe2f2d9085b87555b9bb088",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mpaae8d931abe2f2d9085b87555b9bb088",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mpaae8d931abe2f2d9085b87555b9bb088\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mpaae8d931abe2f2d9085b87555b9bb088</b></p><a name=\"mpaae8d931abe2f2d9085b87555b9bb088\"> </a><a name=\"hcmpaae8d931abe2f2d9085b87555b9bb088\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://www.who-umc.org/phpid/4</code>/7532F47F36A3585D1F348BBDDA057862</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Ogivri 150 mg powder for concentrate for solution for infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Ogivri</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: trastuzumab</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 150 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: powder for concentrate for solution for infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 NOR}\">Norway</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 NOR}\">Norway</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.who-umc.org/phpid/4",
        "value" : "7532F47F36A3585D1F348BBDDA057862"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Ogivri 150 mg powder for concentrate for solution for infusion",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Ogivri",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "trastuzumab",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "150 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "powder for concentrate for solution for infusion",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "NOR",
              "display" : "Norway"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "NOR",
              "display" : "Norway"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-5af3df1132d20d744a88dab06e924e5e",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-5af3df1132d20d744a88dab06e924e5e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-5af3df1132d20d744a88dab06e924e5e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-5af3df1132d20d744a88dab06e924e5e</b></p><a name=\"mid-5af3df1132d20d744a88dab06e924e5e\"> </a><a name=\"hcmid-5af3df1132d20d744a88dab06e924e5e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1341/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000074029}\">Powder for concentrate for solution for infusion</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002158}\">Vial</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1341/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000074029",
          "display" : "Powder for concentrate for solution for infusion"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002158",
          "display" : "Vial"
        }]
      }
    }
  }]
}

```
