# ePI document Bundle for Dovato 50 mg/300 mg film-coated tablets Package Leaflet for language da - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Dovato 50 mg/300 mg film-coated tablets Package Leaflet for language da**

## Example Bundle: ePI document Bundle for Dovato 50 mg/300 mg film-coated tablets Package Leaflet for language da

**Composition category:**Raw

**Composition status:**final

### B. INDLÆGSSEDDEL

 

unavailable


#### Indlægsseddel: Information til brugeren

 

B. INDLÆGSSEDDEL Indlægsseddel: Information til patienten

Dovato 50 mg/300 mg filmovertrukne tabletter
dolutegravir/lamivudin

Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger. - Gem indlægssedlen. Du kan få brug for at læse den igen.
- Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide. - Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.
- Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se punkt 4.
Se den nyeste indlægsseddel på www.indlaegsseddel.dk


#### Oversigt over indlægssedlen

 

Oversigt over indlægssedlen

1. Virkning og anvendelse
1. Det skal du vide, før du begynder at tage Dovato
1. Sådan skal du tage Dovato
1. Bivirkninger
1. Opbevaring
1. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

Dovato er et lægemiddel, der indeholder to aktive stoffer, som anvendes til behandling af infektion med hiv (human immundefekt virus): dolutegravir og lamivudin. Dolutegravir tilhører en gruppe af antiretrovirale lægemidler, der kaldes integrasehæmmere (INI'er), og lamivudin tilhører en gruppe af antiretrovirale lægemidler, der kaldes nukleosidanalog revers transkriptasehæmmere (NRTI'er).

Dovato bruges til behandling af hiv hos voksne og unge over 12 år, som vejer mindst 40 kg.

Dovato helbreder ikke hiv-infektion, men det holder mængden af virus i kroppen på et lavt niveau. Dette hjælper din krop til at bevare antallet af CD4-celler i dit blod. CD4-celler er en type hvide blodceller, der spiller en vigtig rolle, når kroppen skal bekæmpe infektioner.

Behandlingen med Dovato virker ikke ens på alle. Lægen vil holde øje med, hvor effektiv din behandling er.


#### 2. Det skal du vide, før du begynder at tage Dovato

 

Tag ikke Dovato

* hvis du er allergisk (overfølsom) over for dolutegravir eller lamivudin eller et af de øvrige indholdsstoffer i Dovato (angivet i punkt 6)
* hvis du tager et lægemiddel, der kaldes fampridin (også kendt som dalfampridin; der anvendes til multipel sklerose).

→ Kontakt lægen, hvis du tror, at noget af dette gælder for dig.

Advarsler og forsigtighedsregler Nogle personer, der tager Dovato eller anden kombinationsbehandling mod hiv, har større risiko for bivirkninger end andre. Du skal være klar over den øgede risiko:

* hvis du har moderat eller svær leversygdom
* hvis du tidligere har haft en leversygdom, herunder hepatitis B eller C (hvis du har hepatitis B-infektion, må du ikke stoppe med at tage Dovato uden at have talt med lægen, da din hepatitis kan vende tilbage)
* hvis du har nyreproblemer. → Kontakt lægen, før du bruger Dovato, hvis noget af dette gælder for dig. Du kan have brug for ekstra kontrol, herunder blodprøver, mens du tager din medicin. Se punkt 4 for yderligere oplysninger.

Allergiske reaktioner Dovato indeholder dolutegravir. Dolutegravir kan forårsage en alvorlig allergisk reaktion, som kaldes en overfølsomhedsreaktion. Det er nødvendigt, at du kender vigtige tegn og symptomer, som du skal holde øje med, mens du tager Dovato. → Læs oplysningerne under "Allergiske reaktioner" i punkt 4 i denne indlægsseddel.

Hold øje med vigtige symptomer Nogle personer, der tager medicin mod hiv-infektion, udvikler andre tilstande, der kan være alvorlige. Disse tilstande omfatter:

* symptomer på infektioner og betændelse
* ledsmerter, stive led og knogleproblemer. Det er nødvendigt, at du kender vigtige tegn og symptomer, som du skal holde øje med, mens du tager Dovato.
→ Læs oplysningerne under "Andre mulige bivirkninger" i punkt 4 i denne indlægsseddel.

Børn Dette lægemiddel må ikke anvendes til børn under 12 år, da det ikke er undersøgt tilstrækkeligt hos disse patienter.

Brug af anden medicin sammen med Dovato Fortæl altid lægen eller apotekspersonalet, hvis du tager anden medicin, for nylig har taget anden medicin eller planlægger at tage anden medicin.

Tag ikke Dovato med følgende lægemidler:

* fampridin (også kendt som dalfampridin), der anvendes til multipel sklerose.

Nogle lægemidler kan påvirke virkningen af Dovato eller gøre det mere sandsynligt, at du får bivirkninger. Dovato kan også påvirke virkningen af andre lægemidler. Fortæl lægen, hvis du tager nogle af lægemidlerne, der står på følgende liste:

* metformin til behandling af diabetes (sukkersyge)
* lægemidler kaldet antacida (syreneutraliserende lægemidler) til behandling af fordøjelsesbesvær og halsbrand. Tag ikke et antacid i 6 timer, før du tager Dovato, eller i mindst 2 timer efter at du har taget Dovato (se også punkt 3, "Sådan skal du tage Dovato")
* tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium. Hvis du tager Dovato sammen med mad, kan du tage tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium samtidig med Dovato. Hvis du ikke tager Dovato sammen med mad, må du ikke tage tilskud eller multivitamin, der indeholder calcium, jern eller magnesium i 6 timer før du tager Dovato, eller i mindst 2 timer efter du har taget Dovato (se også punkt 3, "Sådan skal du tage Dovato")
* emtricitabin, etravirin, efavirenz, nevirapin eller tipranavir/ritonavir til behandling af hiv-infektion
* lægemidler (normalt væsker), der indeholder sorbitol og andre sukkeralkoholer (som f.eks. xylitol, mannitol, lactitol eller maltitol), hvis de tages regelmæssigt
* cladribin til behandling af leukæmi eller multipel sclerose
* rifampicin til behandling af tuberkulose (TB) og andre bakterieinfektioner
* phenytoin og phenobarbital til behandling af epilepsi
* oxcarbazepin og carbamazepin til behandling af epilepsi eller bipolar lidelse
* prikbladet perikon (Hypericum perforatum), et naturlægemiddel til behandling af depression. → Fortæl lægen eller apotekspersonalet, hvis du tager nogle af disse lægemidler. Lægen kan beslutte at justere din dosis eller, at du har brug for flere kontroller.

Graviditet Hvis du er gravid, har mistanke om, at du er gravid, eller planlægger at blive gravid: → Tal med din læge om fordele og risici ved at tage Dovato.

Hvis du tager Dovato på det tidspunkt, hvor du bliver gravid eller i løbet af de første seks uger af graviditeten, kan det øge risikoen for en type fødselsdefekt, kaldet neuralrørsdefekt, såsom rygmarksbrok (misdannet rygmarv).

Hvis der er risiko for, at du kan blive gravid, mens du tager Dovato: → Tal med din læge og diskuter, om der er behov for prævention, såsom kondom eller p-piller.

Fortæl det straks til din læge, hvis du bliver gravid, eller hvis du planlægger at blive gravid. Din læge vil gennemgå din behandling. Stop ikke med at tage Dovato uden først at tale med din læge, da det kan skade dig og dit ufødte barn.

Amning Amning anbefales ikke hos kvinder, der er hiv-positive, da hiv-infektion kan overføres til barnet gennem modermælken.

En lille mængde af indholdsstofferne i Dovato kan også overføres til din modermælk.

Hvis du ammer eller påtænker at amme, bør du drøfte det med lægen hurtigst muligt.

Trafik- og arbejdssikkerhed
Dovato kan gøre dig svimmel og give dig andre bivirkninger, der gør dig mindre opmærksom. → Du må ikke føre motorkøretøjer eller betjene maskiner, medmindre du er sikker på, at du ikke er påvirket.


#### 3. Sådan skal du tage Dovato

 

Tag altid lægemidlet nøjagtigt som beskrevet i denne indlægsseddel eller efter lægens anvisning. Er du i tvivl, så spørg lægen eller apotekspersonalet.

* Den anbefalede dosis Dovato er 1 tablet én gang dagligt.

Synk tabletten med væske. Dovato kan tages med eller uden mad.

Brug til børn og unge Unge i alderen mellem 12 og 17 år, som vejer mindst 40 kg, kan tage den samme dosis som voksne på 1 tablet én gang dagligt.

Syreneutraliserende lægemidler (antacida) Antacida, der anvendes til behandling af fordøjelsesbesvær og halsbrand, kan modvirke optagelsen af Dovato i kroppen og gøre det mindre effektivt. Tag ikke et antacid i 6 timer, før du tager Dovato, eller i mindst 2 timer efter at du har taget Dovato. Du kan tage andre syreneutraliserende lægemidler, f.eks. ranitidin og omeprazol samtidig med Dovato. → Tal med lægen for yderligere råd om, hvordan du skal tage syreneutraliserende lægemidler sammen med Dovato.

Tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium Tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium, kan modvirke optagelsen af Dovato i kroppen og gøre det mindre effektivt. Hvis du tager Dovato sammen med mad, kan du tage tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium samtidig med Dovato. Hvis du ikke tager Dovato sammen med mad, må du ikke tage tilskud eller multivitamin, der indeholder calcium, jern eller magnesium, i 6 timer før du tager Dovato, eller i mindst 2 timer efter du har taget Dovato. → Tal med lægen for yderligere råd om, hvordan du skal tage tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium, mens du tager Dovato.

Hvis du har taget for meget Dovato Hvis du tager for mange Dovato-tabletter, skal du kontakte lægen eller apotekspersonalet for vejledning. Tag Dovato-pakningen med, hvis det er muligt.

Hvis du har glemt at tage Dovato Hvis du glemmer en dosis, skal du tage den så snart, du husker det. Men hvis din næste dosis skal tages inden for 4 timer, skal du springe den glemte dosis over og tage den næste på det sædvanlige tidspunkt. Fortsæt derefter med behandlingen som normalt. → Du må ikke tage en dobbeltdosis som erstatning for den glemte dosis.

Du må ikke stoppe med at tage Dovato, medmindre lægen har sagt det. Tag Dovato så længe, som lægen anbefaler. Du må ikke stoppe, medmindre lægen har sagt det. Hvis du stopper med Dovato, kan det påvirke dit helbred, og hvordan din behandling vil virke i fremtiden.

Spørg lægen eller apotekspersonalet, hvis der noget, du er i tvivl om.


#### 4. Bivirkninger

 

Dette lægemiddel kan som alle andre lægemidler give bivirkninger, men ikke alle får bivirkninger. Derfor er det meget vigtigt, at du taler med lægen om eventuelle ændringer i dit helbred.

Allergiske reaktioner Dovato indeholder dolutegravir. Dolutegravir kan forårsage en alvorlig allergisk reaktion, som kaldes en overfølsomhedsreaktion. Dette er en ikke almindelig bivirkning (kan forekomme hos op til 1 ud af 100 personer) hos personer, der tager dolutegravir. Hvis du får nogen af følgende symptomer:

* hududslæt
* høj kropstemperatur (feber)
* manglende energi (træthed)
* hævelse, nogle gange af ansigtet eller munden (angioødem), hvilket giver vejrtrækningsbesvær
* muskel- eller ledsmerter. → Gå straks til lægen. Lægen kan beslutte at foretage undersøgelser for at kontrollere din lever, dine nyrer eller dit blod og vil måske bede dig om at stoppe med at tage Dovato.

Meget almindelige bivirkninger
Kan forekomme hos flere end 1 ud af 10 personer:

* hovedpine
* diarré
* kvalme.

Almindelige bivirkninger
Kan forekomme hos op til 1 ud af 10 personer:

* depression (følelse af dyb bedrøvelse eller af at være værdiløs)
* udslæt
* kløe (pruritus)
* opkastning
* smerter eller ubehag i maven
* vægtøgning
* luftafgang fra tarmen (flatulens)
* svimmelhed
* døsighed
* problemer med at sove (insomni)
* unormale drømme
* manglende energi (træthed)
* hårtab
* angst
* ledsmerter
* muskelsmerter.

Almindelige bivirkninger, der muligvis kan ses i blodprøver, er:

* øget niveau af leverenzymer (aminotransferaser)
* øget niveau af enzymer, der dannes i musklerne (kreatinfosfokinase).

Ikke almindelige bivirkninger
Kan forekomme hos op til 1 ud af 100 personer:

* leverbetændelse (hepatitis)
* selvmordsforsøg (særligt hos patienter, som tidligere har haft depression eller psykiske problemer)
* selvmordstanker (særligt hos patienter, som tidligere har haft depression eller psykiske problemer)
* panikanfald.

Ikke almindelige bivirkninger, der muligvis kan ses i blodprøver, er:

* nedsat antal blodceller, der bidrager til, at blodet størkner (trombocytopeni)
* lavt antal røde blodceller (anæmi) eller lavt antal hvide blodceller (neutropeni).

Sjældne bivirkninger
Kan forekomme hos op til 1 ud af 1000 personer:

* leversvigt (tegnene kan omfatte gulfarvning af huden og det hvide i øjnene eller usædvanligt mørk urin)
* hævelse, nogle gange af ansigtet eller munden (angioødem), hvilket giver vejrtrækningsbesvær
* betændelse i bugspytkirtlen (pancreatitis)
* nedbrydning af muskelvæv
* selvmord (særligt hos patienter, som tidligere har haft depression eller psykiske problemer).

→ Fortæl det omgående til lægen, hvis du oplever psykiske problemer (se også andre psykiske problemer ovenfor).

Sjældne bivirkninger, der muligvis kan ses i blodprøver, er:

* stigning i bilirubin (test af leverfunktion)
* stigning i et enzym, der kaldes amylase.

Meget sjældne bivirkninger Kan forekomme hos op til 1 ud af 10.000 personer:

* for meget mælkesyre i blodet (laktacidose)
* følelsesløshed, snurrende fornemmelse i huden (prikken og stikken)
* en følelse af svaghed i arme og ben.

Meget sjældne bivirkninger, der muligvis kan ses i blodprøver, er:

* manglende dannelse af nye røde blodceller i knoglemarven (ren erytrocytaplasi).

Andre mulige bivirkninger Personer, der tager kombinationsbehandling mod hiv, kan få andre bivirkninger.

Symptomer på infektion og betændelse
Personer med fremskreden hiv-infektion eller aids har et svækket immunforsvar og har større risiko for at udvikle alvorlige infektioner (opportunistiske infektioner). Sådanne infektioner kan have været "skjult" og ikke være blevet opdaget af det svækkede immunsystem før behandlingens start. Efter start af behandling bliver immunforsvaret stærkere og kan angribe infektionerne, hvilket kan give symptomer på infektion og betændelse. Symptomerne involverer som regel feber, samt nogle af følgende:

* hovedpine
* mavepine
* vejrtrækningsbesvær.

I sjældne tilfælde, når immunsystemet bliver stærkere, kan det også angribe sundt kropsvæv (autoimmune sygdomme). Der kan udvikles symptomer på autoimmune sygdomme flere måneder efter, du begynder at tage medicin til behandling af din hiv-infektion. Symptomerne kan omfatte:

* hjertebanken (hurtigt eller uregelmæssigt hjerteslag) eller rysten
* hyperaktivitet (overdreven rastløshed og bevægelse)
* svaghed, der starter i hænder og fødder og bevæger sig op ad kroppen.

Hvis du får nogen symptomer på infektion, eller hvis du bemærker nogen af ovennævnte symptomer: → Fortæl det omgående til lægen. Tag ikke andre lægemidler mod infektionen, medmindre lægen har sagt det.

Ledsmerter, stive led og knogleproblemer

Nogle personer, der får kombinationsbehandling mod hiv-infektion, udvikler en tilstand, der kaldes osteonekrose. Med denne sygdom er dele af knoglevævet permanent beskadiget på grund af nedsat blodtilførsel til knoglerne. Personer, der kan have større risiko for at få denne tilstand:

* hvis de har fået kombinationsbehandling i lang tid
* hvis de også tager en form for antiinflammatorisk (betændelsesdæmpende) medicin, der kaldes kortikosteroider
* hvis de drikker alkohol
* hvis deres immunforsvar er meget svækket
* hvis de er overvægtige.

Symptomerne på osteonekrose omfatter:

* stive led
* ømhed og smerter i leddene (særligt i hofter, knæ eller skuldre)
* bevægelsesbesvær.

Hvis du bemærker nogen af disse symptomer: → Fortæl det til lægen.

Virkning på vægt, fedtstoffer i blodet og blodsukkeret: Under hiv-behandling kan der være en stigning i vægt og i niveauer af fedtstoffer og glukose i blodet. Dette er delvist knyttet til genoprettet helbred og livsstil og undertiden til hiv-medicinen selv. Din læge vil teste for disse ændringer. Indberetning af bivirkninger Hvis du oplever bivirkninger, bør du tale med din læge eller apotekspersonalet. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via det nationale rapporteringssystem anført i Appendix V. Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.


#### 5. Opbevaring

 

Opbevar lægemidlet utilgængeligt for børn.

Brug ikke lægemidlet efter den udløbsdato, der står på æsken og beholderen eller blisterkortet efter EXP. Udløbsdatoen er den sidste dag i den nævnte måned.

Dette lægemiddel kræver ingen særlige forholdsregler vedrørende opbevaringen.

Spørg apotekspersonalet, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

Dovato indeholder:

* Aktive stoffer: dolutegravir og lamivudin. Hver tablet indeholder dolutegravirnatrium svarende til 50 mg dolutegravir og 300 mg lamivudin.
* Øvrige indholdsstoffer: mikrokrystallinsk cellulose, natriumstivelsesglycolat, magnesiumstearat, mannitol (E421), povidon (K29/32), natriumstearylfumarat, hypromellose (E464), macrogol, titandioxid (E171).
* Dette lægemiddel indeholder mindre end 1 mmol (23 mg) natrium pr. tablet, dvs. det er i det væsentlige natriumfrit.

Udseende og pakningsstørrelser

Dovato filmovertrukne tabletter er ovale, bikonvekse, hvide tabletter præget med "SV 137" på den ene side.

De filmovertrukne tabletter fås i beholdere, der er lukket med børnesikret lukke eller i børnesikrede blisterkort.

Beholder Hver beholder indeholder 30 filmovertrukne tabletter.

Fås også i multipakninger, der indeholder 90 filmovertrukne tabletter (3 beholdere à 30 filmovertrukne tabletter).

Blisterpakning Hver blisterpakning med 30 filmovertrukne tabletter består af 4 blisterkort, som hver indeholder 7 filmovertrukne tabletter og 1 blisterkort, som indeholder 2 filmovertrukne tabletter.

Fås også i multipakninger, der indeholder 90 filmovertrukne tabletter (3 blisterpakninger à filmovertrukne tabletter).

Ikke alle pakningsstørrelser er nødvendigvis markedsført i dit land.

Indehaver af markedsføringstilladelsen
ViiV Healthcare BV Van Asch van Wijckstraat 55H 3811 LP Amersfoort Holland

Fremstiller Glaxo Wellcome, S.A.
Avda. Extremadura, 3 09400 Aranda De Duero Burgos Spanien

Hvis du ønsker yderligere oplysninger om dette lægemiddel, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:

België/Belgique/Belgien ViiV Healthcare srl/bv
Tél/Tel: + 32 (0) 10 85 65
Lietuva ViiV Healthcare BV Tel: + 370 80000

България ViiV Healthcare BV Teл.: + 359 80018

Luxembourg/Luxemburg ViiV Healthcare srl/bv
Belgique/Belgien Tél/Tel: + 32 (0) 10 85 65
Česká republika GlaxoSmithKline, s.r.o. Tel: + 420 222 001 cz.info@gsk.com

Magyarország ViiV Healthcare BV. Tel.: + 36 80088 Danmark GlaxoSmithKline Pharma A/S Tlf: + 45 36 35 91 dk-info@gsk.com

Malta ViiV Healthcare BV Tel: + 356 80065 Deutschland ViiV Healthcare GmbH
Tel.: + 49 (0)89 203 0038-10
viiv.med.info@viivhealthcare.com

Nederland ViiV Healthcare BV
Tel: + 31 (0)33 2081

Eesti ViiV Healthcare BV Tel: + 372 8002

Norge GlaxoSmithKline AS Tlf: + 47 22 70 20

Ελλάδα GlaxoSmithKline Μονοπρόσωπη A.E.B.E. Τηλ: + 30 210 68 82
Österreich GlaxoSmithKline Pharma GmbH Tel: + 43 (0)1 97075 0 at.info@gsk.com

España

Polska Laboratorios ViiV Healthcare, S.L.
Tel: + 34 900 923 501
es-ci@viivhealthcare.com GSK Services Sp. z o.o. Tel.: + 48 (0)22 576 9

France ViiV Healthcare SAS
Tél.: + 33 (0)1 39 17 69 Infomed@viivhealthcare.com

Portugal VIIVHIV HEALTHCARE, UNIPESSOAL, LDA
Tel: + 351 21 094 08 01
viiv.fi.pt@viivhealthcare.com

Hrvatska ViiV Healthcare BV Tel: + 385 800787 România ViiV Healthcare BV
Tel: + 40800672 Ireland GlaxoSmithKline (Ireland) Limited Tel: + 353 (0)1 4955 Slovenija ViiV Healthcare BV Tel: + 386 80688

Ísland Vistor hf. Sími: +354 535 7 Slovenská republika ViiV Healthcare BV Tel: + 421 800500

Italia ViiV Healthcare S.r.l
Tel: + 39 (0)45 7741 Suomi/Finland GlaxoSmithKline Oy Puh/Tel: + 358 (0)10 30 30

Κύπρος ViiV Healthcare BV Τηλ: + 357 80070

Sverige GlaxoSmithKline AB Tel: + 46 (0)8 638 93 info.produkt@gsk.com

Latvija ViiV Healthcare BV Tel: + 371 80205

United Kingdom (Northern Ireland) ViiV Healthcare BV Tel: + 44 (0)800 221customercontactuk@gsk.com

Denne indlægsseddel blev senest ændret {måned ÅÅÅÅ}.

Andre informationskilder

Du kan finde yderligere oplysninger om dette lægemiddel på Det Europæiske Lægemiddelagenturs hjemmeside: http://www.ema.europa.eu.


####  Dovato 50 mg/300 mg film-coated tablets 
PMSWI:
** EU/1/19/1370/001 **PHPID:
** 0x073AF2E5B92AE19E8B67635AFFB3D6CA **
-------

Full name: **Dovato 50 mg/300 mg film-coated tablets**

 - Invented name part: ** Dovato ** 

 - Scientific name part: ** dolutegravir/lamivudine ** 

 - Strength part: ** 50 mg/300 mg ** 

 - Pharmaceutical dose form part: ** film-coated tablets ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/19/1370/001 ** 

 Region: ** ** 

Marketing authorisation holder: **ViiV Healthcare BV** 

 Identifier: 
*  **ORG-100012958** 
 

 Status: ** Active (2019-07-01T13:28:17Z) ** 

 Package 1 of 1

PMSWI: ** EU/1/19/1370/001 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Child-resistant closure** **(Glass)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Film-coated tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** DOLUTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** lamivudine ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** sodium starch glycolate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** mannitol ** 

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Active ** 

 Substance: ** DOLUTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** lamivudine ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** sodium starch glycolate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** mannitol ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/19/1370/001"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-da-16598f252d07b4784b82ba43cf9e847e",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-da-16598f252d07b4784b82ba43cf9e847e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_composition-da-16598f252d07b4784b82ba43cf9e847e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-da-16598f252d07b4784b82ba43cf9e847e</b></p><a name=\"composition-da-16598f252d07b4784b82ba43cf9e847e\"> </a><a name=\"hccomposition-da-16598f252d07b4784b82ba43cf9e847e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>nan</code>/c90d140de2d4ddf3b2a2617fc2fc996c</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-04-29 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mah-31ff1af739c7dcf77386a86f8dd83d29\">Organization ViiV Healthcare BV</a></p><p><b>title</b>: TEST PURPOSES ONLY - Dovato 50 mg/300 mg film-coated tablets</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-04-29 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "nan",
        "value" : "c90d140de2d4ddf3b2a2617fc2fc996c"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "date" : "2022-04-29T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-31ff1af739c7dcf77386a86f8dd83d29"
      }],
      "title" : "TEST PURPOSES ONLY - Dovato 50 mg/300 mg film-coated tablets",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-04-29T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. INDLÆGSSEDDEL",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. INDLÆGSSEDDEL"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Indlægsseddel: Information til brugeren",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Indlægsseddel: Information til brugeren"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>B. INDLÆGSSEDDEL Indlægsseddel: Information til patienten</p><p>Dovato 50 mg/300 mg filmovertrukne tabletter<br/>dolutegravir/lamivudin</p><p>Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger. - Gem indlægssedlen. Du kan få brug for at læse den igen.<br/>- Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide. - Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.<br/>- Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se punkt 4.<br/>Se den nyeste indlægsseddel på www.indlaegsseddel.dk</p></div>"
          }
        },
        {
          "title" : "Oversigt over indlægssedlen",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Oversigt over indlægssedlen"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Oversigt over indlægssedlen</p><ol><li>Virkning og anvendelse</li><li>Det skal du vide, før du begynder at tage Dovato</li><li>Sådan skal du tage Dovato</li><li>Bivirkninger</li><li>Opbevaring</li><li>Pakningsstørrelser og yderligere oplysninger</li></ol></div>"
          }
        },
        {
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Virkning og anvendelse"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Dovato er et lægemiddel, der indeholder to aktive stoffer, som anvendes til behandling af infektion med hiv (human immundefekt virus): dolutegravir og lamivudin. Dolutegravir tilhører en gruppe af antiretrovirale lægemidler, der kaldes integrasehæmmere (INI'er), og lamivudin tilhører en gruppe af antiretrovirale lægemidler, der kaldes nukleosidanalog revers transkriptasehæmmere (NRTI'er).</p><p>Dovato bruges til behandling af hiv hos voksne og unge over 12 år, som vejer mindst 40 kg.</p><p>Dovato helbreder ikke hiv-infektion, men det holder mængden af virus i kroppen på et lavt niveau. Dette hjælper din krop til at bevare antallet af CD4-celler i dit blod. CD4-celler er en type hvide blodceller, der spiller en vigtig rolle, når kroppen skal bekæmpe infektioner.</p><p>Behandlingen med Dovato virker ikke ens på alle. Lægen vil holde øje med, hvor effektiv din behandling er.</p></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du begynder at tage  Dovato",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Det skal du vide, før du begynder at tage  Dovato"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Tag ikke Dovato</p><ul><li><p>hvis du er allergisk (overfølsom) over for dolutegravir eller lamivudin eller et af de øvrige indholdsstoffer i Dovato (angivet i punkt 6)</p></li><li><p>hvis du tager et lægemiddel, der kaldes fampridin (også kendt som dalfampridin; der anvendes til multipel sklerose).</p></li></ul><p>→ Kontakt lægen, hvis du tror, at noget af dette gælder for dig.</p><p>Advarsler og forsigtighedsregler Nogle personer, der tager Dovato eller anden kombinationsbehandling mod hiv, har større risiko for bivirkninger end andre. Du skal være klar over den øgede risiko:</p><ul><li><p>hvis du har moderat eller svær leversygdom</p></li><li><p>hvis du tidligere har haft en leversygdom, herunder hepatitis B eller C (hvis du har hepatitis B-infektion, må du ikke stoppe med at tage Dovato uden at have talt med lægen, da din hepatitis kan vende tilbage)</p></li><li><p>hvis du har nyreproblemer. → Kontakt lægen, før du bruger Dovato, hvis noget af dette gælder for dig. Du kan have brug for ekstra kontrol, herunder blodprøver, mens du tager din medicin. Se punkt 4 for yderligere oplysninger.</p></li></ul><p>Allergiske reaktioner Dovato indeholder dolutegravir. Dolutegravir kan forårsage en alvorlig allergisk reaktion, som kaldes en overfølsomhedsreaktion. Det er nødvendigt, at du kender vigtige tegn og symptomer, som du skal holde øje med, mens du tager Dovato. → Læs oplysningerne under \"Allergiske reaktioner\" i punkt 4 i denne indlægsseddel.</p><p>Hold øje med vigtige symptomer Nogle personer, der tager medicin mod hiv-infektion, udvikler andre tilstande, der kan være alvorlige. Disse tilstande omfatter:</p><ul><li><p>symptomer på infektioner og betændelse</p></li><li><p>ledsmerter, stive led og knogleproblemer. Det er nødvendigt, at du kender vigtige tegn og symptomer, som du skal holde øje med, mens du tager Dovato.<br/>→ Læs oplysningerne under \"Andre mulige bivirkninger\" i punkt 4 i denne indlægsseddel.</p></li></ul><p>Børn Dette lægemiddel må ikke anvendes til børn under 12 år, da det ikke er undersøgt tilstrækkeligt hos disse patienter.</p><p>Brug af anden medicin sammen med Dovato Fortæl altid lægen eller apotekspersonalet, hvis du tager anden medicin, for nylig har taget anden medicin eller planlægger at tage anden medicin.</p><p>Tag ikke Dovato med følgende lægemidler:</p><ul><li>fampridin (også kendt som dalfampridin), der anvendes til multipel sklerose.</li></ul><p>Nogle lægemidler kan påvirke virkningen af Dovato eller gøre det mere sandsynligt, at du får bivirkninger. Dovato kan også påvirke virkningen af andre lægemidler. Fortæl lægen, hvis du tager nogle af lægemidlerne, der står på følgende liste:</p><ul><li><p>metformin til behandling af diabetes (sukkersyge)</p></li><li><p>lægemidler kaldet antacida (syreneutraliserende lægemidler) til behandling af fordøjelsesbesvær og halsbrand. Tag ikke et antacid i 6 timer, før du tager Dovato, eller i mindst 2 timer efter at du har taget Dovato (se også punkt 3, \"Sådan skal du tage Dovato\")</p></li><li><p>tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium. Hvis du tager Dovato sammen med mad, kan du tage tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium samtidig med Dovato. Hvis du ikke tager Dovato sammen med mad, må du ikke tage tilskud eller multivitamin, der indeholder calcium, jern eller magnesium i 6 timer før du tager Dovato, eller i mindst 2 timer efter du har taget Dovato (se også punkt 3, \"Sådan skal du tage Dovato\")</p></li><li><p>emtricitabin, etravirin, efavirenz, nevirapin eller tipranavir/ritonavir til behandling af hiv-infektion</p></li><li><p>lægemidler (normalt væsker), der indeholder sorbitol og andre sukkeralkoholer (som f.eks. xylitol, mannitol, lactitol eller maltitol), hvis de tages regelmæssigt</p></li><li><p>cladribin til behandling af leukæmi eller multipel sclerose</p></li><li><p>rifampicin til behandling af tuberkulose (TB) og andre bakterieinfektioner</p></li><li><p>phenytoin og phenobarbital til behandling af epilepsi</p></li><li><p>oxcarbazepin og carbamazepin til behandling af epilepsi eller bipolar lidelse</p></li><li><p>prikbladet perikon (Hypericum perforatum), et naturlægemiddel til behandling af depression. → Fortæl lægen eller apotekspersonalet, hvis du tager nogle af disse lægemidler. Lægen kan beslutte at justere din dosis eller, at du har brug for flere kontroller.</p></li></ul><p>Graviditet Hvis du er gravid, har mistanke om, at du er gravid, eller planlægger at blive gravid: → Tal med din læge om fordele og risici ved at tage Dovato.</p><p>Hvis du tager Dovato på det tidspunkt, hvor du bliver gravid eller i løbet af de første seks uger af graviditeten, kan det øge risikoen for en type fødselsdefekt, kaldet neuralrørsdefekt, såsom rygmarksbrok (misdannet rygmarv).</p><p>Hvis der er risiko for, at du kan blive gravid, mens du tager Dovato: → Tal med din læge og diskuter, om der er behov for prævention, såsom kondom eller p-piller.</p><p>Fortæl det straks til din læge, hvis du bliver gravid, eller hvis du planlægger at blive gravid. Din læge vil gennemgå din behandling. Stop ikke med at tage Dovato uden først at tale med din læge, da det kan skade dig og dit ufødte barn.</p><p>Amning Amning anbefales ikke hos kvinder, der er hiv-positive, da hiv-infektion kan overføres til barnet gennem modermælken.</p><p>En lille mængde af indholdsstofferne i Dovato kan også overføres til din modermælk.</p><p>Hvis du ammer eller påtænker at amme, bør du drøfte det med lægen hurtigst muligt.</p><p>Trafik- og arbejdssikkerhed<br/>Dovato kan gøre dig svimmel og give dig andre bivirkninger, der gør dig mindre opmærksom. → Du må ikke føre motorkøretøjer eller betjene maskiner, medmindre du er sikker på, at du ikke er påvirket.</p></div>"
          }
        },
        {
          "title" : "3. Sådan skal du tage Dovato",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Sådan skal du tage Dovato"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Tag altid lægemidlet nøjagtigt som beskrevet i denne indlægsseddel eller efter lægens anvisning. Er du i tvivl, så spørg lægen eller apotekspersonalet.</p><ul><li>Den anbefalede dosis Dovato er 1 tablet én gang dagligt.</li></ul><p>Synk tabletten med væske. Dovato kan tages med eller uden mad.</p><p>Brug til børn og unge Unge i alderen mellem 12 og 17 år, som vejer mindst 40 kg, kan tage den samme dosis som voksne på 1 tablet én gang dagligt.</p><p>Syreneutraliserende lægemidler (antacida) Antacida, der anvendes til behandling af fordøjelsesbesvær og halsbrand, kan modvirke optagelsen af Dovato i kroppen og gøre det mindre effektivt. Tag ikke et antacid i 6 timer, før du tager Dovato, eller i mindst 2 timer efter at du har taget Dovato. Du kan tage andre syreneutraliserende lægemidler, f.eks. ranitidin og omeprazol samtidig med Dovato. → Tal med lægen for yderligere råd om, hvordan du skal tage syreneutraliserende lægemidler sammen med Dovato.</p><p>Tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium Tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium, kan modvirke optagelsen af Dovato i kroppen og gøre det mindre effektivt. Hvis du tager Dovato sammen med mad, kan du tage tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium samtidig med Dovato. Hvis du ikke tager Dovato sammen med mad, må du ikke tage tilskud eller multivitamin, der indeholder calcium, jern eller magnesium, i 6 timer før du tager Dovato, eller i mindst 2 timer efter du har taget Dovato. → Tal med lægen for yderligere råd om, hvordan du skal tage tilskud eller multivitaminer, der indeholder calcium, jern eller magnesium, mens du tager Dovato.</p><p>Hvis du har taget for meget Dovato Hvis du tager for mange Dovato-tabletter, skal du kontakte lægen eller apotekspersonalet for vejledning. Tag Dovato-pakningen med, hvis det er muligt.</p><p>Hvis du har glemt at tage Dovato Hvis du glemmer en dosis, skal du tage den så snart, du husker det. Men hvis din næste dosis skal tages inden for 4 timer, skal du springe den glemte dosis over og tage den næste på det sædvanlige tidspunkt. Fortsæt derefter med behandlingen som normalt. → Du må ikke tage en dobbeltdosis som erstatning for den glemte dosis.</p><p>Du må ikke stoppe med at tage Dovato, medmindre lægen har sagt det. Tag Dovato så længe, som lægen anbefaler. Du må ikke stoppe, medmindre lægen har sagt det. Hvis du stopper med Dovato, kan det påvirke dit helbred, og hvordan din behandling vil virke i fremtiden.</p><p>Spørg lægen eller apotekspersonalet, hvis der noget, du er i tvivl om.</p></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Bivirkninger"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Dette lægemiddel kan som alle andre lægemidler give bivirkninger, men ikke alle får bivirkninger. Derfor er det meget vigtigt, at du taler med lægen om eventuelle ændringer i dit helbred.</p><p>Allergiske reaktioner Dovato indeholder dolutegravir. Dolutegravir kan forårsage en alvorlig allergisk reaktion, som kaldes en overfølsomhedsreaktion. Dette er en ikke almindelig bivirkning (kan forekomme hos op til 1 ud af 100 personer) hos personer, der tager dolutegravir. Hvis du får nogen af følgende symptomer:</p><ul><li><p>hududslæt</p></li><li><p>høj kropstemperatur (feber)</p></li><li><p>manglende energi (træthed)</p></li><li><p>hævelse, nogle gange af ansigtet eller munden (angioødem), hvilket giver vejrtrækningsbesvær</p></li><li><p>muskel- eller ledsmerter. → Gå straks til lægen. Lægen kan beslutte at foretage undersøgelser for at kontrollere din lever, dine nyrer eller dit blod og vil måske bede dig om at stoppe med at tage Dovato.</p></li></ul><p>Meget almindelige bivirkninger<br/>Kan forekomme hos flere end 1 ud af 10 personer:</p><ul><li><p>hovedpine</p></li><li><p>diarré</p></li><li><p>kvalme.</p></li></ul><p>Almindelige bivirkninger<br/>Kan forekomme hos op til 1 ud af 10 personer:</p><ul><li><p>depression (følelse af dyb bedrøvelse eller af at være værdiløs)</p></li><li><p>udslæt</p></li><li><p>kløe (pruritus)</p></li><li><p>opkastning</p></li><li><p>smerter eller ubehag i maven</p></li><li><p>vægtøgning</p></li><li><p>luftafgang fra tarmen (flatulens)</p></li><li><p>svimmelhed</p></li><li><p>døsighed</p></li><li><p>problemer med at sove (insomni)</p></li><li><p>unormale drømme</p></li><li><p>manglende energi (træthed)</p></li><li><p>hårtab</p></li><li><p>angst</p></li><li><p>ledsmerter</p></li><li><p>muskelsmerter.</p></li></ul><p>Almindelige bivirkninger, der muligvis kan ses i blodprøver, er:</p><ul><li><p>øget niveau af leverenzymer (aminotransferaser)</p></li><li><p>øget niveau af enzymer, der dannes i musklerne (kreatinfosfokinase).</p></li></ul><p>Ikke almindelige bivirkninger<br/>Kan forekomme hos op til 1 ud af 100 personer:</p><ul><li><p>leverbetændelse (hepatitis)</p></li><li><p>selvmordsforsøg (særligt hos patienter, som tidligere har haft depression eller psykiske problemer)</p></li><li><p>selvmordstanker (særligt hos patienter, som tidligere har haft depression eller psykiske problemer)</p></li><li><p>panikanfald.</p></li></ul><p>Ikke almindelige bivirkninger, der muligvis kan ses i blodprøver, er:</p><ul><li><p>nedsat antal blodceller, der bidrager til, at blodet størkner (trombocytopeni)</p></li><li><p>lavt antal røde blodceller (anæmi) eller lavt antal hvide blodceller (neutropeni).</p></li></ul><p>Sjældne bivirkninger<br/>Kan forekomme hos op til 1 ud af 1000 personer:</p><ul><li><p>leversvigt (tegnene kan omfatte gulfarvning af huden og det hvide i øjnene eller usædvanligt mørk urin)</p></li><li><p>hævelse, nogle gange af ansigtet eller munden (angioødem), hvilket giver vejrtrækningsbesvær</p></li><li><p>betændelse i bugspytkirtlen (pancreatitis)</p></li><li><p>nedbrydning af muskelvæv</p></li><li><p>selvmord (særligt hos patienter, som tidligere har haft depression eller psykiske problemer).</p></li></ul><p>→ Fortæl det omgående til lægen, hvis du oplever psykiske problemer (se også andre psykiske problemer ovenfor).</p><p>Sjældne bivirkninger, der muligvis kan ses i blodprøver, er:</p><ul><li><p>stigning i bilirubin (test af leverfunktion)</p></li><li><p>stigning i et enzym, der kaldes amylase.</p></li></ul><p>Meget sjældne bivirkninger Kan forekomme hos op til 1 ud af 10.000 personer:</p><ul><li><p>for meget mælkesyre i blodet (laktacidose)</p></li><li><p>følelsesløshed, snurrende fornemmelse i huden (prikken og stikken)</p></li><li><p>en følelse af svaghed i arme og ben.</p></li></ul><p>Meget sjældne bivirkninger, der muligvis kan ses i blodprøver, er:</p><ul><li>manglende dannelse af nye røde blodceller i knoglemarven (ren erytrocytaplasi).</li></ul><p>Andre mulige bivirkninger Personer, der tager kombinationsbehandling mod hiv, kan få andre bivirkninger.</p><p>Symptomer på infektion og betændelse<br/>Personer med fremskreden hiv-infektion eller aids har et svækket immunforsvar og har større risiko for at udvikle alvorlige infektioner (opportunistiske infektioner). Sådanne infektioner kan have været \"skjult\" og ikke være blevet opdaget af det svækkede immunsystem før behandlingens start. Efter start af behandling bliver immunforsvaret stærkere og kan angribe infektionerne, hvilket kan give symptomer på infektion og betændelse. Symptomerne involverer som regel feber, samt nogle af følgende:</p><ul><li><p>hovedpine</p></li><li><p>mavepine</p></li><li><p>vejrtrækningsbesvær.</p></li></ul><p>I sjældne tilfælde, når immunsystemet bliver stærkere, kan det også angribe sundt kropsvæv (autoimmune sygdomme). Der kan udvikles symptomer på autoimmune sygdomme flere måneder efter, du begynder at tage medicin til behandling af din hiv-infektion. Symptomerne kan omfatte:</p><ul><li><p>hjertebanken (hurtigt eller uregelmæssigt hjerteslag) eller rysten</p></li><li><p>hyperaktivitet (overdreven rastløshed og bevægelse)</p></li><li><p>svaghed, der starter i hænder og fødder og bevæger sig op ad kroppen.</p></li></ul><p>Hvis du får nogen symptomer på infektion, eller hvis du bemærker nogen af ovennævnte symptomer: → Fortæl det omgående til lægen. Tag ikke andre lægemidler mod infektionen, medmindre lægen har sagt det.</p><p>Ledsmerter, stive led og knogleproblemer</p><p>Nogle personer, der får kombinationsbehandling mod hiv-infektion, udvikler en tilstand, der kaldes osteonekrose. Med denne sygdom er dele af knoglevævet permanent beskadiget på grund af nedsat blodtilførsel til knoglerne. Personer, der kan have større risiko for at få denne tilstand:</p><ul><li><p>hvis de har fået kombinationsbehandling i lang tid</p></li><li><p>hvis de også tager en form for antiinflammatorisk (betændelsesdæmpende) medicin, der kaldes kortikosteroider</p></li><li><p>hvis de drikker alkohol</p></li><li><p>hvis deres immunforsvar er meget svækket</p></li><li><p>hvis de er overvægtige.</p></li></ul><p>Symptomerne på osteonekrose omfatter:</p><ul><li><p>stive led</p></li><li><p>ømhed og smerter i leddene (særligt i hofter, knæ eller skuldre)</p></li><li><p>bevægelsesbesvær.</p></li></ul><p>Hvis du bemærker nogen af disse symptomer: → Fortæl det til lægen.</p><p>Virkning på vægt, fedtstoffer i blodet og blodsukkeret: Under hiv-behandling kan der være en stigning i vægt og i niveauer af fedtstoffer og glukose i blodet. Dette er delvist knyttet til genoprettet helbred og livsstil og undertiden til hiv-medicinen selv. Din læge vil teste for disse ændringer. Indberetning af bivirkninger Hvis du oplever bivirkninger, bør du tale med din læge eller apotekspersonalet. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via det nationale rapporteringssystem anført i Appendix V. Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</p></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Opbevaring"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Opbevar lægemidlet utilgængeligt for børn.</p><p>Brug ikke lægemidlet efter den udløbsdato, der står på æsken og beholderen eller blisterkortet efter EXP. Udløbsdatoen er den sidste dag i den nævnte måned.</p><p>Dette lægemiddel kræver ingen særlige forholdsregler vedrørende opbevaringen.</p><p>Spørg apotekspersonalet, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.</p></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Pakningsstørrelser og yderligere oplysninger"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Dovato indeholder:</p><ul><li><p>Aktive stoffer: dolutegravir og lamivudin. Hver tablet indeholder dolutegravirnatrium svarende til 50 mg dolutegravir og 300 mg lamivudin.</p></li><li><p>Øvrige indholdsstoffer: mikrokrystallinsk cellulose, natriumstivelsesglycolat, magnesiumstearat, mannitol (E421), povidon (K29/32), natriumstearylfumarat, hypromellose (E464), macrogol, titandioxid (E171).</p></li><li><p>Dette lægemiddel indeholder mindre end 1 mmol (23 mg) natrium pr. tablet, dvs. det er i det væsentlige natriumfrit.</p></li></ul><p>Udseende og pakningsstørrelser</p><p>Dovato filmovertrukne tabletter er ovale, bikonvekse, hvide tabletter præget med \"SV 137\" på den ene side.</p><p>De filmovertrukne tabletter fås i beholdere, der er lukket med børnesikret lukke eller i børnesikrede blisterkort.</p><p>Beholder Hver beholder indeholder 30 filmovertrukne tabletter.</p><p>Fås også i multipakninger, der indeholder 90 filmovertrukne tabletter (3 beholdere à 30 filmovertrukne tabletter).</p><p>Blisterpakning Hver blisterpakning med 30 filmovertrukne tabletter består af 4 blisterkort, som hver indeholder 7 filmovertrukne tabletter og 1 blisterkort, som indeholder 2 filmovertrukne tabletter.</p><p>Fås også i multipakninger, der indeholder 90 filmovertrukne tabletter (3 blisterpakninger à filmovertrukne tabletter).</p><p>Ikke alle pakningsstørrelser er nødvendigvis markedsført i dit land.</p><p>Indehaver af markedsføringstilladelsen<br/>ViiV Healthcare BV Van Asch van Wijckstraat 55H 3811 LP Amersfoort Holland</p><p>Fremstiller Glaxo Wellcome, S.A.<br/>Avda. Extremadura, 3 09400 Aranda De Duero Burgos Spanien</p><p>Hvis du ønsker yderligere oplysninger om dette lægemiddel, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:</p><p>België/Belgique/Belgien ViiV Healthcare srl/bv<br/>Tél/Tel: + 32 (0) 10 85 65<br/>Lietuva ViiV Healthcare BV Tel: + 370 80000</p><p>България ViiV Healthcare BV Teл.: + 359 80018</p><p>Luxembourg/Luxemburg ViiV Healthcare srl/bv<br/>Belgique/Belgien Tél/Tel: + 32 (0) 10 85 65<br/>Česká republika GlaxoSmithKline, s.r.o. Tel: + 420 222 001 cz.info@gsk.com</p><p>Magyarország ViiV Healthcare BV. Tel.: + 36 80088 Danmark GlaxoSmithKline Pharma A/S Tlf: + 45 36 35 91 dk-info@gsk.com</p><p>Malta ViiV Healthcare BV Tel: + 356 80065 Deutschland ViiV Healthcare GmbH<br/>Tel.: + 49 (0)89 203 0038-10<br/>viiv.med.info@viivhealthcare.com</p><p>Nederland ViiV Healthcare BV<br/>Tel: + 31 (0)33 2081</p><p>Eesti ViiV Healthcare BV Tel: + 372 8002</p><p>Norge GlaxoSmithKline AS Tlf: + 47 22 70 20</p><p>Ελλάδα GlaxoSmithKline Μονοπρόσωπη A.E.B.E. Τηλ: + 30 210 68 82<br/>Österreich GlaxoSmithKline Pharma GmbH Tel: + 43 (0)1 97075 0 at.info@gsk.com</p><p>España</p><p>Polska Laboratorios ViiV Healthcare, S.L.<br/>Tel: + 34 900 923 501<br/>es-ci@viivhealthcare.com GSK Services Sp. z o.o. Tel.: + 48 (0)22 576 9</p><p>France ViiV Healthcare SAS<br/>Tél.: + 33 (0)1 39 17 69 Infomed@viivhealthcare.com</p><p>Portugal VIIVHIV HEALTHCARE, UNIPESSOAL, LDA<br/>Tel: + 351 21 094 08 01<br/>viiv.fi.pt@viivhealthcare.com</p><p>Hrvatska ViiV Healthcare BV Tel: + 385 800787 România ViiV Healthcare BV<br/>Tel: + 40800672 Ireland GlaxoSmithKline (Ireland) Limited Tel: + 353 (0)1 4955 Slovenija ViiV Healthcare BV Tel: + 386 80688</p><p>Ísland Vistor hf. Sími: +354 535 7 Slovenská republika ViiV Healthcare BV Tel: + 421 800500</p><p>Italia ViiV Healthcare S.r.l<br/>Tel: + 39 (0)45 7741 Suomi/Finland GlaxoSmithKline Oy Puh/Tel: + 358 (0)10 30 30</p><p>Κύπρος ViiV Healthcare BV Τηλ: + 357 80070</p><p>Sverige GlaxoSmithKline AB Tel: + 46 (0)8 638 93 info.produkt@gsk.com</p><p>Latvija ViiV Healthcare BV Tel: + 371 80205</p><p>United Kingdom (Northern Ireland) ViiV Healthcare BV Tel: + 44 (0)800 221customercontactuk@gsk.com</p><p>Denne indlægsseddel blev senest ændret {måned ÅÅÅÅ}.</p><p>Andre informationskilder</p><p>Du kan finde yderligere oplysninger om dette lægemiddel på Det Europæiske Lægemiddelagenturs hjemmeside: http://www.ema.europa.eu.</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-dolutegravirsodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-dolutegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-dolutegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-dolutegravirsodium</b></p><a name=\"ingredient-for-dovato-dolutegravirsodium\"> </a><a name=\"hcingredient-for-dovato-dolutegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/1Q1V9V5WYQ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 1Q1V9V5WYQ}\">DOLUTEGRAVIR SODIUM</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>50 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "1Q1V9V5WYQ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "1Q1V9V5WYQ",
              "display" : "DOLUTEGRAVIR SODIUM"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 50,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-lamivudine",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-lamivudine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-lamivudine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-lamivudine</b></p><a name=\"ingredient-for-dovato-lamivudine\"> </a><a name=\"hcingredient-for-dovato-lamivudine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/2T8Q726O95 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 2T8Q726O95}\">lamivudine</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>300 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "2T8Q726O95"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "2T8Q726O95",
              "display" : "lamivudine"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 300,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-microcrystallinecellulose</b></p><a name=\"ingredient-for-dovato-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-dovato-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-sodiumstarchglycolate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-sodiumstarchglycolate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-sodiumstarchglycolate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-sodiumstarchglycolate</b></p><a name=\"ingredient-for-dovato-sodiumstarchglycolate\"> </a><a name=\"hcingredient-for-dovato-sodiumstarchglycolate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/H8AV0SQX4D (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta H8AV0SQX4D}\">sodium starch glycolate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "H8AV0SQX4D"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "H8AV0SQX4D",
              "display" : "sodium starch glycolate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-magnesiumstearate</b></p><a name=\"ingredient-for-dovato-magnesiumstearate\"> </a><a name=\"hcingredient-for-dovato-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-mannitol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-mannitol",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-mannitol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-mannitol</b></p><a name=\"ingredient-for-dovato-mannitol\"> </a><a name=\"hcingredient-for-dovato-mannitol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/3OWL53L36A (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 3OWL53L36A}\">mannitol</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "3OWL53L36A"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "3OWL53L36A",
              "display" : "mannitol"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-dolutegravirsodium",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-dolutegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-dolutegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-dolutegravirsodium</b></p><a name=\"substance-dolutegravirsodium\"> </a><a name=\"hcsubstance-dolutegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/1Q1V9V5WYQ (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>441.36</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C20H18F2N305.Na</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(4R,12.ALPHA.S)-N-((2,4-DIFLUOROPHENYL)METHYL)-7-HYDROXY-4-METHYL-6,8-DIOXO-3,4,6,8,12,12.ALPHA.-HEXAHYDRO-2H-PYRIDO(1',2':4,5)PYRAZINO(2,1-.BETA.)(1,3)OXAZINE-9-CARBOXAMIDE</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "1Q1V9V5WYQ"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 441.36
        }
      }],
      "structure" : {
        "molecularFormula" : "C20H18F2N305.Na"
      },
      "name" : [{
        "name" : "(4R,12.ALPHA.S)-N-((2,4-DIFLUOROPHENYL)METHYL)-7-HYDROXY-4-METHYL-6,8-DIOXO-3,4,6,8,12,12.ALPHA.-HEXAHYDRO-2H-PYRIDO(1',2':4,5)PYRAZINO(2,1-.BETA.)(1,3)OXAZINE-9-CARBOXAMIDE",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-lamivudine",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-lamivudine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-lamivudine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-lamivudine</b></p><a name=\"substance-lamivudine\"> </a><a name=\"hcsubstance-lamivudine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/2T8Q726O95 (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>229.26</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C8H11N303S</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(-)-1-((2R,5S)-2-(HYDROXYMETHYL)-1,3-OXATHIOLAN-5-YL)CYTOSINE</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "2T8Q726O95"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 229.26
        }
      }],
      "structure" : {
        "molecularFormula" : "C8H11N303S"
      },
      "name" : [{
        "name" : "(-)-1-((2R,5S)-2-(HYDROXYMETHYL)-1,3-OXATHIOLAN-5-YL)CYTOSINE",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-49178f16170ee8a6bc2a4361c1748d5f",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-49178f16170ee8a6bc2a4361c1748d5f</b></p><a name=\"ap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><a name=\"hcap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "123456"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization49178f16170ee8a6bc2a4361c1748d5f0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization49178f16170ee8a6bc2a4361c1748d5f0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization49178f16170ee8a6bc2a4361c1748d5f0</b></p><a name=\"authorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><a name=\"hcauthorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2019-07-01 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mah-31ff1af739c7dcf77386a86f8dd83d29\">Organization ViiV Healthcare BV</a></p><p><b>regulator</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mra-7c9b97127f73ff3605a10eb1c2cc24d1\">Organization European Medicines Agency</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2019-07-01T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-31ff1af739c7dcf77386a86f8dd83d29"
      },
      "regulator" : {
        "reference" : "Organization/mra-7c9b97127f73ff3605a10eb1c2cc24d1"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/man-173fde4cb6b1018cb7ec8ab708d3961c",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "man-173fde4cb6b1018cb7ec8ab708d3961c",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization man-173fde4cb6b1018cb7ec8ab708d3961c</b></p><a name=\"man-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><a name=\"hcman-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100004538 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000033}\">Manufacturer</span></p><p><b>name</b>: GLAXO WELLCOME, S.A.</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Avda. Extremadura 3, 09400 Aranda De Duero Aranda De Duero ES(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100004538"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000033",
          "display" : "Manufacturer"
        }]
      }],
      "name" : "GLAXO WELLCOME, S.A.",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Avda. Extremadura 3, 09400 Aranda De Duero Aranda De Duero ES",
          "line" : ["Avda. Extremadura 3, 09400 Aranda De Duero"],
          "city" : "Aranda De Duero",
          "country" : "ES"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-31ff1af739c7dcf77386a86f8dd83d29",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-31ff1af739c7dcf77386a86f8dd83d29",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-31ff1af739c7dcf77386a86f8dd83d29</b></p><a name=\"mah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><a name=\"hcmah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100012958 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: ViiV Healthcare BV</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Van Asch van Wijckstraat 55H Amersfoort NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100012958"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "ViiV Healthcare BV",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Van Asch van Wijckstraat 55H Amersfoort NL",
          "line" : ["Van Asch van Wijckstraat 55H"],
          "city" : "Amersfoort",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mra-7c9b97127f73ff3605a10eb1c2cc24d1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mra-7c9b97127f73ff3605a10eb1c2cc24d1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mra-7c9b97127f73ff3605a10eb1c2cc24d1</b></p><a name=\"mra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><a name=\"hcmra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100013412 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000032}\">Medicines Regulatory Authority</span></p><p><b>name</b>: European Medicines Agency</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100013412"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000032",
          "display" : "Medicines Regulatory Authority"
        }]
      }],
      "name" : "European Medicines Agency",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL",
          "line" : ["Carretera De Martorell 41 61, Poligono Industrial Nord-Est"],
          "city" : "Amsterdam",
          "postalCode" : "1083 HS",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-2977a2afce16a0bd914b8d242dd126b5",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-2977a2afce16a0bd914b8d242dd126b5",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-2977a2afce16a0bd914b8d242dd126b5</b></p><a name=\"ppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><a name=\"hcppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>name</b>: Dovato 50 mg/300 mg film-coated tablets 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003203}\">Glass</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "name" : "Dovato 50 mg/300 mg film-coated tablets 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003203",
              "display" : "Glass"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp16598f252d07b4784b82ba43cf9e847e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp16598f252d07b4784b82ba43cf9e847e</b></p><a name=\"mp16598f252d07b4784b82ba43cf9e847e\"> </a><a name=\"hcmp16598f252d07b4784b82ba43cf9e847e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001, <code>https://www.who-umc.org/phpid</code>/0x073AF2E5B92AE19E8B67635AFFB3D6CA</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Dovato 50 mg/300 mg film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Dovato</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: dolutegravir/lamivudine</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 50 mg/300 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0x073AF2E5B92AE19E8B67635AFFB3D6CA"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Dovato 50 mg/300 mg film-coated tablets",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Dovato",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "dolutegravir/lamivudine",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "50 mg/300 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "film-coated tablets",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-49178f16170ee8a6bc2a4361c1748d5f",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-49178f16170ee8a6bc2a4361c1748d5f</b></p><a name=\"mid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><a name=\"hcmid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073665}\">Film-coated tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073665",
          "display" : "Film-coated tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }]
    }
  }]
}

```
