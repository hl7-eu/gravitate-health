# FK39570 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK39570**

## Example Bundle: FK39570

**Composition category:**

**Composition status:**final

### Indlægsseddel: Information til patienten

 

## Indlægsseddel: Information til patienten

### Imurel 25 mg og 50 mg filmovertrukne tabletter

azathioprin

### Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger.

* Gem indlægssedlen. Du kan få brug for at læse den igen.
* Spørg lægen, apotekspersonalet eller sundhedspersonalet, hvis der er mere, du vil vide.
* Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.
* Kontakt lægen, apotekspersonalet eller sundhedspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt her. Se [punkt 4](#Section4).

Se den nyeste indlægsseddel på
[www.indlaegsseddel.dk](https://www.indlaegsseddel.dk)

### Oversigt over indlægssedlen

1. Virkning og anvendelse
1. Det skal du vide, før du begynder at tage Imurel
1. Sådan skal du tage Imurel
1. Bivirkninger
1. Opbevaring
1. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

 

## 1. Virkning og anvendelse

Imurel indeholder det aktive stof azathioprin. Det tilhører en gruppe af lægemidler, som kaldes immunsuppressiva. Dette betyder, at de gør dit immunforsvar svagere.

 

Imurel kan anvendes for at hjælpe din krop med at acceptere et transplanteret organ, såsom en ny nyre, et nyt hjerte eller en ny lever, eller til at behandle nogle sygdomme, hvor dit immunsystem reagerer mod din egen krop (autoimmune sygdomme).

 

Autoimmune sygdomme kan omfatte:

* svær reumatoid artritis (en sygdom, hvor immunsystemet angriber celler i slimhinden i leddene, hvilket forårsager hævelse, smerte og stivhed i leddene),
* systemisk lupus erythematosus (en sygdom, hvor immunsystemet angriber mange af kroppens organer og væv, herunder hud, led, nyrer, hjerne og andre organer, hvilket forårsager svær træthed, feber, stivhed og ledsmerter),
* dermatomyositis og polymyositis (en gruppe af sygdomme, som forårsager betændelse i musklerne, muskelsvaghed og hududslæt),
* autoimmun kronisk aktiv hepatitis (en sygdom, hvor immunsystemet angriber levercellerne, hvilket forårsager leverbetændelse, træthed, muskelsmerter, gulfarvning af huden og feber),
* pemphigus vulgaris (en sygdom, hvor immunsystemet angriber hudceller, hvilket forårsager alvorlig blisterdannelse i huden, munden, næsen, svælget og på kønsdelene),
* polyarteritis nodosa (en sjælden sygdom, som forårsager betændelse i blodårerne),
* autoimmun hæmolytisk anæmi (en alvorlig blodsygdom, hvor kroppen nedbryder røde blodlegemer hurtigere end den kan producere nye, med symptomer som svaghed og åndenød),
* kronisk refraktær idiopatisk trombocytopenisk purpura (en lidelse med et lavt antal blodplader, der kan forårsage, at det er lettere at få voldsomme blå mærker og blødning).

 

Imurel kan også anvendes til behandling af inflammatorisk tarmsygdom (Crohns sygdom eller colitis ulcerosa).

 

Lægen har valgt denne medicin, så den passer til dig og din sygdom.

 

Imurel kan anvendes alene, men i de fleste tilfælde anvendes det sammen med andre lægemidler.


#### 2. Det skal du vide, før du begynder at tage Imurel

 

 

## 2. Det skal du vide, før du begynder at tage Imurel

Lægen kan have foreskrevet anden anvendelse eller dosering end angivet i denne information. Følg altid lægens anvisning og oplysningerne på doseringsetiketten.

### Tag ikke Imurel:

* hvis du er allergisk over for azathioprin eller et af de øvrige indholdsstoffer i Imurel (angivet i [punkt 6](#Section6))
* hvis du er allergisk over for mercaptopurin (et lægemiddel, som ligner azathioprin, som er det aktive stof i Imurel)

### Advarsler og forsigtighedsregler

Kontakt lægen eller apotekspersonalet før du tager Imurel:

* hvis du lige har fået eller snart skal have en vaccination (vaccine). Hvis du tager Imurel, bør du ikke få en vaccine med levende organismer (f.eks. influenzavaccine, mæslingevaccine, BCG-vaccine, osv.), før din læge siger, at det er sikkert. Dette skyldes, at nogle vacciner kan give dig en infektion, hvis du får dem, mens du tager Imurel
* hvis du har en genetisk sygdom, som kaldes LeschNyhans syndrom. Dette er en sjælden arvelig sygdom, som skyldes mangel på noget, som kaldes HPRT eller “hypoxantin-guanin-fosforibosyltransferase”
* hvis du har lever- eller nyreproblemer
* hvis du har en genetisk sygdom, som kaldes TPMT-mangel (hvor din krop producerer for lidt af et enzym, som kaldes thiopurinmethyltransferase)
* hvis du nogensinde har haft skoldkopper eller helvedesild
* hvis du har haft hepatitis B (en leversygdom, som skyldes en virus)
* hvis du skal have foretaget en operation (dette skyldes at lægemidler, herunder tubocurarin eller succinylcholin, som anvendes som muskelafslappende midler under en operation, kan interagere med Imurel. Før operationen skal du fortælle den læge, som skal bedøve dig, at du får behandling med Imurel.

 

**NUDT15-genmutation**

Hvis du har en nedarvet mutation i NUDT15-genet (et gen, som er medvirkende til nedbrydningen af Imurel i kroppen), har du en højere risiko for infektioner og hårtab, og din læge kan derfor give dig en lavere dosis.

Hvis du er usikker på, om noget af det ovenstående gælder for dig, skal du tale med lægen, sundhedspersonalet eller apotekspersonalet, før du tager Imurel.

Din læge vil
**regelmæssigt tage blodprøver **under behandlingen med Imurel for at tjekke for ændringer (se
[punkt 3](#Section3)”Sådan skal du tage Imurel”). Hyppigheden af blodprøverne vil normalt nedsættes, des længere du tager Imurel.

Hvis du får behandling, som undertrykker immunsystemet, kan behandling med Imurel medføre en øget risiko for:

* tumorer, herunder hudkræft. Når du tager Imurel, skal du derfor undgå for megen eksponering for sollys, og du skal bruge beskyttende påklædning og solcreme med en høj beskyttelsesfaktor.
* lymfoproliferative sygdomme
* behandling med Imurel øger risikoen for at få en type kræft, der kaldes ”lymfoproliferativ sygdom”. Ved behandlingsregimer, der består af flere immunsupprimerende lægemidler, herunder thiopuriner, kan dette medføre dødsfald.
* en kombination af flere immunsupprimerende lægemidler, der gives samtidigt, øger risikoen for sygdomme i lymfesystemet på grund af en virusinfektion (Epstein-Barr-virus-relaterede lymfoproliferative sygdomme).

* udvikling af en alvorlig lidelse, der hedder makrofag-aktiveringssyndrom (kraftig aktivering af hvide blodlegemer forbundet med en betændelseslignende reaktion (inflammation)). Denne lidelse ses typisk hos personer, der har visse typer leddegigt.
* alvorlig infektion med skoldkopper eller helvedesild. Derfor skal du undgå kontakt med personer, der har skoldkopper eller helvedesild, mens du tager Imurel.
* en tidligere infektion med hepatitis B, som bliver aktiv igen.
* andre infektioner, såsom PML (progressiv multifokal leukoencefalopati), som er en opportunistisk infektion. Hvis du får tegn på infektion, skal du kontakte din læge (se [punkt 4](#Section4) “Bivirkninger”).

### Brug af anden medicin sammen med Imurel

**Fortæl det altid til lægen eller apotekspersonalet, hvis du bruger anden medicin eller har brugt det for nylig. Dette skyldes at Imurel kan påvirke den måde, som andre lægemidler virker på. Andre lægemidler kan også påvirke den måde, som Imurel virker på. Det er især vigtigt, at du fortæller det til lægen, hvis du tager eller planlægger at tage:**

* ribavirin (anvendes til behandling af virusinfektioner)
* methotrexat (anvendes primært til behandling af kræft)
* allopurinol, oxipurinol, thiopurinol eller andre xanthinoxidasehæmmere, såsom febuxostat (anvendes primært til behandling af gigt)
* penicillamin (anvendes primært til behandling af reumatoid artritis)
* ACE-hæmmer (anvendes primært til behandling af højt blodtryk - hypertension)
* antikoagulantia, såsom warfarin eller acenocoumarol (anvendes til at forebygge blodpropper)
* cimetidin (anvendes til behandling af mavesår og fordøjelsesproblemer)
* indomethacin (anvendes som smertestillende og antiinflammatorisk (betændelseshæmmende) middel)
* cytostatiske lægemidler (lægemidler, som anvendes til behandling af forskellige former for kræft)
* aminosalicylater, f.eks. olsalazin, mesalazin eller sulfasalazin (anvendes primært til behandling af colitis ulcerosa og Crohns sygdom)
* co-trimoxazol (antibiotikum, anvendes til behandling af infektioner forårsaget af bakterier)
* infliximab (anvendes primært til behandling af colitis ulcerosa og Crohns sygdom)
* muskelafslappende midler, f.eks. tubocurarin eller succinylcholin (anvendes under operationer), da de kan interagere med Imurel. Før en operation skal du fortælle den læge, som skal bedøve dig, at du får behandling med azathioprin, da de muskelafslappende midler, der bliver anvendt til bedøvelse, kan interagere med azathioprin.

 

Hvis du er usikker på, om noget af det ovenstående gælder for dig, skal du tale med lægen eller apotekspersonalet, før du tager Imurel.

### Vaccination under behandlingen med Imurel

Hvis du skal have en vaccination (vaccine), skal du tale med lægen eller sundhedspersonalet, før du får den. Hvis du tager Imurel, bør du ikke få en vaccine med levende organismer (f.eks. influenzavaccine, mæslingevaccine, BCG-vaccine, osv.), før lægen siger, at det er sikkert. Dette skyldes, at nogle vacciner kan give dig en infektion, hvis du får dem, mens du tager Imurel.

### Brug af Imurel sammen med mad og drikke

Du skal tage lægemidlet mindst 1 time før eller 2 timer efter, du har indtaget mælk eller mælkeprodukter.

### Graviditet, amning og frugtbarhed

Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge eller apotekspersonalet til råds, før du tager dette lægemiddel.

 

**Graviditet**

For at undgå graviditet skal du og din partner skal anvende sikker prævention under behandlingen med Imurel.

 

Hvis du er gravid, vil din læge nøje overveje, om du skal tage dette lægemiddel, ved at vurdere fordele og ulemper ved behandlingen.

 

**Amning**

Der kan udskilles små mængder af Imurel i modermælken. Det anbefales, at kvinder, som får Imurel, undlader at amme, medmindre fordelene ved amning overstiger de mulige risici for barnet. Spørg din læge til råds, før du ammer.

 

**Frugtbarhed**

Virkningen af Imurel på frugtbarheden er ikke kendt.

### Trafik- og arbejdssikkerhed

Imurel menes ikke at påvirke evnen til at føre motorkøretøj eller betjene maskiner. Hvis du oplever bivirkninger af lægemidlet, kan det være, at du ikke kan føre motorkøretøj eller betjene maskiner.

### Imurel indeholder lactose

Kontakt lægen, før du tager denne medicin, hvis lægen har fortalt dig, at du ikke tåler visse sukkerarter.


#### 3. Sådan skal du tage Imurel

 

 

## 3. Sådan skal du tage Imurel

Tag altid Imurel nøjagtigt efter lægens anvisning. Er du i tvivl, så spørg lægen eller apotekspersonalet.

 

Mængden af Imurel varierer fra patient til patient, og ordineres af din læge. Dosis afhænger af, hvilken sygdom du behandles for.

 

Du kan tage Imurel sammen med mad eller på tom mave, men du skal tage Imurel på samme måde hver dag. Nogle patienter får kvalme, når de starter med at tage Imurel. Dette kan mindskes ved at tage tabletterne efter maden.

* Når du tager Imurel, vil din læge tage regelmæssige blodprøver. Dette er for at tjekke antallet og typen af celler i blodet, og for at sikre, at din lever fungerer, som den skal
* Din læge vil måske også foretage andre blod- og urinprøver, for at holde øje med, hvordan dine nyrer fungerer og for at måle urinsyreniveauet. Urinsyre er et naturligt stof, som produceres i kroppen, og niveauet af urinsyre kan stige, når du tager Imurel. Et højt niveau af urinsyre kan skade dine nyrer

 

Det kan være, at din læge ændrer din dosis af Imurel, på baggrund af resultaterne af disse prøver.

 

Synk tabletterne hele. Du må ikke tygge tabletterne. Tabletterne må ikke deles eller knuses.

Det er vigtigt, at omsorgspersoner er opmærksomme på nødvendigheden af sikker håndtering af lægemidlet. Hvis du eller din omsorgsperson håndterer delte tabletter, skal du eller din omsorgsperson omgående vaske hænder. Spørg din læge eller apotekspersonalet til råds.

### Den anbefalede dosis er:

**Voksne, som har fået foretaget en organtransplantation**: Den første behandlingsdag er den sædvanlige dosis op til 5 mg pr. kilo kropsvægt, herefter er den sædvanlige daglige dosis 1 mg til 4 mg pr. kilo kropsvægt. Lægen vil justere dosis under behandlingen, dette afhænger af, hvordan du reagerer på medicinen.

 

**Voksne med andre sygdomme:**Den sædvanlige startdosis er 1 mg til 3 mg pr. kilo kropsvægt, herefter er den sædvanlige daglige dosis mindre end 1 mg til 3 mg pr. kilo kropsvægt. Lægen vil justere dosis under behandlingen, dette afhænger af, hvordan du reagerer på medicinen.

 

Det kan være nødvendigt at reducere dosis til ældre patienter.

Det kan være nødvendigt at reducere dosis til patienter, som har nyre- eller leverproblemer.

### Brug til børn

**Børn, som har fået foretaget en organtransplantation:**Doseringen til børn, som har fået foretaget en organtransplantation, er den samme som til voksne.

 

**Børn med andre sygdomme: **Doseringen til børn med andre sygdomme er den samme som til voksne.

Børn, som er overvægtige, kan have brug for en højere dosis.

### Hvis du har taget for meget Imurel

Kontakt
**omgående **lægen, skadestuen eller apotekspersonalet, hvis du har taget mere af Imurel, end der står i denne information, eller mere end lægen har foreskrevet, og du føler dig utilpas.

### Hvis du har glemt at tage Imurel

Du må ikke tage en dobbeltdosis som erstatning for den glemte dosis. Fortæl det til lægen, hvis du har glemt at tage en dosis.

Hvis det er ved at være tid til den næste dosis, skal du springe den glemte dosis over, og tage den næste dosis, som du plejer. Ellers skal du tage den glemte dosis, så snart du kommer i tanker om det, og herefter tage Imurel, som du plejer.

### Hvis du holder op med at tage Imurel

Kontakt lægen eller apotekspersonalet før du stopper med at tage Imurel. Du må ikke stoppe med at tage Imurel, før din læge har sagt, at det er sikkert for dig at stoppe.

 

**Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.**


#### 4. Bivirkninger

 

 

## 4. Bivirkninger

Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger. Følgende bivirkninger kan forekomme med dette lægemiddel:

### Stop med at tage Imurel og kontakt omgående en læge, hvis du får en eller flere af de følgende alvorlige bivirkninger, da du kan have brug for akut lægehjælp:

* allergiske reaktioner (disse er ikke almindelige bivirkninger, som kan forekomme hos op til 1 ud af 100 personer), symptomerne kan omfatte:
* generel træthed, svimmelhed, kvalme, opkastning, diarré eller mavesmerter
* hævelse af øjenlågene, ansigtet eller læberne
* rødme af huden, knuder under huden eller hududslæt (herunder blistere, kløe eller afskalning af huden)
* smerter i musklerne eller leddene
* pludselig hvæsende vejrtrækning, hoste eller vejrtrækningsbesvær
I alvorlige tilfælde kan disse reaktioner være livstruende (dette er sjældent, og kan forekomme hos op til 1 ud af 1000 personer).

* hududslæt eller rødme, hvilket kan udvikle sig til livstruende hudreaktioner, herunder udbredt udslæt med blistere og afskalning af huden, som især optræder omkring munden, næsen, øjnene eller kønsdelene (Stevens-Johnson syndrom), voldsom afskalning af huden (toksisk epidermal nekrolyse) (disse kan være meget sjældne bivirkninger, som kan forekomme hos op til 1 ud af 10.000 personer)
* reversibel pneumonitis (lungebetændelse - forårsager åndenød, hoste og feber) (disse kan være meget sjældne bivirkninger, som kan forekomme hos op til 1 ud af 10.000 personer)
* problemer med dit blod eller din knoglemarv, symptomerne omfatter svaghed, træthed, bleghed, du let får blå mærker, usædvanlig blødning eller infektioner (disse kan være meget almindelige bivirkninger, som kan forekomme hos flere end 1 ud af 10 personer)
* når azathioprin anvendes samtidig med andre lægemidler, som undertrykker immunsystemet, kan du få en virus, som kan forårsage skade på din hjerne. Dette kan medføre hovedpine, adfærdsændringer, taleforstyrrelser, nedsatte færdigheder, såsom nedsat hukommelse, nedsat opmærksomhed og nedsat evne til at tage beslutninger (kognitiv tilbagegang), og det kan være dødeligt (tilstand kaldet JC-virus associeret progressiv multifokal leukoencefalopati) (disse kan være meget sjældne bivirkninger, som kan forekomme hos op til 1 ud af 10.000 personer)

### Kontakt omgående en læge eller specialist, hvis du får en eller flere af de følgende alvorlige bivirkninger, da du kan have brug for akut lægehjælp:

* du har feber eller andre tegn på en infektion, såsom øm hals, øm mund, vandladningsproblemer eller infektion i luftvejene, som forårsager åndenød og hoste (disse kan være meget almindelige bivirkninger, som kan forekomme hos flere end 1 ud af 10 personer)
* problemer med din lever, symptomerne omfatter gulfarvning af huden eller det hvide i øjnene (gulsot) (disse kan være ikke almindelige bivirkninger, som kan forekomme hos op til 1 ud af 100 personer)
* forskellige former for kræft, herunder blodkræft, lymfekræft eller hudkræft (se [punkt 2](#Section2) ”Advarsler og forsigtighedsregler”) (disse kan være sjældne bivirkninger, som kan forekomme hos op til 1 ud af 1000 personer)
* Sweets syndrom (også kendt som akut febril neutrofil dermatose). Du kan udvikle et udslæt (hævede røde, lyserøde eller lilla knuder, som er ømme, når de berøres), især på armene, hænderne, fingrene, ansigtet eller halsen, hvilket også kan ledsages af feber (det vides ikke, hvor ofte disse bivirkninger forekommer - kan ikke bestemmes ud fra de tilgængelige data)
* en bestemt form for lymfomer (hepatosplenisk T-celle lymfom). Du kan opleve næseblod, træthed, voldsom nattesved, vægttab og uforklarlig feber (det vides ikke, hvor ofte disse bivirkninger forekommer - kan ikke bestemmes ud fra de tilgængelige data)

 

Hvis du oplever noget af det ovenstående, skal du stoppe med at tage Imurel og kontakte en læge omgående.

### Andre bivirkninger omfatter:

**Meget almindelig (kan forekomme hos flere end 1 ud af 10 personer)**

* lavt antal hvide blodlegemer i blodet, hvilket kan forårsage en infektion

 

**Almindelig (kan forekomme hos op til 1 ud af 10 personer)**

* kvalme

 

**Ikke almindelig (kan forekomme hos op til 1 ud af 100 personer)**

* anæmi (lavt antal røde blodlegemer i blodet)
* pancreatitis (betændelse i bugspytkirtlen), hvilket kan forårsage svære smerter i den øvre del af maven

 

**Sjælden (kan forekomme hos op til 1 ud af 1000 personer)**

* Du kan opleve hårtab, mens du tager Imurel. Oftest gror håret ud igen, også selvom du fortsætter med at tage Imurel. Tal med din læge, hvis du er bekymret.

 

**Meget sjælden (kan forekomme hos op til 1 ud af 10.000 personer)**

* tarmproblemer, som kan forårsage diarré, mavesmerter, forstoppelse, kvalme eller opkastninger (hul på tarmen)

 

**Ikke kendt (hyppigheden kan ikke bestemmes ud fra de tilgængelige data)**

* fotosensitivitet (følsomhed over for lys eller sollys)

### Indberetning af bivirkninger

Hvis du oplever bivirkninger, bør du tale med din læge, sygeplejerske eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via:

Lægemiddelstyrelsen

Axel Heides Gade 1

DK-2300 København S

Websted: www.meldenbivirkning.dk

 

Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.

[Meld en bivirkning.](https://www.meldenbivirkning.dk)


#### 5. Opbevaring

 

 

## 5. Opbevaring

Opbevar lægemidlet utilgængeligt for børn.

 

Dette lægemiddel kræver ingen særlige forholdsregler vedrørende opbevaringen.

 

Brug ikke Imurel efter den udløbsdato, der står på pakningen. Udløbsdatoen er den sidste dag i den nævnte måned.

 

Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

 

## 6. Pakningsstørrelser og yderligere oplysninger

### Imurel 25 og 50 mg overtrukne tabletter indeholder:

Aktivt stof: Azathioprin.

Øvrige indholdsstoffer: Lactose, majsstivelse, pregelatineret stivelse, stearinsyre, magnesiumstearat, hypromellose og macrogol.

Imurel 25 mg filmovertrukne tabletter indeholder også titandioxid (E171) og jernoxid (E172).

### Udseende og pakningsstørrelser

**Udseende**

Imurel 25 mg er en rund, orange bikonveks filmovertrukket tablet. Tabletten er præget IM 2 på den ene side.

Imurel 50 mg er en rund, gul bikonveks filmovertrukket tablet. Tabletten er præget IM 5 på den ene side.

 

**Pakningsstørrelser**

Imurel 25 mg findes i blisterpakninger med 50 tabletter.

Imurel 50 mg findes i blisterpakninger med 50 og 100 tabletter.

Ikke alle pakningsstørrelser er nødvendigvis markedsført.


####  Imurel tab 25 mg 
LEGEMIDDELMERKEVAREID:
** ID_72CA1852-ECDA-4096-A284-C4EDDA63602D **
-------

Full name: **Imurel tab 25 mg**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 2

LEGEMIDDELPAKNINGID: ** ID_B896FBA6-8A32-4436-9644-0295166F6E2C ** 

VARENUMMER: ** 073947 ** 

VNR: ** 073947 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK39570",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
    "value" : "39570"
  },
  "type" : "document",
  "timestamp" : "2022-04-20T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK39570-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK39570-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_FK39570-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK39570-COMP</b></p><a name=\"FK39570-COMP\"> </a><a name=\"hcFK39570-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/</code>/39570</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2022-04-20</p><p><b>author</b>: Identifier: <code>https://medicin.dk</code>/medicin.dk</p><p><b>title</b>: Imurel® 25 mg og 50 mg filmovertrukne tabletter</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
        "value" : "39570"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-8"
      },
      {
        "reference" : "MedicinalProductDefinition/IBD-MPD-10"
      }],
      "date" : "2022-04-20",
      "author" : [{
        "identifier" : {
          "system" : "https://medicin.dk",
          "value" : "medicin.dk"
        }
      }],
      "title" : "Imurel® 25 mg og 50 mg filmovertrukne tabletter",
      "section" : [{
        "title" : "Indlægsseddel: Information til patienten",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section0\"/><h2>Indlægsseddel: Information til patienten</h2><h3>Imurel 25 mg og 50 mg filmovertrukne tabletter</h3><div class=\"paragraph\">azathioprin</div><h3>Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger.</h3><ul><li>Gem indlægssedlen. Du kan få brug for at læse den igen.</li><li>Spørg lægen, apotekspersonalet eller sundhedspersonalet, hvis der er mere, du vil vide.</li><li>Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.</li><li>Kontakt lægen, apotekspersonalet eller sundhedspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt her. Se <a href=\"#Section4\" title=\"Anchor link til afsnit - punkt 4\">punkt 4</a>.</li></ul><div class=\"paragraph\">Se den nyeste indlægsseddel på <a href=\"https://www.indlaegsseddel.dk\" title=\"null\">www.indlaegsseddel.dk</a></div><h3>Oversigt over indlægssedlen</h3><ol><li>Virkning og anvendelse</li><li>Det skal du vide, før du begynder at tage Imurel</li><li>Sådan skal du tage Imurel</li><li>Bivirkninger</li><li>Opbevaring</li><li>Pakningsstørrelser og yderligere oplysninger</li></ol></div>"
        },
        "section" : [{
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section1\"/><div> </div><h2>1. Virkning og anvendelse</h2><div class=\"paragraph\">Imurel indeholder det aktive stof azathioprin. Det tilhører en gruppe af lægemidler, som kaldes immunsuppressiva. Dette betyder, at de gør dit immunforsvar svagere.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Imurel kan anvendes for at hjælpe din krop med at acceptere et transplanteret organ, såsom en ny nyre, et nyt hjerte eller en ny lever, eller til at behandle nogle sygdomme, hvor dit immunsystem reagerer mod din egen krop (autoimmune sygdomme).</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Autoimmune sygdomme kan omfatte:</div><ul><li>svær reumatoid artritis (en sygdom, hvor immunsystemet angriber celler i slimhinden i leddene, hvilket forårsager hævelse, smerte og stivhed i leddene),</li><li>systemisk lupus erythematosus (en sygdom, hvor immunsystemet angriber mange af kroppens organer og væv, herunder hud, led, nyrer, hjerne og andre organer, hvilket forårsager svær træthed, feber, stivhed og ledsmerter),</li><li>dermatomyositis og polymyositis (en gruppe af sygdomme, som forårsager betændelse i musklerne, muskelsvaghed og hududslæt),</li><li>autoimmun kronisk aktiv hepatitis (en sygdom, hvor immunsystemet angriber levercellerne, hvilket forårsager leverbetændelse, træthed, muskelsmerter, gulfarvning af huden og feber),</li><li>pemphigus vulgaris (en sygdom, hvor immunsystemet angriber hudceller, hvilket forårsager alvorlig blisterdannelse i huden, munden, næsen, svælget og på kønsdelene),</li><li>polyarteritis nodosa (en sjælden sygdom, som forårsager betændelse i blodårerne),</li><li>autoimmun hæmolytisk anæmi (en alvorlig blodsygdom, hvor kroppen nedbryder røde blodlegemer hurtigere end den kan producere nye, med symptomer som svaghed og åndenød),</li><li>kronisk refraktær idiopatisk trombocytopenisk purpura (en lidelse med et lavt antal blodplader, der kan forårsage, at det er lettere at få voldsomme blå mærker og blødning).</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Imurel kan også anvendes til behandling af inflammatorisk tarmsygdom (Crohns sygdom eller colitis ulcerosa).</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Lægen har valgt denne medicin, så den passer til dig og din sygdom.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Imurel kan anvendes alene, men i de fleste tilfælde anvendes det sammen med andre lægemidler.</div></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du begynder at tage Imurel",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section2\"/><div> </div><h2>2. Det skal du vide, før du begynder at tage Imurel</h2><div class=\"paragraph\">Lægen kan have foreskrevet anden anvendelse eller dosering end angivet i denne information. Følg altid lægens anvisning og oplysningerne på doseringsetiketten.</div><h3>Tag ikke Imurel:</h3><ul><li>hvis du er allergisk over for azathioprin eller et af de øvrige indholdsstoffer i Imurel (angivet i <a href=\"#Section6\" title=\"Anchor link til afsnit - punkt 6\">punkt 6</a>)</li><li>hvis du er allergisk over for mercaptopurin (et lægemiddel, som ligner azathioprin, som er det aktive stof i Imurel)</li></ul><h3>Advarsler og forsigtighedsregler</h3><div class=\"paragraph\">Kontakt lægen eller apotekspersonalet før du tager Imurel:</div><ul><li>hvis du lige har fået eller snart skal have en vaccination (vaccine). Hvis du tager Imurel, bør du ikke få en vaccine med levende organismer (f.eks. influenzavaccine, mæslingevaccine, BCG-vaccine, osv.), før din læge siger, at det er sikkert. Dette skyldes, at nogle vacciner kan give dig en infektion, hvis du får dem, mens du tager Imurel</li><li>hvis du har en genetisk sygdom, som kaldes LeschNyhans syndrom. Dette er en sjælden arvelig sygdom, som skyldes mangel på noget, som kaldes HPRT eller “hypoxantin-guanin-fosforibosyltransferase”</li><li>hvis du har lever- eller nyreproblemer</li><li>hvis du har en genetisk sygdom, som kaldes TPMT-mangel (hvor din krop producerer for lidt af et enzym, som kaldes thiopurinmethyltransferase)</li><li>hvis du nogensinde har haft skoldkopper eller helvedesild</li><li>hvis du har haft hepatitis B (en leversygdom, som skyldes en virus)</li><li>hvis du skal have foretaget en operation (dette skyldes at lægemidler, herunder tubocurarin eller succinylcholin, som anvendes som muskelafslappende midler under en operation, kan interagere med Imurel. Før operationen skal du fortælle den læge, som skal bedøve dig, at du får behandling med Imurel.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>NUDT15-genmutation</b><br/>Hvis du har en nedarvet mutation i NUDT15-genet (et gen, som er medvirkende til nedbrydningen af Imurel i kroppen), har du en højere risiko for infektioner og hårtab, og din læge kan derfor give dig en lavere dosis.</div><div class=\"paragraph\"><br/>Hvis du er usikker på, om noget af det ovenstående gælder for dig, skal du tale med lægen, sundhedspersonalet eller apotekspersonalet, før du tager Imurel.</div><div class=\"paragraph\"><br/>Din læge vil <b>regelmæssigt tage blodprøver </b>under behandlingen med Imurel for at tjekke for ændringer (se <a href=\"#Section3\" title=\"Anchor link til afsnit - punkt 3\">punkt 3</a> ”Sådan skal du tage Imurel”). Hyppigheden af blodprøverne vil normalt nedsættes, des længere du tager Imurel.</div><div class=\"paragraph\"><br/>Hvis du får behandling, som undertrykker immunsystemet, kan behandling med Imurel medføre en øget risiko for:</div><ul><li>tumorer, herunder hudkræft. Når du tager Imurel, skal du derfor undgå for megen eksponering for sollys, og du skal bruge beskyttende påklædning og solcreme med en høj beskyttelsesfaktor.</li><li>lymfoproliferative sygdomme<ul><li>behandling med Imurel øger risikoen for at få en type kræft, der kaldes ”lymfoproliferativ sygdom”. Ved behandlingsregimer, der består af flere immunsupprimerende lægemidler, herunder thiopuriner, kan dette medføre dødsfald.</li><li>en kombination af flere immunsupprimerende lægemidler, der gives samtidigt, øger risikoen for sygdomme i lymfesystemet på grund af en virusinfektion (Epstein-Barr-virus-relaterede lymfoproliferative sygdomme).</li></ul></li><li>udvikling af en alvorlig lidelse, der hedder makrofag-aktiveringssyndrom (kraftig aktivering af hvide blodlegemer forbundet med en betændelseslignende reaktion (inflammation)). Denne lidelse ses typisk hos personer, der har visse typer leddegigt.</li><li>alvorlig infektion med skoldkopper eller helvedesild. Derfor skal du undgå kontakt med personer, der har skoldkopper eller helvedesild, mens du tager Imurel.</li><li>en tidligere infektion med hepatitis B, som bliver aktiv igen.</li><li>andre infektioner, såsom PML (progressiv multifokal leukoencefalopati), som er en opportunistisk infektion. Hvis du får tegn på infektion, skal du kontakte din læge (se <a href=\"#Section4\" title=\"Anchor link til afsnit - punkt 4\">punkt 4</a> “Bivirkninger”).</li></ul><h3>Brug af anden medicin sammen med Imurel</h3><div class=\"paragraph\"><b>Fortæl det altid til lægen eller apotekspersonalet, hvis du bruger anden medicin eller har brugt det for nylig. Dette skyldes at Imurel kan påvirke den måde, som andre lægemidler virker på. Andre lægemidler kan også påvirke den måde, som Imurel virker på. Det er især vigtigt, at du fortæller det til lægen, hvis du tager eller planlægger at tage:</b></div><ul><li>ribavirin (anvendes til behandling af virusinfektioner)</li><li>methotrexat (anvendes primært til behandling af kræft)</li><li>allopurinol, oxipurinol, thiopurinol eller andre xanthinoxidasehæmmere, såsom febuxostat (anvendes primært til behandling af gigt)</li><li>penicillamin (anvendes primært til behandling af reumatoid artritis)</li><li>ACE-hæmmer (anvendes primært til behandling af højt blodtryk - hypertension)</li><li>antikoagulantia, såsom warfarin eller acenocoumarol (anvendes til at forebygge blodpropper)</li><li>cimetidin (anvendes til behandling af mavesår og fordøjelsesproblemer)</li><li>indomethacin (anvendes som smertestillende og antiinflammatorisk (betændelseshæmmende) middel)</li><li>cytostatiske lægemidler (lægemidler, som anvendes til behandling af forskellige former for kræft)</li><li>aminosalicylater, f.eks. olsalazin, mesalazin eller sulfasalazin (anvendes primært til behandling af colitis ulcerosa og Crohns sygdom)</li><li>co-trimoxazol (antibiotikum, anvendes til behandling af infektioner forårsaget af bakterier)</li><li>infliximab (anvendes primært til behandling af colitis ulcerosa og Crohns sygdom)</li><li>muskelafslappende midler, f.eks. tubocurarin eller succinylcholin (anvendes under operationer), da de kan interagere med Imurel. Før en operation skal du fortælle den læge, som skal bedøve dig, at du får behandling med azathioprin, da de muskelafslappende midler, der bliver anvendt til bedøvelse, kan interagere med azathioprin.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du er usikker på, om noget af det ovenstående gælder for dig, skal du tale med lægen eller apotekspersonalet, før du tager Imurel.</div><h3>Vaccination under behandlingen med Imurel</h3><div class=\"paragraph\">Hvis du skal have en vaccination (vaccine), skal du tale med lægen eller sundhedspersonalet, før du får den. Hvis du tager Imurel, bør du ikke få en vaccine med levende organismer (f.eks. influenzavaccine, mæslingevaccine, BCG-vaccine, osv.), før lægen siger, at det er sikkert. Dette skyldes, at nogle vacciner kan give dig en infektion, hvis du får dem, mens du tager Imurel.</div><h3>Brug af Imurel sammen med mad og drikke</h3><div class=\"paragraph\">Du skal tage lægemidlet mindst 1 time før eller 2 timer efter, du har indtaget mælk eller mælkeprodukter.</div><h3>Graviditet, amning og frugtbarhed</h3><div class=\"paragraph\">Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge eller apotekspersonalet til råds, før du tager dette lægemiddel.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Graviditet</b></div><div class=\"paragraph\">For at undgå graviditet skal du og din partner skal anvende sikker prævention under behandlingen med Imurel.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du er gravid, vil din læge nøje overveje, om du skal tage dette lægemiddel, ved at vurdere fordele og ulemper ved behandlingen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Amning</b></div><div class=\"paragraph\">Der kan udskilles små mængder af Imurel i modermælken. Det anbefales, at kvinder, som får Imurel, undlader at amme, medmindre fordelene ved amning overstiger de mulige risici for barnet. Spørg din læge til råds, før du ammer.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Frugtbarhed</b></div><div class=\"paragraph\">Virkningen af Imurel på frugtbarheden er ikke kendt.</div><h3>Trafik- og arbejdssikkerhed</h3><div class=\"paragraph\">Imurel menes ikke at påvirke evnen til at føre motorkøretøj eller betjene maskiner. Hvis du oplever bivirkninger af lægemidlet, kan det være, at du ikke kan føre motorkøretøj eller betjene maskiner.</div><h3>Imurel indeholder lactose</h3><div class=\"paragraph\">Kontakt lægen, før du tager denne medicin, hvis lægen har fortalt dig, at du ikke tåler visse sukkerarter.</div></div>"
          }
        },
        {
          "title" : "3. Sådan skal du tage Imurel",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section3\"/><div> </div><h2>3. Sådan skal du tage Imurel</h2><div class=\"paragraph\">Tag altid Imurel nøjagtigt efter lægens anvisning. Er du i tvivl, så spørg lægen eller apotekspersonalet.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Mængden af Imurel varierer fra patient til patient, og ordineres af din læge. Dosis afhænger af, hvilken sygdom du behandles for.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Du kan tage Imurel sammen med mad eller på tom mave, men du skal tage Imurel på samme måde hver dag. Nogle patienter får kvalme, når de starter med at tage Imurel. Dette kan mindskes ved at tage tabletterne efter maden.</div><ul><li>Når du tager Imurel, vil din læge tage regelmæssige blodprøver. Dette er for at tjekke antallet og typen af celler i blodet, og for at sikre, at din lever fungerer, som den skal</li><li>Din læge vil måske også foretage andre blod- og urinprøver, for at holde øje med, hvordan dine nyrer fungerer og for at måle urinsyreniveauet. Urinsyre er et naturligt stof, som produceres i kroppen, og niveauet af urinsyre kan stige, når du tager Imurel. Et højt niveau af urinsyre kan skade dine nyrer</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Det kan være, at din læge ændrer din dosis af Imurel, på baggrund af resultaterne af disse prøver.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Synk tabletterne hele. Du må ikke tygge tabletterne. Tabletterne må ikke deles eller knuses.</div><div class=\"paragraph\"><br/>Det er vigtigt, at omsorgspersoner er opmærksomme på nødvendigheden af sikker håndtering af lægemidlet. Hvis du eller din omsorgsperson håndterer delte tabletter, skal du eller din omsorgsperson omgående vaske hænder. Spørg din læge eller apotekspersonalet til råds.</div><h3>Den anbefalede dosis er:</h3><div class=\"paragraph\"><b>Voksne, som har fået foretaget en organtransplantation</b>: Den første behandlingsdag er den sædvanlige dosis op til 5 mg pr. kilo kropsvægt, herefter er den sædvanlige daglige dosis 1 mg til 4 mg pr. kilo kropsvægt. Lægen vil justere dosis under behandlingen, dette afhænger af, hvordan du reagerer på medicinen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Voksne med andre sygdomme:</b> Den sædvanlige startdosis er 1 mg til 3 mg pr. kilo kropsvægt, herefter er den sædvanlige daglige dosis mindre end 1 mg til 3 mg pr. kilo kropsvægt. Lægen vil justere dosis under behandlingen, dette afhænger af, hvordan du reagerer på medicinen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Det kan være nødvendigt at reducere dosis til ældre patienter.</div><div class=\"paragraph\"><br/>Det kan være nødvendigt at reducere dosis til patienter, som har nyre- eller leverproblemer.</div><h3>Brug til børn</h3><div class=\"paragraph\"><b>Børn, som har fået foretaget en organtransplantation:</b> Doseringen til børn, som har fået foretaget en organtransplantation, er den samme som til voksne.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Børn med andre sygdomme: </b>Doseringen til børn med andre sygdomme er den samme som til voksne.</div><div class=\"paragraph\">Børn, som er overvægtige, kan have brug for en højere dosis.</div><h3>Hvis du har taget for meget Imurel</h3><div class=\"paragraph\">Kontakt <b>omgående </b>lægen, skadestuen eller apotekspersonalet, hvis du har taget mere af Imurel, end der står i denne information, eller mere end lægen har foreskrevet, og du føler dig utilpas.</div><h3>Hvis du har glemt at tage Imurel</h3><div class=\"paragraph\">Du må ikke tage en dobbeltdosis som erstatning for den glemte dosis. Fortæl det til lægen, hvis du har glemt at tage en dosis.</div><div class=\"paragraph\"><br/>Hvis det er ved at være tid til den næste dosis, skal du springe den glemte dosis over, og tage den næste dosis, som du plejer. Ellers skal du tage den glemte dosis, så snart du kommer i tanker om det, og herefter tage Imurel, som du plejer.</div><h3>Hvis du holder op med at tage Imurel</h3><div class=\"paragraph\">Kontakt lægen eller apotekspersonalet før du stopper med at tage Imurel. Du må ikke stoppe med at tage Imurel, før din læge har sagt, at det er sikkert for dig at stoppe.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.</b></div></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section4\"/><div> </div><h2>4. Bivirkninger</h2><div class=\"paragraph\">Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger. Følgende bivirkninger kan forekomme med dette lægemiddel:</div><h3>Stop med at tage Imurel og kontakt omgående en læge, hvis du får en eller flere af de følgende alvorlige bivirkninger, da du kan have brug for akut lægehjælp:</h3><ul><li>allergiske reaktioner (disse er ikke almindelige bivirkninger, som kan forekomme hos op til 1 ud af 100 personer), symptomerne kan omfatte:<ul><li>generel træthed, svimmelhed, kvalme, opkastning, diarré eller mavesmerter</li><li>hævelse af øjenlågene, ansigtet eller læberne</li><li>rødme af huden, knuder under huden eller hududslæt (herunder blistere, kløe eller afskalning af huden)</li><li>smerter i musklerne eller leddene</li><li>pludselig hvæsende vejrtrækning, hoste eller vejrtrækningsbesvær<br/>I alvorlige tilfælde kan disse reaktioner være livstruende (dette er sjældent, og kan forekomme hos op til 1 ud af 1000 personer).</li></ul></li><li>hududslæt eller rødme, hvilket kan udvikle sig til livstruende hudreaktioner, herunder udbredt udslæt med blistere og afskalning af huden, som især optræder omkring munden, næsen, øjnene eller kønsdelene (Stevens-Johnson syndrom), voldsom afskalning af huden (toksisk epidermal nekrolyse) (disse kan være meget sjældne bivirkninger, som kan forekomme hos op til 1 ud af 10.000 personer)</li><li>reversibel pneumonitis (lungebetændelse - forårsager åndenød, hoste og feber) (disse kan være meget sjældne bivirkninger, som kan forekomme hos op til 1 ud af 10.000 personer)</li><li>problemer med dit blod eller din knoglemarv, symptomerne omfatter svaghed, træthed, bleghed, du let får blå mærker, usædvanlig blødning eller infektioner (disse kan være meget almindelige bivirkninger, som kan forekomme hos flere end 1 ud af 10 personer)</li><li>når azathioprin anvendes samtidig med andre lægemidler, som undertrykker immunsystemet, kan du få en virus, som kan forårsage skade på din hjerne. Dette kan medføre hovedpine, adfærdsændringer, taleforstyrrelser, nedsatte færdigheder, såsom nedsat hukommelse, nedsat opmærksomhed og nedsat evne til at tage beslutninger (kognitiv tilbagegang), og det kan være dødeligt (tilstand kaldet JC-virus associeret progressiv multifokal leukoencefalopati) (disse kan være meget sjældne bivirkninger, som kan forekomme hos op til 1 ud af 10.000 personer)</li></ul><h3>Kontakt omgående en læge eller specialist, hvis du får en eller flere af de følgende alvorlige bivirkninger, da du kan have brug for akut lægehjælp:</h3><ul><li>du har feber eller andre tegn på en infektion, såsom øm hals, øm mund, vandladningsproblemer eller infektion i luftvejene, som forårsager åndenød og hoste (disse kan være meget almindelige bivirkninger, som kan forekomme hos flere end 1 ud af 10 personer)</li><li>problemer med din lever, symptomerne omfatter gulfarvning af huden eller det hvide i øjnene (gulsot) (disse kan være ikke almindelige bivirkninger, som kan forekomme hos op til 1 ud af 100 personer)</li><li>forskellige former for kræft, herunder blodkræft, lymfekræft eller hudkræft (se <a href=\"#Section2\" title=\"Anchor link til afsnit - punkt 2\">punkt 2</a> ”Advarsler og forsigtighedsregler”) (disse kan være sjældne bivirkninger, som kan forekomme hos op til 1 ud af 1000 personer)</li><li>Sweets syndrom (også kendt som akut febril neutrofil dermatose). Du kan udvikle et udslæt (hævede røde, lyserøde eller lilla knuder, som er ømme, når de berøres), især på armene, hænderne, fingrene, ansigtet eller halsen, hvilket også kan ledsages af feber (det vides ikke, hvor ofte disse bivirkninger forekommer - kan ikke bestemmes ud fra de tilgængelige data)</li><li>en bestemt form for lymfomer (hepatosplenisk T-celle lymfom). Du kan opleve næseblod, træthed, voldsom nattesved, vægttab og uforklarlig feber (det vides ikke, hvor ofte disse bivirkninger forekommer - kan ikke bestemmes ud fra de tilgængelige data)</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du oplever noget af det ovenstående, skal du stoppe med at tage Imurel og kontakte en læge omgående.</div><h3>Andre bivirkninger omfatter:</h3><div class=\"paragraph\"><b>Meget almindelig (kan forekomme hos flere end 1 ud af 10 personer)</b></div><ul><li>lavt antal hvide blodlegemer i blodet, hvilket kan forårsage en infektion</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Almindelig (kan forekomme hos op til 1 ud af 10 personer)</b></div><ul><li>kvalme</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ikke almindelig (kan forekomme hos op til 1 ud af 100 personer)</b></div><ul><li>anæmi (lavt antal røde blodlegemer i blodet)</li><li>pancreatitis (betændelse i bugspytkirtlen), hvilket kan forårsage svære smerter i den øvre del af maven</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Sjælden (kan forekomme hos op til 1 ud af 1000 personer)</b></div><ul><li>Du kan opleve hårtab, mens du tager Imurel. Oftest gror håret ud igen, også selvom du fortsætter med at tage Imurel. Tal med din læge, hvis du er bekymret.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Meget sjælden (kan forekomme hos op til 1 ud af 10.000 personer)</b></div><ul><li>tarmproblemer, som kan forårsage diarré, mavesmerter, forstoppelse, kvalme eller opkastninger (hul på tarmen)</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ikke kendt (hyppigheden kan ikke bestemmes ud fra de tilgængelige data)</b></div><ul><li>fotosensitivitet (følsomhed over for lys eller sollys)</li></ul><h3>Indberetning af bivirkninger</h3><div class=\"paragraph\">Hvis du oplever bivirkninger, bør du tale med din læge, sygeplejerske eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via:</div><div class=\"paragraph\"><br/>Lægemiddelstyrelsen</div><div class=\"paragraph\">Axel Heides Gade 1</div><div class=\"paragraph\">DK-2300 København S<br/>Websted: www.meldenbivirkning.dk</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</div><div class=\"paragraph\"><a href=\"https://www.meldenbivirkning.dk\" title=\"Meld en bivirkning\">Meld en bivirkning.</a></div></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section5\"/><div> </div><h2>5. Opbevaring</h2><div class=\"paragraph\">Opbevar lægemidlet utilgængeligt for børn.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Dette lægemiddel kræver ingen særlige forholdsregler vedrørende opbevaringen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Brug ikke Imurel efter den udløbsdato, der står på pakningen. Udløbsdatoen er den sidste dag i den nævnte måned.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.</div></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section6\"/><div> </div><h2>6. Pakningsstørrelser og yderligere oplysninger</h2><h3>Imurel 25 og 50 mg overtrukne tabletter indeholder:</h3><div class=\"paragraph\">Aktivt stof: Azathioprin.</div><div class=\"paragraph\">Øvrige indholdsstoffer: Lactose, majsstivelse, pregelatineret stivelse, stearinsyre, magnesiumstearat, hypromellose og macrogol.</div><div class=\"paragraph\">Imurel 25 mg filmovertrukne tabletter indeholder også titandioxid (E171) og jernoxid (E172).</div><h3>Udseende og pakningsstørrelser</h3><div class=\"paragraph\"><b>Udseende</b></div><div class=\"paragraph\">Imurel 25 mg er en rund, orange bikonveks filmovertrukket tablet. Tabletten er præget IM 2 på den ene side.<br/>Imurel 50 mg er en rund, gul bikonveks filmovertrukket tablet. Tabletten er præget IM 5 på den ene side.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Pakningsstørrelser</b></div><div class=\"paragraph\">Imurel 25 mg findes i blisterpakninger med 50 tabletter.<br/>Imurel 50 mg findes i blisterpakninger med 50 og 100 tabletter.<br/>Ikke alle pakningsstørrelser er nødvendigvis markedsført.</div></div>"
          },
          "section" : [{
            "title" : "Indehaver af markedsføringstilladelsen og fremstiller",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Indehaver af markedsføringstilladelsen og fremstiller</h2><h3>Indehaveren af markedsføringstilladelsen</h3><div class=\"paragraph\">Aspen Pharma Trading Limited</div><div class=\"paragraph\">3016 Lake Drive,</div><div class=\"paragraph\">Citywest Business Campus,</div><div class=\"paragraph\">Dublin 24, Irland</div><div class=\"paragraph\">Tel: +45 78 77 28 87</div><h3>Fremstiller</h3><div class=\"paragraph\">Excella GmbH &amp;amp; Co. KG</div><div class=\"paragraph\">Nürnberger Strasse 12</div><div class=\"paragraph\">90537 Feucht</div><div class=\"paragraph\">Tyskland</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Aspen Bad Oldesloe GmbH</div><div class=\"paragraph\">32-36 Industriestrasse</div><div class=\"paragraph\">23843 Bad Oldesloe</div><div class=\"paragraph\">Tyskland</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du ønsker yderligere oplysninger om dette lægemiddel, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:</div><div class=\"paragraph\"><b>Repræsentant</b></div><div class=\"paragraph\">Aspen Nordic</div><div class=\"paragraph\">Branch Office of Aspen Pharma Ireland Ltd.</div><div class=\"paragraph\">Borupvang 3</div><div class=\"paragraph\">2750 Ballerup</div><div class=\"paragraph\">Danmark</div><div class=\"paragraph\">Tlf.: +45 78 77 28 87</div></div>"
            }
          },
          {
            "title" : "Denne indlægsseddel blev senest ændret December 2021",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Denne indlægsseddel blev senest ændret December 2021</h2></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/IBD-MPD-8",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "IBD-MPD-8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_IBD-MPD-8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition IBD-MPD-8</b></p><a name=\"IBD-MPD-8\"> </a><a name=\"hcIBD-MPD-8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_72CA1852-ECDA-4096-A284-C4EDDA63602D</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Imurel tab 25 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_72CA1852-ECDA-4096-A284-C4EDDA63602D"
      }],
      "name" : [{
        "productName" : "Imurel tab 25 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/IBD-PPD-8",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "IBD-PPD-8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_IBD-PPD-8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition IBD-PPD-8</b></p><a name=\"IBD-PPD-8\"> </a><a name=\"hcIBD-PPD-8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_B896FBA6-8A32-4436-9644-0295166F6E2C, <code>https://farmalogg.no/varenummer</code>/073947, <code>https://pharmaca.fi/vnr</code>/073947</p><p><b>name</b>: Imurel tab 25 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK39570.html#MedicinalProductDefinition_IBD-MPD-8\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_72CA1852-ECDA-4096-A284-C4EDDA63602D</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_B896FBA6-8A32-4436-9644-0295166F6E2C"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "073947"
      },
      {
        "system" : "https://pharmaca.fi/vnr",
        "value" : "073947"
      }],
      "name" : "Imurel tab 25 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-8"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/IBD-MPD-10",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "IBD-MPD-10",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_IBD-MPD-10\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition IBD-MPD-10</b></p><a name=\"IBD-MPD-10\"> </a><a name=\"hcIBD-MPD-10\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_065A4A9B-3A00-47F8-9FE0-AD9BB3559E6B</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Imurel tab 50 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_065A4A9B-3A00-47F8-9FE0-AD9BB3559E6B"
      }],
      "name" : [{
        "productName" : "Imurel tab 50 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/IBD-PPD-10",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "IBD-PPD-10",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_IBD-PPD-10\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition IBD-PPD-10</b></p><a name=\"IBD-PPD-10\"> </a><a name=\"hcIBD-PPD-10\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_FFD056BC-F52D-49A2-9399-303ED4030849, <code>https://farmalogg.no/varenummer</code>/075009, <code>https://pharmaca.fi/vnr</code>/075009</p><p><b>name</b>: Imurel tab 50 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK39570.html#MedicinalProductDefinition_IBD-MPD-10\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_065A4A9B-3A00-47F8-9FE0-AD9BB3559E6B</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_FFD056BC-F52D-49A2-9399-303ED4030849"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "075009"
      },
      {
        "system" : "https://pharmaca.fi/vnr",
        "value" : "075009"
      }],
      "name" : "Imurel tab 50 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-10"
      }]
    }
  }]
}

```
