# FK546406 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK546406**

## Example Bundle: FK546406

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: informasjon til brukeren

 

# Pakningsvedlegg: informasjon til brukeren

## Aprovel 300 mg filmdrasjerte tabletter

### irbesartan


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Spør lege eller apotek hvis du har flere spørsmål eller trenger mer informasjon.
* Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.
* Kontakt lege eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om:

 

## I dette pakningsvedlegget finner du informasjon om:

1. Hva Aprovel er og hva det brukes mot
1. Hva du må vite før du bruker Aprovel
1. Hvordan du bruker Aprovel
1. Mulige bivirkninger
1. Hvordan du oppbevarer Aprovel
1. Innholdet i pakningen og ytterligere informasjon


#### 1. Hva Aprovel er og hva det brukes mot

 

## 1. Hva Aprovel er og hva det brukes mot

Aprovel tilhører en gruppe legemidler som heter angiotensin II-reseptor antagonister. Angiotensin II produseres i kroppen og binder seg til reseptorer i blodårene, noe som får dem til å trekke seg sammen. Dette fører til økning i blodtrykk. Aprovel hindrer bindingen av angiotensin II til disse reseptorene. Dermed slapper blodårene av og blodtrykket reduseres. Aprovel forsinker reduksjon av nyrefunksjon hos pasienter med høyt blodtrykk og type 2 diabetes.

Aprovel brukes hos voksne pastienter
* til å behandle høyt blodtrykk (*essensiell hypertensjon*)
* til å beskytte nyrene hos pasienter med høyt blodtrykk, type 2 diabetes og når laboratorieprøver har påvist nedsatt nyrefunksjon.


#### 2. Hva du må vite før du bruker Aprovel

 

## 2. Hva du må vite før du bruker Aprovel


#### 3. Hvordan du bruker Aprovel

 

## 3. Hvordan du bruker Aprovel

Bruk alltid dette legemidlet nøyaktig slik legen har fortalt deg. Kontakt lege eller apotek hvis du er usikker.

Hvordan du tar medisinen
Aprovel er til
**oral **bruk. Tablettene bør svelges sammen med en tilstrekkelig mengde væske (f.eks. et glass vann). Du kan ta Aprovel med eller uten mat. Dosen bør tas på samme tid hver dag. Det er viktig at du fortsetter å ta Aprovel inntil legen bestemmer noe annet.

* **Pasienter med høyt blodtrykk**
Den vanlige dosen er 150 mg en gang daglig. Dosen kan økes senere til 300 mg en gang daglig, avhengig av effekten på blodtrykket.

* **Pasienter med høyt blodtrykk og type 2 diabetes med nyresykdom**
Hos pasienter med høyt blodtrykk og type 2 diabetes foretrekkes 300 mg en gang daglig som vedlikeholdsdose i behandling av diabetesrelatert nyresykdom.

Legen anbefaler muligens en lavere dose, spesielt hos visse pasientgrupper, slik som de som får
**hemodialyse **eller de
**over 75 år**.

Maksimal blodtrykkssenkende effekt bør oppnås 4-6 uker etter behandlingsstart.

Bruk av Aprovel hos barn og ungdom
Aprovel skal ikke gis til barn under 18 år. Hvis et barn ved et uhell svelger noen tabletter, kontakt lege umiddelbart.


#### 4. Mulige bivirkninger

 

## 4. Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det. Noen av disse bivirkningene kan være alvorlige og kan kreve medisinsk behandling.

Som med lignende legemidler er det rapportert sjeldne tilfeller av allergiske hudreaksjoner (utslett, elveblest), samt lokal hevelse i ansiktet, lepper og/eller tungen hos pasienter som tar irbesartan. Viss du får noen av disse symptomene eller blir tungpustet,
**slutt å ta Aprovel og kontakt legen umiddelbart.**

Frekvensen av bivirkningene som er listet opp nedenfor er definert på følgende måte:

Svært vanlige: kan inntreffe hos flere enn 1 av 10 personer

Vanlige: kan inntreffe hos opptil 1 av 10 personer

Mindre vanlige: kan inntreffe hos opptil 1 av 100 personer

Bivirkninger som ble rapportert i kliniske studier hos pasienter som ble behandlet med Aprovel var:
* Svært vanlige (kan inntreffe hos flere enn 1 av 10 personer): hvis du lider av høyt blodtrykk og type 2 diabetes med nyresykdom, kan blodprøver vise en økning i kaliumnivået.

* Vanlige (kan inntreffe hos opptil 1 av 10 personer): svimmelhet, kvalme/oppkast, tretthet og blodprøver kan vise økte nivåer av et enzym som er et mål på muskel- og hjertefunksjonen (kreatininkinaseenzym). Hos pasienter med høyt blodtrykk og type 2 diabetes med nyresykdom ble det også rapportert svimmelhet når man reiser seg fra liggende eller sittende stilling, lavt blodtrykk når man reiser seg fra liggende eller sittende stilling, smerter i ledd eller muskler og nedsatt nivå av et protein i de røde blodcellene (hemoglobin) ble også rapportert.

* Mindre vanlige (kan inntreffe hos opptil 1 av 100 personer): økt hjerterytme, rødming, hoste, diaré, fordøyelsesbesvær/halsbrann, seksuell dysfunksjon (problemer med seksuell prestasjon), brystsmerte.

Enkelte bivirkninger er rapportert siden markedsføringen av Aprovel. Bivirkninger der hyppigheten ikke er kjent er: følelse av at omgivelsene spinner rundt, hodepine, endret smaksopplevelse, øresus, muskelkramper, smerter i ledd og muskler, redusert antall røde blodceller (anemi – symptomer kan være tretthet, hodepine, kortpustethet når du trener, svimmelhet og blekhet), redusert antall blodplater, unormal leverfunksjon, økt kaliumnivå i blodet, redusert nyrefunksjon, betennelse i små blodårer hovedsakelig i huden (tilstanden kalles leukocytoklastisk vaskulitt) og alvorlige allergiske reaksjoner (anafylaktisk sjokk). Uvanlige tilfeller av gulsott (gulfarging av huden og/eller det hvite i øynene) er også rapportert.


#### 5. Hvordan du oppbevarer Aprovel

 

## 5. Hvordan du oppbevarer Aprovel

Oppbevares utilgjengelig for barn.

Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken og blisterpakningen etter EXP. Utløpsdatoen er den siste dagen i den angitte måneden.

Oppbevares ved høyst 30ºC.

Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.


#### 6. Innholdet i pakningen og ytterligere informasjon

 

## 6. Innholdet i pakningen og ytterligere informasjon


####  Aprovel tab 300 mg 
LEGEMIDDELMERKEVAREID:
** ID_AAC5FC7D-F44D-43E6-AF98-9E730D3097BA **
-------

Full name: **Aprovel tab 300 mg**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_AABC42A4-F392-4AD3-8777-BB7E11DCED02 ** 

VARENUMMER: ** 019688 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK546406",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "546406"
  },
  "type" : "document",
  "timestamp" : "2023-01-30T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK546406-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK546406-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK546406-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK546406-COMP</b></p><a name=\"FK546406-COMP\"> </a><a name=\"hcFK546406-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/546406</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2023-01-30</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: Aprovel Sanofi tabletter 300 mg</p></div>"
      },
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "546406"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-8"
      }],
      "date" : "2023-01-30",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "Aprovel Sanofi tabletter 300 mg",
      "section" : [{
        "title" : "Pakningsvedlegg: informasjon til brukeren",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: informasjon til brukeren</h1><h2>Aprovel 300 mg filmdrasjerte tabletter</h2><h3>irbesartan</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Spør lege eller apotek hvis du har flere spørsmål eller trenger mer informasjon.</li><li>Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.</li><li>Kontakt lege eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om:",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om:</h2><div class=\"paragraph\"><ol><li>Hva Aprovel er og hva det brukes mot</li><li>Hva du må vite før du bruker Aprovel</li><li>Hvordan du bruker Aprovel</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer Aprovel</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "1. Hva Aprovel er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>1. Hva Aprovel er og hva det brukes mot</h2><div class=\"paragraph\">Aprovel tilhører en gruppe legemidler som heter angiotensin II-reseptor antagonister. Angiotensin II produseres i kroppen og binder seg til reseptorer i blodårene, noe som får dem til å trekke seg sammen. Dette fører til økning i blodtrykk. Aprovel hindrer bindingen av angiotensin II til disse reseptorene. Dermed slapper blodårene av og blodtrykket reduseres. Aprovel forsinker reduksjon av nyrefunksjon hos pasienter med høyt blodtrykk og type 2 diabetes.</div><div class=\"paragraph\">Aprovel brukes hos voksne pastienter<ul><li>til å behandle høyt blodtrykk (<i>essensiell hypertensjon</i>)</li><li>til å beskytte nyrene hos pasienter med høyt blodtrykk, type 2 diabetes og når laboratorieprøver har påvist nedsatt nyrefunksjon.</li></ul></div></div>"
          }
        },
        {
          "title" : "2. Hva du må vite før du bruker Aprovel",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>2. Hva du må vite før du bruker Aprovel</h2></div>"
          },
          "section" : [{
            "title" : "Bruk ikke Aprovel",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Bruk ikke Aprovel</h3><div class=\"paragraph\"><ul><li>dersom du er <b>allergisk </b>overfor irbesartan eller noen av de andre innholdsstoffene i dette legemidlet (listet opp i avsnitt 6).</li><li>dersom du er <b>gravid i tredje måned eller mer. </b>(Det er også best å unngå Aprovel tidlig i svangerskapet - se ”Graviditet og amming”).</li><li>dersom du har <b>diabetes eller nedsatt nyrefunksjon </b>og du får behandling med et legemiddel mot høyt blodtrykk som inneholder aliskiren.</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler</h3><div class=\"paragraph\">Snakk med legefør du bruker Aprovel og <b>hvis noe av det følgende gjelder for deg</b>:<ul><li>dersom du får <b>mye oppkast og diaré</b></li><li>dersom du har <b>nyreproblemer</b></li><li>dersom du har <b>hjerteproblemer</b></li><li>dersom du får Aprovel for <b>diabetisk nyresykdom</b>. I så tilfelle kan det hende at legen tar blodprøver, spesielt for å måle kaliumnivået ved dårlig nyrefunksjon</li><li>dersom du får lave blodsukkernivåer (syptomene kan være svette, svakhet, sult, svimmelhet, skjelving, hodepine, rødme eller blekhet, nummenhet, rask, bankende hjerterytme), spesielt hvis du blir behandlet for diabetes.</li><li>dersom du <b>skal ha en operasjon </b>eller <b>bli gitt narkose</b>.</li><li>dersom du bruker noen av følgende legemidler mot høyt blodtrykk:<ul><li>en ACE-hemmer (f.eks. enalapril, lisinopril, ramipril), særlig hvis du har diabetisk nyresykdom</li><li>aliskiren</li></ul></li></ul></div><div class=\"paragraph\">Legen kan utføre regelmessige kontroller av nyrefunksjonen din, blodtrykket og nivået av elektrolytter (f.eks. kalium) i blodet ditt.</div><div class=\"paragraph\">Se også informasjon i avsnittet «Bruk ikke Aprovel».</div><div class=\"paragraph\">Du må fortelle legen hvis du tror du er gravid (<span class=\"underline\">eller om du tror du kan komme til å bli gravid</span>). Aprovel er ikke anbefalt tidlig i svangerskapet, og må ikke benyttes hvis du er mer enn tre måneder gravid, ettersom det kan føre til alvorlige skader på barnet dersom det blir brukt på dette stadiet av svangerskapet (se avsnitt om graviditet).</div></div>"
            }
          },
          {
            "title" : "Barn og ungdom",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029899"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Barn og ungdom</h3><div class=\"paragraph\">Dette legemidlet skal ikke brukes av barn og ungdom da effekt og sikkerhet enda ikke er fullstendig fastslått.</div></div>"
            }
          },
          {
            "title" : "Andre legemidler og Aprovel",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og Aprovel</h3><div class=\"paragraph\">Snakk med lege eller apotek dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler.</div><div class=\"paragraph\">Legen kan endre dosen din og/eller ta andre forholdsregler:</div><span class=\"inline-title\">hvis du bruker en ACE-hemmer eller aliskiren (se også informasjon i avsnittene «Bruk ikke Aprovel» og «Advarsler og forsiktighetsregler»).</span><div class=\"paragraph\"><b>Det kan være nødvendig å ta blodprøver dersom du tar:</b><ul><li>kaliumtilskudd</li><li>salterstatninger som inneholder kalium</li><li>kaliumsparende legemidler (blant annet enkelte vanndrivende legemidler)</li><li>legemidler som inneholder litium</li><li>repaglinid (legemiddel som brukes til å senke blodsukkernivået)</li></ul></div><div class=\"paragraph\">Hvis du tar visse smertestillende midler som kalles ikke-steroide antiinflammatoriske legemidler, kan effekten av irbesartan reduseres.</div></div>"
            }
          },
          {
            "title" : "Inntak av Aprovel sammen med mat og drikke",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029901"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Inntak av Aprovel sammen med mat og drikke</h3><div class=\"paragraph\">Aprovel kan tas sammen med eller uten mat.</div></div>"
            }
          },
          {
            "title" : "Graviditet og amming",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet og amming</h3><div class=\"paragraph\"><b>Graviditet</b>:<br/>Du må informere din lege dersom du tror du er gravid (<span class=\"underline\">eller om du tror du kan komme til å bli gravid</span>). Din lege vil vanligvis råde deg til å slutte med Aprovel før du blir gravid, eller så snart du vet du er gravid, og vil anbefale deg å bruke et annet legemiddel istedenfor Aprovel. Aprovel er ikke anbefalt tidlig i svangerskapet, og må ikke benyttes når du er mer enn 3 måneder gravid, ettersom det kan føre til alvorlige skader på barnet dersom det blir brukt etter graviditetens tredje måned.</div><div class=\"paragraph\"><b>Amming</b>:<br/>Informer legen dersom du ammer eller skal begynne å amme. Aprovel er ikke anbefalt for mødre som ammer, og din lege vil kanskje velge en annen behandling for deg, dersom du ønsker å amme, spesielt hvis barnet er nyfødt eller ble født for tidlig.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\">Det er ikke sannsynlig at Aprovel påvirker evnen til å kjøre bil eller bruke maskiner. Noen ganger kan imidlertid svimmelhet eller tretthet forekomme ved behandling av høyt blodtrykk. Dersom du opplever disse, snakk med legen før du prøver å kjøre bil eller bruke maskiner.</div></div>"
            }
          },
          {
            "title" : "Aprovel inneholder laktose",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Aprovel inneholder laktose</h3><div class=\"paragraph\">Dersom du ikke tåler visse sukkertyper (for eksempel laktose), kontakt legen før du tar dette legemidlet.</div><div class=\"paragraph\"><b>Aprovel inneholder natrium</b>.<br/>Dette legemidlet inneholder mindre enn 1 mmol natrium (23 mg) i hver tablett, og er så godt som “natriumfritt”.</div></div>"
            }
          }]
        },
        {
          "title" : "3. Hvordan du bruker Aprovel",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>3. Hvordan du bruker Aprovel</h2><div class=\"paragraph\">Bruk alltid dette legemidlet nøyaktig slik legen har fortalt deg. Kontakt lege eller apotek hvis du er usikker.</div><span class=\"inline-title\">Hvordan du tar medisinen</span><div class=\"paragraph\">Aprovel er til <b>oral </b>bruk. Tablettene bør svelges sammen med en tilstrekkelig mengde væske (f.eks. et glass vann). Du kan ta Aprovel med eller uten mat. Dosen bør tas på samme tid hver dag. Det er viktig at du fortsetter å ta Aprovel inntil legen bestemmer noe annet.</div><div class=\"paragraph\"><ul><li><b>Pasienter med høyt blodtrykk</b><br/>Den vanlige dosen er 150 mg en gang daglig. Dosen kan økes senere til 300 mg en gang daglig, avhengig av effekten på blodtrykket.</li></ul></div><div class=\"paragraph\"><ul><li><b>Pasienter med høyt blodtrykk og type 2 diabetes med nyresykdom</b><br/>Hos pasienter med høyt blodtrykk og type 2 diabetes foretrekkes 300 mg en gang daglig som vedlikeholdsdose i behandling av diabetesrelatert nyresykdom.</li></ul></div><div class=\"paragraph\">Legen anbefaler muligens en lavere dose, spesielt hos visse pasientgrupper, slik som de som får <b>hemodialyse </b>eller de <b>over 75 år</b>.</div><div class=\"paragraph\">Maksimal blodtrykkssenkende effekt bør oppnås 4-6 uker etter behandlingsstart.</div><span class=\"inline-title\">Bruk av Aprovel hos barn og ungdom</span><div class=\"paragraph\">Aprovel skal ikke gis til barn under 18 år. Hvis et barn ved et uhell svelger noen tabletter, kontakt lege umiddelbart.</div></div>"
          },
          "section" : [{
            "title" : "Dersom du tar for mye av Aprovel",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029907"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du tar for mye av Aprovel</h3><div class=\"paragraph\">Kontakt lege eller apotek umiddelbart dersom du ved en feil har tatt for mange tabletter.</div></div>"
            }
          },
          {
            "title" : "Dersom du har glemt å ta Aprovel",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029908"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du har glemt å ta Aprovel</h3><div class=\"paragraph\">Dersom du glemmer å ta en dose, ta neste dose som vanlig. Du må ikke ta en dobbelt dose som erstatning for en glemt dose.</div><div class=\"paragraph\">Spør lege eller apotek dersom du har noen spørsmål om bruken av dette legemidlet</div></div>"
            }
          }]
        },
        {
          "title" : "4. Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>4. Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det. Noen av disse bivirkningene kan være alvorlige og kan kreve medisinsk behandling.</div><div class=\"paragraph\">Som med lignende legemidler er det rapportert sjeldne tilfeller av allergiske hudreaksjoner (utslett, elveblest), samt lokal hevelse i ansiktet, lepper og/eller tungen hos pasienter som tar irbesartan. Viss du får noen av disse symptomene eller blir tungpustet, <b>slutt å ta Aprovel og kontakt legen umiddelbart.</b></div><div class=\"paragraph\">Frekvensen av bivirkningene som er listet opp nedenfor er definert på følgende måte:<br/>Svært vanlige: kan inntreffe hos flere enn 1 av 10 personer<br/>Vanlige: kan inntreffe hos opptil 1 av 10 personer<br/>Mindre vanlige: kan inntreffe hos opptil 1 av 100 personer</div><div class=\"paragraph\">Bivirkninger som ble rapportert i kliniske studier hos pasienter som ble behandlet med Aprovel var:<ul><li>Svært vanlige (kan inntreffe hos flere enn 1 av 10 personer): hvis du lider av høyt blodtrykk og type 2 diabetes med nyresykdom, kan blodprøver vise en økning i kaliumnivået.</li></ul></div><div class=\"paragraph\"><ul><li>Vanlige (kan inntreffe hos opptil 1 av 10 personer): svimmelhet, kvalme/oppkast, tretthet og blodprøver kan vise økte nivåer av et enzym som er et mål på muskel- og hjertefunksjonen (kreatininkinaseenzym). Hos pasienter med høyt blodtrykk og type 2 diabetes med nyresykdom ble det også rapportert svimmelhet når man reiser seg fra liggende eller sittende stilling, lavt blodtrykk når man reiser seg fra liggende eller sittende stilling, smerter i ledd eller muskler og nedsatt nivå av et protein i de røde blodcellene (hemoglobin) ble også rapportert.</li></ul></div><div class=\"paragraph\"><ul><li>Mindre vanlige (kan inntreffe hos opptil 1 av 100 personer): økt hjerterytme, rødming, hoste, diaré, fordøyelsesbesvær/halsbrann, seksuell dysfunksjon (problemer med seksuell prestasjon), brystsmerte.</li></ul></div><div class=\"paragraph\">Enkelte bivirkninger er rapportert siden markedsføringen av Aprovel. Bivirkninger der hyppigheten ikke er kjent er: følelse av at omgivelsene spinner rundt, hodepine, endret smaksopplevelse, øresus, muskelkramper, smerter i ledd og muskler, redusert antall røde blodceller (anemi – symptomer kan være tretthet, hodepine, kortpustethet når du trener, svimmelhet og blekhet), redusert antall blodplater, unormal leverfunksjon, økt kaliumnivå i blodet, redusert nyrefunksjon, betennelse i små blodårer hovedsakelig i huden (tilstanden kalles leukocytoklastisk vaskulitt) og alvorlige allergiske reaksjoner (anafylaktisk sjokk). Uvanlige tilfeller av gulsott (gulfarging av huden og/eller det hvite i øynene) er også rapportert.</div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger. Dette gjelder også bivirkninger som ikke er nevnt i pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "5. Hvordan du oppbevarer Aprovel",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>5. Hvordan du oppbevarer Aprovel</h2><div class=\"paragraph\">Oppbevares utilgjengelig for barn.</div><div class=\"paragraph\">Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken og blisterpakningen etter EXP. Utløpsdatoen er den siste dagen i den angitte måneden.</div><div class=\"paragraph\">Oppbevares ved høyst 30ºC.</div><div class=\"paragraph\">Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.</div></div>"
          }
        },
        {
          "title" : "6. Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>6. Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av Aprovel",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av Aprovel</h3><div class=\"paragraph\">Virkestoff er irbesartan. Hver tablett Aprovel 300 mg inneholder 300 mg irbesartan.</div><div class=\"paragraph\">Andre innholdsstoffer er laktosemonohydrat, mikrokrystallinsk cellulose, krysskarmellosenatrium, hypromellose, silikondioksid, magnesiumstearat, titandioksid, makrogol 3000, karnaubavoks. Se avsnitt 2 «Aprovel inneholder laktose»</div></div>"
            }
          },
          {
            "title" : "Hvordan Aprovel ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan Aprovel ser ut og innholdet i pakningen</h3><div class=\"paragraph\">Aprovel 300 mg filmdrasjerte tabletter er hvite til &quot;off-white&quot;, bikonvekse og oval-formede med et hjerte trykt på den ene siden og tallet 2873 trykt på den andre siden.</div><div class=\"paragraph\">Aprovel 300 mg filmdrasjerte tabletter leveres i blisterpakninger på 14, 28, 30, 56, 84, 90 eller 98 filmdrasjerte tabletter. Endose blisterpakninger på 56 × 1 filmdrasjerte tabletter kan leveres til sykehus.</div><div class=\"paragraph\">Ikke alle pakningsstørrelser vil nødvendigvis bli markedsført.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen:",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen:</h3><div class=\"paragraph\">Sanofi Winthrop Industrie<br/>82 avenue Raspail<br/>94250 Gentilly<br/>Frankrike</div><span class=\"inline-title\">Tilvirker:</span><div class=\"paragraph\">SANOFI WINTHROP INDUSTRIE<br/>1, rue de la Vierge<br/>Ambarès &amp; Lagrave<br/>F-33565 Carbon Blanc Cedex - Frankrike</div><div class=\"paragraph\">SANOFI WINTHROP INDUSTRIE<br/>30-36 Avenue Gustave Eiffel, BP 7166<br/>F-37071 Tours Cedex 2 - Frankrike</div><div class=\"paragraph\">Sanofi-Aventis, S.A.<br/>Ctra. C-35 (La Batlloria-Hostalric), km. 63.09<br/>17404 Riells i Viabrea (Girona)<br/>Spania</div><div class=\"paragraph\">Ta kontakt med den lokale representanten for innehaveren av markedsføringstillatelsen for ytterligere informasjon om dette legemidlet:</div><div class=\"paragraph\">sanofi-aventis Norge AS<br/>Tlf: +47 67 10 71 00</div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 30.01.2023",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 30.01.2023</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Detaljert informasjon om dette legemiddel er tilgjengelig på nettstedet til Det europeiske legemiddelkontoret (the European Medicines Agency): <a href=\"http://www.ema.europa.eu/\" title=\"\n               \n                  http://www.ema.europa.eu/\n               \n            \">http://www.ema.europa.eu/ </a>og på nettstedet til <a href=\"http://www.felleskatalogen.no\" title=\"\n               \n                  www.felleskatalogen.no\n               \n            \">www.felleskatalogen.no</a></div></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-8",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-8</b></p><a name=\"Diabetes-MPD-8\"> </a><a name=\"hcDiabetes-MPD-8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_AAC5FC7D-F44D-43E6-AF98-9E730D3097BA</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Aprovel tab 300 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_AAC5FC7D-F44D-43E6-AF98-9E730D3097BA"
      }],
      "name" : [{
        "productName" : "Aprovel tab 300 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-8",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-8</b></p><a name=\"Diabetes-PPD-8\"> </a><a name=\"hcDiabetes-PPD-8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_AABC42A4-F392-4AD3-8777-BB7E11DCED02, <code>https://farmalogg.no/varenummer</code>/019688</p><p><b>name</b>: Aprovel tab 300 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK546406.html#MedicinalProductDefinition_Diabetes-MPD-8\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_AAC5FC7D-F44D-43E6-AF98-9E730D3097BA</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_AABC42A4-F392-4AD3-8777-BB7E11DCED02"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "019688"
      }],
      "name" : "Aprovel tab 300 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-8"
      }]
    }
  }]
}

```
