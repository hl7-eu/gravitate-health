# ePI document Bundle for Xenical 120mg hard capsules Package Leaflet for language es - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Xenical 120mg hard capsules Package Leaflet for language es**

## Example Bundle: ePI document Bundle for Xenical 120mg hard capsules Package Leaflet for language es

**Composition category:**Processed

**Composition status:**final

### B. Package Leaflet

#### Package leaflet: Information for the user

 

# Package leaflet: Information for the patient

## Atorvastatin Momaja 10 mg, 20 mg, 40 mg, 80 mg Film-coated Tablets

## Atorvastatin

Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.

* Keep this leaflet. You may need to read it again.
* If you have any further questions, ask your doctor, pharmacist or nurse.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.
* If you get any side effects, talk to your doctor, pharmacist or nurse. This includes any possible side effects not listed in this leaflet. See section 4.


#### What is in this leaflet

 

## What is in this leaflet

1. What Atorvastatin is and what it is used for
1. What you need to know before you take Atorvastatin
1. How to take Atorvastatin
1. Possible side effects
1. How to store Atorvastatin
1. Contents of the pack and other information


#### 1. What Atorvastatin is and what it is used for

 

Atorvastatin belongs to a group of medicines known as statins, which are lipid (fat) regulating medicines.

Atorvastatin is used to lower lipids known as cholesterol and triglycerides in the blood when a low-fat diet and lifestyle changes alone have failed. If you are at increased risk of heart disease, Atorvastatin can also reduce such risk even if your cholesterol levels are normal. You should maintain a standard cholesterol-lowering diet during treatment.


#### 2. What you need to know before you take Atorvastatin

 

**Do not take Atorvastatin:**

* if you are allergic to Atorvastatin or any of the other ingredients of this medicine (listed in section 6).
* if you have or have ever had a disease which affects the liver.
* if you have had any unexplained abnormal blood tests for liver function.
* if you are a woman able to have children and not using reliable contraception.
* if you are pregnant, or trying to become pregnant.
* if you are breast-feeding.
* if you use the combination of glecaprevir/pibrentasvir in the treatment of hepatitis C.

### Warnings and precautions

Talk to your doctor, pharmacist or nurse before taking Atorvastatin if you have:

* severe respiratory failure
* taken fusidic acid in the last 7 days (orally or by injection)
* had a previous stroke with bleeding into the brain, or small pockets of fluid in the brain
* kidney problems
* an under-active thyroid gland (hypothyroidism)
* repeated or unexplained muscle aches or pains, personal or family history of muscle problems
* previous muscular problems during treatment with other lipid-lowering medicines
* myasthenia (general muscle weakness) or ocular myasthenia (eye muscle weakness)
* regularly drinking a large amount of alcohol
* history of liver disease
* age over 70 years

### Other medicines and Atorvastatin

Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines. Some medicines may change the effect of Atorvastatin or increase the risk of side effects, including rhabdomyolysis:

* Medicines affecting the immune system (e.g. ciclosporin)
* Certain antibiotics or antifungals (e.g. erythromycin, clarithromycin, ketoconazole, itraconazole, voriconazole, fluconazole, posaconazole, rifampin, fusidic acid)
* Other lipid-lowering medicines (e.g. gemfibrozil, other fibrates, colestipol)
* Calcium channel blockers (e.g. amlodipine, diltiazem), antiarrhythmics (e.g. digoxin, verapamil, amiodarone)
* Letermovir
* HIV treatments (e.g. ritonavir, lopinavir, atazanavir, indinavir, darunavir, tipranavir/ritonavir)
* Hepatitis C treatments (e.g. telaprevir, boceprevir, elbasvir/grazoprevir, ledipasvir/sofosbuvir)
* Ezetimibe, warfarin, oral contraceptives, stiripentol, cimetidine, phenazone, colchicine, antacids containing aluminium or magnesium
* St John’s Wort
* Daptomycin

### Atorvastatin with food and drink

* **Grapefruit juice:** Do not take more than one or two small glasses per day because large quantities can change the effects of Atorvastatin.
* **Alcohol:** Avoid drinking too much alcohol while taking this medicine.

### Pregnancy and breast-feeding

Do not take Atorvastatin if you are pregnant, trying to become pregnant or breast-feeding. Women able to become pregnant must use reliable contraception.

### Driving and using machines

This medicine normally does not affect your ability to drive or use machines. However, do not drive or operate machines if your ability is affected.

### Atorvastatin contains lactose

If you have been told by your doctor that you have intolerance to some sugars, contact your doctor before taking this medicine.

### Sodium content

This medicine contains less than 1 mmol sodium (23 mg) per tablet, that is to say essentially ‘sodium-free’.


#### 3. How to take Atorvastatin

 

Before starting treatment, your doctor will place you on a low-cholesterol diet, which you should continue during therapy with Atorvastatin.

The usual starting dose is 10 mg once a day in adults and children aged 10 years or older. Your doctor may increase your dose every 4 weeks up to a maximum of 80 mg once a day.

Swallow Atorvastatin tablets whole with water. They can be taken at any time of day, with or without food. Try to take your tablet at the same time each day.

Always take this medicine exactly as your doctor or pharmacist has told you. If you take more than you should accidentally, contact your doctor or nearest hospital for advice.

### If you forget to take Atorvastatin

If you forget a dose, take the next scheduled dose at the correct time. Do not take a double dose to make up for a forgotten dose.

### If you stop taking Atorvastatin

If you have any further questions on the use of this medicine or wish to stop treatment, ask your doctor or pharmacist.


#### 4. Possible side effects

 

Like all medicines, Atorvastatin can cause side effects, although not everybody gets them.

### Serious side effects

#### Rare: may affect up to 1 in 1,000 people

* Serious allergic reactions (swelling of face, tongue, throat possibly causing breathing difficulty)
* Severe skin reactions (peeling, blistering of skin, mouth, eyes, genitals, fever)
* Muscle breakdown (rhabdomyolysis): muscle weakness, pain, red-brown urine, fever, which can be life-threatening.

#### Very rare: may affect up to 1 in 10,000 people

* Unexpected bleeding or bruising suggesting liver issues
* Lupus-like syndrome (rash, joint disorders, blood cell effects)

### Other possible side effects

#### Common: may affect up to 1 in 10 people

* Nasal inflammation, throat pain, nose bleed
* Allergic reactions
* Increased blood sugar levels, increased creatine kinase
* Headache
* Nausea, constipation, wind, indigestion, diarrhoea
* Joint, muscle, or back pain
* Abnormal liver function tests

#### Uncommon: may affect up to 1 in 100 people

* Anorexia, weight gain, decreased blood sugar levels
* Nightmares, insomnia
* Dizziness, numbness or tingling, change in taste, memory loss
* Blurred vision
* Ringing in ears/head
* Vomiting, belching, abdominal pain, pancreatitis
* Hepatitis
* Rash, itching, hives, hair loss
* Neck pain, muscle fatigue
* Fatigue, weakness, chest pain, ankle swelling (oedema), raised temperature
* White blood cells in urine

#### Rare: may affect up to 1 in 1,000 people

* Visual disturbance
* Unexpected bleeding or bruising
* Cholestasis (jaundice)
* Tendon injury
* Lichenoid drug reaction
* Vasculitis (purple skin lesions)

#### Very rare: may affect up to 1 in 10,000 people

* Severe allergic reaction with breathing difficulty, collapse
* Hearing loss
* Gynecomastia (breast enlargement in men)

#### Not known

* Constant muscle weakness
* Myasthenia gravis, ocular myasthenia

### Reporting of side effects

If you get any side effects, talk to your doctor, pharmacist or nurse. You can also report side effects via the Yellow Card Scheme at [www.mhra.gov.uk/yellowcard](https://www.mhra.gov.uk/yellowcard).


#### 5. How to store Atorvastatin

 

* Keep out of the sight and reach of children.
* Store below 25 °C.
* Do not use this medicine after the expiry date which is stated on the carton and blister after ‘EXP’. The expiry date refers to the last day of that month.
* Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use.


#### 6. Contents of the pack and other information

 

### What Atorvastatin contains

* **Active substance:** Atorvastatin as atorvastatin calcium trihydrate. Each film-coated tablet contains 10 mg, 20 mg, 40 mg or 80 mg atorvastatin.
* **Other ingredients:**
* Tablet core: Microcrystalline cellulose (E460), Lactose monohydrate, Colloidal anhydrous silica, Croscarmellose sodium (E468), Sodium hydrogen carbonate, Sodium carbonate anhydrous, Hydroxypropylcellulose (E463), Magnesium stearate (E470b), Butylhydroxyanisole, Butylhydroxytoluene
* Film coating: Hypromellose (E464), macrogol 8000, titanium dioxide (E171), talc (E553b)

### What Atorvastatin tablets look like and contents of the pack

* **10 mg:** White to off white, film-coated oval tablets ~6.1 mm × 8.6 mm, debossed ‘A30’.
* **20 mg:** White to off white, film-coated oval tablets ~6.6 mm × 12.1 mm, debossed ‘A31’.
* **40 mg:** White to off white, film-coated oval tablets ~8.1 mm × 16.9 mm, debossed ‘A32’.
* **80 mg:** White to off white, film-coated oval tablets ~10.8 mm × 21.7 mm, debossed ‘A33’.

Supplied in cold-form blister laminate packs of 10, 14, 20, 28, 30, 50, 56, 60, 84, 90, 98, 100 tablets. Not all pack sizes may be marketed.

### Marketing Authorisation Holder

SUN PHARMA UK LIMITED

6-9 The Square, Stockley Park, Uxbridge, UB11 1FW, United Kingdom

### Manufacturer

Sun Pharmaceutical Industries Europe B.V.

Polarisavenue 87, 2132 JH Hoofddorp, The Netherlands

Terapia S.A.

124 Fabricii Street, 400 632 Cluj Napoca, Romania

This medicine is authorised in the Member States of the European Economic Area and in the United Kingdom (Northern Ireland) under the following names:

* Bulgaria: ATORVISTAT K 10/20 mg филмирани таблетки
* Finland: Atorvastatin Orion 10/20/40/80 mg tabletti, kalvopäällysteinen
* France: ATORVASTATINE SUN 10/20/40/80 mg, comprimé pelliculé
* Ireland: Atorvastatin 10/20/40/80 mg film-coated tablets
* Latvia: Atorvastatin SUN 10/20/40/80 mg apvalkotās tabletes
* Lithuania: Atorvastatin SUN 10/20/40/80 mg plėvele dengtos tabletės
* Poland: Storvas CRT
* Romania: Atorvastatin Terapia 10/20/40/80 mg comprimate filmate
* Spain: ATORVASTATINA SUN 10-20-40-80 mg COMPRIMIDOS RECUBIERTOS CON PELÍCULA EFG
* United Kingdom (Northern Ireland): Atorvastatin 10/20/40/80 mg Film-coated Tablets

This leaflet was last revised in October 2024.


####  Atorvastatin Flexpen 100 units/ml solution for injection in pre-filled pens 
DOC:
** himss-Atorvastatin **
-------

Full name: **Atorvastatin Flexpen 100 units/ml solution for injection in pre-filled pens**

 - Invented name part: ** Atorvastatin FlexPen ** 

 - Scientific name part: ** Insulin ** 

 - Strength part: ** 100 units/ml ** 

 - Pharmaceutical dose form part: ** solution for injection in pre-filled pens ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundle-atorvastatin-proc",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/98/071/004"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-en-Atorvastatin-pproc",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-en-Atorvastatin-pproc",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_composition-en-Atorvastatin-pproc\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-en-Atorvastatin-pproc</b></p><a name=\"composition-en-Atorvastatin-pproc\"> </a><a name=\"hccomposition-en-Atorvastatin-pproc\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: difficult_text</li><li>concept: <span title=\"Codes:{http://gravitatehealth.eu/codes diff001}\">Difficult text</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: hiv</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 19030005}\">HIV</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: pediatric</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 376171000221106}\">Pediatric population (qualifier value)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: adult</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 376161000221102}\">Adult population (qualifier value)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: rash</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 827160004}\">Erythematous rash (disorder)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: lactose</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 47703008}\">Lactose</span></li></ul></blockquote><p><b>identifier</b>: <code>http://ema.europa.eu/identifier</code>/himss-Atorvastatin</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs P}\">Processed</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: EMA</p><p><b>title</b>: TEST PURPOSES ONLY - Atorvastatin</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "difficult_text"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://gravitatehealth.eu/codes",
                "code" : "diff001",
                "display" : "Difficult text"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "hiv"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "19030005",
                "display" : "HIV"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "pediatric"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "376171000221106",
                "display" : "Pediatric population (qualifier value)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "adult"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "376161000221102",
                "display" : "Adult population (qualifier value)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "rash"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "827160004",
                "display" : "Erythematous rash (disorder)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "lactose"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "47703008",
                "display" : "Lactose"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      }],
      "identifier" : [{
        "system" : "http://ema.europa.eu/identifier",
        "value" : "himss-Atorvastatin"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "P",
          "display" : "Processed"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/himss-Atorvastatin-mpd"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "display" : "EMA"
      }],
      "title" : "TEST PURPOSES ONLY - Atorvastatin",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. Package Leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"></div>"
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Package leaflet: Information for the patient</h1><h2>Atorvastatin Momaja 10 mg, 20 mg, 40 mg, 80 mg Film-coated Tablets</h2><h2>Atorvastatin</h2><p>Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.</p><ul><li>Keep this leaflet. You may need to read it again.</li><li>If you have any further questions, ask your doctor, pharmacist or nurse.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.</li><li>If you get any side effects, talk to your doctor, pharmacist or nurse. This includes any possible side effects not listed in this leaflet. See section 4.</li></ul></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>What is in this leaflet</h2><ol><li>What Atorvastatin is and what it is used for</li><li>What you need to know before you take Atorvastatin</li><li>How to take Atorvastatin</li><li>Possible side effects</li><li>How to store Atorvastatin</li><li>Contents of the pack and other information</li></ol></div>"
          }
        },
        {
          "title" : "1. What Atorvastatin is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What Atorvastatin is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Atorvastatin belongs to a group of medicines known as statins, which are lipid (fat) regulating medicines.</p><p>Atorvastatin is used to lower lipids known as cholesterol and triglycerides in the blood when a low-fat diet and lifestyle changes alone have failed. If you are at increased risk of heart disease, Atorvastatin can also reduce such risk even if your cholesterol levels are normal. You should maintain a standard cholesterol-lowering diet during treatment.</p></div>"
          }
        },
        {
          "title" : "2. What you need to know before you take Atorvastatin",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take Atorvastatin"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Do not take Atorvastatin:</strong></p><ul><li>if you are allergic to Atorvastatin or any of the other ingredients of this medicine (listed in section 6).</li><li>if you have or have ever had a disease which affects the liver.</li><li>if you have had any unexplained abnormal blood tests for liver function.</li><li class=\"pediatric\">if you are a woman able to have children and not using reliable contraception.</li><li class=\"pregnancy\">if you are pregnant, or trying to become pregnant.</li><li class=\"breastfeeding\">if you are breast-feeding.</li><li>if you use the combination of glecaprevir/pibrentasvir in the treatment of hepatitis C.</li></ul><h3>Warnings and precautions</h3><p>Talk to your doctor, pharmacist or nurse before taking Atorvastatin if you have:</p><ul><li>severe respiratory failure</li><li>taken fusidic acid in the last 7 days (orally or by injection)</li><li>had a previous stroke with bleeding into the brain, or small pockets of fluid in the brain</li><li>kidney problems</li><li>an under-active thyroid gland (hypothyroidism)</li><li>repeated or unexplained muscle aches or pains, personal or family history of muscle problems</li><li>previous muscular problems during treatment with other lipid-lowering medicines</li><li>myasthenia (general muscle weakness) or ocular myasthenia (eye muscle weakness)</li><li>regularly drinking a large amount of alcohol</li><li>history of liver disease</li><li>age over 70 years</li></ul><h3>Other medicines and Atorvastatin</h3><p>Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines. Some medicines may change the effect of Atorvastatin or increase the risk of side effects, including rhabdomyolysis:</p><ul><li>Medicines affecting the immune system (e.g. ciclosporin)</li><li class=\"difficult\">Certain antibiotics or antifungals (e.g. erythromycin, clarithromycin, ketoconazole, itraconazole, voriconazole, fluconazole, posaconazole, rifampin, fusidic acid)</li><li>Other lipid-lowering medicines (e.g. gemfibrozil, other fibrates, colestipol)</li><li class=\"difficult\">Calcium channel blockers (e.g. amlodipine, diltiazem), antiarrhythmics (e.g. digoxin, verapamil, amiodarone)</li><li>Letermovir</li><li class=\"hiv\">HIV treatments (e.g. ritonavir, lopinavir, atazanavir, indinavir, darunavir, tipranavir/ritonavir)</li><li>Hepatitis C treatments (e.g. telaprevir, boceprevir, elbasvir/grazoprevir, ledipasvir/sofosbuvir)</li><li class=\"difficult\">Ezetimibe, warfarin, oral contraceptives, stiripentol, cimetidine, phenazone, colchicine, antacids containing aluminium or magnesium</li><li>St John’s Wort</li><li>Daptomycin</li></ul><h3>Atorvastatin with food and drink</h3><ul><li><strong>Grapefruit juice:</strong> Do not take more than one or two small glasses per day because large quantities can change the effects of Atorvastatin.</li><li><strong>Alcohol:</strong> Avoid drinking too much alcohol while taking this medicine.</li></ul><h3>Pregnancy and breast-feeding</h3><p class=\"breastfeeding pregnancy\">Do not take Atorvastatin if you are pregnant, trying to become pregnant or breast-feeding. Women able to become pregnant must use reliable contraception.</p><h3>Driving and using machines</h3><p>This medicine normally does not affect your ability to drive or use machines. However, do not drive or operate machines if your ability is affected.</p><h3>Atorvastatin contains lactose</h3><p>If you have been told by your doctor that you have intolerance to some sugars, contact your doctor before taking this medicine.</p><h3>Sodium content</h3><p>This medicine contains less than 1 mmol sodium (23 mg) per tablet, that is to say essentially ‘sodium-free’.</p></div>"
          }
        },
        {
          "title" : "3. How to take Atorvastatin",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take Atorvastatin"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Before starting treatment, your doctor will place you on a low-cholesterol diet, which you should continue during therapy with Atorvastatin.</p><p class=\"pediatric adult\">The usual starting dose is 10 mg once a day in adults and children aged 10 years or older. Your doctor may increase your dose every 4 weeks up to a maximum of 80 mg once a day.</p><p>Swallow Atorvastatin tablets whole with water. They can be taken at any time of day, with or without food. Try to take your tablet at the same time each day.</p><p>Always take this medicine exactly as your doctor or pharmacist has told you. If you take more than you should accidentally, contact your doctor or nearest hospital for advice.</p><h3>If you forget to take Atorvastatin</h3><p>If you forget a dose, take the next scheduled dose at the correct time. Do not take a double dose to make up for a forgotten dose.</p><h3>If you stop taking Atorvastatin</h3><p>If you have any further questions on the use of this medicine or wish to stop treatment, ask your doctor or pharmacist.</p></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Like all medicines, Atorvastatin can cause side effects, although not everybody gets them.</p><h3>Serious side effects</h3><h4>Rare: may affect up to 1 in 1,000 people</h4><ul><li>Serious allergic reactions (swelling of face, tongue, throat possibly causing breathing difficulty)</li><li>Severe skin reactions (peeling, blistering of skin, mouth, eyes, genitals, fever)</li><li>Muscle breakdown (rhabdomyolysis): muscle weakness, pain, red-brown urine, fever, which can be life-threatening.</li></ul><h4>Very rare: may affect up to 1 in 10,000 people</h4><ul><li>Unexpected bleeding or bruising suggesting liver issues</li><li class=\"rash\">Lupus-like syndrome (rash, joint disorders, blood cell effects)</li></ul><h3>Other possible side effects</h3><h4>Common: may affect up to 1 in 10 people</h4><ul><li>Nasal inflammation, throat pain, nose bleed</li><li>Allergic reactions</li><li>Increased blood sugar levels, increased creatine kinase</li><li>Headache</li><li>Nausea, constipation, wind, indigestion, diarrhoea</li><li>Joint, muscle, or back pain</li><li>Abnormal liver function tests</li></ul><h4>Uncommon: may affect up to 1 in 100 people</h4><ul><li>Anorexia, weight gain, decreased blood sugar levels</li><li>Nightmares, insomnia</li><li>Dizziness, numbness or tingling, change in taste, memory loss</li><li>Blurred vision</li><li>Ringing in ears/head</li><li>Vomiting, belching, abdominal pain, pancreatitis</li><li>Hepatitis</li><li class=\"hiv rash\">Rash, itching, hives, hair loss</li><li>Neck pain, muscle fatigue</li><li>Fatigue, weakness, chest pain, ankle swelling (oedema), raised temperature</li><li>White blood cells in urine</li></ul><h4>Rare: may affect up to 1 in 1,000 people</h4><ul><li>Visual disturbance</li><li>Unexpected bleeding or bruising</li><li>Cholestasis (jaundice)</li><li>Tendon injury</li><li>Lichenoid drug reaction</li><li>Vasculitis (purple skin lesions)</li></ul><h4>Very rare: may affect up to 1 in 10,000 people</h4><ul><li>Severe allergic reaction with breathing difficulty, collapse</li><li>Hearing loss</li><li>Gynecomastia (breast enlargement in men)</li></ul><h4>Not known</h4><ul><li>Constant muscle weakness</li><li>Myasthenia gravis, ocular myasthenia</li></ul><h3>Reporting of side effects</h3><p>If you get any side effects, talk to your doctor, pharmacist or nurse. You can also report side effects via the Yellow Card Scheme at <a href=\"https://www.mhra.gov.uk/yellowcard\" target=\"_blank\">www.mhra.gov.uk/yellowcard</a>.</p></div>"
          }
        },
        {
          "title" : "5. How to store Atorvastatin",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store Atorvastatin"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ul><li class=\"pediatric\">Keep out of the sight and reach of children.</li><li>Store below 25 °C.</li><li>Do not use this medicine after the expiry date which is stated on the carton and blister after ‘EXP’. The expiry date refers to the last day of that month.</li><li>Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use.</li></ul></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>What Atorvastatin contains</h3><ul><li><strong>Active substance:</strong> Atorvastatin as atorvastatin calcium trihydrate. Each film-coated tablet contains 10 mg, 20 mg, 40 mg or 80 mg atorvastatin.</li><li><strong>Other ingredients:</strong><ul><li class=\"lactose difficult\">Tablet core: Microcrystalline cellulose (E460), Lactose monohydrate, Colloidal anhydrous silica, Croscarmellose sodium (E468), Sodium hydrogen carbonate, Sodium carbonate anhydrous, Hydroxypropylcellulose (E463), Magnesium stearate (E470b), Butylhydroxyanisole, Butylhydroxytoluene</li><li>Film coating: Hypromellose (E464), macrogol 8000, titanium dioxide (E171), talc (E553b)</li></ul></li></ul><h3>What Atorvastatin tablets look like and contents of the pack</h3><ul><li><strong>10 mg:</strong> White to off white, film-coated oval tablets ~6.1 mm × 8.6 mm, debossed ‘A30’.</li><li><strong>20 mg:</strong> White to off white, film-coated oval tablets ~6.6 mm × 12.1 mm, debossed ‘A31’.</li><li><strong>40 mg:</strong> White to off white, film-coated oval tablets ~8.1 mm × 16.9 mm, debossed ‘A32’.</li><li><strong>80 mg:</strong> White to off white, film-coated oval tablets ~10.8 mm × 21.7 mm, debossed ‘A33’.</li></ul><p>Supplied in cold-form blister laminate packs of 10, 14, 20, 28, 30, 50, 56, 60, 84, 90, 98, 100 tablets. Not all pack sizes may be marketed.</p><h3>Marketing Authorisation Holder</h3><p>SUN PHARMA UK LIMITED</p><p>6-9 The Square, Stockley Park, Uxbridge, UB11 1FW, United Kingdom</p><h3>Manufacturer</h3><p>Sun Pharmaceutical Industries Europe B.V.</p><p>Polarisavenue 87, 2132 JH Hoofddorp, The Netherlands</p><p>Terapia S.A.</p><p>124 Fabricii Street, 400 632 Cluj Napoca, Romania</p><p>This medicine is authorised in the Member States of the European Economic Area and in the United Kingdom (Northern Ireland) under the following names:</p><ul><li>Bulgaria: ATORVISTAT K 10/20 mg филмирани таблетки</li><li>Finland: Atorvastatin Orion 10/20/40/80 mg tabletti, kalvopäällysteinen</li><li>France: ATORVASTATINE SUN 10/20/40/80 mg, comprimé pelliculé</li><li>Ireland: Atorvastatin 10/20/40/80 mg film-coated tablets</li><li>Latvia: Atorvastatin SUN 10/20/40/80 mg apvalkotās tabletes</li><li>Lithuania: Atorvastatin SUN 10/20/40/80 mg plėvele dengtos tabletės</li><li>Poland: Storvas CRT</li><li>Romania: Atorvastatin Terapia 10/20/40/80 mg comprimate filmate</li><li>Spain: ATORVASTATINA SUN 10-20-40-80 mg COMPRIMIDOS RECUBIERTOS CON PELÍCULA EFG</li><li>United Kingdom (Northern Ireland): Atorvastatin 10/20/40/80 mg Film-coated Tablets</li></ul><p>This leaflet was last revised in October 2024.</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/himss-Atorvastatin-mpd",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "himss-Atorvastatin-mpd",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_himss-Atorvastatin-mpd\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition himss-Atorvastatin-mpd</b></p><a name=\"himss-Atorvastatin-mpd\"> </a><a name=\"hchimss-Atorvastatin-mpd\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://www.gravitatehealth.eu/sid/doc</code>/himss-Atorvastatin</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Atorvastatin Flexpen 100 units/ml solution for injection in pre-filled pens</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Atorvastatin FlexPen</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Insulin</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 100 units/ml</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: solution for injection in pre-filled pens</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.gravitatehealth.eu/sid/doc",
        "value" : "himss-Atorvastatin"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Atorvastatin Flexpen 100 units/ml solution for injection in pre-filled pens",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Atorvastatin FlexPen",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "Insulin",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "100 units/ml",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "solution for injection in pre-filled pens",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  }]
}

```
