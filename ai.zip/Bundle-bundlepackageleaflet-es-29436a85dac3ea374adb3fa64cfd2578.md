# ePI document Bundle for HIPÉRICO ARKOPHARMA cápsulas duras Package Leaflet for language es - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for HIPÉRICO ARKOPHARMA cápsulas duras Package Leaflet for language es**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Blister** **(cardboard)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** hard capsules ** 

 Unit of presentation: ** hard capsules ** 

Ingredient

 Role: ** active ** 

 Substance: ** Hypericum perforatum L. ** 

Ingredient

 Role: ** excipient ** 

 Substance: ** microcrystalline cellulose ** 

Ingredient

 Role: ** excipient ** 

 Substance: ** magnesium stearate ** 

Ingredient

 Role: ** excipient ** 

 Substance: ** colloidal hydrophobic silica ** 

Ingredient

 Role: ** excipient ** 

 Substance: ** maltodextrin ** 

## Example Bundle: ePI document Bundle for HIPÉRICO ARKOPHARMA cápsulas duras Package Leaflet for language es

**Composition category:**Raw

**Composition status:**final

### B. PROSPECTO

 

unavailable


#### PROSPECTO: INFORMACIÓN PARA EL USUARIO

 

**PROSPECTO: INFORMACIÓN PARA EL USUARIO**

**HIPÉRICO ARKOPHARMA cápsulas duras**

****Hypericum perforatum**** **L.**

** **

**Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.**

Siga exactamente las instrucciones de administración del medicamento contenidas en este prospecto o las indicadas por su farmacéutico, médico o enfermero.

- Conserve este prospecto, ya que puede tener que volver a leerlo.

- Si necesita consejo o más información, consulte a su farmacéutico.

- Si experimenta efectos adversos, consulte a su médico, farmacéutico o enfermero, incluso si se trata de efectos adversos que no aparecen en este prospecto.

- Debe consultar a un médico si empeora o si no mejora después de 28 días de tratamiento.

** **


#### Contenido del prospecto

 

**Contenido del prospecto**

** **

1. Qué es **HIPÉRICO ARKOPHARMA** y para qué se utiliza

2. Qué necesita saber antes de empezar a tomar **HIPÉRICO ARKOPHARMA**

3. Cómo tomar **HIPÉRICO ARKOPHARMA**

4. Posibles efectos adversos

5. Conservación de **HIPÉRICO ARKOPHARMA** 6. Contenido del envase e información adicional.


#### 1. Qué es HIPÉRICO ARKOPHARMA cápsulas duras y para qué se utiliza

 

Medicamento a base de plantas para el tratamiento sintomático de los estados de decaimiento que cursan con desánimo, pérdida de interés, cansancio y alteraciones del sueño.

Debe consultar a un médico si empeora o si no mejora después de 28 días.


#### 2. Qué necesita saber antes de empezar a tomar HIPÉRICO ARKOPHARMA cápsulas duras

 

**No tome HIPÉRICO ARKOPHARMA**

* Si es menor de 18 años.
* Si usted está embarazada o en periodo de lactancia.
* Si es alérgico a **Hypericum perforatum** L. o a cualquiera de los componentes del medicamento.
* Si va a someterse a alguna intervención quirúrgica que requiera tratamiento con otros medicamentos.
* Si usted está en tratamiento con alguno de los medicamentos indicados en este prospecto. Algunos componentes del hipérico (**Hypericum perforatum** L.) pueden producir interacciones farmacocinéticas con gran número de medicamentos, ocasionando un posible descenso de su efectividad; (ver la información sobre la toma de otros medicamentos).

**Advertencias y precauciones**

Consulte a su farmacéutico, médico o enfermero antes de empezar a tomar HIPÉRICO ARKOPHARMA.

Si usted está tomando HIPÉRICO ARKOPHARMA, evite exposiciones intensas a los rayos UV (largas exposiciones al sol o baños de rayos UVA).

Las mujeres que utilizan anticonceptivos orales no deben utilizar simultáneamente este medicamento porque puede producir sangrado entre los ciclos menstruales y falta de eficacia; de los medicamentos anticonceptivos.

Evite las exposiciones a radiación solar intensa o a radiación ultravioleta artificial durante la toma de; este medicamento. No se recomienda el uso de este medicamento durante tratamientos de fototerapia (tratamientos con rayos UVA) o si va a ser sometido a algún estudio de fotodiagnóstico, particularmente en personas de piel clara, ya que se podrían producir; reacciones similares a las quemaduras solares en la piel expuesta.

Si usted ha sido diagnosticado de depresión y está en tratamiento con medicamentos psicotrópicos o con antidepresivos inhibidores selectivos de la recaptación de serotonina o medicamentos del grupo de los triptanos, no debe utilizar este medicamento.

Se deberá dejar de tomar este medicamento 10 días antes de una operación quirúrgica u otra intervención clínica programada a fin de evitar interacciones potenciales con otros medicamentos, durante el uso de anestesia general o local.

**Niños y adolescentes**

No deben utilizar este medicamento los niños y adolescentes menores de 18 años.

**Uso de HIPÉRICO ARKOPHARMA con otros medicamentos**

Algunos componentes del hipérico (**Hypericum perforatum** L.) pueden producir una reducción de los efectos terapéuticos de otros medicamentos, cuando se toman simultáneamente con hipérico. En los tratamientos que pueden verse afectados por este medicamento se incluyen los medicamentos recomendados por su médico y también los que usted puede adquirir sin prescripción del médico.

No deben comenzar a utilizar preparados de hipérico sin consultar antes con su médico o farmacéutico, los pacientes que estén tomando los siguientes medicamentos:

* para el SIDA (antirretrovirales)
* para el rechazo de trasplantes (ciclosporina)
* para la epilepsia
* para el corazón (digoxina)
* para el tratamiento del asma o bronquitis crónica (teofilina)
* para la migraña
* para la depresión
* anticoagulantes orales
* anticonceptivos orales

Para mayor información, consulte la siguiente lista:

No tome este medicamento si usted está en tratamiento con cualquier medicamento de los indicados en este listado:

* Agonistas 5HT (Triptanes): tales como almotriptan, eleptriptan, frovatriptan, naratriptan, rizatriptan, sumatriptan, zolmitriptan;
* Analgésicos: tales como tramadol;
* Anestésicos/ medicamentos para la preparación de una intervención quirúrgica: tales como fentanilo, propofol, midazolam, sevoflurano;
* Ansiolíticos: tales como buspirona;
* Antagonistas hormonales:; tales como exemestano;
* Antianginosos: tales como ivabradina;
* Antiarrítmicos: tales como amiodarona; Antibacterianos: tales como eritromicina, claritromicina, telitromicina;
* Anticoagulantes: tales como warfarina, acenocumarol;
* Anticonceptivos Hormonales: anticonceptivos orales, anticonceptivos hormonales de emergencia (Píldora del día después), implantes e inyecciones hormonales, parches transdérmicos, dispositivos intrauterinos con hormonas;
* Anticonvulsivantes (Antiepilépticos): tales como carbamazepina, fenobarbital, fenitoína, primidona, valproato sódico;
* Antidepresivos Tricíclicos: tales como amitriptilina, clomipramina; IMAO: tales como moclobemida; ISRS (inhibidores selectivos de la recaptación de serotonina) tales como citalopram, fluoxetina, fluvoxamina, paroxetina, sertralina; Otros antidepresivos como duloxetina, venlafaxina;
* Antifúngicos:; tales como itraconazol, voriconazol;
* Antimaláricos: tales como lumefantrina;
* Antiparkinsonianos: tales como rasagilina;
* Antisicóticos:; tales como aripiprazol;
* Todos los Antivirales:; tales como Inhibidores de Proteasa (amprenavir, atazanavir, darunavir, fosamprenavir indinavir, lopinavir, nelfinavir, ritonavir, saquinavir, tipranavir); Inhibidores de transcriptasa inversa no nucleósidos (efavirenz, nevirapina, delavirdina);
* Aprepitant (se utiliza para evitar vómitos, tras un tratamiento con quimioterapia);
* Barbituratos tales como butobarbital, fenobarbital;
* Bloqueadores de los canales del Calcio: tales como amlodipina, nifedipina, verapamilo, felodipina;
* Citotóxicos: como irinotecan, dasatinib, erlotinib, imatinib, sorafenib, sunitinib, etoposido, mitotano;
* Diuréticos: tales como eplerenona;
* Estimulantes de SNC:; tales como metilfenidato;
* Glucósidos cardiacos: tales como digoxina;
* Hipoglucemiantes orales (antidiabéticos orales): tales como gliclazida;
* Hipolipemiantes: tales como; simvastatina, atorvastatina;
* Hormonas tiroideas: todos los medicamentos de esta clase incluido Tiroxina;
* Inhibidores de la bomba de protones: tales como lansoprazol, omeprazol;
* Inmunosupresores: tales como ciclosporina, tacrolimus;
* Litio;
* Teofilina;
* Terapia hormonal de remplazo: tales como los parches, geles, anillo vaginal)

En caso de tratamiento concomitante de HIPÉRICO ARKOPHARMA con medicamentos anticoagulantes (como fenprocumona, warfarina, clopidogrel, ácido acetilsalicílico y otros antireumáticos no esteroideos) no puede excluirse que el efecto de estas preparaciones se vea aumentado.

No puede excluirse que HIPÉRICO ARKOPHARMA actúe sobre la metabolización de otros medicamentos lo que puede afectar a la potencia y/o duración del efecto de los medicamentos a los que se refiere. Por esta razón, consulte con su médico o farmacéutico antes de tomar HIPÉRICO ARKOPHARMA con otros tratamientos.

Informe a su médico o farmacéutico si está tomando o ha tomado recientemente cualquier otro medicamento, incluso los adquiridos sin receta médica.

Informe también a su médico o farmacéutico sobre cualquier sospecha de cambio en los efectos de los medicamentos que está tomando a la vez que HIPÉRICO ARKOPHARMA.

**Toma de HIPÉRICO ARKOPHARMA con los alimentos y bebidas**

Los alimentos y las bebidas no tienen influencia sobre el efecto del medicamento.

**Embarazo, lactancia y fertilidad**

Si está embarazada o en periodo de lactancia, cree que pudiera estar embarazada o tiene intención de quedarse embarazada, consulte a su farmacéutico o médico antes de utilizar este medicamento. No se recomienda su administración en estas circunstancias.

**Conducción y uso de máquinas**

No se han realizado estudios sobre la capacidad de conducir y el uso de máquinas.


#### 3. Cómo tomar HIPÉRICO ARKOPHARMA cápsulas duras

 

Siga exactamente las instrucciones de administración del medicamento contenidas en este prospecto o las indicadas por su farmacéutico, médico o enfermero. En caso de duda, pregunte a su farmacéutico, médico o enfermero.

La dosis recomendada es:

Adultos: tomar 2 cápsulas, 2 ó 3 veces al día con un vaso de agua.

Es aconsejable que las tomas se realicen siempre a las mismas horas.

Este medicamento se utiliza vía oral.

La duración de tratamiento es de 6 semanas.

El efecto del medicamento aparece generalmente a las 4 semanas. Si los síntomas persisten, debería consultar con un profesional sanitario.

Una vez abierto el envase, se retirará la bolsita absorbente que no es apta para consumo humano y no debe ser ingerida.

**Uso en niños y adolescentes**

No utilizar en niños y adolescentes menores de 18 años

**Si toma más HIPÉRICO ARKOPHARMA del que debe**

Si se ha tomado una dosis excesiva de HIPÉRICO ARKOPHARMA pueden aparecer convulsiones o estado de confusión.

En caso de la toma de una dosis excesiva de hipérico, se debe proteger de las radiaciones solares o de cualquier otra fuente de rayos UV durante 1-2 semanas.

En caso de sobredosis o ingestión accidental, consulte inmediatamente a su farmacéutico o médico o llame al Servicio de Información Toxicológica, teléfono 91 562 04 20, indicando el producto y la cantidad ingerida.

**Si olvidó tomar HIPÉRICO ARKOPHARMA**

En caso de olvido de una dosis, tome el medicamento lo antes posible continuando el tratamiento de la forma prescrita. Sin embargo, si está próxima la siguiente dosis, es mejor que no tome la dosis olvidada y espere a la siguiente. En ningún caso tome una dosis doble para compensar la dosis olvidada.


#### 4. Posibles efectos adversos

 

Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.

En casos raros, con una frecuencia que afecta a menos de un caso por cada 1000 pacientes, se han descrito problemas digestivos tales como náusea, dolor abdominal, diarrea, pérdida de apetito; o reacciones en la piel como picor, irritación, enrojecimiento (urticaria) y muy raramente podrían ocurrir reacciones similares a las quemaduras solares, en la piel expuesta a radiación solar o artificial intensa.

También se ha descrito dolor de cabeza, neuropatía, ansiedad, mareo, fatiga, manía o alergias, para los que se desconoce la frecuencia de aparición.

**Comunicación de reacciones adversas**:

Si experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del Sistema Español de Farmacovigilancia de medicamentos de Uso Humano: [_https://www.notificaram.es_](https://www.notificaram.es). Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.


#### 5. Conservación de HIPÉRICO ARKOPHARMA cápsulas duras

 

Mantener este medicamento fuera de la vista y del alcance de los niños.

No conservar a temperatura superior a 25ºC.

Una vez abierto, desechar después de 21 días.

No utilice HIPÉRICO ARKOPHARMA después de la fecha de caducidad que aparece en el envase, después de la abreviatura “CAD”. La fecha de caducidad es el último día del mes que se indica.

Los medicamentos no se deben tirar por los desagües ni a la basura. Deposite los envases y los medicamentos que no necesite en el Punto SIGRE de la farmacia. En caso de duda pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que no necesita. De esta forma, ayudará a proteger el medio ambiente.


#### 6. Contenido del envase e información adicional

 

**Composición de HIPÉRICO ARKOPHARMA**

Cada cápsula contiene como principio activo:

175 mg de extracto seco hidroalcohólico de **Hypericum perforatum** L. herba (sumidades floridas de hipérico) (3.5-6:1) que corresponden a: 0,27 mg a 0,46mg de hipericinas totales, ≥ 10,5 mg de flavonoides y 2,71 mg a 4,63 mg de hiperforina.

Disolvente de extracción: etanol 60% m/m

Los demás componentes son los excipientes: celulosa microcristalina, estearato de magnesio, sílice coloidalhidrófoba y maltodextrina.

Composición de la cápsula: hipromelosa, dióxido de titanio y óxido de hierro amarillo.

**Aspecto del producto y contenido del envase**

Existe 1 presentación en frascos que contienen 42 cápsulas, con una bolsita absorbente en su interior.

Una vez abierto el envase, se retirará la bolsita absorbente que no es apta para consumo humano y no debe ser ingerida.

** **

**Titular de la autorización de comercialización y responsable de la fabricación:**

** **

**Titular**

**Arkopharma LABORATORIOS, S.A.U,**

C/ Amaltea, 9

28045 MADRID

** **

**Responsable de la fabricación**

**ARKOPHARMA**

LABORATOIRES PHARMACEUTIQUES

BP 28 – 06511 CARROS Cedex - FRANCE

** **

**Fecha de la última revisión de este prospecto: septiembre 2016**

** **

La información detallada y actualizada de este medicamento está disponible en la página web de la Agencia Española de Medicamentos y Productos Sanitarios (AEMPS) [_http://www.aemps.gob.es/_](http://www.aemps.gob.es/)


####  HIPÉRICO ARKOPHARMA cápsulas duras 
PMSWI:
** 79963 **
-------

Full name: **HIPÉRICO ARKOPHARMA cápsulas duras**

 - Invented name part: ** HIPÉRICO ARKOPHARMA ** 

 - Scientific name part: ** Hypericum perforatum L. ** 

 - Strength part: ** 175 mg ** 

 - Pharmaceutical dose form part: ** hard capsules ** 

 Name usage: **English ()** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** 79963 ** 

 Region: ** ** 

Marketing authorisation holder: **Arkopharma LABORATORIOS, S.A.U,** 

 Identifier: 
*  **xx** 
 

 Status: ** Active (2015-01-01) ** 

 Package 1 of 1

PMSWI: ** x ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****175 

Administrable Product (1 of 1)

 Dose form: ** Hard capsules ** 

 Unit of presentation: ** hard capsule ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** active ** 

 Substance: ** Hypericum perforatum L. ** 

Ingredient

 Role: ** excipient ** 

 Substance: ** microcrystalline cellulose ** 

Ingredient

 Role: ** excipient ** 

 Substance: ** magnesium stearate ** 

Ingredient

 Role: ** excipient ** 

 Substance: ** colloidal hydrophobic silica ** 

Ingredient

 Role: ** excipient ** 

 Substance: ** maltodextrin ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-es-29436a85dac3ea374adb3fa64cfd2578",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "es",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "79963"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-es-af8d2f6e4772c29a8ef9fbb165e80d28",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-es-af8d2f6e4772c29a8ef9fbb165e80d28",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"es\" lang=\"es\"><a name=\"Composition_composition-es-af8d2f6e4772c29a8ef9fbb165e80d28\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-es-af8d2f6e4772c29a8ef9fbb165e80d28</b></p><a name=\"composition-es-af8d2f6e4772c29a8ef9fbb165e80d28\"> </a><a name=\"hccomposition-es-af8d2f6e4772c29a8ef9fbb165e80d28\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: es</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/79963</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#Organization_mah-c2a5378488511eaedce26dde272c2290\">Organization Arkopharma LABORATORIOS, S.A.U,</a></p><p><b>title</b>: TEST PURPOSES ONLY - HIPÉRICO ARKOPHARMA cápsulas duras</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "79963"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-c2a5378488511eaedce26dde272c2290"
      }],
      "title" : "TEST PURPOSES ONLY - HIPÉRICO ARKOPHARMA cápsulas duras",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. PROSPECTO",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PROSPECTO"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div><p><strong><span>PROSPECTO: INFORMACIÓN PARA EL USUARIO</span></strong></p><p><strong><span>HIPÉRICO ARKOPHARMA cápsulas duras</span></strong></p><p><strong><em><span>Hypericum perforatum</span></em></strong> <strong><span>L.</span></strong></p><p><strong><span>&#xa0;</span></strong></p><p><strong><span>Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.</span></strong></p><p><span>Siga exactamente las instrucciones de administración del medicamento contenidas en este prospecto o las indicadas por su farmacéutico, médico o enfermero.</span></p><p><span>- Conserve este prospecto, ya que puede tener que volver a leerlo.</span></p><p><span>- Si necesita consejo o más información, consulte a su farmacéutico.</span></p><p><span>- Si experimenta efectos adversos, consulte a su médico, farmacéutico o enfermero, incluso si se trata de efectos adversos que no aparecen en este prospecto.</span></p><p><span>- Debe consultar a un médico si empeora o si no mejora después de 28 días de tratamiento.</span></p><p><strong><span>&#xa0;</span></strong></p></div></div>"
          }
        },
        {
          "title" : "Contenido del prospecto",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Contenido del prospecto"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Contenido del prospecto</span></strong></p><p><strong><span>&#xa0;</span></strong></p><p><span>1. Qué es</span> <strong><span>HIPÉRICO ARKOPHARMA</span></strong> <span>y para qué se utiliza</span></p><p><span>2. Qué necesita saber antes de empezar a tomar</span> <strong><span>HIPÉRICO ARKOPHARMA</span></strong></p><p><span>3. Cómo tomar</span> <strong><span>HIPÉRICO ARKOPHARMA</span></strong></p><p><span>4. Posibles efectos adversos</span></p><p><span>5. Conservación de</span> <strong><span>HIPÉRICO ARKOPHARMA</span></strong> <span>6. Contenido del envase e información adicional.</span></p></div>"
          }
        },
        {
          "title" : "1. Qué es HIPÉRICO ARKOPHARMA cápsulas duras y para qué se utiliza",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Qué es HIPÉRICO ARKOPHARMA cápsulas duras y para qué se utiliza"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div><p><span>Medicamento a base de plantas para el tratamiento sintomático de los estados de decaimiento que cursan con desánimo, pérdida de interés, cansancio y alteraciones del sueño.</span></p><p><span>Debe consultar a un médico si empeora o si no mejora después de 28 días.</span></p></div></div>"
          }
        },
        {
          "title" : "2. Qué necesita saber antes de empezar a tomar HIPÉRICO ARKOPHARMA cápsulas duras",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Qué necesita saber antes de empezar a tomar HIPÉRICO ARKOPHARMA cápsulas duras"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>No tome HIPÉRICO ARKOPHARMA</span></strong></p><ul><li><span>Si es menor de 18 años.</span></li><li><span>Si usted está embarazada o en periodo de lactancia.</span></li><li><span>Si es alérgico a</span> <em><span>Hypericum perforatum</span></em> <span>L. o a cualquiera de los componentes del medicamento.</span></li><li><span>Si va a someterse a alguna intervención quirúrgica que requiera tratamiento con otros medicamentos.</span></li><li><span>Si usted está en tratamiento con alguno de los medicamentos indicados en este prospecto. Algunos componentes del hipérico (</span><em><span>Hypericum perforatum</span></em> <span>L.) pueden producir interacciones farmacocinéticas con gran número de medicamentos, ocasionando un posible descenso de su efectividad; (ver la información sobre la toma de otros medicamentos).</span></li></ul><p><strong><span>Advertencias y precauciones</span></strong></p><p><span>Consulte a su farmacéutico, médico o enfermero antes de empezar a tomar HIPÉRICO ARKOPHARMA.</span></p><p><span>Si usted está tomando HIPÉRICO ARKOPHARMA, evite exposiciones intensas a los rayos UV (largas exposiciones al sol o baños de rayos UVA).</span></p><p><span>Las mujeres que utilizan anticonceptivos orales no deben utilizar simultáneamente este medicamento porque puede producir sangrado entre los ciclos menstruales y falta de eficacia; de los medicamentos anticonceptivos.</span><a name=\"OLE_LINK3\" id=\"OLE_LINK3\"></a></p><p><span>Evite las exposiciones a radiación solar intensa o a radiación ultravioleta artificial durante la toma de; este medicamento. No se recomienda el uso de este medicamento durante tratamientos de fototerapia (tratamientos con rayos UVA) o si va a ser sometido a algún estudio de fotodiagnóstico, particularmente en personas de piel clara, ya que se podrían producir; reacciones similares a las quemaduras solares en la piel expuesta</span><span>.</span></p><p><span>Si usted ha sido diagnosticado de depresión y está en tratamiento con medicamentos psicotrópicos o con antidepresivos inhibidores selectivos de la recaptación de serotonina o medicamentos del grupo de los triptanos, no debe utilizar este medicamento.</span></p><p><span>Se deberá dejar de tomar este medicamento 10 días antes de una operación quirúrgica u otra intervención clínica programada a fin de evitar interacciones potenciales con otros medicamentos, durante el uso de anestesia general o local.</span></p><p><strong><span>Niños y adolescentes</span></strong></p><p><span>No deben utilizar este medicamento los niños y adolescentes menores de 18 años.</span></p><p><strong><span>Uso de HIPÉRICO ARKOPHARMA con otros medicamentos</span></strong></p><p><span>Algunos componentes del hipérico (</span><em><span>Hypericum perforatum</span></em> <span>L.) pueden producir una reducción de los efectos terapéuticos de otros medicamentos, cuando se toman simultáneamente con hipérico. En los tratamientos que pueden verse afectados por este medicamento se incluyen los medicamentos recomendados por su médico y también los que usted puede adquirir sin prescripción del médico.</span></p><p><span>No deben comenzar a utilizar preparados de hipérico sin consultar antes con su médico o farmacéutico, los pacientes que estén tomando los siguientes medicamentos:</span></p><ul><li><span>para el SIDA (antirretrovirales)</span></li><li><span>para el rechazo de trasplantes (ciclosporina)</span></li><li><span>para la epilepsia</span></li><li><span>para el corazón (digoxina)</span></li><li><span>para el tratamiento del asma o bronquitis crónica (teofilina)</span></li><li><span>para la migraña</span></li><li><span>para la depresión</span></li><li><span>anticoagulantes orales</span></li><li><span>anticonceptivos orales</span></li></ul><p><span>Para mayor información, consulte la siguiente lista:</span></p><p><span>No tome este medicamento si usted está en tratamiento con cualquier medicamento de los indicados en este listado:</span></p><ul><li>Agonistas 5HT (Triptanes): tales como almotriptan, eleptriptan, frovatriptan, naratriptan, rizatriptan, sumatriptan, zolmitriptan;</li><li>Analgésicos: tales como tramadol;</li><li>Anestésicos/ medicamentos para la preparación de una intervención quirúrgica: tales como fentanilo, propofol, midazolam, sevoflurano;</li><li>Ansiolíticos: tales como buspirona;</li><li>Antagonistas hormonales:; tales como exemestano;</li><li>Antianginosos: tales como ivabradina;</li><li>Antiarrítmicos: tales como amiodarona; Antibacterianos: tales como eritromicina, claritromicina, telitromicina;</li><li>Anticoagulantes: tales como warfarina, acenocumarol;</li><li>Anticonceptivos Hormonales: anticonceptivos orales, anticonceptivos hormonales de emergencia (Píldora del día después), implantes e inyecciones hormonales, parches transdérmicos, dispositivos intrauterinos con hormonas;</li><li>Anticonvulsivantes (Antiepilépticos): tales como carbamazepina, fenobarbital, fenitoína, primidona, valproato sódico;</li><li>Antidepresivos Tricíclicos: tales como amitriptilina, clomipramina; IMAO: tales como moclobemida; ISRS (inhibidores selectivos de la recaptación de serotonina) tales como citalopram, fluoxetina, fluvoxamina, paroxetina, sertralina; Otros antidepresivos como duloxetina, venlafaxina;</li><li>Antifúngicos:; tales como itraconazol, voriconazol;</li><li>Antimaláricos: tales como lumefantrina;</li><li>Antiparkinsonianos: tales como rasagilina;</li><li>Antisicóticos:; tales como aripiprazol;</li><li>Todos los Antivirales:; tales como Inhibidores de Proteasa (amprenavir, atazanavir, darunavir, fosamprenavir indinavir, lopinavir, nelfinavir, ritonavir, saquinavir, tipranavir); Inhibidores de transcriptasa inversa no nucleósidos (efavirenz, nevirapina, delavirdina);</li><li>Aprepitant (se utiliza para evitar vómitos, tras un tratamiento con quimioterapia);</li><li>Barbituratos tales como butobarbital, fenobarbital;</li><li>Bloqueadores de los canales del Calcio: tales como amlodipina, nifedipina, verapamilo, felodipina;</li><li>Citotóxicos: como irinotecan, dasatinib, erlotinib, imatinib, sorafenib, sunitinib, etoposido, mitotano;</li><li>Diuréticos: tales como eplerenona;</li><li>Estimulantes de SNC:; tales como metilfenidato;</li><li>Glucósidos cardiacos: tales como digoxina;</li><li>Hipoglucemiantes orales (antidiabéticos orales): tales como gliclazida;</li><li>Hipolipemiantes: tales como; simvastatina, atorvastatina;</li><li>Hormonas tiroideas: todos los medicamentos de esta clase incluido Tiroxina;</li><li>Inhibidores de la bomba de protones: tales como lansoprazol, omeprazol;</li><li>Inmunosupresores: tales como ciclosporina, tacrolimus;</li><li>Litio;</li><li>Teofilina;</li><li>Terapia hormonal de remplazo: tales como los parches, geles, anillo vaginal)</li></ul><p><span>En caso de tratamiento concomitante de HIPÉRICO ARKOPHARMA con medicamentos anticoagulantes (como fenprocumona, warfarina, clopidogrel, ácido acetilsalicílico y otros antireumáticos no esteroideos) no puede excluirse que el efecto de estas preparaciones se vea aumentado</span><span>.</span></p><p><span>No puede excluirse que HIPÉRICO ARKOPHARMA actúe sobre la metabolización de otros medicamentos lo que puede afectar a la potencia y/o duración del efecto de los medicamentos a los que se refiere. Por esta razón, consulte con su médico o farmacéutico antes de tomar HIPÉRICO ARKOPHARMA con otros tratamientos.</span></p><p><span>Informe a su médico o farmacéutico si está tomando o ha tomado recientemente cualquier otro medicamento, incluso los adquiridos sin receta médica.</span></p><p><span>Informe también a su médico o farmacéutico sobre cualquier sospecha de cambio en los efectos de los medicamentos que está tomando a la vez que HIPÉRICO ARKOPHARMA.</span></p><p><strong><span>Toma de HIPÉRICO ARKOPHARMA con los alimentos y bebidas</span></strong></p><p><span>Los alimentos y las bebidas no tienen influencia sobre el efecto del medicamento.</span></p><p><strong><span>Embarazo, lactancia y fertilidad</span></strong></p><p><span>Si está embarazada o en periodo de lactancia, cree que pudiera estar embarazada o tiene intención de quedarse embarazada, consulte a su farmacéutico o médico antes de utilizar este medicamento. No se recomienda su administración en estas circunstancias.</span></p><p><strong><span>Conducción y uso de máquinas</span></strong></p><p><span>No se han realizado estudios sobre la capacidad de conducir y el uso de máquinas</span><span>.</span></p></div>"
          }
        },
        {
          "title" : "3. Cómo tomar HIPÉRICO ARKOPHARMA cápsulas duras",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Cómo tomar HIPÉRICO ARKOPHARMA cápsulas duras"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div><p><span>Siga exactamente las instrucciones de administración del medicamento contenidas en este prospecto o las indicadas por su farmacéutico, médico o enfermero. En caso de duda, pregunte a su farmacéutico, médico o enfermero.</span></p><p><span>La dosis recomendada es:</span></p><p><span>Adultos: tomar 2 cápsulas, 2 ó 3 veces al día con un vaso de agua.</span></p><p><span>Es aconsejable que las tomas se realicen siempre a las mismas horas.</span></p><p><span>Este medicamento se utiliza vía oral.</span></p><p><span>La duración de tratamiento es de 6 semanas.</span></p><p><span>El efecto del medicamento aparece generalmente a las 4 semanas. Si los síntomas persisten, debería consultar con un profesional sanitario.</span></p><p><span>Una vez abierto el envase, se retirará la bolsita absorbente que no es apta para consumo humano y no debe ser ingerida.</span></p><p><strong><span>Uso en niños y adolescentes</span></strong></p><p><span>No utilizar en niños y adolescentes menores de 18 años</span></p><p><strong><span>Si toma más HIPÉRICO ARKOPHARMA del que debe</span></strong></p><p><span>Si se ha tomado una dosis excesiva de HIPÉRICO ARKOPHARMA pueden aparecer convulsiones o estado de confusión.</span></p><p><span>En caso de la toma de una dosis excesiva de hipérico, se debe proteger de las radiaciones solares o de cualquier otra fuente de rayos UV durante 1-2 semanas.</span></p><p><span>En caso de sobredosis o ingestión accidental, consulte inmediatamente a su farmacéutico o médico o llame al Servicio de Información Toxicológica, teléfono 91 562 04 20, indicando el producto y la cantidad ingerida.</span></p><p><strong><span>Si olvidó tomar HIPÉRICO ARKOPHARMA</span></strong></p><p><span>En caso de olvido de una dosis, tome el medicamento lo antes posible continuando el tratamiento de la forma prescrita. Sin embargo, si está próxima la siguiente dosis, es mejor que no tome la dosis olvidada y espere a la siguiente. En ningún caso tome una dosis doble para compensar la dosis olvidada</span><span>.</span></p></div></div>"
          }
        },
        {
          "title" : "4. Posibles efectos adversos",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Posibles efectos adversos"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div><p><span>Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.</span></p><p><span>En casos raros, con una frecuencia que afecta a menos de un caso por cada 1000 pacientes, se han descrito problemas digestivos tales como náusea, dolor abdominal, diarrea, pérdida de apetito; o reacciones en la piel como picor, irritación, enrojecimiento (urticaria) y muy raramente podrían ocurrir reacciones similares a las quemaduras solares, en la piel expuesta a radiación solar o artificial intensa.</span></p><p><span>También se ha descrito dolor de cabeza, neuropatía, ansiedad, mareo, fatiga, manía o alergias, para los que se desconoce la frecuencia de aparición.</span></p><p><strong><span>Comunicación de reacciones adversas</span></strong><span>:</span></p><p><span>Si experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del Sistema Español de Farmacovigilancia de medicamentos de Uso Humano:</span> <a href=\"https://www.notificaram.es\"><u><span>https://www.notificaram.es</span></u></a><span>. Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.</span></p></div></div>"
          }
        },
        {
          "title" : "5. Conservación de HIPÉRICO ARKOPHARMA cápsulas duras",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Conservación de HIPÉRICO ARKOPHARMA cápsulas duras"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div><p><span>Mantener este medicamento fuera de la vista y del alcance de los niños.</span></p><p><span>No conservar a temperatura superior a 25ºC.</span></p><p><span>Una vez abierto, desechar después de 21 días.</span></p><p><span>No utilice HIPÉRICO ARKOPHARMA después de la fecha de caducidad que aparece en el envase, después de la abreviatura “CAD”. La fecha de caducidad es el último día del mes que se indica.</span></p><p><span>Los medicamentos no se deben tirar por los desagües ni a la basura. Deposite los envases y los medicamentos que no necesite en el Punto SIGRE</span> <span>de la farmacia. En caso de duda pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que no necesita. De esta forma, ayudará a proteger el medio ambiente</span><span>.</span></p></div></div>"
          }
        },
        {
          "title" : "6. Contenido del envase e información adicional",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contenido del envase e información adicional"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div><p><strong><span>Composici&#243;n de HIP&#201;RICO ARKOPHARMA</span></strong></p><p><span>Cada c&#225;psula contiene como principio activo:</span></p><p><span>175 mg de extracto seco hidroalcoh&#243;lico de</span> <em><span>Hypericum perforatum</span></em> <span>L. herba (sumidades floridas de hip&#233;rico) (3.5-6:1) que corresponden a: 0,27 mg a 0,46mg de hipericinas totales, &#8805; 10,5 mg de flavonoides y 2,71 mg a 4,63 mg de hiperforina.</span></p><p><span>Disolvente de extracci&#243;n: etanol 60% m/m</span></p><p><span>Los dem&#225;s componentes son los excipientes: celulosa microcristalina, estearato de magnesio, s&#237;lice coloidalhidr&#243;foba y maltodextrina.</span></p><p><span>Composici&#243;n de la</span> <span>c&#225;psula: hipromelosa, di&#243;xido de titanio y &#243;xido de hierro amarillo.</span></p><p><strong><span>Aspecto del producto y contenido del envase</span></strong></p><p><span>Existe 1 presentaci&#243;n en frascos que contienen 42 c&#225;psulas, con una bolsita absorbente en su interior.</span></p><p><span>Una vez abierto el envase, se retirar&#225; la bolsita absorbente que no es apta para consumo humano y no debe ser ingerida.</span></p><p><strong><span>&#xa0;</span></strong></p><p><strong><span>Titular de la autorizaci&#243;n de comercializaci&#243;n y responsable de la fabricaci&#243;n:</span></strong></p><p><strong><span>&#xa0;</span></strong></p><p><strong><span>Titular</span></strong></p><p><strong><span>Arkopharma LABORATORIOS, S.A.U,</span></strong></p><p><span>C/ Amaltea, 9</span></p><p><span>28045 MADRID</span></p><p><strong><span>&#xa0;</span></strong></p><p><strong><span>Responsable de la fabricaci&#243;n</span></strong></p><p><strong><span>ARKOPHARMA</span></strong></p><p><span>LABORATOIRES PHARMACEUTIQUES</span></p><p><span>BP 28 &#8211; 06511 CARROS Cedex - FRANCE</span></p><p><strong><span>&#xa0;</span></strong></p><p><strong><span>Fecha de la &#250;ltima revisi&#243;n de este prospecto: septiembre 2016</span></strong></p><p><strong><span>&#xa0;</span></strong></p><p><span>La informaci&#243;n detallada y actualizada de este medicamento est&#225; disponible en la p&#225;gina web de la Agencia Espa&#241;ola de Medicamentos y Productos Sanitarios (AEMPS)</span> <a href=\"http://www.aemps.gob.es/\"><u><span>http://www.aemps.gob.es/</span></u></a></p></div></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-hipricoarkopharma-hypericumperforatuml",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-hipricoarkopharma-hypericumperforatuml",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-hipricoarkopharma-hypericumperforatuml\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-hipricoarkopharma-hypericumperforatuml</b></p><a name=\"ingredient-for-hipricoarkopharma-hypericumperforatuml\"> </a><a name=\"hcingredient-for-hipricoarkopharma-hypericumperforatuml\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/XK4IUX8MNB (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#ManufacturedItemDefinition_mid-29436a85dac3ea374adb3fa64cfd2578\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963 (use: official, ); status = active; manufacturedDoseForm = hard capsules; unitOfPresentation = hard capsules</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#AdministrableProductDefinition_ap-29436a85dac3ea374adb3fa64cfd2578\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#xx; status = active; administrableDoseForm = Hard capsules; unitOfPresentation = hard capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 72072}\">active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta XK4IUX8MNB}\">Hypericum perforatum L.</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>175 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "XK4IUX8MNB"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-29436a85dac3ea374adb3fa64cfd2578"
      },
      {
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-29436a85dac3ea374adb3fa64cfd2578"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "72072",
          "display" : "active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "XK4IUX8MNB",
              "display" : "Hypericum perforatum L."
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 175,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-hipricoarkopharma-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-hipricoarkopharma-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-hipricoarkopharma-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-hipricoarkopharma-microcrystallinecellulose</b></p><a name=\"ingredient-for-hipricoarkopharma-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-hipricoarkopharma-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#ManufacturedItemDefinition_mid-29436a85dac3ea374adb3fa64cfd2578\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963 (use: official, ); status = active; manufacturedDoseForm = hard capsules; unitOfPresentation = hard capsules</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#AdministrableProductDefinition_ap-29436a85dac3ea374adb3fa64cfd2578\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#xx; status = active; administrableDoseForm = Hard capsules; unitOfPresentation = hard capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-29436a85dac3ea374adb3fa64cfd2578"
      },
      {
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-29436a85dac3ea374adb3fa64cfd2578"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-hipricoarkopharma-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-hipricoarkopharma-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-hipricoarkopharma-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-hipricoarkopharma-magnesiumstearate</b></p><a name=\"ingredient-for-hipricoarkopharma-magnesiumstearate\"> </a><a name=\"hcingredient-for-hipricoarkopharma-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#ManufacturedItemDefinition_mid-29436a85dac3ea374adb3fa64cfd2578\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963 (use: official, ); status = active; manufacturedDoseForm = hard capsules; unitOfPresentation = hard capsules</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#AdministrableProductDefinition_ap-29436a85dac3ea374adb3fa64cfd2578\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#xx; status = active; administrableDoseForm = Hard capsules; unitOfPresentation = hard capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-29436a85dac3ea374adb3fa64cfd2578"
      },
      {
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-29436a85dac3ea374adb3fa64cfd2578"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-hipricoarkopharma-colloidalhydrophobicsilica",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-hipricoarkopharma-colloidalhydrophobicsilica",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-hipricoarkopharma-colloidalhydrophobicsilica\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-hipricoarkopharma-colloidalhydrophobicsilica</b></p><a name=\"ingredient-for-hipricoarkopharma-colloidalhydrophobicsilica\"> </a><a name=\"hcingredient-for-hipricoarkopharma-colloidalhydrophobicsilica\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/8MDF5V39QO (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#ManufacturedItemDefinition_mid-29436a85dac3ea374adb3fa64cfd2578\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963 (use: official, ); status = active; manufacturedDoseForm = hard capsules; unitOfPresentation = hard capsules</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#AdministrableProductDefinition_ap-29436a85dac3ea374adb3fa64cfd2578\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#xx; status = active; administrableDoseForm = Hard capsules; unitOfPresentation = hard capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 8MDF5V39QO}\">colloidal hydrophobic silica</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "8MDF5V39QO"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-29436a85dac3ea374adb3fa64cfd2578"
      },
      {
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-29436a85dac3ea374adb3fa64cfd2578"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "8MDF5V39QO",
              "display" : "colloidal hydrophobic silica"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-hipricoarkopharma-maltodextrin",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-hipricoarkopharma-maltodextrin",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-hipricoarkopharma-maltodextrin\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-hipricoarkopharma-maltodextrin</b></p><a name=\"ingredient-for-hipricoarkopharma-maltodextrin\"> </a><a name=\"hcingredient-for-hipricoarkopharma-maltodextrin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/7CVR7L4A2D (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#ManufacturedItemDefinition_mid-29436a85dac3ea374adb3fa64cfd2578\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963 (use: official, ); status = active; manufacturedDoseForm = hard capsules; unitOfPresentation = hard capsules</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#AdministrableProductDefinition_ap-29436a85dac3ea374adb3fa64cfd2578\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#xx; status = active; administrableDoseForm = Hard capsules; unitOfPresentation = hard capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 7CVR7L4A2D}\">maltodextrin</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "7CVR7L4A2D"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-29436a85dac3ea374adb3fa64cfd2578"
      },
      {
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-29436a85dac3ea374adb3fa64cfd2578"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "7CVR7L4A2D",
              "display" : "maltodextrin"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-hypericumperforatumwhole",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-hypericumperforatumwhole",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-hypericumperforatumwhole\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-hypericumperforatumwhole</b></p><a name=\"substance-hypericumperforatumwhole\"> </a><a name=\"hcsubstance-hypericumperforatumwhole\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/XK4IUX8MNB (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#Organization_mah-c2a5378488511eaedce26dde272c2290\">Organization Arkopharma LABORATORIOS, S.A.U,</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>156.09</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C35H52O4</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Hyperforin</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "XK4IUX8MNB"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/mah-c2a5378488511eaedce26dde272c2290"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 156.09
        }
      }],
      "structure" : {
        "molecularFormula" : "C35H52O4"
      },
      "name" : [{
        "name" : "Hyperforin",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-29436a85dac3ea374adb3fa64cfd2578",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-29436a85dac3ea374adb3fa64cfd2578",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-29436a85dac3ea374adb3fa64cfd2578\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-29436a85dac3ea374adb3fa64cfd2578</b></p><a name=\"ap-29436a85dac3ea374adb3fa64cfd2578\"> </a><a name=\"hcap-29436a85dac3ea374adb3fa64cfd2578\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/xx</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073681}\">Hard capsules</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">hard capsule</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#ManufacturedItemDefinition_mid-29436a85dac3ea374adb3fa64cfd2578\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963 (use: official, ); status = active; manufacturedDoseForm = hard capsules; unitOfPresentation = hard capsules</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "xx"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073681",
          "display" : "Hard capsules"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "hard capsule"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-29436a85dac3ea374adb3fa64cfd2578"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization29436a85dac3ea374adb3fa64cfd25780",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization29436a85dac3ea374adb3fa64cfd25780",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization29436a85dac3ea374adb3fa64cfd25780\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization29436a85dac3ea374adb3fa64cfd25780</b></p><a name=\"authorization29436a85dac3ea374adb3fa64cfd25780\"> </a><a name=\"hcauthorization29436a85dac3ea374adb3fa64cfd25780\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/79963 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072062}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-01-01</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#Organization_mah-c2a5378488511eaedce26dde272c2290\">Organization Arkopharma LABORATORIOS, S.A.U,</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "79963"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072062",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-01-01",
      "holder" : {
        "reference" : "Organization/mah-c2a5378488511eaedce26dde272c2290"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-c2a5378488511eaedce26dde272c2290",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-c2a5378488511eaedce26dde272c2290",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-c2a5378488511eaedce26dde272c2290\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-c2a5378488511eaedce26dde272c2290</b></p><a name=\"mah-c2a5378488511eaedce26dde272c2290\"> </a><a name=\"hcmah-c2a5378488511eaedce26dde272c2290\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/xx (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Arkopharma LABORATORIOS, S.A.U,</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>C/ Amaltea, 9 Madrid ES(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "xx"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Arkopharma LABORATORIOS, S.A.U,",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "C/ Amaltea, 9 Madrid ES",
          "line" : ["C/ Amaltea, 9"],
          "city" : "Madrid",
          "postalCode" : "28045",
          "country" : "ES"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-ee8bd93e975dcd04f4824ba8d24a8944",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-ee8bd93e975dcd04f4824ba8d24a8944",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-ee8bd93e975dcd04f4824ba8d24a8944\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-ee8bd93e975dcd04f4824ba8d24a8944</b></p><a name=\"ppd-ee8bd93e975dcd04f4824ba8d24a8944\"> </a><a name=\"hcppd-ee8bd93e975dcd04f4824ba8d24a8944\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/x (use: official, )</p><p><b>name</b>: HIPÉRICO ARKOPHARMA cápsulas duras 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Prodcut</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-01-03</p><p><b>containedItemQuantity</b>: 175 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>copackagedIndicator</b>: false</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi xxx}\">cardboard</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-en-29436a85dac3ea374adb3fa64cfd2578.html#ManufacturedItemDefinition_mid-29436a85dac3ea374adb3fa64cfd2578\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#79963 (use: official, ); status = active; manufacturedDoseForm = hard capsules; unitOfPresentation = hard capsules</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "x"
      }],
      "name" : "HIPÉRICO ARKOPHARMA cápsulas duras 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Prodcut"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-01-03",
      "containedItemQuantity" : [{
        "value" : 175,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "copackagedIndicator" : false,
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "xxx",
              "display" : "cardboard"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-29436a85dac3ea374adb3fa64cfd2578"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mpaf8d2f6e4772c29a8ef9fbb165e80d28",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mpaf8d2f6e4772c29a8ef9fbb165e80d28",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mpaf8d2f6e4772c29a8ef9fbb165e80d28\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mpaf8d2f6e4772c29a8ef9fbb165e80d28</b></p><a name=\"mpaf8d2f6e4772c29a8ef9fbb165e80d28\"> </a><a name=\"hcmpaf8d2f6e4772c29a8ef9fbb165e80d28\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/79963</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000000000}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: HIPÉRICO ARKOPHARMA cápsulas duras</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: HIPÉRICO ARKOPHARMA</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Hypericum perforatum L.</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 175 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: hard capsules</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 ES}\">Spain</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 ES}\">Spain</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "79963"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000000000",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "HIPÉRICO ARKOPHARMA cápsulas duras",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "HIPÉRICO ARKOPHARMA",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "Hypericum perforatum L.",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "175 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "hard capsules",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "ES"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "ES"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-29436a85dac3ea374adb3fa64cfd2578",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-29436a85dac3ea374adb3fa64cfd2578",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-29436a85dac3ea374adb3fa64cfd2578\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-29436a85dac3ea374adb3fa64cfd2578</b></p><a name=\"mid-29436a85dac3ea374adb3fa64cfd2578\"> </a><a name=\"hcmid-29436a85dac3ea374adb3fa64cfd2578\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/79963 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073681}\">hard capsules</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">hard capsules</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "79963"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073681",
          "display" : "hard capsules"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "hard capsules"
        }]
      }
    }
  }]
}

```
