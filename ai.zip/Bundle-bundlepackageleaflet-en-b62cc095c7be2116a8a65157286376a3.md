# ePI document Bundle for amoxicillin 250 mg tablets Package Leaflet for language en - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for amoxicillin 250 mg tablets Package Leaflet for language en**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **15 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Capsule ** 

 Unit of presentation: ** Capsule ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Active ** 

 Substance: ** AMOXICILLIN ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

## Example Bundle: ePI document Bundle for amoxicillin 250 mg tablets Package Leaflet for language en

**Composition category:**Raw

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.

* Keep this leaflet. You may need to read it again.
* If you have any further questions, ask your doctor or pharmacist.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their sign of illness are the same as yours.
* If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.


#### What is in this leaflet

 

What is in this leaflet

1. What Amoxicillin capsules is and what it is used for
1. What you need to know before you take Amoxicillin capsules
1. How to take Amoxicillin capsules
1. Possible side effects
1. How to store Amoxicillin capsules
1. Contents of the pack and other information


#### 1. What amoxicillin is and what it is used for

 

# What Amoxicillin capsules is and what it is used for

What Amoxicillin Capsule is Amoxicillin 250 mg and 500 mg Capsules is an antibiotic. The active ingredient is amoxicillin. This belongs to a group of medicines called ‘penicillins’.

What Amoxicillin Capsule is used for Amoxicillin Capsule is used to treat infections caused by bacteria in different parts of the body. Amoxicillin Capsule may also be used in combination with other medicines to treat stomach ulcers.


#### 2. What you need to know before you take amoxicillin

 

**Do not take Amoxicillin capsule:**

* if you are allergic to amoxicillin, penicillin or any of the other ingredients of this medicine (listed in section 6)
* if you have ever had an allergic reaction to any antibiotic. This can include a skin rash or swelling of the face or throat. Do not take Amoxicillin Capsules if any of the above apply. If you are not sure, talk to your doctor or pharmacist before taking Amoxicillin Capsules.

**Warnings and Precautions**

Talk to your doctor or pharmacist before taking Amoxicillin Capsule if you:

* have glandular fever (fever, sore throat, swollen glands and extreme tiredness)
* have kidney problems
* are not urinating regularly. If you are not sure if any of the above apply to you, talk to your doctor or pharmacist before taking Amoxicillin Capsules.

**Blood and urine tests**

If you are having:

* Urine tests (glucose) or blood tests for liver function
* Oestriol tests (used during pregnancy to check the baby is developing normally) Tell your doctor or pharmacist that you are taking Amoxicillin Capsule. This is because Amoxicillin Capsule can affect the results of these tests.

**Other medicines and Amoxicillin Capsules**

Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines.

* If you are taking allopurinol (used for gout) with Amoxicillin Capsules, it may be more likely that you will have an allergic skin reaction.
* If you are taking probenecid, (used to treat gout), concomitant use of probenecid may reduce the excretion of amoxicillin and is not recommended. Your doctor may decide to adjust your dose of Amoxicillin Capsules.
* If you are taking medicines to help stop blood clots (such as warfarin), you may need extra blood tests.
* If you are taking other antibiotics (such as tetracycline) Amoxicillin Capsules may be less effective.
* If you are taking methotrexate (used to treat cancer and severe psoriasis), penicillins may reduce the excretion of methotrexate causing a potential increase in side effects.

**Pregnancy and breast-feeding**

If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor or pharmacist for advice before taking this medicine.

**Driving and using machines**

Amoxicillin Capsules can have side effects and the symptoms (such as allergic reactions, dizziness and convulsions) may make you unfit to drive. Do not drive or operate machinery unless you are feeling well.


#### 3. How to take amoxicillin

 

Always take this medicine exactly as your doctor or pharmacist has told you. Check with your doctor or pharmacist if you are not sure.

* Swallow with water without opening capsule.
* Space the doses evenly during the day, at least 4 hours apart.

The recommended dose is:

**Children weighing less than 40 kg**

All doses are worked out depending on the child’s body weight in kilograms.

* Your doctor will advise you how much Amoxicillin Capsules you should give to your baby or child.
* The usual dose is 40 mg to 90 mg for each kilogram of body weight a day, given in two or three divided doses.
* The maximum recommended dose is 100 mg for each kilogram of body weight a day.

**Adults, elderly patients and children weighing 40 kg or more**

The usual dose of Amoxicillin Capsules is 250 mg to 500 mg three times a day or 750 mg to 1 g every 12 hours, depending on the severity and type of infection.

* Severe infections: 750 mg to 1 g three times a day.
* Urinary tract infection: 3 g twice daily for one day.
* Lyme disease (an infection spread by parasites called ticks): Isolated erythema migrans (early stage – red or pink circular rash): 4 g a day, Systemic manifestations (late stage – for more serious symptoms or when the disease spreads around your body): up to 6 g a day.
* Stomach ulcers: one 750 mg or one 1 g dose twice a day for 7 days with other antibiotics and medicines to treat stomach ulcers.
* To prevent heart infection during surgery: the dose will vary according to the type of surgery. Other medicines may also be given at the same time. Your doctor, pharmacist or nurse can give you more details.
* The maximum recommended dose is 6 g per day.

**Kidney problems**

If you have kidney problems the dose might be lower than the usual dose.

**If you take more Amoxicillin Capsules than you should**

If you have taken too much Amoxicillin Capsules, signs might be an upset stomach (feeling sick, being sick or diarrhoea) or crystals in the urine, which may be seen as cloudy urine, or problems urinating. Talk to your doctor as soon as possible. Take the medicine to show the doctor.

**If you forget to take Amoxicillin Capsules**

* If you forget to take a dose, take it as soon as you remember.
* Do not take the next dose too soon, wait about 4 hours before taking the next dose.
* Do not take a double dose to make up for a forgotten dose. How long should you take Amoxicillin Capsules for?
* Keep taking Amoxicillin Capsules for as long as your doctor has told you to, even if you feel better. You need every dose to help fight the infection. If some bacteria survive they can cause the infection to come back.
* Once you finish treatment, if you still feel unwell you should go back to see the doctor. Thrush (a yeast infection of moist areas of the body which can cause soreness, itching and white discharge) may develop if Amoxicillin Capsules is used for a long time. If this occurs tell your doctor. If you take Amoxicillin Capsules for a long time, your doctor may perform additional tests to check your kidneys, liver and blood are working normally. If you have any further questions on the use of this medicine, ask your doctor or pharmacist.


#### 4. Possible side effects

 

Like all medicines, this medicine can cause side effects, although not everybody gets them. Stop taking Amoxicillin Capsules and see a doctor straight away, if you notice any of the following serious side effects – you may need urgent medical treatment:

The following are very rare (may affect up to 1 in 10,000 people)

* allergic reactions, the signs may include: skin itching or rash, swelling of the face, lips, tongue, body or breathing difficulties. These can be serious and occasionally deaths have occurred
* rash or pinpoint flat red round spots under the skin surface or bruising of the skin. This is due to inflammation of blood vessel walls due to an allergic reaction. It can be associated with joint pain (arthritis) and kidney problems
* a delayed allergic reaction can occur usually 7 to 12 days after having Amoxicillin Capsules, some signs include: rashes, fever, joint pains and enlargement of the lymph nodes especially under the arms
* a skin reaction known as ‘erythema multiforme’ where you may develop: itchy reddish purple patches on the skin especially on the palms of the hands or soles of the feet, ‘hive-like’raised swollen areas on the skin, tender areas on the surfaces of the mouth, eyes and genitals. You may have a fever and be very tired
* other severe skin reactions can include: changes in skin colour, bumps under the skin, blistering, pustules, peeling, redness, pain, itching, scaling. These may be associated with fever, headaches and body aches
* flu-like symptoms with a rash, fever, swollen glands, and abnormal blood test results (including increased white blood cells (eosinophilia) and liver enzymes) (Drug Reaction with Eosinophilia and Systemic Symptoms (DRESS)).
* high temperature (fever), chills, a sore throat or other signs of an infection, or if you bruise easily. These may be signs of a problem with your blood cells
* the Jarisch-Herxheimer reaction which occur during treatment with Amoxicillin Capsules for Lyme disease and causes fever, chills, headache, muscle pain and skin rash.
* inflammation of the large bowel (colon) with diarrhoea (sometimes containing blood), pain and fever
* serious liver side effects may occur. They are mainly associated with people having treatment over a long period, males and the elderly. You must tell doctor urgently if you get:
* severe diarrhoea with bleeding
* blisters, redness or bruising of the skin
* darker urine or paler stools
* yellowing of the skin or the whites of the eyes (jaundice). See also anaemia below which might result in jaundice.

**These can happen when having the medicines or for up to several weeks after.**

If any of the above happens stop taking the medicine and see your doctor straight away. Sometimes you may get less severe skin reactions such as:

* a middle itchy rash (round, pink-red patches), ‘hive-like’ swollen areas on forearms, legs, palms, hands or feet. This is uncommon (may affect up to 1 in 100 people). If you have any of these talk to your doctor as Amoxicillin Capsules will need to be stopped. The other possible side effects are:

**Common (may affect up to 1 in 10 people)**

* skin rash
* feeling sick (nausea)
* diarrhoea.

**Uncommon (may affect up to 1 in 100 people)**

* being sick (vomiting).

**Very rare (may affect up to 1 in 10,000 people)**

* thrush (a yeast infection of the vagina, mouth or skin folds), you can get treatment for thrush from your doctor or pharmacist
* kidney problems
* fits (convulsions), seen in patients on high doses or with kidney problems
* dizziness
* hyperactivity
* crystals in urine, leading to acute renal injury which may be seen as cloudy urine, or difficulty or discomfort in passing urine. Make sure you drink plenty of fluids to reduce the chances of these symptoms
* the tongue may change to yellow, brown or black and it may have a hairy appearance
* an excessive breakdown of red blood cells causing a form of anaemia. Signs include: tiredness, headaches, shortness of breath, dizziness, looking pale and yellowing of the skin and the whites of the eyes
* low number of white blood cells
* low number of cells involved in blood clotting
* the blood may take longer to clot than it normally would. You may notice this if you have a nosebleed or cut yourself.
* Chest pain in the context of allergic reactions, which may be a symptom of allergy triggered cardiac infarction (Kounis syndrome)
* Drug-induced enterocolitis syndrome (DIES): DIES has been reported mainly in children receiving amoxicillin. It is a certain kind of allergic reaction with the leading symptom of repetitive vomiting (1-4 hours after drug administration). Further symptoms could comprise abdominal pain, lethargy, diarrhoea, and low blood pressure.
* Rash with blisters arranged in a circle with central crusting or like a string of pearls (linear IgA disease)
* Inflammation of the membranes that surround the brain and spinal cord (aseptic meningitis) Reporting of side effects If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via Yellow Card Scheme, Website: www.mhra.gov.uk/yellowcard. By reporting side effects you can help provide more information on the safety of this medicine.


#### 5. How to store amoxicillin

 

Keep this medicine out of the sight and reach of children.

Do not use this medicine after the expiry date which is stated on the carton after EXP. The expiry date refers to the last day of that month.

Store in the original pack below 30°C.

Do not use this medicine if you notice visible signs of deterioration.

Do not throw away any medicines via waste water or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.


#### 6. Contents of the pack and other information

 

unavailable


####  amoxicillin 250 mg tablets 
IDS:
** hack-1 **
-------

Full name: **amoxicillin 250 mg tablets**

 - Invented name part: ** Amoxicillin ** 

 - Scientific name part: ** AMOXY ** 

 - Strength part: ** 250 mg ** 

 - Pharmaceutical dose form part: ** tablet ** 

 Name usage: **English (United kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** hack-1 ** 

 Region: ** ** 

Marketing authorisation holder: **ACME industry** 

 Identifier: 
*  **ORG-100000789** 
 

 Status: ** Active (2015-02-07T13:28:17Z) ** 

 Package 1 of 1

PMSWI: ** 10637 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****250 

Administrable Product (1 of 1)

 Dose form: ** Capsule ** 

 Unit of presentation: ** Capsule ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Active ** 

 Substance: ** AMOXICILLIN ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "hack-1"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-en-b62cc095c7be2116a8a65157286376a3",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-en-b62cc095c7be2116a8a65157286376a3",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_composition-en-b62cc095c7be2116a8a65157286376a3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-en-b62cc095c7be2116a8a65157286376a3</b></p><a name=\"composition-en-b62cc095c7be2116a8a65157286376a3\"> </a><a name=\"hccomposition-en-b62cc095c7be2116a8a65157286376a3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/hack-1</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#Organization_mah-0880223fada9f23e0f3760dee80fc7a3\">Organization ACME industry</a></p><p><b>title</b>: TEST PURPOSES ONLY - amoxicillin 250 mg tablets</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "hack-1"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-0880223fada9f23e0f3760dee80fc7a3"
      }],
      "title" : "TEST PURPOSES ONLY - amoxicillin 250 mg tablets",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. Package Leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.</p><ul><li>Keep this leaflet. You may need to read it again.</li><li>If you have any further questions, ask your doctor or pharmacist.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their sign of illness are the same as yours.</li><li>If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.</li></ul></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>What is in this leaflet</p><ol><li>What Amoxicillin capsules is and what it is used for</li><li>What you need to know before you take Amoxicillin capsules</li><li>How to take Amoxicillin capsules</li><li>Possible side effects</li><li>How to store Amoxicillin capsules</li><li>Contents of the pack and other information</li></ol></div>"
          }
        },
        {
          "title" : "1. What amoxicillin is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What amoxicillin is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1 id=\"what-amoxicillin-capsules-is-and-what-it-is-used-for\">What Amoxicillin capsules is and what it is used for</h1><p>What Amoxicillin Capsule is Amoxicillin 250 mg and 500 mg Capsules is an antibiotic. The active ingredient is amoxicillin. This belongs to a group of medicines called ‘penicillins’.</p><p>What Amoxicillin Capsule is used for Amoxicillin Capsule is used to treat infections caused by bacteria in different parts of the body. Amoxicillin Capsule may also be used in combination with other medicines to treat stomach ulcers.</p></div>"
          }
        },
        {
          "title" : "2. What you need to know before you take amoxicillin",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take amoxicillin"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Do not take Amoxicillin capsule:</strong></p><ul><li>if you are allergic to amoxicillin, penicillin or any of the other ingredients of this medicine (listed in section 6)</li><li>if you have ever had an allergic reaction to any antibiotic. This can include a skin rash or swelling of the face or throat. Do not take Amoxicillin Capsules if any of the above apply. If you are not sure, talk to your doctor or pharmacist before taking Amoxicillin Capsules.</li></ul><p><strong>Warnings and Precautions</strong></p><p>Talk to your doctor or pharmacist before taking Amoxicillin Capsule if you:</p><ul><li>have glandular fever (fever, sore throat, swollen glands and extreme tiredness)</li><li>have kidney problems</li><li>are not urinating regularly. If you are not sure if any of the above apply to you, talk to your doctor or pharmacist before taking Amoxicillin Capsules.</li></ul><p><strong>Blood and urine tests</strong></p><p>If you are having:</p><ul><li>Urine tests (glucose) or blood tests for liver function</li><li>Oestriol tests (used during pregnancy to check the baby is developing normally) Tell your doctor or pharmacist that you are taking Amoxicillin Capsule. This is because Amoxicillin Capsule can affect the results of these tests.</li></ul><p><strong>Other medicines and Amoxicillin Capsules</strong></p><p>Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines.</p><ul><li>If you are taking allopurinol (used for gout) with Amoxicillin Capsules, it may be more likely that you will have an allergic skin reaction.</li><li>If you are taking probenecid, (used to treat gout), concomitant use of probenecid may reduce the excretion of amoxicillin and is not recommended. Your doctor may decide to adjust your dose of Amoxicillin Capsules.</li><li>If you are taking medicines to help stop blood clots (such as warfarin), you may need extra blood tests.</li><li>If you are taking other antibiotics (such as tetracycline) Amoxicillin Capsules may be less effective.</li><li>If you are taking methotrexate (used to treat cancer and severe psoriasis), penicillins may reduce the excretion of methotrexate causing a potential increase in side effects.</li></ul><p><strong>Pregnancy and breast-feeding</strong></p><p>If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor or pharmacist for advice before taking this medicine.</p><p><strong>Driving and using machines</strong></p><p>Amoxicillin Capsules can have side effects and the symptoms (such as allergic reactions, dizziness and convulsions) may make you unfit to drive. Do not drive or operate machinery unless you are feeling well.</p></div>"
          }
        },
        {
          "title" : "3. How to take amoxicillin",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take amoxicillin"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Always take this medicine exactly as your doctor or pharmacist has told you. Check with your doctor or pharmacist if you are not sure.</p><ul><li>Swallow with water without opening capsule.</li><li>Space the doses evenly during the day, at least 4 hours apart.</li></ul><p>The recommended dose is:</p><p><strong>Children weighing less than 40 kg</strong></p><p>All doses are worked out depending on the child’s body weight in kilograms.</p><ul><li>Your doctor will advise you how much Amoxicillin Capsules you should give to your baby or child.</li><li>The usual dose is 40 mg to 90 mg for each kilogram of body weight a day, given in two or three divided doses.</li><li>The maximum recommended dose is 100 mg for each kilogram of body weight a day.</li></ul><p><strong>Adults, elderly patients and children weighing 40 kg or more</strong></p><p>The usual dose of Amoxicillin Capsules is 250 mg to 500 mg three times a day or 750 mg to 1 g every 12 hours, depending on the severity and type of infection.</p><ul><li>Severe infections: 750 mg to 1 g three times a day.</li><li>Urinary tract infection: 3 g twice daily for one day.</li><li>Lyme disease (an infection spread by parasites called ticks): Isolated erythema migrans (early stage – red or pink circular rash): 4 g a day, Systemic manifestations (late stage – for more serious symptoms or when the disease spreads around your body): up to 6 g a day.</li><li>Stomach ulcers: one 750 mg or one 1 g dose twice a day for 7 days with other antibiotics and medicines to treat stomach ulcers.</li><li>To prevent heart infection during surgery: the dose will vary according to the type of surgery. Other medicines may also be given at the same time. Your doctor, pharmacist or nurse can give you more details.</li><li>The maximum recommended dose is 6 g per day.</li></ul><p><strong>Kidney problems</strong></p><p>If you have kidney problems the dose might be lower than the usual dose.</p><p><strong>If you take more Amoxicillin Capsules than you should</strong></p><p>If you have taken too much Amoxicillin Capsules, signs might be an upset stomach (feeling sick, being sick or diarrhoea) or crystals in the urine, which may be seen as cloudy urine, or problems urinating. Talk to your doctor as soon as possible. Take the medicine to show the doctor.</p><p><strong>If you forget to take Amoxicillin Capsules</strong></p><ul><li>If you forget to take a dose, take it as soon as you remember.</li><li>Do not take the next dose too soon, wait about 4 hours before taking the next dose.</li><li>Do not take a double dose to make up for a forgotten dose. How long should you take Amoxicillin Capsules for?</li><li>Keep taking Amoxicillin Capsules for as long as your doctor has told you to, even if you feel better. You need every dose to help fight the infection. If some bacteria survive they can cause the infection to come back.</li><li>Once you finish treatment, if you still feel unwell you should go back to see the doctor. Thrush (a yeast infection of moist areas of the body which can cause soreness, itching and white discharge) may develop if Amoxicillin Capsules is used for a long time. If this occurs tell your doctor. If you take Amoxicillin Capsules for a long time, your doctor may perform additional tests to check your kidneys, liver and blood are working normally. If you have any further questions on the use of this medicine, ask your doctor or pharmacist.</li></ul></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Like all medicines, this medicine can cause side effects, although not everybody gets them. Stop taking Amoxicillin Capsules and see a doctor straight away, if you notice any of the following serious side effects – you may need urgent medical treatment:</p><p>The following are very rare (may affect up to 1 in 10,000 people)</p><ul><li>allergic reactions, the signs may include: skin itching or rash, swelling of the face, lips, tongue, body or breathing difficulties. These can be serious and occasionally deaths have occurred</li><li>rash or pinpoint flat red round spots under the skin surface or bruising of the skin. This is due to inflammation of blood vessel walls due to an allergic reaction. It can be associated with joint pain (arthritis) and kidney problems</li><li>a delayed allergic reaction can occur usually 7 to 12 days after having Amoxicillin Capsules, some signs include: rashes, fever, joint pains and enlargement of the lymph nodes especially under the arms</li><li>a skin reaction known as ‘erythema multiforme’ where you may develop: itchy reddish purple patches on the skin especially on the palms of the hands or soles of the feet, ‘hive-like’raised swollen areas on the skin, tender areas on the surfaces of the mouth, eyes and genitals. You may have a fever and be very tired</li><li>other severe skin reactions can include: changes in skin colour, bumps under the skin, blistering, pustules, peeling, redness, pain, itching, scaling. These may be associated with fever, headaches and body aches</li><li>flu-like symptoms with a rash, fever, swollen glands, and abnormal blood test results (including increased white blood cells (eosinophilia) and liver enzymes) (Drug Reaction with Eosinophilia and Systemic Symptoms (DRESS)).</li><li>high temperature (fever), chills, a sore throat or other signs of an infection, or if you bruise easily. These may be signs of a problem with your blood cells</li><li>the Jarisch-Herxheimer reaction which occur during treatment with Amoxicillin Capsules for Lyme disease and causes fever, chills, headache, muscle pain and skin rash.</li><li>inflammation of the large bowel (colon) with diarrhoea (sometimes containing blood), pain and fever</li><li>serious liver side effects may occur. They are mainly associated with people having treatment over a long period, males and the elderly. You must tell doctor urgently if you get:<ul><li>severe diarrhoea with bleeding</li><li>blisters, redness or bruising of the skin</li><li>darker urine or paler stools</li><li>yellowing of the skin or the whites of the eyes (jaundice). See also anaemia below which might result in jaundice.</li></ul></li></ul><p><em>These can happen when having the medicines or for up to several weeks after.</em></p><p>If any of the above happens stop taking the medicine and see your doctor straight away. Sometimes you may get less severe skin reactions such as:</p><ul><li>a middle itchy rash (round, pink-red patches), ‘hive-like’ swollen areas on forearms, legs, palms, hands or feet. This is uncommon (may affect up to 1 in 100 people). If you have any of these talk to your doctor as Amoxicillin Capsules will need to be stopped. The other possible side effects are:</li></ul><p><em>Common (may affect up to 1 in 10 people)</em></p><ul><li>skin rash</li><li>feeling sick (nausea)</li><li>diarrhoea.</li></ul><p><em>Uncommon (may affect up to 1 in 100 people)</em></p><ul><li>being sick (vomiting).</li></ul><p><em>Very rare (may affect up to 1 in 10,000 people)</em></p><ul><li>thrush (a yeast infection of the vagina, mouth or skin folds), you can get treatment for thrush from your doctor or pharmacist</li><li>kidney problems</li><li>fits (convulsions), seen in patients on high doses or with kidney problems</li><li>dizziness</li><li>hyperactivity</li><li>crystals in urine, leading to acute renal injury which may be seen as cloudy urine, or difficulty or discomfort in passing urine. Make sure you drink plenty of fluids to reduce the chances of these symptoms</li><li>the tongue may change to yellow, brown or black and it may have a hairy appearance</li><li>an excessive breakdown of red blood cells causing a form of anaemia. Signs include: tiredness, headaches, shortness of breath, dizziness, looking pale and yellowing of the skin and the whites of the eyes</li><li>low number of white blood cells</li><li>low number of cells involved in blood clotting</li><li>the blood may take longer to clot than it normally would. You may notice this if you have a nosebleed or cut yourself.</li><li>Chest pain in the context of allergic reactions, which may be a symptom of allergy triggered cardiac infarction (Kounis syndrome)</li><li>Drug-induced enterocolitis syndrome (DIES): DIES has been reported mainly in children receiving amoxicillin. It is a certain kind of allergic reaction with the leading symptom of repetitive vomiting (1-4 hours after drug administration). Further symptoms could comprise abdominal pain, lethargy, diarrhoea, and low blood pressure.</li><li>Rash with blisters arranged in a circle with central crusting or like a string of pearls (linear IgA disease)</li><li>Inflammation of the membranes that surround the brain and spinal cord (aseptic meningitis) Reporting of side effects If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via Yellow Card Scheme, Website: www.mhra.gov.uk/yellowcard. By reporting side effects you can help provide more information on the safety of this medicine.</li></ul></div>"
          }
        },
        {
          "title" : "5. How to store amoxicillin",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store amoxicillin"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keep this medicine out of the sight and reach of children.</p><p>Do not use this medicine after the expiry date which is stated on the carton after EXP. The expiry date refers to the last day of that month.</p><p>Store in the original pack below 30°C.</p><p>Do not use this medicine if you notice visible signs of deterioration.</p><p>Do not throw away any medicines via waste water or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-croscarmellosesodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-croscarmellosesodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-croscarmellosesodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-croscarmellosesodium</b></p><a name=\"ingredient-for-amox-croscarmellosesodium\"> </a><a name=\"hcingredient-for-amox-croscarmellosesodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/M28OL1HH48 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta M28OL1HH48}\">Croscarmellose sodium</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "M28OL1HH48"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "M28OL1HH48",
              "display" : "Croscarmellose sodium"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-microcrystallinecellulose</b></p><a name=\"ingredient-for-amox-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-amox-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">Microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "Microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-amoxicillin",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-amoxicillin",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-amoxicillin\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-amoxicillin</b></p><a name=\"ingredient-for-amox-amoxicillin\"> </a><a name=\"hcingredient-for-amox-amoxicillin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/804826J2HU (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 804826J2HU}\">AMOXICILLIN</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>250 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "804826J2HU"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "804826J2HU",
              "display" : "AMOXICILLIN"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 250,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-hypromellose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-hypromellose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-hypromellose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-hypromellose</b></p><a name=\"ingredient-for-amox-hypromellose\"> </a><a name=\"hcingredient-for-amox-hypromellose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/3NXW29V3WO (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 3NXW29V3WO}\">Hypromellose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "3NXW29V3WO"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "3NXW29V3WO",
              "display" : "Hypromellose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-macrogol3000",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-macrogol3000",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-macrogol3000\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-macrogol3000</b></p><a name=\"ingredient-for-amox-macrogol3000\"> </a><a name=\"hcingredient-for-amox-macrogol3000\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/SA1B764746 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta SA1B764746}\">Macrogol 3000</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "SA1B764746"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "SA1B764746",
              "display" : "Macrogol 3000"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-lactosemonohydrate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-lactosemonohydrate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-lactosemonohydrate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-lactosemonohydrate</b></p><a name=\"ingredient-for-amox-lactosemonohydrate\"> </a><a name=\"hcingredient-for-amox-lactosemonohydrate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EWQ57Q8I5X (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EWQ57Q8I5X}\">Lactose Monohydrate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EWQ57Q8I5X"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EWQ57Q8I5X",
              "display" : "Lactose Monohydrate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-silicondioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-silicondioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-silicondioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-silicondioxide</b></p><a name=\"ingredient-for-amox-silicondioxide\"> </a><a name=\"hcingredient-for-amox-silicondioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/ETJ7Z6XBU4 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta ETJ7Z6XBU4}\">Silicon dioxide</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "ETJ7Z6XBU4"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "ETJ7Z6XBU4",
              "display" : "Silicon dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-titaniumdioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-titaniumdioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-titaniumdioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-titaniumdioxide</b></p><a name=\"ingredient-for-amox-titaniumdioxide\"> </a><a name=\"hcingredient-for-amox-titaniumdioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/15FIX9V2JP (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 15FIX9V2JP}\">Titanium Dioxide</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "15FIX9V2JP"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "15FIX9V2JP",
              "display" : "Titanium Dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-magnesiumstearate</b></p><a name=\"ingredient-for-amox-magnesiumstearate\"> </a><a name=\"hcingredient-for-amox-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-amox-carnaubawax",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-amox-carnaubawax",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-amox-carnaubawax\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-amox-carnaubawax</b></p><a name=\"ingredient-for-amox-carnaubawax\"> </a><a name=\"hcingredient-for-amox-carnaubawax\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/R12CBM0EIZ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#10637; status = active; administrableDoseForm = Capsule; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta R12CBM0EIZ}\">Carnauba wax</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "R12CBM0EIZ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "R12CBM0EIZ",
              "display" : "Carnauba wax"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-amoxicillin",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-amoxicillin",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-amoxicillin\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-amoxicillin</b></p><a name=\"substance-amoxicillin\"> </a><a name=\"hcsubstance-amoxicillin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/804826J2HU (use: official, )</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#Organization_mah-0880223fada9f23e0f3760dee80fc7a3\">Organization ACME industry</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "804826J2HU"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/mah-0880223fada9f23e0f3760dee80fc7a3"
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-b62cc095c7be2116a8a65157286376a3",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-b62cc095c7be2116a8a65157286376a3",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-b62cc095c7be2116a8a65157286376a3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-b62cc095c7be2116a8a65157286376a3</b></p><a name=\"ap-b62cc095c7be2116a8a65157286376a3\"> </a><a name=\"hcap-b62cc095c7be2116a8a65157286376a3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/10637</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000016452}\">Capsule</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002113}\">Capsule</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "10637"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000016452",
          "display" : "Capsule"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002113",
          "display" : "Capsule"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationb62cc095c7be2116a8a65157286376a30",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationb62cc095c7be2116a8a65157286376a30",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationb62cc095c7be2116a8a65157286376a30\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationb62cc095c7be2116a8a65157286376a30</b></p><a name=\"authorizationb62cc095c7be2116a8a65157286376a30\"> </a><a name=\"hcauthorizationb62cc095c7be2116a8a65157286376a30\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/hack-1 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#Organization_mah-0880223fada9f23e0f3760dee80fc7a3\">Organization ACME industry</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "hack-1"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-0880223fada9f23e0f3760dee80fc7a3"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-0880223fada9f23e0f3760dee80fc7a3",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-0880223fada9f23e0f3760dee80fc7a3",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-0880223fada9f23e0f3760dee80fc7a3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-0880223fada9f23e0f3760dee80fc7a3</b></p><a name=\"mah-0880223fada9f23e0f3760dee80fc7a3\"> </a><a name=\"hcmah-0880223fada9f23e0f3760dee80fc7a3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100000789 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: ACME industry</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>street x and y Paris FR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100000789"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "ACME industry",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "street x and y Paris FR",
          "line" : ["street x and y"],
          "city" : "Paris",
          "country" : "FR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-eac9778d48eb0b894852b7d0d82c3aa8",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-eac9778d48eb0b894852b7d0d82c3aa8",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-eac9778d48eb0b894852b7d0d82c3aa8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-eac9778d48eb0b894852b7d0d82c3aa8</b></p><a name=\"ppd-eac9778d48eb0b894852b7d0d82c3aa8\"> </a><a name=\"hcppd-eac9778d48eb0b894852b7d0d82c3aa8\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/10637 (use: official, )</p><p><b>name</b>: amoxicillin 250 mg tablets 15</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#hack-1; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 250 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 15</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-en-b62cc095c7be2116a8a65157286376a3.html#ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#106036 (use: official, ); status = active; manufacturedDoseForm = Capsule; unitOfPresentation = Capsule</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "10637"
      }],
      "name" : "amoxicillin 250 mg tablets 15",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 250,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 15,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mpb62cc095c7be2116a8a65157286376a3",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mpb62cc095c7be2116a8a65157286376a3",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mpb62cc095c7be2116a8a65157286376a3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mpb62cc095c7be2116a8a65157286376a3</b></p><a name=\"mpb62cc095c7be2116a8a65157286376a3\"> </a><a name=\"hcmpb62cc095c7be2116a8a65157286376a3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>http://fakesys.com/ids</code>/hack-1</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: amoxicillin 250 mg tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Amoxicillin</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: AMOXY</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 250 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 UK}\">United kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 UK}\">United kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://fakesys.com/ids",
        "value" : "hack-1"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "amoxicillin 250 mg tablets",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Amoxicillin",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "AMOXY",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "250 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "tablet",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "UK",
              "display" : "United kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "UK",
              "display" : "United kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-b62cc095c7be2116a8a65157286376a3",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-b62cc095c7be2116a8a65157286376a3",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-b62cc095c7be2116a8a65157286376a3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-b62cc095c7be2116a8a65157286376a3</b></p><a name=\"mid-b62cc095c7be2116a8a65157286376a3\"> </a><a name=\"hcmid-b62cc095c7be2116a8a65157286376a3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/106036 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 200000016452}\">Capsule</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002113}\">Capsule</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "106036"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "200000016452",
          "display" : "Capsule"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002113",
          "display" : "Capsule"
        }]
      }
    }
  }]
}

```
