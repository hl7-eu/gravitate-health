# FK40963 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK40963**

## Example Bundle: FK40963

**Composition category:**

**Composition status:**final

### Indlægsseddel: Information til patienten

 

## Indlægsseddel: Information til brugeren

### Entocort, hårde kapsler med modificeret udløsning 3 mg

budesonid

### Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger.

* Gem indlægssedlen. Du kan få brug for at læse den igen.
* Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide.
* Lægen har ordineret Entocort til dig personligt. Lad derfor være med at give det til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.
* Tal med lægen eller apotekspersonalet, hvis en bivirkning bliver værre, eller du får bivirkninger, som ikke er nævnt her.

 

Den nyeste indlægsseddel kan findes på
[www.indlaegsseddel.dk](https://www.indlaegsseddel.dk).

### Oversigt over indlægssedlen

1. Virkning og anvendelse
1. Det skal du vide, før du begynder at tage Entocort
1. Sådan skal du tage Entocort
1. Bivirkninger
1. Opbevaring
1. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

 

## 1. Virkning og anvendelse

Entocort, kapsler med modificeret udløsning, indeholder et binyrebarkhormon, der dæmper den betændelse, som forekommer ved Crohns sygdom.

Du kan bruge Entocort til behandling af Crohns sygdom i tyndtarmen og den øverste del af tyktarmen.

 

Mikroskopisk colitis: Entocort kapsler anvendes til behandling af mikroskopisk colitis (en sygdom med kronisk betændelse i tyktarmen der typisk er med kronisk vandig diarré).

 

Lægen kan have givet dig Entocort for noget andet. Følg altid lægens anvisning.


#### 2. Det skal du vide, før du begynder at tage Entocort

 

 

## 2. Det skal du vide, før du begynder at tage Entocort

### Tag ikke Entocort

* hvis du er allergisk over for budesonid eller et af de øvrige indholdsstoffer i Entocort (angivet i [pkt. 6](#Section6)).
* hvis du har betændelse i tarmen, som skyldes svamp, virus eller bakterier.

### Advarsler og forsigtighedsregler

Kontakt lægen eller apoteket, før du tager Entocort:

* hvis du har tuberkulose
* hvis du har eller for nylig havde en infektion
* hvis du har leversygdomme
* hvis du har knogleskørhed
* hvis du har mavesår
* hvis du har for højt blodtryk
* hvis du har sukkersyge
* hvis du har grå eller grøn stær
* hvis du samtidig er i behandling mod svamp (ketoconazol, itraconazol)

 

Fortæl også lægen, hvis der er nogen i din familie, som har sukkersyge eller grøn stær.

Skoldkopper og mæslinger kan få et mere alvorligt forløb når du er i behandling med Entocort. Kontakt lægen hvis du har været udsat for smitte og ikke tidligere har haft sygdommene eller ikke er blevet vaccineret mod dem.

Sig det til lægen, hvis du oplever sløret syn eller andre synsforstyrrelser.

Kontakt lægen hvis du skifter fra anden medicin med binyrebarkhormon til Entocort, eller når du slutter din behandling med Entocort. Du kan få udslæt, høfeber eller smerter i muskler og led, træthed, hovedpine, kvalme og opkastning.

Hvis du skal opereres, skal du fortælle lægen, at du er i behandling med Entocort.

### Børn og teenagere

Lægen vil regelmæssigt kontrollere højden hos børn, der behandles med Entocort i længere tid. Hvis væksten er nedsat, bør behandlingen overvejes påny.

### Brug af anden medicin sammen med Entocort

Fortæl altid lægen eller på apoteket, hvis du bruger anden medicin eller har gjort det for nylig. Det gælder også medicin, som ikke er købt på recept, f.eks. naturlægemidler og vitaminer og mineraler.

Entocort kan påvirke virkningen af anden medicin, ligesom anden medicin kan ændre virkningen af Entocort. Tal med din læge, hvis du tager:

* ketoconazol eller itrakonazol (svampemiddel)
* østrogener og p-piller (kvindeligt kønshormon)
* carbamazepin (mod epilepsi)
* nogle lægemidler kan øge virkningen af Entocort, og din læge vil overvåge dig omhyggeligt, hvis du tager sådanne lægemidler (inklusive visse former for HIV-medicin, herunder ritonavir (eller andre HIV-proteasehæmmere) og cobicistat).

 

På grund af hæmning af binyrebarkfunktionen kan diagnostiske test af hypofyse-aktiviteten vise fejlagtige lave værdier.

### Brug af Entocort sammen med mad og drikke

Du kan tage Entocort sammen med mad og drikke, dog skal du ikke tage det sammen med grapefrugt eller grapefrugtjuice.

### Graviditet, amning og fertilitet

Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge eller apoteket til råds, før du tager Entocort.

### Trafik- og arbejdssikkerhed

Entocort påvirker ikke arbejdssikkerheden eller evnen til at færdes sikkert i trafikken.

### Entocort indeholder saccharose

Entocort, kapsler med modificeret udløsning, indeholder saccharose. Kontakt lægen, før du tager denne medicin, hvis lægen har fortalt dig, at du ikke tåler visse sukkerarter.


#### 3. Sådan skal du tage Entocort

 

 

## 3. Sådan skal du tage Entocort

Tag altid Entocort nøjagtigt efter lægens anvisning. Er du i tvivl, så spørg lægen eller på apoteket. Ændring eller stop af behandlingen bør kun ske i samråd med lægen.

 

**Du skal synke kapslerne hele med vand. Du må ikke dele eller tygge kapslerne.**

 

**Crohns sygdom**

**Den sædvanlige dosering er:**

**Voksne:**

**Dosis ved aktiv sygdom:**

3 kapsler (9 mg) én gang daglig om morgenen i op til 8 uger.

Det tager normalt 2-4 uger, inden Entocort giver fuld virkning.

 

**Dosis til forhindring af tilbagefald af sygdommen:**

2 kapsler (6 mg) én gang daglig om morgenen.

Tal med din læge, hvis du tager medicinen i længere tid. Dosis bør holdes så lav som muligt.

 

**Dosis til patienter, der har været i behandling med medicin, der indeholder prednisolon:**

2 kapsler (6 mg) én gang daglig om morgenen.

Når du starter med Entocort, skal du langsomt aftrappe prednisolonbehandlingen. Det skal altid ske i samråd med din læge.

 

**Hvis du afbryder behandlingen, skal du nedtrappe dosis gradvist. Tal med lægen.**

 

**Mikroskopisk colitis**

**Voksne:
Dosis ved aktiv sygdom:**

3 kapsler (9 mg) én gang daglig om morgenen i op til 8 uger. Det tager normalt 2-4 uger, inden Entocort giver fuld virkning. Når behandlingen skal ophøre, bør dosis normalt reduceres
**gradvist. Tal med lægen.**

 

**Dosis til forhindring af tilbagefald af sygdommen:**

Individuelt, men dosis bør holdes så lavt som muligt. Tal med din læge, hvis du tager medicinen i længere tid.

 

**Ældre:**

Det er ikke nødvendigt at ændre dosis. Følg lægens anvisning.

 

**Brug til børn:**

Du må ikke give Entocort til børn. Følg lægens anvisning

### Hvis du har taget for mange Entocort, kapsler med modificeret udløsning

Kontakt lægen, skadestuen eller apoteket, hvis du har taget flere Entocort, kapsler med modificeret udløsning, end der står i denne information, eller mere end lægen har foreskrevet, og du føler dig utilpas. Tag pakningen med.

**Symptomer ved overdosering:**

Hvis du gennem længere tid tager for mange kapsler, kan der opstå symptomer, der er nævnt under afsnittet om bivirkninger.

### Hvis du har glemt at tage Entocort

Du må ikke tage en dobbeltdosis som erstatning for den glemte dosis. Fortsæt blot med den sædvanlige dosis.


#### 4. Bivirkninger

 

 

## 4. Bivirkninger

Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger.

 

**Almindelige bivirkninger**(forekommer hos mellem 1 og 10 ud af 100 behandlede):

* tendens til måneansigt (Cushing-lignende træk)
* nervøsitet, søvnløshed, humørsvingninger og depression
* hjertebanken
* fordøjelsesbesvær
* muskelkramper
* menstruationsforstyrrelser
* hududslæt og nældefeber
* svaghed og nedsat kraft i musklerne pga. for lavt kalium i blodet. For lavt kalium i blodet kan i meget sjældne tilfælde blive alvorlig med lammelser og forstyrrelser i hjertets rytme (risiko for hjertestop). Tal med lægen.

 

**Ikke almindelige bivirkninger**(forekommer hos mellem 1 og 10 ud af 1000 behandlede):

* rysten
* utilsigtede bevægelser eller ekstrem rastløshed eventuelt med muskelspasmer eller trækninger
* angst
* sår i mavesæk eller tolvfingertarm

 

**Sjældne bivirkninger **(forekommer hos mellem 1 og 10 ud af 10.000 behandlede):

* aggression
* hovedpine, kvalme, synsnedsættelse og regnbuesyn pga. forhøjet tryk i øjet (grøn stær). Kontakt straks læge eller skadestue
* uklarhed af øjets naturlige linse herunder bagsiden af linsen, sløret syn
* misfarvning af huden, som følge af blødning under huden
* betændt bugspytkirtel (forbundet med smerter i øvre maveregion og ryggen samt kvalme)
* knoglevævsdød på grund af nedsat blodtilførsel til knoglen

 

**Meget sjældne bivirkninger**(forekommer hos færre end 1 ud af 10.000 behandlede):

* pludseligt hududslæt, åndedrætsbesvær og besvimelse (inden for minutter til timer) pga. overfølsomhed (anafylaktisk reaktion). **Kan være livsfarligt. Ring 112.**
* nedsat vækst hos børn.

 

De fleste bivirkninger, nævnt i denne liste, kan også forventes for andre behandlinger med glukokortikoider.

### Indberetning af bivirkninger

Hvis du oplever bivirkninger, bør du tale med din læge eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via de oplysninger, der fremgår herunder.

 

Lægemiddelstyrelsen

Axel Heides Gade 1

DK-2300 København S

Websted: www.meldenbivirkning.dk

 

Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.

[Meld en bivirkning.](https://www.meldenbivirkning.dk)


#### 5. Opbevaring

 

 

## 5. Opbevaring

Opbevar Entocort utilgængeligt for børn.

Opbevar Entocort i original emballage, tæt tillukket, da medicinen er følsom over for fugt.

Brug ikke Entocort efter den udløbsdato, der står på pakningen. Udløbsdatoen er den sidste dag i den nævnte måned.

Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

 

## 6. Pakningsstørrelser og yderligere oplysninger

### Entocort, hårde kapsler med modificeret udløsning 3 mg indeholder:

* Aktivt stof: Budesonid.
* Øvrige indholdsstoffer: Ethylcellulose; tributylacetylcitrat; methacrylsyre copolymer; triethylcitrat (E1505); simeticon; polysorbat 80; talcum. Sukkerkugler (bestående af saccharose og majsstivelse).
Kapsel: Gelatine; titandioxid (E171); rød jernoxid (E172).

### Udseende

Entocort 3 mg, kapsler med modificeret udløsning er af hård gelatine med en ugennemskinnelig, lysegrå kerne og uigennemskinnelig lyserød kapsel. Kapslen er mærket CIR på den ene side og 3 mg på den anden.

### Pakningsstørrelser

50 kapsler, 100 kapsler.

Ikke alle pakningsstørrelser er nødvendigvis markedsført.


####  

-------

Full name: ****

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK40963",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
    "value" : "40963"
  },
  "type" : "document",
  "timestamp" : "2022-07-26T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK40963-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK40963-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_FK40963-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK40963-COMP</b></p><a name=\"FK40963-COMP\"> </a><a name=\"hcFK40963-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/</code>/40963</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2022-07-26</p><p><b>author</b>: Identifier: <code>https://medicin.dk</code>/medicin.dk</p><p><b>title</b>: Entocort® 3 mg kapsler med modificeret udløsning</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
        "value" : "40963"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "date" : "2022-07-26",
      "author" : [{
        "identifier" : {
          "system" : "https://medicin.dk",
          "value" : "medicin.dk"
        }
      }],
      "title" : "Entocort® 3 mg kapsler med modificeret udløsning",
      "section" : [{
        "title" : "Indlægsseddel: Information til patienten",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section0\"/><h2>Indlægsseddel: Information til brugeren</h2><h3>Entocort, hårde kapsler med modificeret udløsning 3 mg</h3><div class=\"paragraph\">budesonid</div><h3>Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger.</h3><ul><li>Gem indlægssedlen. Du kan få brug for at læse den igen.</li><li>Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide.</li><li>Lægen har ordineret Entocort til dig personligt. Lad derfor være med at give det til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.</li><li>Tal med lægen eller apotekspersonalet, hvis en bivirkning bliver værre, eller du får bivirkninger, som ikke er nævnt her.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Den nyeste indlægsseddel kan findes på <a href=\"https://www.indlaegsseddel.dk\" title=\"null\">www.indlaegsseddel.dk</a>.</div><h3>Oversigt over indlægssedlen</h3><ol><li>Virkning og anvendelse</li><li>Det skal du vide, før du begynder at tage Entocort</li><li>Sådan skal du tage Entocort</li><li>Bivirkninger</li><li>Opbevaring</li><li>Pakningsstørrelser og yderligere oplysninger</li></ol></div>"
        },
        "section" : [{
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section1\"/><div> </div><h2>1. Virkning og anvendelse</h2><div class=\"paragraph\">Entocort, kapsler med modificeret udløsning, indeholder et binyrebarkhormon, der dæmper den betændelse, som forekommer ved Crohns sygdom.</div><div class=\"paragraph\">Du kan bruge Entocort til behandling af Crohns sygdom i tyndtarmen og den øverste del af tyktarmen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Mikroskopisk colitis: Entocort kapsler anvendes til behandling af mikroskopisk colitis (en sygdom med kronisk betændelse i tyktarmen der typisk er med kronisk vandig diarré).</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Lægen kan have givet dig Entocort for noget andet. Følg altid lægens anvisning.</div></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du begynder at tage Entocort",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section2\"/><div> </div><h2>2. Det skal du vide, før du begynder at tage Entocort</h2><h3>Tag ikke Entocort</h3><ul><li>hvis du er allergisk over for budesonid eller et af de øvrige indholdsstoffer i Entocort (angivet i <a href=\"#Section6\" title=\"Anchor link til afsnit - pkt. 6\">pkt. 6</a>).</li><li>hvis du har betændelse i tarmen, som skyldes svamp, virus eller bakterier.</li></ul><h3>Advarsler og forsigtighedsregler</h3><div class=\"paragraph\">Kontakt lægen eller apoteket, før du tager Entocort:</div><ul><li>hvis du har tuberkulose</li><li>hvis du har eller for nylig havde en infektion</li><li>hvis du har leversygdomme</li><li>hvis du har knogleskørhed</li><li>hvis du har mavesår</li><li>hvis du har for højt blodtryk</li><li>hvis du har sukkersyge</li><li>hvis du har grå eller grøn stær</li><li>hvis du samtidig er i behandling mod svamp (ketoconazol, itraconazol)</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Fortæl også lægen, hvis der er nogen i din familie, som har sukkersyge eller grøn stær.</div><div class=\"paragraph\"><br/>Skoldkopper og mæslinger kan få et mere alvorligt forløb når du er i behandling med Entocort. Kontakt lægen hvis du har været udsat for smitte og ikke tidligere har haft sygdommene eller ikke er blevet vaccineret mod dem.</div><div class=\"paragraph\"><br/>Sig det til lægen, hvis du oplever sløret syn eller andre synsforstyrrelser.</div><div class=\"paragraph\"><br/>Kontakt lægen hvis du skifter fra anden medicin med binyrebarkhormon til Entocort, eller når du slutter din behandling med Entocort. Du kan få udslæt, høfeber eller smerter i muskler og led, træthed, hovedpine, kvalme og opkastning.</div><div class=\"paragraph\"><br/>Hvis du skal opereres, skal du fortælle lægen, at du er i behandling med Entocort.</div><h3>Børn og teenagere</h3><div class=\"paragraph\">Lægen vil regelmæssigt kontrollere højden hos børn, der behandles med Entocort i længere tid. Hvis væksten er nedsat, bør behandlingen overvejes påny.</div><h3>Brug af anden medicin sammen med Entocort</h3><div class=\"paragraph\">Fortæl altid lægen eller på apoteket, hvis du bruger anden medicin eller har gjort det for nylig. Det gælder også medicin, som ikke er købt på recept, f.eks. naturlægemidler og vitaminer og mineraler.</div><div class=\"paragraph\"><br/>Entocort kan påvirke virkningen af anden medicin, ligesom anden medicin kan ændre virkningen af Entocort. Tal med din læge, hvis du tager:</div><ul><li>ketoconazol eller itrakonazol (svampemiddel)</li><li>østrogener og p-piller (kvindeligt kønshormon)</li><li>carbamazepin (mod epilepsi)</li><li>nogle lægemidler kan øge virkningen af Entocort, og din læge vil overvåge dig omhyggeligt, hvis du tager sådanne lægemidler (inklusive visse former for HIV-medicin, herunder ritonavir (eller andre HIV-proteasehæmmere) og cobicistat).</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">På grund af hæmning af binyrebarkfunktionen kan diagnostiske test af hypofyse-aktiviteten vise fejlagtige lave værdier.</div><h3>Brug af Entocort sammen med mad og drikke</h3><div class=\"paragraph\">Du kan tage Entocort sammen med mad og drikke, dog skal du ikke tage det sammen med grapefrugt eller grapefrugtjuice.</div><h3>Graviditet, amning og fertilitet</h3><div class=\"paragraph\">Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge eller apoteket til råds, før du tager Entocort.</div><h3>Trafik- og arbejdssikkerhed</h3><div class=\"paragraph\">Entocort påvirker ikke arbejdssikkerheden eller evnen til at færdes sikkert i trafikken.</div><h3>Entocort indeholder saccharose</h3><div class=\"paragraph\">Entocort, kapsler med modificeret udløsning, indeholder saccharose. Kontakt lægen, før du tager denne medicin, hvis lægen har fortalt dig, at du ikke tåler visse sukkerarter.</div></div>"
          }
        },
        {
          "title" : "3. Sådan skal du tage Entocort",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section3\"/><div> </div><h2>3. Sådan skal du tage Entocort</h2><div class=\"paragraph\">Tag altid Entocort nøjagtigt efter lægens anvisning. Er du i tvivl, så spørg lægen eller på apoteket. Ændring eller stop af behandlingen bør kun ske i samråd med lægen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Du skal synke kapslerne hele med vand. Du må ikke dele eller tygge kapslerne.</b></div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Crohns sygdom</b></div><div class=\"paragraph\"><b>Den sædvanlige dosering er:</b></div><div class=\"paragraph\"><b>Voksne:</b></div><div class=\"paragraph\"><b>Dosis ved aktiv sygdom:</b></div><div class=\"paragraph\">3 kapsler (9 mg) én gang daglig om morgenen i op til 8 uger.</div><div class=\"paragraph\">Det tager normalt 2-4 uger, inden Entocort giver fuld virkning.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Dosis til forhindring af tilbagefald af sygdommen:</b></div><div class=\"paragraph\">2 kapsler (6 mg) én gang daglig om morgenen.</div><div class=\"paragraph\">Tal med din læge, hvis du tager medicinen i længere tid. Dosis bør holdes så lav som muligt.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Dosis til patienter, der har været i behandling med medicin, der indeholder prednisolon:</b></div><div class=\"paragraph\">2 kapsler (6 mg) én gang daglig om morgenen.</div><div class=\"paragraph\">Når du starter med Entocort, skal du langsomt aftrappe prednisolonbehandlingen. Det skal altid ske i samråd med din læge.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Hvis du afbryder behandlingen, skal du nedtrappe dosis gradvist. Tal med lægen.</b></div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Mikroskopisk colitis</b></div><div class=\"paragraph\"><b>Voksne:<br/>Dosis ved aktiv sygdom:</b></div><div class=\"paragraph\">3 kapsler (9 mg) én gang daglig om morgenen i op til 8 uger. Det tager normalt 2-4 uger, inden Entocort giver fuld virkning. Når behandlingen skal ophøre, bør dosis normalt reduceres <b>gradvist. Tal med lægen.</b></div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Dosis til forhindring af tilbagefald af sygdommen:</b></div><div class=\"paragraph\">Individuelt, men dosis bør holdes så lavt som muligt. Tal med din læge, hvis du tager medicinen i længere tid.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ældre:</b></div><div class=\"paragraph\">Det er ikke nødvendigt at ændre dosis. Følg lægens anvisning.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Brug til børn:</b></div><div class=\"paragraph\">Du må ikke give Entocort til børn. Følg lægens anvisning</div><h3>Hvis du har taget for mange Entocort, kapsler med modificeret udløsning</h3><div class=\"paragraph\">Kontakt lægen, skadestuen eller apoteket, hvis du har taget flere Entocort, kapsler med modificeret udløsning, end der står i denne information, eller mere end lægen har foreskrevet, og du føler dig utilpas. Tag pakningen med.</div><div class=\"paragraph\"><b>Symptomer ved overdosering:</b></div><div class=\"paragraph\">Hvis du gennem længere tid tager for mange kapsler, kan der opstå symptomer, der er nævnt under afsnittet om bivirkninger.</div><h3>Hvis du har glemt at tage Entocort</h3><div class=\"paragraph\">Du må ikke tage en dobbeltdosis som erstatning for den glemte dosis. Fortsæt blot med den sædvanlige dosis.</div></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section4\"/><div> </div><h2>4. Bivirkninger</h2><div class=\"paragraph\">Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Almindelige bivirkninger</b> (forekommer hos mellem 1 og 10 ud af 100 behandlede):</div><ul><li>tendens til måneansigt (Cushing-lignende træk)</li><li>nervøsitet, søvnløshed, humørsvingninger og depression</li><li>hjertebanken</li><li>fordøjelsesbesvær</li><li>muskelkramper</li><li>menstruationsforstyrrelser</li><li>hududslæt og nældefeber</li><li>svaghed og nedsat kraft i musklerne pga. for lavt kalium i blodet. For lavt kalium i blodet kan i meget sjældne tilfælde blive alvorlig med lammelser og forstyrrelser i hjertets rytme (risiko for hjertestop). Tal med lægen.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ikke almindelige bivirkninger</b> (forekommer hos mellem 1 og 10 ud af 1000 behandlede):</div><ul><li>rysten</li><li>utilsigtede bevægelser eller ekstrem rastløshed eventuelt med muskelspasmer eller trækninger</li><li>angst</li><li>sår i mavesæk eller tolvfingertarm</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Sjældne bivirkninger </b>(forekommer hos mellem 1 og 10 ud af 10.000 behandlede):</div><ul><li>aggression</li><li>hovedpine, kvalme, synsnedsættelse og regnbuesyn pga. forhøjet tryk i øjet (grøn stær). Kontakt straks læge eller skadestue</li><li>uklarhed af øjets naturlige linse herunder bagsiden af linsen, sløret syn</li><li>misfarvning af huden, som følge af blødning under huden</li><li>betændt bugspytkirtel (forbundet med smerter i øvre maveregion og ryggen samt kvalme)</li><li>knoglevævsdød på grund af nedsat blodtilførsel til knoglen</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Meget sjældne bivirkninger</b> (forekommer hos færre end 1 ud af 10.000 behandlede):</div><ul><li>pludseligt hududslæt, åndedrætsbesvær og besvimelse (inden for minutter til timer) pga. overfølsomhed (anafylaktisk reaktion). <b>Kan være livsfarligt. Ring 112.</b></li><li>nedsat vækst hos børn.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">De fleste bivirkninger, nævnt i denne liste, kan også forventes for andre behandlinger med glukokortikoider.</div><h3>Indberetning af bivirkninger</h3><div class=\"paragraph\">Hvis du oplever bivirkninger, bør du tale med din læge eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via de oplysninger, der fremgår herunder.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Lægemiddelstyrelsen</div><div class=\"paragraph\">Axel Heides Gade 1</div><div class=\"paragraph\">DK-2300 København S<br/>Websted: www.meldenbivirkning.dk</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</div><div class=\"paragraph\"><a href=\"https://www.meldenbivirkning.dk\" title=\"Meld en bivirkning\">Meld en bivirkning.</a></div></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section5\"/><div> </div><h2>5. Opbevaring</h2><div class=\"paragraph\">Opbevar Entocort utilgængeligt for børn.</div><div class=\"paragraph\">Opbevar Entocort i original emballage, tæt tillukket, da medicinen er følsom over for fugt.</div><div class=\"paragraph\">Brug ikke Entocort efter den udløbsdato, der står på pakningen. Udløbsdatoen er den sidste dag i den nævnte måned.</div><div class=\"paragraph\">Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.</div></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section6\"/><div> </div><h2>6. Pakningsstørrelser og yderligere oplysninger</h2><h3>Entocort, hårde kapsler med modificeret udløsning 3 mg indeholder:</h3><ul><li>Aktivt stof: Budesonid.</li><li>Øvrige indholdsstoffer: Ethylcellulose; tributylacetylcitrat; methacrylsyre copolymer; triethylcitrat (E1505); simeticon; polysorbat 80; talcum. Sukkerkugler (bestående af saccharose og majsstivelse).<br/>Kapsel: Gelatine; titandioxid (E171); rød jernoxid (E172).</li></ul><h3>Udseende</h3><div class=\"paragraph\">Entocort 3 mg, kapsler med modificeret udløsning er af hård gelatine med en ugennemskinnelig, lysegrå kerne og uigennemskinnelig lyserød kapsel. Kapslen er mærket CIR på den ene side og 3 mg på den anden.</div><h3>Pakningsstørrelser</h3><div class=\"paragraph\">50 kapsler, 100 kapsler.</div><div class=\"paragraph\">Ikke alle pakningsstørrelser er nødvendigvis markedsført.</div></div>"
          },
          "section" : [{
            "title" : "Indehaver af markedsføringstilladelsen og fremstiller",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Indehaver af markedsføringstilladelsen og fremstiller</h2><h3>Indehaver af markedsføringstilladelsen</h3><div class=\"paragraph\">Tillotts Pharma GmbH</div><div class=\"paragraph\">Warmbacher Str. 80</div><div class=\"paragraph\">79618 Rheinfelden</div><div class=\"paragraph\">Tyskland</div><h3>Lokal repræsentant for indehaveren af markedsføringstilladelsen:</h3><div class=\"paragraph\">Tillotts Pharma AB, Gustavslundsvägen 135, 167 51 Bromma, Sverige</div><h3>Fremstiller</h3><div class=\"paragraph\">Astrea Fontaine SAS<br/>Rue des Prés Potets<br/>21121 Fontaine-les-Dijon<br/>Frankrig</div></div>"
            }
          },
          {
            "title" : "Denne indlægsseddel blev senest revideret maj 2022",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Denne indlægsseddel blev senest revideret maj 2022</h2></div>"
            }
          }]
        }]
      }]
    }
  }]
}

```
