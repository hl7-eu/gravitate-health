# [Preprocessed] ePI document for Dovato 50 mg/300 mg comprimidos Package Leaflet - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **[Preprocessed] ePI document for Dovato 50 mg/300 mg comprimidos Package Leaflet**

## Example Bundle: [Preprocessed] ePI document for Dovato 50 mg/300 mg comprimidos Package Leaflet

**Composition category:**processed

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

Prospecto: información para el paciente Dovato 50 mg/300 mg comprimidos recubiertos con película dolutegravir/lamivudina
**Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.**
* Conserve este prospecto, ya que puede tener que volver a leerlo.
* Si tiene alguna duda, consulte a su médico o farmacéutico.
* Este medicamento se le ha recetado solamente a usted, y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.
* Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver sección 4.


#### What is in this leaflet

 

1. Qué es Dovato y para qué se utiliza
1. Qué necesita saber antes de empezar a tomar Dovato
1. Cómo tomar Dovato
1. Posibles efectos adversos
1. Conservación de Dovato
1. Contenido del envase e información adicional


#### 1. What Dovato 50 mg/300 mg comprimidos recubiertos con película is and what it is used for

 

Dovato es un medicamento que contiene dos principios activos usados para tratar la infección por el virus de la inmunodeficiencia humana (VIH): dolutegravir y lamivudina. Dolutegravir pertenece al grupo de medicamentos antirretrovirales llamados inhibidores de la integrasa (INI) y lamivudina pertenece a un grupo de medicamentos antirretrovirales denominados inhibidores de la transcriptasa inversa análogos de nucleósido (ITIAN).


#### 2. What you need to know before you take Dovato 50 mg/300 mg comprimidos recubiertos con película

 

**No tome Dovato**

* si es alérgico (hipersensible) a dolutegravir o lamivudina o a alguno de los demás componentes de este medicamento (incluidos en la sección 6)
* si está tomando un medicamento llamado fampridina (también conocido como dalfampridina; utilizado para tratar la esclerosis múltiple).

Si cree que algo de esto le aplica, consulte a su médico.

**Advertencias y precauciones** Algunas personas que toman Dovato u otros tratamientos combinados frente al VIH tienen un mayor riesgo de desarrollar efectos adversos graves que otras. Usted necesita saber que hay un mayor riesgo:

* si tiene una enfermedad hepática moderada o grave
* si alguna vez ha tenido una enfermedad hepática, incluyendo hepatitis B o C (si tiene hepatitis B no deje de tomar Dovato sin el consejo de su médico, ya que podría empeorar)
* si tiene un problema de riñón.

Consulte a su médico antes de empezar a tomar Dovato si le aplica alguna de estas condiciones. Puede necesitar pruebas adicionales, incluyendo análisis de sangre, mientras toma este medicamento. Para más información, ver sección 4.

**Reacciones alérgicas**

Dovato contiene dolutegravir. Dolutegravir puede producir una reacción alérgica grave conocida como reacción de hipersensibilidad. Usted necesita saber a qué signos y síntomas importantes debe estar atento mientras esté tomando Dovato.

Lea la información “Reacciones alérgicas” en la sección 4 de este prospecto.

**Esté atento a los síntomas importantes**

Algunas personas que toman medicamentos para la infección por el VIH desarrollan otros trastornos, que pueden ser graves. Estos incluyen:

* síntomas de infecciones e inflamación
* dolor en las articulaciones, rigidez y problemas de huesos.

Usted necesita saber a qué signos y síntomas importantes debe estar atento mientras esté tomando Dovato.

Lea la información sobre “Otros posibles efectos adversos” en la sección 4 de este prospecto.

**Niños**

Este medicamento no está indicado en niños menores de 12 años, porque no ha sido estudiado en estos pacientes.

**Otros medicamentos y Dovato** Informe a su médico si está tomando, ha tomado recientemente o pudiera tener que tomar cualquier otro medicamento.

No tome Dovato con el siguiente medicamento:

* fampridina (también conocido como dalfampridina), utilizado para tratar la esclerosis múltiple.

Algunos medicamentos pueden afectar al funcionamiento de Dovato o aumentar la probabilidad de sufrir efectos adversos. Dovato también puede afectar al funcionamiento de algunos otros medicamentos.

Informe a su médico si está tomando alguno de los siguientes medicamentos:

* metformina, para tratar la diabetes
* medicamentos llamados antiácidos, para tratar la indigestión y el ardor de estómago. No tome un antiácido durante las 6 horas antes de tomar Dovato, o por lo menos 2 horas después de tomarlo (ver también sección 3, “Cómo tomar Dovato”).
* suplementos o multivitamínicos que contienen calcio, hierro o magnesio. Si toma Dovato con comida, puede tomar los suplementos o multivitamínicos que contengan calcio, hierro o magnesio a la vez que Dovato. Si no toma Dovato con comida, no puede tomar un suplemento o multivitamínico que contenga calcio, hierro o magnesio durante las 6 horas antes de tomar Dovato, o por lo menos 2 horas después de tomarlo (ver también sección 3, “Cómo tomar Dovato”).
* emtricitabina, etravirina, efavirenz, nevirapina o tipranavir/ritonavir, para tratar la infección por el VIH medicamentos (generalmente líquidos) que contengan sorbitol y otros polialcoholes (como xilitol, manitol, lactitol o maltitol), si se toman con regularidad
* cladribina, utilizada para tratar la leucemia o la esclerosis múltiple
* rifampicina, para tratar la tuberculosis (TB) y otras infecciones bacterianas
* fenitoína y fenobarbital, para tratar la epilepsia
* oxcarbazepina y carbamazepina, para tratar la epilepsia o el trastorno bipolar
* hierba de San Juan (Hypericum perforatum), un medicamento a base de plantas para tratar la depresión.

Informe a su médico o farmacéutico si está tomando alguno de estos medicamentos. Su médico puede decidir ajustar su dosis o que usted necesite chequeos adicionales.

**Embarazo**

Si está embarazada, cree que podría estar embarazada o tiene intención de quedarse embarazada:

Consulte a su médico sobre los riegos y beneficios de tomar Dovato.

Tomar Dovato en el momento de quedarse embarazada o durante las primeras seis semanas de embarazo puede aumentar el riesgo de un defecto de nacimiento, denominado defecto del tubo neural, como la espina bífida (malformación de la médula espinal).

Si existe la posibilidad de quedarse embarazada mientras está tomando Dovato:

Consulte a su médico y valore si existe la necesidad de utilizar un método anticonceptivo, como preservativos o anticonceptivos orales.

Informe a su médico de inmediato si se queda embarazada o tiene intención de quedarse embarazada. Su médico revisará su tratamiento. No interrumpa el tratamiento con Dovato sin consultar a su médico, ya que esto podría dañarles a usted y a su hijo.

**Lactancia**

**No se recomienda** que las mujeres que conviven con el VIH den el pecho porque la infección por VIH puede transmitirse al bebé a través de la leche materna.

Una pequeña cantidad de los componentes de Dovato también pueden pasar a la leche materna.

Si está dando el pecho o piensa en dar el pecho, debe consultar con su médico lo antes posible.

**Conducción y uso de máquinas** Dovato puede hacer que se sienta mareado y puede tener otros efectos adversos que reduzcan su atención.

No conduzca ni maneje maquinaria, a menos que esté seguro que no está afectado.


#### 3. How to take Dovato 50 mg/300 mg comprimidos recubiertos con película

 

Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico. En caso de duda, consulte de nuevo a su médico o farmacéutico.

* La dosis recomendada de Dovato es **un comprimido una vez al día.**

Trague el comprimido con un poco de líquido. Dovato se puede tomar con o sin alimentos.

**Uso en** **adolescentes**

Los adolescentes de entre 12 y 17 años y que pesen por lo menos 40 kg pueden tomar la dosis de adultos de un comprimido una vez al día.

**Medicamentos antiácidos**

Los antiácidos para tratar la indigestión y el ardor de estómago pueden hacer que Dovato no sea absorbido por su cuerpo y hacerlo menos efectivo.

No tome un antiácido durante las 6 horas antes de tomar Dovato, o por lo menos 2 horas después de tomarlo.

Otros medicamentos que disminuyen la acidez, como ranitidina y omeprazol, pueden tomarse al mismo tiempo que Dovato.

Consulte con su médico para que le aconseje sobre qué medicamentos contra la acidez puede tomar con Dovato.

**Suplementos o multivitamínicos que contienen calcio, hierro o magnesio**

Los suplementos o multivitamínicos que contengan calcio, hierro o magnesio pueden hacer que Dovato no sea absorbido en su cuerpo y hacerlo menos efectivo.

Si toma Dovato con comida, puede tomar los suplementos o multivitamínicos que contengan calcio, hierro o magnesio a la vez que Dovato. Si no toma Dovato con comida, no puede tomar un suplemento o multivitamínico que contenga calcio, hierro o magnesio durante las 6 horas antes de tomar Dovato, o por lo menos 2 horas después de tomarlo.

Consulte con su médico para que le aconseje sobre cómo tomar suplementos o multivitamínicos que contengan calcio, hierro o magnesio con Dovato.

**Si toma más** **Dovato** **del que debe**

Si excede el número de comprimidos de Dovato, **contacte con su médico o farmacéutico para que le aconseje**. Si es posible, muéstreles la caja de Dovato.

**Si olvidó tomar** **Dovato**

Si olvida una dosis, tómela tan pronto como lo recuerde. Pero si quedan menos de 4 horas para su próxima dosis, sáltese esa dosis que olvidó y tome la siguiente a la hora habitual. Luego continúe su tratamiento como antes.

**No tome una dosis doble** para compensar las dosis olvidadas.

** **

**No interrumpa el tratamiento con Dovato sin la recomendación de su médico**

Tome Dovato hasta que su médico se lo indique. No deje de tomarlo a menos que su médico se lo aconseje. La interrupción del tratamiento con Dovato puede afectar a su salud y al funcionamiento futuro del tratamiento.

Si tiene cualquier otra duda sobre el uso de este medicamento, pregunte a su médico o farmacéutico.


#### 4. Possible side effects

 

Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran, **por lo que es muy importante que le comente a su médico cualquier cambio en su estado de salud.**

**Reacciones alérgicas**

Dovato contiene dolutegravir. Dolutegravir puede producir una reacción alérgica grave conocida como **reacción de hipersensibilidad.** Esta es una reacción poco frecuente (puede afectar hasta 1 de cada 100 personas) en personas que toman dolutegravir. Si tiene alguno de los siguientes síntomas:

* erupción cutánea
* una temperatura alta (**fiebre**)
* falta de energía (**cansancio**)
* hinchazón, a veces de la cara o la boca (**angioedema**), que causa dificultad para respirar
* dolores musculares o articulares.

**** **Acuda a un médico inmediatamente.** Su médico puede decidir realizar pruebas hepáticas, de riñón o sanguíneas y puede que le indique que deje de tomar Dovato.

**Efectos adversos muy frecuentes**

Estos pueden afectar a **más de 1 de cada 10** personas:

* dolor de cabeza
* diarrea
* náuseas.

**Efectos adversos frecuentes**

Estos pueden afectar **hasta 1 de cada 10** personas:

* depresión (sensación de tristeza profunda y falta de autoestima)
* erupción cutánea
* picor (**prurito**)
* vómitos
* dolor o molestias en el estómago (**abdominal**)
* aumento de peso
* gases (**flatulencia**)
* mareo
* somnolencia
* dificultad para conciliar el sueño (**insomnio**)
* sueños anormales
* falta de energía (**cansancio**)
* pérdida de cabello
* ansiedad
* dolor articular
* dolor muscular.

Los efectos adversos frecuentes que pueden aparecer en los análisis de sangre son:

* aumento en el nivel de las enzimas del hígado (**aminotransferasas**)
* aumento en el nivel de las enzimas producidas en los músculos (**creatinfosfoquinasa**).

**Efectos adversos poco frecuentes**

Estos pueden afectar **hasta 1 de cada 100** personas:

* inflamación del hígado (**hepatitis**)
* intento de suicidio (especialmente en pacientes que anteriormente han tenido depresión o problemas de salud mental)
* pensamientos suicidas (especialmente en pacientes que anteriormente han tenido depresión o problemas de salud mental)
* crisis de angustia.

Los efectos adversos poco frecuentes que pueden aparecer en los análisis de sangre son:

* una disminución de las células involucradas en la coagulación sanguínea (**trombocitopenia**)
* un recuento bajo de glóbulos rojos (**anemia**) o recuento bajo de glóbulos blancos (**neutropenia**).

**Efectos adversos raros**

Estos pueden afectar **hasta** **1 de cada 1.000** personas:

* insuficiencia hepática (los signos pueden incluir coloración amarillenta de la piel y del blanco de los ojos u orina inusualmente oscura)
* hinchazón, a veces de la cara o la boca (**angioedema**), causando dificultad para respirar
* inflamación del páncreas (**pancreatitis**)
* rotura del tejido muscular
* suicidio (especialmente en pacientes que anteriormente han tenido depresión o problemas de salud mental).

**Informe a su médico de inmediato** si experimenta algún problema de salud mental (consulte también otros problemas de salud mental que aparecen más arriba).

Los efectos adversos raros que pueden aparecer en los análisis de sangre son:

* aumento de bilirrubina (prueba de función del hígado)
* aumento de una enzima llamada **amilasa**.

**Efectos adversos muy raros**

Estos pueden afectar **hasta** **1 de cada 10.000** personas:

* acidosis láctica (exceso de ácido láctico en la sangre)
* entumecimiento, sensación de hormigueo en la piel (pinchazos)
* sensación de debilidad en las extremidades.

Los efectos adversos muy raros que pueden aparecer en los análisis de sangre son:

* un fallo de la médula ósea en producir nuevos glóbulos rojos (**aplasia pura de glóbulos rojos**).

**Otros posibles efectos adversos**

Las personas que toman un tratamiento de combinación para el VIH pueden tener otros efectos adversos.

**Síntomas de infección e inflamación**

Las personas con infección por el VIH avanzada (SIDA) tienen un sistema inmunitario debilitado y es más probable que desarrollen infecciones graves (infecciones oportunistas). Tales infecciones pueden haberse desarrollado de manera "silenciosa", no siendo detectadas por el sistema inmunitario debilitado antes de que el tratamiento se iniciara. Después de iniciar el tratamiento, el sistema inmunitario se vuelve más fuerte y puede luchar contra estas infecciones, lo que puede causar síntomas de infección o inflamación. Los síntomas generalmente incluyen fiebre, además de algunos de los siguientes:

* dolor de cabeza
* dolor de estómago
* dificultad para respirar.

En casos raros, como el sistema inmunitario se vuelve más fuerte, también puede atacar tejidos sanos (**trastornos** **autoinmunes****)**. Los síntomas de los trastornos autoinmunes pueden aparecer muchos meses después de comenzar a tomar medicamentos para tratar la infección por el VIH. Los síntomas pueden incluir:

* palpitaciones (latido cardíaco rápido o irregular) o temblor
* hiperactividad (excesiva inquietud y movimiento)
* debilidad que empieza en las manos y pies y que asciende hacia el tronco del cuerpo.

**Si tiene cualquier síntoma de infección** o si nota cualquiera de los síntomas anteriores:

**Consulte a su médico inmediatamente**. No tome otros medicamentos para la infección sin consultar antes con su médico.

**Dolor en las articulaciones, rigidez y problemas de huesos**

Algunas personas en tratamiento combinado para el VIH desarrollan **osteonecrosis**. En esta afección, partes del tejido óseo se dañan permanentemente debido al menor aporte de sangre a los huesos. Las personas pueden ser más propensas a padecer esta afección:

* si han tomado un tratamiento combinado durante un largo tiempo
* si también están tomando medicamentos antiinflamatorios llamados corticosteroides
* si beben alcohol
* si su sistema inmunitario está muy debilitado
* si tienen sobrepeso.

**Los signos de la osteonecrosis incluyen:**

* rigidez en las articulaciones
* molestias y dolores en las articulaciones (especialmente en la cadera, rodilla u hombro)
* dificultad de movimiento.

Si nota alguno de estos síntomas:

**Informe a su médico**.

**Efectos en el peso, los lípidos y la glucosa en sangre:**

Durante el tratamiento frente al VIH puede haber un aumento en el peso y en los niveles de lípidos y glucosa en la sangre. Esto está parcialmente relacionado con la recuperación de la salud y el estilo de vida y, a veces, con los propios medicamentos para tratar el VIH. Su médico evaluará estos cambios.


#### 5. How to store Dovato 50 mg/300 mg comprimidos recubiertos con película

 

Mantener este medicamento fuera de la vista y del alcance de los niños

No utilice este medicamento después de la fecha de caducidad que aparece en la caja y el frasco después de CAD. La fecha de caducidad es el último día del mes que se indica.

Este medicamento no requiere ninguna condición especial de conservación.

Los medicamentos no se deben tirar por los desagües ni a la basura. Pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudará a proteger el medio ambiente.


#### 6. Contents of the pack and other information

 

**Composición de Dovato**
* Los principios activos son dolutegravir y lamivudina. Cada comprimido contiene dolutegravir sódico equivalente a 50 mg de dolutegravir y 300 mg de lamivudina.
* Los demás componentes son celulosa microcristalina, carboximetilalmidón sódico, estearato de magnesio, manitol (E421), povidona (K29/32), fumarato estearilo de sodio, hipromelosa (E464), macrogol, dióxido de titanio (E171).
* Este medicamento contiene menos de 1 mmol de sodio (23 mg) por comprimido; esto es, esencialmente “exento de sodio”.


####  Dovato 50 mg/300 mg film-coated tablets 
PMSWI:
** EU/1/19/1370/001 **PHPID:
** 0x073AF2E5B92AE19E8B67635AFFB3D6CA **
-------

Full name: **Dovato 50 mg/300 mg film-coated tablets**

 - Invented name part: ** Dovato ** 

 - Scientific name part: ** dolutegravir/lamivudine ** 

 - Strength part: ** 50 mg/300 mg ** 

 - Pharmaceutical dose form part: ** film-coated tablets ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/19/1370/001 ** 

 Region: ** ** 

Marketing authorisation holder: **ViiV Healthcare BV** 

 Identifier: 
*  **ORG-100012958** 
 

 Status: ** Active (2019-07-01T13:28:17Z) ** 

 Package 1 of 1

PMSWI: ** EU/1/19/1370/001 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Child-resistant closure** **(Glass)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Film-coated tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** DOLUTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** lamivudine ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** sodium starch glycolate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** mannitol ** 

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Active ** 

 Substance: ** DOLUTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** lamivudine ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** sodium starch glycolate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** mannitol ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "processedbundledovato-es",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "es",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/19/1370/001"
  },
  "type" : "document",
  "timestamp" : "2023-04-25T11:55:27Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/compositione722f6782d3f34f86982e14386c8811dll",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "compositione722f6782d3f34f86982e14386c8811dll",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "es",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"es\" lang=\"es\"><a name=\"Composition_compositione722f6782d3f34f86982e14386c8811dll\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition compositione722f6782d3f34f86982e14386c8811dll</b></p><a name=\"compositione722f6782d3f34f86982e14386c8811dll\"> </a><a name=\"hccompositione722f6782d3f34f86982e14386c8811dll\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: es</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: pregnancyCategory</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 77386006}\">Pregnancy</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: indication</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ B90}\">HIV-infection/AIDS</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: breastfeedingCategory</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 69840006}\">Normal breast feeding (finding)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: liver</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ D97}\">Liver disease, other</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: contra-indication-hypericum</li><li>concept: <span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta XK4IUX8MNB}\">Hypericum perforatum L.</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: contra-indication-calcium</li><li>concept: <span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta SY7Q814VUP}\">Calcium</span></li></ul></blockquote><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/yy</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs P}\">processed</span></p><p><b>date</b>: 2022-04-29 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mra-7c9b97127f73ff3605a10eb1c2cc24d1\">Organization European Medicines Agency</a></p><p><b>title</b>: TEST PURPOSES ONLY - Dovato 50 mg/300 mg comprimidos recubiertos con película</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-04-29 13:28:17+0000</td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "pregnancyCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "77386006",
                "display" : "Pregnancy"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "indication"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "B90",
                "display" : "HIV-infection/AIDS"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "breastfeedingCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "69840006",
                "display" : "Normal breast feeding (finding)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "liver"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "D97",
                "display" : "Liver disease, other"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "contra-indication-hypericum"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
                "code" : "XK4IUX8MNB",
                "display" : "Hypericum perforatum L."
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "contra-indication-calcium"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
                "code" : "SY7Q814VUP",
                "display" : "Calcium"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      }],
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "yy"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "P",
          "display" : "processed"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "date" : "2022-04-29T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mra-7c9b97127f73ff3605a10eb1c2cc24d1"
      }],
      "title" : "TEST PURPOSES ONLY - Dovato 50 mg/300 mg comprimidos recubiertos con película",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-04-29T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PROSPECTO"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Prospecto: información para el paciente Dovato 50 mg/300 mg comprimidos recubiertos con película dolutegravir/lamivudina <b>Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.</b><ul><li>Conserve este prospecto, ya que puede tener que volver a leerlo.</li><li>Si tiene alguna duda, consulte a su médico o farmacéutico.</li><li>Este medicamento se le ha recetado solamente a usted, y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.</li><li>Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver sección 4.</li></ul></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Contenido del prospecto"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ol><li>Qué es Dovato y para qué se utiliza</li><li>Qué necesita saber antes de empezar a tomar Dovato</li><li>Cómo tomar Dovato</li><li>Posibles efectos adversos</li><li>Conservación de Dovato</li><li>Contenido del envase e información adicional</li></ol></div>"
          }
        },
        {
          "title" : "1. What Dovato 50 mg/300 mg comprimidos recubiertos con película is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Qué es Dovato y para qué se utiliza"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"indication\">Dovato es un medicamento que contiene dos principios activos usados para tratar la infección por el virus de la inmunodeficiencia humana (VIH): dolutegravir y lamivudina. Dolutegravir pertenece al grupo de medicamentos antirretrovirales llamados inhibidores de la integrasa (INI) y lamivudina pertenece a un grupo de medicamentos antirretrovirales denominados inhibidores de la transcriptasa inversa análogos de nucleósido (ITIAN).</div></div>"
          }
        },
        {
          "title" : "2. What you need to know before you take Dovato 50 mg/300 mg comprimidos recubiertos con película",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Qué necesita saber antes de empezar a tomar Dovato"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>No tome Dovato</strong></p><ul><li>si es alérgico (hipersensible) a dolutegravir o lamivudina o a alguno de los demás componentes de este medicamento (incluidos en la sección 6)</li><li>si está tomando un medicamento llamado fampridina (también conocido como dalfampridina; utilizado para tratar la esclerosis múltiple).</li></ul><p>Si cree que algo de esto le aplica, consulte a su médico.</p><p><strong>Advertencias y precauciones</strong> Algunas personas que toman Dovato u otros tratamientos combinados frente al VIH tienen un mayor riesgo de desarrollar efectos adversos graves que otras. Usted necesita saber que hay un mayor riesgo:</p><ul><li><span class=\"liver\">si tiene una enfermedad hepática moderada o grave</span></li><li>si alguna vez ha tenido una enfermedad hepática, incluyendo hepatitis B o C (si tiene hepatitis B no deje de tomar Dovato sin el consejo de su médico, ya que podría empeorar)</li><li>si tiene un problema de riñón.</li></ul><p>Consulte a su médico antes de empezar a tomar Dovato si le aplica alguna de estas condiciones. Puede necesitar pruebas adicionales, incluyendo análisis de sangre, mientras toma este medicamento. Para más información, ver sección 4.</p><p><em>Reacciones alérgicas</em></p><p>Dovato contiene dolutegravir. Dolutegravir puede producir una reacción alérgica grave conocida como reacción de hipersensibilidad. Usted necesita saber a qué signos y síntomas importantes debe estar atento mientras esté tomando Dovato.</p><p>Lea la información “Reacciones alérgicas” en la sección 4 de este prospecto.</p><p><em>Esté atento a los síntomas importantes</em></p><p>Algunas personas que toman medicamentos para la infección por el VIH desarrollan otros trastornos, que pueden ser graves. Estos incluyen:</p><ul><li>síntomas de infecciones e inflamación</li><li>dolor en las articulaciones, rigidez y problemas de huesos.</li></ul><p>Usted necesita saber a qué signos y síntomas importantes debe estar atento mientras esté tomando Dovato.</p><p>Lea la información sobre “Otros posibles efectos adversos” en la sección 4 de este prospecto.</p><p><strong>Niños</strong></p><p>Este medicamento no está indicado en niños menores de 12 años, porque no ha sido estudiado en estos pacientes.</p><p><strong>Otros medicamentos y Dovato</strong> Informe a su médico si está tomando, ha tomado recientemente o pudiera tener que tomar cualquier otro medicamento.</p><p>No tome Dovato con el siguiente medicamento:</p><ul><li>fampridina (también conocido como dalfampridina), utilizado para tratar la esclerosis múltiple.</li></ul><p>Algunos medicamentos pueden afectar al funcionamiento de Dovato o aumentar la probabilidad de sufrir efectos adversos. Dovato también puede afectar al funcionamiento de algunos otros medicamentos.</p><p>Informe a su médico si está tomando alguno de los siguientes medicamentos:</p><ul><li>metformina, para tratar la diabetes</li><li>medicamentos llamados antiácidos, para tratar la indigestión y el ardor de estómago. No tome un antiácido durante las 6 horas antes de tomar Dovato, o por lo menos 2 horas después de tomarlo (ver también sección 3, “Cómo tomar Dovato”).</li><li class=\"contra-indication-calcium\">suplementos o multivitamínicos que contienen calcio, hierro o magnesio. Si toma Dovato con comida, puede tomar los suplementos o multivitamínicos que contengan calcio, hierro o magnesio a la vez que Dovato. Si no toma Dovato con comida, no puede tomar un suplemento o multivitamínico que contenga calcio, hierro o magnesio durante las 6 horas antes de tomar Dovato, o por lo menos 2 horas después de tomarlo (ver también sección 3, “Cómo tomar Dovato”).</li><li>emtricitabina, etravirina, efavirenz, nevirapina o tipranavir/ritonavir, para tratar la infección por el VIH medicamentos (generalmente líquidos) que contengan sorbitol y otros polialcoholes (como xilitol, manitol, lactitol o maltitol), si se toman con regularidad</li><li>cladribina, utilizada para tratar la leucemia o la esclerosis múltiple</li><li>rifampicina, para tratar la tuberculosis (TB) y otras infecciones bacterianas</li><li>fenitoína y fenobarbital, para tratar la epilepsia</li><li>oxcarbazepina y carbamazepina, para tratar la epilepsia o el trastorno bipolar</li><li class=\"contra-indication-hypericum\">hierba de San Juan (Hypericum perforatum), un medicamento a base de plantas para tratar la depresión.</li></ul><p>Informe a su médico o farmacéutico si está tomando alguno de estos medicamentos. Su médico puede decidir ajustar su dosis o que usted necesite chequeos adicionales.</p><div class=\"pregnancyCategory\"><p><strong>Embarazo</strong></p><p>Si está embarazada, cree que podría estar embarazada o tiene intención de quedarse embarazada:</p><p>Consulte a su médico sobre los riegos y beneficios de tomar Dovato.</p><p>Tomar Dovato en el momento de quedarse embarazada o durante las primeras seis semanas de embarazo puede aumentar el riesgo de un defecto de nacimiento, denominado defecto del tubo neural, como la espina bífida (malformación de la médula espinal).</p><p>Si existe la posibilidad de quedarse embarazada mientras está tomando Dovato:</p><p>Consulte a su médico y valore si existe la necesidad de utilizar un método anticonceptivo, como preservativos o anticonceptivos orales.</p><p>Informe a su médico de inmediato si se queda embarazada o tiene intención de quedarse embarazada. Su médico revisará su tratamiento. No interrumpa el tratamiento con Dovato sin consultar a su médico, ya que esto podría dañarles a usted y a su hijo.</p><p><strong>Lactancia</strong></p><p><strong>No se recomienda</strong> que las mujeres que conviven con el VIH den el pecho porque la infección por VIH puede transmitirse al bebé a través de la leche materna.</p><p>Una pequeña cantidad de los componentes de Dovato también pueden pasar a la leche materna.</p><p>Si está dando el pecho o piensa en dar el pecho, debe consultar con su médico lo antes posible.</p></div><p><strong>Conducción y uso de máquinas</strong> Dovato puede hacer que se sienta mareado y puede tener otros efectos adversos que reduzcan su atención.</p><p>No conduzca ni maneje maquinaria, a menos que esté seguro que no está afectado.</p></div>"
          }
        },
        {
          "title" : "3. How to take Dovato 50 mg/300 mg comprimidos recubiertos con película",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Cómo tomar Dovato"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico. En caso de duda, consulte de nuevo a su médico o farmacéutico.</p><ul><li>La dosis recomendada de Dovato es <b>un comprimido una vez al día.</b></li></ul><p>Trague el comprimido con un poco de líquido. Dovato se puede tomar con o sin alimentos.</p><p><strong>Uso en</strong> <strong>adolescentes</strong></p><p>Los adolescentes de entre 12 y 17 a&#241;os y que pesen por lo menos 40 kg pueden tomar la dosis de adultos de un comprimido una vez al d&#237;a.</p><p><strong>Medicamentos anti&#225;cidos</strong></p><p>Los anti&#225;cidos para tratar la indigesti&#243;n y el ardor de est&#243;mago pueden hacer que Dovato no sea absorbido por su cuerpo y hacerlo menos efectivo.</p><p>No tome un anti&#225;cido durante las 6 horas antes de tomar Dovato, o por lo menos 2 horas despu&#233;s de tomarlo.</p><p>Otros medicamentos que disminuyen la acidez, como ranitidina y omeprazol, pueden tomarse al mismo tiempo que Dovato.</p><p>Consulte con su m&#233;dico para que le aconseje sobre qu&#233; medicamentos contra la acidez puede tomar con Dovato.</p><div class=\"contra-indication-calcium\"><p><strong>Suplementos o multivitam&#237;nicos que contienen calcio, hierro o magnesio</strong></p><p>Los suplementos o multivitam&#237;nicos que contengan calcio, hierro o magnesio pueden hacer que Dovato no sea absorbido en su cuerpo y hacerlo menos efectivo.</p><p>Si toma Dovato con comida, puede tomar los suplementos o multivitam&#237;nicos que contengan calcio, hierro o magnesio a la vez que Dovato. Si no toma Dovato con comida, no puede tomar un suplemento o multivitam&#237;nico que contenga calcio, hierro o magnesio durante las 6 horas antes de tomar Dovato, o por lo menos 2 horas despu&#233;s de tomarlo.</p><p>Consulte con su m&#233;dico para que le aconseje sobre c&#243;mo tomar suplementos o multivitam&#237;nicos que contengan calcio, hierro o magnesio con Dovato.</p></div><p><strong>Si toma m&#225;s</strong> <strong>Dovato</strong> <strong>del que debe</strong></p><p>Si excede el n&#250;mero de comprimidos de Dovato, <strong>contacte con su m&#233;dico o farmac&#233;utico para que le aconseje</strong>. Si es posible, mu&#233;streles la caja de Dovato.</p><p><strong>Si olvid&#243; tomar</strong> <strong>Dovato</strong></p><p>Si olvida una dosis, t&#243;mela tan pronto como lo recuerde. Pero si quedan menos de 4 horas para su pr&#243;xima dosis, s&#225;ltese esa dosis que olvid&#243; y tome la siguiente a la hora habitual. Luego contin&#250;e su tratamiento como antes.</p><p><strong>No tome una dosis doble</strong> para compensar las dosis olvidadas.</p><p><strong>&#160;</strong></p><p><strong>No interrumpa el tratamiento con Dovato sin la recomendaci&#243;n de su m&#233;dico</strong></p><p>Tome Dovato hasta que su m&#233;dico se lo indique. No deje de tomarlo a menos que su m&#233;dico se lo aconseje. La interrupci&#243;n del tratamiento con Dovato puede afectar a su salud y al funcionamiento futuro del tratamiento.</p><p>Si tiene cualquier otra duda sobre el uso de este medicamento, pregunte a su m&#233;dico o farmac&#233;utico.</p></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Posibles efectos adversos"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran, <b>por lo que es muy importante que le comente a su médico cualquier cambio en su estado de salud.</b></p><p><strong>Reacciones al&#233;rgicas</strong></p><p>Dovato contiene dolutegravir. Dolutegravir puede producir una reacci&#243;n al&#233;rgica grave conocida como <em>reacci&#243;n de hipersensibilidad.</em> Esta es una reacci&#243;n poco frecuente (puede afectar hasta 1 de cada 100 personas) en personas que toman dolutegravir. Si tiene alguno de los siguientes s&#237;ntomas:</p><ul><li>erupci&#243;n cut&#225;nea</li><li>una temperatura alta (<em>fiebre</em>)</li><li>falta de energ&#237;a (<em>cansancio</em>)</li><li>hinchaz&#243;n, a veces de la cara o la boca (<em>angioedema</em>), que causa dificultad para respirar</li><li>dolores musculares o articulares.</li></ul><p><strong></strong> <strong>Acuda a un m&#233;dico inmediatamente.</strong> Su m&#233;dico puede decidir realizar pruebas hep&#225;ticas, de ri&#241;&#243;n o sangu&#237;neas y puede que le indique que deje de tomar Dovato.</p><p><strong>Efectos adversos muy frecuentes</strong></p><p>Estos pueden afectar a <strong>m&#225;s de 1 de cada 10</strong> personas:</p><ul><li>dolor de cabeza</li><li>diarrea</li><li>n&#225;useas.</li></ul><p><strong>Efectos adversos frecuentes</strong></p><p>Estos pueden afectar <strong>hasta 1 de cada 10</strong> personas:</p><ul><li>depresi&#243;n (sensaci&#243;n de tristeza profunda y falta de autoestima)</li><li>erupci&#243;n cut&#225;nea</li><li>picor (<em>prurito</em>)</li><li>v&#243;mitos</li><li>dolor o molestias en el est&#243;mago (<em>abdominal</em>)</li><li>aumento de peso</li><li>gases (<em>flatulencia</em>)</li><li>mareo</li><li>somnolencia</li><li>dificultad para conciliar el sue&#241;o (<em>insomnio</em>)</li><li>sue&#241;os anormales</li><li>falta de energ&#237;a (<em>cansancio</em>)</li><li>p&#233;rdida de cabello</li><li>ansiedad</li><li>dolor articular</li><li>dolor muscular.</li></ul><p>Los efectos adversos frecuentes que pueden aparecer en los an&#225;lisis de sangre son:</p><ul><li>aumento en el nivel de las enzimas del h&#237;gado (<em>aminotransferasas</em>)</li><li>aumento en el nivel de las enzimas producidas en los m&#250;sculos (<em>creatinfosfoquinasa</em>).</li></ul><p><strong>Efectos adversos poco frecuentes</strong></p><p>Estos pueden afectar <strong>hasta 1 de cada 100</strong> personas:</p><ul><li>inflamaci&#243;n del h&#237;gado (<em>hepatitis</em>)</li><li>intento de suicidio (especialmente en pacientes que anteriormente han tenido depresi&#243;n o problemas de salud mental)</li><li>pensamientos suicidas (especialmente en pacientes que anteriormente han tenido depresi&#243;n o problemas de salud mental)</li><li>crisis de angustia.</li></ul><p>Los efectos adversos poco frecuentes que pueden aparecer en los an&#225;lisis de sangre son:</p><ul><li>una disminuci&#243;n de las c&#233;lulas involucradas en la coagulaci&#243;n sangu&#237;nea (<em>trombocitopenia</em>)</li><li>un recuento bajo de gl&#243;bulos rojos (<em>anemia</em>) o recuento bajo de gl&#243;bulos blancos (<em>neutropenia</em>).</li></ul><p><strong>Efectos adversos raros</strong></p><p>Estos pueden afectar <strong>hasta</strong> <strong>1 de cada 1.000</strong> personas:</p><ul><li>insuficiencia hep&#225;tica (los signos pueden incluir coloraci&#243;n amarillenta de la piel y del blanco de los ojos u orina inusualmente oscura)</li><li>hinchaz&#243;n, a veces de la cara o la boca (<em>angioedema</em>), causando dificultad para respirar</li><li>inflamaci&#243;n del p&#225;ncreas (<em>pancreatitis</em>)</li><li>rotura del tejido muscular</li><li>suicidio (especialmente en pacientes que anteriormente han tenido depresi&#243;n o problemas de salud mental).</li></ul><p><strong>Informe a su m&#233;dico de inmediato</strong> si experimenta alg&#250;n problema de salud mental (consulte tambi&#233;n otros problemas de salud mental que aparecen m&#225;s arriba).</p><p>Los efectos adversos raros que pueden aparecer en los an&#225;lisis de sangre son:</p><ul><li>aumento de bilirrubina (prueba de funci&#243;n del h&#237;gado)</li><li>aumento de una enzima llamada <em>amilasa</em>.</li></ul><p><strong>Efectos adversos muy raros</strong></p><p>Estos pueden afectar <strong>hasta</strong> <strong>1 de cada 10.000</strong> personas:</p><ul><li>acidosis l&#225;ctica (exceso de &#225;cido l&#225;ctico en la sangre)</li><li>entumecimiento, sensaci&#243;n de hormigueo en la piel (pinchazos)</li><li>sensaci&#243;n de debilidad en las extremidades.</li></ul><p>Los efectos adversos muy raros que pueden aparecer en los an&#225;lisis de sangre son:</p><ul><li>un fallo de la m&#233;dula &#243;sea en producir nuevos gl&#243;bulos rojos (<em>aplasia pura de gl&#243;bulos rojos</em>).</li></ul><p><strong>Otros posibles efectos adversos</strong></p><p>Las personas que toman un tratamiento de combinaci&#243;n para el VIH pueden tener otros efectos adversos.</p><p><strong>S&#237;ntomas de infecci&#243;n e inflamaci&#243;n</strong></p><p>Las personas con infecci&#243;n por el VIH avanzada (SIDA) tienen un sistema inmunitario debilitado y es m&#225;s probable que desarrollen infecciones graves (infecciones oportunistas). Tales infecciones pueden haberse desarrollado de manera \"silenciosa\", no siendo detectadas por el sistema inmunitario debilitado antes de que el tratamiento se iniciara. Despu&#233;s de iniciar el tratamiento, el sistema inmunitario se vuelve m&#225;s fuerte y puede luchar contra estas infecciones, lo que puede causar s&#237;ntomas de infecci&#243;n o inflamaci&#243;n. Los s&#237;ntomas generalmente incluyen fiebre, adem&#225;s de algunos de los siguientes:</p><ul><li>dolor de cabeza</li><li>dolor de est&#243;mago</li><li>dificultad para respirar.</li></ul><p>En casos raros, como el sistema inmunitario se vuelve m&#225;s fuerte, tambi&#233;n puede atacar tejidos sanos (<em>trastornos</em> <em>autoinmunes</em><em>)</em>. Los s&#237;ntomas de los trastornos autoinmunes pueden aparecer muchos meses despu&#233;s de comenzar a tomar medicamentos para tratar la infecci&#243;n por el VIH. Los s&#237;ntomas pueden incluir:</p><ul><li>palpitaciones (latido card&#237;aco r&#225;pido o irregular) o temblor</li><li>hiperactividad (excesiva inquietud y movimiento)</li><li>debilidad que empieza en las manos y pies y que asciende hacia el tronco del cuerpo.</li></ul><p><strong>Si tiene cualquier s&#237;ntoma de infecci&#243;n</strong> o si nota cualquiera de los s&#237;ntomas anteriores:</p><p><strong>Consulte a su m&#233;dico inmediatamente</strong>. No tome otros medicamentos para la infecci&#243;n sin consultar antes con su m&#233;dico.</p><p><strong>Dolor en las articulaciones, rigidez y problemas de huesos</strong></p><p>Algunas personas en tratamiento combinado para el VIH desarrollan <em>osteonecrosis</em>. En esta afecci&#243;n, partes del tejido &#243;seo se da&#241;an permanentemente debido al menor aporte de sangre a los huesos. Las personas pueden ser m&#225;s propensas a padecer esta afecci&#243;n:</p><ul><li>si han tomado un tratamiento combinado durante un largo tiempo</li><li>si tambi&#233;n est&#225;n tomando medicamentos antiinflamatorios llamados corticosteroides</li><li>si beben alcohol</li><li>si su sistema inmunitario est&#225; muy debilitado</li><li>si tienen sobrepeso.</li></ul><p><strong>Los signos de la osteonecrosis incluyen:</strong></p><ul><li>rigidez en las articulaciones</li><li>molestias y dolores en las articulaciones (especialmente en la cadera, rodilla u hombro)</li><li>dificultad de movimiento.</li></ul><p>Si nota alguno de estos s&#237;ntomas:</p><p><strong>Informe a su m&#233;dico</strong>.</p><p><strong>Efectos en el peso, los l&#237;pidos y la glucosa en sangre:</strong></p><p>Durante el tratamiento frente al VIH puede haber un aumento en el peso y en los niveles de l&#237;pidos y glucosa en la sangre. Esto est&#225; parcialmente relacionado con la recuperaci&#243;n de la salud y el estilo de vida y, a veces, con los propios medicamentos para tratar el VIH. Su m&#233;dico evaluar&#225; estos cambios.</p></div>"
          }
        },
        {
          "title" : "5. How to store Dovato 50 mg/300 mg comprimidos recubiertos con película",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Conservación de Dovato"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Mantener este medicamento fuera de la vista y del alcance de los niños</p><p>No utilice este medicamento después de la fecha de caducidad que aparece en la caja y el frasco después de CAD. La fecha de caducidad es el último día del mes que se indica.</p><p>Este medicamento no requiere ninguna condición especial de conservación.</p><p>Los medicamentos no se deben tirar por los desagües ni a la basura. Pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudará a proteger el medio ambiente.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contenido del envase e información adicional"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><b>Composición de Dovato</b><ul><li>Los principios activos son dolutegravir y lamivudina. Cada comprimido contiene dolutegravir sódico equivalente a 50 mg de dolutegravir y 300 mg de lamivudina.</li><li>Los demás componentes son celulosa microcristalina, carboximetilalmidón sódico, estearato de magnesio, manitol (E421), povidona (K29/32), fumarato estearilo de sodio, hipromelosa (E464), macrogol, dióxido de titanio (E171).</li><li>Este medicamento contiene menos de 1 mmol de sodio (23 mg) por comprimido; esto es, esencialmente “exento de sodio”.</li></ul></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-dolutegravirsodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-dolutegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-dolutegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-dolutegravirsodium</b></p><a name=\"ingredient-for-dovato-dolutegravirsodium\"> </a><a name=\"hcingredient-for-dovato-dolutegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/1Q1V9V5WYQ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 1Q1V9V5WYQ}\">DOLUTEGRAVIR SODIUM</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>50 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "1Q1V9V5WYQ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "1Q1V9V5WYQ",
              "display" : "DOLUTEGRAVIR SODIUM"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 50,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-lamivudine",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-lamivudine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-lamivudine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-lamivudine</b></p><a name=\"ingredient-for-dovato-lamivudine\"> </a><a name=\"hcingredient-for-dovato-lamivudine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/2T8Q726O95 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 2T8Q726O95}\">lamivudine</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>300 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "2T8Q726O95"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "2T8Q726O95",
              "display" : "lamivudine"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 300,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-microcrystallinecellulose</b></p><a name=\"ingredient-for-dovato-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-dovato-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-sodiumstarchglycolate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-sodiumstarchglycolate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-sodiumstarchglycolate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-sodiumstarchglycolate</b></p><a name=\"ingredient-for-dovato-sodiumstarchglycolate\"> </a><a name=\"hcingredient-for-dovato-sodiumstarchglycolate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/H8AV0SQX4D (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta H8AV0SQX4D}\">sodium starch glycolate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "H8AV0SQX4D"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "H8AV0SQX4D",
              "display" : "sodium starch glycolate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-magnesiumstearate</b></p><a name=\"ingredient-for-dovato-magnesiumstearate\"> </a><a name=\"hcingredient-for-dovato-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-dovato-mannitol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-dovato-mannitol",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-dovato-mannitol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-dovato-mannitol</b></p><a name=\"ingredient-for-dovato-mannitol\"> </a><a name=\"hcingredient-for-dovato-mannitol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/3OWL53L36A (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#123456; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 3OWL53L36A}\">mannitol</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "3OWL53L36A"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      },
      {
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "3OWL53L36A",
              "display" : "mannitol"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-dolutegravirsodium",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-dolutegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-dolutegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-dolutegravirsodium</b></p><a name=\"substance-dolutegravirsodium\"> </a><a name=\"hcsubstance-dolutegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/1Q1V9V5WYQ (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>441.36</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C20H18F2N305.Na</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(4R,12.ALPHA.S)-N-((2,4-DIFLUOROPHENYL)METHYL)-7-HYDROXY-4-METHYL-6,8-DIOXO-3,4,6,8,12,12.ALPHA.-HEXAHYDRO-2H-PYRIDO(1',2':4,5)PYRAZINO(2,1-.BETA.)(1,3)OXAZINE-9-CARBOXAMIDE</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "1Q1V9V5WYQ"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 441.36
        }
      }],
      "structure" : {
        "molecularFormula" : "C20H18F2N305.Na"
      },
      "name" : [{
        "name" : "(4R,12.ALPHA.S)-N-((2,4-DIFLUOROPHENYL)METHYL)-7-HYDROXY-4-METHYL-6,8-DIOXO-3,4,6,8,12,12.ALPHA.-HEXAHYDRO-2H-PYRIDO(1',2':4,5)PYRAZINO(2,1-.BETA.)(1,3)OXAZINE-9-CARBOXAMIDE",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-lamivudine",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-lamivudine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-lamivudine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-lamivudine</b></p><a name=\"substance-lamivudine\"> </a><a name=\"hcsubstance-lamivudine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/2T8Q726O95 (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>229.26</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C8H11N303S</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(-)-1-((2R,5S)-2-(HYDROXYMETHYL)-1,3-OXATHIOLAN-5-YL)CYTOSINE</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "2T8Q726O95"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 229.26
        }
      }],
      "structure" : {
        "molecularFormula" : "C8H11N303S"
      },
      "name" : [{
        "name" : "(-)-1-((2R,5S)-2-(HYDROXYMETHYL)-1,3-OXATHIOLAN-5-YL)CYTOSINE",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-49178f16170ee8a6bc2a4361c1748d5f",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-49178f16170ee8a6bc2a4361c1748d5f",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-49178f16170ee8a6bc2a4361c1748d5f</b></p><a name=\"ap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><a name=\"hcap-49178f16170ee8a6bc2a4361c1748d5f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "123456"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization49178f16170ee8a6bc2a4361c1748d5f0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization49178f16170ee8a6bc2a4361c1748d5f0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization49178f16170ee8a6bc2a4361c1748d5f0</b></p><a name=\"authorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><a name=\"hcauthorization49178f16170ee8a6bc2a4361c1748d5f0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2019-07-01 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mah-31ff1af739c7dcf77386a86f8dd83d29\">Organization ViiV Healthcare BV</a></p><p><b>regulator</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_mra-7c9b97127f73ff3605a10eb1c2cc24d1\">Organization European Medicines Agency</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2019-07-01T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-31ff1af739c7dcf77386a86f8dd83d29"
      },
      "regulator" : {
        "reference" : "Organization/mra-7c9b97127f73ff3605a10eb1c2cc24d1"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/man-173fde4cb6b1018cb7ec8ab708d3961c",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "man-173fde4cb6b1018cb7ec8ab708d3961c",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization man-173fde4cb6b1018cb7ec8ab708d3961c</b></p><a name=\"man-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><a name=\"hcman-173fde4cb6b1018cb7ec8ab708d3961c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100004538 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000033}\">Manufacturer</span></p><p><b>name</b>: GLAXO WELLCOME, S.A.</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Avda. Extremadura 3, 09400 Aranda De Duero Aranda De Duero ES(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100004538"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000033",
          "display" : "Manufacturer"
        }]
      }],
      "name" : "GLAXO WELLCOME, S.A.",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Avda. Extremadura 3, 09400 Aranda De Duero Aranda De Duero ES",
          "line" : ["Avda. Extremadura 3, 09400 Aranda De Duero"],
          "city" : "Aranda De Duero",
          "country" : "ES"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-31ff1af739c7dcf77386a86f8dd83d29",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-31ff1af739c7dcf77386a86f8dd83d29",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-31ff1af739c7dcf77386a86f8dd83d29</b></p><a name=\"mah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><a name=\"hcmah-31ff1af739c7dcf77386a86f8dd83d29\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100012958 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: ViiV Healthcare BV</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Van Asch van Wijckstraat 55H Amersfoort NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100012958"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "ViiV Healthcare BV",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Van Asch van Wijckstraat 55H Amersfoort NL",
          "line" : ["Van Asch van Wijckstraat 55H"],
          "city" : "Amersfoort",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mra-7c9b97127f73ff3605a10eb1c2cc24d1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mra-7c9b97127f73ff3605a10eb1c2cc24d1",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mra-7c9b97127f73ff3605a10eb1c2cc24d1</b></p><a name=\"mra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><a name=\"hcmra-7c9b97127f73ff3605a10eb1c2cc24d1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100013412 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000032}\">Medicines Regulatory Authority</span></p><p><b>name</b>: European Medicines Agency</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100013412"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000032",
          "display" : "Medicines Regulatory Authority"
        }]
      }],
      "name" : "European Medicines Agency",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL",
          "line" : ["Carretera De Martorell 41 61, Poligono Industrial Nord-Est"],
          "city" : "Amsterdam",
          "postalCode" : "1083 HS",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-2977a2afce16a0bd914b8d242dd126b5",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-2977a2afce16a0bd914b8d242dd126b5",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-2977a2afce16a0bd914b8d242dd126b5</b></p><a name=\"ppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><a name=\"hcppd-2977a2afce16a0bd914b8d242dd126b5\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>name</b>: Dovato 50 mg/300 mg film-coated tablets 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001,https://www.who-umc.org/phpid#0x073AF2E5B92AE19E8B67635AFFB3D6CA; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003203}\">Glass</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/19/1370/001 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "name" : "Dovato 50 mg/300 mg film-coated tablets 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003203",
              "display" : "Glass"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp16598f252d07b4784b82ba43cf9e847e",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp16598f252d07b4784b82ba43cf9e847e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp16598f252d07b4784b82ba43cf9e847e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp16598f252d07b4784b82ba43cf9e847e</b></p><a name=\"mp16598f252d07b4784b82ba43cf9e847e\"> </a><a name=\"hcmp16598f252d07b4784b82ba43cf9e847e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001, <code>https://www.who-umc.org/phpid</code>/0x073AF2E5B92AE19E8B67635AFFB3D6CA</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Dovato 50 mg/300 mg film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Dovato</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: dolutegravir/lamivudine</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 50 mg/300 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0x073AF2E5B92AE19E8B67635AFFB3D6CA"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Dovato 50 mg/300 mg film-coated tablets",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Dovato",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "dolutegravir/lamivudine",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "50 mg/300 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "film-coated tablets",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-49178f16170ee8a6bc2a4361c1748d5f",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-49178f16170ee8a6bc2a4361c1748d5f",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-49178f16170ee8a6bc2a4361c1748d5f</b></p><a name=\"mid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><a name=\"hcmid-49178f16170ee8a6bc2a4361c1748d5f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/19/1370/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073665}\">Film-coated tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-da-49178f16170ee8a6bc2a4361c1748d5f.html#Organization_man-173fde4cb6b1018cb7ec8ab708d3961c\">Organization GLAXO WELLCOME, S.A.</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/19/1370/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073665",
          "display" : "Film-coated tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-173fde4cb6b1018cb7ec8ab708d3961c"
      }]
    }
  }]
}

```
