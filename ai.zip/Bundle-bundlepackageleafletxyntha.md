# Bundle - Patient Medication Information for Xyntha® Lyophilized Powder for Reconstitution in a Vial - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle - Patient Medication Information for Xyntha® Lyophilized Powder for Reconstitution in a Vial**

## Example Bundle: Bundle - Patient Medication Information for Xyntha® Lyophilized Powder for Reconstitution in a Vial

**Composition category:**

**Composition status:**final

### TITLE PAGE

 

![](#binarypfizerlogo)

**Xyntha**®

Lyophilized Powder for Reconstitution in a Vial

250, 500, 1000, or 2000 IU in single-use vials and one pre-filled diluent syringe containing 4 mL 0.9% Sodium Chloride for reconstitution*

Antihemophilic Factor (Recombinant) [BDDrFVIII]

For Intravenous Injection

Antihemorrhagic Blood Coagulation Factor VIII

Reference Market: Canada


### PACKAGE LEAFLET

 

**Xyntha**®

Moroctocog alfa, Antihemophilic Factor (Recombinant)

**Xyntha 250, 500, 1000, & 2000 IU Powder* and *Solvent for Solution* for *Injection**

*This leaflet is a summary and will not tell you everything about **Xyntha. Contact your doctor or hemophilia treatment center if you have any questions about the drug.*


### ABOUT THIS MEDICATION

 

**What the medication is used for:**

Coagulation Factor VIII is a protein that is necessary for blood to clot. People who have the hereditary bleeding disease factor VIII deficiency (hemophilia A) lack this clotting factor, causing their blood to take longer to form a clot. Xyntha is a form of coagulation factor VIII.

Xyntha is used for the control and treatment of bleeding and the routine and surgical prevention of bleeding in people with hemophilia A.

**What is does:**

Administering Xyntha increases blood levels of factor VIII and helps prevent and control bleeding episodes in patients with hemophilia A. Xyntha has the same clot-promoting effects as factor VIII protein made from human plasma.

**When it should not be used:**

You should not take Xyntha unless your doctor confirms you have hemophilia A. Xyntha should not be used for the treatment of other clotting factor deficiencies such as von Willebrand’s disease or hemophilia B.

Xyntha is produced in hamster cells and may contain trace amounts of hamster proteins. Patients who have a known history of allergic reactions to hamster proteins should not take Xyntha. Your doctor will advise you if you have had allergic reactions to hamster proteins.

Do not use Xyntha after the expiry date printed on the pack.

Do not use Xyntha if the packaging is torn or shows signs of tampering.

**What the medicinal ingredient is:**

Xyntha is a coagulation factor VIII product that is produced by recombinant technology.

Xyntha does not contain any human blood or plasma, albumin, preservatives, or added animal or human components in the final product, making it naturally free from the risk of transmission of blood-borne pathogens such as human immunodeficiency virus (HIV), hepatitis viruses, and parvovirus.

**What the important nonmedicinal ingredients are:**

Polysorbate 80 (0.4 mg/vial), Sucrose (12 mg/vial), L-Histidine (6 mg/vial), Calcium Chloride Dihydrate (1 mg/vial), Sodium Chloride (72 mg/vial) [after reconstitution with diluent].

**What dosage forms it comes in:**

Xyntha is supplied in kits that include single-use vials that contain nominally 250, 500, 1000, or 2000 IU per vial with pre-filled diluent syringe containing 4 mL 0.9% Sodium Chloride for reconstitution.


### WARNINGS AND PRECAUTIONS

 


**BEFORE you use ****Xyntha**** talk to your hemophilia doctor if:**

* You are pregnant or planning to become pregnant***. ***It is not known whether Xyntha can affect your ability to have children or harm your developing baby.
* You are breastfeeding or planning to breast feed. It is not known whether Xyntha passes into breast milk.
* You are taking other medicines***. ***Tell your hemophilia doctor if you are taking any other medicines or naturopathic products, including any that you buy without a prescription from your pharmacy, supermarket, or health food shop.

Your hemophilia doctor will advise you whether or not to take Xyntha or if you need to adjust the dose, or adapt your treatment.


#### INTERACTIONS WITH THIS MEDICATION

 

No interactions of Xyntha with other medicinal products are known.


### PROPER USE OF THIS MEDICATION

 

You should always follow the specific instructions given by your hemophilia doctor.

The steps listed below are general guidelines for using Xyntha. If you are unsure of the procedures, please call your hemophilia doctor or nurse before using.

Your hemophilia doctor will decide the dose of Xyntha you will receive. The dose and duration of Xyntha treatment will depend on your individual need for replacement factor VIII therapy.

Your hemophilia doctor may decide to change your dose of Xyntha. In the presence of an inhibitor, you may need higher doses or specific treatment. Contact your hemophilia doctor or nurse immediately if bleeding is not controlled after using Xyntha.

Do not stop taking Xyntha or lower your dose, without checking with your hemophilia doctor, unless you think you are having an allergic reaction.

Your doctor may occasionally need to take blood tests to make sure that the level of factor VIII in your blood is high enough to allow normal blood clotting.

Each Xyntha vial kit contains:

* 1 vial of Xyntha powder
* 1 syringe pre-filled with 4 mL of sodium chloride diluent
* 1 plunger rod for the syringe
* 1 vial adapter
* 1 sterile infusion set
* 2 alcohol swabs
* 1 bandage
* 1 gauze
* 1 package insert

Xyntha Hospital pack contains:

* 3 vial of Xyntha powder
* 3 syringe pre-filled with 4 mL of sodium chloride diluent
* 3 plunger rods for the syringe
* 3 vial adapters
* 1 package insert

Xyntha Hospital pack does not contain:

* sterile infusion set (tubing and butterfly needle)
* alcohol swabs
* bandage
* gauze

Not all strengths/pack sizes may be marketed.

Xyntha is supplied in a sterile, freeze-dried powder form, and it is intended for injection directly into your vein, usually either by yourself, your doctor, your hemophilia nurse, or other trained person.

Before it can be injected, the powder must be dissolved with the liquid diluent supplied (0.9% sodium chloride) to make it an injectable liquid.

An infusion set (tubing and butterfly needle), sterile alcohol swabs, gauze pads and bandages are required.

These devices are not included in the Xyntha Hospital package.

Always use an aseptic technique.

**RECONSTITUTION**

Always wash your hands before performing the following procedures. Use germ-free methods during the preparation procedures.

Use only the materials provided in the Xyntha kit for dissolving the Xyntha powder with the sodium chloride diluent.

All components used in the mixing and injection of Xyntha should be used as soon as possible after opening their sterile containers to minimize unnecessary exposure to room air.

Xyntha is administered by intravenous injection after dissolving with the supplied diluent (0.9% sodium chloride) in the pre-filled syringe.

Additional instructions for using Xyntha are provided after **INFUSION (Intravenous Injection)** that detail the use of a Xyntha Powder and Solvent for Solution for Injection.

Note: If you use more than one vial of Xyntha per injection, each vial should be dissolved according to the following instructions. The empty syringe should be removed leaving the vial adapter in place, and a separate large luer lock syringe may be used to draw back the dissolved contents of each vial. Do not detach the diluent syringes or the large luer lock syringe until you are ready to attach the large luer lock syringe to the next vial adapter.

1. Allow the vial of freeze-dried Xyntha powder and the pre-filled diluent syringe to reach room temperature.
1. Remove the plastic flip-top cap from the Xyntha vial to expose the central portions of the rubber stopper.![](#binaryimage003)
1. Wipe the top of the vial with alcohol swab, or use another antiseptic solution, and allow to dry. After cleaning, do not touch the rubber stopper with your hand or allow it to touch any surface.If you need to use more than 1 vial to inject your prescribed dose, you must use a new alcohol swab for each vial.
1. 
1. Peel back the cover from the clear plastic vial adapter package. **Do not remove the adapter from the package.**
1. Place the vial on a flat surface. While holding the adapter in the package, place the vial adapter over the vial. Press down firmly on the package until the adapter snaps into place on top of the vial, with the adapter spike penetrating the vial stopper.
1. Grasp the plunger rod as shown in the diagram. Avoid contact with the shaft of the plunger rod. Attach the threaded end of the plunger rod to the diluent syringe by pushing and turning firmly.![](#binaryimage004)
1. Break off the tamper-resistant, plastic-tip cap from the diluent syringe by snapping the perforation of the cap. This is done by bending the cap up and down until the perforation is broken. Do not touch the inside of the cap or the syringe tip. The diluent syringe may need to be recapped (if the dissolved Xyntha is not used immediately), so place the cap on its top on a clean surface in a spot where it would be least likely to become contaminated.![](#image007)
1. Lift the package away from the adapter and discard the package.![](#image008)
1. Place the vial on a flat surface. Connect the diluent syringe to the vial adapter by inserting the tip of the syringe into the adapter opening while firmly pushing and turning the syringe clockwise until the connection is secured.![](#)
1. Slowly depress the plunger rod to inject all the diluent into the Xyntha vial.![](#image012a)
1. With the syringe still connected to the adapter, gentlyswirl the contents of the vial until the powder is dissolved.
1. Note: The final solution should be inspected visually for particulate matter before administration. The solution should be clear to slightly pearly and colorless. If it is not, the solution should be discarded and a new kit should be used.
1. Ensuring that the syringe plunger rod is still fully depressed, invert the vial. Slowly draw the solution into the syringe.
1. Note: If you prepared more than one vial of Xyntha, remove the diluent syringe from the vial adapter, leaving the vial adapter attached to the vial. Quickly attach a separate large luer lock syringe and draw back the dissolved contents as instructed above. Repeat this procedure with each vial in turn. Do not detach the diluent syringes or the large luer lock syringe until you are ready to attach the large luer lock syringe to the next vial adapter.![](#image012b)
1. Detach the syringe from the vial adapter by gently pulling and turning the syringe counterclockwise. Discard the vial with the adapter attached. Note: If the solution is not to be used immediately, the syringe cap should be carefully replaced. Do not touch the syringe tip or the inside of the cap.

Xyntha should be infused within 3 hours after dissolving. The dissolved solution may be stored at room temperature prior to infusion.

**INFUSION (Intravenous Injection)**

You should inject Xyntha as instructed by your hemophilia doctor or nurse. Once you learn how to self-infuse, you can follow the instructions in this insert.

Always wash your hands before doing the following procedures. Germ-free methods should be used during injection. If you need to use more than 1 vial to inject your prescribed dose, you must use a new alcohol swab for each vial. Do not use the injection needle to withdraw the medicine from vial.

Xyntha should be administered using the pre-filled diluent syringe provided or a single sterile disposable plastic luer-lock syringe. In addition, the solution should be withdrawn from the vial using the vial adapter.

1. Attach the syringe to the luer end of the infusion set tubing and perform venipuncture as instructed by your hemophilia doctor or nurse.
1. Apply a tourniquet and prepare the injection site by wiping the skin well with an alcohol swab.![](#image013)
1. Insert the needle on the infusion set tubing into the vein, and remove the tourniquet. Infuse the reconstituted Xyntha product over several minutes. Your comfort level should determine the rate of infusion.![](#image014)
1. After injecting Xyntha, remove the infusion set and discard. The amount of drug product left in the infusion set will not affect your treatment. Dispose of all unused solution, the empty vial(s), and the used needles and syringes in an appropriate sharps container used for throwing away waste that might hurt others if not handled properly.

You should record the lot number of the product every time you use Xyntha. The lot number can be found on the vial label. The peel-off label on the vial may be used to record the lot number.

| |
| :--- |
| In case of drug overdose, contact a health care practitioner, hospital emergency department or regional Poison Control Centre immediately, even if there are no symptoms. |


### SIDE EFFECTS AND WHAT TO DO ABOUT THEM

 

Xyntha may cause allergic reactions.

Some side effects of Xyntha include cold sensation, chest pain, rapid heart beat, sweating, drowsiness, muscle weakness, loss of appetite, muscle pain, pain, coughing, shortness of breath, diarrhea, stomach cramps, altered taste, injection site pain or inflammation and weakness.

Contact your hemophilia doctor immediately if your bleeding does not stop as expected.

Your body can also produce inhibitors, or antibodies, against Xyntha, which may prevent Xyntha from working properly. If your bleeding is not controlled with the usual dose of Xyntha, call your hemophilia doctor or nurse. You should be monitored in order to find out whether a factor VIII inhibitor is present.

These are not all the possible side effects of Xyntha. Call your hemophilia doctor or nurse right away if any side effect becomes serious, if you notice any side effects not listed in this leaflet, or if there is any other side effect that concerns you.

Tell all your doctors, dentists, and pharmacists who are treating you that you are taking Xyntha.

If you are about to start taking any new medication, tell your doctor and pharmacist that you are taking Xyntha.

If you become pregnant while taking Xyntha, tell your hemophilia doctor and your doctor who will look after you during your pregnancy.

* **Very Rare**: Headache
  * ?: 
  * ?: 
  * ?: x
* **Very Rare**: Fever
  * ?: 
  * ?: 
  * ?: x
* **Very Rare**: Nausea
  * ?: 
  * ?: 
  * ?: x
* **Very Rare**: Vomiting
  * ?: 
  * ?: 
  * ?: x
* **Very Rare**: Bleeding does not stop as expected after infusing Xyntha
  * ?: 
  * ?: x
  * ?: 
* **Very Rare**: Using an increasing amount of Xyntha to control your bleed
  * ?: 
  * ?: x
  * ?: 
* **Very Rare**: Chills
  * ?: 
  * ?: 
  * ?: x
* **Very Rare**: Flushing
  * ?: 
  * ?: 
  * ?: x
* **Very Rare**: Allergic reactions (such as skin rash, itching, chest tightness, wheezing, dizziness, hives, faintness, rapid heartbeat, shortness of breath, and/or a swollen face)
  * ?: 
  * ?: 
  * ?: x

*This is not a complete list of side effects. For any unexpected effects while taking Xyntha, contact your doctor or hemophilia treatment center.*


### HOW TO STORE IT

 

Keep the freeze-dried Xyntha vial and the diluent syringe in the refrigerator at a temperature of 2° to 8°C.

Xyntha may be stored at room temperature not above 25°C for up to 3 months and not to exceed the expiration date. You should write the date in the space provided on the outer carton when you first store Xyntha at room temperature.

After room temperature storage, the product can be returned to refrigerated storage until the expiration date. Do not store Xyntha at room temperature and return it to refrigerated storage more than once.

DO NOT freeze.

DO NOT use after the expiration date (month and year) on the label, even if it has been stored properly.

Avoid exposure of the Xyntha vials to light.

Xyntha does not contain a preservative. Use the dissolved solution as soon as possible after mixing. If the solution is not used right away, it can be stored at room temperature and must be used within 3 hours.

DO NOT use Xyntha if the dissolved solution is not clear to slightly pearly and colorless.

Keep Xyntha (and needles) where young children cannot reach it.


### MORE INFORMATION

 

Last revised: April 2016

**Marketing Authorisation Holder:**

Pfizer Canada ULC.

17300 Trans-Canada Highway

Kirkland, Quebec

Canada, H9J 2M5

**Manufactured, Packaged and Released By:**

Wyeth Farma S.A,

Autovia Del Norte A-1, KM 23

Desvio Algete, KM 1,

28700 San Sebastian De Los Reyes

Madrid, Spain



####  

-------

Full name: ****

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleafletxyntha",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.jordan.gov.jo/",
    "value" : "xyntha"
  },
  "type" : "document",
  "timestamp" : "2020-09-01T00:00:00Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/compositionpmixyntha",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "compositionpmixyntha",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_compositionpmixyntha\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition compositionpmixyntha</b></p><a name=\"compositionpmixyntha\"> </a><a name=\"hccompositionpmixyntha\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://www.jordan.gov.jo/</code>/0d69fdcb-33cf-407f-8209-a6529856ab4f</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://www.jordan.gov.jo/ 100000155538}\">Package Leaflet</span></p><p><b>date</b>: 2020-09-01 00:00:00+0000</p><p><b>author</b>: </p><ul><li><a href=\"Bundle-bundlepackageleafletxyntha.html#Organization_organizationpfizercanada\">Organization Pfizer Canada ULC.</a></li><li><a href=\"Bundle-bundlepackageleafletxyntha.html#Organization_organizationwyeth\">Organization Manufactured, Packaged and Released By Wyeth Farma S.A</a></li></ul><p><b>title</b>: Patient Medicination Information Xyntha® Lyophilized Powder for Reconstitution in a Vial</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.jordan.gov.jo/",
        "value" : "0d69fdcb-33cf-407f-8209-a6529856ab4f"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://www.jordan.gov.jo/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "date" : "2020-09-01T00:00:00Z",
      "author" : [{
        "reference" : "Organization/organizationpfizercanada"
      },
      {
        "reference" : "Organization/organizationwyeth"
      }],
      "title" : "Patient Medicination Information Xyntha® Lyophilized Powder for Reconstitution in a Vial",
      "section" : [{
        "title" : "TITLE PAGE",
        "code" : {
          "coding" : [{
            "system" : "https://www.jordan.gov.jo/",
            "code" : "100000155538"
          }],
          "text" : "Title Page"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><img src=\"#binarypfizerlogo\" alt=\"Pfizer Logo\"/></p><p><b>Xyntha</b><sup>®</sup></p><p>Lyophilized Powder for Reconstitution in a Vial</p><p>250, 500, 1000, or 2000 IU in single-use vials and one pre-filled diluent syringe containing 4 mL 0.9% Sodium Chloride for reconstitution*</p><p>Antihemophilic Factor (Recombinant) [BDDrFVIII]</p><p>For Intravenous Injection</p><p>Antihemorrhagic Blood Coagulation Factor VIII</p><p>Reference Market: Canada</p></div>"
        }
      },
      {
        "title" : "PACKAGE LEAFLET",
        "code" : {
          "coding" : [{
            "system" : "https://www.jordan.gov.jo/",
            "code" : "100000155538"
          }],
          "text" : "Package leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><b>Xyntha</b><sup>®</sup></p><p>Moroctocog alfa, Antihemophilic Factor (Recombinant)</p><p><b>Xyntha 250, 500, 1000, &amp; 2000 IU Powder<i> and </i>Solvent for Solution<i> for </i>Injection</b></p><p><i>This leaflet is a summary and will not tell you everything about </i><i>Xyntha. Contact your doctor or hemophilia treatment center if you have any questions about the drug.</i></p></div>"
        }
      },
      {
        "title" : "ABOUT THIS MEDICATION",
        "code" : {
          "coding" : [{
            "system" : "https://www.jordan.gov.jo/",
            "code" : "100000155538"
          }],
          "text" : "ABOUT THIS MEDICATION"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><b>What the medication is used for:</b></p><p>Coagulation Factor VIII is a protein that is necessary for blood to clot. People who have the hereditary bleeding disease factor VIII deficiency (hemophilia A) lack this clotting factor, causing their blood to take longer to form a clot. Xyntha is a form of coagulation factor VIII.</p><p>Xyntha is used for the control and treatment of bleeding and the routine and surgical prevention of bleeding in people with hemophilia A.</p><p><b>What is does:</b></p><p>Administering Xyntha increases blood levels of factor VIII and helps prevent and control bleeding episodes in patients with hemophilia A. Xyntha has the same clot-promoting effects as factor VIII protein made from human plasma.</p><p><b>When it should not be used:</b></p><p>You should not take Xyntha unless your doctor confirms you have hemophilia A. Xyntha should not be used for the treatment of other clotting factor deficiencies such as von Willebrand’s disease or hemophilia B.</p><p>Xyntha is produced in hamster cells and may contain trace amounts of hamster proteins. Patients who have a known history of allergic reactions to hamster proteins should not take Xyntha. Your doctor will advise you if you have had allergic reactions to hamster proteins.</p><p>Do not use Xyntha after the expiry date printed on the pack.</p><p>Do not use Xyntha if the packaging is torn or shows signs of tampering.</p><p><b>What the medicinal ingredient is:</b></p><p>Xyntha is a coagulation factor VIII product that is produced by recombinant technology.</p><p>Xyntha does not contain any human blood or plasma, albumin, preservatives, or added animal or human components in the final product, making it naturally free from the risk of transmission of blood-borne pathogens such as human immunodeficiency virus (HIV), hepatitis viruses, and parvovirus.</p><p><b>What the important nonmedicinal ingredients are:</b></p><p>Polysorbate 80 (0.4 mg/vial), Sucrose (12 mg/vial), L-Histidine (6 mg/vial), Calcium Chloride Dihydrate (1 mg/vial), Sodium Chloride (72 mg/vial) [after reconstitution with diluent].</p><p><b>What dosage forms it comes in:</b></p><p>Xyntha is supplied in kits that include single-use vials that contain nominally 250, 500, 1000, or 2000 IU per vial with pre-filled diluent syringe containing 4 mL 0.9% Sodium Chloride for reconstitution.</p></div>"
        }
      },
      {
        "title" : "WARNINGS AND PRECAUTIONS",
        "code" : {
          "coding" : [{
            "system" : "https://www.jordan.gov.jo/",
            "code" : "100000155538"
          }],
          "text" : "WARNINGS AND PRECAUTIONS"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><table border=\"1\"><tbody><tr><td><p><b>Serious Warnings and Precautions</b></p></td></tr><tr><td><p><b>Xyntha may cause allergic reactions. Signs of allergy include hives (rash with itching), swelling, chest tightness, difficulty breathing, wheezing, faintness, and rapid heart rate. If any of these symptoms occur, stop using Xyntha immediately and contact your hemophilia doctor or seek emergency medical care. The initial infusions of Xyntha should be administered under proper medical supervision, where proper medical care for allergic reactions could be provided.</b></p><p><b>Notify your hemophilia doctor if you are unable to prevent or control episodes of bleeding with your normal dose of Xyntha.  Your body may produce inhibitors against Xyntha. Inhibitors are antibodies produced by your immune system that can prevent Xyntha from working properly. Check with your hemophilia doctor to make sure you are closely monitored with blood tests for the presence of inhibitors.</b></p></td></tr></tbody></table><p><b>BEFORE you use </b><b>Xyntha</b><b> talk to your hemophilia doctor if:</b></p><ul><li><p>You are pregnant or planning to become pregnant<b><i>. </i></b>It is not known whether Xyntha can affect your ability to have children or harm your developing baby.</p></li><li><p>You are breastfeeding or planning to breast feed. It is not known whether Xyntha passes into breast milk.</p></li><li><p>You are taking other medicines<b><i>. </i></b>Tell your hemophilia doctor if you are taking any other medicines or naturopathic products, including any that you buy without a prescription from your pharmacy, supermarket, or health food shop.</p></li></ul><p>Your hemophilia doctor will advise you whether or not to take Xyntha or if you need to adjust the dose, or adapt your treatment.</p></div>"
        },
        "section" : [{
          "title" : "INTERACTIONS WITH THIS MEDICATION",
          "code" : {
            "coding" : [{
              "system" : "https://www.jordan.gov.jo/",
              "code" : "100000155538"
            }],
            "text" : "INTERACTIONS WITH THIS MEDICATION"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>No interactions of Xyntha with other medicinal products are known.</p></div>"
          }
        }]
      },
      {
        "title" : "PROPER USE OF THIS MEDICATION",
        "code" : {
          "coding" : [{
            "system" : "https://www.jordan.gov.jo/",
            "code" : "100000155538"
          }],
          "text" : "PROPER USE OF THIS MEDICATION"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>You should always follow the specific instructions given by your hemophilia doctor.</p><p>The steps listed below are general guidelines for using Xyntha<sup>. </sup>If you are unsure of the procedures, please call your hemophilia doctor or nurse before using.</p><p>Your hemophilia doctor will decide the dose of Xyntha you will receive. The dose and duration of Xyntha treatment will depend on your individual need for replacement factor VIII therapy.</p><p>Your hemophilia doctor may decide to change your dose of Xyntha. In the presence of an inhibitor, you may need higher doses or specific treatment. Contact your hemophilia doctor or nurse immediately if bleeding is not controlled after using Xyntha.</p><p>Do not stop taking Xyntha or lower your dose, without checking with your hemophilia doctor, unless you think you are having an allergic reaction.</p><p>Your doctor may occasionally need to take blood tests to make sure that the level of factor VIII in your blood is high enough to allow normal blood clotting.</p><p>Each Xyntha vial kit contains:</p><ul><li><p>1 vial of Xyntha powder</p></li><li><p>1 syringe pre-filled with 4 mL of sodium chloride diluent</p></li><li><p>1 plunger rod for the syringe</p></li><li><p>1 vial adapter</p></li><li><p>1 sterile infusion set</p></li><li><p>2 alcohol swabs</p></li><li><p>1 bandage</p></li><li><p>1 gauze</p></li><li><p>1 package insert</p></li></ul><p></p><p>Xyntha Hospital pack contains:</p><ul><li><p>3 vial of Xyntha powder</p></li><li><p>3 syringe pre-filled with 4 mL of sodium chloride diluent</p></li><li><p>3 plunger rods for the syringe</p></li><li><p>3 vial adapters</p></li><li><p>1 package insert</p></li></ul><p/><p>Xyntha Hospital pack does not contain:</p><ul><li><p>sterile infusion set (tubing and butterfly needle)</p></li><li><p>alcohol swabs</p></li><li><p>bandage</p></li><li><p>gauze</p></li></ul><p>Not all strengths/pack sizes may be marketed.</p><p>Xyntha is supplied in a sterile, freeze-dried powder form, and it is intended for injection directly into your vein, usually either by yourself, your doctor, your hemophilia nurse, or other trained person.</p><p>Before it can be injected, the powder must be dissolved with the liquid diluent supplied (0.9% sodium chloride) to make it an injectable liquid.</p><p>An infusion set (tubing and butterfly needle), sterile alcohol swabs, gauze pads and bandages are required.</p><p>These devices are not included in the Xyntha Hospital package.</p><p/><p>Always use an aseptic technique.</p><p></p><p><b>RECONSTITUTION</b></p><p>Always wash your hands before performing the following procedures. Use germ-free methods during the preparation procedures.</p><p>Use only the materials provided in the Xyntha kit for dissolving the Xyntha powder with the sodium chloride diluent.</p><p>All components used in the mixing and injection of Xyntha should be used as soon as possible after opening their sterile containers to minimize unnecessary exposure to room air.</p><p>Xyntha is administered by intravenous injection after dissolving with the supplied diluent (0.9% sodium chloride) in the pre-filled syringe.</p><p>Additional instructions for using Xyntha are provided after <b>INFUSION (Intravenous Injection)</b> that detail the use of a Xyntha Powder and Solvent for Solution for Injection.</p><p>Note: If you use more than one vial of Xyntha per injection, each vial should be dissolved according to the following instructions. The empty syringe should be removed leaving the vial adapter in place, and a separate large luer lock syringe may be used to draw back the dissolved contents of each vial. Do not detach the diluent syringes or the large luer lock syringe until you are ready to attach the large luer lock syringe to the next vial adapter.</p><p></p><ol><li><p>Allow the vial of freeze-dried Xyntha powder and the pre-filled diluent syringe to reach room temperature.</p></li><li><p>Remove the plastic flip-top cap from the Xyntha vial to expose the central portions of the rubber stopper.</p><img src=\"#binaryimage003\" alt=\"clip_image003_-1584181510.png\"/></li><li><p>Wipe the top of the vial with alcohol swab, or use another antiseptic solution, and allow to dry. After cleaning, do not touch the rubber stopper with your hand or allow it to touch any surface.If you need to use more than 1 vial to inject your prescribed dose, you must use a new alcohol swab for each vial.</p></li><li><p></p></li><li><p>Peel back the cover from the clear plastic vial adapter package. <b>Do not remove the adapter from the package.</b></p></li><li><p>Place the vial on a flat surface. While holding the adapter in the package, place the vial adapter over the vial. Press down firmly on the package until the adapter snaps into place on top of the vial, with the adapter spike penetrating the vial stopper.</p></li><li><p>Grasp the plunger rod as shown in the diagram. Avoid contact with the shaft of the plunger rod. Attach the threaded end of the plunger rod to the diluent syringe by pushing and turning firmly.</p><img src=\"#binaryimage004\" alt=\"clip_image004_128978964.png\"/></li><li><p>Break off the tamper-resistant, plastic-tip cap from the diluent syringe by snapping the perforation of the cap. This is done by bending the cap up and down until the perforation is broken. Do not touch the inside of the cap or the syringe tip. The diluent syringe may need to be recapped (if the dissolved Xyntha is not used immediately), so place the cap on its top on a clean surface in a spot where it would be least likely to become contaminated.</p><img src=\"#image007\" alt=\"clip_image007_1848870172.png\"/></li><li><p>Lift the package away from the adapter and discard the package.</p><img src=\"#image008\" alt=\"clip_image008_-1930407291.png\"/></li><li><p>Place the vial on a flat surface. Connect the diluent syringe to the vial adapter by inserting the tip of the syringe into the adapter opening while firmly pushing and turning the syringe clockwise until the connection is secured.</p><img src=\"#\" alt=\"clip_image010_524367703.png\"/></li><li><p>Slowly depress the plunger rod to inject all the diluent into the Xyntha vial.</p><img src=\"#image012a\" alt=\"clip_image012_583978923.png\"/></li><li><p>With the syringe still connected to the adapter, gentlyswirl the contents of the vial until the powder is dissolved.</p></li><li><p>Note: The final solution should be inspected visually for particulate matter before administration. The solution should be clear to slightly pearly and colorless. If it is not, the solution should be discarded and a new kit should be used.</p></li><li><p>Ensuring that the syringe plunger rod is still fully depressed, invert the vial. Slowly draw the solution into the syringe.</p></li><li><p>Note: If you prepared more than one vial of Xyntha, remove the diluent syringe from the vial adapter, leaving the vial adapter attached to the vial. Quickly attach a separate large luer lock syringe and draw back the dissolved contents as instructed above. Repeat this procedure with each vial in turn. Do not detach the diluent syringes or the large luer lock syringe until you are ready to attach the large luer lock syringe to the next vial adapter.</p><img src=\"#image012b\" alt=\"clip_image012_-1646958650.png\"/></li><li><p>Detach the syringe from the vial adapter by gently pulling and turning the syringe counterclockwise. Discard the vial with the adapter attached. Note: If the solution is not to be used immediately, the syringe cap should be carefully replaced. Do not touch the syringe tip or the inside of the cap.</p></li></ol><p>Xyntha should be infused within 3 hours after dissolving. The dissolved solution may be stored at room temperature prior to infusion.</p><p><b>INFUSION (Intravenous Injection)</b></p><p>You should inject Xyntha as instructed by your hemophilia doctor or nurse. Once you learn how to self-infuse, you can follow the instructions in this insert.</p><p>Always wash your hands before doing the following procedures. Germ-free methods should be used during injection. If you need to use more than 1 vial to inject your prescribed dose, you must use a new alcohol swab for each vial. Do not use the injection needle to withdraw the medicine from vial.</p><p>Xyntha should be administered using the pre-filled diluent syringe provided or a single sterile disposable plastic luer-lock syringe. In addition, the solution should be withdrawn from the vial using the vial adapter.</p><ol><li><p>Attach the syringe to the luer end of the infusion set tubing and perform venipuncture as instructed by your hemophilia doctor or nurse.</p></li><li><p>Apply a tourniquet and prepare the injection site by wiping the skin well with an alcohol swab.</p><img src=\"#image013\" alt=\"clip_image013_1472120925.png\"/></li><li><p>Insert the needle on the infusion set tubing into the vein, and remove the tourniquet. Infuse the reconstituted Xyntha product over several minutes. Your comfort level should determine the rate of infusion.</p><img src=\"#image014\" alt=\"clip_image014_-861669482.jpg\"/></li><li><p>After injecting Xyntha, remove the infusion set and discard. The amount of drug product left in the infusion set will not affect your treatment. Dispose of all unused solution, the empty vial(s), and the used needles and syringes in an appropriate sharps container used for throwing away waste that might hurt others if not handled properly.</p></li></ol><p>You should record the lot number of the product every time you use Xyntha. The lot number can be found on the vial label. The peel-off label on the vial may be used to record the lot number.</p><table border=\"1\"><tbody><tr><td>In case of drug overdose, contact a health care practitioner, hospital emergency department or regional Poison Control Centre immediately, even if there are no symptoms.</td></tr></tbody></table></div>"
        }
      },
      {
        "title" : "SIDE EFFECTS AND WHAT TO DO ABOUT THEM",
        "code" : {
          "coding" : [{
            "system" : "https://www.jordan.gov.jo/",
            "code" : "100000155538"
          }],
          "text" : "SIDE EFFECTS AND WHAT TO DO ABOUT THEM"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Xyntha may cause allergic reactions.</p><p>Some side effects of Xyntha include cold sensation, chest pain, rapid heart beat, sweating, drowsiness, muscle weakness, loss of appetite, muscle pain, pain, coughing, shortness of breath, diarrhea, stomach cramps, altered taste, injection site pain or inflammation and weakness.</p><p>Contact your hemophilia doctor immediately if your bleeding does not stop as expected.</p><p>Your body can also produce inhibitors, or antibodies, against Xyntha, which may prevent Xyntha from working properly. If your bleeding is not controlled with the usual dose of Xyntha, call your hemophilia doctor or nurse. You should be monitored in order to find out whether a factor VIII inhibitor is present.</p><p>These are not all the possible side effects of Xyntha. Call your hemophilia doctor or nurse right away if any side effect becomes serious, if you notice any side effects not listed in this leaflet, or if there is any other side effect that concerns you.</p><p>Tell all your doctors, dentists, and pharmacists who are treating you that you are taking Xyntha.</p><p>If you are about to start taking any new medication, tell your doctor and pharmacist that you are taking Xyntha.</p><p>If you become pregnant while taking Xyntha, tell your hemophilia doctor and your doctor who will look after you during your pregnancy.</p><table border=\"1\"><tbody><tr><td colspan=\"4\"><p><b>SERIOUS SIDE EFFECTS, HOW OFTEN THEY HAPPEN AND WHAT TO DO ABOUT THEM</b></p></td></tr><tr><td rowspan=\"2\"><p><b>Symptom / effect</b></p></td><td colspan=\"2\"><p><b>Talk with your doctor</b></p></td><td rowspan=\"2\"><p><b>Stop the infusion and call your doctor</b></p></td></tr><tr><td><p><b>Only if severe</b></p></td><td><p><b>In all cases</b></p></td></tr><tr><td colspan=\"4\"><p><b>Uncommon</b></p></td></tr><tr><td><p>Headache</p></td><td><p></p></td><td><p></p></td><td><p>x</p></td></tr><tr><td colspan=\"4\"><p><b>Rare</b></p></td></tr><tr><td><p>Fever</p></td><td><p></p></td><td><p></p></td><td><p>x</p></td></tr><tr><td><p>Nausea</p></td><td><p></p></td><td><p></p></td><td><p>x</p></td></tr><tr><td><p>Vomiting</p></td><td><p></p></td><td><p></p></td><td><p>x</p></td></tr><tr><td colspan=\"4\"><p><b>Very Rare</b></p></td></tr><tr><td><p>Bleeding does not stop as expected after infusing Xyntha</p></td><td><p></p></td><td><p>x</p></td><td><p></p></td></tr><tr><td><p>Using an increasing amount of Xyntha to control your bleed</p></td><td><p></p></td><td><p>x</p></td><td><p></p></td></tr><tr><td><p>Chills</p></td><td><p></p></td><td><p></p></td><td><p>x</p></td></tr><tr><td><p>Flushing</p></td><td><p></p></td><td><p></p></td><td><p>x</p></td></tr><tr><td><p>Allergic reactions (such as skin rash, itching, chest tightness, wheezing, dizziness, hives, faintness, rapid heartbeat, shortness of breath, and/or a swollen face)</p></td><td><p></p></td><td><p></p></td><td><p>x</p></td></tr></tbody></table><p><i>This is not a complete list of side effects. For any unexpected effects while taking Xyntha, contact your doctor or hemophilia treatment center.</i></p></div>"
        }
      },
      {
        "title" : "HOW TO STORE IT",
        "code" : {
          "coding" : [{
            "system" : "https://www.jordan.gov.jo/",
            "code" : "100000155538"
          }],
          "text" : "HOW TO STORE IT"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keep the freeze-dried Xyntha vial and the diluent syringe in the refrigerator at a temperature of 2° to 8°C.</p><p>Xyntha may be stored at room temperature not above 25°C for up to 3 months and not to exceed the expiration date. You should write the date in the space provided on the outer carton when you first store Xyntha at room temperature.</p><p>After room temperature storage, the product can be returned to refrigerated storage until the expiration date. Do not store Xyntha at room temperature and return it to refrigerated storage more than once.</p><p>DO NOT freeze.</p><p>DO NOT use after the expiration date (month and year) on the label, even if it has been stored properly.</p><p>Avoid exposure of the Xyntha vials to light.</p><p>Xyntha does not contain a preservative. Use the dissolved solution as soon as possible after mixing. If the solution is not used right away, it can be stored at room temperature and must be used within 3 hours.</p><p>DO NOT use Xyntha if the dissolved solution is not clear to slightly pearly and colorless.</p><p>Keep Xyntha (and needles) where young children cannot reach it.</p></div>"
        }
      },
      {
        "title" : "MORE INFORMATION",
        "code" : {
          "coding" : [{
            "system" : "https://www.jordan.gov.jo/",
            "code" : "100000155538"
          }],
          "text" : "MORE INFORMATION"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Last revised: April 2016</p><p></p><p><b>Marketing Authorisation Holder:</b></p><p>Pfizer Canada ULC.</p><p>17300 Trans-Canada Highway</p><p>Kirkland, Quebec</p><p>Canada, H9J 2M5</p><p></p><p><b>Manufactured, Packaged and Released By:</b></p><p>Wyeth Farma S.A,</p><p>Autovia Del Norte A-1, KM 23</p><p>Desvio Algete, KM 1,</p><p>28700 San Sebastian De Los Reyes</p><p>Madrid, Spain</p><table border=\"1\"><tbody><tr><td><p>THIS IS A MEDICAMENT</p><ul><li><p>Medicament is a product which affects your health and its consumption contrary to instructions is dangerous for you.</p></li><li><p>Follow strictly the doctor's prescription, the method of use and the instructions of the Pharmacist who sold the medicament.</p></li><li><p>The doctor and the Pharmacist are experts in medicines, their benefits and risks.</p></li><li><p>Do not by yourself interrupt the period of treatment prescribed.</p></li><li><p>Do not repeat the same prescription without consulting your doctor.</p></li></ul><p><b>Keep all medicaments out of reach and sight of children</b></p><p><b>Council of Arab Health Ministers</b></p><p><b>Union of Arabic Pharmacists</b></p></td></tr></tbody></table></div>"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/organizationwyeth",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "organizationwyeth",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_organizationwyeth\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization organizationwyeth</b></p><a name=\"organizationwyeth\"> </a><a name=\"hcorganizationwyeth\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/placeholder (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Manufactured, Packaged and Released By Wyeth Farma S.A</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Wyeth Farma S.A, Autovia Del Norte A-1, KM 23, Desvio Algete, KM 1, 28700 San Sebastian De Los Reyes, Madrid, Spain (work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "placeholder"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }],
        "text" : "Marketing authorisation holder"
      }],
      "name" : "Manufactured, Packaged and Released By Wyeth Farma S.A",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Wyeth Farma S.A, Autovia Del Norte A-1, KM 23, Desvio Algete, KM 1, 28700 San Sebastian De Los Reyes, Madrid, Spain ",
          "line" : ["Autovia Del Norte A-1"],
          "city" : "Madrid",
          "country" : "ES"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/organizationpfizercanada",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "organizationpfizercanada",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_organizationpfizercanada\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization organizationpfizercanada</b></p><a name=\"organizationpfizercanada\"> </a><a name=\"hcorganizationpfizercanada\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/placeholder (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Pfizer Canada ULC.</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Pfizer Canada ULC., 17300 Trans-Canada Highway, Kirkland, Quebec, Canada, H9J 2M5(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "placeholder"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }],
        "text" : "Marketing authorisation holder"
      }],
      "name" : "Pfizer Canada ULC.",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Pfizer Canada ULC., 17300 Trans-Canada Highway, Kirkland, Quebec, Canada, H9J 2M5",
          "line" : ["Trans-Canada Highway"],
          "city" : "Kirkland",
          "country" : "CA"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binarypfizerlogo",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binarypfizerlogo",
      "contentType" : "image/jpeg",
      "data" : "/9j/4AAQSkZJRgABAQAA3ADcAAD/4QCMRXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAADcAAAAAQAAANwAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAOWgAwAEAAAAAQAAAIkAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/AABEIAIkA5QMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAICAgICAgMCAgMFAwMDBQYFBQUFBggGBgYGBggKCAgICAgICgoKCgoKCgoMDAwMDAwODg4ODg8PDw8PDw8PDw//2wBDAQICAgQEBAcEBAcQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/3QAEAA//2gAMAwEAAhEDEQA/AP37xS0UUAFFFFABRRQaAGjrRnmkOOlIXUDnoKAb7ikHrRyen51xniLx/wCFvDMDTarfxoV42A7mz/ujJr588T/tKRjdD4YsN7A48yb7hHsAQa9nAZBi8V/Cg2fKZzxrl2AX7+qr9lqz6zZ1QEscfjXNar4y8M6KduqalDbP1w7gH8q/PzxD8VvHPiF2NzqDQQN/yyi4UfTv+tecyzTzsXnleXPOXYmvusB4aVZWeInb0PyjOPHSlC6wlK/mz7z1r9ofwNpcphgeW9YfxRJuT8815vqv7UbKxTStH8wdmeTb+mK+SjwOBgVA3Ix2r6zCeH2Ap/xE5H55mHjDmta/JJRXke73/wC0d47uifs6w245wNu7H48Vyl98bviLeqUlv0UH+4m0/mDXlLYNROe2c172G4VwFN+5TR8djOM8zxGlSszpr3x74wvGJk1a5T/cldf5NXMXni7xWuf+J1fdP+fmUf8As1V3PWsC9OM44Ne2sHStyqK+48P+0sS3rUf3svx/Enxzp7brXW7o45/eTSN/Nq6S0/aY+LmjqEg1KKRB/wA9Idx/MmvJLpuuDXM3ROSc1z4jJsNWXLVppo9TBZ7i6Mr06jT9T6j079tH4l2EqnULW2v0XqqqI8/iM161oP7e/h6TCeJ/D89ljqYGM35cLX5wXJBJ96wLk8nHUV8/i+Bstnp7O3ofeZX4j5tRt+9v6n7i+D/2nfg34zhR7bX4rGZzgQ3jCGU/8BJr3m2u7a7iSe2lWWKRQyspyGB6EV/NHNkHcp2MOcjg/nXa+DfjV8Tfh1dpceGNeuIIlILQu2+NwOx3ZOPpXxuZeGGl8NU+TP07J/Fxu0cVT+aP6MKTvX5j/Cn/AIKF6TeSRaT8WdPGmyuwUXlqCYAP9tSWfPrjiv0Y8N+K/D3i7TItX8OX8V/aSgFZInDDkZAOOQfY81+bZnkeJwkuWtC3n0P1jKeIsHjY3ozv5HS0h6U3d096d1FeSe4KKKKKYH//0P38opg4JxThyKAFopnTpTPf0oAm6VGx4zXN+I/FOieFbF7/AFm5WCNBnk5Y/QdTXx149+O+ta+ZLHw9mws848zPzuP6A17uT8O4jGytTWnfofGcUcc4HKo/vpXl0it/+AfTXi/4q+FfB6tFeXImu+0UZDNn39BXyl4t+Ovi7xBvttPP9m2xzxGcuQP9rgivF5HlmkMszl3JyzMcsc1H+tfsGTcDYTDLmn78vPb7j+auJvFnMMc3Gk/Zw7J6/foTXNxPeTNc3crTyPyXYlmJ+pqqxJGDxTz6VETnp0r7eFKMVaKsfmFSpOo3KTu/Mb+pq7p2j6rrMoh0mzkupP7qKSfrXffDL4b3nxA1Yxtuh023wZZB1J9FPr/Kvte9Phb4SeD5Lu3gSC3tlwBgbpH9OeSTXxnEHGKw1T6tRjzVH+B+mcI+HFTG0XjMXPkpLW9r3/FHxPbfBf4g3kPnLYeXnqshww/SuW1v4c+NdEVn1DSZhEnJkVdy/nXY6z8aviBrOrifTrtrNZGAjgjwV56A9Tmv0B0J7m70Wzk1NF+0SRKXGMjcRz1rxcz4qzLA8ksQotS6I+myDgPJs39pTwc5Jx6taP5f8E/JEnkjBBHHNV25r6s/aQ8A6boVxbeKdKjEP21ys6rwC56ED35zXyk7YJ/zzX3+RZrDHYeOIgrX6H5LxTw9UyzGzwdR6rr8rlaUnBrnL1+oNbly+FNcvevzXtxPnoLUw7thmubumzmty7fmubum5Jq/U9CmYty3JrBuTya2LhhzWBO3Ws5eZ62HRlTtwc1hXJ4Na87DJrCu24rJpXuexR2MG5IJOTx6GvSPhP8AHP4g/BTWk1HwhfstpuDTWUjEwSjvlOgPo2MivM7kgmsWUjJrnxeFpV48laN0ejl2Pq0KnPRlZn9Gn7Pv7SXg34+6CJdNcWWuWyA3dgzZaNu5Q9WT0OBX0mpPGa/lR8FeOPEnw58T2Xi7wpdtZ6hYuChBO1hnlGA6qe9f0Y/s6/HLRPjv8PrTxRp+IL6ECG+tictFMo5/Buo+uOtfgfF3Cf1Cbq0tYP8AA/pLg3i769BUa2k1+J9A0Ug6Clr4g+/P/9H9+jQeBx3pu7BIoZscngUtw21Y3OOa8d+JPxZ0jwTCbSIi51F1ykQP3fdvQelYXxa+LsXhVG0TRGWXU5FwSDkRA9z718R3Nze6pePPcyNPc3DfMWOSWboa/QuFuD5YhfWcTpBbLufiniF4mxwj+p4F3qPd9j6Z8N/DzVfjHpx8WeJ9YliaZ28qNUBRVBI4GcVut+zLpCcvrcqgf9M1HH517n8P9Fi0DwlpunRDG2JWOf7z/Mf1NeT/ALQ/iS60bRLLT7GcwS3cu7cp5wmCf51z4XN8bVxf1bCT5Yt2SXY68Zw3lmGytZhmFLnmldtt6tnOt+zPpjqDBr0mR/0yU/1rkde/Zz8QafB52jXi320cq42MfpjOTXkul/EXxno7iS01WfCnIVmyhP8AtDHIr7s+F3jN/G/hOHVrlAlwrNFIB0LLwSPQGvezevnGWJVJ1eaJ8hw3geHM9bw9Og6c7X3Pzp1TTdQ0i8k0/U4Ht7mI4ZGGCKp28Et3cx2tsheWVgqqOrE+lfcv7QHg601PwrL4hhixe6ftIZR95GOCD9Ac187/AAJ0D+3PHltcsu6GwUzA9gwIA/nX1WA4qjXy2eLlpKN9POyPgc48PpYTOqWXxd1KzT8rv/I+1fh54RtfB/hez0qIfvAoaVwMF3I5Jr5h/aZ8Syz6nY+GIXBihBmkH+30H6GvtQnYnPAFfmH8Ute/4SHx3q2o4xH5nlAenljZ/SvgOBaDxWZOvU1td/M/ZPFXEwy/JI4SjpzWj8jkdEv4tK1yw1O4G6KzuEkcdyFOT+dfp9oPjDw9rOkwanY3kbwMgJIbpx0/CvynY4wO46n1FAmmVCscjqvsxA+lfpXE3CUcx5GpWlH8j8S4H8QquTe0gocykfSP7RfxE0rxPeWegaJP58NiWaZ15QucYAPtzmvl9yCKkc56VUlcKpzXu5NlMMFhlQp9D5LiXiCrmmLli6ys328lb9DOvJAMiuWu5Mk1sXcvJrmrqTk17TSvdHj01szKunrm7qTqK17p+prnbhtxOKZ6FKNzMuH64rCnbrWrct1rCuGxmsZHr4eOhmTtwawbtuK1p24Nc/dPmsj1oKyMeZssTWPM2Ca0Zm6kdqyZWJJxVM1oIoyt2r6z/Yp+M938KvjNY6bczbNE8TEWd2GPyqx5jcDpuLBRn0r5JlJHNV7K7ksdSs9QhJV7aeKUEHoUcMP5V5GcYKGJw86T1ufW5Fi5YevCrF7H9diYKgjpinV578JdbuPE3ws8H+Irpt82qaRYXTt6tNAjk/ma9Cr+YK1NwnKD6Ox/U9GpzwjLuj//0v33P3ulePfFr4kQeCdHMFsQ+pXQKxIT93/aPsK9L1vVrbQ9LudVvG2xWys7H2Ffmd4y8VXni/xDdazeMTvYrGp6Kg6AV9pwZw79exHNP4I7/wCR+W+J/Gf9m4X2NL+JP8F3Ma7vLi/uZr29lMs8zbnY9WJ5/L0FdV8PtIOveMtK05ecyiQ+6xkMf0rhcjrnkcj2r6P/AGbdFivvEt5rUq82KBU9CZMg/pX7DxFiVhMBNrtZH8y8F4GWOzWlCo73d3+p9twxiOBIgMBRge2K+Df2g9bk1DxwLBZN8VlEAF7K5zu/pX3de3C2trNcMeI0ZvyGa/LTxRq41vxHqWp7932md2BzngngV+X+HeE9pjHVf2V+Z+/+NOYOll9PCQ+0/wAjFZgFB9ia/Qf4D6NLpHgC1M+N12zTj3V+R+lfJHw6+GOueMtTgaWB4NOVg8kzqQGUH7q5659q/RCwsrfTLKGytkEcMKBVA/hUDAFep4iZ1Smo4am7u+p894L8L1qVSePrxsrWX+ZwPxf1JNM+Hur3MihgUVMe7kL/AFryb9mPQZLfRb/W5l4u3Cxn/ZTIb9awf2kPHUdwIfBmmSCRsh7nHOP7q+xzzXvnwn0P+wfA2l2h+88QlP1k+b+tfNTjPC5PaejqS/BWPt6VSlj+JXOm7qjGzfnd/wCZ2Wvfbf7Hvf7OTfcmJ/LX1fBx+tfnzdfBL4lXVzNdSWILzOznnuxya+x/it8SY/hzpUF8Lb7XLcvsWMMFPGMnmvBF/aouGdVXQySxA/1g7nHpXTwrHMaFKVfB000+r8jj8QqmSYmvDDZjUalHZLzPJj8CfiOelgPzrE1/4SeNfDmlz61rFqsNrAA0jFjxk4HH1NfpZoV9PqmkWmo3MHkS3EauyH+EkdK+c/2oddWy8K2+iRuA+oSgMvfYvOfzFe3lPHGPxGMhh5W1dnofMcR+F2VYTLqmMi3otP0PkHwp4A8T+NkuJfD9v562pUSE8AFugH5V0k/wA+JzqQung/jWr8N/jbF8M9Fl02HSftcszl3k3hd3oMEds13b/thXKMsaeHWd2IAUSrkk8AAY6mvps1zHOY15fV6a5Fs2fDcPZPw5Uw0PrdWXtHul69DxKf8AZz+K8hJTTh+dY037NXxdfj+zRjuc1+oHgTXNc8ReHoNZ17Tv7KnuRuFuWDsqnpuIxyRzjtXBfHX4r6b8LfCFxeFwdTulaO0iz8xdhgNj0XOa+So8dZnUrKhFJybtsfpWJ8Lslo4R4ucpKNr6s/HDxNpF/wCHNXudE1QBbu0bbIFOQD1xWZofhbxJ4vv10/wzp82o3LDOyBck/ngcfWvZ/hP8KvEnx08Y3E1w7RWXmGa+u8dCxyUU/wB454HpX6u+HvCngL4M+EpP7Phh03T7GPfPM+NzBByztxljX2HEHGywijQguar17Hw3CXh28e5Ymb5KK2b6o/MLRf2KPjDrtit9dSWel+Zz5M7uJB9QqkD864zx3+x78ZvBtidSgtItciUEutiS7qB3IcL0r3L4kft5eIE1iW1+HGmwR2EBK+deKWMmP4lUFcA19z/Aj4hal8VPhlp3i/WLRbS7uS6SIo+UlDgso9G6ivmcdxHnOFjHFYhJRk9j7vLeE8ixlSWFw0m5RW/Q/nkvhLBJJBOhjdCVYMNrAjqCK9I8Bfs9/FH4raPJr/g3TDdWUUnl7ycZIzn8iK9r/by0HRvDnxoJ0WFIDqFgl1OqDAaYuy5+uAK/UP8AZV8Dx+BPgh4c01R+8u4ftjnuTc/vOfpuxXvZ1xhKjl9LEUl70/wPEyDgeGIzCthKsvdh2PxY8Zfsp/GjwT4evPFPiXTEs9Psl3SSF/yA9z0FcB8L/gJ8UPjNciLwTpEktorBZLuQFLeInszdfyBr9/P2gfBOhePPAjaT4wvhYeGraVLzUXLbS0VswkCZ9GwQR3r5K+Fn7bvwwl+IeifBrwR4ZbTvD0sps7a9MixxggEhzGVBAOMcnkmvEwnGmYV8NKVOneS3tskfSYzgfL8Nio06lTlj+LZ8D/Ev9hr46/DrQ5fEM9rba1bW6F5RpztI8SAZZmDqvAHXFfFMhYNtYEEHGCMHI4x+df13XXkeRL9qx5W0l933duOc57V/Kf4ksINX+LF9pWigyRXmsPDGB333G3j8/wAq9DhPimtjFNV0vdW6MuJuFKOClTVFvV9T+lr9nQMvwA+GwYYI8N6Tn/wEjr2WuM+HPh+Xwn8P/DXhec5k0jTbS0bHTMEKxn+VdnX41jJKVacl1b/M/a8JG1KCfZfkf//T/U/9pXxUbXTbXwxayFXvG3ybTyET+E+zZ/SvjPIJ44FetfHXVRqPxG1GMMWS2IiHsUJDfqK8eDdh0r+juDMvWHwEF1lqfw/4k53LGZpVd/di7L5E+QK+9v2d9BTTfBP2+Rf3l/IZAf8AYIGB/Ovgi3ja5uIoIxuaVgoA9zX6oeEdEh8OeHrHRbfmO0iVF9xivnPEzGOGHp0E/ib/AAt/mfdeB2VKpjquJa0ikvvv/kaOrXmmWdm51edIYG+UlzgYPavKxJ8FtKYzvJYKQckld2D+VeZftP635Vlpmgo+GlfziPVVBXH618bA7cYOPTHFeFwtwX9Zw6ryqON+x9Rx54lrA454aNGM+XrJN/qfohqHxv8AhroUPl6fdpcBRgJbr0/A4FeG+Nf2jtU1RJLHwtb/AGOFxjzpP9b74Xla+YCeSTkk0wv6DHr9K+0y7gDBUZ+0neT8z80zjxczPE03ShaEf7qa/VnUeGrS98TeLLC2ZmuLi6uEZyTlmUMC2c+1fqhaQLa2kVtEu1YkCj2AGBXwD+zloral8QRqDcpp0TM2eh3gqK/QWVxFEWPRRmvgfEXExlioUIbRX43f6WP13wWwThgKuLq7zk9fKyPhP9pvxA994kstAX7llF52R/ekyOfyrw/wJpS674y0nSWGVuJ13Y/2Ru/pV74n69/wkHjnVr6Nt0fnFEP+wvQV6p+zFoaaj4xvNUmj3pZwHYxH3ZCw/pmvvYWwOR9ny/iz8iqt5rxOovVOdvkj75jQRwqijAAAAr87/wBpnxHDqnjmPToSCNOh8t/Z2O7j8DX6GXNwltbSXErBUjUkk9ABX4+ePfELa74s1XVmIJnmbA65CHaD+lfDeG2C9pjJVpbRX5n6142Zg6WXwwkN5P8ABHLTSPI6xplpHIC4GST7D3r7f+An7P32DyfGnji3zdnD21s/IiU9C47t+YFUP2c/gokwi8f+K4cnIeygccDPIkIP/jtfS3xR+JehfC7wzLrOpyDzMFYIQfmlfsFHX6+gr2eLeK6mIq/2fgd3o2uvkfPeH3AFDCUFm2ZaJK6T/Nh8Tfih4Z+FnhyTWNanBfBWG3XHmSv2VRX46/ETx94o+KniptU1Ny9xcOIra3U5SMMcKig+569ad8RviN4h+I2vy6/r85JGRFGp+WFD0VR/M1lfDNI7r4leGYJfu/2hbHnof3gr3Mg4ZhlmGliZq9Szv5eh8/xTxtUznGQwdJ8tK9l5n7GfA/4fWPw8+H2m6RbxBLiaNZrhv4mlcbjn/dzj8K+dP2z5fiLrumaX4C8EaVPf21+zSXjQjkhMeWucjg85r7lhULGqDoBXwp8c/wBr2++FHju58F2/h77aYIo5FmaUKPnz2I9q/KcmniK+PdalDnle9mfvOeUcLhsrWHqzcIWSuv66nzH8K/2KviF4q1O1u/H0R0DR0YNLG+DcsB0VQMrg9Dk8Cv0317xL4A+BngNXv549O0rSIAkUQI3vsXAVR3Y471+YXib9vb4nX8LwaBY2mnBwRuZfMYe4II5r438d/ETx18QrltV8Xarc6m8Hyr5jkpFv6BR2zjpX3tfh7MMyrKeYSUILoj82wXE+W5VRlDLYOU39p/0jvtd8U6n+0R8f7LUL2PCatfxRxw9RHaq4yv8A3zk/U1/QbpWn2+kaZaaTZLsgs4UhjHokahQPyFfh9+wb4NTxR8bhrs3zR+HLZpyuMqzTBoxn6HkV+5kj+VE0j9FBP5Cvm+PqsI16eFpfDBH2HhrSlOhVxtX4pvc/Kb/go98Y7ywtdN+D+jTmL7ci3d8UOCY8/u147blOR3FfkFBeT2NzFeWcpgnt2DxupwVZeQQRXun7THjQ+Ofjf4s1xLg3FsLx4rck5CxJ0Ue2c18+ytX6lwtlMcNgYQtq9WfmPE2azxOPnO+idl8j6X8RftnftCeIvCDeDdR8SH7HInkzSRxRpNImMbS6qGH1BzXa/sD/AAhufiZ8a4PEt+u/SvCwN3OXBIllb5VXP94Fg1fGWl6Rqev6vaaHots11f3sqxQQoNzO7HAAxX9K/wCyx8DbL4D/AAssPDbbZNWvALm/mC7d87joR/srhfwr5ni3FUMvwzo4eKUp9j7HhHCV8fiFVrtuMe59LDoKWkHQUtfiZ+2n/9T6o+JLyD4h+JvMyT/aN3/3z5rVxe/jp2/KvYPj7pZ0r4j6hKibY7z96CejMxJY/ma8YIzznAr+psjxEauDpThtZfkfwDxNhqlDMa9OovtP8z1D4R6L/wAJB4+0y04dIW86Qf7K9c/ia/Tj7icHkV+U3gvxtqvgXU31fSFjaeSMxnzF3YBIP9K9UP7SvxBYEFbbbj/nnz/OvgOMeGcdjsSqlKPu20P17w143yzKcDKnXb55O7t+Bk/HrXm1b4gXUAffFYosaY6DIBb9a8V39R61Yv7+41K9n1C6bdNcOzsfdjmqWRX6Hk+BeGw0KPZH43xFmbxmMq4hv4mSl6jLetMLDpTSzYwOSSB+dejUfLHmZ41OPNJJH3N+y7obwaBfa3MmGuZiiE/xIADn86968ea6nhvwlqmsydLaFm/HpWX8K9Ek8O+BdK02dQsiQgsPduf5GvLv2m/EI0vwSmlxN+8vpVUr6pg5/XFfzhV5sdm2mt5fgj+08Oo5Tw3ro1H8WfAUszSySStyWYsc+5r75/Zi0M2PguTWSpDalIWB7kIdn9K/PWWcBSM+texaJ+0f428K6PBoujxWqW9su1FMWfqSc1+wcY5PiMThI4fCr1P5z8OOIcHgsyljcc3s7W7n3X8Z/Edv4a+HWsXkz7GlheBD/wBNJAQo/Ovzq+CfgxfiH4/t7K7BNpbf6TceuAeB+LYzUPxC+PHjP4haL/YWtiBbXzFkIiTaSUOQc5Ncd4A+LXiL4Y3d3e+Ho4ZJbtAjNMu44BzxyK8fJeGcXhMuq04r97L8j6zibjLA5jnFGtNv2MPzP2bt4IraFIIFCRxqFVQMAAcAAV8yfFr9nN/i14iXWNT8RXFtDCu2G3RUKIO5GR196+Spf2yvion8Fl6/6n9PvVnS/tqfFpD8sVkP+2Of/Zq+QwfBmb4ep7Wkkpdz9HzDxDyHF0vq9Ztx7W/4J7VL+wnpD5P/AAk91/37j/wr5v8AjP8ACvSf2cfEHhnVtP1ebVb37StwYpFVQqQEOPu4PzEEVsSftufF1f8AlnY/9+P/ALKvnD4r/FnxP8Wtei8QeJ/KE8EKwIsK7F2qSckZPPNfYZNlecOty42X7uzv5nwue5nkCoc2WwtUTVj9zvh5420nx/4Q07xLpEyyxXcSlgpztfGGU+mDkc18y/tMfssv8Y7uHxV4ZvI7HXYIxE4mz5U0a/dBKgkEc4x681+Y/wAM/jn4/wDhDeNP4SvcWszAy2ko3wP77cj5sd6+w7T/AIKLeVAi6h4OZ5gvzMl0ACfYbDXy1fhLMcDifbYNXXS36n3OE41yzMsGqGP0fU4Hwr+wD8RdUvx/wluq2unWCt85h3NKR/sgjb+dez/tB/Cr4J/Br9nTU/C8fk22oyqj28shzc3N4gOxj1IySeOFrxfxz/wUR8ZahZtbeC9Bh0eY8ebcOLnr6KAmDXwB488f+LfiHrMmveMdUl1K7fgNISVQf3VU9B7V9JgsqzfF1oVsZLljF3stD5vH5tkuEozo4KHNKStd62P1i/4Jx+CbbT/AGseOJ48X2qXRgVvW3jVWH/jxNfZvxt8XjwJ8KPFHircEOn2cjoT3Y8AD86/En4d/tq/FX4W+ENP8FeFrbT1sdNTYpkt9zvkk5Y7hk81gfFv9sn4tfF/whL4L8Sm0hsJ5FeT7ND5buAD8pO48HPNeLjeDsfiMweImlyOX4I+kyrjPAYbLVhqbfOk/vZ8mXMzTTyzSH5pHLEk5JJOazZCzyCJVJZjgAclieAB71ZWOaeWO1to2lnlYIiIMl2bgAL3JNfr3+xx+xAdNktPil8YbJXuMCSx0yVcrGe0kqnvjopHvX3+dZ5QwNG8nr0R8PkeSV8dWtGOnVnQ/sIfslnwfawfGH4h2Y/tm8QNptvIObaJhnzGB/iYYxnkYr9TF5OajWPaAqgBV6CpADiv56zLM6mKqurUep/ROVZXTwtJUqa0H0UCivPPTP//V/Vr9pPwTLrWgReJbGLzLjSyxfHURNyx98Yr4JDY/r9a/Yu7tobyCS2uEDxSAqykZBB9q/Nv40/C278A6xJqNlGz6NdMSjgcRM38LH+Rr9g8POIoKP1Ks7fy/5H82+MnBMpT/ALRw8f8AF/meM7qXeRVPzkBKk80eavqK/YT+bupbL5603cKqtMo71EblR3pBdl0tXTeCdMbXPF2k6Sqlxc3Eav7LnrXCPd9819F/svaTJq/j+TUmTfBYQNuPZXbG38eDXi8RY72GCqVOy/E+p4Nyt4vMqNFLd6n6M2sQgtY4uoRAPyFfnr+1V4pjvfF9poUJ/wCQbFmQZ4Jlww/IV+hk0iwwPNIdqoCSfQCvxt+K/ihvEnxA1vVFOV89ol91iJQfoK/HfDrBOrjnWe0V+Z/SXjJmHscshhYv43+RyE12MdayZbjIOTVSW5GODWZLcdea/oA/lGnT1LM849ayZ7jHU1BNc+9ZM1xk9aTZ1U6ZLPP6GsqaY4pss+PxrLmn4rNs7adEWabFZE8uc06ac461lTTcdalyPUpURk0prIuJiM81LPNjvWHczc8VNurOu1kQ3MxJ61lStzyalmcHJJ4/rWczPLIkMQ3yyYVVUZLE9APelKoo6vRG+HouTstyGaSt3wf4G8YfEXXIfDvgvTJdUvrggBYh8q9ssxwAB7mvsj4F/sI/Ej4mSwa544R/DGg7wSsykXUy8E7YzgqpHRs1+ynwq+C3w++DejJo3gjTEtuMSTthp5f9+TGTX59xBx5Qw14Yf3p/gj9U4a4Ar4lKdZcsfxZ8s/sw/sQ+G/hD5Hi/xwItb8VEZQkZgttw5CKw5PuQcdq+/VUIMKMY9OlPUZGKXA/KvxTMcyrYqo6laV2z90yzKqOEpqnRjZIdRRRXCeiFFFFAH//W/fboSfU1lazomna7p82mapCs9vMpUo4yMGtcjr70EeozVQqOL93RmVahGrBwmrp7n5ufFv8AZ81zwfNNrHhRGv8ASTl/KXmWHPJB9VHbHNfML3ZRij5Vh2PB/LtX7fsu7g4KnsRXz38Rf2cvBHjgNeWqHStRPSaBQFJ7lkGAx96/VOHfESVNKljVddz8A4x8GY1ZPEZc7XveL/Q/L83Y5OeBUL3ffPWvY/G/7OXxL8HmS4trM6vaIx2vbZeTb6smOPzr5/vBd2U7217C0EinDI67WB+lfrWBzjC4lc1GaZ+C5lw1i8HJxxFNpmrJdnlc9P5etfon+yBoTW3g6+8QOMHUZyoz1IiyAf1r8yTK8reXGcySEKv1PAFftN8HNC/4R74c6DYGPypPssTyL/tuoLfrXw3iXjowwkaKfxM/UvBbKPaY94hrSK/EvfFTxHb+GPh9res3TbVit3QEf35BtX9TX4mXF+88j3Eh/eSHefqea/Sr9s/xYNI+Htt4dAy+szhceghw+T+VfllLcgnBbOev4VPhhgFHCzrPdv8ABWNvGvMva4+GHW0Yr77s0JLkCs2W6qk9wTyaoyT461+muaPx6NG+xalnzzWdNOBVeWfIrOlnzUK3c7KdEnmnzWZLN2zTJZunNZ002DUSa3uejSw99h8svFZM8+Pl71ct7a+1O4FpptvJdzN0SJSST9BXtngv9lL46+PiXsPD76ZEf+WmoZgRh7HBzXnYrNcNRV6tRI93CZPiazUaNNt+R83T3AOQDnHX2qpZ2moaxdrY6VbS3lw/AjhQyNn6KCa/WT4f/wDBOLSRHBefEvXpLlzgyWlr8ij2EwOT9dtfd3gD4GfC34ZRQ/8ACIaBbWtxCuwXJjVrgj3lI3EmviMz8SMNTTjQTk/wP0HJ/C7GVmpYm0Y/ifjZ8KP2F/i58RWg1HxCieGdKkIYtccyyR99irkg/wC8BX6m/B/9kf4Q/B9EudN04arqw6312A8n0C/cGP8Adr6gC9wM07Br8yzfi/GYz3ZStHstD9eyXgnBYJJqN5LqxqqFUBRgDpjpinbSetHQc08V8yfXLYaAR3pSM0tFIAooooAKKKKAP//X/fo5owadRSauAhGaTGadRRYCJow4IYAg+tcT4k+G3grxbCYfEGjwXg7ZXB/MYNd3RW9LETg7wdjmr4OlVXLUimvM+TdT/Y/+GlzrVtrGltcab9nlSXyImBiYoQwyGBPb1r6rSIRIsaDCqMDFT0V0YzMq+IUVWm5W2uceW5HhMG5PDU1Hm3sfDP7UnwY+InxS8Q6bN4ZWN7Gyt8EOWz5pZs4wCOmK+S5v2SPjSmQNPjk+jN/8TX7NUV9LlXHGLwdFUaaVl3Pj868M8Bj8RLE1pS5n2a/yPxVf9kr43twNKT/vtv8A4mq//DIfxwdjnS4x/wADb/4mv2yor1P+Im4+1uWP3P8AzPKj4OZYnfnn96/yPxVT9jH41TEboIIh7lz/AOy11mmfsD/E2/Aa91uxsh3DRys34YAr9fqK46/iHmE1ZNL0O/D+FWV03qm/Vn5n6N/wTx0whf8AhI/E07n+L7KAv5b1Ne5+Ff2Jvgd4ciC32mPrkn9+8bJ/8c2ivr2ivDxPE+Oq6Tqs+jwnBmW0fhoo4fw58OvBPhG2Fn4e0W2s4l6BIwT+bZP612iRqg2qAoHYVJRXiVK05u8nc+io4enTVoRSGgYNGD6U6ioNhoHel5paKQCHNLRRQAUUUUAFFFFABRRRQB//2Q=="
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage003",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage003",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAFYAAABXCAYAAACeCrJSAAAAAXNSR0IArs4c6QAAAHhlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAACQAAAAAQAAAJAAAAABAAKgAgAEAAAAAQAAAFagAwAEAAAAAQAAAFcAAAAAgR//HwAAAAlwSFlzAAAWJQAAFiUBSVIk8AAADjBJREFUeAHtnHewFMUTxxtFEQMoIhjBBCoI5lhYIkZQQQyIomAZ+UPFVIqhygSCOVSZCApGFDCAlFqCgrlEy4wkFcWcFXOaX3/6517tu9u9u72bvb33tKveu7vZ2dnZ3pmeb3d/Z5uJiNO//8SzBprT3muvvSYdO3b03PS/t7nnn39eTLEodfXVV//3asLzna+//vqynOc2/2vuHw38p9iUhkJmil2wYEFKt1QfzWam2EceeUT23HPP+tBCCr3ITLG///67PPnkk3LxxRfL33//ncKtZdtkZor96quv7M4vuugimTJlijjXtOB0ZooNj6eBAwcKCm5KUheKZbReeeWVcttttzUZ3Wam2L/++quBErGzo0ePblDWmH+Y55XFDXzxxRcNLjtv3jzZeOONG5Q15h+ZjdjTTjtNPv30U/njjz9krbXWknvvvbeoHm+//XZp3769rLLKKrL//vvLjz/+WLR+1gczU+yOO+4oa6+9tjRv3lwOPPBAeeyxx2J1cd1118nVV18tY8eOlY8++kiAagMGDIitXy8H3LfffqvrR3aydOlS16xZM7d48eKCTqjtdWussYZ79NFHc8eWLVvmdOS6Tz75JFdWT19ef/11l9mIDY8qokH77bdfJCpgtJ566ql2PDhn1VVXlZkzZ0rXrl0lfxEM6tTDZ+YjltGmtjZy0KkS3Ycfflhw7M8//3SdO3d28+fPLziWdUHdjFhGF7Y2X3799VdbpFq1apV/SJZffnm54oor5PTTT69Lr60uTEGB1v4p+Omnn+xby5YtI6tMmDBB1PbKnXfeGXk8y8K6VOwDDzxgSGG77bYz3ay44ooFOkKZL7/8snz99dcydepUg2yPP/54Qb2sCgrnX417ApadPXu2LFy4UH755RdhdKrtlOuvv14UKZjTANZdYYUVGvQM8/DMM89ImzZt5OGHH5b77rtP+vTpI6NGjZKzzz67Qd2sfmSyeD3xxBNO47Fut912czrinNpTW3N0lbf+AME06kXIy3333XdlrUcvvviia926tbvmmmucOhBlnZNGJRYvHmYmih0+fLhToJ+7r6eeesqddNJJTkeiO+igg9z999/vwKua5HTqFOTqlfry888/u5133tmts8467oMPPihVPZXjKLbZP4qteZa2V69etprjzq655pqiI42H3EC+/PJL+w1ePeOMMxocK/YDbIt5wTsbOnSoXHLJJYYiip3j89gbb7zx//S3z0bLbQt3tkuXLtKuXbvYU1D4pptuKscdd5yccMIJstpqq8XWDR8AipH2YXHbe++9jTNx4oknhquk/j1TVBAHo8J3jTKJelUSUtxoo41E3WQ5//zzDTmE2037e6aKLffm5syZY6s+ObJKZOTIkXL88cdXcmrF52QGtzbccEN56aWXhFEVJ998840ccsghFioEQg0ePNiiW3H148oxA++8844MGzbMYFxcPZ/lmS1e3MRhhx1m4cKoAPdnn30mK620kujKnrvffv36yRZbbCGXXXaZLLdcssmmCEPatm1r7WHf0xQWLyQTuHXrrbc6tZ9OR1Mk5DnnnHOcxg8MdgUVfvvtN8O1GpsNihJ96mLmOnTokOicSiqnhmPVi3L77LOPU5fUbbvttk5Xf9etWze3ww47uB49eji1d4ZP77nnHqcpmsi+E9EiBsuDDzsIah7cJpts4oYMGRJ5XqlC+nPeeeeVqlbV8VRwLBhygw02MGyKHWXKMvUUuAu4lJQKWYDNNttMZsyYYVMm7h8JxhYtWogGtEUBf64atFPc1/fee8/MRe5AGV/efPNN6du3rzz33HOy7rrrlnFG8iqpmIKbb77ZqTLMa4p77Ndee61TH99ttdVWsX/6UFww9fG8Jk2a5DSWkGtSYwlOc1+530m+jBgxwqlSk5ySqK53U6Arr1NwHjm9deFxixYtsg6i2COPPLJoZ5XA0UCxmny0B6YruwXFv//+e7sWbm9SIUiOqdIEZdJTy6qPYpMtrSVmxSmnnCL77ruvrb75Vcmu6giVyZMn5x8q+Rtzog9D3n//fQuIgyJI19x4443CNZMKnpnad/PmgHRpiRdUoLFQG0HhhSb/8SoOdRr+c+eee26iEZufNCQy1qlTJ1sAVSkV93+vvfZy+nDyu1n1b6+mgPAfq38pYYqjjCSmIF+xwTU0lmvmYfr06UFR4k9yasAwn+LNFKiS5Nlnny0LtF944YXGDyBLQIC6GgFt9OzZ00gflbZzyy23yDHHHFPp6bHnVW1jgU+wWFDUkiVLRFfv2IsFBziH4AoRKyBTpQK0AzYpRq60CRk0aJCQfoen61sqtlFMH6YpSAC54YYbzFtSd9R+R/1jFdeolgNB6EJndjIc8A7OCaOCOFNAW0C7uNR50Fapz7vuussp9i5VrezjXkwBBGKN+NvDPvnkk+WOO+6wEXDBBRdEDgAcA5J/m2++uRGOqaQPJLJuqUKC2WeddVZk6rzUueHj9D8gQofLq/letSmAJbj11ltbH0j+HXHEEfLqq68aqwXPCy8pLDBYYL0gMFqYysRL4WMlFRKIBxxwQNLTCuoDBclo+NxwUrVi6RQ2MyxbbrmlaGJPFBIJ5Dd26gX7DIhO8QACIYuggF2IZiUVbDr20Yeg2FmzZvloKtdGVTYWewIejBPlXhm8ioticZ7yBiz5p8DfBX8Q4QKXNs7G4hb/8MMPcZdOVP7000/HRtoSNaSVveBYXEt9REVvELxJdItFi8gWDMJAcBbIzLKAkfoO/5VSrG5VdVzfh8B0VBPloylTbNWmAOIEkX3wKcHkKAFvzp07V2AOYmPXW289Ofjggy3RB8ECMgawRz0qw8K4sOUEsjEjED58CNwxTJIvqVqxdGTixIkSbIjjRmGu5AvhP1Ik+PuwXFCcxlWFEBsrMtlYjbGakiG6oXCNlFkzZBKihPDfgw8+GHUocZlyhC3UmfjEIidUZWODucO0BQ+CackMaNwzOFT2J3gUm6lQzRE21D479azMPEQ1QlxC0+dRhxKX+baxXkYsDw3i2iuvvCK66Mjhhx9ugWhGZD7cKvKADY/ikV166aXy7rvvitKMjMcFyiBAnS8gEhiJPmASm03CwfT8ayX97U2xl19+uQF/sgTsFVBCsBx66KFmRwnv6SKTqG+YCqCU5saM2KGUpILzsYtHHXWU2eaCgwkL6B+Dwqd4MQVAH/hW+cL0xnUlXIibGs4C5Nct9nunnXZyGo+IrKJ2O7I8SaFSkZzOuCSnxNb1AreC1vG1gUpxQtKQzCskNzIIRPGTyPjx450ucElOSVR39913rzrmEFzQS6yAqcOK2r1796IQCfIbNCG2HUEQ3mOPPUSVZeeWM/00bW32tJy6ldTBhkfR9Stpi3O82FjsYbkYUKe00dsJGV511VVmR2GogHNZQNh3ECUsglGMxKi6SctwtyE9+xYvNlaxpvv444+D2ZDoU7lZTlkxBq/05ow8fPTRRzvFuNYOPFe8trT4rm+//baFO+Es+BCvNlY5VoY9i+W8SnUau8vNweYm3aKowJE6ARvHLVyl2izn+N13322LK4PDx2ZCr4ol6MyoU36UAfyovVnl3GS4DjEF9nHBqMGPrzagHW47/B3K0q677ur69+/v1EQ5WOHViFfFBh1h1GkswKYWUS8U7kP0ZRFOHQcfTRW0oe6zA3Ugyn506lI3CBQVnFCiIBXFskmDKaXJRffQQw/ZNIaxUil+De4BJgzRrLQF13yXXXYx97zSa6FY7/xY7ZjwR+QJTwZCBEEaSBbbb7+9qD0rm/IeXqVxmUkepi1cB4JzXOCn3Ot7gVvhiymNyDZSBO4hYUXYKuS5dGEz3586SZVE1GzllVcOXyq179UqlY55H7FvvfWWEDTJF51eohEkG83kwgieqLcjSusUCMWUFbuhm266yWK++e3W62/viuVGiwWpicsy+jTdYoFx8kwwtNUuWZSK42z6YEoG7RDYIZAOMaQxiRfsFhh64BEvdagEbAOvcDJU2U7tssVaYX7X49b54H6jPlNZvFikiKlCH4K6A+EYd5eycHY2auRxHDJwQAhmryxZXrgIjVG8jlieoHINDGbBZVUKkcEvXtoQfv1I1JMOl8FdJRLWGCUVHBsoQnNROeWCYZneGvg2LKoEjVjHgT2122yzje1XYC9DYxQUC3OCEZvKXlp1EGw/K+8uhLHCYkQmFvoR+xDY68p+BQgfpFfY90WkiaSixm5t/0FjNAEkSFNVLErhIlCQxo0bJ8cee2xOT6TKUTzogHAgEA3WYFqhwdyFa/ClJorlPsh/6VZ388agGzV1QbHePa8opcEsZHQy5TUwE8k7iDqvMZfVRLEoqGfPnsaCwRHQxUk+//zzxqy3kn2vmWLpCe8mYNFCcGGhHDVVqaliUSIuK/kr6EO4srw9I1B2U1JyzRWL8siG4pW98MILFhcgxMhLeUkmNiXx7nklBfVE7/U1JZZ3gk+ri1xRjkLS9mtdP1XPK+nNkM8iAKO214jIbJAjAFOp6E4eR5IwC0nd86p0WhPAmTZtmqEIVbj07t1bdDu84WCcDZyIIKTINeAEgDJAHLzmhKA68V48PF4AXGsBxyKZm4K4UUUYkVGnES6nbzs2bgH9JSUOQxxakyrZ+AgBfRSOmL5KKjYWEXctn+V1O2LtcRf5pwQLYbcOoxbYBv0IChOyRDd8sIFEt87LmWeeWaSV9A7VzKVN7xaiW1ZOg73sgVjumDFjoiulWFozlzbFe4hsmhGMneUNHrwGlYhZrSUTHFuLm4RNzsvMYJdX8o6EavvYZBWLYkhK4nSwcaTW0qQVizJJqQcv+K2lci39TYzU19bJWna+Xq/Fyyr/B7l3A0stWZEXAAAAAElFTkSuQmCC"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage004",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage004",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAHMAAAB+CAAAAAAytnHkAAAABGdBTUEAALGOfPtRkwAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAAAniSURBVGhD7Zt7UFTXGcC/e3cXkDcqC6gQQEKiJgqiUZI2AhmqjjomGixosFoz0fhupFXbJGCjiWNE40SMo+YlUzU1nWqqrVVDkqJQFQMDGh9RF5WgCPJehH3c23MfC/dx7nLv7joZp5w/lrvn8f3O951zvvOdexZ9IkgTYYqlZJmezNCX+4dJ5LXbm5UJhmtkFN1LB4jrcU46Xdeuh5f2SkSsfHaWstCMIV/071Vnr6tOqswt1INNWr7/HeUWCVmreyUCBMnrtC1xqGYDvay40StAUezWJDVIs79cwMl+PXly5pGZisj7b7Wr0BIaw+W1Tj/vjHlwraLc9ONqkNDhI69W/Joz5vF/KAk+7fusKmbDIHm1qngnzHO/UJS7aJ8qJPw0RFavXtgN2Xge/rWS4LLAp7ki+/wib0wlS8IBPzabtMtKy8cLsmTMok+VmGvf50uez2Pn/fn/IudgsNEkeC9gSyqSK9m/1TEyEcWCKSRfK3eiFZi117jRPL7nl+nsw96YOO+S0sWwZW4ex0wYsvD1BEZPuaMqLnCmJ6XktjpYH/lgzOQlE7j29pSgg1Ny98C3kM8L3Hd56aqXsF0uH+6MGdEQiVd06DUmf9WWFMdY+qS3xu+qC/T9gP6BbxE8ujgGy2z3JZwxR36vwCQYA9BHd1yL5KGbN6d+w0h6d8yveIGdt+InlCZjulwhnELy8Uwpmq4woN52HWxcD36mOMfEs3axeIfHpqr7w/rsb4GQjedZ0QKUzdtpS7c5YW7/CUKaTLE6XBXaZA+GyAd1YVEl0mI005gJQJBsgYwZMP3LlxWgALuXAPj4dJliMFC62uLnBbDxzwWUrPTU5yxrxt/wTFifpMBEJltXgxoNum798THBNsH10Gay0Yz/Sc0uCL0n6bSt05fJIfmJJN9XBs//wyasoq3ex9hJ6dO/mb4RFC5qSdU1ERDKZq0uSJLuPkWTRALlTHgvet7wpgr/sXLwsio2L6LNTra1+IcEdrJfLVRbcxtBgCGU/bos+oI0TCjinIgjYZjw+RjdwGd+K0W2Bl8exW9SQ6oJIDs6anbWeOloewZxGxEBovkWk8tvStr+i51CTpkTBt7CGLdy7OLPrDp25vlG3maXQ0hXF/o0UBRNAxHLd9+e94rUlbWIwzycnlCHQUJZUG3UXb5xAOfKsvbqEfvjeN4Zcq3uh7UOvj4UJ4FC05pJWKZ8L0I1/3njr9AYRuUcNnQvectTjQ+ocILklh0AYXsnCxqNq2eW4ph24OMkLBO75EuGjW6iiZkZW4Qq7FxURY/syaBm9XuRbpoReOwVjJ52YFeMgp44w/xgzoUGAi5niQo7xaEq+VHWi0RDSI5w55ILw+qJYx6OmNpuRRMGV9aTF/gAwGpe/XaLKMS1iQ2HZQo3Hoe8LzYgNQUTcvuulcxystmQhJJ1mfN7uETDY3MOLBT27R5LMTg6jGViDiQ3quZ3mR3OCwmo31+ZkBEAxO37aCpnlE+byjkENrVb354kYiIdLD79QmDnwfDkrerHM28dNDimJyOXGgBRHYjZhYxJDTJGci6JS2RDfMD5JEEGYnpN+6oD2ttvMucSlePZUWilmoXMbom4cWiK2PQut4WwiQ5GHyu/Yh7DGC+ocjxzV+vvYZFIokAh/pG4PzHz8pPd+ZeeQI+pQS3o809MprrxbN5shka5bJSjax6FyW8csO7lC935VewKXroBfSxTZMo2x8VzfVsoAuhAqfwAs2meJE9nIcHavnTFzG7rfj2ZqbIcMTlfj9XT2CoWfmr/Tagn6BCjDiTDF96FfKjA6OjxcXNjK9kQvXTf6x/xvTnwIfNgHHcG1igzo2qE4SjYp06KMncNDGVkm3OZY7bl97y4+DvosLoNFZBsFEVeQivHz8/e2ND5xyr7yELW7icSuEBx+ZwULqTE6hlzS8Sc3pIH1HBOw3PjVqFJ47M5k4PGnPX6gPCiwbCHPXOay84yf3ShobYIe455niUzccStKfw2NXvOm1wjLDPtkDCYePNozjhwnL2D9a+ypuTlkG2WlQCfgHUhyyy7wuuP5J6IuV5+4/jR94xXQvjM3BecMDMX7HS0BfhswxTH4YjJbBUvGRqFDoxHRK4YpaTZPe18To6vjF3U8x0gj/+CX5+/W9Ed5G5fFn9E0PDOMKEUgNui/ZqNURxpxBuv7RJXdsaEDc8s4jS9mq03VggbnhSHU2AVn/vSSgRH8Xkn9ot3PiGzWegt2YJjef1XpFnP77u7861zotVahKJqYUoVn24m/lt4/P/L6ETeG1HCEWFtqx/r96TEhZGTL1cShuHxn0481FMSOQOKU7lDWIseDFvQxCLL0HjaQXfmBptNnlwHh3rCvlm/sTC5TS2mYEFHWab/j6OWG7GmB6JD0Bm6RPdCEV9vzJn0WlYgStlno3fw1cLKLBGCdwfpQPYD/7QLQiS/VnzKc2jDf1Ka7sZKyMTJSaLq0B01dh7tqdp0xLv74MVuH4JUUzzMVjhYlMXPW98dAKfPGNmjjCiVlvf2RhFvn+7c0N2yiE6wVp57DtM8GXeE7QXTW7HKPbs3MZrK+5iazKWp8iNj2wvMWzdpop8QuXsnmrui56SaMZgIkyisLZfFS1iyC8zl4RnYw2Jy3YRyVePqArNwm2wbYlH0oPY7EWqgLjBprJYIZjfWPzSmGl2c1XFBT3eRas9IbnOEAvr09Kg5cXHCwwNgJLswnqLAWSiS6MJcWnmGOawec9fIiCarBRdUnvXxBxPmx+F8fF2ByrstF2w75MqaRQOGSnezjotJ3/S8QnA6P1xgwoDde6Z/LJV68akFKpGu+SFKfiGNDoSqA2FX9GyT3rpzOl9tchxue1l5LjA3oTtt+aKww7ZtiV9Kzx4eihNy8kfkp8vfT40oufbd3qdrFZaRe37oVH7a17jeG5KTs19NXuN4P+PR/XMjKN53w/jH//5QmMWJ/BtunCZxWBNIa2qeQ63RTsxG495yyuprZVKgLob16HjC92uxt8/kVNzx1UNrpXkGc3kkS6XfPUSmL+byDvWgVV0Mz/RV63h6IqDQylTtyD24Z+uw91ratNeqJ/wcTO6lqVtJq56UBwZUK9MtBfnGfUxPWBEv41GwrQemrWZ/+3/jhzwwtR6FOQSOuwY39NWqpyd+9ayV6YZ63U21Mn+W9am1kxjDaBah8IsBLTbXzNQiXKGuZqaqE4nzjmll0tggXpvympnaxHvovOI+VKueol9dCPEa4l7tTNMIrF8wL1dtAO3M2bJXYKphLseasv/J0IpEscmlfC17BQUXlevrTPatvXWJvISYFRXaOnr+vLP6b6gQpjepqOThKvpoDwtUIU77vFUhtJcqfUz3bagkoc+2fbZ11wL/A86InCVEI/tdAAAAAElFTkSuQmCC"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage006",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage006",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAIwAAACBCAYAAAASXlLgAAAAAXNSR0IArs4c6QAAAHhlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAACQAAAAAQAAAJAAAAABAAKgAgAEAAAAAQAAAIygAwAEAAAAAQAAAIEAAAAARR2d3gAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAE4BJREFUeAHtnXmsFEUexwsQBAQPCEZUVNxgXAU8E+VQwKwR8Q4SBbMR/1KMRjExohDFK4igaNZo1HXxBHYRlEtENOIJLrsiKkoQRDxAF4iAiopI7+9Tvl+np9/0TM97M/Vez9Qv6ddXdXXNr77vd1ZVtwiEjCfPgRQcaCHUMkU5X8RzIOSAB0zICn+QhgMeMGm45MuEHPCACVnhD9JwwAMmDZd8mZADHjAhK/xBGg54wKThki8TcsADJmSFP0jDAQ+YNFzyZUIOeMCErPAHaTjgAZOGS75MyAEPmJAV/iANB/ZKU6gcZTZs2GCOOOKIclTl60jgwLZt28x+++2XcLc8l50Bhubuvffe5qCDDipPy6ugFv6JWrVqZQ499NBG/Zpvv/3W/Prrr42qI+3DTgFz6qmnmiVLlqRtW1WXAyzdu3c38OTtt99u1G8dOHCgeeONNxpVR9qHvQ2TllNlLEfnop6HDBnSaLCUsVmpqnIqYVK1qIoLPfDAA2b79u2GMWu33XabGT9+fEm/FrVzzz33WDvl+uuvL+nZchX2gCkXJ4vUA1gAyKhRo8yECROKlK5/m2dlwJu9gXHLudIXX3yhh5XfM0TTBcmPCgYMGODiVc3uHdddd10gBn8wY8aMYPfu3SW175xzzrF8EyQEb731ln32l19+CcQWtNvxxx/PEFu7CZBKqrvUwhaNpT7U0PK1DBj+UcSwLQks/fr1Cw4//PDgo48+CgER5f3SpUvt/RdeeCEQw9kZYLzRW2EhjipatmyZdZ1xoYsR5TGIJ0+ebD2f4cOH20fiagd75qKLLjJnn322DVcUq7dc970NUy5OJtSDvTFr1ixz2GGHJZQw5ssvvzS9e/e29zFmV65cafbdd19z3HHHmY8//thEA3Jatk+fPkakixk6dKhTT8sDJrEbG3/j9ttvt4aq2CGJlWkEXNRWvRjVjh07csBCJaKWzP77728WLlxo6/zxxx/N77//nlh/uW94lVSAo/w345mwnXbaaYbOSUt0Ip1LdDuJcLEBCuWiAU3eI/aLVUnRUL+WV/WEWmrXrp2NFie9o9zXPWASOErn0GlKRGOxF9KG4DV6O2bMGK2i3p53oHqiJB6QfQ9gLUbEZKi/f//+xYqW7b4HTB5W0lmI/TgBAjqpGCFdvv/++7x16LOoonPPPdd8+OGHeskG9W6++Wazdu1ap1IjbECKAw+YGJMAxbHHHhu7+scp6iEqdfIVAizz5s2zKiYpGqupgShYqAsP6cUXX7T2Sb6EpLjSNvdEWaQTqiyqsrheafJGb4TDuL+onXy2Ch0zcuRIu0UeyTkELIsXLzYSoLNbzs3ICclCbJcoKQBIGUgwLnrLHgOySy+91BrBXPjggw/s9Xxl7Y0K/fGAEcY++eSTBhXBf3gSWLgHYArRnXfeadq2bVsQLKi0aB4JoFA30gIgscUJb4tUQENSCvG6Gn0uDXVCzSnSu2nTpoBwPTR16tRApEcYTRWG5hx36NAhIKqahqgniS655JJApEog7nBY5IcffrBRWhkjFKxYsSK8zgHvvPDCC+0ztEm8qPA+7RfwBuvXr7fXqJcyPjUQsqi8B4CXzoXRElXNAUgUMHSS5m/StCAJMNFc0uDBg8OqOOYdSYDkOvfjYCEVQNuVOPaAUW5UYA9gosDId0yZUom8jxjFAXkgaMqUKfacxOMJJ5wQIBlE9dlrlEsCWNJ7eQaw0DbqUvKAUU5UYI/YlthHQcDQqQ0l6gc4gEHsGfue+fPnBzK6LjjjjDMCsZGs6ihFIlAXG3WLzVOvaS4BU5NuNSH3JML4LZT3SXpOr0vHWrecehhrS2AN72bu3LlGbA6b+1n72WfW29H8kT4b33OfeBB1sVF3PNAXf6bi5/XgWqELiFH+E5qa+C8VpubdGqKG0vwelQDUj6To1atX8N6yZVZioGbiFC0fv5fvXMvz2ypJgLHmJEw8gkuuh/9cNrLDuLnlJEL95HtETVnJJZ1qj0ffcIPZLsfEVwRA9r24zrTvrrvusm62gKmcTSlLXTUHGAWH7ukkOlE3rpeLyDtNnDjRiJdkGNfy1VdfWWDwjpdeesn0EpXTTuI206ZNM507d7YxHNrhMjdU6m+tucAdHeKCAIsG2h599NFwOAJgYLwLkqRHjx5mvATlHnvsMXPxxRdbe0fb9vXXX5uuXbs2u5xSzUkY7ZBK7gHL9OnTw6ERRHYBwLXXXmsmTZpkJPZjUwPLly83jzzyiB2NRzohSgCLZ5obecCUuUfIJzG4CdtEDNAwWYlquvzyy82wYcMsWCQYZ9+MDcVktjhxrdBYGsrjOfGecttd8bZEzz1gotxo5DGShXwSKgeDlbwQ0mTOnDnWoL7iiivMNddcY6JgIbcUly40QxOY1BknAEJ+idwWeTCGUriimrNhKslYyf1YAxebBTVERllcaSsJUFFPPfWUtVW0DdgtEtTT03p7pAx1/vzzzzn3DjjgAMPQCQBJtvqCCy6w78gpVKETD5gyMZbOI0j34IMPWrBQLSqD4Z0M1gYsdH505oCOysvXBIJ9GvjDLY9SkhqLlqnUsQdMGThLRJZBU4ygW7BggWnZsqU1cInrQKgoBkRFwcJ1AINxGwUOQx3YUEl4SUSddcYjzzQ1eRumkT2ArYJaARx0PDEWBmFdeeWVtqMZckmZOFh4bbdu3awnpENCcbVx+wHYKaecYp9rTmCxrKpkKDlat+jygBB2NREhflE7gUiBnLEoJB8ZuiC2R9GfS9mePXva5wUsAdNgSyWXqQGvkhooYbBZUEOoI00MUhUeDKoJYzcNCVhsqiBN2eZQxqukEnuBVELHjh2tgQswAIsSqgUApQWLPpelvQdMCb1FUA6bYubMmdYbwsCFAAmShcluUQCVUHVminqVlKKrAAphehl3a6O3GmfBG8LLATgYvdUOFljlAVMEMIAFWwVXlyAZG/EU9sRKyA3deOONVa2GoizygIlyI3YMWF5++WUbVc1nlxBtJUSPiqoV8jZMgZ4eN26cDeXrDEZAo3kgcjiAiZmKMhWlQC3VdcsDJqE/cZsfeughG9ZnRiR5IaQJS6UqgAjKFcsoJ1Sf2cseMHm6DneZYQPqDWGrkCNi5Nzrr79u7RdWf6o1sMAqb8PEAIOLzKpPqB/NDR1yyCF2zArX2GpRsiibPGCUE7IHLAzWxj3mmL2O8WUJjrvvvtvaLLUoWZRNXiUpJ2TPfCVAogE4BQsRXMCCiqplsMAqL2HqALNAMs7jbrnFHH300XbAEpljSQLaCO7pp59uVVFd0ZreeQkj3T/7+efNd999Z4bKCDiGF+gXV2ohN1Qq+j1ghGP/kJhK9yOPNIsWLTIzZI7QWBk5hzpS1VQqU6u5fNWrJHJARGwhBjLlIwZATXvuORPs2WOGX3aZOemkk6ykyVe21q9VPWBIDjKyTRbvCZf5ytfp/5Y5QozJbd26dc5ChfnK1vK1qgcMnYsEYeUEgnEyOi1vf5Nc9FScA1VvwxDG10wzeaA0y6YWZ1vtlsg8YFjEkNB9EpEHYkA1uSHmCrWQgldffXWYD0p6zl/Pz4HMAQZw0Pm6MfVUr2lSUH8q19k6ycQvEoc8M1JmH/5JPCJG+MfL63N+n8yBZmXDMK20GOnIN12JiSGT5Hq6dOlixo4dGz4OUAAEHtIxxxxjOsg4XCaTnXnmmWaJJBB3iBGMTeOpNA40OWDI2RAggxgXm2Y5Dg3ZR39qdOVs7JReApIdUl/ffv3C8So6h2jgoEE269y5Uydr0+AdeUrHgSZVSWSDyQyzhDo5HMACGIpthX4aYPlk1Sojq1aaPn37hmDRZ5hJyAI+I0aMsHOS13/+ec7MQy3n9wkcKHXSVEPLy7CAcCKbGJ92jTnxWhpaXc5z1C3Sw65ne9mIEcFCWbVy65YtOWWiJzt37gzunTjRLo/62Zo1wYknnpizFm60bBaOXU5kcyphMDRJ6rG8unREYkwkAduJlzXLjFHbTSTIoL/8xXSSJcDyEWvO/UeCdCwXhnT7+xNP2M/lsc6cp+IccAoYoq6onXLZDKgxxq+gftSGQSVRf751VWDHbPmcXus2bey6KppoZN2WNWvWFOeWLyHrjzqiqEpq7CsFKHY1bOk/O69ZwGK/2sq5brL6Qb2vuNIG8arClbob247m8rxLlZQZwPDxBmweNj4YATBglIT9Q5AoWHQPaKKT27nOd6CrjVwCpsndaunEeoR7Hc/tMK1DJISNrfz222/hJ2SIwySRxmJQU2xEepkb7anhHGhWgNHOTAIBgTiMZrWBtHyhnw/wMLLZ0pQvVJe/14yGaBKTYcopxLjZ+MqSTO8gL3TTTTeZ8847z+y1V2GsAxSkCst+YWwX+hSwAgGJRPkoMUmNbLenOg640ucYnOjafMTCPCysk0R8RkZAZA3b3bt3B7NmzgwmTpiQaLvITwv4aJWs+mSf2bNnT1LVOdeJ5fBsdMuCkezShnHqVtdhNNzxH03+iMhr0oc5kRSoEvJASB1ySdL9dql1AU1YFwfc14QikoJcEdeSVFzOw3JCnEhzVHqPtWBYb87THxxoMsCggp6XwdesjMAqTNqpGLzYKWyU4XzUqFGmY/v2Ztozz9jzP0ueCGJ9/ntF7UCE/PlAp9o4xFj6Smog39py9oE8f4jlaDv0Nuca49FrtbxvEsAgMbBXRL3YL3nQyXQMGwlCXYufMqIzzLChQ83GTZvMLvGOlr/3nln27rthn3WSBCKShgQm0oDyrPFPPire+eFDJRwA2CNSZNHjVSLd+J3VRs4BAyN1bIqChIgtHc2GZIC4hht8vhi477//vuktC/b0kxWe4hPJuI6kATSiyyvSSbSFtENa0rZ7wKTlWEI5bARWrUYCKEDY63AF/puRFKyQQG7n6aefNisELABrnUxVXfrOO2HIn8HaZw0ebDZu3Gi++eYbM0YmoZVz2Q1tk/4UgE47mFdNO3XT+3pO+wGuBBj1VlXtC/umZf6puLdxRkangSD66ZQ+ffqY2bNnm/ny2TslyTDroY2p9Bdpg+RZKctw3CEfpMJeKaf7i6RDPepYHX25BgH1nKEZGMq0HaL9tKVaySlgokzEiyFBiKckX0gNb2EAA5aFdQsOhjfqDtrvs485+eSTrZ2z+tNPzfg77rBjdp+TeUWoAgibKC4h6h4vusN41m9CkthE0sVBE62EAWBKgIX2I0mrlZwDBtHN4jyE+pn6wTr8rIzAUEpslmfEE1osMxA7yn/ttthXOlBDSB/UwyoZJDVp8mSrhgjm8WkZJeyNQTKqDpc6bvNomaQ9EkMJycF7GNZJ0LAYUT76fLHyWbzvHDB8qoWoLeBAjBNnAUTYMlPuv9+8K/+drQQYcbDw9bLNW7ea/8kcaD5/9y9ZSYE6IHJMUVXHMe9gGz16dIOlDXVjF/H9I9oJUTeAjRNtIf1Q7eQcMIBEvQekDLYChiTqZfXq1RY4O3/6KYfvXQ8+2A7i3iDAeOXVV80csW2oQwGTU1hOkDCAiK0chIrTNhcCTDne1dzrcA4YZQgRWZYuBSxLRBLwTaBdYtPs2rVLi9h9j6OOsmBZJR9s+NvDD5sVos5YiLBYbggwEh1uqC2T04jICWBkq1Vq2VQ/nIwzXyrbvHmz6SfeE1IlDpYuBx5og3EtpJH/lKjwf8Ur4j98yJAhBZuN+khjcxSsxN/My4EmAwwSRr+BKMlBc74slhylfcQbQgJh2ywWNfTqa6+ZN998Myc3hHrLR6g5pIsP6efjTuOuNQlgiGXwvUKWYH/88cet64qX9Nc6TwdD8yz55tCnn3xiFspauLfeeqt1wQFANDekKQRsDHVvNU7CokDRso1jk39aOeAcMHgYxF/ke0LW+yDBiCtKkKxNmzYWNMyXfkWA0lYSjiyuTHlUEWWihH2CNGEjiYltQVnsIqKtnirAARH5Tkg8lkCaH0inB+LuBvPnzQs2bdxo3y0db+9xXzo8mP7ss+Egb66Jh5KqjQKqQDynVGWrqZD8c1j+yT9ORX8W8HMuYYiktpePXqKCmHWId4SEUGlBvKWnJBQZVUc2W4dj0thCVM0Jv0K/2/U9p4BhWOWWLVvMKxLJJeS+WY6Z1kq8RP417CdkCMdfddVVVk0RYufL8cVcY8BHekEXM3TNxFp6n9M4DMtsDJfc0bp168wisVEIpTOGhW8NYbgCHAigAALyTXhTOorO3szzhwQmOSl9Pk8Rf6lMHHAqYVC0B8undVu0bGlYUw6jdoAYqng45GyUMFwZjceXWZNcZy3r92454FTCbJVc0FzxZqB3ZNTcVInGQrjY9913nz3mDzYNwTfAgm3CgKtCRHnyUcXKFaojy/c0S+/iN7TArHbxIjpUE3gu3leL78BBKDU7XwqfZPiGTDR2BJhSGubLNk8OgBenNkzzZINvVSkc8IAphVu+rPvAned5tjngJUy2+8956z1gnLM82y/0gMl2/zlvvQeMc5Zn+4UeMNnuP+et94BxzvJsv9ADJtv957z1HjDOWZ7tF3rAZLv/nLfeA8Y5y7P9Qg+YbPef89Z7wDhnebZf6AGT7f5z3noPGOcsz/YLPWCy3X/OW+8B45zl2X6hB0y2+8956z1gnLM82y/0gMl2/zlvvQeMc5Zn+4UeMNnuP+et94BxzvJsv9ADJtv957z1/wcLICQkJnhqfwAAAABJRU5ErkJggg=="
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage007",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage007",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAIAAAACFCAYAAACT8/B4AAAAAXNSR0IArs4c6QAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAABtCSURBVHhe7d0FtCPHsQbgNjMzM8bMHDOzHTMzQwxrZmZmSsx2jDEzMzMzM7Od56/P6X1ara5mRnAt6arO0fF6VzPT3VVd9ddf1aPB//enhK702RUYvM/OvDvxuAJdA+jjhtA1gK4B9PEV6OPTr+gBHnnkkbDQQguFoYYaqo8vT+dN/8cffwyff/55GHbYYXvGAL/99lv44Ycf4pdGHnnkzluFPjijQQYZJHz44Yfhp59+GmD2VTHAbrvtFnbaaac+uFydOeX11lsvnH/++fkNoEsRdJYh8Ozl0s0COkvHhWfTNYDCS9ZZF3QNoLP0WXg2XQMovGSddUHXADpLn4Vn0zWAwkvWWRd0DaCz9Fl4Nl0DKLxknXVB1wA6S5+FZ9M1gMJL1lkXdA2gs/RZeDZdAyi8ZJ11QdcAOkufhWfTNYDCS9ZZF3QNoLP0WXg2XQMovGSddUHXADpLn4Vn0zWAwkvWWRd0DeBPfd57773h73//exhjjDHCxx9/3FkazphN1wD+XKC555476H/8xz/+0aeUb7J90gCefPLJMPPMM/dX9uCDDx4mmGCCsMYaa3QNoNNX4Jxzzgkbb7xx+OKLL8Ioo4zSf7p2/3zzzTfA9L/66quwzjrrhOuuu66py/L888/HZ9x8883xLMboo48e/va3v4XJJpssTDfddGHCCScMQw89dFPG0Oc8gN1PDj744HDUUUf1X9QDDjhgoAVefPHFw6OPPhqWWmqpcOONNzZMAYzvyiuvjD36Dz74YJhqqqnCaqutFg477LCgddvJnZdffjlcf/318e9ef/31eFBn3HHHjd9lFFNMMUUYa6yxwpBDDhmxCwNh0MMPP3z/cQprI400UtVx9zkDOPHEE8Pqq68ell122bi43D8ZbrjhBliofffdNyrhiCOOCDvssENu5VPeRx99FAYddNDw7rvvRmxB/L8jd+eee2748ssvw5prrhkOOeSQiD/8W7kst9xyA/yV+3z66afRGF588cXw5ptvxvv98ssv/U/8fPbZZ+G7774b4DrjWXnllcPWW29dcQ59zgCsAlf/1ltvhWeeeSbMMsssAy0M1z/xxBOHr7/+Opfi99lnn3DRRReF999/Px6lszt///33MMkkkwRHsggF+vtbbrklTDrppLnuW/ol9xlzzDHjh9HkFeP473//G/bff/8YYsqlTxqARaCoSspP/7bhhhtmrrGdPMMMM8Ts4aGHHoqxu9VksMEGCyuuuGL8rLvuuuGCCy4YYIh91gAaoagNNtgg2P2bbrppI27X9HvwBl0P0MBlBgyvueaaBt6x92/V9QB1rPnUU08dQZl0rV2lawBVNPfzzz+Hiy++OHD1lWTeeecNd9xxR9cAesv6pTl33nln5O6laHYfdD3iiCPGNGeTTTYZaCjPPvtskONT4jLLLFNoqDvuuGMEeZtttlk44YQTBiJjttpqq5i/twsGqDT5XvcAt99+e8yFpSa//vprJDJGHXXUMN5440VCwwct6wNVf/LJJ+Gyyy4Ld999d1T0EkssERZZZJGw9tprx1RNHv/tt98GLz94++23w4EHHth/njfddFMkcZAt0iCkzt577x05AOnUv/71rx4N4t///neYfvrp4zikc9jD7bffPswxxxyRqLn00kuD7wwxxBARB6ywwgqFjKtVvtwrBvD000+HU089NZx99tmx6rb55puH0047LbJWmC/59gcffBAXFkvmz+hRhAomy1tKrr322rjYlWS00UYL//nPf8Kcc87Z3wAANASIt5wgdRgDWpexXXHFFZFIWWCBBcI999wz0C1xBEgWHoOHMUYexBhQtuYx00wzxTkwRmkgkiaLdWsVpZeOo2kGgHLFu/sASdttt1049thjwzDDDDNgHvrnDqZAn3rEjqY4gkJdddVV446l4H79+kVu/bnnngsbbbRR/Dse448//ogvwxJWSmX33XePOx7LxgCQMP5s97unl2d5BmGsWD2e4uqrrw4LL7xwPdPo9WsbZgBcNabptttui7sR6yUuq6+X8tPNniHliss777xzEG7222+/qKCrrroqzD///OGuu+6Kyj3ppJOiEcAHDCHRsTyG6ymcJCaP0mEC/45C5v5d7+/x+pdffnlYbLHF4rz32muvWFlMNHOz51zP/Ws2gJdeeiku8A033BB3kPiMbcJhn3zyyb2q9LQAI4wwQny+XYpyPeuss/orHf9/3333RVAHGDICSrLbk/KFH/TwoosuOsDuZwR2N9QvfPmstdZaUfGMnaKFgfHHHz8svfTSkXHDJM4444wx5Ck9q+jZCEIQr6JO4LnvvPNOBLNvvPFG5Pj92avcYJVtt922/+vc6lFytWtzG4BXjO25555R2QbNpZqsQomFaIV3CgKDdqkxAoN2vGzBfx977LEI5gBB8fuJJ54IULx5JaEcxrvHHnvEglHCHLwYlw83JMH9wxaUDqCq0uHo4ZZkHLwLzygc8kDffPNNkMkQAJYh+K8PvDLllFNGQ4E5jF91DyiGM+CVueaaK4bTRpaGMw2ANVpU+bBUyKRMutXk1ltvjehednHKKafE3SMk2YGvvPJK5P5fffXVgLyRFTDgF154IaZ45oTSJYzEXOEGBjHbbLPFPz/11FMDTJnSgc5pp502KkjIsRlsBCCTxwAiTz/99HD00UcXXi5VSB8Gev/998cxw1MM+vvvv49hq1QYDoDKEItIVQNgtXaDmKdCluJhkQf01ne5fejcLrRLZB0M94EHHojhye6zo+xG3xG6FIOEAyloMoA03sMPPzxmDgn0SVmTCH/KrtZD2JHWMjrpKgykqYMhcvnuwQD8O0MpKuOMM04EtD7VhGfjJeAS+lIEyiNVDUBao+JVXivPc+Pe/I7mDhkAIkgqOeuss0a+QCroz5RMUYyYsoUDu9dCQe3+rpJYRCmqTEH8P/LII6OX4VESwOPGGccWW2wRnyMb+Oc//xnT2SWXXDIceuihcQ1tJODS9ca24IILxgaPRsnss88eAfeuu+4awwYMxHtlSVUDsDitrnxoXCwGniaaaKIYP6V7Z555ZoynYjd0zt1LFRmIhbfDGch7770X8/tKMvbYY8euG88gcMExxxwTSSUumAdIXlGlTTg444wzYljxHNfzRr4jREmFdfYIH7ITmEI4hQEARdcjrnoyyCxl+ndhAzPJyHg6ZFe1bCQTA+R56F/xHTvTTtNWRfncLkaOm6ccQI9X0Hzh7y0I141voFAgTlylmMknn7ziFB5//PFoUMAlD4L9Y1BAHu/BwErfpgo0CiXCzkorrRSJotKwKevgCaSiSYBCGQGyDEaxaxmdnSyz6In8qrbmUlFZhXsIf8LSPPPMU/GStjMA7vSggw7qTyq99tprUfmAl8VOKNt/V1llldgAIVsR86V3QBkDEDOrKd9qYf/QwYzokksuiTEcsPNMC6qzCMeAM/BsIEwaCjDynNLiUnENhpOiKYmgu31Sl7JwJpRoXUuppGcKZQBsT8ZaSbu8gTHDD+YOB5VLWxgAlw6QUjK+f8stt4yo3kKXKt/k7Eg7SDrGvTMEgFBWwHCkedJYys9TxrXw7sOIeA1AkxeBxpFCYr/mUvhCkUrmAVza1ZWEQTIS3qgnYXRCiQ+84r4M0DoIZYwNPjNXxiPz4PWEEuHOXJPwfNhKayDtbSkDUG6lRL10JkAx/o7yAC2LxI0jVAAoLtjii5VcpnwYEVPaVOk+rmcEXLe0CE9BYQwHQLKweZSfFssCI72kYUCe0CF2CwN2l0IQwOgZxkZhPQmFMIC8ncZCQiUwJz03bwaeOn1sDp6DQTJEHiOJuUsnL7zwwgGG9pd5AJYNXae0zaiAONVBhId4yU2W9tmx5GmmmSamcr7HI1TqqLUzEDB2g1yeK6Qgiq9H1BG0issI0L3AFuVA4AAe6ptR2InVJGUTyB8Uct6UrfSeqaZSChhhEqTXww8/HPkPIJ7HswaknDvwd71uAKhW4MTutovzdsjyEuJkUr5dXUn5cVJ/UrMMyCIxMnxAo8TOt9PQwZQHZwCLqcwtvuMAGMb6668/wOGT0jHAC5hVXoySZA6NEimulFC4konwUsBppWyg1wwAM2YQCBQT5gLzihgsrlK+SeRRPmxgZ8oUpG+NFqXl5ZdfPvIJ5iYmQ/jSPKGAC+YJhCIGyAWXC8BnfLxHKlvjMhqVeqt3+AiTvI1aQ7k0xQAoWSqk+IIJg7gtFvQtPSsiwBQghrunfGAwa+dTvh2Inm3GeT/ZARwAs0gPS4Xy4AwZAj7f+Bk+ReMeKLtUYBpxGW/gewwJjmAIXLhTQPVKYhKlr2juUmmoAXBjKnBycbSkj7Sr9CBmkclYPDsfUMyjfCkZt++aVNYt8rw835WapV2e5/tAI6oYgaTyyDjxAHoLyg2BZ/QB1lIDizAphjMKH7hIKggYq1vUKw0zAIsvFaoENGoZpN1l51sAO15crbbzk/J5GAAtizuvZUxSMKQSmreo2BSIIV4JUJPVHH/88RVvA2T6MGL8hU0EY+hSkiJC98IK78FY6qnENsQALLZd0YgDlOhRblK3LUAl53Vfros7L/8dI0xZAnzcPsRvgTF4jW7IkF/jAuoRu1eFj7eE2jWwlGcNftlLBoMQAiSFBnG8/BfcGBCQJ8QWIYgaGgJYKrdkgPWI7MDuQNCYKLaNUL4qGyMTK1W70o8fSQX9v50BZLmHPNtuw84pm4rR3K3rkTb1CKO0ExshUlI1AW4cVVtaKQSQxetKwLH02SqVsAZPKSth/EWlLg8ghxdvxa28gspFXCB4xHauHWLm2uTZCCAAKykf+aOCxgNYFJU3XoGR4AVw3WIj41FhKy+kMBYAUs2AweAfdAUVFSxcT3x60Xul78vVzUE85/WELgIn5CWqKF9dREiAFRL1nXdMNRkABUKn3JQmkWpi4aBZXbMEKEJ8cFnugZ60wxE3jMn34QiplZKmZ6jWSbvcg8sTJli/HBxQLH3RQ/lYhAEewGeXXXaJzKD7ChNFRCqaVylF7qveLyQwBh7MWjBmH6RTXtFwywiAVBkHDoB3zpLCBpDKnlgwg6wmKFGZgLxYu1NPQqEUlJQv1YOUATr3kMczCovFI4iNiCTMYRERc3kY5JM4W4SB46p5kmaIcUiZGaV1VcpmuMJqETBrfjgS7x2w6ZTJAcmewLO5FDIA3HqKN1m/KMrlymW5OIrLUr4qGXcNZVO+li3EhSpWyizU0IUd96xVeCA7xQ4pwr7xHAyZu21W/z9jF864cWVnXtKmMO+8Ymz4BsDRdYwL84p1rJsJ1Dsn3aqmfEpU7OCufcToasrH1lG02A5hS7WgYjucWzRoxBJrNqksr5NnoQAnO6WIAbivfF7G0Yhsp6dxwijIJPOXVhsjzKM3QFlY2ERHYxiriXuoOaiAKhC5plJLXyEPIN5D1j0J8sJAUZzljFf5NRoWuH0TVQGkfHFWTgsomiDlMyIt0sCikmwjBI6oxYvAIYo9XHTR84CYURsnAdye5gEA4j54AuFWtmDdZQoyEJ5VLcL6Jc8oPFk/RbRysZ4JUzAgvEKp5DYAoEzZs5IbUajBNdv93GRWr5sOHoP1XbHYJKVt6FDkBnfLdZkoY7IrhJ5GST3GpB4htYRPeK88QvmwEKXlEVkKb4d3sHsVjGRCPpXEJrKeysCVDsimayqFrtwGwJWw/FJBygAZTtlAr3lO31K+AgowhjxyT+kZBKzUK72zCxiDhkpGANw0UjRHCDW1COJJyAIkEVVZBAxwpyJJ+UXmIeTpKoZXsiqmmEGbUJoK26hS5m3dz2UAUjTpVuL0xWvWBmToha8WFkoXuVz5mCwAUegQ7wkDEBLkxNxlkUXLo1ClWwuqQbRW4XJ5JW5a2OrpXkAdNE75wGdRoUjklbQ1S8R8oYN340FkFEIOz5OkUjaQywAoiktiZdCkNE1hg2HkRcR2CwTvv0CdXUi5Uh29c6llW4gBNllyecEkaxHy/Lt7K9vWK0KSnBuPUYkFRfHKYFLnby3PwwjysEA1IizPGUvfVatArqlGyqiEZ0ZR3g1kTLkMgLKQIHa8qtZ5552XOR+xHdCSxlggH16E8hkUpC+nh6oNFr4QUoQShtLTWzkAH/eoll30NDitYujcRr3XR5HGWBmBgx9JKB+BRfn1tHi7n13tOTaadnTGWy2vT2NAifsAkhSvpgC3lJ9wyjQAk2F5csuso894fGybQauJQ/IUZddju3SlqohxhxStIubvKd9AeRi8frVqm+wCik+0aaYllnxBy1apoopc29N3hSmxF29vowhzlM/t16v89Ew8P2/DGwCgvO8222wzUHGo0hjxCZTP8HnVQgYA8DjWZGJZyjcgO0u2kBC7RbA4DACBQvlivO+hcbUtCQOUD/h5VqUXNpROzEGHWlI4oFPpVB9howXKxy14a4ndBsM0WgBl3lcolhnwoNaO9xHn4ZLUJ+j50kYZlE2XmmTLQXxmCODGAbRqLlMDotyf1Ze2Qicih/LFd91AclIVMEem7PIE8EyOglT2enp5o8HaXQBXeRdOnsW2QystQJ5r83wH2hfOzM2aNUtsILyID09rQ2jCUVyTORFFIRtP5pa1cauGAAvW0ztmWT2CgSI1OJZW2CifVSrpJuXzAFI6MZOFJvfIy8hvhYzSA5iVFpALw4S5vkgThOPiCKXy9+82Wkl693kBsbfSa1kb/TxVRF6hHqlqAHacqlsSeTsXCgxC6wykNM3wPTmyvNe1jAOvTfn61+14hRwLhDSifAuG7mRMWQ0c4j96U7iw27jDPMehHdPSNNEbIgR4QUQKB73xzHqeUdUA5Lmp4maXiqFSGwQNAFcuCjr+ndvnjoQO3oCLx/DZ5ciepHxVPoieG2NcWQL8wQk+MgiKdUBCaqdXoFJ1TyoktKSjWFnPaMS/o2tVPwHaZqSyjRhjukdVA1D4IeIJEqjaDydI9+AAsdxuV8O36xiQ/j7IH0gB+FIbF/qXkSlflr88KmuSjMcH0AR2IF1xHlJOpAvPwziyQkulZ7mmloOZ6V6yJo0ybW0AFkCrklhTresnuXU7H7IX/6B5u13cx1OnxUzKF8e5b7FZWlOrYPVgA/UER7c8C0jkeRRvagF+gCqqOKslq9qY0d1ZBbFa59zI66p6ALuJu/ffnoTyIV+FHcCMS1e80OKF31fBS1WrUuXjr+3gIk0Z1SbuPip0PsAnLOL5qNGigqhyj3oMQEHMZmhGc2rR+VT7flUDALiq1d+lIRRsoe1mhz/EWhw0woEb5YbtSDiAwqWWlI9LlztLnxotqW++/BBEnudoekF1k9Jj3HmuLf8Oggufn0JpLfdo9jWZTGBPA6B8E7RTxG+hArunj40HQEAghOAByofaATaGAkwCfenXuho9ScUTY6ilibO0V1+fXT3MIbAqFHScAdjddjtuWicu8CfdE/MxUHY6LwDcMYqkfMgYfwCkaflCVDRDNG3wXrVIqQFgLusxAGkvHkQ6nE7o1jKmZl5T2ANojMT8QftiuuogJWOoxF116PSmDDscOucN7HysIY+ANNLl0qydIayU8xN5FpHxpjeM+L7iFHKnnvOF8JNPvUfT84y/lu8UMgDKt7vx0FqQLBbrBvzU9fWcqY8DQHru9ArYBZSvDs+lypFhhmbm5bUeT6v0Pj99D/UYgMYOa6MVq1EtbbUouqdrchsA0GbH2uEqSz6OYknn7PRUcJDnI2jSWy25eoYgPGhx0kOQp5xZzyQr/TZO1v0QV5U4fIarrFvPQUwhk8EjvKxNK0kuA6B8zJ/BUyDihev39xTtF7N0pEh7xHctYvJ7i2ZhMWKKFZjAZoux1AL+jjvuuB6HpvpWD+euLA4s6yHEjrpfLQWtZqxdVQMQ/+TXABXGDbK2o+X4AJyavAVPRqA0iaIVfynd/6slFD3AUc9EhZ5KNHXWPUt/RbT8u0JXPQbgfqqYSDFhxkkmYLgVWMLMWgAaF4LVFMKNsWS7X5UQjYsxYwRSQfFdnR/3riD0Vwjknn43IO/z8RUILaEJmZW4DR4NvgEG0dbS2XpFdqRFCy7CllZq5a73GUWur2oA0HopEaTCBwhaDE0ZKl4MQ5EGHsjqXi0ysFq+K9xQYtGUSzZT2t2bSs3plzprGUu1a4RGWZS0GO1c5JdAGz2WXBggPVRfYDMOSDZqUsJNLW/mbtTzi9xHJsWbpuNf1c5OFrlv0e8WMoCiN+/N76tFqECW/zRqb46h6LOkyIC0DEkozdPbUPQZWd/vGAPQ8QpYtZsIs+ko2F9hBB1hAJg2XEOtL6P6q41GmxtyTHYlU6h2mrrRY217A4DU5fCqjO0s0mtFLCmzLCbrfGWj5tr2BqA7FrHSCaKw5gQwgNhbRtD2BqDjp1ULLbUYpTN9Gm/1TKir1HICqshz29oAlJudRGq0OGJd5FW2jX6+9nXtbTyBOkTe85e1jKOtDUDDZy0vbcxaqKJvDsm6Xy3/nt4NhDRCw5e/I7CWe1a6pm0NQDlaccoZgU4VRqDEjmHFwlZ7G1qta9C2BiD1K//N31oXoZWvU1spNYKiNHfW3NrSAPQUSpNamZbOWvgi/654lIzACepGvU7eGNrSAJShnfjpSyLceRMLYKjUXk+DSum6tZ0BeJ9AOoXUlwzAXB10cUhHt7WzGPoUsl4Xl7VGbWcAkH9f2/2lSkQXy3y0l6kgereSQ7J5fiW07bMAjRmIn/S28Czr7uR/123to4/Ri6RgA28UczKqSLbQVh7Am0q8iaQr/78CQoGP0IgR1V8gLHjzupdvZb3Grq0MAO/vCHpXBl4BFUQt6D4wkiNp3tuoushAdHRrbyuXtjEAlTI1f+1nXam+AsrLPk5upfcFOe/o4EvbGgB+vvw9t11DyF4B/Y08gY9eTo27bZcGqo4hfRrxE2rZS9a536gEnls+BAA3jqOVntnrXBX1/sxa3gCcy1P4aVY1rPeXvLWe2NIG4D07cv9aTvq01jK37mha1gC0RjmOVctbQVt3uVtvZC1pANqk5a66YRr1DqHWW/rWGFHLGYAuX7y2AxN5f/SgNZayPUfRUgagtVuBwxuuVb260vwVaBkDAPZUurR4F/nBxOYvUWc/oSUMICnfj0Q4Wt6V5qxA4Z+NQ72mn3xtzpBCPM7N5XufIN66X79+zXpUn76vdfaLZ7lqAekdO5oue7Pxsi83evSmdfK4SSqGAO+ycXa9ksvozYF2n9X4FaD80lb6igbgXUB9peO28UvcXndsCRDYXkvWWaPtGkBn6bPwbLoGUHjJOuuCrgF0lj4Lz6ZrAIWXrLMu6BpAZ+mz8Gy6BlB4yTrrgv8DKyoP5mkBHckAAAAASUVORK5CYII="
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage008",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage008",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAHIAAACKCAAAAABTd0HVAAAABGdBTUEAALGOfPtRkwAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAAA1OSURBVGhD7Zt5WBRHFsBfzwz3jQygch8axQOEgAeCiBpFjUg8YsTgfaBR3Jho8OIz0Y3rsYmJcaMbFTWaeMQcxk00AQZRQAQ88OIyDiCXgOEYhmFmeqvnYqa7h+mWcfPt91l/8HVXv3q/eq+qq169HngLQVOEnnjXjRGuZFxaJbzDWtWYBsmVaUt31atrqTXMu8iD+ONylfjBe/uUl5x157P5XRZfS85Ui6gkGwbVatdwvPIdqEhOr6dUr3HmneABBhyV+HL7rb2Ul7sneZybrFESXlXVV1cjf/pXi7Rrkg5toLHSvc6FWosBT7vymzmXVLfR1VGppzRDsSs5ldR2L3+BuqPEk0X96JChgll07tZBTtx+aYJKyOHmP+0yQlQ3cUuqe+s2ttwfeFurxmbgDbWsVu2GaYaRcN7jqaW6zdrpow9MUd0cm51J6u/8Z44nJxJ1bdlVMXz44OOzVIN88HIfGjN1rASn48H3NUJedwZUq24mp763i9Q4KX75wuWQ9sglwi8u9t1xszpNqNr/vu2oQSS8URpUqJGy739tpOrmdMysY+ZazcW5V9L+8K+NSnRClcv73+Sn7Eqmap/6OgMkrDdzLyTUKMqn8zX8i6n2icv6E5WS3Cvpt9zDI5fxNYyslvwvC2iQsO7ofGpHdB2LnicN6yMYoZIb6npaMwESEg6+fcvOSlrlHx25gDSZ+DY+l+/QaU8ezAQJEeWRE/er/dk3IEDTzaVLp7hFD3enGR2o6nPwpxQa7Q6Ojz0p8hQrAdzKtvQ+Ng4jRG0KB6aN0rTZPWU5HQ9A3G4Kl4b8+hr16dovdjJBAmybtWVK7LKxSNhXGO5/1FnZquETIT0RnphwYfD6pY+pj992YIiEQd/BpX3jZy6N5LqU/DDYZeXUPgBLbh/WXnC01DeK7dHdxydOzaEwucNzw8iVNI5VikyYABc/n9o/Ycm0aWUHY+7ypIty9dgoqQFr4lHGACoSln3JHIl0xMSA8ITnqE99dyLvbAutslNoJhdZOYbbEpV+21Z9Tnkau5TZWHZJeSQn/zze7QTy6+lN4vK+NFuUrBwHBRHgA7+bgWQA17bRkVSn17EaucmTM4LGf+Yg4lg6Vre4kYezqQYAVy4Kckgb1EyxKTonhjUSYEztCc/x0wD6tLUVO9trQfE/6zvRy2RvplDKqfHYEPs9mTkq73mQAPHx3y/3eQc8S6G2xsbWwpTQ29nW3IoBJudYuaowktbkYSkpJKbf7+ROGHasskVs7PohaU7ejzCstQUHjANyHAMcs7S0ttCotK7s/x/XodN1EZ7lz4sE2DnJ/fgM9wpkGPKlHOeYmVtaKczVFCtZhcfBuPOxOpWod88xlqomYxqHPNjkWSHjmZqbmZnTBIxmnNbmJUem712rzajX7EvqWkOO/XBQl6MsSsb+8e9X5HrWIKTRUlRl9WvAL6e/09ppzkxla+XeWu0Wp/kfueonArK80nNzcbTX3zar45mc45UskbV8neFyOj45n6xB6x65rO3ZkrC5rQdcB0wf7Cl6kvOteTZF3oBjL8TptojPObBCP9OyEcOe2FwOqFi9+n76TxVWvYfmUUYSdONYqrKz5Ndsh58+JNqMLdCLgwm99yakwoABenvG6x6aQd4HbG3F2mFXl95WCYAJsa+LG2Ye0IRpdFweHMmKn6mvS3eGU9r0Kx1E2/9aYklwahXjWK3tJbdqRVBBX3iwcMfZhHvTZk2mG9Wz1HDbuZ5WUVMHsbY7O4OkveNp76+n/NwdstNl5crO376J9587B+1RuuU2ddO9o4gsyUVWi9so60yJKR59I+ZiN1YSj0wmTUotOzWm7s34cB3J85R2+ANKv5AM/gi31HHlev/Bhfpehq56302b2n/cGbfvTRWm6BeR9zhSwArw3la63j/uxEkbcZyvV77yqCcvtBio00anKxazZz/ZumBiiAVW8fhi4JseRTseRcTFqvcmol32qSoqUlohBsyOVD80b9ivAbcFgkLTh2guaxey9X0OfXGjSIKPfuMUMSY7ZYXnw5/FxEarFF4fl95KDoDwBmJCkaMN6BS+H20fNnaP16ky0gGJ6nCTEerzAdLEDQnZ3jElNakpODLC8eHB6mJcaO5kozVsnU2NcnSLqWJdhTXivFvt4Bi8eo04/cGKbNcHJPsN7SRI3OyhUFpWfPOwyDMlAnBRRyVYW1jwuCDrkHSIpBiOg6WNnaYXn3SC04hV0HA163pppSzthxGUN5QBUuQEzXI/P44zEd9hvqVyaGtDHJRkQDiepZWlznKUBHWC39LLaiUVwlfCI492xQwaWxkgMyeAmJh51Y3eaOPi+gtFCAYoLDA1N7fQ3anL8utwYRVUVPpFRoTSL4wGl3Wia+feViBRgNVArDAcrz+bUWBACgvkpbl/yisa2irqfcaODlaGfHqKYSurrx4CMQZyMyc7kCrE7XRfCNH9+3UybqtZWq57+JSpNOd31tNnzmmQ4rg1n9jnyR0UZd0BvE9k8JPM7OstbksCA/0MEw3tlwCCXoOg3d6Zoqo5oxjneESOuZH59UbToJFz/tGtM7tbCij+jy9BJ1vFko2LrJRPa3JKcTOv0KFZgpPveYWOTqCsit2NpOHpszeJmHiyorwmzHKiD15xrQqz8vK1v/JbqU3gqMSBuoFs9yj1UwPTp/1AyfWCVtx22CKsXPAD16YXX5Ke2+kfOjJRle1jRtGR6gZZnnUlq3XGwVHLoejqtesoXG7KLHcJCfug33NgDI/lvczsq5LgiBWH4H5GmkCEc27mdQ4eOW6DJtvWEyrZSnlh5rUCLCRqXSqUp+/J65S+cVvoNDIszpsCkaHjibLgvfXO1gvqLKBWcy2k+Ibg6j3r0KidPlCcvr0AD4zaMJD7ZdDHehaumpBxuFm2g+/TO9bH1Hk3Sr/eyhhGqVMim3OzMktch0ctcoUiwfuF3OCoLQOUNizT60LOmG8qjyaG7neIf58+h060bJlZRo+8PCFucZID3MpYk2MaFrWdNqCitMRvLrgz66fYxKYdAtKRsks0B8o/2kRuqbByfF14+lf5tfOCwr9lPi967cs1GQIReNNnH+rGNloqrgNsXkBKkqsWPP7DM4v75eU0bGROBLOYDnsiCVzzrTpTTW1MpIpeJx+c1NNnJsCrr7IAMhMlkAVHFugKG968mCmnl1LMncWzdV/nF4q8q+iIfNYFnQ69UKRiFJ2GvdKuEwG9UOTjOeFp5yjHpheK3IwyFueujCaN8wtFIlYI3DA+ktNNigRgEGTrpIFQL9haKd+foUEIW3M5ONZcMFv9lc9hHXUv9aKkUFgiZd4pe3hmmpg/B/zPJKqBMkldwrszyC/oyJO0ayzzt/1IykLYfUyDbONZ1J9Rt7bdMj7bl4Kc69OiOl+r5Vha+XgcBK4o1GxWmW4+n69Sq2pZeDeJuo2hbHnPZiwmLwhXbqEX+ER+Bke5ZoArtkPRX5szfklMPmaztBKgXnkcnxZUEDcfQFqCnLyI83Cj4rMMM2XMpLRdo4xzalJufY2OYRIZWrLvX7vwQIHs9nXR6GCNNNuxBx0WsFq3TtFJ6AiYt2YrVucmlhKfN6VM3MrUF1pWjjl8FlnE27StLHsu/tClb+wE7pYtBXXEZn05ltHUZ20lyKUd6MSAd0hkYnR2x6UdXLxDStSBVOfHCHrx7JHaqno/DuAx86ZWq54hrZ89tWfkTG0hlkh5iXlxwyNwVB2CeO0lLlhNOzGdROhrY0kRujRYWCKTvf/Vy8IerFTN5Jiol6kduuHZoGOfhcviJINA1jPWUjAzrKoAfcVTqpZDS1kOpwXgLjFzKgWwzvhIuLHQvTla01M5Vzyyk4dCx36oDjhzdH44oo/O0rGQtlLUpKXLViuLiFU7BQk9DJvJFik4DOXPXHAeZmrCRcPnXsTF0DWPh65bH4W9lp5gfCRSnT3tkVTcniiTZaEfGkkKcBCvkuI/mnP7/A7jPzI+sjAKJdCz963Jn3+i6Pw7ylXAZNHJjNrVIW7ozBNA/RBDtZqlY//IJKKbRpjBG2J5ZJtKXd+g+l3n6hv9UQ/aJIZzJCyR0xVHyU/W5vLB73KXAROegKdznuFhVEiwRBJNnqWcBSlFvbx840JfRlD2yLRJEv5U6ud+x8odO+YdY8JkjbwabZ+hlQnXMG5BcfJxF/IPkei6wBqZYC0kBYlqtf3Ohu1+Ech7ZZv1EBF5/vX8YMOuZWvlPdCb40E/MAAiODBU2CKrwMuQSkPP2SIxYJBX7h7KFgkwkz5h50057ugDs0eueYtOl4m/IX9qnrNHcnvqWfZIxtYYz7H/cyTrQJnaQ7aOpfsszNJutkj92V7GYLZIxor1C75EGsGJRtmie94PtmOJznQ9LWyRjT0FPldQ2VMoWyt7ykPt2SL/gtXHKGssu353/V8GycVEMo3DIKXGRY49epTd+MydSy+vSNLSxfFkcd58dkAjSPOOGEEJOxVsZyw77bTSL5FGcOL/6eZlBMtfTh8jOPHl9HlBTnzp2JeONbIHXi54RnaoWt1f4Nj/AgLo+IAQfnF2AAAAAElFTkSuQmCC"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage010",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage010",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAGAAAABdCAYAAABafGNLAAAAAXNSR0IArs4c6QAAAHhlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAACQAAAAAQAAAJAAAAABAAKgAgAEAAAAAQAAAGCgAwAEAAAAAQAAAF0AAAAAVWn7MQAAAAlwSFlzAAAWJQAAFiUBSVIk8AAADUVJREFUeAHt3dvLFdUbB/BlamnZyczOaXbQSovOpJ00UkIlCAqCEiSMwPKfyAuvvFKCuuii6KaI6IBmoEQRFZ1Qy8zKtDLPpp2Pv9/7WbBexu2r7+y9Zztr435g3DP7nbVm5vt91nNaa7ZD/tcnoSe1IDCkT46r5cq9i/Yj0COgH4p6doYVL/vPP/+E3bt3h2+//bb4dW+/IgSGDx8eTj/99DBhwoT+Hg8iYP/+/eGNN94IixcvDmeccUboM1H9J1a5U3Q7Za/x33//hT179sTbcG9///133Kc0Nn3qa+TIkfFv/n7CCSfE4yrvvdW+3M9JJ50Ubr755rBkyZL+bg4iwEOSqVOnhieffDKceOKJ/SdWufPbb7/F7kaMGBGOO66cFfzhhx/CokWLwtChQ8Py5cvDxo0bYx+bNm0KmzdvDn/++Wc47bTTwt133x0++uij4PsZM2aEmTNnVnnrLff1+eefB9vq1asP6qPc0x/UpL0D2vrBBx+Ep59+OgC1CkFiWSKruF6VfRw0AqrsuLEvJuKPP/4I27dvj5pAGyZNmhSMgjPPPLPx9NLHp5xyShgzZkz466+/OjZiS99MCyd2lICff/45bN26NTA5//77b9x+//33cOqpp0Yz99NPP4UdO3ZEf9OqBrOt+kfA8ccf3wIE9TapnIAECIcO4C1btkT7bASw30C67LLLwgUXXBDeeuutSMBZZ53V0ihA6r59++LmuqKMbpPKCAAwEEQqX3/9dfjkk09iBHLdddeFiy++OIwaNeoQO80E8QPvv/9+mD17dlNRl+sZTd999104cOBAjIKQ3m1SGQG0/bXXXot2noYvXLjwEMAbwbn66qsjiOvXr48gMk1lRciJ1EsvvTRGQfyLMK/bpG0ChK7MwDPPPBNuueWWcMkll8RwsKxNv/LKK6P5eemll8L8+fNbwo/pMSLE/d0mbYehzMDrr78ebrvttqiNMr1hw8rzSmtHjx4dAWS6hKnNiFxF/K8Pm5FRNrlr5jqdOrctAtj8Xbt2BdEOOw8IjrYZMVJkr+PGjQvr1q2L0Uwz7REmCaMItm6T8qo6wJN5cATQPPF4s+CnLrWTC3z11VchZePpb4N9Cj85YT6AGUrbYO1y+XtbI0D8rXB3xRVXtAw+wH799dfwzjvvhDlz5jRVu9EWYT67VdoaAR6eGRKPtwrCjz/+GEPJ8ePHh/POO680jq4n8lq7dm0kgSNudvSUvlgHT2yLAPfFBABh8uTJTY8CbZkdZYmHHnqo6cdk9mbNmhXDXY4XCceUE4aYEYAAvsB+M/Lxxx/HMgITNlgML4Om9Wy9OYuTTz45ZtU+5QPap4jo+++/jzWmbihNtOUDgE3jPLyaD2d4uDCSmeIzZMo7d+4MslafHHAZ0wPMc889N4L92WefhV9++SVqfjHfoADugzIobzST2DWjOFWe27YJonWc53vvvRfBv+iii2JxTZUTOYCntQAHDO1ku+ULvjv//PNjCDvYQzE39957b/j0009jKfvOO+8MN954YxwVSEC8wt6KFStiV/6u79ylbQI8PDDnzZsX1qxZEydKaJ9JHaaBk3377bfj6HDehRdeGIl44YUXwqOPPhouv/zyQTFieuQasuyxY8dG7V66dGl0uhTAPTBLlEB96eGHH47mKFVIm0kMB72Zik9om4B0PzTUSGBmFNheffXVCNq7774bZ6WmTZsWwWez5Q0TJ07snw9IfQz0CXxm6/nnn4/AM3e2xx9/PI4kI8zG3Lj+OeecE0NjI4XZYt6USHKVyghgbjywSARAMlthoRKFSRhTiCqkJPmJDRs2RDPFXCWCGoHSh+lFGq5vdp7Gq/vwCdrqDwkpKUMy38IkUYhjgoAEHCIAZSPj++J7gDAhMmcaTZwHXM6Uj6DlzFOjOB/oygz6SLE+gIGvb+31jQTn6osAP/dIqLIR0AhcOmYaDheNAEwkZIQMVssHPHBpuX0E2PgATt33RgbA9+7dGwuCRkYiPN1Pbp8dJ+BIDwxAI6WMlirYKfYxb0A1gvgdNh8xyhkECf7G8SIqZwfsfmslwA2UFebEKAE2YIHM7Iiy+AcEIAYBzkOq73KfI+gaApgYgAI/mSAkSP74hlSKRgC/AvjkF8qSXMd5bRHgYQ1xD9ppcR1aDVimC/jMEf+CGN8R92SUMG18QO4mqK1SBEAsE5Td0spOCKAlcIDlcEU9EjwbkGk/0wNox4jwN+JYm5ylLQI4RrG4+gsT0ImIA/Aya2UFGo90pLD7Rp5Y37Vtoinz00jQzoKt3MsRbRHAHIhCPLzstxMkAFv54Z577omjjXnhZF955ZXogJkfecC2bdvi3LRpTfeBtJtuuinceuutOQ+A9qMgw/3BBx8MTz31VHxYpWVmqWox52wjcgfrS6+55pqo4fyABWAW6VqcO3fu3Gh+qr6HTvTXlhN2Q4Y6wB977LFYDHv55Zdjhkr7FM86IfzA/fffH5577rmo/UYJ02SN0PTp07N3vEVM2iZAZwAAyvXXXx+XHbLPimEmXABjwp0ZQZRkCmntCNNn6bmCXvI7+uQjJGfup1ukEgI8rIdOqyOAwBGyzeJ3nxw1P5HmCVIbcTw7zmGWFWC7lq3bpTICEhDCwSI4CmPss4xVhMKJJkEagoiJnLKihiQz1j6NgNQ2jYR0nPtn5QQ0PjCzU6VTRpi8w6tUyJZ/IAEZCfz77ruva5xwe8a4Ee2jcIwAo0kCJkEjzJ2Ei6/55ptvOpYUduLxOj4Cqr5pTp1DB7qIa3zffEOq+3D+N9xwQxwNVV+3U/11HQHKC17uMEHP5FgXRPvlBt4zMBmfe/2nSGbXEcDWi6TM9fItZtEkg0bGl19+GUcHYrpFuudOuwXRJu+zR0CTgFV9elcT0KkSeNUgH6m/bH2AiEa8r6RB2P6imGz58MMP4yIv9l82LTxVohYhNZ6vrWjJm/OKd87JQbIkIMX6Mmgr3WS9HGzKmgFH+9WV0hyxYyUQ+QHwbRK0FLaKnJSprU+yn8s8QZYEAMpEi015Oa1yS5kvImhwKk83arL2wlWCAEU65yLE+2z66RHQiFrhGMA0mMlgil588cVw7bXXxrCTiVHUQ4D6UWPIaSTQcqNBeAp0o8dEvUkd4A9kngqXP6q7WY6AhADzAjyV0lQttejKYl/lb7+7kzRdG+DzBX4theZ7D9mLI0aACRx/z02yj4JUPpPW2qfxyFBxbdRk2o40xMiOi6MjR/ApQ9YEAJSkT/tAT5vjRnFuinAaCWo8N4fjrAnIAaBO30OWPoDpEOez5zaOV2Tj++JoGAic4oSPPszGaZuWsGif08jIkgDRD+DlASQlZer9R7LlALdSOoEs8pGc+VQtXbVqVYysio57IBKP5ndZmiDhI0cqgpGEcb7EeiDbQELDrQ1KK+Vova2YvHkdVibsB0JykSwJAA5AAS8RswJP2dkisLRMsRFAYacStfOYKiVrEzeOla0tkUGqeWkjIhfJ0gQBJ5kawInn33zzzZiAWUXBnIh0vOJUDDWZHjYfyLRfBo0EpYcFCxbE2pLFW9oe7qWRo01MlgSw5UwNk+KdYGR4o555Yb/H901DEvuNThm4FmjJlolVGUjhR1KfVS4SiBdp458sCWB6RDPs/xdffBEJ4JRp89lnnx0LdIBn35N/SJGNNpZHensf4N5NRqQX/ZxrZCA4F8mSAFGQud477rgjgsWkrFy5Mq6GmzJlSvA7dORwQLL/2loh4VdYlC6uuuqqaHaYnpyWrGfrhDlVJgZ4jzzySNRmK55tALaJlgbalC6UKjhtZQs/7Oc37BTpgK9tLpLlCACOKAhwy5Yti+BZdwrMsjE8k4QAqyduv/32OBqeeOKJ6D+8wyyyykGyJcBcALutju9nD9j/ZOfLAschq4TSeo6XaeOcTeT0CBgERc5UyAkoDjm9fF1shpAUBSVy0rHzjBagMzmIsC8iKpYriv3VsZ/tCBDhCDtFMhZc8QmNUiTA34rHQlcO1ytUfseUGBGkSFL8osZ/siUAJpIsM1vMDy1OyVlKvhynfecXj9WEJF38SCLAOblJ1gTQWBos7GQ+mhEmS5g6kOlqpp9On5s1AR6ehiMimY+ygGiX/ELZNnWcl20eUAcYdVyzR0AdqBeu2SOgAEYduz0C6kC9cM0eAQUw6tjtEVAH6oVr9ggogFHHbo+AOlAvXLNHQAGMOnZ7BNSBeuGaPQIKYNSx2yOgDtQL1+wRUACjjt0eAXWgXrjmMUeAtUE5zYgdcwQUlC+L3WOSgJxGQNYzYibmvXD37LPPll4PlNTa6gdS5v+nSW3q+MyagHYAsTrOm5Qm9HOWQwgwPGmPX6Gtcw2l1cwW0npT/q677mp6Ur4Iumchnss6Uwt2j/byRNe0xKZRDiHAksDVq1eHBx544KAlH40NO31sYZYV0aIWb7cXl5+0em3vHFvmTrGaXWXR6jVTO8rkmmlhcfp+SJ/G9/9HjB7WehovQFTxwOkirXym2/JZ1b1YN5RWSqTPVu6t1TZWdlhMbIk96buHIf8H2Q7b7xDBgoQAAAAASUVORK5CYII="
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage012a",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage012a",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAFQAAABTCAYAAAABbiB5AAAAAXNSR0IArs4c6QAAAHhlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAACQAAAAAQAAAJAAAAABAAKgAgAEAAAAAQAAAFSgAwAEAAAAAQAAAFMAAAAAoKPJGAAAAAlwSFlzAAAWJQAAFiUBSVIk8AAACfhJREFUeAHtnUeIFE0Ux2vNOQfMGBFzwBzwoJjAjKgI5nzQgyAeVDwoiCKYEcGDGA8qiphRUDwYMOtFUcwBc87z1a+W11/P7HRP78x2Ty3sg9mqrvj636/qvap63ZsT06SKqMAQKCEt5eTkKH6QLRgXK1ZM/fv3T1i0PgQ3B1C4rVu3rqpfv35ojKcCiHwIEHm4XMMk18SLFy/uPGyuRQj+/v2rrly5orp3766+f/+ekv+yZcumLJdf4bp48WJuv5phQ/oqtnTpUrkMNZwxY0bg9q9evWrKjhw50rfOpk2bfPPDzgQ/KFckUj7Tgi3QpEmTwA0eOXLElD1w4IB68+aNatq0aZ66v3//VnPnzs2TnpUEeXK680gk9OTJk9JlynDSpEkpy1CgY8eOgcqFWQj8oMgldMqUKYEFR+ZUvwrNmjVTelrwKxJpXqSAvnz5Uj19+jTQDQ4ZMkRt377dt+zu3bvVtWvXVOPGjX3LRZkZKaDNmzcPdG9o6qNHj6p37955ll+3bp0aM2aMqlixonr48GGo1oknE0kyIgP08ePH6vPnz0lYyJu0cOFCk3j+/HnVsGFDderUKQMwIM+bN0/VrFlTtWnTRpUqVcqpjOTPnj1bIdl16tRR7du3V2vWrHHyo4rkMJHSGXaXNpvU8uXLQ+m7evXq6u3btynbLlmypEJrQ6NHj1ZVq1ZVpP369cvYoWKfYvcFmTt37typateurQYMGJCy70wKwJeBEkAh3VioWr5MmTK5Hfn8XbFiRezHjx/ml1js27dvscGDB8clf/nyJe7a60Ib/V5ZBZYOflBkQ75///4pBWDQoEGqdOnSqnXr1nnKJluCouGTpSdW7ty5c2JSaNeRATphwgTfm6hcubLq1KmTKXP//n21evXquPKyHF27dq2T/uLFC3Xjxg21ceNGJy0xcvr0abV58+bE5NCu49byofWiG9bD1bN5wLp161Zc/tSpU+OumUPLly9v5lN3hjbqFb9KlSqpT58+OVmPHj1SPXv2VM+ePVNBRodTMcNIZBJapUoVT1Yx4Bm+bkKJ7dmzR61fv94kM+kzHbRo0cJdzIkDJlaEnoMNsCg2vdJSNWrUUIAbGcmsrDsMVSn9+fNHukoabtu2LWk6iSNGjIi9fv06Nn78+Nj169c9y3ll6BEQ06aUV3aBpIMfFJmEYhv60fTp0z2zDx48aEwmpM5P0r0aQLqjktLIAGU1k4r27dvnWYQ9TwDlwaQzJ2LLRkGRAYpCYZnoR+PGjfPMZp5lDmV1hOYG1KD7AosWLcqj9Dw7yjAjMkDh8/3797mrCQ+m9RSURzlJUbQ8gAoBKqcLgDps2DBJNjvxy5YtU7Vq1VJjx441duqqVatU27ZtnTJhRiJbespNcKNawchlnhATauLEiWrXrl1K7+ybow+t0Mxw1wpJ9enTxyxDMdbnzJnj1B84cKCaOXOm6tGjhznKcTIiisjSMzI7VO7rwYMHEk0aMrTZlluwYIHZmrtz546zDtdLTSPlT548UYcPH44D9MSJE6Y9lNaHDx+Sth1JotH1jLWQzSbph1CviNyXnvHLly/HqlWrZvL10I7JWZSEXhVbtWrllRVaOvhBkc6hIiFbtmyRqG/IKezPnz9NGaYCTj0hpgA/QqpbtmzpVyS0vKwA2rVrVxUEVABFGUHMURz/QqzhWRH5kd887Vcv07ysAArT+/fvD8R7iRK50zy7+CKZehowa3r2S/v27auwURPp69eviUmRXGcNUMwetLaf7QkCeloyQGDUi9nE+pzhz0M5d+6cKcMxM44ObIiwW//8+fNIAEzsJHIt72agQ4cOau/evWrWrFnGftyxY4c728RlaCOdFSpUMGkMfzchxaNGjTI/d3o24lmTUPfNbt26VQHmzZs345aVzIMcgUCYU/ygREBNoiV/rABUsGjXrp1ZVnLa2aVLF6WPTZTMhSgnUVD6OESqWBdmdch7oYHS0TaoyZY5FHBFQUnoVT+b6VZJaDIgRLMjqWI2sdFiK0UGaLrznkgoBr4opWRmki0ARwZopjfMkGe1BMm8mmmbYdQvNICyQSyAuj1GwgAlkzYLDaCAKTapzKWZ3HhYdQsNoG7N7o6HBUy67TqAitGcbkNh1+OYGB8lSCQ17D7Tad8BNJ3KUdZxLz3FwI+y/6B9FRpAMZtEKZUrVy7o/UVezgE0rCGv395QjRo1MjdWr1491aBBg7RuEv4EUNqxlZylZ1iA4qQgRj1baosXL04LC7eE2mzYO4CmdZcBK7mdaFeuXBmw1v/F8H7Gmxl/J46NbVZKkQCKdDECevfu/T9K+Yhx7i5renzr/dx28tFsKEUdQMO07WTII2XpED6gbrJ5DnWUkpvhMOLszqdLHz9+NM4LAMmZe9HSUyPJ+0TpEt7NKDScZ3FksFkpORIa5pBPF0jqMfdy8Cbec0OHDi0cEhqW2ZQJmNRlP5RXtwkB9fjx447zQ6Zth1HfUUpiNIfRSSZtcly8YcMGc75EO/g38bOVHEDdDv82MSsjR2xPpibO6G0lZw61lcFkfInDQ7K8bKc5EpptRrz6FxtW8pHYog1mQSONMJk0Fg35NICUKonmHBJbdIws6KQZylEy1QHYVovE8JfmPUZWjVfC8bbD5x4Tavjw4VYfI1uvlFhm4kTGBwdQSKzrbSarzSa+5sAeAN8qOXPmjDp79qy6d++e6tatm7WYWg0omyHsLvF6DR55LD1xfcRV3FayesijgPBMZhXH90Z4x4nPYhSK3SYbnzjOYZxwIpmYShyBELfZt8lqCeXlLly9kUiOPggBNJmxb4tAOIDKJoQtjMFHr1691KtXr4znMkBCiUtRk2jRHwdQi3gyrLBex+4EQB42xjxxMeqRVlwceSHXJnIAFUZtYO7SpUtmExme0PIMcdkQ4T1PcZbgzN82cgC1aSghfXyUhfeOABdJ5JCP9Nu3b5s4/k18qs02cgBleNlCAKe/QWKGM1/LwXyaPHmyYW/JkiVq2rRpZuhbDag4EtgAKm+BzJ8/3zg3MOxFYQI0ryheuHDBSCrre1ZPNpGzUhKmbWBOv56t9JdwzIcDedCyhccoQtvzEQJWT6L5beDZ4UFvjRnSzIb6mSHpJ0ioPw1seNFMmvf43aE29k0a38E7dOhQkOYiKQOPkCOhDCdbiBWReIdoHs0RsoR87IoNkmPHjtl5+gmqEAhH9ZXw3B79/8oT9yultb9fdqR5wq8jobZIp/DRr18/iXqGNnoyWwuo30JDPhlkk+0sT91aQFN9NIsb0GNa7sOa0FpAg4BVJKHWyFF4jFgroeHdcrgtWwsofvmpKMi0kKqNgs53Nkdo+O7duyn/u0FBM+DVHhvLXv9pgQM78ljXe5XxajdVuszLPCzi+X1ocR8TTNVZUb4/AoD/H5Y/FuK/737DAAAAAElFTkSuQmCC"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage012b",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage012b",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAFQAAABTCAYAAAABbiB5AAAAAXNSR0IArs4c6QAAAHhlWElmTU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAACQAAAAAQAAAJAAAAABAAKgAgAEAAAAAQAAAFSgAwAEAAAAAQAAAFMAAAAAoKPJGAAAAAlwSFlzAAAWJQAAFiUBSVIk8AAACfhJREFUeAHtnUeIFE0Ux2vNOQfMGBFzwBzwoJjAjKgI5nzQgyAeVDwoiCKYEcGDGA8qiphRUDwYMOtFUcwBc87z1a+W11/P7HRP78x2Ty3sg9mqrvj636/qvap63ZsT06SKqMAQKCEt5eTkKH6QLRgXK1ZM/fv3T1i0PgQ3B1C4rVu3rqpfv35ojKcCiHwIEHm4XMMk18SLFy/uPGyuRQj+/v2rrly5orp3766+f/+ekv+yZcumLJdf4bp48WJuv5phQ/oqtnTpUrkMNZwxY0bg9q9evWrKjhw50rfOpk2bfPPDzgQ/KFckUj7Tgi3QpEmTwA0eOXLElD1w4IB68+aNatq0aZ66v3//VnPnzs2TnpUEeXK680gk9OTJk9JlynDSpEkpy1CgY8eOgcqFWQj8oMgldMqUKYEFR+ZUvwrNmjVTelrwKxJpXqSAvnz5Uj19+jTQDQ4ZMkRt377dt+zu3bvVtWvXVOPGjX3LRZkZKaDNmzcPdG9o6qNHj6p37955ll+3bp0aM2aMqlixonr48GGo1oknE0kyIgP08ePH6vPnz0lYyJu0cOFCk3j+/HnVsGFDderUKQMwIM+bN0/VrFlTtWnTRpUqVcqpjOTPnj1bIdl16tRR7du3V2vWrHHyo4rkMJHSGXaXNpvU8uXLQ+m7evXq6u3btynbLlmypEJrQ6NHj1ZVq1ZVpP369cvYoWKfYvcFmTt37typateurQYMGJCy70wKwJeBEkAh3VioWr5MmTK5Hfn8XbFiRezHjx/ml1js27dvscGDB8clf/nyJe7a60Ib/V5ZBZYOflBkQ75///4pBWDQoEGqdOnSqnXr1nnKJluCouGTpSdW7ty5c2JSaNeRATphwgTfm6hcubLq1KmTKXP//n21evXquPKyHF27dq2T/uLFC3Xjxg21ceNGJy0xcvr0abV58+bE5NCu49byofWiG9bD1bN5wLp161Zc/tSpU+OumUPLly9v5lN3hjbqFb9KlSqpT58+OVmPHj1SPXv2VM+ePVNBRodTMcNIZBJapUoVT1Yx4Bm+bkKJ7dmzR61fv94kM+kzHbRo0cJdzIkDJlaEnoMNsCg2vdJSNWrUUIAbGcmsrDsMVSn9+fNHukoabtu2LWk6iSNGjIi9fv06Nn78+Nj169c9y3ll6BEQ06aUV3aBpIMfFJmEYhv60fTp0z2zDx48aEwmpM5P0r0aQLqjktLIAGU1k4r27dvnWYQ9TwDlwaQzJ2LLRkGRAYpCYZnoR+PGjfPMZp5lDmV1hOYG1KD7AosWLcqj9Dw7yjAjMkDh8/3797mrCQ+m9RSURzlJUbQ8gAoBKqcLgDps2DBJNjvxy5YtU7Vq1VJjx441duqqVatU27ZtnTJhRiJbespNcKNawchlnhATauLEiWrXrl1K7+ybow+t0Mxw1wpJ9enTxyxDMdbnzJnj1B84cKCaOXOm6tGjhznKcTIiisjSMzI7VO7rwYMHEk0aMrTZlluwYIHZmrtz546zDtdLTSPlT548UYcPH44D9MSJE6Y9lNaHDx+Sth1JotH1jLWQzSbph1CviNyXnvHLly/HqlWrZvL10I7JWZSEXhVbtWrllRVaOvhBkc6hIiFbtmyRqG/IKezPnz9NGaYCTj0hpgA/QqpbtmzpVyS0vKwA2rVrVxUEVABFGUHMURz/QqzhWRH5kd887Vcv07ysAArT+/fvD8R7iRK50zy7+CKZehowa3r2S/v27auwURPp69eviUmRXGcNUMwetLaf7QkCeloyQGDUi9nE+pzhz0M5d+6cKcMxM44ObIiwW//8+fNIAEzsJHIt72agQ4cOau/evWrWrFnGftyxY4c728RlaCOdFSpUMGkMfzchxaNGjTI/d3o24lmTUPfNbt26VQHmzZs345aVzIMcgUCYU/ygREBNoiV/rABUsGjXrp1ZVnLa2aVLF6WPTZTMhSgnUVD6OESqWBdmdch7oYHS0TaoyZY5FHBFQUnoVT+b6VZJaDIgRLMjqWI2sdFiK0UGaLrznkgoBr4opWRmki0ARwZopjfMkGe1BMm8mmmbYdQvNICyQSyAuj1GwgAlkzYLDaCAKTapzKWZ3HhYdQsNoG7N7o6HBUy67TqAitGcbkNh1+OYGB8lSCQ17D7Tad8BNJ3KUdZxLz3FwI+y/6B9FRpAMZtEKZUrVy7o/UVezgE0rCGv395QjRo1MjdWr1491aBBg7RuEv4EUNqxlZylZ1iA4qQgRj1baosXL04LC7eE2mzYO4CmdZcBK7mdaFeuXBmw1v/F8H7Gmxl/J46NbVZKkQCKdDECevfu/T9K+Yhx7i5renzr/dx28tFsKEUdQMO07WTII2XpED6gbrJ5DnWUkpvhMOLszqdLHz9+NM4LAMmZe9HSUyPJ+0TpEt7NKDScZ3FksFkpORIa5pBPF0jqMfdy8Cbec0OHDi0cEhqW2ZQJmNRlP5RXtwkB9fjx447zQ6Zth1HfUUpiNIfRSSZtcly8YcMGc75EO/g38bOVHEDdDv82MSsjR2xPpibO6G0lZw61lcFkfInDQ7K8bKc5EpptRrz6FxtW8pHYog1mQSONMJk0Fg35NICUKonmHBJbdIws6KQZylEy1QHYVovE8JfmPUZWjVfC8bbD5x4Tavjw4VYfI1uvlFhm4kTGBwdQSKzrbSarzSa+5sAeAN8qOXPmjDp79qy6d++e6tatm7WYWg0omyHsLvF6DR55LD1xfcRV3FayesijgPBMZhXH90Z4x4nPYhSK3SYbnzjOYZxwIpmYShyBELfZt8lqCeXlLly9kUiOPggBNJmxb4tAOIDKJoQtjMFHr1691KtXr4znMkBCiUtRk2jRHwdQi3gyrLBex+4EQB42xjxxMeqRVlwceSHXJnIAFUZtYO7SpUtmExme0PIMcdkQ4T1PcZbgzN82cgC1aSghfXyUhfeOABdJ5JCP9Nu3b5s4/k18qs02cgBleNlCAKe/QWKGM1/LwXyaPHmyYW/JkiVq2rRpZuhbDag4EtgAKm+BzJ8/3zg3MOxFYQI0ryheuHDBSCrre1ZPNpGzUhKmbWBOv56t9JdwzIcDedCyhccoQtvzEQJWT6L5beDZ4UFvjRnSzIb6mSHpJ0ioPw1seNFMmvf43aE29k0a38E7dOhQkOYiKQOPkCOhDCdbiBWReIdoHs0RsoR87IoNkmPHjtl5+gmqEAhH9ZXw3B79/8oT9yultb9fdqR5wq8jobZIp/DRr18/iXqGNnoyWwuo30JDPhlkk+0sT91aQFN9NIsb0GNa7sOa0FpAg4BVJKHWyFF4jFgroeHdcrgtWwsofvmpKMi0kKqNgs53Nkdo+O7duyn/u0FBM+DVHhvLXv9pgQM78ljXe5XxajdVuszLPCzi+X1ocR8TTNVZUb4/AoD/H5Y/FuK/737DAAAAAElFTkSuQmCC"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage013",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage013",
      "contentType" : "image/jpeg",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAGoAAABqCAYAAABUIcSXAAAAAXNSR0IArs4c6QAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAABuFSURBVHhe7V0JPJTb+38xdoZBKVvRglIo1K1Ei0qbLu1o36WQJs3VYKpJynalVUkoW/ttXyzZiVa0kCVr9mUMxvg/xz/9qtvyWspy53w+78eY93nPec73+55znnOe55whODk5YZzU8xEg9HwVORoiBDhE9ZL3gEMUh6hegkAvUZPTojhE9RIEeomanBbVF4iqZjAmuh48uBXq0txL6tMb1SRcv3Pn2twZMy7TaLT671XgZy1qMDy4VFpa2qe4uJjZG1Ho4To3gX6WLS0t7ysw7AZ87jBRrfUsKioiA9uQFyd1NQIODg6r8OT5sxbVlgcXnsw4Mr8OAbxE/ToNODnjQoBDFC6Yul+IQ1T3c4BLAw5RuGDqfiEOUd3PAS4NOEThgqn7hThEdT8HuDTgEIULpu4X4hDV/Rzg0oBDFC6Yul+IQ1T3c4BLAw5RuGDqeiEqlcoDC93IfYRrHZVDVNdz8NMcgST9sEuXTe/eu78ahHl++gAIcIjCg1IXyAA53JDNogshoYuGDx9u0NDQSHSk0ZLfvnmthSd7DlGfoWRDoUwVIBCYGBvTInBjd+GWGFwfPopIwd8mFgsjXCZgj9NpNPa3ALal2K/C2GxFIT5CHGoIIDT46rV/FBYYGyumJCfPZTIbGiy2bfdzsKechftF69etzeQQBQgA+MObaggNoqIsXgKBIA9fvUcAVdTWTj979mzj6/T0wU9TUwm5ubmi9+7dH6uopGRQUlLMaGpi7X2VkZ4Dz7S+zGJiYsR+/ftjJJJEfUMD81VyUlI8fMclRiIBL2yspqoGq6ur4Y2OjdXh4SEMLy8rtS4uKhYtKMhvUVZW4VJVG/nMwnL7xl07dzyvYDJL4cK8XFwKmlms73p1Pyewz7QoS0tLIUFBkqCAAFYOFRSBCwEw1u/CBa3377LnpaSkiGdkpEmwWexhuXl5GIHAg0lKSTHycnPjhisrc/MLCLwmksTLhESEQxX4B+X269ePNzXl8a2Kigo04LPcvbzMcrKy2JlvM1uASD75QYNUiWJiA5MSE99wc3OzlRQVpWpqqnIHDBhQLywsfFdGZmCiA5VaOXv2bF54PpPFYtXS6fQMMCDwNKB/yfRKolB/DwAKeHl5MdpqJCoqOvrG3Zubnz5OnZyQmCCZ+eaN6Lt3WZiIiEiJjs4fLEkpUvJWy+2F6hqaNyeM034OzwnC1QDXcwAv/lvoWVlZffq6urw8kSQujmlpjf1CVHfChO8Cn5ycjKGrK1KvJAoqPlNQWFh1oIy8+tUrlxTz3udN8PDw4BmsOBgbra5ZMGzYUH+6s7OQ+sgR90H2OhBRjcD6UFyE3b9zq/XqbanXEAWtyDjhcco0V5eD8sOHK+vn5+eLqqmpMTU0NVPNV68+ucTEmALgVwEpLYgEIEkEPtf2NkK+p2+PI8qKbGdGFOB7DQoPSHr2YnSAr68KtBq5I0eP6vHy8GC6elNerV2/7uCunTtPg0wN9P3SMC4LQVfYAF1hK0ko/U6SrGztDMDmEOZmc6e6uNByfsXL0a1E2VCo40QIGDJPlVDljhw5omi5eaNhZWWVf1R4OCYkLIzJyMqmTp069aHFduvDY0eroTi490DKOyCibXzK+hXAtCdPohBfyTQDg7Dq6upIEolUAAZFGZPBzJ40ebKYuqZ6ZuSDBzHtye9bsr+cKBsbyjACgVXDIhBERAiEKlACvfWDTp48ybfbevuS8oryBTEx0WLFRUXiMjKyDS1c2LXlpqa+rq7ur4YqDYqDeUsVRH42uNFpGTeuXOpsfX/J87UslnBAwHnXW7dvi1ZXVOrcv38nU0BQeIKXp2epiopKg7b2lwZIR5TAS1RrlwLjBDI10Wc0y2Z9LFAAgJRwodHew30xeNOr0DrWx3uk5NSnmzIy0nXS09KkHycl8b18+UKyvLxcBKy0ejW1UTVaOuOKnWbOOr9s2bJCPgJ3Cjzf+vadD/D7bn3KysokPT09G1D3RiaTZQQEBIrg8zcnoB0Bpb3PuNHpsfAMulqTjo5O69/Ro0a2N6vvyuMiKi7hsVl/GZmaQ67uYlKSkqPLystaGpuaxKorq/kz376pYjWzpCEsd9BkPT3B2tpaYlBQsBi0FKypsRETJ0lgKirKzTU1NXfmzjeSIO+yS9CfopcGTL8FcAORZjnvMjFn+j5clUp79erMk8fJqw0NZzfy8vHxkXfbXfnLnloBL8faNkMCV0a9TAgXUVbbLf4G0FlCQsIEkqQkVvqhpBhm42XcPDzlQ5SUFLmauN6JEcXjlVVUKidOnKysMEi+HExnX2lJ4gP0pgOIfPC3ccG8ufxoIvkWlmKCaDQ0h2lXgnzUdSfrrdqwaUu2jdX2FQwGc+gJn1OLV5mbGxeXFBtJSfWL272b8nqKnu4NJhtTctlHO9WuAnqwMC6iEuLjVaEO+XChbg91a7wAfCkApwgB6eWitbX9CE0ihfCZp6Iiq1FGRoZYLyDAaOuOEEkIg6CgIEROuwlqw+/4SZ/p5eVlXEDSjuCLl8fz8PCQNm+yOGu9zTIEZNICg0NNvI94zaY5OlgL8PPH3bp96xWUHdWD8cetGi6iILcSqHDN17nCd+8+foeMhM9Tl+/8gJdixPQZBmbLlpsyYDuQsrqmZo2SghwWERVRdvny1f7W1tvZJcWFdWGhIfagyKDV69Y7RETFziaTqdlgMufiRqSHCuIlqlvVt6RShUGBRdlZ2Rpy5gp7KiqqCgrz8paqKA3ea7Z8+eCSoiK0ZUVOZJnpoA8V1cX+Z8/qFhcWNAxTHpZfj0ydPpB6BVEkDBPS15+iNWHSJPYqc1O2u4fXKksry1DAPx5IGgPm57QzPqfJG9atvet19NhcG+ttzy5fDjOSle53DGSQhdotCXoBAShYCK466H063OUj5Xs8UVBZEqORtbaZzdbVUFePySsqGaY8QjUJdG8KCA5OHK89/mje+9wlYEhgWtraG2HCWXTl0iU9WOHmysrJWUOSlkatDY2v3ZHmnPTxGQ4w80HhnToip8cTBctDwtu2WYz409jkYm1draKUlKSEkpLSPwkxCcU1VdXZMnKyBU3NrKyN69b98SIt3TI2NlbZmX5gpYgIkW26bJlrXGysNJlKPQ3zvIJfzRS8VOJQhoWvn/+4QwedZSMjH40ZMkQpY6np8oCigs4Nkz2eKPAv8YLLwnDx0iWplZU1xSePHxu0ecvW/uB4Gj9CfeTDBmbjIC8P99FmK1cmLzCaZy1KJIofOe5tO3Tw4IhDbm4hmppj7Pz8/Afa2tvfEOLmvglATs7OyRutIC+fzWCz0mGyCrOFzicgSY1ib3/w7t17s8aMGRN37NTJdXoTJ76FEZIf+r/66MjIThXS44mC2lXl5eUJcHPzDKytqn42UVevtIXNUknPSG9QkFFkP097ogkm++iI8HCRlavXOGzfueNkfS1LCsaETEsy2ch0mamFoeGsTQYzZjYednFO22ZlvQtamWELm53gcvjQYQqVqsCsZUo0EbAY8LgWdhTNtIwMxRcvX5YlJyYMgV6gOSLidiHogFZv/mUtd6SM3kCUkPmqlb7bLSxW60+bpjVQZkDMk6bmgWJEMZWqqg+viGKig7PevbtjvNCkDNzc7h+nEUUIDAD+PZDl/fRJ6ss5c+Zarly1ei44E+WSEhOwt2+zxtFoTqHurm7YfvoBTE2tdbkHV+jWt4BWGjw4+dLly8iDm90RIn72TI8nCir+HtDb9vzli+y9e/cLnTntMzs6+lGjnJycCnhvp/Xr178IJr78LHajEVT2X/EHiCz4PuDGjX9SDrm6UYODLgxhNbMxWTk5zOf0GaypqRFbscIcAx8XJijAj8G8q39u7uuqj5Pzn+H36b5LJ1ojnkJ6PFFtldhHo7mh132U2sh9cKEF4vHwb1NWTh7lxInj6olxicg/ZQbX429VHAhPg++XRsfE1Y4Zo7l2jz0VW7TIBGtp4cWMjP5ELvsWWNFvwbgb9/VTUkKm/zM8AP4umV5D1NeAfBbnYHKQvn8y/cBB1z8XLgy9HBa2Gu59c+QGcolllTU6ickpJWRb28Jjx46qH3ZzrzVdvjwDLMd0orh4zWg1tR1RsbH8NmTKGzcXeo9ZK+y1RH1OHFrPAxJ2OTjSHObNX3Ds+rUr1vDdnc9l4P5A+F9xruFMxeMnfALo+w95FZUWDttla+1dkF8o7+ntdWeynm5JYHDw/imTJ9Nu37171MrObqaHs/MX+fyuFvR1OX2CKFSpuobGmTD+qOlNnVI63cDA+/69e6hlPWqrMBNjNu6wsF0x/o8/XquPHoGMjteWNjZYcFCQyblz55ocqQ6PJCUkiv3P+R06HxKyyeTPP0/euHm7EuICc8GET+8ugtrK7RNEQWuRnjBx4koXl4P75s+fH37A2cVmlqFh5O1bt8aDqVxSDyQJYAIy8fHxGx8/TjZEJCEAvNzc0LiFoZjANWvWjLS3d9w1ZcrUo75+Z52PHT1ubjhrpv+D8IhCMDBK6+srmBCT0WFTG8qQhQg1AokEM0N4r5gsbPDLjBdScHIL+v+nqU8QxWSzzfn5+bmBpFBkJUKtV2zcspWhrq4Rc+/BQ3cRokT40mVmTmCio6OCbn+Nysf4wGwK1f5i9ts3Zfp6k9dQ7KmR7h7ue/R0J3k8e/okU1CAdLe9a0BADhGWtJCLZ3Jg6EXtyAf3phcVFOrHxsWya2tqwZ3HXQb3UHzhT1OfIKq4sIjIYNShIBn+tho/T3286fqNm9z79+3dStlDnVhYmKcddCHADYj6LiiHnekoDvB+9rvsu3r6eh7y8go6nl5el4xNFt5uuRjGD0+2+tXwpqdPX0zwOXPqxLUrVxXg4C9sgq5uztwFC2L3OO29oq05GoVXv+Ti4sIVOtsniJKXleGBRVlNqLgkXJ+C7s+e8dkArSJzgZHRJPAM7wKSgvCAjIyTyIjIrQdcDq+yI5PXw5JQ0dr1G56fPnVyBtz7aTgYdMXLIeTAeubM6VomJiax4dGPyDeuXAlGZRe9z8Nuoev6lTZVDuDRqU8QBX6MnLS0tHf5xcWzYCWiCCa5n1ZA4d7Duto6Z5iH7flRa/oGWAmb1ts+sd621X72nDk3oyIix8I+AQuXw4f96TQaCon+lCxt7OaRRPhaPkAcm5ODo72UlNQsaekBme7u7mO2bNmClpJaV0o6k/oEUQBAPdWBxjA0mEF99uzpCxj8W8Crm4eAsdy+fR50iy5oB0V7gAJw0eYAFDvIePjggYH/hQsedra2OxctWVIHAZeT+Lj5boFZgPIcQqc76z0Mf2gW/eiRNIyTzSEXL/tM1dN1hAVZ7q4gCendq4lCQTNQBxEr6x3OhYUF3DDhjRijpbUH9iEdg4E8AAZyEXUNDfO4xJQth533ISOjQwnAriCTKUcm/vFHuNH8+b6BQSG7/c6eOZybnWty459r2NChw2rV1Eefyy8siJMkkZLA0kSOwi71gf1youDtJrEILBkIvswB5WvBN0QC31DrIY0ANBd81wKxedIfAzSzP77JuAAF2cahKiO8P3woZsEcahcsVRfz8/FtHzdu3I6EhITIilqmsfSAgQOF+Lhx7UH6UaEuLvQkK1tbSdudO8mao0a4zDKck6+tMy7w5IljSbBHCm1YuwJdIq5Nabgq95XQLycKugfjnPzS2ak52U0qI9RYl0ND5QSEhN72HzBQ9bjP6TfDVFTqomPjizW1tBVFiAQv0C8FT0VsbGyGCYiINDvscZDR0RkfzWSxXgqwCMW2drvOKygMWguDebysnHyl4WzDWOj2svHk+TMZj8OHb8PLVR0VFVWmrKx8hslgUMG0/9ljXXK/U0SB0sjE1GEwG5WjY2Kkc3NyjO7eufO6paVZ6/mz5/y1tTVCrq6usEuPhDU3N5fX19cXysrKiZWWfuCRHjBAmpeXT6WwIL+OSBSTh+NQIRiNvQrj4mocra5B6N+/fwujvj5RaYgSH1cLVw5JQrwhKSXlAWTEBfkJRTyKpsJWP0kxURHsSWoqBls6l6OOnBuiQbPevubdaUexsti0gR4SHDQWWh7a3NYlCfKKPX3q1CxV1RExL9PTWuANOBBAo/3yCBq8RI21p1IlwILKr2Iw15w+frzg8ZMUTS0dnRF5OTnyDAaDh0gkVmtojmkWJ5EENdS1ns6cPSdkzsz5NwcOJKEBuQ4u1P2geMBPc5G2wEzUBcI9ObjKHR33y8rIDljb0Ngw/VVGRkPh+wJCSVmpfHFBEYubB9sB8w4sKzOTXfA+nw/NTcRgc1lm5hssN+89Bi4P4JmrNbS5H4nIA3JtZXcJSW2ZFBYysx2d9oavMF+xMsD/HK55UGcVwEUU2W63GexzNUhNTZWAuAV+tZFq9fCmv1RXVz/tSKU9njt3FjI/0XKMMoZVZNUyBTVFBATQTr7KrxT8YsLYRhoap0Cu1Urj5sZeL1po+jeGCdAFSRgR1ldQa0B66oHcNSQDxKL/0W606Q2NLMzAYBpmZmqKRUVFYvUNaMMHhvmc8R05fuKELBgM0SS4UxFAX4MMse6MJYtN9gcEnIuMiIiwAn0uQvfK+uj76iwn33weF1FgdqoOHaJ0Pigk+MVUff0EhCe0dQaBxRKFfanPUlIS2zJv8+F8WgztiNZeXi5tFtPngZ2tJKFUUYHx8/AzPPgIBF9Pz7/9Fi9eHNjSwsW3eu26pT6nfWLR2t8yUzP9hUuWHhBkMkXhkdYdh12VvLxoDFVV1RjXv/9ev8TY2ElGVmbGjevXvaHccniZPm1X7aryUD64iIqNid4JCkRGR0Vh6OruBEChrvQGAKNwKSw0/tLV6/IDB/Q/Zm1lM37jmvVNsGwjVlNTrWgyf25kV5vJbXVPT09nw3UaNmR/gN3uOhMn6YZdungFInPJmeDtbYsg7jKocBEFpfUob2db7YGE3CFDhpWHh4dzzZk146anh9triIsIffLixV4WnAgB91tXyX9lQt3xwUMHi58/eSKkp697K+JRlAeUt7Ory8RLVIeDPrpa4c/zg0mteEMzJr5g7pxhZsuWoB0jz/zO+uqHXrrkKykphYI0f0tyc3FJsKFSqwLPB+ZqaWjap71+U0sUEtgP+rTtIeu0HniJ6nRBvyIDmMNUQvc3FSKR0u/cC9+znmzpBeNXRVTkI6EZhoblOWAN/q4EB1tkjVRVvRISFqw0e+YMx+hHUaXwIvl+fsRCZ3Tp1UShiqOVDL9zAW7GC4yOxsXF7scEMKHMt29V9lCpoce9fx9RyII1s7Qs0xk/wQO2tkqAI9M0NibmnQ2ZnA4trtNjVq8nCpHVT7Jfqp6+/ouFCxfvDAsLecRg1PbrL0ny7swb3JFnA8ADvJRKbdiyaaNbclKym5n5ygsB/n5bYZ1QBJagvlhxb2/+fYIoOp2W4HyAThk1anQAzHbTGHUMdNAUWrD97Ql2UqK5YsqZ06coXt7HjTU0NPw2bbE4BF20PVg2XB/vt1uvPkHUxy7wH6qjw7rJurr+7wvyb0JX9KTdaHThA2ipCY5n+LB284YH5ouXHAkNDTE7H3jhHyDMFu61O/aizxCFMJ5nZPSuorzybmCA/xwABIWMuXch9u3OCo5cQIPkm4thoWOSnjwNXbZ86YZ+Uv2JwUHnL8JCRg5akcebaZ8iChZmX6xav9a3obFRZMq06ZvDH9xH64t+QFin3Rx4Af2OHENbQ33mw/v3+V3dPMPhNLNTO8jk8/AytUAU0qfTZn5URp8iCghpgMpft7TY/CYzM4sCLczp+tWrty0pFAEvOIKtk2B3+HHQ6/8XIDGMCf64DRZbLUfMmjFto7/f2SACgZeIJ+M+RdTHsQq50F96uB2ypjo4HRk37o/7CQlxqyFEWQJClD8d2oEHnF8hA07T5xQKlXH/fvibjLcZI0epqp7BU06fI6qt0vAWl1Ac/rpLFBMvhy2j1+Lj4vTgbZYCoNoVO4EHxPbKgJXa5glGTlJPPM/3WaJQ5V320X3IFMrTsWPH8mrr6Dx1dffcAl3jqa5c2sEDclfI9GmiWsmi05Mgfrw8NCzs/upVqwLD9afO2EtzfAX+I8/O7DDsCvDbk0efJwqBAYE17ySVlD48ioqS2Em2ez5x0qRpx44fRyfPnIfW9cs3YbeHkO/J/ieIAjKQe7566dKlvJTdzsr5+WlOWyy27OHl413o6e7traY2vBiOcsvrCbs2/tNEtVUetnsiM7kJukJfiFm+DmcrqdjutPLOy835APOuInEJCY99jg4lIJMPQa+FsPKNHJQ9Iv0nWtTXSEPLad1uA4c+lq5Zt2YVm8WSO3bilHRcdJQtrBfKCgkLtcyePTccjsPeBw4lIRaTWQBeW0Rgt6X/JFFtaLu5tRLWShpKaiNH/hUSHGxcU1M3cT+drqUzfvyrGQYznlOdHPfA7asoWgpamjCEq306Oe13MfefJupbIMN4hs5DvSQkyI8lxseLHTzsGrboT+MrcAh9jfUO2+Dly5elaoO5DzK45j9dRSSHqB8gCaRVQbDK8l22O8ry8vJXunm4T9phbbMWYjzHzDNaoL2bvPMayKCzAn954hD1E4hhbGr9EZXNFEoMSYzo+/Bh5HD0ax2LFi8OXmBsMj8kJHhUHYHg6vXvGMYuJY9DFE44j9HprRFNsPzT+vfC+fOW5wICp06epOtksd2q2s7e/mVjI5sB64kROLNslxiHqHbB9T9hCDyNBjO/dOHSJW8M9PT/unLxYsnFsJA9sHtlIOzN6vCZSt9Th0NUB4lCj4GZj1wnGQkJ8Xf3OzufHTdu/COHvbTZYB227jD8GKrdiRL+9yiHqC6AEQgpg5a0zXy5aZmZuVlgXExs7V4nx71giFzrqvkXh6guIAplAfvAckVFRSyiIiM3Uf7a46+treN99PixZvA9xbSNa98p6r/n4e0izDuUDYovhAfroNvjpu/fu2PFSvPkRQsXHlm3fn0IfIdOivlXWDh8rwwbsiXwFMhpUXhQaofMxwXgXOj2zj1/9izTwmJrqOW27VO9/vaMq29gfX0QsSC44nHlziEKF0ztF0Ln99na2lV6ex/BTpw8pWBsbKIQFnYRg8CbLzJrbsYXnv5DouDHFtHeIgyOChXHGy3T/ir13SeSkt6mBZ4/CucBGmHwU0XYsmVLMa8jRzD4zavWSjcIi2DsFvDAsOEHaSoqfvgjMD8kCn53QxN+WBEbNWpUJtqHy0ntQyA6+jomRvT/9BDa1gorGV9kAj9NgRF4eYUA344TtXzJkq1wWbZPPY70Zwigw+lbj2r4QRoM997D1XGiPotH46DfAQRg+2izoeGfw8Cd8s0ju8HgkITf/60FhyayGH+YOMbEzxDqxH3YOtoM13fPVQeDAx0DhytxiMIFU/cLcYjqfg5wacAhChdM3S/EIar7OcClAYcoXDB1v9D/AUtcf7PkN70sAAAAAElFTkSuQmCC"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Binary/binaryimage0014",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "binaryimage0014",
      "contentType" : "image/jpeg",
      "data" : "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/wAALCABhAGEBAREA/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/9oACAEBAAA/AOs8OeD9C1fTp72+tJJZ3v7tSwuZV4W4kUDAYAYAA/CtX/hXvhf/AKB0n/gXN/8AF0f8K98L/wDQOk/8C5v/AIuj/hXvhf8A6B0n/gXN/wDF0f8ACvfC/wD0DpP/AALm/wDi6P8AhXvhf/oHSf8AgXN/8XR/wr3wv/0DpP8AwLm/+Lo/4V74X/6B0n/gXN/8XR/wr3wv/wBA6T/wLm/+Lpv/AAgPhQttFi2fT7ZN/wDF0k3gPwjbxNLPZmKNeS73sygfiXrnfEWheFY/DOqXOj6bd3EkNlNJHcwTzGJCEJDh2cKwBHRSx9q6P7PD/wA8U/75FV/Cf9qQaRPNa+TdQHUL3Ns/yOv+kyZ2v0P0YdT94CtseJNJQFbu9isJl+/BeOsTr+BPI9xkHsTTh4j0Vvuarayf9c5Q/wDKj/hINL7XJb/dic/yFB1+w/hF3J/1zspn/khpP7Zab/jz0y/uD6vD5AH18zafyBo2a5c/fls7FehWNWnf6hjtAP1U0f2IsnN3qOoXLDoftJh/SLYD+IoPhvQ25k0izmb+/NCsjfmwJp50DRSu06RYlfT7MmP5UQaBottKJbfSLGGRejx2yKR+IFVfGf8AyI+vf9g24/8ARbVWp/gr/kAy/wDYRvf/AEplroKKKKhubq3srd7i7njt4UGWklcKq/UmuP8AEXxB0xNEuW0PUTLeIV2PHbPIg+cZ+Yrt6ZHWjR/HSmIG8tdYnzDG+8aa5AY53fdXpwMfjXXWF5HqFjDeQrIscy7lEiFGH1B6VYqJjcecAiR+Xxli5z+WP61leM/+RH17/sG3H/otqrU/wV/yAZf+wje/+lMtdBRRRXIWdlF4m8WandaoonttJnW3tLSTlFbaGaQr0JO7gnoK6PVNLtdX02TT7pW8iTbuCNtPBBHI9wKTTtLh01NsUkjjYkY3kcKucDgD1NXaKo3erWtpN9my890RkW8C75MdiR/CP9piB71h+LZ9Xn8Ga4zWVvawHTrgkSTF5ceW2QVUbQfoxqemeDby1i0OdZLmJGXUL0sGcAj/AEmTrV4+IrSS4QWvn3MAyWnt7aSaNj/dVlBBOepzxjH0l/tW4l4tNJvJM9HlCwqPruO78lNG3XpuTLp9n6oI3uD/AN9ZT/0Gg6ZfPy2vXqn0jigA/WMn9a53VdF1jQdRk1zS7/UL2O52/wBowRpAZnCjCug8vBIHUYyeOa0dJ1X+2Yg+keJbe5P8UdxbAyJ/vKrIR+VaQi10db7T3/7c3X/2oaDFrpH/AB/aenubR2/9qCmCwvLri61mRl/ijtEWFWH1+Zx9Qwq7Z2NtYQmK1hWNSdzY5Lt3ZieWJ7k8ms3xn/yI+vf9g24/9FtVaqGipa23g3UtRe0gklt7nUJQzxqxys8pHUe1aF7ZXlnHAp1W6lWX5JVYKTvIwHUgAggkHHT29W6wYZVsvtbTXNkl2v2iK5tSFZWDIM/KFIDOrcjjbntTbzSdRhk26N58NqmTJZfaBHHL6CNwC0Z9hhfpnNLY2GnXkBnTR185GKSOJ2+1RuOqtI2HzyP4uQQQSCDTo5Na0+8kFtaXE9iqLtjvJ1Zwec7WXcxAGPv5JJ6gDllzpnhzxGhuNW0IxTZwzXNuY3GP+mi9R/wKq8HgzwbPIYrYlmXrHFqUpx+AerH/AArrwmTl9JEp/wCms8r/AM2NDfDrwg3XQ4B9GYfyNNk8CWduu7RNS1LSJV5Xybp3jJ/2kckEe3FZWp61qH/CN+JfD+urH/aNvpFxNHPEMJdReWw3gdiDwR69K2qoaUjv4Hu2RS4i1O6meMDJkRLx3dAO+5VIx3zW9rUL3mk+faEySQlbiJUbHnbeduR03DgEdCQeelV9TEcnh6S4tLqR7eeNcBiJVkRiAc7weCDTkuJvD6xw39w1xp+Qkd5KfniJ4CynuM4Af/vr+8ZtQ0OG8uhfQlILwKF8xohIsijoHU9QOxBBHYgE5r/ZNWjO021vOB/GuoTR5/4AVYD6ZNHn6tC2ZLO+Yf8ATGS3dR9c7WP4c14P4lju5/HWqz3cEy5d2BmhaMlC52Ha3OMDirega9ruk3qz6GJbqVFObdUeVGXodyqeg459cV1tz8UvFdtb2qXHh9bW4kV8tLBIBLz8pVDgjHQ8nOe1dnB4/wBPeLdc6ZrNo/8Acm06TP8A46CP1rn/ABJLP4ji1XWIdPurSxsNDvI/OuojE1w7xngKedoAzn1rpqf4K/5AMv8A2Eb3/wBKZKn0W6gsoo9FncQ3FuWigjfgyRKTsK5+98m3OM4Oc0t54YsLhHFrv055DmR7MKnmf7ykFWPHUjI7HrUh8OaZMp+3Qf2izdTfHzhn1Ct8q/8AAQBU2jwzW2nrbTBv3DvHGWOSYwxEfPf5dvNXqKo6jYNdeVPbOkV5btuhlZcjB+8hx/Cw4Pvg9VFQLqclsxa/0m4gc8GW2Q3CN9Ng34+qih9b0G4IhnvrPcxH7q4dVbIOR8rYPUDtWoCGUMpBB5BHesbxn/yI+vf9g24/9FtVan+Cv+QDL/2Eb3/0plraurS3vYGguoI5omxlJFBHHSs/bfaOfk87ULH+6Tvng+hPMi/X5/8AezgXLPU7LUNwtblJGT78ecPGfRlPKn2IFWqKKKKayq6lWUMpGCCMg1nN4d0nJaGyW1djlntGa3Zvq0ZBP41keLrG/tfButmHU3mh/s+43xXUYYhfLbhXXaQfdt1T0/wV/wAgGX/sI3v/AKUy10FFVbzTLDUNpvLOC4KfcaSMMU9wTyD9Krf2J5QxaanqNtnrifzv/RofH4Uv2DVIx+51lpD/ANPNsjj/AMc2UmdehGNmnXfvue3/AExJ/Og6rc2p/wCJhpk0Sf8APW3PnoPqAN/47ce9XbW7tr2AT2lxHPEeA8bhh+YqaisXxn/yI+vf9g24/wDRbVWp/gr/AJAMv/YRvf8A0plroKKKKKKKoXWj2tzObqPfa3ZH/HzbnY5x03dnA9GBHtUQuNWseLm1W/iH/La1wkg/3o2OPxViT2UVPa6xYXk3kRXAW4xnyJVMcuPXYwDY98VS8Z/8iPr3/YNuP/RbVWqn4T17RrLSJ7e71axt5l1C93Ry3KKwzcyEZBOelbX/AAlPh7/oPaZ/4GR/40f8JT4e/wCg9pn/AIGR/wCNH/CU+Hv+g9pn/gZH/jR/wlPh7/oPaZ/4GR/40f8ACU+Hv+g9pn/gZH/jR/wlPh7/AKD2mf8AgZH/AI0f8JT4e/6D2mf+Bkf+NH/CU+Hv+g9pn/gZH/jR/wAJT4e/6D2mf+Bkf+NQ3WueE76HybzVdHuI852S3ETDPrgmud8UX+jx+EtYj0zxVasr2E6/ZZbtLgPlG4Ult4Y9B8xA/u1tVgX/APyELn/rs/8AM1BRRRRRRRRRQeld7X//2Q=="
    }
  }]
}

```
