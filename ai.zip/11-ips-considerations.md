# IPS Considerations - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **IPS Considerations**

## IPS Considerations

As for the IPS, we need to take into account the current IG is R4 based. On par with this, several entities still have their IPSs in the R4 format. This creates a potential problem since the ePI is R5 and handling both versions in a single collection is due to break.

For the purpose of this project, we updated the resources in a R4 IPS to comply with the R5 specification in order to test out the pipeline. In a real production environment, this could be addressed with mappings, updates to content or a more IPA like approach to the data.

**The data is linked to epi according to the table below**

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| gravitate-Matilda | 9d7be868-8264-4d94-ad04-ef04ecc92e51 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/03/256/022 | Humira 40 mg | Humira 40 mg Solution for injection Subcutaneous use pre-filled syringe (glass) |
| gravitate-Matilda | 9d7be868-8264-4d94-ad04-ef04ecc92e51 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xe72f98caa2b13cb3ccb489a1a7945c91 | Humira 40 mg solution for injection in pre-filled syringe 2 pre-filled syringes + 2 alcohol pads | Humira 40 mg Solution for injection Subcutaneous use pre-filled syringe (glass) |
| gravitate-Matilda | 9d7be868-8264-4d94-ad04-ef04ecc92e51 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | L04AB04 | adalimumab |   |
| gravitate-Matilda | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7et | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | PL31654/0006 | DOLOCATIL 1 g tablets |   |
| gravitate-Matilda | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7et | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xE857DA811B4A6F3BD57810C45D2EA1ED | Paracetamol 1g tablets | DOLOCATIL 1 g tablets |
| gravitate-Matilda | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7et | [http://www.whocc.no/atc](http://www.whocc.no/atc) | N02BE01 | paracetamol |   |
| gravitate-Matilda | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7eu | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | 77022 | Pentasa Slow Release Tablets 1g |   |
| gravitate-Matilda | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7eu | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E827xx | Mesalazine, 1g, Tablets | Pentasa Slow Release Tablets 1g |
| gravitate-Matilda | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7eu | [http://www.whocc.no/atc](http://www.whocc.no/atc) | A07EC02 | mesalazine |   |
| gravitate-Cecilia | b50ae644-e0b7-4007-809f-26f493cbe36c | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/17/1201/002 | Skilarence 120 mg gastro-resistant tablets | Skilarence 120 mg gastro-resistant tablets |
| gravitate-Cecilia | b50ae644-e0b7-4007-809f-26f493cbe36c | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0x9982CA8A825D4561506CE808982E3B9D | dimethyl fumarate, 30 mg/ 1 tablet, Gastro-resistant tablet |   |
| gravitate-Cecilia | b50ae644-e0b7-4007-809f-26f493cbe36c | [http://www.whocc.no/atc](http://www.whocc.no/atc) | L04AX07 | dimethyl fumarate |   |
| gravitate-Cecilia | de131e15-ed13-4b31-b38c-3204a84d99c4 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/97/049/001 | Karvea 75 mg/ 1 tablet, Tablet | Karvea 75 mg tablet blister x28 |
| gravitate-Cecilia | de131e15-ed13-4b31-b38c-3204a84d99c4 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | C09DA04 | irbesartan and diuretics |   |
| gravitate-Cecilia | 9ac3356c-4ea4-4814-84c3-235484f2ef19 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | 16028/0340 | Boots Decongestant 0.05% w/v Nasal spray |   |
| gravitate-Cecilia | 9ac3356c-4ea4-4814-84c3-235484f2ef19 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E82234 | Oxymetazoline hydrochloride, 0.5 mg/ 1 ml, Nasal spray, solution |   |
| gravitate-Cecilia | 9ac3356c-4ea4-4814-84c3-235484f2ef19 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | R01AA05 | oxymetazoline |   |
| gravitate-Pedro | 9d7be868-8264-4d94-ad04-ef04ecc92e52 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/19/1370/001 | Dovato 50 mg/300 mg 30 tablets | Dovato 50 mg/300 mg film-coated tablets |
| gravitate-Pedro | 9d7be868-8264-4d94-ad04-ef04ecc92e52 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0x073AF2E5B92AE19E8B67635AFFB3D6CA | lamivudine and dolutegravir, 300 mg/50 mg, tablets | Dovato 50 mg/300 mg film-coated tablets |
| gravitate-Pedro | 9d7be868-8264-4d94-ad04-ef04ecc92e52 | [http://snomed.info/sct](http://snomed.info/sct) | 787165000 | Dolutegravir- and lamivudine-containing product in oral dose form |   |
| gravitate-Pedro | 9d7be868-8264-4d94-ad04-ef04ecc92e52 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | J05AR25 | lamivudine and dolutegravir |   |
| gravitate-Pedro | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7e4 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | PL31654/0006 | MIRTAZAPINA CINFA 30 mg Coated Tablet |   |
| gravitate-Pedro | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7e4 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0x6c47381b040e5b588db23b2272f28eec | mirtazapine 30 mg, tablets | MIRTAZAPINA CINFA 30 mg Coated Tablet |
| gravitate-Pedro | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7e4 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | N06AX11 | mirtazapine |   |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda7785g | [https://cima.aemps.es/ids](https://cima.aemps.es/ids) | 68290 | CALCIO/VITAMINA D3 ROVI 1000 mg/880 UI COMPRIMIDOS EFERVESCENTES | Calcio/Vitamina D3 ROVI 1000 mg/880 UI comprimidos efervescentes |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda7785g | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E82716 | Calcium Vitamin D | Calcio/Vitamina D3 ROVI 1000 mg/880 UI comprimidos efervescentes |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda77854 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | xxxxxx | BLASTON 1 mg tablets |   |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda77854 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xbb82cd10ab2add752b2b9224931077b2 | cinitrapide 1 mg tablet | BLASTON 1 mg tablets |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda77854 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | A03FA08 | Cinitapride |   |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda77855 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | yyy | AQUILEA ARTICULACIONES COLAGENO Y MAGNESIO 375GR |   |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda77856 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | kkk | SORIA NATURAL VITAMINA C 36 COMPRIMIDOS |   |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda77856 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | A11GA01 | ascorbic acid (vit C) |   |
| gravitate-Pedro | 6f4151e9-91f6-4f1e-adc3-fb94dda77857 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | zzzz | NATURES PLUS SPIRU-TEIN BATIDO PROTEINA SABOR COOKIES 525GR |   |
| gravitate-ips-4 | b50ae644-e0b7-4007-809f-26f493cbe362 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/13/853/001 | Remsima 100 mg powder for concentrate for solution for infusion | Remsima 100 mg powder for concentrate for solution for infusion |
| gravitate-ips-4 | b50ae644-e0b7-4007-809f-26f493cbe362 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E82718 | Infliximab 100 mg powder for concentrate for solution for infusion | Remsima 100 mg powder for concentrate for solution for infusion |
| gravitate-ips-4 | de131e15-ed13-4b31-b38c-3204a84d99c2 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/97/049/001 | Karvea 75 mg/ 1 tablet, Tablet | Karvea 75 mg tablet blister x28 |
| gravitate-ips-4 | de131e15-ed13-4b31-b38c-3204a84d99c2 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E82719 | Irbesartan, 75 mg/ 1 tablet, Tablet | Karvea 75 mg tablet blister x28 |
| gravitate-ips-4 | de131e15-ed13-4b31-b38c-3204a84d99c2 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | C09DA04 | irbesartan and diuretics |   |
| gravitate-ips-4 | 9ac3356c-4ea4-4814-84c3-235484f2ef12 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/96/007/035 | Humalog Mix50 KwikPen 100 U/ml 5 pre-filled pen | Humalog Mix50 Insulin KwikPen, 100 U/ml, Suspension for injection 3ml pre-fill |
| gravitate-ips-4 | 9ac3356c-4ea4-4814-84c3-235484f2ef12 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E82717 | Insulin Lispro 100 U/ml 5 pre-filled pen | Humalog Mix50 Insulin KwikPen, 100 U/ml, Suspension for injection 3ml pre-fill |
| gravitate-helen | 9d7be868-8264-4d94-ad04-ef04ecc92e50 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/96/007/035 | Humalog Mix50 KwikPen 100 U/ml 5 pre-filled pen | Humalog Mix50 Insulin KwikPen, 100 U/ml, Suspension for injection 3ml pre-fill |
| gravitate-helen | 9d7be868-8264-4d94-ad04-ef04ecc92e50 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E82717 | Insulin Lispro 100 U/ml 5 pre-filled pen | Humalog Mix50 Insulin KwikPen, 100 U/ml, Suspension for injection 3ml pre-fill |
| gravitate-helen | 9d7be868-8264-4d94-ad04-ef04ecc92e50 | [http://snomed.info/sct](http://snomed.info/sct) | 388454007 | Product containing insulin lispro (medicinal product) |   |
| gravitate-helen | 9d7be868-8264-4d94-ad04-ef04ecc92e50 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | A10AD04 | insulin lispro |   |
| gravitate-helen | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7e3 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | PL31654/0087 | Monuril |   |
| gravitate-helen | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7e3 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xE857DA811B4A6F3BD57810C45D2EA1RF | Fosfomycin, 3g, Granules for oral solution |   |
| gravitate-helen | fdb5c97f-0a46-41ba-bc34-2efd2ef2f7e3 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | J01XX01 | fosfomycin |   |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78367 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/18/1326/001 | Flucelvax | Flucelvax Tetra - suspension for injection in pre-filled syringe Influenza vaccine (surface antigen, inactivated, prepared in cell cultures) |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78367 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xbb82cd10ab2add752b2b9224931000k2 | Flucelvax |   |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78367 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | A03ku92 | Flucelvax |   |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda79261 | [https://cima.aemps.es/ids](https://cima.aemps.es/ids) | 79963 | HIP√âRICO ARKOPHARMA c√°psulas duras | HIP√âRICO ARKOPHARMA c√°psulas duras |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda79261 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xbb82cd10ab2add752b2b9224931099j1 | St. John's Wort (HIP√âRICO ARKOPHARMA) hard tablet |   |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda79261 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | A03FA02 | HYPERICUM PERFORATUM WHOLE |   |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda7785h | [https://cima.aemps.es/ids](https://cima.aemps.es/ids) | 68290 | CALCIO/VITAMINA D3 ROVI 1000 mg/880 UI COMPRIMIDOS EFERVESCENTES | Calcio/Vitamina D3 ROVI 1000 mg/880 UI comprimidos efervescentes |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda7785h | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E82716 | Calcium Vitamin D | Calcio/Vitamina D3 ROVI 1000 mg/880 UI comprimidos efervescentes |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78367 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/18/1326/001 | Flucelvax | Flucelvax Tetra - suspension for injection in pre-filled syringe Influenza vaccine (surface antigen, inactivated, prepared in cell cultures) |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78367 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xbb82cd10ab2add752b2b9224931000k2 | Flucelvax |   |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78367 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | A03ku92 | Flucelvax |   |
| gravitate-Alicia | 9d7be868-8264-4d94-ad04-ef04ecc92i99 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/18/1289/001 | Biktarvy 30 mg/120 mg/15 mg film-coated tablets | Biktarvy 50 mg/200 mg/25 mg film-coated tablets |
| gravitate-Alicia | 9d7be868-8264-4d94-ad04-ef04ecc92i99 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0x073AF2E5B92AE19E8B67635AFFB3D9nq | Biktarvy 30 mg/120 mg/15 mg film-coated tablets |   |
| gravitate-Alicia | 9d7be868-8264-4d94-ad04-ef04ecc92i99 | [http://snomed.info/sct](http://snomed.info/sct) | 774856007 | Product containing only bictegravir and emtricitabine and tenofovir (medicinal product) |   |
| gravitate-Alicia | 9d7be868-8264-4d94-ad04-ef04ecc92i99 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | J05AR20 | emtricitabine, tenofovir alafenamide and bictegravir |   |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78356 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | 39.955 | Carbamazepine 200 mg tablets | Tegretol 200 mg tablets |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78356 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | xxx | Carbamazepine 200 mg tablets |   |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78333 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/98/071/004 | Orlistat 60 mg capsule | Xenical 120mg hard capsules |
| gravitate-Alicia | 6f4151e9-91f6-4f1e-adc3-fb94dda78333 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | xxx | Orlistat 60 mg capsule |   |
| gravitate-maria | b50ae644-e0b7-4007-809f-26f493cbe36b | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/17/1201/002 | Skilarence 120 mg gastro-resistant tablets | Skilarence 120 mg gastro-resistant tablets |
| gravitate-maria | b50ae644-e0b7-4007-809f-26f493cbe36b | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0x9982CA8A825D4561506CE808982E3B9D | dimethyl fumarate, 30 mg/ 1 tablet, Gastro-resistant tablet |   |
| gravitate-maria | b50ae644-e0b7-4007-809f-26f493cbe36b | [http://www.whocc.no/atc](http://www.whocc.no/atc) | L04AX07 | dimethyl fumarate |   |
| gravitate-maria | de131e15-ed13-4b31-b38c-3204a84d99c7 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | EU/1/97/049/001 | Karvea 75 mg/ 1 tablet, Tablet | Karvea 75 mg tablet blister x28 |
| gravitate-maria | de131e15-ed13-4b31-b38c-3204a84d99c7 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0x8DFB446EDB3B8AE508AE493827A704E4 | Irbesartan, 75 mg/ 1 tablet, Tablet |   |
| gravitate-maria | de131e15-ed13-4b31-b38c-3204a84d99c7 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | C09DA04 | irbesartan and diuretics |   |
| gravitate-maria | 9ac3356c-4ea4-4814-84c3-235484f2ef10 | [https://spor.ema.europa.eu/pmswi](https://spor.ema.europa.eu/pmswi) | 16028/0671 | Boots Decongestant 0.05% w/v Nasal spray |   |
| gravitate-maria | 9ac3356c-4ea4-4814-84c3-235484f2ef10 | [https://www.who-umc.org/phpid](https://www.who-umc.org/phpid) | 0xF79CABF272B6A7EEF104DDDA44E88901 | Oxymetazoline hydrochloride, 0.5 mg/ 1 ml, Nasal spray, solution |   |
| gravitate-maria | 9ac3356c-4ea4-4814-84c3-235484f2ef10 | [http://www.whocc.no/atc](http://www.whocc.no/atc) | R01AA05 | oxymetazoline |   |

### Local IPS

Here are two methods of using user based edits on the app with IPS retrieved from server. Please be aware that PV server and IPS server may be the same instance or different instances, depdending on the situation

