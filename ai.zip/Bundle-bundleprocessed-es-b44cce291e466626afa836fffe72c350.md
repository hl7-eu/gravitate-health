# [Processed] ePI document Bundle for biktarvy-es Package Leaflet for language es - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **[Processed] ePI document Bundle for biktarvy-es Package Leaflet for language es**

## Example Bundle: [Processed] ePI document Bundle for biktarvy-es Package Leaflet for language es

**Composition category:**processed

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

**Prospecto: información para el usuario**

**Biktarvy 50 mg/200 mg/25 mg comprimidos recubiertos con película**

bictegravir/emtricitabina/tenofovir alafenamida

**Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.**

* Conserve este prospecto, ya que puede tener que volver a leerlo.
* Si tiene alguna duda, consulte a su médico o farmacéutico.
* Este medicamento se le ha recetado solamente a usted, y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.
* Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver sección 4.


#### What is in this leaflet

 

**Contenido del prospecto**

1. Qué es Biktarvy y para qué se utiliza
1. Qué necesita saber antes de empezar a tomar Biktarvy
1. Cómo tomar Biktarvy
1. Posibles efectos adversos
1. Conservación de Biktarvy
1. Contenido del envase e información adicional


#### 1. Qué es Biktarvy y para qué se utiliza

 

Biktarvy contiene tres principios activos:

* **bictegravir,** un medicamento antirretroviral conocido como inhibidor de la transferencia de las hebras de la integrasa (INI)
* **emtricitabina,** un medicamento antirretroviral de un tipo conocido como nucleósido inhibidor de la transcriptasa inversa (ITIAN)
* **tenofovir alafenamida,** un medicamento antirretroviral de un tipo conocido como nucleótido inhibidor de la transcriptasa inversa (ITIANt)

Biktarvy es un comprimido único para el tratamiento de la infección por el virus de la inmunodeficiencia humana 1 (VIH-1) en adultos.

Biktarvy reduce la cantidad de VIH presente en el organismo. Esto mejora el sistema inmunitario y disminuye el riesgo de desarrollar enfermedades asociadas con la infección por el VIH.


#### 2. Qué necesita saber antes de empezar a tomar Biktarvy

 

**No tome Biktarvy**

* **Si es alérgico a bictegravir, emtricitabina, tenofovir alafenamida** o a alguno de los demás componentes de este medicamento (incluidos en la sección 6 de este prospecto).
* **Si actualmente está tomando alguno de los siguientes medicamentos:**

Si está tomando alguno de estos medicamentos,
**no tome Biktarvy y consulte a su médico**
**inmediatamente.**
**Advertencias y precauciones**

**Consulte a su médico antes de empezar a tomar Biktarvy:**

* **Si tiene problemas hepáticos o antecedentes de enfermedad hepática, incluida la hepatitis.** Los pacientes que padecen de enfermedades hepáticas, como la hepatitis B o C crónica, y están en tratamiento con antirretrovirales tienen más riesgo de presentar complicaciones hepáticas graves y potencialmente mortales. Si tiene infección por el virus de la hepatitis B, su médico evaluará detenidamente la mejor pauta terapéutica para usted.
* **Si tiene hepatitis B.** Los problemas hepáticos pueden empeorar después de dejar de tomar Biktarvy.
* No deje de tomar Biktarvy si tiene hepatitis B. Hable antes con su médico. Puede consultar más detalles en la sección 3, **No interrumpa el tratamiento con Biktarvy.**

**Mientras esté tomando Biktarvy**

Una vez que empiece a tomar Biktarvy, esté atento a:

* **Signos de inflamación o infección**
* **Dolor articular, rigidez o problemas óseos**

**Si nota cualquiera de estos síntomas, informe a su médico inmediatamente.**
Puede consultar
más información en la sección 4,
**Posibles efectos adversos**
.
Aunque no se han observado problemas renales con Biktarvy, existe la posibilidad de que pueda experimentar problemas renales si toma Biktarvy durante un periodo de tiempo prolongado.

Mientras esté tomando este medicamento **aún puede transmitir el VIH a los demás,** aunque un tratamiento antirretroviral eficaz reduzca el riesgo. Consulte a su médico sobre qué precauciones son necesarias para no infectar a otras personas. Este medicamento no es una cura para la infección por el VIH. Mientras usted esté tomando Biktarvy podrá seguir padeciendo infecciones u otras enfermedades asociadas con la infección por el VIH.

**Niños y adolescentes**

**No administre este medicamento a niños y adolescentes menores de 18 años de edad.** No se ha estudiado todavía el uso de Biktarvy en niños y adolescentes menores de 18 años de edad.

**Otros medicamentos y Biktarvy**

**Informe a su médico o farmacéutico si está tomando, ha tomado recientemente o pudiera tener que tomar cualquier otro medicamento.** Biktarvy puede interaccionar con otros medicamentos. Como consecuencia, los niveles sanguíneos de Biktarvy o de otros medicamentos se pueden ver afectados. Esto puede impedir que sus medicamentos funcionen correctamente o empeorar sus posibles efectos adversos. En algunos casos, su médico puede tener que ajustar la dosis o comprobar sus concentraciones sanguíneas.

**Medicamentos que nunca se deben tomar con Biktarvy:**

* **rifampicina** utilizada para tratar algunas infecciones bacterianas como la tuberculosis
* **hierba de San Juan** (**Hypericum perforatum**, hipérico), un medicamento a base de plantas utilizado para la depresión y la ansiedad, o productos que lo contengan**.**

Si está tomando alguno de estos medicamentos,
**no tome Biktarvy e informe a su médico**
**inmediatamente.**
**Consulte con su médico si está tomando:**

* **medicamentos utilizados para tratar el VIH y/o la hepatitis B** que contengan:
* **antibióticos, utilizados para tratar las infecciones bacterianas**, que contengan:
* **antiepilépticos,** utilizados para tratar la epilepsia, que contengan:
* **inmunosupresores,** utilizados para controlar la respuesta inmunitaria del organismo tras un trasplante, que contengan ciclosporina
* **medicamentos para la curación de úlceras** que contengan sucralfato

**Informe a su médico si está tomando alguno de estos medicamentos.**
No interrumpa su
tratamiento sin consultar con su médico.
**Consulte a su médico o farmacéutico si está tomando:**

* **antiácidos** para tratar úlceras estomacales, acidez estomacal o reflujo ácido, que contengan hidróxido de aluminio y/o de magnesio
* **suplementos de minerales** o **de vitaminas,** que contengan magnesio o hierro

**Consulte a su médico o farmacéutico antes de tomar Biktarvy**
si está tomando alguno de estos
medicamentos.
**Antiácidos y suplementos de magnesio:** tendrá que tomar Biktarvy al menos 2 horas **antes** de tomar los antiácidos o suplementos que contengan aluminio y/o magnesio. O puede tomar Biktarvy junto con alimentos al menos 2 horas **después** de la toma del antiácido o suplemento que contenga aluminio y/o magnesio.

**Suplementos de hierro:** tendrá que tomar Biktarvy al menos 2 horas **antes** de tomar los suplementos de hierro o puede tomarlos todos juntos con alimentos.

**Embarazo y lactancia**

* Si está embarazada o en periodo de lactancia, cree que podría estar embarazada o tiene intención de quedarse embarazada, consulte a su médico o farmacéutico antes de utilizar este medicamento.
* Informe a su médico inmediatamente si se queda embarazada y pregunte sobre los posibles beneficios y riesgos de su tratamiento antirretroviral para usted y para su hijo.

Si ha tomado Biktarvy durante su embarazo su médico puede solicitar que se haga análisis de sangre periódicos y otras pruebas diagnósticas para controlar el desarrollo de su niño. En niños cuyas madres tomaron nucleósidos inhibidores de la transcriptasa inversa (ITIAN) durante el embarazo, el beneficio de la protección frente al VIH fue mayor que el riesgo de que se produjeran efectos adversos.

**No dé el pecho a su hijo durante el tratamiento con Biktarvy.** Esto se debe a que algunos de los principios activos de este medicamento pasan a la leche materna. Se recomienda que no dé el pecho para evitar que transmita el virus al niño a través de la leche materna. Si realmente desea amamantar, hable primero con su médico.

**Conducción y uso de máquinas**

Biktarvy puede causar mareo. Si nota mareo durante el tratamiento con Biktarvy, no conduzca ni maneje herramientas o máquinas.

**Biktarvy contiene sodio**

Este medicamento contiene menos de 1 mmol de sodio (23 mg) por comprimido; esto es, esencialmente “exento de sodio”.


#### 3. Cómo tomar Biktarvy

 

Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico.

En caso de duda, consulte de nuevo a su médico o farmacéutico.

**La dosis recomendada es:**

**Adultos:** un comprimido al día, con o sin alimentos

No mastique, triture ni divida el comprimido.

* **Consulte a su médico o farmacéutico si está tomando:**
* **antiácidos** para tratar úlceras estomacales, acidez estomacal o reflujo ácido, que contengan hidróxido de aluminio y/o de magnesio
* **suplementos de minerales** o **vitaminas** que contengan magnesio o hierro
* **Vea la sección 2 para más información** sobre cómo tomar estos medicamentos con Biktarvy.

**Si toma más Biktarvy del que debe**

Si toma más cantidad de la dosis recomendada de Biktarvy puede correr mayor riesgo de experimentar posibles efectos adversos con este medicamento (ver sección 4, **Posibles efectos adversos**).

Consulte inmediatamente a su médico o acuda al servicio de urgencias más cercano. Lleve consigo el frasco de comprimidos para que pueda describir fácilmente qué ha tomado.

**Si olvidó tomar Biktarvy**

Es importante que no olvide una dosis de Biktarvy.

Si olvida una dosis:

* **Si se da cuenta en las 18 horas** posteriores a la hora a la que normalmente toma Biktarvy, debe tomar el comprimido tan pronto como sea posible. Luego tome la dosis siguiente de la forma habitual.
* **Si se da cuenta después de 18 horas o más** de la hora a la que normalmente toma Biktarvy, no tome la dosis olvidada. Espere y tome la siguiente dosis a la hora habitual.

**Si vomita** antes de que transcurra 1 hora tras haber tomado Biktarvy, tome otro comprimido. Si vomita transcurrida 1 hora de haber tomado Biktarvy, no necesita tomar otro comprimido hasta el momento de la hora habitual.

**No interrumpa el tratamiento con Biktarvy**

**No interrumpa el tratamiento con Biktarvy sin hablar antes con su médico.** Interrumpir Biktarvy puede afectar gravemente el funcionamiento de tratamientos futuros. Si se interrumpe Biktarvy por algún motivo, consulte con su médico antes de reiniciar la toma de comprimidos de Biktarvy.

**Cuando vea que le queda poca cantidad de Biktarvy,** acuda a su médico o farmacéutico para que le proporcione más. Esto es muy importante, ya que la cantidad de virus puede empezar a aumentar si el medicamento se interrumpe incluso durante un corto periodo de tiempo. Es posible que entonces la enfermedad se vuelva más difícil de tratar.

**Si tiene infección por VIH y hepatitis B** es especialmente importante no suspender su tratamiento con Biktarvy sin antes hablar con su médico. Puede necesitar hacerse análisis de sangre durante varios meses tras suspender el tratamiento. En algunos pacientes con enfermedad hepática avanzada o cirrosis no se recomienda suspender el tratamiento ya que esto puede producir un empeoramiento de su hepatitis, situación que puede ser potencialmente mortal.

**Hable con su médico inmediatamente**
acerca de síntomas nuevos o inusuales tras suspender su
tratamiento, particularmente síntomas que asocie con la infección por el virus de la hepatitis B.
Si tiene cualquier otra duda sobre el uso de este medicamento, pregunte a su médico o farmacéutico.


#### 4. Posibles efectos adversos

 

Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.

**Posibles efectos adversos: informe a un médico inmediatamente**

* **Cualquier signo de inflamación o de infección.** En algunos pacientes con infección avanzada por el VIH (sida) y antecedentes de infecciones oportunistas (infecciones que ocurren en personas con un sistema inmunitario débil), se pueden producir signos y síntomas de inflamación por infecciones previas poco después de iniciar el tratamiento contra el VIH. Se cree que estos síntomas se deben a una mejoría de la respuesta inmunitaria del organismo, que le permite combatir infecciones que podrían haber estado presentes sin síntomas obvios.
* Se pueden producir también **trastornos autoinmunitarios,** en los que el sistema inmunitario ataca a los tejidos sanos del organismo, después de que empiece a tomar medicamentos para la infección por el VIH. Los trastornos autoinmunitarios se pueden producir muchos meses después del inicio del tratamiento. Esté atento a cualquier síntoma de infección u otros síntomas, como:

* debilidad muscular
* debilidad que se inicia en las manos y los pies y se desplaza hacia el tronco
* palpitaciones, temblor o hiperactividad

**Si nota cualquiera de estos síntomas o cualquier síntoma de inflamación o infección, informe a su médico inmediatamente.**
**Efectos adversos frecuentes**

**(pueden afectar hasta 1 de cada 10 personas)**

* depresión
* sueños anormales
* dolor de cabeza
* mareo
* diarrea
* ganas de vomitar (**náuseas**)
* cansancio (**fatiga**)

**Efectos adversos poco frecuentes**

(**pueden afectar hasta 1 de cada 100 personas**)

* anemia
* vómitos
* dolor de estómago
* problemas digestivos que generan molestias después de las comidas (**dispepsia**)
* gases (**flatulencia**)
* hinchazón de la cara, labios, lengua o garganta (**angioedema**)
* picazón (**prurito**)
* erupción
* habones (**urticaria**)
* dolor en las articulaciones (**artralgia**)
* comportamiento suicida
* ansiedad
* trastornos del sueño

**Los análisis de sangre también pueden mostrar:**

* Concentraciones más altas de sustancias llamadas bilirrubina y/o creatinina sérica en la sangre

**Si considera que alguno de los efectos adversos que sufre es grave, informe a su médico.**
**Otros efectos que se pueden observar durante el tratamiento contra el VIH**

La frecuencia de los siguientes efectos adversos se considera no conocida (la frecuencia no se puede estimar a partir de los datos disponibles).

* **Problemas óseos.** Algunos pacientes tratados con medicamentos antirretrovirales combinados como Biktarvy pueden desarrollar una enfermedad de los huesos llamada **osteonecrosis** (muerte del tejido óseo debida a una pérdida del suministro de sangre al hueso). Tomar este tipo de medicamentos durante un tiempo prolongado, tomar corticosteroides, beber alcohol, tener un sistema inmunitario muy débil y tener sobrepeso, pueden ser algunos de los muchos factores de riesgo para desarrollar esta enfermedad. Los signos de osteonecrosis son:

**Si nota cualquiera de estos síntomas, informe a su médico.**
Durante el tratamiento del VIH puede haber un aumento en el peso y en los niveles de glucosa y lípidos en la sangre. Esto puede estar en parte relacionado con la recuperación de la salud y con el estilo de vida y, en el caso de los lípidos en la sangre, algunas veces con los medicamentos contra el VIH por sí mismos. Su médico le controlará estos cambios.

**Comunicación de efectos adversos**

Si experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del sistema nacional de notificación incluido en el [Apéndice V.](http://www.ema.europa.eu/docs/en_GB/document_library/Template_or_form/2013/03/WC500139752.doc) Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.


#### 5. Conservación de Biktarvy

 

Mantener este medicamento fuera de la vista y del alcance de los niños.

No utilice este medicamento después de la fecha de caducidad que aparece en la caja y en el frasco después de {CAD}. La fecha de caducidad es el último día del mes que se indica.

Conservar en el embalaje original para protegerlo de la humedad. Mantener el frasco perfectamente cerrado. No utilizar si falta el sello del frasco o está roto.

Los medicamentos no se deben tirar por los desagües ni a la basura. Pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudará a proteger el medio ambiente.


#### 6. Contenido del envase e información adicional

 

**Composición de Biktarvy**

**Los principios activos son** bictegravir, emtricitabina y tenofovir alafenamida. Cada comprimido de Biktarvy contiene bictegravir sódico equivalente a 50 mg de bictegravir, 200 mg de emtricitabina y tenofovir alafenamida fumarato equivalente a 25 mg de tenofovir alafenamida.

**Los demás componentes son**

**Núcleo del comprimido**

Celulosa microcristalina, croscarmelosa sódica, estearato de magnesio.

**Recubrimiento con película**

Alcohol polivinílico, dióxido de titanio (E171), macrogol, talco, óxido de hierro rojo (E172), óxido de hierro negro (E172).

**Aspecto del producto y contenido del envase**

Los comprimidos recubiertos con película de Biktarvy son comprimidos recubiertos con película de color marrón purpúreo, con forma de cápsula, marcados en una de las caras del comprimido con «GSI» y en la otra cara del comprimido con «9883». Biktarvy se presenta en frascos de 30 comprimidos y en envases de 3 frascos, conteniendo cada uno de ellos 30 comprimidos. Cada frasco contiene un desecante de gel de sílice que debe conservarse en el frasco para ayudar a proteger los comprimidos. El desecante de gel de sílice está contenido en un sobre o recipiente separado, y no se debe tragar.

Puede que solamente estén comercializados algunos tamaños de envases.

**Titular de la autorización de comercialización**

Gilead Sciences Ireland UC

Carrigtohill

County Cork, T45 DP77

Irlanda

**Responsable de la fabricación**

Gilead Sciences Ireland UC

IDA Business & Technology Park

Carrigtohill

County Cork

Irlanda

Pueden solicitar más información respecto a este medicamento dirigiéndose al representante local del titular de la autorización de comercialización:

| | |
| :--- | :--- |
| **België/Belgique/Belgien**Gilead Sciences Belgium SPRL-BVBATél/Tel: + 32 (0) 24 01 35 50 | **Lietuva**Gilead Sciences Poland Sp. z o.o.Tel.: + 48 (0) 22 262 8702 |
| **????????**Gilead Sciences Ireland UC???.: + 353 (0) 1 686 1888 | **Luxembourg/Luxemburg**Gilead Sciences Belgium SPRL-BVBATél/Tel: + 32 (0) 24 01 35 50 |
| **Ceská republika**Gilead Sciences s.r.o.Tel: + 420 (0) 910 871 986 | **Magyarország**Gilead Sciences Ireland UCTel.: + 353 (0) 1 686 1888 |
| **Danmark**Gilead Sciences Sweden ABTlf: + 46 (0) 8 5057 1849 | **Malta**Gilead Sciences Ireland UCTel: + 353 (0) 1 686 1888 |
| **Deutschland**Gilead Sciences GmbHTel: + 49 (0) 89 899890-0 | **Nederland**Gilead Sciences Netherlands B.V.Tel: + 31 (0) 20 718 36 98 |
| **Eesti**Gilead Sciences Poland Sp. z o.o.Tel.: +48 (0) 22 262 8702 | **Norge**Gilead Sciences Sweden ABTlf: + 46 (0) 8 5057 1849 |
| **Ελλ?δα**Gilead Sciences Ελλ?ς Μ.ΕΠΕ.Τηλ: + 30 (0) 210 8930 100 | **Österreich**Gilead Sciences GesmbHTel: + 43 (0) 1 260 830 |
| **España**Gilead Sciences, S.L.Tel: + 34 (0) 91 378 98 30 | **Polska**Gilead Sciences Poland Sp. z o.o.Tel.: + 48 (0) 22 262 8702 |
| **France**Gilead SciencesTél: + 33 (0) 1 46 09 41 00 | **Portugal**Gilead Sciences, Lda.Tel: + 351 (0) 21 7928790 |
| **Hrvatska**Gilead Sciences Ireland UCTel: + 353 (0) 1 686 1888 | **România**Gilead Sciences Ireland UCTel: + 353 (0) 1 686 1888 |
| **Irlanda**Gilead Sciences Ireland UCTel: + 353 (0) 214 825 999 | **Slovenija**Gilead Sciences Ireland UCTel: + 353 (0) 1 686 1888 |
| **Ísland**Gilead Sciences Sweden ABSími: + 46 (0) 8 5057 1849 | **Slovenská republika**Gilead Sciences Slovakia s.r.o.Tel: + 421 (0) 232 121 210 |
| **Italia**Gilead Sciences S.r.l.Tel: + 39 02 439201 | **Suomi/Finland**Gilead Sciences Sweden ABPuh/Tel: + 46 (0) 8 5057 1849 |
| **Κ?προς**Gilead Sciences Ελλ?ς Μ.ΕΠΕ.Τηλ: + 30 (0) 210 8930 100 | **Sverige**Gilead Sciences Sweden ABTel: + 46 (0) 8 5057 1849 |
| **Latvija**Gilead Sciences Poland Sp. z o.o.Tel.: + 48 (0) 22 262 8702 | **Reino Unido**Gilead Sciences Ltd.Tel: + 44 (0) 8000 113 700 |

**Fecha de la última revisión de este prospecto:**

La información detallada de este medicamento está disponible en la página web de la Agencia Europea de Medicamentos: [http://www.ema.europa.eu.](http://www.ema.europa.eu/)


####  Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 
PMSWI:
** EU/1/18/1289/001 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E827gy **
-------

Full name: **Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion**

 - Invented name part: ** Biktarvy ** 

 - Scientific name part: ** bictegravir/emtricitabine/tenofovir alafenamide ** 

 - Strength part: ** 50 mg/200 mg/25 mg ** 

 - Pharmaceutical dose form part: ** film-coated tablets ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/18/1289/001 ** 

 Region: ** ** 

Marketing authorisation holder: **Gilead Sciences Ireland UC** 

 Identifier: 
*  **ORG-100008368** 
 

 Status: ** Active (2018-06-21T13:28:17Z) ** 

 Package 1 of 2

PMSWI: ** EU/1/18/1289/001 ** 

GTIN: ** 07612345678904 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **90 Child-resistant closure** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Child-resistant closure** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

 Package 2 of 2

PMSWI: ** EU/1/18/1289/001 ** 

Description:

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundleprocessed-es-b44cce291e466626afa836fffe72c350",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "es",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/18/1289/001"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-proc-es-1846d2b12fecbbb0310cd8c196c98f82",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-proc-es-1846d2b12fecbbb0310cd8c196c98f82",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "es",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"es\" lang=\"es\"><a name=\"Composition_composition-proc-es-1846d2b12fecbbb0310cd8c196c98f82\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-proc-es-1846d2b12fecbbb0310cd8c196c98f82</b></p><a name=\"composition-proc-es-1846d2b12fecbbb0310cd8c196c98f82\"> </a><a name=\"hccomposition-proc-es-1846d2b12fecbbb0310cd8c196c98f82\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: es</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: indication</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ B90}, {http://snomed.info/sct 86406008}\">HIV-infection/AIDS</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: pregnancyCategory</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ W78}\">Pregnancy</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: breastfeedingCategory</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 69840006}\">Normal breast feeding (finding)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: liver</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ D97}\">Liver disease, other</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: contra-indication-hypericum</li><li>concept: <span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta XK4IUX8MNB}\">Hypericum perforatum L.</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: hepatitisB</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 66071002}\">Viral hepatitis type B (disorder)</span></li></ul></blockquote><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/b22ec2e7263c64ba0d74e2718a1859op</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs P}\">processed</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mah-715f8a161ed438d0584510e5b4512caa\">Organization Gilead Sciences Ireland UC</a></p><p><b>title</b>: TEST PURPOSES ONLY - Biktarvy 50 mg/200 mg/25 mg film-coated tablets</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "indication"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "B90",
                "display" : "HIV-infection/AIDS"
              },
              {
                "system" : "http://snomed.info/sct",
                "code" : "86406008",
                "display" : "HIV-infection/AIDS"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "pregnancyCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "W78",
                "display" : "Pregnancy"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "breastfeedingCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "69840006",
                "display" : "Normal breast feeding (finding)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "liver"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "D97",
                "display" : "Liver disease, other"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "contra-indication-hypericum"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
                "code" : "XK4IUX8MNB",
                "display" : "Hypericum perforatum L."
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "hepatitisB"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "66071002",
                "display" : "Viral hepatitis type B (disorder)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      }],
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "b22ec2e7263c64ba0d74e2718a1859op"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "P",
          "display" : "processed"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-715f8a161ed438d0584510e5b4512caa"
      }],
      "title" : "TEST PURPOSES ONLY - Biktarvy 50 mg/200 mg/25 mg film-coated tablets",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PACKAGE LEAFLET"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Prospecto: información para el usuario"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><a name=\"page1\" id=\"page1\"></a><strong><span>Prospecto: informaci&#243;n para el usuario</span></strong></p><p><strong><span>Biktarvy 50 mg/200 mg/25 mg comprimidos recubiertos con pel&#237;cula</span></strong></p><p><span>bictegravir/emtricitabina/tenofovir alafenamida</span></p><p><strong><span>Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene informaci&#243;n importante para usted.</span></strong></p><ul><li><span>Conserve este prospecto, ya que puede tener que volver a leerlo.</span></li><li><span>Si tiene alguna duda, consulte a su m&#233;dico o farmac&#233;utico.</span></li><li><span>Este medicamento se le ha recetado solamente a usted, y no debe d&#225;rselo a otras personas aunque tengan los mismos s&#237;ntomas que usted, ya que puede perjudicarles.</span></li><li><span>Si experimenta efectos adversos, consulte a su m&#233;dico o farmac&#233;utico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver secci&#243;n 4.</span></li></ul></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Contenido del prospecto"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Contenido del prospecto</span></strong></p><ol><li><span>Qu&#233; es Biktarvy y para qu&#233; se utiliza</span></li><li><span>Qu&#233; necesita saber antes de empezar a tomar Biktarvy</span></li><li><span>C&#243;mo tomar Biktarvy</span></li><li><span>Posibles efectos adversos</span></li><li><span>Conservaci&#243;n de Biktarvy</span></li><li><span>Contenido del envase e informaci&#243;n adicional</span></li></ol></div>"
          }
        },
        {
          "title" : "1. Qué es Biktarvy y para qué se utiliza",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Qué es Biktarvy y para qué se utiliza"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Biktarvy contiene tres principios activos:</span></p><ul><li><strong><span>bictegravir,</span></strong> <span>un medicamento antirretroviral conocido como inhibidor de la transferencia de las</span> <span>hebras de la integrasa (INI)</span></li><li><strong><span>emtricitabina,</span></strong> <span>un medicamento antirretroviral de un tipo conocido como nucle&#243;sido inhibidor</span> <span>de la transcriptasa inversa (ITIAN)</span></li><li><strong><span>tenofovir alafenamida,</span></strong> <span>un medicamento antirretroviral de un tipo conocido como nucle&#243;tido</span> <span>inhibidor de la transcriptasa inversa (ITIANt)</span></li></ul><p><span class=\"indication\">Biktarvy es un comprimido &#250;nico para el tratamiento de la infecci&#243;n por el virus de la inmunodeficiencia humana 1 (VIH-1) en adultos.</span></p><p><span>Biktarvy reduce la cantidad de VIH presente en el organismo. Esto mejora el sistema inmunitario y disminuye el riesgo de desarrollar enfermedades asociadas con la infecci&#243;n por el VIH.</span></p></div>"
          }
        },
        {
          "title" : "2. Qué necesita saber antes de empezar a tomar Biktarvy",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Qué necesita saber antes de empezar a tomar Biktarvy"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>No tome Biktarvy</span></strong></p><ul><li><strong><span>Si es al&#233;rgico a bictegravir, emtricitabina, tenofovir alafenamida</span></strong> <span>o a alguno de los dem&#225;s</span> <span>componentes de este medicamento (incluidos en la secci&#243;n 6 de este prospecto).</span></li><li><a name=\"page2\" id=\"page2\"></a><strong><span>Si actualmente est&#225; tomando alguno de los siguientes medicamentos:</span></strong></li><ul><li><strong><span>rifampicina</span></strong> <span>utilizada para tratar algunas infecciones bacterianas como la tuberculosis</span></li><li class=\"contra-indication-hypericum\"><strong><span>hierba de San Juan</span></strong> <span>(</span><em><span>Hypericum perforatum</span></em><span>, hip&#233;rico), un medicamento a base de</span> <span>plantas utilizado para la depresi&#243;n y la ansiedad, o productos que la contengan.</span></li></ul></ul><span>Si est&#225; tomando alguno de estos medicamentos,</span> <strong><span>no tome Biktarvy y consulte a su m&#233;dico</span></strong> <strong><span>inmediatamente.</span></strong><p><strong><span>Advertencias y precauciones</span></strong></p><p><strong><span>Consulte a su m&#233;dico antes de empezar a tomar Biktarvy:</span></strong></p><ul><li class=\"liver\"><strong><span>Si tiene problemas hep&#225;ticos o antecedentes de enfermedad hep&#225;tica, incluida la hepatitis.</span></strong> <span>Los pacientes que padecen de enfermedades hep&#225;ticas, como la hepatitis B o C cr&#243;nica, y est&#225;n en tratamiento con antirretrovirales tienen m&#225;s riesgo de presentar complicaciones hep&#225;ticas graves y potencialmente mortales. Si tiene infecci&#243;n por el virus de la hepatitis B, su m&#233;dico evaluar&#225; detenidamente la mejor pauta terap&#233;utica para usted.</span></li><li class=\"hepatitisB\"><strong><span>Si tiene hepatitis B.</span></strong> <span>Los problemas hep&#225;ticos pueden empeorar despu&#233;s de dejar de tomar</span> <span>Biktarvy.</span></li><li><span>No deje de tomar Biktarvy si tiene hepatitis B. Hable antes con su m&#233;dico. Puede consultar m&#225;s detalles en la secci&#243;n 3,</span> <em><span>No interrumpa el tratamiento con Biktarvy.</span></em></li></ul><p><strong><span>Mientras est&#233; tomando Biktarvy</span></strong></p><p><span>Una vez que empiece a tomar Biktarvy, est&#233; atento a:</span></p><ul><li><strong><span>Signos de inflamaci&#243;n o infecci&#243;n</span></strong></li><li><strong><span>Dolor articular, rigidez o problemas &#243;seos</span></strong></li></ul><strong><span>Si nota cualquiera de estos s&#237;ntomas, informe a su m&#233;dico inmediatamente.</span></strong> <span>Puede consultar</span> <span>m&#225;s informaci&#243;n en la secci&#243;n 4,</span> <em><span>Posibles efectos adversos</span></em><span>.</span><p><span>Aunque no se han observado problemas renales con Biktarvy, existe la posibilidad de que pueda experimentar problemas renales si toma Biktarvy durante un periodo de tiempo prolongado.</span></p><p><span>Mientras est&#233; tomando este medicamento</span> <strong><span>a&#250;n puede transmitir el VIH a los dem&#225;s,</span></strong> <span>aunque un tratamiento antirretroviral eficaz reduzca el riesgo. Consulte a su m&#233;dico sobre qu&#233; precauciones son necesarias para no infectar a otras personas. Este medicamento no es una cura para la infecci&#243;n por el VIH. Mientras usted est&#233; tomando Biktarvy podr&#225; seguir padeciendo infecciones u otras enfermedades asociadas con la infecci&#243;n por el VIH.</span></p><p><strong><span>Ni&#241;os y adolescentes</span></strong></p><p><strong><span>No administre este medicamento a ni&#241;os y adolescentes menores de 18 a&#241;os de edad.</span></strong> <span>No se ha</span> <span>estudiado todav&#237;a el uso de Biktarvy en ni&#241;os y adolescentes menores de 18 a&#241;os de edad.</span></p><p><strong><span>Otros medicamentos y Biktarvy</span></strong></p><p><strong><span>Informe a su m&#233;dico o farmac&#233;utico si est&#225; tomando, ha tomado recientemente o pudiera tener que tomar cualquier otro medicamento.</span></strong> <span>Biktarvy puede interaccionar con otros medicamentos.</span> <span>Como consecuencia, los niveles sangu&#237;neos de Biktarvy o de otros medicamentos se pueden ver afectados. Esto puede impedir que sus medicamentos funcionen correctamente o empeorar sus posibles efectos adversos. En algunos casos, su m&#233;dico puede tener que ajustar la dosis o comprobar sus concentraciones sangu&#237;neas.</span></p><p><a name=\"page3\" id=\"page3\"></a><strong><span>Medicamentos que nunca se deben tomar con Biktarvy:</span></strong></p><ul><li><strong><span>rifampicina</span></strong> <span>utilizada para tratar algunas infecciones bacterianas como la tuberculosis</span></li><li class=\"contra-indication-hypericum\"><strong><span>hierba de San Juan</span></strong> <span>(</span><em><span>Hypericum perforatum</span></em><span>, hip&#233;rico), un medicamento a base de plantas</span> <span>utilizado para la depresi&#243;n y la ansiedad, o productos que lo contengan</span><strong><span>.</span></strong></li></ul><span>Si est&#225; tomando alguno de estos medicamentos,</span> <strong><span>no tome Biktarvy e informe a su m&#233;dico</span></strong> <strong><span>inmediatamente.</span></strong><p><strong><span>Consulte con su m&#233;dico si est&#225; tomando:</span></strong></p><ul><li><strong><span>medicamentos utilizados para tratar el VIH y/o la hepatitis B</span></strong> <span>que contengan:</span></li><ul><li><span>adefovir dipivoxil, atazanavir, bictegravir, emtricitabina, lamivudina, tenofovir alafenamida o tenofovir disoproxilo</span></li></ul><li><strong><span>antibi&#243;ticos, utilizados para tratar las infecciones bacterianas</span></strong><span>, que contengan:</span></li><ul><li><span>azitromicina, claritromicina, rifabutina o rifapentina</span></li></ul><li><strong><span>antiepil&#233;pticos,</span></strong> <span>utilizados para tratar la epilepsia, que contengan:</span></li><ul><li><span>carbamazepina, oxcarbazepina, fenobarbital o fenito&#237;na</span></li></ul><li><strong><span>inmunosupresores,</span></strong> <span>utilizados para controlar la respuesta inmunitaria del organismo tras un</span> <span>trasplante, que contengan ciclosporina</span></li><li><strong><span>medicamentos para la curaci&#243;n de &#250;lceras</span></strong> <span>que contengan sucralfato</span></li></ul><strong><span>Informe a su m&#233;dico si est&#225; tomando alguno de estos medicamentos.</span></strong> <span>No interrumpa su</span> <span>tratamiento sin consultar con su m&#233;dico.</span><p><strong><span>Consulte a su m&#233;dico o farmac&#233;utico si est&#225; tomando:</span></strong></p><ul><li><strong><span>anti&#225;cidos</span></strong> <span>para tratar &#250;lceras estomacales, acidez estomacal o reflujo &#225;cido, que contengan</span> <span>hidr&#243;xido de aluminio y/o de magnesio</span></li><li><strong><span>suplementos de minerales</span></strong> <span>o</span> <strong><span>de vitaminas,</span></strong> <span>que contengan magnesio o hierro</span></li></ul><strong><span>Consulte a su m&#233;dico o farmac&#233;utico antes de tomar Biktarvy</span></strong> <span>si est&#225; tomando alguno de estos</span> <span>medicamentos.</span><p><strong><span>Anti&#225;cidos y suplementos de magnesio:</span></strong> <span>tendr&#225; que tomar Biktarvy al menos 2 horas</span> <strong><span>antes</span></strong> <span>de</span> <span>tomar los anti&#225;cidos o suplementos que contengan aluminio y/o magnesio. O puede tomar Biktarvy junto con alimentos al menos 2 horas</span> <strong><span>despu&#233;s</span></strong> <span>de la toma del anti&#225;cido o suplemento que contenga aluminio y/o magnesio.</span></p><p><strong><span>Suplementos de hierro:</span></strong> <span>tendr&#225; que tomar Biktarvy al menos 2 horas</span> <strong><span>antes</span></strong> <span>de tomar los</span> <span>suplementos de hierro o puede tomarlos todos juntos con alimentos.</span></p><div class=\"pregnancyCategory\"><p><strong><span>Embarazo y lactancia</span></strong></p><ul><li><span>Si est&#225; embarazada o en periodo de lactancia, cree que podr&#237;a estar embarazada o tiene intenci&#243;n de quedarse embarazada, consulte a su m&#233;dico o farmac&#233;utico antes de utilizar este medicamento.</span></li><li><span>Informe a su m&#233;dico inmediatamente si se queda embarazada y pregunte sobre los posibles beneficios y riesgos de su tratamiento antirretroviral para usted y para su hijo.</span></li></ul><p><span>Si ha tomado Biktarvy durante su embarazo su m&#233;dico puede solicitar que se haga an&#225;lisis de sangre peri&#243;dicos y otras pruebas diagn&#243;sticas para controlar el desarrollo de su ni&#241;o. En ni&#241;os cuyas madres tomaron nucle&#243;sidos inhibidores de la transcriptasa inversa (ITIAN) durante el embarazo, el beneficio de la protecci&#243;n frente al VIH fue mayor que el riesgo de que se produjeran efectos adversos.</span></p></div><p class=\"breastfeedingCategory\"><strong><span>No d&#233; el pecho a su hijo durante el tratamiento con Biktarvy.</span></strong> <span>Esto se debe a que algunos de los</span> <span>principios activos de este medicamento pasan a la leche materna. Se recomienda que no d&#233; el pecho para evitar que transmita el virus al ni&#241;o a trav&#233;s de la leche materna. Si realmente desea amamantar, hable primero con su m&#233;dico.</span></p><p><a name=\"page4\" id=\"page4\"></a><strong><span>Conducci&#243;n y uso de m&#225;quinas</span></strong></p><p><span>Biktarvy puede causar mareo. Si nota mareo durante el tratamiento con Biktarvy, no conduzca ni maneje herramientas o m&#225;quinas.</span></p><p><strong><span>Biktarvy contiene sodio</span></strong></p><p><span>Este medicamento contiene menos de 1 mmol de sodio (23 mg) por comprimido; esto es, esencialmente &#8220;exento de sodio&#8221;.</span></p></div>"
          }
        },
        {
          "title" : "3. Cómo tomar Biktarvy",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Cómo tomar Biktarvy"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Siga exactamente las instrucciones de administraci&#243;n de este medicamento indicadas por su m&#233;dico.</span></p><p><span>En caso de duda, consulte de nuevo a su m&#233;dico o farmac&#233;utico.</span></p><p><strong><span>La dosis recomendada es:</span></strong></p><p><strong><span>Adultos:</span></strong> <span>un comprimido al d&#237;a, con o sin alimentos</span></p><p><span>No mastique, triture ni divida el comprimido.</span></p><ul><li><strong><span>Consulte a su m&#233;dico o farmac&#233;utico si est&#225; tomando:</span></strong></li><li><strong><span>anti&#225;cidos</span></strong> <span>para tratar &#250;lceras estomacales, acidez estomacal o reflujo &#225;cido, que contengan</span> <span>hidr&#243;xido de aluminio y/o de magnesio</span></li><li><strong><span>suplementos de minerales</span></strong> <span>o</span> <strong><span>vitaminas</span></strong> <span>que contengan magnesio o hierro</span></li><li><strong><span>Vea la secci&#243;n 2 para m&#225;s informaci&#243;n</span></strong> <span>sobre c&#243;mo tomar estos medicamentos con Biktarvy.</span></li></ul><p><strong><span>Si toma m&#225;s Biktarvy del que debe</span></strong></p><p><span>Si toma m&#225;s cantidad de la dosis recomendada de Biktarvy puede correr mayor riesgo de experimentar posibles efectos adversos con este medicamento (ver secci&#243;n 4,</span> <em><span>Posibles efectos adversos</span></em><span>).</span></p><p><span>Consulte inmediatamente a su m&#233;dico o acuda al servicio de urgencias m&#225;s cercano. Lleve consigo el frasco de comprimidos para que pueda describir f&#225;cilmente qu&#233; ha tomado.</span></p><p><strong><span>Si olvid&#243; tomar Biktarvy</span></strong></p><p><span>Es importante que no olvide una dosis de Biktarvy.</span></p><p><span>Si olvida una dosis:</span></p><ul><li><strong><span>Si se da cuenta en las 18 horas</span></strong> <span>posteriores a la hora a la que normalmente toma Biktarvy, debe</span> <span>tomar el comprimido tan pronto como sea posible. Luego tome la dosis siguiente de la forma habitual.</span></li><li><strong><span>Si se da cuenta despu&#233;s de 18 horas o m&#225;s</span></strong> <span>de la hora a la que normalmente toma Biktarvy, no</span> <span>tome la dosis olvidada. Espere y tome la siguiente dosis a la hora habitual.</span></li></ul><p><strong><span>Si vomita</span></strong> <span>antes de que transcurra 1 hora tras haber tomado Biktarvy, tome otro comprimido. Si</span> <span>vomita transcurrida 1 hora de haber tomado Biktarvy, no necesita tomar otro comprimido hasta el momento de la hora habitual.</span></p><p><strong><span>No interrumpa el tratamiento con Biktarvy</span></strong></p><p><strong><span>No interrumpa el tratamiento con Biktarvy sin hablar antes con su m&#233;dico.</span></strong> <span>Interrumpir Biktarvy</span> <span>puede afectar gravemente el funcionamiento de tratamientos futuros. Si se interrumpe Biktarvy por alg&#250;n motivo, consulte con su m&#233;dico antes de reiniciar la toma de comprimidos de Biktarvy.</span></p><p><a name=\"page5\" id=\"page5\"></a><strong><span>Cuando vea que le queda poca cantidad de Biktarvy,</span></strong> <span>acuda a su m&#233;dico o farmac&#233;utico para que le</span> <span>proporcione m&#225;s. Esto es muy importante, ya que la cantidad de virus puede empezar a aumentar si el medicamento se interrumpe incluso durante un corto periodo de tiempo. Es posible que entonces la enfermedad se vuelva m&#225;s dif&#237;cil de tratar.</span></p><p><strong><span>Si tiene infecci&#243;n por VIH y hepatitis B</span></strong> <span>es especialmente importante no suspender su tratamiento</span> <span>con Biktarvy sin antes hablar con su m&#233;dico. Puede necesitar hacerse an&#225;lisis de sangre durante varios meses tras suspender el tratamiento. En algunos pacientes con enfermedad hep&#225;tica avanzada o cirrosis no se recomienda suspender el tratamiento ya que esto puede producir un empeoramiento de su hepatitis, situaci&#243;n que puede ser potencialmente mortal.</span></p><strong><span>Hable con su m&#233;dico inmediatamente</span></strong> <span>acerca de s&#237;ntomas nuevos o inusuales tras suspender su</span> <span>tratamiento, particularmente s&#237;ntomas que asocie con la infecci&#243;n por el virus de la hepatitis B.</span><p><span>Si tiene cualquier otra duda sobre el uso de este medicamento, pregunte a su m&#233;dico o farmac&#233;utico.</span></p></div>"
          }
        },
        {
          "title" : "4. Posibles efectos adversos",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Posibles efectos adversos"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.</span></p><p><strong><span>Posibles efectos adversos: informe a un m&#233;dico inmediatamente</span></strong></p><ul><li><strong><span>Cualquier signo de inflamaci&#243;n o de infecci&#243;n.</span></strong> <span>En algunos pacientes con infecci&#243;n avanzada</span> <span>por el VIH (sida) y antecedentes de infecciones oportunistas (infecciones que ocurren en personas con un sistema inmunitario d&#233;bil), se pueden producir signos y s&#237;ntomas de inflamaci&#243;n por infecciones previas poco despu&#233;s de iniciar el tratamiento contra el VIH. Se cree que estos s&#237;ntomas se deben a una mejor&#237;a de la respuesta inmunitaria del organismo, que le permite combatir infecciones que podr&#237;an haber estado presentes sin s&#237;ntomas obvios.</span></li><li><span>Se pueden producir tambi&#233;n</span> <strong><span>trastornos autoinmunitarios,</span></strong> <span>en los que el sistema inmunitario ataca a los tejidos sanos del organismo, despu&#233;s de que empiece a tomar medicamentos para la infecci&#243;n por el VIH. Los trastornos autoinmunitarios se pueden producir muchos meses despu&#233;s del inicio del tratamiento. Est&#233; atento a cualquier s&#237;ntoma de infecci&#243;n u otros s&#237;ntomas, como:</span></li></ul><ul><li><span>debilidad muscular</span></li><li><span>debilidad que se inicia en las manos y los pies y se desplaza hacia el tronco</span></li><li><span>palpitaciones, temblor o hiperactividad</span></li></ul><strong><span>Si nota cualquiera de estos s&#237;ntomas o cualquier s&#237;ntoma de inflamaci&#243;n o infecci&#243;n, informe a su m&#233;dico inmediatamente.</span></strong><p><strong><span>Efectos adversos frecuentes</span></strong></p><p><em><span>(pueden afectar hasta 1 de cada 10 personas)</span></em></p><ul><li><span>depresi&#243;n</span></li><li><span>sue&#241;os anormales</span></li><li><span>dolor de cabeza</span></li><li><span>mareo</span></li><li><span>diarrea</span></li><li><span>ganas de vomitar (</span><em><span>n&#225;useas</span></em><span>)</span></li><li><span>cansancio (</span><em><span>fatiga</span></em><span>)</span></li></ul><p><strong><span>Efectos adversos poco frecuentes</span></strong></p><p><span>(</span><em><span>pueden afectar hasta 1 de cada 100 personas</span></em><span>)</span></p><ul><li><span>anemia</span></li><li><a name=\"page6\" id=\"page6\"></a><span>v&#243;mitos</span></li><li><span>dolor de est&#243;mago</span></li><li><span>problemas digestivos que generan molestias despu&#233;s de las comidas (</span><em><span>dispepsia</span></em><span>)</span></li><li><span>gases (</span><em><span>flatulencia</span></em><span>)</span></li><li><span>hinchaz&#243;n de la cara, labios, lengua o garganta (</span><em><span>angioedema</span></em><span>)</span></li><li><span>picaz&#243;n (</span><em><span>prurito</span></em><span>)</span></li><li><span>erupci&#243;n</span></li><li><span>habones (</span><em><span>urticaria</span></em><span>)</span></li><li><span>dolor en las articulaciones (</span><em><span>artralgia</span></em><span>)</span></li><li><span>comportamiento suicida</span></li><li><span>ansiedad</span></li><li><span>trastornos del sue&#241;o</span></li></ul><p><em><span>Los an&#225;lisis de sangre tambi&#233;n pueden mostrar:</span></em></p><ul><li><span>Concentraciones m&#225;s altas de sustancias llamadas bilirrubina y/o creatinina s&#233;rica en la sangre</span></li></ul><strong><span>Si considera que alguno de los efectos adversos que sufre es grave, informe a su m&#233;dico.</span></strong><p><strong><span>Otros efectos que se pueden observar durante el tratamiento contra el VIH</span></strong></p><p><span>La frecuencia de los siguientes efectos adversos se considera no conocida (la frecuencia no se puede estimar a partir de los datos disponibles).</span></p><ul><li><strong><span>Problemas &#243;seos.</span></strong> <span>Algunos pacientes tratados con medicamentos antirretrovirales combinados</span> <span>como Biktarvy pueden desarrollar una enfermedad de los huesos llamada</span> <em><span>osteonecrosis</span></em> <span>(muerte del tejido &#243;seo debida a una p&#233;rdida del suministro de sangre al hueso). Tomar este tipo de medicamentos durante un tiempo prolongado, tomar corticosteroides, beber alcohol, tener un sistema inmunitario muy d&#233;bil y tener sobrepeso, pueden ser algunos de los muchos factores de riesgo para desarrollar esta enfermedad. Los signos de osteonecrosis son:</span></li><ul><li><span>rigidez articular</span></li><li><span>molestias y dolores articulares (especialmente de la cadera, la rodilla y el hombro)</span></li><li><span>dificultad para moverse</span></li></ul></ul><strong><span>Si nota cualquiera de estos s&#237;ntomas, informe a su m&#233;dico.</span></strong><p><span>Durante el tratamiento del VIH puede haber un aumento en el peso y en los niveles de glucosa y l&#237;pidos en la sangre. Esto puede estar en parte relacionado con la recuperaci&#243;n de la salud y con el estilo de vida y, en el caso de los l&#237;pidos en la sangre, algunas veces con los medicamentos contra el VIH por s&#237; mismos. Su m&#233;dico le controlar&#225; estos cambios.</span></p><p><strong><span>Comunicaci&#243;n de efectos adversos</span></strong></p><p><span>Si experimenta cualquier tipo de efecto adverso, consulte a su m&#233;dico o farmac&#233;utico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. Tambi&#233;n puede comunicarlos directamente</span> <span>a trav&#233;s del sistema nacional de notificaci&#243;n incluido en el</span> <a href=\"http://www.ema.europa.eu/docs/en_GB/document_library/Template_or_form/2013/03/WC500139752.doc\"><span>Ap&#233;ndice V.</span></a> <span>Mediante la comunicaci&#243;n de efectos adversos usted puede contribuir a proporcionar m&#225;s informaci&#243;n sobre la seguridad de este medicamento.</span></p></div>"
          }
        },
        {
          "title" : "5. Conservación de Biktarvy",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Conservación de Biktarvy"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Mantener este medicamento fuera de la vista y del alcance de los ni&#241;os.</span></p><p><span>No utilice este medicamento despu&#233;s de la fecha de caducidad que aparece en la caja y en el frasco despu&#233;s de {CAD}. La fecha de caducidad es el &#250;ltimo d&#237;a del mes que se indica.</span></p><p><span>Conservar en el embalaje original para protegerlo de la humedad. Mantener el frasco perfectamente cerrado. No utilizar si falta el sello del frasco o est&#225; roto.</span></p><p><a name=\"page7\" id=\"page7\"></a><span>Los medicamentos no se deben tirar por los desag&#252;es ni a la basura. Pregunte a su farmac&#233;utico c&#243;mo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudar&#225; a proteger el medio ambiente.</span></p></div>"
          }
        },
        {
          "title" : "6. Contenido del envase e información adicional",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contenido del envase e información adicional"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Composici&#243;n de Biktarvy</span></strong></p><p><strong><span>Los principios activos son</span></strong> <span>bictegravir, emtricitabina y tenofovir alafenamida. Cada comprimido de</span> <span>Biktarvy contiene bictegravir s&#243;dico equivalente a 50 mg de bictegravir, 200 mg de emtricitabina y tenofovir alafenamida fumarato equivalente a 25 mg de tenofovir alafenamida.</span></p><p><strong><span>Los dem&#225;s componentes son</span></strong></p><p><em><span>N&#250;cleo del comprimido</span></em></p><p><span>Celulosa microcristalina, croscarmelosa s&#243;dica, estearato de magnesio.</span></p><p><em><span>Recubrimiento con pel&#237;cula</span></em></p><p><span>Alcohol polivin&#237;lico, di&#243;xido de titanio (E171), macrogol, talco, &#243;xido de hierro rojo (E172), &#243;xido de hierro negro (E172).</span></p><p><strong><span>Aspecto del producto y contenido del envase</span></strong></p><p><span>Los comprimidos recubiertos con pel&#237;cula de Biktarvy son comprimidos recubiertos con pel&#237;cula de color marr&#243;n purp&#250;reo, con forma de c&#225;psula, marcados en una de las caras del comprimido con &#171;GSI&#187; y en la otra cara del comprimido con &#171;9883&#187;. Biktarvy se presenta en frascos de 30 comprimidos y en envases de 3 frascos, conteniendo cada uno de ellos 30 comprimidos. Cada frasco contiene un desecante de gel de s&#237;lice que debe conservarse en el frasco para ayudar a proteger los comprimidos. El desecante de gel de s&#237;lice est&#225; contenido en un sobre o recipiente separado, y no se debe tragar.</span></p><p><span>Puede que solamente est&#233;n comercializados algunos tama&#241;os de envases.</span></p><p><strong><span>Titular de la autorizaci&#243;n de comercializaci&#243;n</span></strong></p><p><span>Gilead Sciences Ireland UC</span></p><p><span>Carrigtohill</span></p><p><span>County Cork, T45 DP77</span></p><p><span>Irlanda</span></p><p><strong><span>Responsable de la fabricaci&#243;n</span></strong></p><p><span>Gilead Sciences Ireland UC</span></p><p><span>IDA Business &#38; Technology Park</span></p><p><span>Carrigtohill</span></p><p><span>County Cork</span></p><p><span>Irlanda</span></p><p><span>Pueden solicitar m&#225;s informaci&#243;n respecto a este medicamento dirigi&#233;ndose al representante local del titular de la autorizaci&#243;n de comercializaci&#243;n:</span></p><table cellspacing=\"0\" cellpadding=\"0\"><tr><td><p><strong><span>Belgi&#235;/Belgique/Belgien</span></strong></p><p><span>Gilead Sciences Belgium SPRL-BVBA</span></p><p><span>T&#233;l/Tel: + 32 (0) 24 01 35 50</span></p></td><td><p><strong><span>Lietuva</span></strong></p><p><span>Gilead Sciences Poland Sp. z o.o.</span></p><p><span>Tel.: + 48 (0) 22 262 8702</span></p></td></tr><tr><td><p><strong><span>????????</span></strong></p><p><span>Gilead Sciences Ireland UC</span></p><p><span>???.: + 353 (0) 1 686 1888</span></p></td><td><p><strong><span>Luxembourg/Luxemburg</span></strong></p><p><span>Gilead Sciences Belgium SPRL-BVBA</span></p><p><span>T&#233;l/Tel: + 32 (0) 24 01 35 50</span></p></td></tr><tr><td><p><strong><span>Cesk&#225; republika</span></strong></p><p><span>Gilead Sciences s.r.o.</span></p><p><span>Tel: + 420 (0) 910 871 986</span></p></td><td><p><strong><span>Magyarorsz&#225;g</span></strong></p><p><span>Gilead Sciences</span> <span>Ireland UC</span></p><p><span>Tel.: + 353 (0) 1 686 1888</span></p></td></tr><tr><td><p><strong><span>Danmark</span></strong></p><p><span>Gilead Sciences Sweden AB</span></p><p><span>Tlf: + 46 (0) 8 5057 1849</span></p></td><td><p><strong><span>Malta</span></strong></p><p><span>Gilead Sciences Ireland UC</span></p><p><span>Tel: + 353 (0) 1 686 1888</span></p></td></tr><tr><td><p><strong><span>Deutschland</span></strong></p><p><span>Gilead Sciences GmbH</span></p><p><span>Tel: + 49 (0) 89 899890-0</span></p></td><td><p><strong><span>Nederland</span></strong></p><p><span>Gilead Sciences Netherlands B.V.</span></p><p><span>Tel: + 31 (0) 20 718 36 98</span></p></td></tr><tr><td><p><strong><span>Eesti</span></strong></p><p><span>Gilead Sciences Poland Sp. z o.o.</span></p><p><span>Tel.: +48 (0) 22 262 8702</span></p></td><td><p><strong><span>Norge</span></strong></p><p><span>Gilead Sciences Sweden AB</span></p><p><span>Tlf: + 46 (0) 8 5057 1849</span></p></td></tr><tr><td><p><strong><span>&#917;&#955;&#955;?&#948;&#945;</span></strong></p><p><span>Gilead Sciences &#917;&#955;&#955;?&#962; &#924;.&#917;&#928;&#917;.</span></p><p><span>&#932;&#951;&#955;: + 30 (0) 210 8930 100</span></p></td><td><p><strong><span>&#214;sterreich</span></strong></p><p><span>Gilead Sciences GesmbH</span></p><p><span>Tel: + 43 (0) 1 260 830</span></p></td></tr><tr><td><p><strong><span>Espa&#241;a</span></strong></p><p><span>Gilead Sciences, S.L.</span></p><p><span>Tel: + 34 (0) 91 378 98 30</span></p></td><td><p><strong><span>Polska</span></strong></p><p><span>Gilead Sciences Poland Sp. z o.o.</span></p><p><span>Tel.: + 48 (0) 22 262 870</span><span>2</span></p></td></tr><tr><td><p><strong><span>France</span></strong></p><p><span>Gilead Sciences</span></p><p><span>T&#233;l: + 33 (0) 1 46 09 41 00</span></p></td><td><p><strong><span>Portugal</span></strong></p><p><span>Gilead Sciences, Lda.</span></p><p><span>Tel: + 351 (0) 21 7928790</span></p></td></tr><tr><td><p><strong><span>Hrvatska</span></strong></p><p><span>Gilead Sciences Ireland UC</span></p><p><span>Tel: + 353 (0) 1 686 1888</span></p></td><td><p><strong><span>Rom&#226;nia</span></strong></p><p><span>Gilead Sciences Ireland UC</span></p><p><span>Tel: + 353 (0) 1 686 1888</span></p></td></tr><tr><td><p><strong><span>Irlanda</span></strong></p><p><span>Gilead Sciences Ireland UC</span></p><p><span>Tel: + 353 (0) 214 825 999</span></p></td><td><p><strong><span>Slovenija</span></strong></p><p><span>Gilead Sciences Ireland UC</span></p><p><span>Tel: + 353 (0) 1 686 1888</span></p></td></tr><tr><td><p><strong><span>&#205;sland</span></strong></p><p><span>Gilead Sciences Sweden AB</span></p><p><span>S&#237;mi: + 46 (0) 8 5057 1849</span></p></td><td><p><strong><span>Slovensk&#225; republika</span></strong></p><p><span>Gilead Sciences Slovakia s.r.o.</span></p><p><span>Tel: + 421 (0) 232 121 210</span></p></td></tr><tr><td><p><strong><span>Italia</span></strong></p><p><span>Gilead Sciences S.r.l.</span></p><p><span>Tel: + 39 02 439201</span></p></td><td><p><strong><span>Suomi/Finland</span></strong></p><p><span>Gilead Sciences Sweden AB</span></p><p><span>Puh/Tel: + 46 (0) 8 5057 1849</span></p></td></tr><tr><td><p><strong><span>&#922;?&#960;&#961;&#959;&#962;</span></strong></p><p><span>Gilead Sciences &#917;&#955;&#955;?&#962; &#924;.&#917;&#928;&#917;.</span></p><p><span>&#932;&#951;&#955;: + 30 (0) 210 8930 100</span></p></td><td><p><strong><span>Sverige</span></strong></p><p><span>Gilead Sciences Sweden A</span><span>B</span></p><p><span>Tel: + 46 (0) 8 5057 1849</span></p></td></tr><tr><td><p><strong><span>Latvija</span></strong></p><p><span>Gilead Sciences Poland Sp. z o.o.</span></p><p><span>Tel.: + 48 (0) 22 262 8702</span></p></td><td><p><strong><span>Reino Unido</span></strong></p><p><span>Gilead Sciences Ltd.</span></p><p><span>Tel: + 44 (0) 8000 113 700</span></p></td></tr></table><p><a name=\"page9\" id=\"page9\"></a><strong><span>Fecha de la &#250;ltima revisi&#243;n de este prospecto:</span></strong></p><p><span>La informaci&#243;n detallada de este medicamento est&#225; disponible en la p&#225;gina web de la Agencia Europea de Medicamentos:</span> <a href=\"http://www.ema.europa.eu/\"><span>http://www.ema.europa.eu.</span></a></p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-d79af6e660f456c6c7091803d6bd1a92",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-d79af6e660f456c6c7091803d6bd1a92",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-d79af6e660f456c6c7091803d6bd1a92\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-d79af6e660f456c6c7091803d6bd1a92</b></p><a name=\"cud-d79af6e660f456c6c7091803d6bd1a92\"> </a><a name=\"hccud-d79af6e660f456c6c7091803d6bd1a92\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/pregnancy (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr nan}\">nan</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "pregnancy"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "nan",
              "display" : "nan"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-bictegravirsodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-bictegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-bictegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-bictegravirsodium</b></p><a name=\"ingredient-for-biktarvy-bictegravirsodium\"> </a><a name=\"hcingredient-for-biktarvy-bictegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/4L5MP1Y7W7 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 4L5MP1Y7W7}\">BICTEGRAVIR SODIUM</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>50 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "4L5MP1Y7W7"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "4L5MP1Y7W7",
              "display" : "BICTEGRAVIR SODIUM"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 50,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-emtricitabine",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-emtricitabine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-emtricitabine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-emtricitabine</b></p><a name=\"ingredient-for-biktarvy-emtricitabine\"> </a><a name=\"hcingredient-for-biktarvy-emtricitabine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/G70B4ETF4S (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta G70B4ETF4S}\">Emtricitabine</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>200 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "G70B4ETF4S"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "G70B4ETF4S",
              "display" : "Emtricitabine"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 200,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-tenofoviralafenamide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-tenofoviralafenamide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-tenofoviralafenamide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-tenofoviralafenamide</b></p><a name=\"ingredient-for-biktarvy-tenofoviralafenamide\"> </a><a name=\"hcingredient-for-biktarvy-tenofoviralafenamide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EL9943AG5J (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EL9943AG5J}\">tenofovir alafenamide</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>25 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EL9943AG5J"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EL9943AG5J",
              "display" : "tenofovir alafenamide"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 25,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-microcrystallinecellulose</b></p><a name=\"ingredient-for-biktarvy-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-biktarvy-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">Microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "Microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-croscarmellosesodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-croscarmellosesodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-croscarmellosesodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-croscarmellosesodium</b></p><a name=\"ingredient-for-biktarvy-croscarmellosesodium\"> </a><a name=\"hcingredient-for-biktarvy-croscarmellosesodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/M28OL1HH48 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta M28OL1HH48}\">Croscarmellose sodium</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "M28OL1HH48"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "M28OL1HH48",
              "display" : "Croscarmellose sodium"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-magnesiumstearate</b></p><a name=\"ingredient-for-biktarvy-magnesiumstearate\"> </a><a name=\"hcingredient-for-biktarvy-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-94a96e39cfdcd8b378d12dd4063065f9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-94a96e39cfdcd8b378d12dd4063065f9</b></p><a name=\"ap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><a name=\"hcap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization94a96e39cfdcd8b378d12dd4063065f90",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization94a96e39cfdcd8b378d12dd4063065f90",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization94a96e39cfdcd8b378d12dd4063065f90</b></p><a name=\"authorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><a name=\"hcauthorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2018-06-21 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mah-715f8a161ed438d0584510e5b4512caa\">Organization Gilead Sciences Ireland UC</a></p><p><b>regulator</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mra-1133a7374c78f1d40f41885344f06a5a\">Organization European Medicines Agency</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2018-06-21T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-715f8a161ed438d0584510e5b4512caa"
      },
      "regulator" : {
        "reference" : "Organization/mra-1133a7374c78f1d40f41885344f06a5a"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-715f8a161ed438d0584510e5b4512caa",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-715f8a161ed438d0584510e5b4512caa",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-715f8a161ed438d0584510e5b4512caa\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-715f8a161ed438d0584510e5b4512caa</b></p><a name=\"mah-715f8a161ed438d0584510e5b4512caa\"> </a><a name=\"hcmah-715f8a161ed438d0584510e5b4512caa\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100008368 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Gilead Sciences Ireland UC</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carrigtohill, County Cork, T45 County Cork IR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100008368"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Gilead Sciences Ireland UC",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carrigtohill, County Cork, T45 County Cork IR",
          "line" : ["Carrigtohill, County Cork, T45"],
          "city" : "County Cork",
          "country" : "IR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mra-1133a7374c78f1d40f41885344f06a5a",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mra-1133a7374c78f1d40f41885344f06a5a",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mra-1133a7374c78f1d40f41885344f06a5a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mra-1133a7374c78f1d40f41885344f06a5a</b></p><a name=\"mra-1133a7374c78f1d40f41885344f06a5a\"> </a><a name=\"hcmra-1133a7374c78f1d40f41885344f06a5a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100013412 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000032}\">Medicines Regulatory Authority</span></p><p><b>name</b>: European Medicines Agency</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100013412"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000032",
          "display" : "Medicines Regulatory Authority"
        }]
      }],
      "name" : "European Medicines Agency",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL",
          "line" : ["Carretera De Martorell 41 61, Poligono Industrial Nord-Est"],
          "city" : "Amsterdam",
          "postalCode" : "1083 HS",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-e34e4b65abd3fd8e667db05606cc25a9",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-e34e4b65abd3fd8e667db05606cc25a9",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-e34e4b65abd3fd8e667db05606cc25a9</b></p><a name=\"ppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><a name=\"hcppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, ), Gtin/07612345678904 (use: official, )</p><p><b>name</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 90</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 90</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      },
      {
        "use" : "official",
        "system" : "https://www.gs1.org/gtin",
        "value" : "07612345678904"
      }],
      "name" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 90",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 90,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-6d93344139a7793e7b9bd0f5e32b6c91",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-6d93344139a7793e7b9bd0f5e32b6c91",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-6d93344139a7793e7b9bd0f5e32b6c91</b></p><a name=\"ppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><a name=\"hcppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>name</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "name" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp2a9c4333cfd126f2e7b73ad3cafd6949",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp2a9c4333cfd126f2e7b73ad3cafd6949</b></p><a name=\"mp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><a name=\"hcmp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E827gy</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Biktarvy</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: bictegravir/emtricitabine/tenofovir alafenamide</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 50 mg/200 mg/25 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E827gy"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Biktarvy",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "bictegravir/emtricitabine/tenofovir alafenamide",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "50 mg/200 mg/25 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "film-coated tablets",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-94a96e39cfdcd8b378d12dd4063065f9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-94a96e39cfdcd8b378d12dd4063065f9</b></p><a name=\"mid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><a name=\"hcmid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/contraindication-kidney-bik",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "contraindication-kidney-bik",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_contraindication-kidney-bik\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition contraindication-kidney-bik</b></p><a name=\"contraindication-kidney-bik\"> </a><a name=\"hccontraindication-kidney-bik\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/kidney function (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 76114004}\">Decreased renal function (finding)</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "kidney function"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "76114004",
              "display" : "Decreased renal function (finding)"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/contraindication-diabetes-mellitus-bik",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "contraindication-diabetes-mellitus-bik",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_contraindication-diabetes-mellitus-bik\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition contraindication-diabetes-mellitus-bik</b></p><a name=\"contraindication-diabetes-mellitus-bik\"> </a><a name=\"hccontraindication-diabetes-mellitus-bik\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/diabetes-mellitus (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 73211009}\">Diabetes mellitus (disorder)</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "diabetes-mellitus"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "73211009",
              "display" : "Diabetes mellitus (disorder)"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/contraindication-pregnancy-bik",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "contraindication-pregnancy-bik",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_contraindication-pregnancy-bik\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition contraindication-pregnancy-bik</b></p><a name=\"contraindication-pregnancy-bik\"> </a><a name=\"hccontraindication-pregnancy-bik\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/pregnancy (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 289908002}\">Pregnancy, function (observable entity)</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "pregnancy"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "289908002",
              "display" : "Pregnancy, function (observable entity)"
            }]
          }
        }
      }
    }
  }]
}

```
