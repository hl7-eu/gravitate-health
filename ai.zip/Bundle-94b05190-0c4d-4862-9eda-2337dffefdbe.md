# 94b05190-0c4d-4862-9eda-2337dffefdbe - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **94b05190-0c4d-4862-9eda-2337dffefdbe**

## Bundle: 94b05190-0c4d-4862-9eda-2337dffefdbe



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "94b05190-0c4d-4862-9eda-2337dffefdbe",
  "identifier" : {
    "system" : "http://ema.europa.eu/fhir/epiGuid",
    "value" : "94b05190-0c4d-4862-9eda-2337dffefdbe"
  },
  "type" : "collection",
  "timestamp" : "2024-12-13T18:58:38.0353768+01:00",
  "entry" : [{
    "fullUrl" : "686ad92e-576a-4031-a554-dae891014624",
    "resource" : {
      "resourceType" : "List",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_null\"> </a>electronic Product Information (ePI) master document list</div>"
      },
      "identifier" : [{
        "system" : "http://ema.europa.eu/fhir/epiId",
        "value" : "EPI/24/129"
      }],
      "status" : "current",
      "mode" : "working",
      "title" : "all sections Spanish document",
      "code" : {
        "coding" : [{
          "system" : "http://ema.europa.eu/fhir/documentType",
          "code" : "00001",
          "display" : "epiMasterList"
        }]
      },
      "subject" : [{
        "reference" : "subjectReference"
      }],
      "entry" : [{
        "item" : {
          "reference" : "referenceToDocument",
          "display" : "Ficha técnica o resumen de las características del producto"
        }
      },
      {
        "item" : {
          "reference" : "referenceToDocument",
          "display" : "Prospecto"
        }
      }]
    }
  },
  {
    "fullUrl" : "4ef9349e-6c40-4b33-b4da-484171e2c491",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "4ef9349e-6c40-4b33-b4da-484171e2c491",
      "identifier" : {
        "system" : "http://ema.europa.eu/fhir/epiDocument",
        "value" : "4ef9349e-6c40-4b33-b4da-484171e2c491"
      },
      "type" : "document",
      "timestamp" : "2024-12-13T18:58:38.0353768+01:00",
      "entry" : [{
        "fullUrl" : "4ef9349e-6c40-4b33-b4da-484171e2c491",
        "resource" : {
          "resourceType" : "Composition",
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">electronic Product Information (ePI) document</div>"
          },
          "status" : "final",
          "type" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/100000155531",
              "code" : "100000155532",
              "display" : "Ficha técnica o resumen de las características del producto"
            }]
          },
          "subject" : [{
            "reference" : "subjectReference"
          }],
          "date" : "2024-12-13",
          "author" : [{
            "reference" : "systemUser"
          }],
          "title" : "Ficha técnica o resumen de las características del producto",
          "section" : [{
            "title" : "Ficha técnica o resumen de las características del producto",
            "code" : {
              "coding" : [{
                "system" : "http://spor.ema.europa.eu/v1/lists/100000155531",
                "code" : "200000029791",
                "display" : "Ficha técnica o resumen de las características del producto"
              }]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
            },
            "section" : [{
              "id" : "d18301f1-cec7-423d-b034-71186f01ca61",
              "title" : "1. Nombre del medicamento",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029792",
                  "display" : "Nombre del medicamento"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>PENTASA</span><span>1 g</span><span>suspensión rectal</span></p></div>"
              }
            },
            {
              "id" : "090afc39-2c19-4d9c-ba6a-007d5a4f191c",
              "title" : "2. Composición cualitativa y cuantitativa",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029793",
                  "display" : "Composición cualitativa y cuantitativa"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Un envase de 100 ml contiene 1 g de mesalazina.</span></p><p><em><span> </span></em></p><p><span>Excipientes: Metabisulfito sódico (E-223) 100 mg.</span></p><p><em><span> </span></em></p><p><span>Para</span><span>consultar la lista completa de</span><span>excipientes ver sección 6.1.</span></p><p><span> </span></p></div>"
              }
            },
            {
              "id" : "99d20131-bb44-4507-81ba-da4cab779fb4",
              "title" : "3. Forma farmacéutica",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029797",
                  "display" : "Forma farmacéutica"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Suspensión rectal</span><span>.</span></p><p><span>Suspensión blanc</span><span>a</span><span>a ligeramente amarilla</span><span>.</span></p><p><span> </span></p></div>"
              }
            },
            {
              "id" : "8c61d56c-d207-4d70-9daf-b44c98c758e2",
              "title" : "4. Datos clínicos",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029798",
                  "display" : "Datos clínicos"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "827e4edc-2c63-4049-9e40-a179e62d19a2",
                "title" : "4.1. Indicaciones terapéuticas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029799",
                    "display" : "Indicaciones terapéuticas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Tratamiento de la colitis ulcerosa localizada en recto y colon sigmoideo.</span></p></div>"
                }
              },
              {
                "id" : "ef8f8b26-90b3-451d-b8b7-b74fb60ae0c0",
                "title" : "4.2. Posología y forma de administración",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029800",
                    "display" : "Posología y forma de administración"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Dosis recomendada:</span></strong></p><p><em><span> </span></em></p><p><span><span>Adultos:</span></span><span>Se recomienda una dosis de</span><span>1 g</span><span>de</span><span>mesalazina</span><span>5-ASA</span><span>(un envase de suspensión rectal de 100 ml) al acostarse durante 2-3 semanas. Se puede reducir la dosis según el peso corporal del paciente.</span></p><p><em><span> </span></em></p><p><span><span>Población pediátrica</span></span><span>: Hay poca experiencia y sólo existe documentación limitada del efecto en los niños (6-18 años).</span></p><p><em><span> </span></em></p><p><span>Se recomienda</span><span>realizar una evacuación intestinal</span><span>antes de la administración de la suspensión rectal y</span><span>los</span><span>supositorios. Véase las instrucciones de uso adjuntas.</span></p><p><em><span> </span></em></p><p><span>Agitar bien el envase antes de usar. Los envases de suspensión rectal están protegidos por una</span><span>bolsa</span><span>de aluminio y deben ser utilizados inmediatamente después de su apertura.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "f27ac068-0643-46d5-86f5-8b2d21213b15",
                "title" : "4.3. Contraindicaciones",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029805",
                    "display" : "Contraindicaciones"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No debe administrarse PENTASA</span><span>1 g</span><span>suspensión rectal, en los siguientes casos:</span></p><ul><li><span>Hipersensibilidad a la mesalazina, o a los salicilatos o a algunos de los excipientes</span><span>incluidos en la sección 6.1</span><span>.</span></li><li><span>Pacientes con insuficiencia renal o hepática grave.</span></li></ul></div>"
                }
              },
              {
                "id" : "48e820f9-f069-43eb-a0da-c0c24bb33aee",
                "title" : "4.4. Advertencias y precauciones especiales de empleo",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029806",
                    "display" : "Advertencias y precauciones especiales de empleo"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Debe tenerse especial</span><span>precaución en el tratamiento de pacientes alérgicos a la sulfasalazina (riesgo de alergia a salicilatos).</span><span>Se han observado reacciones adversas cutáneas graves, como reacción al medicamento con eosinofilia y síntomas sistémicos (DRESS), síndrome de Stevens-Johnson (SSJ) y necrólisis epidérmica tóxica (NET) con el tratamiento de mesalazina. La administración de mesalazina debe suspenderse inmediatamente en caso de reacciones de intolerancia agudas, tales como calambres abdominales, dolor abdominal agudo, fiebrey dolor de cabeza intenso y/o ante los primeros signos o síntomas de reacciones cutáneas graves, como exantema cutáneo,  erupciones, lesiones mucosas o cualquier otro signo de hipersensibilidad.</span></p><p><span> </span></p><p><span>Deben tomarse precauciones especiales en pacientes con la función hepática deteriorada.</span><span>Se deben evaluar, antes y durante el tratamiento, a criterio del médico, los parámetros de la función hepática como ALT o AST.</span></p><p><span> </span></p><p><span>No se recomienda el uso de Pentasa en pacientes con insuficiencia renal. Se debe monitorizar la función renal a intervalos regulares (creatinina sérica), especialmente al inicio del tratamiento. Se debe determinar el estado urinario (tiras reactivas) antes y durante el tratamiento, a criterio del médico</span><em><span>.</span></em><span>En los pacientes que desarrollen una alteración renal durante el tratamiento se debe sospechar nefrotoxicidad inducida por la mesalazina. El uso concomitante de otros fármacos nefrotóxicos conocidos, debe aumentar la frecuencia de monitorización de la función renal.</span></p><p><span> </span></p><p><span>Los pacientes con enfermedad pulmonar, en particular asma, deben ser monitorizados cuidadosamente durante el tratamiento, consultar sección 4.8.</span></p><p><span> </span></p><p><span>Se han comunicado raramente reacciones de hipersensibilidad cardíaca inducidas por mesalazina (mio- y pericarditis). Se han descrito muy raramente discrasias sanguíneas graves.</span><span>Se recomienda realizar análisis de sangre para el recuento diferencial</span><span>antes y durante el tratamiento, a criterio del médico. Como se señala en la sección 4.5</span><em><span>,</span></em><span>el tratamiento concomitante con mesalazina puede incrementar el riesgo de discrasia sanguínea en pacientes que están siendo tratados con azatioprina o 6-mercaptopurina o tioguanina. Debe interrumpirse el tratamiento cuando exista sospecha ó evidencia de la aparición de dichas reacciones.</span></p><p><span> </span></p><p><span>Se han notificado casos de nefrolitiasis con el uso de mesalazina, lo que incluye la aparición de</span></p><p><span>cálculos con un contenido de mesalazina del 100 %. Se recomienda garantizar una ingesta</span></p><p><span>suficiente de líquidos durante el tratamiento.</span></p><p><span> </span></p><p><span>Como pauta orientativa, se recomienda pruebas de seguimiento 14 días después del inicio del tratamiento y posteriormente 2 ó 3 pruebas adicionales a intervalos de 4 semanas. Si los resultados son normales, las pruebas de seguimiento se deben realizar cada 3 meses. Si se producen síntomas adicionales, estas pruebas se deben realizar inmediatamente.</span></p><p><span> </span></p><p><span>Se debe utilizar con cuidado en ancianos y solamente en pacientes con la función renal normal.</span></p><p><span> </span></p><p><span>La mesalazina puede producir un cambio de color de la orina de color rojo-marrón tras el contacto con lejía de hipoclorito de sodio (por ejemplo, en los inodoros limpiados con ciertas lejías que contienen hipoclorito de sodio).</span></p><p><span> </span></p><p><span>Por contener metabisulfito sódico (E-223) raramente puede provocar reacciones de alergias graves y broncoespasmos (sensación repentina de ahogo).</span></p></div>"
                }
              },
              {
                "id" : "de4ff7c6-fcb0-4085-b6e8-2e086fbe6382",
                "title" : "4.5. Interacción con otros medicamentos y otras formas de interacción",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029809",
                    "display" : "Interacción con otros medicamentos y otras formas de interacción"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>En varios estudios se ha mostrado una mayor frecuencia de efectos mielosupresores en el tratamiento combinado de Pentasa y azatioprina, 6-mercaptopurina o tioguanina, y parece existir una interacción, sin embargo, no se ha podido establecer el mecanismo de interacción.</span><span>Se recomienda una monitorización de las células blancas sanguíneas y en consecuencia se deberá ajustar la dosificación de tiopurinas.</span></p><p><span> </span></p><p><span>Existe una evidencia débil de que la mesalazina podría disminuir el efecto anticoagulante de la warfarina.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "4ba105c9-1b7d-4096-9ab8-7a845e42d9b5",
                "title" : "4.6. Fertilidad, embarazo y lactancia",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029811",
                    "display" : "Fertilidad, embarazo y lactancia"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Pentasa se debe utilizar con precaución durante el embarazo y la lactancia, y solo cuando según la opinión del médico especialista el beneficio potencial supere al riesgo. La enfermedad de base en sí misma (Enfermedad inflamatoria intestinal EII)) puede aumentar los riesgos de resultado adverso del embarazo..</span></p></div>"
                },
                "section" : [{
                  "id" : "4ba2b2c3-cac7-41cd-b139-972f09aee4f6",
                  "title" : "4.6.1. Embarazo",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029812",
                      "display" : "Embarazo"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Se sabe que la mesalazina atraviesa la barrera placentaria y la concentración en el cordón umbilical es una décima parte de la concentración en el plasma materno. El metabolito acetil mesalazina se encuentra en la misma concentración en el cordón umbilical y en el plasma de la madre. Los estudios en animales con mesalazina oral, no muestran efectos perjudiciales directos o indirectos en relación al embarazo, desarrollo embrionario/fetal, parto y desarrollo postnatal. No existen estudios adecuados y controlados del uso de Pentasa en mujeres embarazadas. Los datos publicados sobre mesalazina en humanos son limitados  y muestran que no hay un aumento de la tasa global de malformaciones congénitas. Algunos datos muestran un aumento de la tasa de partos pretérmino, muerte fetal, y bajo peso al nacer; sin embargo estos resultados adversos del embarazo también están asociados con la enfermedad inflamatoria intestinal activa.</span></p><p><span>Se han reportado trastornos sanguíneos (pancitopenia, leucopenia, trombocitopenia, anemia) en recién nacidos de madres tratadas con Pentasa.</span></p><p><span> </span></p><p><span>En un caso aislado de utilización a largo plazo de dosis altas de mesalazina (2-4g, vía oral) durante el embarazo, se notificó fallo renal en el neonato.</span></p></div>"
                  }
                },
                {
                  "id" : "ab1ef69d-f79c-46f1-9691-cabf4d442b03",
                  "title" : "4.6.2. Lactancia",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029813",
                      "display" : "Lactancia"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>La mesalazina pasa a la leche materna. La concentración de mesalazina en la leche materna es mucho menor que en la sangre materna, mientras que su metabolito, acetil mesalazina, aparece en concentraciones similares o superiores. Hasta la fecha, solo existe una experiencia limitada tras la administración oral en mujeres durante el periodo de lactancia. No se han realizado estudios controlados de Pentasa durante la lactancia. No pueden excluirse reacciones de hipersensibilidad como diarrea.</span></p><p><em><span>             </span></em><em><span>             </span></em></p><p><span>En caso de que el lactante presente diarrea, la lactancia deberá interrumpirse.</span></p></div>"
                  }
                },
                {
                  "id" : "a2c515e6-a6f7-4aef-ae1b-88bb8d2f78e0",
                  "title" : "4.6.3. Fertilidad",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029814",
                      "display" : "Fertilidad"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Los datos de mesalazina en animales muestran que no tiene efecto sobre la fertilidad masculina o femenina.</span></p></div>"
                  }
                }]
              },
              {
                "id" : "58fd9578-4e6a-41e2-857d-896faf84a2f1",
                "title" : "4.7. Efectos sobre la capacidad para conducir y utilizar máquinas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029815",
                    "display" : "Efectos sobre la capacidad para conducir y utilizar máquinas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No hay indicios de que Pentasa suspensión rectal, tenga efecto sobre la capacidad para conducir o utilizar máquinas.</span></p></div>"
                }
              },
              {
                "id" : "8e2b62e2-9634-42e7-af90-c8cf9a7a992d",
                "title" : "4.8. Reacciones adversas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029816",
                    "display" : "Reacciones adversas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Las reacciones adversas observadas más frecuentemente en los ensayos clínicos son diarrea, náuseas, dolor abdominal, dolor de cabeza, vómitos y erupciones cutáneas.</span></p><p><span> </span></p><p><span>Ocasionalmente pueden aparecer reacciones de hipersensibilidad y fiebre medicamentosa.</span></p><p><span>Se han observado reacciones adversas cutáneas graves (RACG), como reacción al medicamento con eosinofilia y síntomas sistémicos (DRESS), el síndrome de Stevens-Johnson (SSJ) y la necrólisis epidérmica tóxica (NET), asociados a la administración de mesalazina (ver sección</span><span> </span><span>4.4).</span></p><p><span> </span></p><p><span>Tras la administración rectal pueden aparecer reacciones locales como prurito, molestias rectales y urgencia de defecar.</span></p><p><span> </span></p><p><span>A continuación se incluye una tabla con la frecuencia de las reacciones adversas, basada en los ensayos clínicos y estudios epidemiológicos:</span></p><p><span> </span></p><table cellpadding=\"0\" cellspacing=\"0\"><tr><td><p><span>Clasificación de órganos del sistema MedDRA</span></p></td><td><p><span>Frecuentes</span></p><p><span>(</span><span>?</span><span>1/100 a &lt; 1/10)</span></p></td><td><p><span>Raras</span></p><p><span>(</span><span>?</span><span>10/10.000 a &lt; 1/1.000)</span></p></td><td><p><span>Muy raras</span></p><p><span>(&lt; 1/10.000)</span></p></td><td><p><span>Frecuencia no conocida (no puede estimarse a partir de los datos disponibles)</span></p></td></tr><tr><td><p><span>Trastornos de la sangre y del sistema linfático:</span></p><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Recuento sanguíneo alterado: anemia, anemia aplásica, agranulocitosis, neutropenia,  leucopenia (incluida granulocitopenia), pancitopenia trombocitopenia, y eosinofilia (como parte de una reacción alérgica).</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos del sistema inmunológico</span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p><p><span>Reacción de hipersensibilidad que incluye reacción anafiláctica.</span></p><p><span> </span></p><p><span> </span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos del sistema nervioso:</span></p></td><td><p><span>Dolor de cabeza</span></p><p><span> </span></p></td><td><p><span>Mareos</span></p></td><td><p><span>Neuropatía periférica</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos cardíacos</span></p></td><td><p><span> </span></p></td><td><p><span>Miocarditis*</span></p><p><span> </span></p><p><span>Pericarditis*</span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos respiratorios, torácicos y mediastínicos</span></p><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Reacciones pulmonares alérgicas y fibróticas (incluida disnea, tos, broncoespasmo, alveolitis alérgica), eosinofilia pulmonar, enfermedad pulmonar intersticial, infiltración pulmonar, neumonitis.</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos</span><span>gastrointestinales</span></p></td><td><p><span>Diarrea, dolor abdominal, náuseas, vómitos, flatulencia</span></p></td><td><p><span>Aumento de la amilasa, pancreatitis aguda*,</span></p></td><td><p><span>Pancolitis</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos hepatobiliares</span></p><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Aumento de las transaminasas, aumento de los parámetros colestásicos (p.e. fosfatasa alcalina, gamma-glutamil transferasa y bilirrubina), hepatotoxicidad (incluida hepatitis*, hepatitis colestásica, cirrosis, fallo hepático)</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos de la piel y el tejido subcutáneo</span></p></td><td><p><span>Erupciones (incluida urticaria, erupción eritematosa)</span></p></td><td><p><span>Fotosensibilidad**</span></p></td><td><p><span>Alopecia reversible</span></p><p><span> </span></p><p><span>Alopecia reversible</span></p><p><span>Dermatitis alérgica</span></p><p><span>Eritema multiforme y</span></p></td><td><p><span>Síndrome de Stevens-Johson (SJS),</span><span>Necrólisis epidérmica tóxica (TEN)</span></p><p><span>Reacción al medicamento con eosinofilia y síntomas sistémicos (DRESS)</span></p></td></tr><tr><td><p><span>Trastorno</span><span>musculoesqueléticos y del tejido conjuntivo</span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Mialgia, artralgia,</span></p><p><span>Síndrome de pseudolupus (lupus eritematoso sistémico).</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos renales y urinarios***</span></p><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Alteración de la función renal (incl. nefritis intersticial* aguda y crónica,</span></p><p><span>síndrome nefrótico, insuficiencia renal),</span></p></td><td><p><span>Nefrolitiasis</span><span>***</span><span>Decoloración de la orina</span><span>***</span></p></td></tr><tr><td><p><span>Trastornos del aparato reproductor</span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Oligospermia (reversible)</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos generales y alteraciones en el lugar de administración:</span></p></td><td><p><span>Malestar anal e irritación en el lugar de la administración, prurito, tenesmo</span></p></td><td><p><span> </span></p></td><td><p><span>Fiebre medicamentosa</span></p></td><td><p><span> </span></p></td></tr></table><p><span> </span></p><p><span>(*) No se conoce el mecanismo de la mesalazina para inducir mio- y pericarditis, pancreatitis, nefritis y hepatitis, pero puede tener un origen alérgico. (La forma de presentación y resolución de los cuadros citados dentro de su posible origen alérgico están sujetos a una alta variabilidad inter e intraindividual, por lo que es imposible prever la gravedad y la evolución de los mismos.)</span></p><p><span>(**) Se han notificado reacciones más graves en pacientes con afecciones cutáneas preexistentes, como dermatitis atópica y eccema atópico.</span></p><p><span>(***)Véase la sección 4.4 si desea más información.</span></p><p><span> </span></p><p><span>Es importante resaltar que varias de estas alteraciones pueden también atribuirse a la enfermedad inflamatoria intestinal en sí misma.</span></p><p><span> </span></p></div>"
                },
                "section" : [{
                  "id" : "3220f1c2-2ad0-4f1b-af79-8c5a3f7c4a34",
                  "title" : "4.8.2. Notificación de sospechas de reacciones adversas",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029818",
                      "display" : "Notificación de sospechas de reacciones adversas"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span> </span></strong></p><p><span>Es importante notificar sospechas de reacciones adversas al medicamento tras su  autorización. Ello permite una supervisión continuada de la relación beneficio/riesgo del medicamento. Se invita a los profesionales sanitarios a notificar las sospechas de reacciones adversas a través del</span><span>Sistema Español de Farmacovigilancia de Medicamentos de Uso Humano</span><span>:</span><a href=\"http://www.notificaRAM.es\"><span><span>www.notificaRAM.es</span></span></a><span>.</span></p></div>"
                  }
                }]
              },
              {
                "id" : "c6b8cce5-faa5-4cba-9eee-e5c6c1eb9153",
                "title" : "4.9. Sobredosis",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029819",
                    "display" : "Sobredosis"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span><span>Experiencia aguda en animales:</span></span></p><p><span>La administración de dosis orales únicas de mesalazina de hasta 5 g/kg en cerdos o una dosis única intravenosa de mesalazina de 920 mg/kg en ratas no dieron lugar a mortalidad.</span></p><p><span> </span></p><p><span><span>Experiencia en humanos</span></span></p><p><span>Existe una experiencia clínica limitada en relación a la sobredosis con Pentasa, que no indica toxicidad renal o hepática. Teniendo en cuenta que Pentasa es un aminosalicilato, pueden ocurrir síntomas de toxicidad a los salicilatos tales como alteraciones del equilibrio ácido-base, hiperventilación, edema pulmonar, vómitos, deshidratación e hipoglucemia. Los síntomas de sobredosificación de salicilatos están correctamente descritos en la literatura.</span></p><p><span>Existen informes de pacientes que han tomado dosis diarias de 8g durante un mes sin efectos adversos.</span></p><p><span> </span></p><p><span> </span></p><p><span>No hay un antídoto específico y el tratamiento es sintomático y de mantenimiento. El tratamiento hospitalario incluye monitorización cuidadosa de la función renal.</span></p></div>"
                }
              }]
            },
            {
              "id" : "0f019072-b8e2-4c13-82c8-192e11d52e51",
              "title" : "5. Propiedades farmacológicas",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029821",
                  "display" : "Propiedades farmacológicas"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "227814a2-e364-4580-94bd-3f8609d8ac95",
                "title" : "5.1. Propiedades farmacodinámicas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029822",
                    "display" : "Propiedades farmacodinámicas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Grupo</span><span><span>farmacoterapéutico</span></span><span>: Agentes antiinflamatorios intestinales, ácido aminosalicílico y similares. Código ATC: A07E C02.</span></p><p><span> </span></p><p><span><span>Mecanismo de acción y efectos farmacodinámicos</span></span></p><p><span>Se ha establecido que la mesalazina es el componente activo de la sulfasalazina, utilizada para el tratamiento de la colitis ulcerosa y enfermedad de Crohn.</span></p><p><span>En base a los resultados clínicos, la acción terapéutica de la mesalazina después de la administración oral ó rectal parece ser debida al efecto local ejercido sobre el tejido intestinal inflamado, más que a un efecto sistémico. Hay información que sugiere que la gravedad de la inflamación colónica en pacientes de colitis ulcerosa tratados con mesalazina está inversamente correlacionada con las concentraciones mucosas de mesalazina.</span></p><p><span> </span></p><p><span>En pacientes con enfermedad inflamatoria intestinal se produce un aumento de la migración de los leucocitos, una producción anormal de citoquinas, un aumento de la producción de metabolitos del ácido araquidónico, particularmente del leucotrieno B4, y un au</span><span>mento de la formación de radicales libres en el tejido intestinal inflamado. El mecanismo de acción de mesalazina no se conoce completamente aunque están implicados mecanismos tales como la activación de la forma</span><span>γ</span><span>de los receptores activadores de proliferación de peroxisomas (PPAR- γ) e inhibición del factor nuclear kappa B (NF-κB) de la mucosa intestinal. La mesalazina presenta efectos farmacológicos tanto</span><em><span>in-vivo</span></em><span>como</span><em><span>in -vitro</span></em><span>que inhiben la quimiotaxis leucocitaria, disminuyen las citoquinas y la forma</span><span>ción de leucotrienos y eliminan radicales libres. Actualmente se desconoce cuál de estos mecanismos, si hay alguno, tiene un papel predominante en la eficacia clínica de mesalazina</span></p></div>"
                },
                "section" : [{
                  "id" : "630f9bc9-890f-4130-86d7-556013e2cac7",
                  "title" : "5.1.1. Mecanismo de acción",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029823",
                      "display" : "Mecanismo de acción"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>-</span></p></div>"
                  }
                },
                {
                  "id" : "855fed17-3a58-49b9-97cc-24df35aea046",
                  "title" : "5.1.2. Efectos farmacodinámicos",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029824",
                      "display" : "Efectos farmacodinámicos"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>-</span></p></div>"
                  }
                }]
              },
              {
                "id" : "4ef26027-8acd-4608-a17c-39b228281ed4",
                "title" : "5.2. Propiedades farmacocinéticas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029827",
                    "display" : "Propiedades farmacocinéticas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Características generales de la sustancia activa:</span></strong></p><p><span><span>Biodisponibilidad y disponibilidad local:</span></span></p><p><span>La actividad terapéutica de la mesalazina depende probablemente del contacto local del fármaco con el área afectada de la mucosa intestinal.</span></p><p><span>Pentasa 1g suspensión rectal está diseñada para proporcionar a la parte distal del tracto intestinal altas concentraciones de mesalazina y una lenta absorción sistémica. Se ha demostrado que la suspensión rectal alcanza y cubre el colón descendente.</span></p><p><span> </span></p><p><span> </span></p><p><span><span>Absorción:</span></span></p><p><span>La absorción tras una administración rectal es baja, aunque depende de la dosis administrada, de la formulación y del alcance de la suspensión. En base a la recuperación en la orina en voluntarios sanos en estado de equilibrio a los que les fue administrada una dosis diaria de</span><span>2 g</span><span>(</span><span>1</span><span> </span><span>g</span><span>x 2), aproximadamente un 15-20% de la dosis se absorbe después de la administración de la suspensión rectal.</span></p><p><span> </span></p><p><span><span>Distribución:</span></span></p><p><span>La unión a proteínas de la mesalazina es de aproximadamente un 50% y de la acetil-mesalazina de un 80%.</span></p><p><span> </span></p><p><span><span>Eliminación:</span></span></p><p><span>Una vez que la formulación no está presente en el tracto gastrointestinal la eliminación seguirá la semivida plasmática de la mesalazina oral o intravenosa sin recubrimiento, que es aproximadamente 40 minutos y 70 minutos para la acetilmesalazina</span></p><p><span> </span></p><p><strong><span>Características en los pacientes:</span></strong></p><p><span>La absorción sistémica tras la administración de Pentasa suspensión rectal se reduce significativamente en pacientes con colitis ulcerosa activa comparada con la que se produce en los pacientes en remisión.</span></p><p><span>En pacientes con disfunción hepática y renal, el descenso resultante en la velocidad de eliminación y el aumento de la concentración sistémica de la mesalazina conlleva a un aumento del riesgo de reacciones adversas nefrotóxicas</span></p></div>"
                },
                "section" : [{
                  "id" : "6929fa18-ac7f-4cd9-b4aa-51d768a01e5b",
                  "title" : "5.2.4. Eliminación",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029831",
                      "display" : "Eliminación"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>-</span></p></div>"
                  }
                }]
              },
              {
                "id" : "8f5ea1e2-6411-43fe-8f22-10b2d1640856",
                "title" : "5.3. Datos preclínicos sobre seguridad",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029834",
                    "display" : "Datos preclínicos sobre seguridad"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Se han demostrado efectos renales tóxicos en todas las especies en las que se ha analizado. Las dosis en ratas y monos y las concentraciones plasmáticas al nivel sin efecto adverso observable (NOAELs) excedieron a aquellas utilizadas en humanos por un factor de 2-7.2.</span></p><p><em><span> </span></em></p><p><span>Los sistemas de ensayo</span><span>in vitro</span><span>y los estudios</span><span>in vivo</span><span>no mostraron evidencia de efectos mutagénicos o clastogénicos. Los estudios acerca del potencial cancerígeno realizados en ratas y ratones no mostraron evidencia de un incremento en la incidencia de tumores relacionado con la sustancia.</span></p></div>"
                }
              }]
            },
            {
              "id" : "868e08c6-4a10-4d60-8a9c-68194ecbb9c5",
              "title" : "6. Datos farmacéuticos",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029836",
                  "display" : "Datos farmacéuticos"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "4c2651b2-f837-4a7a-9f87-305547113e7c",
                "title" : "6.1. Lista de excipientes",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029837",
                    "display" : "Lista de excipientes"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Edetato disódico, metabisulfito sódico (E-223), acetato sódico, ácido clorhídrico para ajuste del pH y agua purificada.</span></p></div>"
                }
              },
              {
                "id" : "f06a1084-e1a4-4717-ac9d-9c120d2e597c",
                "title" : "6.2. Incompatibilidades",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029838",
                    "display" : "Incompatibilidades"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No se conocen.</span></p></div>"
                }
              },
              {
                "id" : "cd091cb4-790c-4e0f-99ac-9400de97f085",
                "title" : "6.3. Periodo de validez",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029839",
                    "display" : "Periodo de validez"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>3 años.</span></p></div>"
                }
              },
              {
                "id" : "c449622d-f4f3-44b1-b2a6-7744f59924c4",
                "title" : "6.4. Precauciones especiales de conservación",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029840",
                    "display" : "Precauciones especiales de conservación"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No conservar a temperatura superior a </span><span>25ºC</span><span>. No refrigerar o congelar. Conservar en el envase original para protegerlo de la luz.</span></p></div>"
                }
              },
              {
                "id" : "094daf3e-7d42-4342-8b6e-6ae8d8a1880c",
                "title" : "6.5. Naturaleza y contenido del envase",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029841",
                    "display" : "Naturaleza y contenido del envase"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Envase de polietileno</span><span>con un aplicador rectal,</span><span>envuelto en una bolsa de aluminio.</span></p><p><em><span> </span></em></p><p><span>Cada caja contiene 7 envases de suspensión rectal de100 mililitros</span><span>.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "cf8bbb0b-debe-46a3-95e4-57079ba7ba08",
                "title" : "6.6. Precauciones especiales de eliminación y otras manipulaciones",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029842",
                    "display" : "Precauciones especiales de eliminación y otras manipulaciones"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>La eliminación del medicamento no utilizado y de todos los materiales que hayan estado en contacto con él, se realizará de acuerdo con la normativa local.</span></p><p><em><span> </span></em></p><p><span>Los envases de suspensión rectal están protegidos por una doble capa de aluminio y deben de ser utilizados inmediatamente después de su apertura.</span></p><p><span>             </span></p><p><span>Se adjunta a cada envase unas instrucciones de uso detalladas.</span></p><p><em><span> </span></em></p><p><strong><span>             </span></strong><strong><span><span>INSTRUCCIONES DE USO</span></span></strong></p><p><em><span> </span></em></p><p><span>1.</span><span>Agitar el envase de plástico antes de ser utilizado.</span></p><p><em><span> </span></em></p><p><span>2.</span><span>Girar 360 º la pequeña parte superior del envase de una sola vez como se indica.</span></p><p><span>             </span></p><p><span>3.</span><span>Cubrirse la mano con la bolsa de plástico que se adjunta y agarrar el frasco.</span></p><p><em><span> </span></em></p><p><span>4.</span><span>Adoptar una posición adecuada para la administración de la suspensión rectal, por ejemplo, sobre el costado izquierdo.</span></p><p><em><span> </span></em></p><p><span>5.</span><span>Insertar cuidadosamente</span><span>el extremo</span><span>del aplicador en el recto</span><span>.</span><span>Mantener una presión suficiente y constante mientras se dispersa el contenido de</span><span>l envase</span><span>.</span></p><p><em><span> </span></em></p><p><span>6.</span><span>Extraer el aplicador con el frasco aún presionado.</span></p><p><em><span> </span></em></p><p><span>7.</span><span>Permanecer en la misma posición durante 5-10 minutos ó hasta que haya desaparecido la urgencia de defecar.</span></p><p><span>8.</span><span>Antes de desechar el envase vacío envolverlo con la bolsa de plástico.</span></p><p><span> </span></p></div>"
                }
              }]
            },
            {
              "id" : "c0489556-576f-4634-8d10-c21f4cad7568",
              "title" : "7. Titular de la autorización de comercialización",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029844",
                  "display" : "Titular de la autorización de comercialización"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>FERRING S.A.U.</span></p><p><span>C/ del Arquitecto Sánchez Arcas nº 3, 1º</span></p><p><span>28040 Madrid</span></p><p><span>España</span></p></div>"
              }
            },
            {
              "id" : "ae666706-c4d5-4478-9cfa-32848aa8c17e",
              "title" : "8. Número(s) de autorización de comercialización",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029845",
                  "display" : "Número(s) de autorización de comercialización"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Nº R</span><span>egistro</span><span>: 60.853</span></p></div>"
              }
            },
            {
              "id" : "7bfee185-74ae-4ee6-b4ca-18dcd52935b9",
              "title" : "9. Fecha de la primera autorización/ renovación de la autorización",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029846",
                  "display" : "Fecha de la primera autorización/ renovación de la autorización"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>Fecha de la primera autorización:</span><span>enero 1996</span></p><p><span>Fecha de la última renovación: julio 2010.</span></p></div>"
              }
            },
            {
              "id" : "ab0eb29f-8dcb-467b-9335-9ed1add05295",
              "title" : "10. Fecha de la revisión del texto",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029847",
                  "display" : "Fecha de la revisión del texto"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Mayo 2023</span></p><p><span> </span></p><p><span> </span></p><p><span>La información detallada y actualizada de este medicamento está disponible en la página Web de la Agencia Española de Medicamentos y Productos Sanitarios (AEMPS) http://www.aemps.gob.es/</span></p></div>"
              }
            }]
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "96430e56-4591-4bec-8292-57e6c0c08eaf",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "96430e56-4591-4bec-8292-57e6c0c08eaf",
      "identifier" : {
        "system" : "http://ema.europa.eu/fhir/epiDocument",
        "value" : "96430e56-4591-4bec-8292-57e6c0c08eaf"
      },
      "type" : "document",
      "timestamp" : "2024-12-13T18:58:38.0353768+01:00",
      "entry" : [{
        "fullUrl" : "96430e56-4591-4bec-8292-57e6c0c08eaf",
        "resource" : {
          "resourceType" : "Composition",
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">electronic Product Information (ePI) document</div>"
          },
          "status" : "final",
          "type" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/100000155531",
              "code" : "100000155538",
              "display" : "Prospecto"
            }]
          },
          "subject" : [{
            "reference" : "subjectReference"
          }],
          "date" : "2024-12-13",
          "author" : [{
            "reference" : "systemUser"
          }],
          "title" : "Prospecto",
          "section" : [{
            "title" : "Prospecto",
            "code" : {
              "coding" : [{
                "system" : "http://spor.ema.europa.eu/v1/lists/100000155531",
                "code" : "200000029894",
                "display" : "Prospecto"
              }]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Prospecto: información para el</span></strong><strong><span>usuario</span></strong></p><p><span> </span></p><p><strong><span>PENTASA</span></strong><strong><span>1 gramo</span></strong><strong><span>s</span></strong><strong><span>uspensión</span></strong><strong><span>r</span></strong><strong><span>ectal</span></strong></p><p><span>Mesalazina</span></p><p><strong><span>Lea todo el prospecto detenidamente antes de empezar a usar</span></strong><strong><span>este medicamento, porque contiene información importante para usted.</span></strong></p><ul><li><span>Conserve este prospecto, ya que puede tener que volver a leerlo.</span><span>Si tiene alguna duda, consulte a su</span><span>médico</span><span>o</span><span>farmacéutico.</span></li><li><span>Este medicamento se le ha recetado solamente a usted,</span><span>y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.</span></li><li><span>Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto.</span></li></ul><p><strong><span>Contenido del prospecto</span></strong></p><p><span>1.   Qué es</span><span>PENTASA suspensión rectal</span><span>y para qué se utiliza</span></p><p><span>2.   Qué necesita saber antes de empezar a</span><span>usar</span><span>PENTASA suspensión rectal</span></p><p><span>3.   Cómo usar</span><span>PENTASA suspensión rectal</span></p><p><span>4.   Posibles efectos adversos</span></p><p><span>5.   Conservación de</span><span>PENTASA suspensión rectal</span></p><p><span>6.   Contenido del envase e información adicional</span></p></div>"
            },
            "section" : [{
              "id" : "9c42a6d4-7801-40de-8c05-d17ddabd054c",
              "title" : "1. Qué es Pentasa suspensión rectal y para qué se utiliza",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029895",
                  "display" : "Qué es \"X\" y para qué se utiliza"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>PENTASA suspensión rectal</span><strong><span>,</span></strong><span>está indicado para el tratamiento de la colitis ulcerosa localizada en recto y colon sigmoideo.</span></p><p><span> </span></p><p><span>La colitis ulcerosa es una enfermedad inflamatoria intestinal en la que el revestimiento del intestino está inflamado y desarrolla muchas roturas diminutas en su superficie (úlceras) que pueden sangrar.</span></p><p><span> </span></p><p><span>Pentasa contiene el principio activo mesalazina,</span><span>pertenece al grupo de</span><span>medicamentos llamados</span><span>antiinflamatorios intestinales</span><span>que ayudan a reducir la inflamación y los síntomas dolorosos</span><span>.</span></p></div>"
              }
            },
            {
              "id" : "22d58499-7ad4-422b-8d42-06927b0e8b98",
              "title" : "2. Qué necesita saber antes de empezar a <tomar><usar> Qué necesita saber antes de empezar a usar Pentasa suspensión rectal",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029896",
                  "display" : "Qué necesita saber antes de empezar a <tomar><usar> \"X\""
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "8588350c-8afa-47de-9b0f-2d1fc304ae1f",
                "title" : "No use PENTASA suspensión rectal:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029897",
                    "display" : "No use PENTASA suspensión rectal:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ul><li><span>si es alérgico al principio activo o a cualquiera de los demás componentes de</span><span>este medicamento (incluidos en la sección 6)</span></li><li><span>si es alérgico a salicilatos por ejemplo aspirina</span></li><li><span>si tiene problemas graves de riñón y/o hígado</span></li></ul><p><strong><span> </span></strong></p></div>"
                }
              },
              {
                "id" : "198294a4-2224-4acc-ac64-7b24b3ade054",
                "title" : "Advertencias y precauciones",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029898",
                    "display" : "Advertencias y precauciones"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Consulte a su médico o farmacéutico</span><span>antes de empezar a usar Pentasa suspensión rectal:</span></p><p><span> </span></p><ul><li><span>si usted es alérgico a la sulfasalazina, (riesgo de alergias a salicilatos)</span></li><li><span>  </span><span>si tiene actualmente o ha tenido deterioro de la función de hígado o de riñón</span></li><li><span>si tiene una enfermedad que pueda hacerle propenso a sufrir hemorragias</span></li><li><span>si esta con un tratamient</span><strong><span>o</span></strong><span>que pueda afectar a la función renal, por ejemplo fármacos antiinflamatorios no esteroideos (AINES), como la aspirina</span></li><li><span>si tiene problemas respiratorios, en particular asma</span></li><li><span>se deberá interrumpir el tratamiento inmediatamente en caso de síntomas agudos de intolerancia, por ejemplo calambres, dolor abdominal, fiebre, dolor de cabeza intenso y erupción.</span></li><li><span>Pueden producirse cálculos renales con el uso de mesalazina. Los síntomas incluyen dolor en los lados del abdomen y presencia de sangre en la orina. Asegúrese de beber una cantidad suficiente de líquido durante el tratamiento con mesalazina.</span></li><li><span>Si ha sufrido alguna vez un exantema cutáneo intenso o descamación de la piel, ampollas o llagas en la boca después de utilizar mesalazina</span></li></ul><p><span>Mesalazina puede producir una decoloración de la orina de color rojo-marrón tras el contacto con lejía de hipoclorito de sodio en el agua del inodoro. Se trata de una reacción química entre mesalazina y la lejía y es inofensiva.</span></p><p><strong><span>Tenga especial cuidado con la mesalazina:</span></strong></p><p><span>Se han observado erupciones cutáneas graves, como reacción al medicamento con eosinofilia y síntomas sistémicos (DRESS), síndrome de Stevens-Johnson (SSJ) y necrólisis epidérmica tóxica (NET), con el tratamiento a base de mesalazina. Deje de tomar mesalazina y solicite atención médica inmediatamente si observa alguno de los síntomas relacionados con estas reacciones cutáneas graves descritos en la sección 4.</span></p><p><strong><span>Mientras esté en tratamiento con este medicamento, su médico le realizará análisis de sangre y orina para controlar su función renal, especialmente al inicio del tratamiento.</span></strong></p><p><em><span> </span></em></p></div>"
                }
              },
              {
                "id" : "b574bd6f-d381-44a7-9cf3-ea1addaa00de",
                "title" : "Uso en niños:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Uso en niños:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Existe documentación limitada sobre el efecto en niños (6-18 años).</span></p><p><span> </span></p><p><strong><span>Uso en ancianos</span></strong><span>:</span></p><p><span>Se debe utilizar con cuidado en ancianos y solamente en pacientes con la función renal normal.</span></p><p><span> </span></p><p><strong><span>Uso de Pentasa</span></strong><strong><span>con</span></strong><strong><span>otros medicamentos:</span></strong></p><p><span>Informe a su médico o farmacéutico si está utilizando o ha utilizado recientemente</span><span>o podría tener que utilizar cualquier</span><span>otro medicamento.</span></p><p><em><span> </span></em></p><p><span>Esto es especialmente importante si usted está tomando cualquiera de los siguientes medicamentos:</span></p><ul><li><span>azatioprina</span><span>(usado tras trasplantes o para tratar enfermedades autoinmunes)</span></li></ul><ul><li><span>6-mercaptopurina</span><span>o tioguanina (quimioterápico, usado para tratar la leucemia)</span></li><li><span>ciertos fármacos que inhiban la coagulación de la sangre (medicamentos para la trombosis o para fluidificar su sangre)</span></li></ul><h1><strong><span>Pentasa</span></strong><strong><span>1 gramo</span></strong><strong><span>suspensión rectal con alimentos y bebidas</span></strong></h1><p><span>No procede.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "f689a7eb-1b96-4e7f-9fa5-31bad851549c",
                "title" : "Embarazo,lactanciay fertilidad",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Embarazo,lactanciay fertilidad"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Si está embarazada o en periodo de lactancia, o cree que podría estar embarazada o tiene intención de quedarse embarazada, consulte</span><span>a su médico</span><span>o</span><span>farmacéutico antes de utilizar</span><span>este</span><span>medicamento</span><span>.</span></p><p><span> </span></p><p><span>Existe una experiencia limitada con el uso de mesalazina</span><span>durante el embarazo y la lactancia.</span></p><p><span>Se han observado alteraciones sanguíneas en recién nacidos de madres tratadas con este medicamento.</span></p><p><span>Los recién nacidos pueden desarrollar reacciones alérgicas tras la lactancia, por ejemplo, diarrea.</span><span>En caso de que el recién nacido presente diarrea, se deberá interrumpir la lactancia.</span></p><p><span> </span></p><p><span><span>Fertilidad:</span></span></p><p><span>Los datos de mesalazina en animales muestran que no tiene efecto sobre la fertilidad masculina o femenina</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "1b218b20-bd29-4429-8aae-60d78b8f1a11",
                "title" : "Conducción y uso de máquinas:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Conducción y uso de máquinas:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>El tratamiento con Pentasa suspensión rectal no parece ejercer ninguna influencia en la capacidad de conducir y/o utilizar máquinas.</span></p></div>"
                }
              }]
            },
            {
              "id" : "c0ba5a8e-9637-49bf-9207-a9ffea4370bc",
              "title" : "3. Cómo usar Pentasa 1 gramo suspensión rectal",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029905",
                  "display" : "Cómo \"<tomar><usar> X\""
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Siga</span><span>exactamente las</span><span>instrucciones</span><span>de administración de</span><span>este medicamento</span><span>indicadas por</span><span>su médico</span><span>.</span><span>En caso de duda, consulte de nuevo a su médico o farmacéutico</span><span>.</span><span>Recuerde usar su medicamento.</span></p><p><span> </span></p><p><span>Los envases de suspensión rectal están protegidos por una</span><span>bolsa</span><span>de aluminio y deben de ser utilizados inmediatamente después de su apertura.</span></p><p><span>Se recomienda evacuar antes de la administración de la suspensión rectal.</span></p><p><strong><span> </span></strong></p><p><span> </span></p><p><strong><span><span>Instrucciones de uso</span></span></strong></p><p><span> </span></p><table cellpadding=\"0\" cellspacing=\"0\"><tr><td><p><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCAC4AHUDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3n4l/GDRPAEltpcdnPrviK7P+j6TZnLt6FyAdo7dCT6YBI5uL4v8AxWKKy/s/6mdw3f8AIU4x2/5Y/wCFM8B6JZ6l+0/8TNavt895o62drZNI24QJLES20H7p+TAIxgO4/iNe6xRCMfhgZOcUAeIf8Lf+LP8A0b7qX/g0/wDtFH/C3vizj/k33Uv/AAa//aK9zooA8M/4W98Wf+jfdS/8Gv8A9oo/4W98Wf8Ao33Uv/Br/wDaK9zooA8M/wCFv/Fn/o33Uv8Awa//AGij/hb3xZx/yb7qX/g1/wDtFe50UAeGf8Le+LP/AEb7qX/g1/8AtFH/AAt/4s/9G+6l/wCDX/7RXudFAHhn/C3/AIs/9G+6l/4Nf/tFH/C3vizj/k33Uv8Awa//AGivc6KAPDP+Fv8AxY7/ALPup49tU/8AtFVY/wBoK90rVY4PiP8ADnV/B1lIo23283UYYk4VtqLjO3jG4knkAV726h1KnoRiuW8e+GbbxX4A1vw/eMBHeWrqrMWxHIBujfAI+64Vsd8YPFAHRWM8N1ZxXVu6yQzosiOvRlIyD+RFFeZ/s838+o/AHwzNcFSYo5bddox8kczouR64UZooAzvhr/ycH8Y/+u2mf+iZK9mrxn4a/wDJwfxj/wCu2mf+iZK9moAKKKKACikZgo5OKb5i/wB4YoAfRSKQRkHNLQAUUUUAFFFFABVS/AawuM/88m/kat1VvcfYbg9/Jb+RoA8r/Zr/AOTevDp/27r/ANKZKKP2a/8Ak3nw7/v3X/pTJRQBX+Gv/Jwfxj/67aZ/6Jkr2avGfhr/AMnB/GP/AK7aZ/6Jkr2agAooooAqahcwWWnz3tzKY4YI2kkYZO1QMk4HJ4HavEPAf7Q+h+MfFNtoN9o0+gvfqRYTzzeZHdOHKlAdoKN1x1GRjg4B9zuoYri3eCeNJYpAUdHGVYEYII7iviT4ufDB/h74mW40tru38IX9wslrcxygnSrvkDLEblTB45GQBksY1NAH29D9w8YGSf161JXi3wb+J2pa8l54M8ZiCDxdpAUFVcA30JUFZ1A+Uggg5T5SCGAAIFezq3AoAdRRRQAUUUUAFVb3/jwuP+uLfyNWqq3v/Hhcf9cW/kaAPK/2a/8Ak3nw7/v3X/pTJRR+zX/ybz4d/wB+6/8ASmSigCv8Nf8Ak4P4x/8AXbTP/RMlezV4z8Nf+Tg/jH/120z/ANEyV7NQAUUUUAIRlSDWF4n8PaP4k8N3nh/W7f7Tp98vlyxlsHqCCD1DBgCD2Iz2repGVW+8M/WgD4M1bwZrXg/xdH4NvHlsfElm0l14Z1y2k+W7QAstu28gA5BVe4dipDK6mvqX4T/FXT/iLorRPG9h4gsAE1DTpvvo3Quv+yTnsCDkEDgm38VPhrpvxH8Kz6bNCkepwKZdOvSdptpu3I5KnowOR36gEfNOmy+ObfxBc61pFhFYfEfwbCLfWdOG7zNcs12jzmDZEjYC7iOWyrqeUFAH2zmlrgfh38SvDvxA0Ky1DT9Qt4b6SMmfS3nRri3YMVO5QcgZUkEgZXBrvQyt0OaAFooooAKq3v8Ax4XH/XJv5GrVVb3/AI8Lj/ri38jQB5X+zX/ybz4d/wB+6/8ASmSij9mv/k3nw7/v3X/pTJRQBX+Gv/Jwfxj/AOu2mf8AomSvZq8Z+Gv/ACcH8Y/+u2mf+iZK9moAO1RNKAfunHrSPNtYrjtmuAvte1jxJrV3pPhS+j0/T7B3h1DWpIRLslAwYYFPyM6/xM4KoQFILAgAHbXWqWNihkvrmK1jClmaaQKAAMkkk8Y9ay7Xxx4NvZorez8VaPcTzMEjijvomd2/uhQ2SfavPdH0/S9Skkm8L+Fj4m8lhbnxDr90HW7ZSqyPGWViy/J1RVjJHycDjro/D3jTUI0fVPHUmmt5SjydD0+CJA2DuJa5WctzwMbOByDQB2iMroCvIr5q8daB4p139q+3h8F69beHdWs/D32wXjWyybwZGiZWBUh8hlxuBxt4xX0VpdncafpsVpdanc6pKmc3V0saySZYkZEaInAOBhRwBnJyT8y/FHxTFoPxt8a6va37w3dp4HNsr2rZkt55LqNY845U/vI2+hB5yMgHHfEP4YeMfAuo6H461bxTpt1fPq8UAk02wSyl8xyzFyY1UN9wg57H6ivtG3Ro2dei54Ht/n/PavhKLxH4q174SyxeLdUvL+6sfGFgii8O6SLMUwZST83VenQGvvFWzlj9OKAJKKbvUEZOKcDmgAqre/8AHhcf9cm/katVVvf+PG4/64t/I0AeV/s1/wDJvPh3/fuv/SmSij9mv/k3nw7/AL91/wClMlFAFf4a/wDJwfxj/wCu2mf+iZK9mrxn4a/8nB/GP/rtpn/omSvZqAOU8dXt5Z+FroacTHfXLJaW0i87JJXWIPjcv3d+evauUTQdP1bWLTwNZxp/wivh8xzahCZGka9uHV2SGQhs7QWEz78l28vqN2ek8YKbjXPCFsZG8mTWd0iK+0MI7W4lTPqBJHGfwqp8ObyHVPCV3rlncvcx6pql9crOxOZIxcSRxHDcqBFHEMcYA55oA7SC1gto44reJYoo1CIiDCoo6AAdAOmKmVQgwBgV4b4l+NdxP4jk8I/CrQ18Z68sZleWGcGztlwclpAQG525wyjLY3ZwK8w1TxF+1rpGnT6leWc8dtEpZ/JtLOdgN3ZEDMcd+DgAnPWgD7B384xz7V8O/GfWNPtfil8WtKmsHmv9XtdNhtZoot2zy/s0kisewKx/mgrc+HupeLfizJONS+PE2h61OzINHht9jsqrglEDIp+VSTsBxySB1q/4xtz8Hj/wg/wxnubrxZ4mR7u/1e+uEkuooYwzHHChc7ZDuIJwGwS2CADxrXvF2nXPhPxPplul3Hdal4ij1S2Z4ygESpMvJHRt0ijHr7ivpx/2kvBlnpumaX4fs9U8T6o8MUYhs7dlLSEbduXAJbIHABzkYzXJQfBXUdPVvFXxSjuPGCxTO1xGdWYNawscmXy9vzEdSBLja5AUlRn6R8O+GvDvhu1NroGiWWlxAbdtvCqEjJOCRyevegDxC++IP7RbaRdeJLf4faRpWloIWjtLyOe6uwr7VJKROGIBJYgoCo6g7TXWfCX4yDx4ZtE1y0h0rxHZQpNNAsgKXKNz5sPJJTDIepxuHJHNetuyRkNuVQ3VjXyx8I76z1z9pvW9S0S3eOwsLO+jlLJFGFZ76SRcBQCQVI+9uIwecbQAD6uqre/8eFx/1yb+RqwrK3AYZqve/wDHjcf9cW/kaAPK/wBmv/k3nw7/AL91/wClMlFH7Nf/ACbz4d/37r/0pkooAr/DX/k4L4x/9dtM/wDRMlezV4v8N22ftAfGNj087TP/AETJXr7XGF3FflB5IPQUAEiOZVK4wDnpnmvnv4latqmh23h/4IfDu4eXVNWRoXlnk8x7Kz52rwCQoTK5IJEadz8w9m8QeN/CnhYL/wAJH4h07TXMZkWK4uFWV1zglE+8/Q9AeleQfBm2tfGXxR8cfFS423cf21tL0eYRMsS26fKJIyzHlk2Z4GCW6BitAHqfw98A6N8PfDFno2l2cImjhRbq8SPa91IB8ztkk4JyQuTtBwOla3irWDoegSahFaNfT+ZHDDbI4VpZZHEca5PAy7Lk9hk9q3D9084ryj4ueNz4Ns9Ml1TwrqWo+H/tUE15qVlIo+xukyPECpB3BpEUHO0YPB3ECgDI1T4IWPirR5bzxLfQW3jGeRrmHV9It/s32WRsMEChv3wU7vmY7iGJyDgjwDxj/wAJr4E+K+kan8U7U6rZwW8+mR6nb8fa7ZoHjz15dBLuIO1jyCe9fUlx4/0PxD8LNW8UeEdctnFvZvIXk5No2D/rU3KUIwThiOmelY3jbwH4SX4cX9xqWrapKIYnmNwdQd/tMjMCFKSMyNudgqqRxuG0ghTQB5rffH/RdT8IWejX2rW9ukypBqVxZq81xNEAciGNl2oZAqhmd22b2A3kA10H/Cz/AIweO4lT4b/Dk6Xp06Zi1bW8gMrRbleNTheucN+8U8ZHavNfgp4C8Px/Eu/0rxFHPcS2OozafBMpeMPPCVlUZThW/cyt97kI3XmvpOxtrHR/iba2GlX11sn02Sa6snmeaOIB0WKQ7yxQnMo6gMAeDtzQB51D8B/GHi6SSb4r/Ei+v7eTcf7P0s+VFyVYZJG3AIPyhOMAhq4v4kfBGPwDqY8WfD3VLzRlEMkqRrOx8mSCF7hhn7zI6wHAJOHAzlWGz3nxL8Y/hz4Tea11fxVZG7tw/mW8D+dIrL1QhM7W7ANjJrwbxt8VJPjZqNp8PfhzY3FpeSSTu11eXEUCTReTIjgJgswMcj+hwDweSAD6R8Ba5N4m8BaB4gmj8ma/sorh0B3DLKCecDPOfSujvf8AjwuP+uTfyNYvhDw+vhfwnpHh9JDIun2sdvvLZLbVAyTgeh/DFbN7/wAeNx/1xb+RoA8r/Zr/AOTefDv+/df+lMlFH7Nf/JvPh3/fuv8A0pkooA8vGqfFCz/aE+J1n8NdH0y/a6ksxeT3xIW22wN5ZB3rycv1BHy9K7JfhZ8WfEUjSeMvi7NaWm9Ve20ODyi8YOR+8+Xy2z1+VgcVq/DVFb9oL4x5GR52mdf+uMleyiNB0UUAeO6D+zX8KtGiHn6PNrExQo8uozFy+WB3bV2qDwBkAcfWvVNO0XStHthbaTp1tYQZLeVbQrEmTjJwoAzwK0KKADtXCfFq3muPg/4thtoWnmfS51VEXczEr6Dk13dYnirb/wAIfrO4Aj7DP1OP+WbUAfMHhf4Paf4u+EeheN/hveTaB4iutOFpdQztutb7b+4nWRfmwHZCw6gnBIHUS2/gX9pCPT7LS5JbFrKykWe3W4vvMEMoKkSEkktggkK25VJyBlVx6t+zZLBN+z14djjkjkeBrqOVVYEo32mRsEdjtZTj0IPQ164yrjO3JXkUAfCfxT+Fsvwi8JaRq0Xi+8n1zU5wt4kSbIzKh8wSRPwUKNtAJG47jyuSK6HQfh94o1bR21rx/wCJPEWl6HqaR3F5Dplo+6ZXhEYM8jHIVRsyGVxtDfd616J+094fv77wloeuWeni+sNDvGmvoViZyImAyxUEfKNoB5GAQelcxqP7Svhib4W2Ogx2Mlzqt9amxvUmi2Q2q7SjS4IkEgzyE7g8kUAeweGvgd8L/DscUtr4Yt7ueNmYTXuZznbtPDcY4PGOua8W/aS8I+HdDvrTxhos9nomtKvnCGH929xJHJEoeMBwAwEhJIUnCfU11Fr8Uvij4q0+1074X/Dm5ttNW3WKHV9cbZvTysq4XhMjHBDOp44GcV5To02r+J/j/oOk/HG7mndLiWGC0BSNYbksCkbqoysbHbtx97KEHBbAB9oeH55LzQdMvLk7rqa1iklOMfMyAk4+uav3v/Hhcf8AXJv5Gqxvba3v7azmnVZ51YxoerBQC3btkH8asXvNhcEHI8p/5GgDyv8AZr/5N58O/wC/df8ApTJRR+zX/wAm8+Hf9+6/9KZKKAK/w1/5OD+Mf/XbTP8A0TJXs1eM/DX/AJOD+Mf/AF20z/0TJXs1ABRSE1B9o5I24b0PTFAFiq1xHFMpilRZI5VKMhAIYHqCDXAeIvjf8NPDBKal4otZJQQDHaE3DLnPJ8sHA4/lXUaF4o0HxZpv9peHdYttQtzx5lvIG2HPRhwVPsfrQB5T+zC8MXwt1OJMIF1u5wijGBhB07dK90zgZ59a+X9BtPiR8HvF/i7T9D+GjeKNF1a+N5aS2l6YkijLMVTJRiSAVUjA5HUjFTa/+094i8L3P2LxD8Jjp1xnb5T62pkX5dwyvk5HGDyPzoA9J+PWq6jpPwF8S3+j3ktpdqkESyxMVZVe4jRwCOmVYjPbPavF/Avg7wR4Y8L2mvaHqi3fjIao6WVncW6XZuNkmYkWPAKhoWjk85CNu8Pu2gLTbP40fFH4oQ3+h6L8NLDUNK1EPbS7/O2LGeCrzblXIDDnA+g61U8D/s0+LrvVNTh8YXEvh3QLpMPZadfCR5yGDIrD5lZFOT8xyCFIzjIAPefE3xn+HPhNDBf+JLaa4X5Tb2JN0465BC8A5BGD04zXjmnr4m+Nnxu0fxRa6bqOj+FNKuLXUIbnUrVULrAAyRptJDFpGl+YMRtYd12t7V4V+C/w58INBNpPhm0e8hYOl3eL9olVlbcrKX4Ug4wVAPA9K7S6vLbT7Oe8vbhYLeCNppJXfAjVckknpgAfQUAcrrl5CPHUbPqEUA0zRbq8kG5QI8sgEj55AwrYPA4PXFbmiTzXXgOxuriQyyz6ckkjt1Z2iBJ/WvNLu4vNW8IahqbzFb7x/NFpun2txb4a0sCWXd5Yf5mWFri4Ykjl9pAxXrs64srv5h/qmPueD/8AXoA8x/Zr/wCTefDv+/df+lMlFH7Nf/JvPh3/AH7r/wBKZKKAKHw9uY7f48fGe4kkWONJNNdnZgAoEEhJOe1a/ij4+/DbwtmO615NQulBP2bTB9pZiADjcMKM7gRlgDXmCfDPSfiT8fviZb69qF/Fp+nXNjI1nay7FuHaBwrNweV+bB9Hb1Ne4+F/hr4D8LGOTQ/COn2dzCWK3LQB51LDBxK2WxgkYzjnA4oA8of4ofGnxvcND4D+HA0WyLFUvtbODgPjcQcAEqRlRv74LYp8PwI8S+LRbyfFj4kX+tFXWb+zrA+Vaow3DcMgBmKsfmCKwyw5r6FMantS+WuQcAnpk9aAOD0D4OfDXw1aCDTvCOnSN5fltNdwi4kZSmxhufOAw4KjCnJ4rjtd/Zn+Gl/MbrSre90G7XaYpbC5YCJlYHcobPOBjrx2r2+kKg9qAPDbz9n2LU4hba/8T/Ger6ezKZrO91FpIpQCCAQcj8e1b3h/9nz4U6AUkj8Lw6hMhYh9RY3A5GMbW+Qj0yvB5HavVNo596WgCFbeONFWNQiqAFVRgADtisnVNc0vR5I4b+ZojIpKhYnfPr90H+lblU72Bp7aWFLiW3aRNgkiwGTPcZBGfwoA5K48dPLaF/DvhnWNZuGaRYU+zG2iZlDZLSy7VVSy4zyeRhTmuY1t1uprNfiRqETyyMs8HhPSlkuBIRIQjSEDfPjKZ+VI8qcggZrsJ/B/2wRrf+KPEN1AjbzELz7OHO0gZaBY3IGc43YyB6Ve0Lwr4e8M272+g6NaWAm2+c0cY3zEd5HILSHk/MxJOTzQBjeGdK1rUdWXxT4qZ4Lx4mWz0uOT93p8LEHDkH95KwA3N0H3V4BZuxvBiwucZ/1LfyNWAq5zVe9/48bj/rk38jQB5X+zX/ybz4d/37r/ANKZKKP2a/8Ak3nw7/v3X/pTJRQBX+GgH/DQfxj4H+u0z/0TJXs1eM/DVl/4aD+MYz83naZx/wBsZK9moAKKKKACiijNABRRRQAUUUUAGB6UUUUAFVb3/jwuP+uLfyNWqp37bbK4J6eU38qAPLf2a/8Ak3nw7/v3X/pTJRR+zX/yb14dGc/Pdf8ApTJRQBx3iC88U/CX446x45TRL7XPCHiW3jN6thCsklvNHtRSeByOcAkAhz3HFgftc/DnJVtF8SEjgn7LAP8A2tRRQAv/AA1x8Oe+ieJM8/8ALtB/8fo/4a4+HOP+QJ4lz6fZoP8A4/RRQAf8NcfDjP8AyBfEhH/XtB/8eo/4a4+HH/QE8SY/69oP/j9FFAB/w1x8OO+ieJPb/RoP/j9J/wANcfDnH/IE8SZ9Ps0H/wAfoooAX/hrj4cZ/wCQJ4k9/wDRoP8A4/R/w1x8OP8AoC+JMf8AXtB/8eoooAP+GuPhx30TxJ7f6NB/8fpP+GuPhzj/AJAniTPp9mg/+P0UUAL/AMNcfDj/AKAniTHf/RoOP/I1Yfij4+H4leG7nwb8M/CWsXOq6wpsJJLyGNI4EkUhmDJIwBxnkkBcZ7UUUAe6fDXwmngf4caP4XVo3eyhxK8bMUeRiWdl3c4LFsdPoOlFFFAH/9k=\" alt=\"Description: C:\\Users\\maln\\AppData\\Local\\Microsoft\\Windows\\Temporary Internet Files\\Content.Word\\New leaflet pictures 121113_Page_1_Page_1.jpg\" width=\"118\" height=\"185\"/></p><p><span>1.</span><span>Q</span><span>uitar inmediatamente antes de su empleo la bolsa de aluminio, y agitar el envase de plástico antes de ser utilizado. </span><span> </span></p></td><td><p><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCAC3AHoDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD0z4i/EDxrrnxJHwr+F/kw6nDD9o1DU7ggpbJheB1xjeuTtJO4Ad86qfDP4yFBu+PVwrYycaHCRn/vuj4cKv8Aw0P8YOAcSad1/wCuL17SOlAHjP8AwrP4xf8ARfLn/wAEMP8A8XSf8Kz+Mf8A0Xy5/wDBDD/8XXtFFAHi/wDwrP4x/wDRfLn/AMEMP/xdH/Cs/jF/0Xy5/wDBDD/8XXtFFAHi/wDwrP4x/wDRfLn/AMEUP/xdH/Cs/jH/ANF8uP8AwQw//F17RRQB4v8A8Kz+MeP+S+XP/ghh/wDi6P8AhWfxjz/yXy5/8EUP/wAXXtFFAHi//Cs/jF/0Xy4/8EMP/wAXS/8ACs/jH/0Xy5/8EMP/AMXXs9FAHi//AArL4x4/5L5cf+CGH/4usTXPC/x88Kp/bmkfEq28VpZxyT3Fhe6etuZQAMKgTdvJG7+JcYGM54+g6ayAg4UZPfFAHB/Cvx9/wsXwFYeI2hS1uXZoLqCMkokynDBSQDgjDD0BwSSK72vBv2fNPtdJ1X4l6bYxeVa2fia4toE3EiONSVAycnoBz3r3nmgDxf4b/wDJw/xi/wCumm/+iXr2hf6V4v8ADf8A5OH+MX/XTTf/AES9e0LQAtFFFABRRRQAUUUUAFFFFABRRRQAUUUHpQB4l8DP+Ro+K/OP+Ktu/wAfnavbMV4l8DTjxP8AFf8A7G677f7TV7dQB4t8N/8Ak4f4xf8AXTTf/RL17QK8X+G//Jw/xi/66ab/AOiXr2gUALRRSFgDigBaKaJFPenZoAKKKKACiiigAooooAKD0ooPSgDxH4G/8jP8Vv8Asbrvv/tNXt1eI/A3/kZ/it/2N13/AOhNXt1AHi3w3/5OH+MX/XTTf/RL17QK8X+G/wDycP8AGL/rppv/AKJevaF/pQAteR/tBeJde8K/CLUdS8PNLDePJHbm6j5NsjnBfocZwEzkEF8gggV65Wbq+lWOs6fdabqNtFd2lxE0csEqhlcEehHtQB8faT4v+J/w507w58RNS8SSeOPCGsII7pGuHkFuxOCnz42yLtODjGVKnGQT9gaPrmla9pNpqmkXkd5Z3UYkiljPyspH6emDgggjqDXyZpumQ/CX4hXvwt+IZe/+HHiLItLrUGCW0THB8zd/yzYH5WIK4JD9MGtP4b+IdX+CXxQf4T+LLxrjQL90fS7v7O2FkkbCMp/uschgN2GHUc5APrOiqy3O4kYIx3PFPE394YPpQBNRTFfcCcdOPWmtLtIDdfSgCWiiigAoqKSYRnBGeM15z8Q/jR4P+Hey21C5OoapISE06yKyTDjO5+f3Y6AbsZzxnBwAc58Df+Rn+K3P/M3Xff8A2mr26vnz9m3ULnVm+IOqX9i+nXd54hluJrSX78EjZLRnIHIOR0B4r6C/GgDxj4b/APJxHxi/66ab/wCiXr2cV4v8N/8Ak4f4xf8AXTTf/RL17QvSgBaKKKAPOvit4BtviR4Ju/D8kkUF6h86xuXUnyJgODgHkEcHrw3Q4Gfn7Qrf/haPge/+DXi5Xs/GvhUSnSriR1Al2cCPJAONu0YxyuG7YH2Eyoc/KCfUivkz9p3/AIR/wz4u8N+LNEuPsnjjzxJ+6kB3Qxj5XkTnndhR03AOOccAB4R/aA1TwT4Wm8G+LvDWoXvi/SXSyggBYtdjOFVmJYgjOARu3DbjrXUXnhH9o7xXbRapqHjaw8LM/wAy6dZK6iDIXKsyhi3Tuxwc4ODg8f4is7X4o+ALL4zeBIRYeM9CZJNV8n90rtGgZyFOdxB2lfm5QkNuOBU9x8XvEXxq8P6F8PvClvPpWs6mudfv7ZSYLaAHa5UddjEq2dwIyEy24mgDJ8QfFbx94buvsA+OmjapKrbX/s3SkuVTgH/WeVtbg44YkHrjBFdf4b1P47eKNFTxF4P+JWgeJ7SG7WGWB7EWylgqsyMTEjd1ztI+9weMn2Xwl8LPBXhLw/b6TYaDZzeUjRyXN1Css0+5cOWYjPzZIx0wcYArrNP0nTdKhMGmada2MJYuY7eFY1LHGThR14H5UAeM3GrftQwWk0y+G/BMxiQv5cZnLuQCcKDMBk8AAkc9TTJPip8YtLs7e41n4HXckW5EnfT9QWeTnAJSJFYnueTgcZPevdsZFMMa5+7QB84XPjf4tfF2V9M8A6Jc+CdKt2ZbrVtTBjkkcEr5SZU7SrBt23LcDJTo3ofw6+C/g/wDjUIIX1fXZRun1S+w7s55YoOiAt9W6ZZsZr0sRken1qTAC4AwBQB4l8DVX/hKPisSMkeLbvBH+81e28eleJfA3/kZ/iv/ANjdd9/9pq9u7UAeL/Df/k4j4xf9dNN/9EvXs4rxf4b/APJw/wAYs/8APTTf/RL17QuKAFooooAqzOAZBu2YG4njj39K+A9Ki1v48fHK9aBHig1KdZbmdHZGtbFMjyzjcOVK/eB+YADgnP1V8evF9n4U+FOtR3MP2mfWbeTS7eENtJaSNlLdDwoJP4Ad+PONDex/Z3+ENp9s0t7zxz4jYlLIKWaWUH5Yzhj8qeYmQOWLepyADl/Ed7p37Pfx6guvC12smi6zCv8AaOlGQs1sjP0wOQQPnTvjcOh50vGdndfCXxtpnxh8AiWfwVr3lyX1laLsiEbgFeMYVXDEocDaxIyARXcfD/4H6bceE9Q1L4jW76p4q8RROb6a8CvJab+0eSwVhgHPqAOgxXJfDW7vPAXjHVfgT8QN91oup+Yuk3M6nbMrnARV+YKrjLdfkcEcluAD6T8O+IdJ8ReGdP13SLhZbG9hWaJgwOAR9046EHII7FSO1bStuAI6Gvjyw1nU/wBmf4g3+iapa6hq/gjVQZ7OVdokRgM5UFgu4HCMDjcAHGM7a+kfCHxH8K+M/C76/oupK9nb7vtBm/dtb4GTvB6DAJz0wOvXAB2dFQpKxlKFSRjOakZio6Z+lADqD0qDz/nVdpBPan+YNgbBAPr2oA8V+Bv/ACM/xW/7G677Z/iavbu1eI/Az/kaPiv/ANjdd9P99q9uoA8X+G//ACcR8Yf+umm/+iXr18zsDtXaxzj73SvIPhv/AMnDfGH18zTf/RL1V+JQWw12PX9J1Ii+i1Cxs74pcSC9hjeWMpBaoMRuHBdnRiQQCedo2gHs/wBobcVAyccds/hn604TN8vqRyPx9a8Hl8U3F58brbVtQtUudOsNYfwvYacVY3dtM0Yd77YTjYcMAwwRGcjgkGHwb9p/4TDw1q628f8AwkeqanrEGvvvLS+VE0gjVgWO0Jstwo7B+BhySAL+0BdT6P4k+G/iu/IbQNJ1tJr5QrMykMhSXCj+FUkwM8k4wawYvE3hnUv2pIfFN5cX2oWy6XENKgtrPzjApj3M8q/6xMGViuEOck5AGK9avfAXw51qXxJoc1hYzXOtOtzqUKSqZ1YAlJcD5lYFywY8/MBnbgD478SJ448I/FR7XTLq+1i88EMWtb65gMssVoMFQ2d37pd5GfR2xwAAAfcFn4o02+1JLCys9SlIC7pRYyrFGST/ABsoHVf5H0r5p8f3vhvw5+2RpOteJLqeHS4YYrl3LNIsUnlsI8AZwm8IcDA5J716/wDB/wCNGifE62NjPAmla/bIC9jvBEq4+Z4j3Geq9R7gAniPDui2etftj/Ea21XSodR05tMVJI7qATQ7j9kZQQwIydhIH+wfSgD1m3+KHw3vtFm1FfGWkS2ihhKJLleQB83yt8zDacdOf5fIviVtPtPi/feGPg54itV0fxpFBp8oRD5cJlcI0RYgtjjqBkLJgdAa+sb34H/CnUbt7u48E2HmSEfLCXgjUAAcIjBRwOwGTk9ya+ZPjNa2Phn9o7Qrb4e6BZ/a9HhtJxpun2oUG4SRpwGRBkkpsYnrg0Adb4Z8Z/EH9n/U9O8JfEq0+2+EpnKWuoWxaX7OvT92eMrkZMbAMAcr/drv/EX7RuiyywaN8OdJu/GOv3K/uYoEZIoyQMFzjJwTyAOzZK9a5bS/g58QvibJb6/8Y/ElzFZj97Fodv8AJsyx3BgPkj4PUb3IYZI2ha968J+CfC3gvTzp3hvRbbT0YL5zJHmSYqSVLueXxk4yeM8Y6UAeOWPgv47+OzHeeLvHw8IaZMAws9HUrPjfuALIw2fL33t2BU9+ls/gzfabq9jqFv8AFjxrNJb3KTNDeah50UihssrLwORke2e9ey7VOTtBzwfpTQsYOR9KAPFfgb/yNPxWJwf+Ktu+v++1e314j8DT/wAVR8Vsf9Dbd9PTe1e3UAeLfDf/AJOH+MXb95pv/ol69Tl0TTLnWbXWLjTbSbULVStvdvArTQg5BCueVBBIODzmvLPhv/ycP8Yv+umm/wDol69oHT8KAPNvif4j0n4b+Gbv4gf8I7b32rp5dlHKItsrBmA2tKEYqgGWwcAkAdSK8N8N/EL4h+MdZvPEOgt8OvC1zPbxi5ub2aMT3HGArMpaTIAA2sABtr6y1CwtNTsJrC+tYrq1nXZLDMgdJFPVSDwQRxXnur/A34U6veLdXngfT0kVNiiz32iYGeqwsqk8nnGSMDOAKAPmbw38NfiTefGqDUtI1gxl7zztR1/Rv3dpGS+6RIjgCQbdvDKAzMQRtG4+6/EH4aeJbjx6nxM+HWrWtp4mt7UwS2l6m6K9XaQAG/hbbhccLwvK8kxy/sw/C+W6lkhj1e2ikct5MF6dgPHA3Ant3JPbNUf+GadCstXTUPDPjfxJoUqx7d9vc5kOSckNgEDkcUAfNPxB03xJ4f8AE8etR+A73wLfQO7yS2EsnkB9+FeJv+WecsOHIOBjaOD7P+yfdX+q634/1rU2ea5v5Laaefy8CSVmmZzwAM5bOO2RwKi+J2hW3wx0ywm1v4x/ES/m1BpFtbWC+Y7/ACwCzMXcKqgsgPU/Nwpwcc3+z/8ADzUPGPhLWLy08f8AiHwwtveCIwaZdNEsh8sNubBGW6cn0oA9n1jxs8vxV8ZeH4/Fl5pcGg6FHfCGCNFVJBlpGZnjbICyQdx1OB1xxf7PUeoTaPJqWl3Vve69rfnX+ranfwGb7OPNdIoSQ6sXcrLIe2MZHIJyvCHhnzP2kfiL4RvNWm8TM3hl7F7q6I8y5Pl2q7XYdWH3SSc/L8xzVf8AZr8e+GPCsGq+D/EF1b6VfyXAlE0yr/pMm4oY94+9j5AqnJyXwcHFAH0Bf+JPGPhvTV1TxJ4c02TS4Oby70q+lklgj/im8loVyo4LASFgNxG7FbPiTS9av9Ohm8Paktjqtm/mwpNuNvcnBBhnABOxs9RkrwwBxg8h8QviJ4RuvBmpeHbPxBpv9r6xCNPt7e4uBFj7Qwg808N8ibyxODwhq7qvxq+FukwSSXXjOweSNzGyWrGeRW6YCpk/U9B3oA67wrr1t4g8M2mrxRtbtMuZbeQ5e3kHEkbe6sGU5A5FePeNvi9q+ueJF8C/B6EarqzT+Re6m0Za2sMEjg42k8Md3QbcAMeF84h8bav8YvGt18PvBmsHw74dubu4vbzUTL5U91EzAbFXIOGB+5jLA/MMAgfSfgTwBofw/wDDNtoehQ/u1PmTTv8A6y4kxjc34cADgDAxQB5j+zbY3umP8Q9P1DUJdRvLPxDLbz3UpYtcSLlXkOSTkkE5JJ5r6CrxH4GDHif4rYz/AMjZdDjt8zV7d2oA8W+G/wDycP8AGL/rppv/AKJevaBwK8X+G/8AycP8Yv8Arppv/ol69klYJCzFtoUZJPYUAMurhLaAzSSLFGg3M7nCqByST24B68V4p4h+OwvdXk8N/C/w/deMtaRhHJPCpjtLdi+07nbAOOCW+5gg7iNwHJa5rXiL9oPxTP4S8Mzz6V4A02YDUtS2lTfOv8CjjI7hT/vNghRXvfhPwj4f8I6FHpPh3S4bC1XBIiQK0rBQu5yMF2wOS2TxQB8peJvjL+0J4B1hn8W6TZWS3e0QpLaq0C7VBIikR8NnOSGc+nHQdZompftRePLKz1HTLzRfDNg8P2iG5dIityG24UqwmcHuMqvfnoK+iNd8O6P4j0S40XXLGO+sJ0aOWGUZBBHOD1B7hhgjqCK+e7/RvH3wBu/7T8LX0nibwLJJHFJpN3IXuLbJYsYxjHc8r13DK/KGABqab8A/EWseNIfFfxL8dy69PFEcQ28flrDJjAMZPyooJLDai/MAeork9R8K/FX4A6DqOr+F/Gek3fhWGbzRYaggEkzv8oAVhksBg4WRdxBOCevXj9qzwHKGitdB1+4uiD5UQtYvnb0/1h6n2/CvJvEviq6+NnxV0rTdS0q/0jSLbT7qaCwkZy0jxwSy7iOAdxQLkAccc0AYXgvxh460HWfE3iq00DTxqHipX239/cJaJA0rs58p5XXO5mU7d2TtB5xmvRW/Z88beNpdMvtZ8QeGNNitbWOGCbRYnmeXYMbpZDgu42KNxZumPUn6N8I+G/Cdp4S01dE0fTRYPbxPE8MKuJV8tQHLEEuSAPmJJPrWda2dj4d+Kq2ulQwWltrGnvNNawhEUSxzAmXYFGS3nMC2eSBQB5xpX7KfgeG5WfXtX1bWdjoyRvL5SlQSSjbckhs4OCD155r0vQPhB8M/DcQXSvBemBkm89JrqL7VKj8YKyTbnGNoIAIAOT1JNd0GX+8Ka7jj5sD19KAPmv42fCi6utbh8R6C3lzySO8DWFtHb3VrchA0W1ogrTK7RlSXLMhKFeN2fUfg742uvHvww0rXb/LXvNtcSFVUSyJw0gC8AHg4wACSBx15r46fECz8J+FbQ2N9DNrb3q/ZYEkBlEiq2GCbSDtJUkMADwOScVtfA7whe+C/hJpGl6krR30o+2Swsu0xNIN3lnIByoIBB6HI7ZIBh/A3H/CT/FbOP+Ruu+v+81e3dq8R+Buf+Eo+K+M/8jbd9P8AfavbqAPFfhuf+MiPjCD3k03/ANEvVT4+eJ9bj07R/h34ZaJNW8WzfZGZnUtFBwGwuRt3E43dAFbHOCOOj1f4j6f8e/ilH8OvDNlrU9xPp4uJr+cRxWgERwxTejOCC/3TxjvnFdt4O+Hvjy++Mw+I3xKXRfPstPNrYwaVJNtSRiQZMOT/AAM4xkj5hwMUAej+CPCOm+CfCNh4b0mJktbRD8ztuaR2bc7k+pYk+g6DAGB025VO0tzTgAOlQzbR1/WgDM8QarbaD4d1TXrosbXTrWW8l8vltsabjjPfA47VzPhzwiz3MHinxhapeeJpts/7zDppeFwsMIyQoXcwLLyxJJONoHAeO/ipZW/irWfhX4302Tw5p+uWMttZa0ZkkTy5leLznUcIN4bgngfeABzXqXirxRFo/gDU/EWmPb3bR2hks5GdWgkduIyzbgPL3FSzbgAuTkUAeU/ET4R2sfiP/hNvhxrFr4X8Y2aNItuohWK6cnOcONqsQzjJGCSM9yfMPEPi7V/HHiPSbiSGLw78WPDMxjt7M7pLfVFHLLG2SgOQ+0E4cSbVY8EfTmi+CNG0my3X0Uet6hMxlutRvoUeW5kJHzHjCjoAo4AAA714v8ePh3olrb6fq3hPzNK157ia5W3sVTLiC3nmaVEA3IS4jDMhC/MuRnbQBjeEPj7Z6Do0+jXiwaD+/knhttRhnc2gdXd4Y0hiw0Ylzs3MuFYL/CKtaL8crUX93e+HfCviLxl4n1eN/wDSWt1iRAgJSCCKMuREoDEgfMTuLEk8ctZ2v/C9dfl8ZeIpp7ew0kaNpqrakRB5pZ4VuM7izYBeTacDjYSeDn6gh+GPgm10p9Pg0KKOBi53maUy5cli3mlt4OWJBDAjsRigDyl9d/aU8VwRRaP4S0rwdbXFuGW7v5lllRs5+4SxUkcbWi4+boSMOb4LfFHxK9xJ4y+MeoeTcRKHt7CMxRFht48tSi44POAT1NemeBdRk/tjxL4SvNSk1O58P3iRxz3AJmNtNAk0XmN0dgWkTd1IjBPOSe8JC4GDzQB8xeIv2WdDt9CkvNF1bWr/AMQIFffPeRoJ2AGcHYNrHnblsA4BPcXfg/4113SfG8Xw18RXl/qljeW5uNDu7q08iaGOPeJIZw2DuUoU/iwykAkEY+h5cOd3zBc9hzn1r5YhEviD9qnQ9L02zitH0W9v9QvJIYmyiGVgEkb+620OOAN055O4ZAPRPgb/AMjR8Vun/I23fX/favbu1eI/A3/kafivjP8AyNt30/3mr27tQB4r8OFDftDfGIEceZpvb/pi9e0qOK8U+HUij9on4vpnBaTTuM8kCF84/MfnXtYoAWmOgZgTT6KAPnrxh4c0fxL+1vpuh69ZR31hdeEWWSKQY/5bzcgjkEdiORXmUtz4i+EvxB8TfD7Q7O/8Y+C1slk1DT7jLSxWsiKsjIyYKY34LABcZyOAR7HqhC/tpaIWOB/wib8/9t5qydMv1s/23PEFm0Tu99o0cSMvRcJE5J/BMfjQA3wP+0B4I/s2DS/EPiSQLGJVttQvBmWdEbIWdVUFJRGU5xtY7gDu+Ucd4z+Jtl4ottRh8PTtqfiXxPEmlaXZwR+YNMsZGUs8jxk4kkJBI3EriPcBgg+2698Dfhf4kuxdaj4Tt0mBJY2kjW+/OPvCMqD079OfU1ueFPhz4N8DxFfC/h+3sJGTZJMMvK65zguxLHn3oA+YtV8M3XwSubjT9a08XXgzxNZWttc3tqS/2K+ijU+cA4IyZQ0oXHIA2/c2n0y0/aR8OXHg1b6Nrf7ZDCI53vbqOJfPwoykSkzSJubOVjwArdNpxp/tB69qlp4X0nwb4fSE6n4rvU09POiDgJxkqSQA+4x4JzxuxggMOK+Hv7PejyeHNM1PWLizjF1brLuggWeaZmVWBZ7gNGozuwqRAhduXYgkgBpHx/8AAfhWzvX09dX8V69f3Pn6hfxWoiF3JtCgqGI2IqqqohAwqjPzFieim+JPxy8SFW8JfCIaVbC68k3GvuyMF45MJMb45B3DcDggc5x23h+O58G+KbXw7dS6XcWOseZ9lvY7WOzuXlj3N5Uix4SU+X0ZFQ/I2V716MiLsHGe/PJoA+K/iTrHxw0LXtOtfH3iu5stOv1mkceH4SUhgJG/7qpv2jHDOSo6kbhu+hPhD4D8FeF/C8Oq+Fbw61JqyrPNrE2Gkusjkf7Cg5+TqDwckGtX4n6Jp+r+Elh1BN0Md3BwCAcPIInHPYxyODjBGcgjtxv7LzvJ8DLIzOZNt5Oq5YkAbuAM/XpQA/4G4Hij4rdP+Ruu+v8AvNXt1eDfs+6ha6nq/wATdSsJfOs7zxNcXEMoG0PGzFlbkZ5Br3jn0oA8N8cfDTxlZfFD/hZ3wwv7KLVriAW9/YXwxFdDKjOR2wASCQfkGCM1yn/Czf2lun/CA+Gvwf8A+6qKKAD/AIWZ+0v/ANCD4b/77H/yVR/ws39pjt4B8Nfi4/8AkqiigDlbrUv2gLn4n2nxDbwToq6rbaf/AGYsIlTyDFvd8kfad27Lno2PY1SC/HdPi03xN/4QvSTrLQeQYvPj8jGwJ93z92cD+91oooA7b/hZ37TAP/Ig+GMf73/3VS/8LO/aYx/yIPhn8H/+6qKKAOR8W337QHjDWPD2qah4N0m0udAuvtlq1pNGoL/KfmDztn7vTjr1ra0Txj+0doGjwaTZeB9BktoNwj8+beyIWLBAftQ4UEKM5OAM5oooAbf+L/2j9S1PSNQm8GaJG2mTtcJFHMoSZjG0fzg3JOAHYjBHNao+Jv7TCjH/AAgPhj/vr/7qoooA5Px7qX7QPxE8MN4e1vwZpFtZySpK5sZY0d9pyBl7hsDOOgzwPpWh4Vtf2gpPBUXw50Lw/ofhywjg2nUVn/0jBbDtuWV/nbJJIUewHFFFAH0D8OfA9j8O/Cdn4Z0+eW5VCZLi4lPM0xALtj+EccDnAAySck91zRRQB//Z\" alt=\"Description: C:\\Users\\maln\\AppData\\Local\\Microsoft\\Windows\\Temporary Internet Files\\Content.Word\\New leaflet pictures 121113_Page_1_Page_2.jpg\" width=\"122\" height=\"184\"/></p><p><span>2. Para romper el precinto gire la boquilla en el sentido de las agujas del reloj una sola vez (la boquilla quedará en la misma posición que al principio).</span></p><p><span> </span></p></td><td><p><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCACzAG8DASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2LxP8b/s3jiXwZ4E8I3fjXWrQkXiW04hhtSCVYGTa2GVtqnOACcZzkUo+JnxiGcfAG4PPfX4h/wC06zf2XdNtT8IJNYZS+oanfzSXly7FpLhlOFLE/ifqSe5r3lRtGO1AHjP/AAs34x/9EAuP/Cgi/wDjVH/CzfjH/wBEAuP/AAoIv/jVez0UAeMf8LN+Mf8A0QC4/wDCgi/+NUf8LN+Mf/RALj/woIv/AI1Xs9FAHjH/AAs34x/9EAuP/Cgi/wDjVH/CzfjH/wBEAuP/AAoIv/jVez0UAeMf8LN+Mf8A0QC4/wDCgi/+NUf8LN+Mf/RALj/woIv/AI1Xs9FAHjH/AAs34x/9EAuP/Cgi/wDjVJ/ws34xf9EAuPw8QRf/ABqvaKKAPDL/AOLPxbsbR7i5+AV+I0HzfZ9YWeQAnGQiQljj2/Su5+H/AMRdD+ImnXl1oy3UE9lIIbq2uojHLBIf4T1Bxgg4PUHpxXayR7lODg9Rz3rw3QdJ/wCEe/bG123spkFrr/h9dUmiWMALIJhH16nJV2P+/wC1AFn9lz/kg9l/1+XH/ode3V4j+y5/yQey/wCvy4/9Dr26gAooooAKKKMj1oAKKazqg3MeKb5i9+PrQBJRUbSKpwTgnp70eYu4LnBPrQBJRRRQA1z8p5xXj8gA/bItwP8AoSz/AOljV7C33TXj83/J5Vv/ANiWf/SxqAKX7Lv/ACQay7/6Zcf+h17SZG3YAGPUmvnn4F6xP4f/AGVb7XYI0mk05NQvFic4EjRguFJ7AkY/GqnhPwd8UPiTolh401/4ualpUepW4lhtNGXyFjUuxVSFKg4HdgTzyzY4APoyS9hhg86eQRRjq0h2gc46msPUfHvgvSJVh1bxbotjI671W5v44yy9MjJ55ryqH9mnwrPbLFr3ijxJq8jNunMl6FjmO7dyu0n07578Gut0n4C/CLSrl7q18E2kkjKUIu5JbpOSCSFlZlB4HOM/maAM7Uf2j/hPYyT28PiGTUbqJzH5FnZTyGRg23CPsCNz0w3OOM8VlP8AtF6bqE4h8L/D/wAV6+6KXlWCx5i9CQC3Ge/09a9V0/wf4V0eKOPS/DunWSRNvjWC2RAjZzkYHBz39h6VXfxb4aXV5tMbW7Jb23LLLC8oBiKIJGz2GEIJPbPOKAPNB8Q/jVrWntPoHwYayimZlt59U1SOJ48MVDSwHa49SoIPoTTZLD9pbWLqFbjWfCPhtIkYmWxt3n81jtwCJd+O/TH417HLeWsFg19JdRR2yLvMzvtRV/vEnjGMHNS2c0NxCJYZElQuy7kIIyCQR+ByPrQB4bL8IPihrFpKuvfGu9hac/vIdPs9kWAcjG10Iz7AfrWReabq/wAGvi74LWz8Wa/rXhjxBcNYXkOqXaTssxysbBiBgAurHAyAh5O7FfSTIpB+Uc14n+0jpLXnwkOuW8Ky3GgXsGoKPKLMU3hHAI+6PnDE+imgD2uN9w/lUlZWhahHq+iWOq28iSQ3tvHcIyHKkMoYEH0Oa1aAGv8AdNeQS/8AJ5Vt/wBiWf8A0savX2+6a8gm/wCTyrb/ALEs/wDpY1AGT+zVb215+z1BZ3sKT2s9zdRTRSKGV0LYYEHqCM1b/ZrnlT4Qtoc8bR3mhaldafc/dKNIH3naR1XEgGeOntUX7MC7vgLZ46/bLgdcfx1Q+Cs8ek/Fr4q+EheTOiakt/bwyKTjeW82TIGCTmIfQCgD3/AxSMwXqcenvSr0qjqt5HYabcX0ssUcUEbSM00gjRQATlmPCgY5J6UAUvES383hrVU0jJvjayC2CuqEy7W24LAqDnHJBHqK+Ro0tpLSaIXEv9loy/a7zDSS30iKbgxoJMYUMfMw/AG64n5KpXpEvxg16TWE1S3WCDQbQ+Wym3Km7YnftVpGUqRGMgnaEXMsuAVirzSWX+2J31PUAbXTYn2xwwKcDLec0MQcBVwFDvI+dmTLL83lxIAX77Xr3WLCwXVJfsOkaTGbVY4pm3TMn73ylDZ+Zf3WWkOEWFZZAH8uNfR/hBrE2n+I38PareGxa7tlNlpaIY4rfYu8jazblYrIWwRvIxJKVaREHl11dtp7RzXiLDe+Wv2azX5Y9PjJ84FkIPzBQHCSZwf382XaKKtjwZcN4Z8ZaffajG5vppN1wjyeQLaF8ySyS7m3lgp3ssjEIMNMTK8aAA+tUddoDNz71ieMdM/t7wRrmhqz51CwmtgIz83zoV49+a8bvPjdrl74oaPwzpti+kIBiS/V4t6IC8krSFwsSbME5VvLVkZstIkbex+Htas/EXh6z1izb9zdLuB5UhhwVwwBBzkdAR0IB4oA4L9nXW7rV/gvplrfeabnSJJNMlLoqgeW3yKu3qqxtGueD8pz616/Xzn8MNUs/AXxB+Lnh3Vprazs9NuTrUaLOAqW8gL/ACqSOiPFk56sB6V2Xw1+O3hD4kajJpVjHc6bqqoZVtLsAGVAeSjA4JGRleCAc4xkgA9Yb7pryCb/AJPKtv8AsSz/AOljV69uDR7h0IzXkM3/ACeVbf8AYln/ANLGoAo/sv4PwEs89Ptlx/6HVS387RP2ztQhe4haHxDoEdxtcEFTGfLCrzgn90WPHT6Grf7Lv/JBrP8A6/Lj/wBDqD4nmHRfj18KvFElkpRry40mSVFXzGaePy4QcnJUNI7e2WxyeQD3Vfu1m61psOraRdabcO0cd1G0TOmN6hgRlcggEdQfUVoocr9KjmUkdCR3xzQB8WXkbPPPdanC1hY2Uj26JGPLwyt/qY2nGVII8x5JACu7zZSZNkaWL6f7HBHqE6WpvfnW1swd6aYi7ShaNz8r/MJFEg4JMspaTZGOk+JnlaB8QNTvpGSW9Enm2yLGoitAqiXcS6hN/mPvCgMqFhLIZHMSVzdjZvZzyFzLNr8e6RFZN62SopdpJXlYCORS/mEsG8oOZX3TFEoAjtbWazumwA2tOGkEcshAsBuB82XghZFH7z94SIgxkk3TOiVXZ/PZ9L0eRYrdmaSe5mxbmYKc+Yxk3PHCgJk+fJGRJLvldI6Rna4MulaTIfs0I824uXYx+b5QD734PlRI7h9rnIz5snmTSKlWn+y2VjJHHLNa6PBMfMmO21mvpohkBQSSmwsW+Y/uc+ZJvncBQBJFtorKURLNbaVEzb7lEEM19KrZCq0xOwICXG/IhD+ZIXmYKvufwR1Zrzw1qdnJE8YgvGeFBuEMUZVV8uMMARtK7mHzHMgLt5jSIngzLtC6tqkQsrK13QQQW/8Ao65h/wCWMTSHdGFdyXcqWjO123zuqxeofCHUPsPxAfTL9FN5fW7W8dtbxny7COFQ4iII/dn5ifLH3dymRmklwoBV+JOl2n/DRGm2F1KbWx8a6JPoV3MIjuQ53IUI/jMixLz/AA/gRU+DXhPQ/BXx28XeC5LGW5nsYotQ0m+niXzRCU2S5kXG7PnKAPu/KxwDXUftJ2U9p4S8P+OtPSRrnwxq0Vy5SbyiIXYK2O+S4iHHQMaq/EEr4a/aE+HXjTycW2rI+i3brCdqO2BGWderMZMAEDhCeQMAA9+X/VD1x6V5FN/yeVbf9iWf/Sxq9cXmPpgY6GvI5f8Ak8m2/wCxLP8A6WNQBS/Zd5+A1ln/AJ/Lj/0Oq37S5Sy8C6J4gSRobzSdbt57edWP7k/N82OnYVZ/Zd5+A1l/1+XH/oddH8cdJk1j4GeLbSOURGOyN2WIJ4hYSkde4Qj055oA9Bs7uG8tYbm3bfDMgkjfGNykZB/KrPb3rjvhlqj6x8LvC+pyNG8lzp0LP5R+VW2AEe2COR65rsc8UAeFfGTSbmHxVpfiO0jVpngW2W4zHCtiImaZpXlcEA4JKuy7Itjvtd/LWvHIHW8l/suwt47q12Fru4ui6CbaDK8jFyPKjjLrIqtv2swkkEkrrHX0h8XtHk1bwBdLHdRWotnjnaW4ufs8Uaq2GcsflXaCWyyvtxlVLha+ct1otozRtJBpkcm5pFiKTXsqtkAeZkRBB8wzkQBt7l7hgFABGtobARtcPBpMToszkmOa+ljBmKqORGEzvw2RACzSb7h1CxKcRR6tq0i2dpbEQxQWx+zE+WTI0USjc8YQlSzkkxtksGuHVYlaX7fv1fWGMVqpMUNvEWiz8+fKiA4jVOrO2/yyxLbrhgI1urqSzlE1yPs+qGPbDFFiFNKTd8oWMBysiKQQuH8ncC3mXEirQAs802k3SXd2IrfVrdY4khihESaZHH8+xN27bIu9dq4fyS6swknkRaueH76bwt4m0+8LLJqdvOolVwypZp1ljZnYgSN5pUjnyvNIxLcSGqtvaTafdmGI/ZNXK7pZmYRLpKBiWZpGLkSIrHJJfyd3G+4kY0yxRFc/2TIWucMTezR+SljCJGBk3MSUbacbhkxq4RA1w8j0AfTfxS0Zte+E/ibS9sTeZZSOPMXcN6ruGPfcMg+v0rwjWrmbxh+xZoetWsqRal4Z8hke13xNbtbkwqw5zu8pgfq3GMYr6F8E6tDrfgHSb4yy3AMPks8qqru0ZMbFlVm2kspO3OR0bBDAeR/BvS7dtK+J/wAJLxr9LPTtTntoy6okn2S4EiIwYAZZgjPkjHzA9OAAe3+GNet/EnhTTNcg2qt/axXHlpKJBGWUMU3cZIJI/A153N/yeVbf9iWf/Sxqqfs66pcTfCz/AIR/UHP9peHr6fTbqImMeUUbIA28FcMRu7lW5wBVqTn9si2/7Es/+lrUAU/2XP8Akg9l/wBflx/6HXr+sWMWo6Ne2U1vHcJcQSRNFKoZXDKVKkHggg4P1ryD9lz/AJIPZf8AX5cf+h17Y2Mc0AeH/s36myfBFNPu4ltn0G+urKVzICHIczM3YADzSPT5a9Ht/G3hq51d9Hh161kv0Z1aJTkIV2hstjAwXVTn+I468V812EupaJ/wtPwfpsklpEPECzSR3BkUW9oyySGYyfdjDbI8uQcrgBWYoKyf9FtNN2RyT22kQSKHxIIJb2eEFmG1Qxj2M2ep+z5JbfcONoB9XeKbI6p4O1azFm15JLaP5MYl8hnkCkptlwfKcNtIkxlThh92vkxi0obV9W3Q2UKmG2t4QYwfL+VYot+RGqux3PgmMsD89w4EfoPhj4reINDW5vPFTtPpcjmOOGRTHIjRjDpEGYthdyK5bJUqqZaWQqvD6lcR6bq0t1Avl3MDiG1jeMIdKhj5SMZ+RJl8xQAoPkmQcS3EgFAEN1dXVleG4lVBrEOFhiVSI9MRQEjVUUFY5BvGFO4Q+Zk77iQLRBby6bI9vaMtvqiCVpJpJhBFpaL8u9ypbbKAzEsSxhLsAZLiRmpbW2m064+zQtF/atspkluHZjHpSxqTIzMPljkDSNlufJ8wqDJPIWqAOvOj6TK1ra2wE9xNP+4JMPWaZY8tGEd8KgOY2YqBJcSFogBWwd+k6ORY2lu3mS3M0YtjhDsE0pyXjVCz7U5MbdC9w5MabRco2naWotrCEmeS4mVot21vJE0rclNvzKkabth2ohM7M8TV6Np2mlLCysVWeee4ItyPKBTz5thLx7XJVI15Qho4y0zSPFa2WsVkJWtpYdJhlLQQlfLmv5YlEQd2/hCsQmUBEfywxBpizAA91+B93aT+F9QsrSB44IrotEZGO+ZcBN3XauPLC7Ixsj2hMsysa55kh8K/tmPJtjRPFOinkSkFZVI+cqRgk+RgAHofwrJ+D19df8J6tzeNI6X9nJaQJGrbdkO3kKvyRwoVaNeqqWCKXYyudn4/vN4f1L4f/ENZZIoPDuriO6RIfNxBMF3vnIxgQ7QO5cdwKAIPA6/8It+1R458OqEjtddtotUjVLfYGYcnBHykfvJMnufeuif/AJPHtsHP/FFnn/t9ap/HHhXW3+MfgHxx4d0k3hspZdP1VkuBG/2WQYVmJ+8sZZ32jkkj6iF/+TyLb/sSz/6WtQBT/Zc/5IPZf9flx/6HXtj/AHa+Sfgl8avBfgj4R2ugahLe3etC7lZNPs7VpZZ98mFVDgIWPoWFd1J8Yvid4huHj8F/CG9itVkZRda3J9mBUKT8ynaEP/AmH1oAI9Ks2/ao8WaBfPHdWfirw7BfTRvlGV4nWBURlIPRC+R8wIBBGOYvGXwdvrW/OqaIJdQ0yKMbdOhkWKSJVYMsUe1RhBzyAXADMFklcOvnfhb4qCL9oe11T4qjQLWe30ya1tr3TjDNHasxEil5VdgDsDoMHI80jGGY19TeHfFOgeLrKS98P6vb6lbRP5bSW0hO1uDg+nGD9KAPkmeaWwuw8kjWmsbFjjWKJYE0tN3CIoDssqqQAoD+TuXiS4kxTrS1ns7vyrdki1fbvnmceWmlxglnJkYttkVSVLDd5W7au+4dnP054q8A6Jrnm3lvENN1zawi1O2XbKjNxv4I3MAXCsfmTexQqTmvAPE/gjX/AA2fsH2OC10lGErajkLE+P3ayyOc+XsUMUjUEpuQoWnlMkYBzalbtV03S4mjsYcTXFzNuUfKxJmm2nEYQfKqAsYy+1Q1yzNEkW66Eem2ErW2m2+2Wd58x5Kk5mmEXKbc+WsaNlC5jjDTF5InPDDc6eUgk/s6wWY+UZxI0lw4dYWkYJkKI0YgBcrFlYoz57s6PZrV9PRijLpW93trMybJL6TPl+Y4gBCoo+T93kRBhDCGdmYACxm3hsrdplmh0iJlMNu222lv5UzukfygWQAYQ7B+7GIYQ0rOwYq+e6atq0bOpZUt7ZB5X2gKSNoxkpEpby/3fJP7qLdI8kjK3+kTnUdUhV1n/d21oiiD7R83lKoWEMyQqPkxGTy7RRbmaWRpbq6mtbtvLbzNcuv3byJGFNrubyhFFjOHCAp+64jwYofnMsgAO1+GaEfFXTo7mEX2ohZPtEqqzpYKsMnyqUIRWGViJGUjBEKBmMsg9O+OWijW/gj4ltxbmaS3tvtKIG2hTEwctknsqk4zXmPwheHS/iDDCv7+5uLeSK7mjdmgtQWASLIIQ4eKOMsAVVgIogwEr19HXVtb3unzWl1bxz20qGOWKVd6SKQQysp6ggnOetAHOfDHxC3if4W+HdZlkaS4uLKMTM77maRRtYk+pKk+vNclL/yeVb/9iWf/AEsas39nSYab4R13wNPMhvfDOsXFq6kbHkiZtySlT0DESYx2X8a0pf8Ak8m2/wCxLP8A6WNQB4h8F/EXj+2+HjaD8O/hylxqV2ZGn8SXaeXb9SFXOMSFM8AucE/dxmu8/wCFXeKfGWvWelfGbx9dXpuEkvrfRtLdYrciMxBwxIG8/PjhflGSG5rpP2X2C/AayywX/TLjk/79UPi98XvAelLDZWes3d34ns5lms20YiRreQnaQ7HMZUrkNGckg9FOGABHL8P/AIL+BfF0kPiLRdNsNNTTozZT6mcxTSAyCcb3OGl2mI7TkgZKjIJHFfs5/Z7f42eLrPwvLcz+FxZFVuRGRHMyTKLdmyilX8tpOP4iJG6cLe8aaH8WvEnhTV/GvxA1ePw5oen25vYfDFu+4SKo/wBTMy8Hfg5JLH5sbQflH0toUNjBolomm29vbWflq0UVuoWNQeeAMDnOeOuaANBVVlIYZB45HWmzwRTQPFIm5HUqy+oPWpqKAPFfFfwXs766XUtFndTboPL02Z8REJGyxRo45gRdxHAYhWfbsZy1eT+IvDevaHfhvFdmHklbZaWi5K3exRFGAsPCRKJQuxfmAlWKPLPJI32DxXm/xitdQn8AS3GmoZrm0uEmCRQvJNj5kYR7DuDEOVynzEFgCpYMoB863V7c6dfskLSS6/K4iLW+0G3x+4SGJIstvBLR/u8hBmGE7vNkCWtqdME0drMkV1DCxuL/AIWOxiA8jajLkk5DRlo+pBgh/wCWkgSztV02Sa1t7qOO7hUfbrvzAIbWNRtdEEPzMWLeWWjOW5ggIxI4rqq3jfZ7cfYNJssTSSTIFJKjZ5smzl5GOI1SMDp5UOAJJKAJ7e4uLi7jfSGexsdNlS4S4kzIUZf3EcrlcBpMgxokYOMeTFgeZKPrvw/rNrr3hzT9XtZUkiu4VlXbKkoB4yNyEqSp4O0kZB5r5Dke1+xwTvan+z0ObWzOXe7ZV8tpZWGMqT+7LIBuwsEHyb3b3X4O+LobzwY8Osata+fbXDKskl1F+8TJ5VVO1UVg6LsAT5MKXA3sAYHhlpfDv7XPivRg07W/iLT4tTjUurIxU438cgAiVRx/jW/J/wAnk23/AGJZ/wDS1q5H4ieI9Aj/AGhfhhqXh/UrDUtTF5LpWoW9pcb5fJl2Ipk2ggKnmOwDYJ9+SOuk/wCTyLb/ALEs/wDpa1AGd+zHtPwEs1bhTeXAP/fdeXfCXw38KPGfwFu9F1a+sdP10TSS3t60ix3MD7/3LZf70e0oNv3csc4Ykjn/AA/8UNP0D9lp/BWnp9v1/WDeRPBB8wtrdsl5XOOB5e4jvj5uAM1B4S8C6Z8RB4I0zw/8P9Rs9MtpI5Na8S3YeGO7CkiWKMbmXnAQFWB3HlQAaAOi8MeHfiN8XrXVvA9/8RBP4N0G5+yrqKWy7tRKEBFyuC6gDf8AMxwShO44K+q/s16tNN8LJNBvH23ug389iY5EZGRQxYKc9wWI9sYPTJ9b0Tw3ofhjSF0vw/pNtptmnPlQR7Qx2hdzd2bAAyck4rwvX/2btV1fXPENzpXxS1LR9L1+8lvbnTFtmaN2kYswcLMiuNxOMr0wOetAHtGteN/Cvh6OZ9a8Rabp/kgM6T3Kh1B77c5xzXCar+0f8KNKNyn/AAkLX80CF1is7aSTziFyFR9oQk8DlgAepFeWn9jYsct8RlY9Tu0XOf8AyPXaaP8AAnx34dSdfD/xet9IW4IaYWPha2gEhAwC2xxnHbNAFj/hfOuarKh8J/B3xPqkQQNK12i2m3d93bgPuB9e1c94m8TftBeIvA1+n/CsrTTrOaJmmIvttx5S8uuwSB+QpGBhiGGBzx0t18IviVfNDFq3x61h7NJVkkj0+xWylcDjAkjlyOvcEdOOBhLv9nTw9rF1azeJ/Gfi7xKtqGMUGpal5qoWxkqdoI6DoRnAznFAHjvgn4bfEf4m+ENK1Wx8VaHo+hytN5n2eBxP5mSrMybApYAKi7XConypgFge5sf2X9SM9x/a3xMvnildphHZW/kKHZNhOwuVAKfJ8oGBwOK6T9n9xpM/jr4feRLEPDmsP9mWQqypazFvKVTnJP7t25/vj6V7sqjA4xigDwK1/ZX8GeUTq/iLXtSuS27zzcKnHYYKnpkj6EivKfip8EfDHh34p+BdC0u7k0rRvEGbSSWSZ5ZfORlDPzgAv5kYABxnPAAxX2rXjv7Q/h+81b4R3l/pjSxahok0erQSwMyujRZ3MCvOQrMc9sZ7UAaHw6+CXg34cf6fpcct7rBRkOo3eGdVIGVVQNqjj0zy3ODis+QY/bIth/1JZ/8AS1q73wZ4g/4SnwNo3iFDF/p9nFM4iVggcqNwXPOA2R3rg5f+Tybf/sSz/wCljUAcf+y54P0KL4eR+MI9NibXLmWa2e7OSwRX4VQSQue+MZxX0ci/KNy4bvXzP8FPHOi/DHStW+GXj6+t9D1PR72R455dywXcTEfPGxAz6gEDKspGTux65/wub4WY48d6R/4ECgDv8CjiuA/4XN8LM/8AI96R1/5+BR/wub4W4H/Fd6RnH/PwtAHf0VwH/C5vhZ/0PekY/wCvgUf8Lm+Fv/Q96R/4ELQB32BQ2Ap7VwH/AAub4Wf9D1pHf/l4Wg/Gb4W4P/Fd6R/4ECgDgLHzPDn7ZGrWSLHFb+JtEju8JIVG9CRuZcctujcc9mPvXvqZ2818x/Erx34Bm+Kvw38Z6D4j0e+msNRaxvmicb1tpQF8xmHO2PMhGeMuenOfXV+M3wrx/wAj5o/X/n5WgD0HtVLULGHUrC4sbuFZra5RopY26OjDBB+orjf+FzfC3H/I96R0/wCflaRvjL8LSMDx5o456/aVoA4X9nXUryz0LX/h7qzMdR8Kag9vuZCoa3dmKMNxz95ZDjGAuz1ydiQ5/bFtmzn/AIos8n/r9avOB4+8DeHf2oZvEen+INNn0HxDphiu7uF0KW1wgJ+bBBGQiHJByW4/ix0fwr1K++Ivxz8SfFD7PdQeHIbEaRpMk8aoJEDhnx3Pzhmyc48zbnIxQB7B4k8HeFvGFkbbxPoNnqiRgrG08YLxAgE7HHzLnaM4IziuUHwA+EG7/kSrft/y8T+/+3RRQAv/AAz/APB//oSrf/wIn/8Ai6P+Gf8A4P5/5Eq3/wDAif8A+LoooAP+Gf8A4P4H/FFW/b/l4n/+Lo/4Z/8Ag/8A9CVb/wDgRP8A/F0UUAH/AAz/APB/P/IlW/8A4ET/APxdH/DP/wAH8H/iirfof+Xif/4uiigBp/Z/+D/bwTbg8jIuJ/8A4unj4AfCBh83guA/W5n/APi6KKAD/hn/AOD/AP0JVv8A+BE//wAXSN+z/wDB/H/IlW//AIET/wDxdFFACW/wH+EdtexXMXgq08yGRXXdLKy5B7qXIb6EEV6HZWNlp1pFY6faQ2dpABHFBAgjSJQOFVRwo9hRRQB//9k=\" alt=\"Description: C:\\Users\\maln\\AppData\\Local\\Microsoft\\Windows\\Temporary Internet Files\\Content.Word\\New leaflet pictures 121113_Page_1_Page_3.jpg\" width=\"112\" height=\"180\"/></p><p><span>3. Cubrirse la mano con la bolsa de plástico que se adjunta.</span></p></td><td><p><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCAC3AHEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2X4mfE/XNN8SWHw++H1gmqeLtSXzd0mDFYxEH55OeG4yM4GBnngGja6L+0vJBG/8AwmnhSMsu5la3YlT6cRY/HvTtDhjk/bJ8TtJGrFPD0LIWUEoS8Y49OCfzr3FV25oA8T/sH9pj/oePCX/gK3/xqk/sH9pjn/iuPCXf/l1b/wCNV7dRQB4j/YP7TH/Q8eEv/AVv/jVH9g/tMf8AQ8eEv/AVv/jVe3UUAeJf2D+0x/0PHhL/AMBW/wDjVH9g/tMY/wCR48Jf+Arf/Gq9tooA8R/sH9pj/oePCX/gK3/xql/sH9pj/oePCX/gK3/xqvbaKAPEf7B/aYx/yPHhL/wFb/41S/2D+0x/0PHhL/wFb/41XttFAHhk2i/tLohP/CbeFGYdhasCfbmMdelWPh/8SfE//Cwh8M/iPpNrp/iL7KLq3u7J98N4gXJBA+43DtnodrDA43e0lfzrwr4q28UPx6+EeoQq6XMt7PbvIrkZjAjO3r0+Zs+tAHu1FFFAHiWgf8nkeKs5z/wjkHX/AH4q9urxHw/j/hsfxVgY/wCKcg7Y/ji7V7dQAUUUUAFFFFABRRUcjkJ8oyx7CgCSivHtU/aA8G6f8TrXwHDHdX91NdpYy3VrtaGCZm2bCcjJBxuxnacg8g49fjJMak9SPTH86AHUUUUAIa8S+Lij/hc3wb/7Cdzx/wABir2014l8XP8Aksvwb/7Cdz7fwxUAe20UUUAeJaBn/hsfxV/2LkHfP8cVe3V4joH/ACeR4q/7FyDtj+OKvbqACiiigAoophlQPsLAN6UAKzcHsa+evjd8VvIlHw88KavFaarcEf2rqeGZNLtv4ySvKucjoCQp7FlNdB8W/ik3heZPCPhGH+1fGmpgRwWkRz9mUgnzXwewyQCR03EhRmvBPAPw4f4ha1/wjVjJDL4e025iuvEGsmYzSandbcmOMkA7AWdR2PMhJJXABvfAP4YReINUsvHV7aRweH9JlcaZbTfPJczggm4cqRjawGBzjAGONx+wYQREuetV9Ps7ewsIrG0tYrS1gURwwQqFSNAMBQAMAAelW6ACiiigBDXiXxc/5LL8G/8AsJ3P/oMVe2mvE/i5/wAll+Df/YTuf/QYqAPbKKKKAPEvD+P+Gx/FOP8AoXIOhz/HFXt1eI6Bn/hsfxVnP/IuQdf9+KvbqACiig9KAIppPLUHrzXj/wASfjdoXhH7ToeiZ1vxgdkUGkwxSSMJHHyb9oxxx8gO/oMfNkewSDJA/H2r5F+Dmi/E680nUvFPhGHwXJJd6nOZr3XFuZLx5A3J3KCAPmPTBy3NAGFDo3jHVPGl/wCCItTgvvH3iOHd4i1OUo0elWpXabVMZ+YjG/aSMFEHQmvrfwb4R0jwT4atNA0W1igt4FwxjTb5r4G526kkkdST2HQCvEPhFY+JdN/aV8d2viu4sZNUuLGG7uP7N3/ZyzMhXbvAPAOOc4z1r6UoAKKKKACiiigBDXiXxb/5LL8G/wDsJ3P/AKDFXtprxL4uf8ll+Df/AGE7n/0GKgD22iiigDxLw/8A8nj+Kun/ACLkHT/fir26vEdA/wCTyPFX/YuQd8/xxV7dQAUh6VBNdRwEmQ7VUZLEjA/w/GvGtT/aP8IQz31toOj614lltJ/s4l021EsEr5AwsgJz3wcc44zkUAeq+JZpYfC2qSwSPHKlpM6yI2ChCEgg9QcgV+d/iI32leCPAF1aaleRST29zqCbJipgnN06bkYYIOIk+brwOeBX0F4w/aeih0+40O4+H+sabeXEbRSJqH7gxI6H5wCuScEEDgEHOeRn5i1/xBFq3hfwvpMdu0LaLYy2zM7D52eeSUEYPQB8cjqKAPtXwzj/AIbA8dD00a0/lFXt1fKXwv8Aip4a8R/tGeIPE17OuiRaxpsFtaR38ixmZ1ZFCqx+UklTgZyemK+obfULe7i822mSZMkZjdXGfqD70AXKKgFyrfdySeelTKwZQw6GgBaKKKAENeJfFz/ksvwb/wCwnc/+gxV7aa8S+Ln/ACWX4N/9hO5/9BioA9tooooA8S0D/k8fxV/2LkHbH8cVe2mvEvD/APyeN4p/7FyDoc/xxV7TLu49PXvQB4z+0F4mtdN8J2PhSS9ktZvE12lo80aZ8i0DKbiQ8EYCkD/gWexryuGFfJW1ksItHtXaT7TbxRqFthcBY76IADA+zwohHBA35ORWtrHiLw/rX7Q/iDxJrkQ1LRPCFg9nFaeSJFvJxhJ+HULiMylWBbORGeQSBPqcen3Pi3VbWC+aa0iunhkgueZS5kxcqduebmPZHGTjc0TgBCOQDnLm3ttYs5rS9ge4a5wktpKCB5/lqTFz91RZLHOORiUDncNo5qf4b6O0i3XhxbvTb3G2zntbrmSWQFrHIfODNFudiCApTGF3ADtZrO4W2icKsk18oQXKvlGlVnkMq7SdmbW3kt+ACWRxjaWY1rcx3lvFKmspZRXS4V0fK2yzYfzRhgMWOBb7uNvmgZjztIBjajrQ0/TNNs/H1np/xD8Gx+RN9ritWs7+yhcvHG7FMbgxjlI+ZmY/fKFlrrPGfwd0Lwz8PtR8f/C/xPrGjvbQnUYEjvm8l4mAzsZfnH7vdgsTk7QT3GJqz6VLoeqahrnhuL7Ja2ct7JaTqVCeYjRJZhhGxR7dmVlO35Wu14j3bjV0D4kajr3wQ034SeHdMOta7c2EtvfXszCG20+38wbCWIwdsZRMkgBscsflIB2ugXHx5s/A+k6rpHjLw74o+36ZbXcWn6sixXUZdUIjVhtDk+bGC8jgk44553LL43+ONMlmj8X/AAo1JreC4aCa60OQXYjYLkLtHDHJB++MBs+m7mPCvhu58HeHRoM3iFtQu7ecrqGpQzlY7fy49q28DuV5ijjkO4sqxfOcD7y9DbXV5Y3cNnpEv2SeBBGojDf6OrbsgIQMnKv8u0f6lmdkKf6KAdHoP7Rnwu1xQJtbfRbkIzSW2qQNC6YbbgsMoSeoAY8V6RpHibQtetvtGh6zZalGFV2NtMr7VblScH5cgHr6H0rl4YvCHxDsns/EOgadqlxZIMw30MczQ+Yg+ZSVym4HrhWxtOBlc8nrP7NPwv1ZW+y6fd6RJt2rJZXDfLzndh9wJ6dfQd6APZvOLHjb1xn+f8jXjXxc/wCSy/Bv/sJ3PT/dirh/GVr46+B7aRrdv8VrrW9Ju9UWFtN1zDSGNl5zIzEsoC842AdcV2vxXdX+MPwZeNg8balcFWU5BG2LBoA9vooooA8S0D/k8fxV1/5FyDr/AL8Ve1uegrxTQP8Ak8fxVjA/4pyDp/vxV7WcFgOvegD4z0PWLjVPEXiy80ZFuYT4murqwZo2VZ52kka2Rs4+VkkumPTBjTJXOHvx29ojQ/2DdSTbIYY7EyKAZEjD/wBlSNlRhpJ3kLDgDyk3BFLb9D4XeINPsfhFf6O+ijVtRm1m5Nkjny0jndWWPD5DRsQkuGXGAp5Ulc3JLrwtqck76dZz6ck6u1gbFAwCzhY9OOxypUeYszIu5RE2fuBsgAxZY45LJ1mhEumvHuELqCWtfP8ALVee/wDaA83k52HGcfJVybUtNVJR4hs/tixW8y3JhxHIY43RdR2lccvcCIrkfc3AeWSMRXlrDFrCLpNz9uEqm9tNlvIEaIu9mYBkAg7zNcYPHmOQAxIY9B4f8L6/qWsx2MenzRQ2k4MlzcwMqD7I/wBniyDt3CVHeRgvUpwcYoA8d8WNP8R/izfeEtDuDa6Jp1zM8k8mW86QeWk1zI4+QFjGhAG1QFAVS7bW9Z8N6Hb+HfDFt4X0iQJBbHfd3bbVkkmzuJ7AyAEDJ3LEiMCwcMy+J/CPzNH8Qw3OqSf2fb61ZyfYrkkAS7ZdrrGxZVWQkFcnBQMGBT5SfoDeseLO1byhD8hKfKsWM+65fKysASSGUO4QoDagD1zG4tbCI24tsLgKQIFyCoJYhg2EXCl4z9522mP/AEXn/FHjbS/CejwyahJNJa4e3tI1cO8zH7zopAGxG/eO5Uq7ELjA2Rcn4p8cXNxdReEvh5YprN9KqmRrXc8YQkZVCu0jJcZZRGfljxtCxrHp+HfAsR8nWNfuG1nWZgPNvWm/dDJAFvDj5REu5FJUNuBMaoVdUnAO28F+IpZ4dP1yztbzT7NyJJ47gMZrgZG7cFJOC3zE/KSWjVQd2yb3+2uEliWWN1eOTDI4OVYHnOenf8a8CZ3nla1tmRY0BEj/ANxdowiDBAIVkycFUWVvmdnZrjrND8cSWmkRxvYrPpVtCFhkSQiWWNULBt8r4AKr8pd8kHexQKWIB4V+1V4ll1/xvp/hjSRJcwaNGv2oxq5VbmblUPHXYqkEHksw6qRXrXxHjaL4l/A2ORCjpeSqykYKkRw8Yr5xlvfEGt6LqniSbwVq14+va7Hq8epW1uJUEELSK8WUUYwWIJPBwMgDNey+Ivid4P8AiN8Z/hSPC2oSXT2OoyvOrwPEUDqm37wAP3T0z0oA+oaKKKAPEtBz/wANj+Kf+xcg6/78Ve0TNtZBxg+p614v4f8A+Tx/FX/YuQdsfxxV7ay7higD4c8OabeaFqfiTw9qd9/Z72GrTW09zNuiW1aVTJDdJuA4VLecgkr8s+QfmbPXeYtw20WP9jGX59u3abHzvl2dBj7Bt83tt83P7vqek+KF9/wqP41Q/El9Pkv/AA/4ktDpmrwRhmxIqrsbBO3OxAAO4WQYGd1ZWpavdalPc32uwWE8TCVZ/sC7EHlKG1MxYI3LJAYURn3HjOUPzEAyZY3Ekd1AUS5DecIWX5ohta3a2HIIPlyS3nsJWbaQS59k+EerPdaTqGjvO8iabKkNur7j/o4VooHGeCrxwpICvykyMRwRjyWJbF9duI7u6/s4faNqXbp53l3AtRK7uBgbfsQMPA6ndtDDfXrEWq+HfA/wb1jX9F1G2uzaWjywyyRty+wLbQOgww2p5Ue04bAJb5ixoA81+GXw00X4lfsxaLpmpFrS9guLuSx1CMbpLaQzNyOmVO0blyM4HIIBrl/iR8OfFHhPWPCWkah8Qb/WrbXp3054LazNmCmIlYMInPmblRAQeuxeeBXu3wD0iXQ/gb4ctZgyvcRPdFXUjHmOXH4YII9c1598cUXVPjZ8PNGlvJRZrHcXLxpIOCo3ZxgnLbNvALYJ2gtigClofh7w/pOmHTNEsIRp0iFZnDB5NQXo2WVG8wESgF1RwftASPIZVn2zuaR4YpCgiylzdKoBQKjb1Vix2kK8pJLERiXP7wyE3AWN0z29vKbaNuJJ1kjRYjySqfeTKiTlsyqiq2d7SMbiKaOOW8hsoLYNb2x3yR7XCAgMyR4J3fKdr4YqoCuZGY+b5YA5YY7i1VJYhb6aADHCyqqznLPvZWwPLz5siqc7tvmu2NzHifitrjx+ANSmY4a5b7OBISZG3v8AP/rF3AZTHzKjM8BJX5Ntv3CSvdSF/Lf7CScD/nvggjJ3LlCYxwWLOWbIj8v/AETlL63XxT8a/AnhLy5Lyys7l9Tuz8nlzCEAIRlVVl3IysEUBg2FCoqKgB9H+BtAbw18P9C0CR2Z7CzjhfMm7DBfmGRjPJPYV5f8WLCzi+Onwj1BLWFby41CeOWdYwHkVREVVmxkgEnAPTJr3KE7k+9u5PNeLfFz/ksvwb/7Cdz/AOgxUAe20UUUAeJeH/8Ak8bxTj/oXIO+f44q9urxHQM/8NkeKs9f+Ecg6/78Ve3UAc14y8J6b418Lah4b1YE2t7Ht3qAXhf+GRMjhgehr5FvtM8YfCO7vLTxTpd5qmiWXkmw1W1hLxFYJHkj80lv3as0qIwJyAAoztBP2/TPLXJbHPr6UAfFFn408LatE1lDq0EcCj7LuuP3bmIEXXmYbGSZ2EP/AFz9uayLqK4+I3im08NaX/pWkW9x/aGp3EEaukUtwRI8SSLlnxI0iBBjeU/2dy/XHiL4UeAfFK3H9s+FNPlmnZmkuIohFM7HGWZ0wzHjqa8/uf2e7bRZjJ8PfHfiHwixlWZoUmNxbthdp+TK5bgHczNj0xjAB5XF8JvCztF9mutUNmhAWR7/ACLhsqgjUhSu3Jj3Ou8sZCqKT5Xm7Gg+A9A0DV7m+0jzp5xC0Mt3dSebJCuMsseQQjMChZhwqy4DN/y33Ljwj8etFimVrfQPFiyiMSy27fY7wKCysIn+VVYq8hywcZdzjLsDzl58RrbSI0tPEnhPxH4Kk7LNamZFVZWJ8px5e7G4OGKYyrnJdhKoB2czrHDLb2sz2tvb7knuQRE8JUH5QxYYkAEzEtKDGSXc797wwJb/AGqKG1EapaR7QIQCA/zHJC7VO0MkhHyKztEp3R7M2tjwu3gzxSLWLw9420PaIX8m1SRkmRlAZVKMY5fLBWIkrs3eTkY/diD1yz8I+HYNNjsxZpPFtwzuwDS5CKc7cD7saLgADaoQDbxQB468sdzbXL/aPJsUUtPcAnDkMAyBxgrGrAKWG3PlrGiBQqpl/CfTp9X/AGjfFOs3Wltb22iadHZwJISnkmQDyx5YwqAxq/yKCq+rfeb2rUfh7oty0E0Ek9u0EgdV3BlH8OQD0KoXRCDgBzkNk5+XfhN8ZdH8H+JvFqyeHL7VY9Z1SS9l1SzVjIsPmYXfCzMyqu925kZgWwc9aAPtdBgV4r8XP+Sy/Bv/ALCdz/6DFXT+EfjF8PfGbR2+h+IrcXrDP2O7/cTZwW4V8b+FYkoWAwea5T4sSBvjJ8HPmU/8TK4PB5xth5+lAHuFFFFAHiWgf8nj+Ken/IuQdP8Afir26vEtA/5PH8U9f+Rcg6/78Ve20AFFFFABSFec96WigBu0VFLaxTwvBPGksTjayOoYMPQjvU9FAHnniD4N/DLxGxbVPBWnSys3mNJAGtnYhcAFoipIx2Jx044FcB/woHxFoM4m+H/xX13R1DRssV0fPjAQcBhwrDr8pXbgkEGvoEjNLQB4A11+0xoOnS6ZLpGieL5JYXWLVLS4jtpYWLHDOkuxGPOQFTbgAEnrW18Dvg2vwx0a6n1b7Jd+Ir35ZrqDcyxxDGIlzjjcNx+UZJx0Va9k2jJNG3nNAHm/ir4K/Dbxckv9p+GLeG6ZTi6sh9nkQldoOVwGx2DBh7V4pqfw3ufh78cfhlBH4o1LV9LutTmNtb3zFjalQmSDnByCoJwM7RwBX1meteJfFsf8Xl+DZ/6idz/6DFQB7bRRRQB4j4fK/wDDY/ikcA/8I5B7Z+eKvb814N498N+NPDPxctPiz4H09tciltxY6ppSybXeIYCsg/i4wcc4IzjBO3K/4aO8SQySQyfBnxAHRipBduoPPSL8KAPo6ivnH/hpPxFj/kjOvd/43/D/AJY0H9pPxFk4+DOvf99v/wDGaAPo6ivnH/hpPxF/0RnX+/8AG/8A8Zpf+Gk/EOf+SM6/1/vv/wDGaAPo2ivnH/hpPxFgf8WZ17Pf53/+M0o/aT8RZ/5Izr//AH2//wAZ+tAH0bRXzj/w0n4i4z8Gdf8A++3/APjNH/DSfiLH/JGdez/vv/8AGaAPo6ivnL/hpPxFkf8AFmdfx/vv/wDGaT/hpPxFg/8AFmdez/vv/wDGaAPo2vEPizIrfGj4OpuBZdTuSQOTjbF/hWCf2lPEAP8AyRnX/wDv4/8A8Zq34N0Dxl8Qvi/b/Ezxxo40Cw0VTDpOkzR7pjuU/vHJx03ZzgZIGMYOQD6CooooATaPzpQuKKKAFooooAKKKKACiiigAooooAKKKKAEZd3c0gQcck49aKKAFooooA//2Q==\" alt=\"Description: C:\\Users\\maln\\AppData\\Local\\Microsoft\\Windows\\Temporary Internet Files\\Content.Word\\New leaflet pictures 121113_Page_1_Page_4.jpg\" width=\"113\" height=\"183\"/></p><p><span>4. Agarrar el envase como se muestra en el dibujo.</span></p><p><span> </span></p></td></tr><tr><td><p><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCABxAJsDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2uF/iR4+1vWLrRPGEPg3R9Mv59NgWDT4rya8eJ9kkkhlyFG5WChQDgnPQVf8A+EF+K/8A0XK6/wDCesv8K1Phb/yB/En/AGM2rf8ApXJXe0AeXf8ACC/Ff/ouV1/4T1l/hR/wgvxX/wCi5XX/AIT1l/hXqNFAHl3/AAgvxY/6Lldf+E9Zf4Uf8IL8V/8AouV1/wCE9Zf4V6jRQB5d/wAIL8V85/4Xldf+E9Zf4Uf8IL8WP+i5XX/hPWX+Feo0UAeXf8IL8V/+i5XX/hPWX+FH/CC/FfP/ACXK6/8ACesv8K9RooA8u/4QX4r/APRcrr/wnrL/AAo/4QX4r8/8Xyuv/Cesv8K9RooA8u/4QX4r/wDRcrr/AMJ6y/wpP+EF+K//AEXK6/8ACesv8K9SooA8u/4QX4sf9Fyuv/Cesv8ACj/hBfix/wBFyuv/AAnrL/CvUaKAPLf+EE+K+Mf8Lyuv/Cesv8KX/hBfiv8A9Fyuv/Cesv8ACvUaKAPLH8DfFgIf+L5XB/3vDtmR+PA/nXPWn7QnhfQ4pdE8dXjWviTT55rS9SxtpHgLxyMoZDj7rKA2DyN2DyK9zb7p7V+c/wAVP+SxeLv+wpcf+jDQB9ufC3/kD+JP+xm1b/0rkrva8q+E/iTRLi48W+H4tSgbVrXxJqkktluxKqG6chtp5K/MORkZ4616orblDetAC0UUUAFFFFABRRSMwUZNACk461ka54k0Pw1pcmp69qttplnHwZrmQIpbBIUZ+8xAOFHJ7CuY8XeP/wCzNQTw34X09vEfiuZC0emQSKggUAZluHPESDIxu5YsoAOcil4e+HF9Nq6+JfiPqVv4n1tW3WsIgxZaWM79tvG2csG/5at85CoOMHIAWXxX/taL7VofgHxdqlgx/c3kVjFDHOuAQyefLGzKQc52j86ms/i1oY1VtO8S6Xq/hCZnEcL67bCCCdiNwVJ1Zoicdt2SQRjIr0QKo6DFZ2taFpHiLRrrR9c0+HUNPul2TW8y7lYZBH0IIBBHIIBGCBQBoI4foc44P1p1edfDCQ6Vb614Fnvnu5vDN6LSF55A0z2kkaywM4HTAdowcAHyjjuB6LQAUUUUAFFFFACN901+c/xU/wCSxeLv+wpcf+jDX6MN901+c/xU/wCSxeLv+wpcf+jDQB9XeHvAGgeM9E1yXUYJLfUbTxNqxtNTs38m7tG+1ycpIOe5+U5B7irh8UeNfh3Klr48t5Ne8PpuK+JNNgJeBFXJN5Ao+QABj5iZXgZGTXRfC3/kD+JP+xm1b/0rkrujGjZyoIPUY60AU9N1jTNXso7zSdQtr+0lB8ue2lWRHwSpwykg4II69RV4EHoQa8v1H4X3ml6nJrfw010+Ebt2WSbTI4VfS7sqFB3wceWzBEQyRkMFzgZJNC+NfH3h5Yk8W/Dy41CNAqvfeGbgXiyMVJZhA+2VVHYYY+5IG4A9Rorg9D+Lvw/1+4a0tfEMFtfJtDWV/wD6JcBiu7Ajl2s3HOVBHvXS614i0nw/ol1rGsX0VhYWyFpbiZsKnOB9SSQABkkkADJFAGqzqilmPAryS48aa58RNWvfDvw2d7bTbdxHe+KmUPDHwCY7UdJpP9r7qg55yuazWPin4uXytqZvPDvw+Kun2Hc0N5riEYJmxhoYWGRsyGYFs8MpX1yxs7PT7GGzs7eC2ghQRxxQRiNEUcBVUcAD0FAHP+DPAui+B9Oms9KSWaW5kM13fXT+bc3kpJJklkPLMcn0AycAZrqqTI9aWgAqs17ai6S0aZBcSKzJEWAZlXbuIGckDcufTcPWqfiHWtL8O+H7vWtZvlstPtE8yaZsnaPQAckk4AAySSAAScV574C8P6l4h19vif4ysYY9VuY9uj2TLk6Rasp4/wCu0gOXbG4A7cgZWgC3Zo+l/tD6nbrZmODXPD8F29wd+JJba4eMqCfl4S4jyByPlPevTK878XLd2vxc+HmoxzFbWZ7/AEyZAxBbzYRMvbBGbXofUHtXolABRRRQAUUUUAI33TX5z/FT/ksXi7/sKXH/AKMNfow33TX5z/FT/ksXi7/sKXH/AKMNAH1D4N8eXnhW58Vx614U1P8AsBfEOqPHrFiBdouLiZpDLCn72NVwBv2sDnkqK9b8P+LfD3irS49T8P6tbajaPgb4JAxViobay/eRsMCVYBhnkCud+F6q+jeJAwyP+Em1b/0rkqTxL8KfB/iS7/tL7A2j60GZ01fR5DZ3as33m8xMbyeR84bqe5oA7oEMKb5cec7RXmraP8XdDn8vTPFGi+JLHd8o1uF7W5C84Uy24KsR8vPl889OtJF4w+JGmlDrXwsmuIwimSXR9VguM9jhJPLbPQ45GD97igDt9c8N6D4jsRZa5otlqduOkd3AsoX3G4HB9xg15tqvwD8LzSWc2g6hqmivYytcWtuLgXlnHMVCiT7PcB04A427f0GNP/hdXha1tvtPiHTfEPhmIbMtq+jXESjcdvLKrKADgZJxzwTW/o/xK8B6+kJ0jxdpN08ziNIRdospYtgL5bEMCT0BHPGM0Acw83xm8MrO0ljoPje2ijAj+zyHS7uZiepDb4RtG4nlcjGDkYPK6VqMnjrxzrN83jXxl4Wu7HUf7MttLgEZtodkMZfziqSwlmlEuGaQ5+VR1C17ysisDvAHO3rmvl/TLDUrjxF4wnW1vDayeJNQkRPtotrd1SeJWY46kGNvfIDD7nAB6lY2Xxm0sWiweJvDni22LZnfUbSTTZyvy8IYjInPzHlOO+c4WtpXxg1IBIvEHw5122nN41rM2jSQazDaldm4ym3cvGRuyUKbsAkA8geevcaboVpNZWsek2Mdoqv5fmG6mjEauqDjduIZDhtvLtkZVmFdV4E06x1qLW5/EkepTzw6h5cH2F7+KKS1a2ilhBjQhF+SbBTaAOc5+8QBmleMvD/xh+IMaQavA3hvQ5BLZ2EhRJdWuwhJmaJ28wRRAjauwZc5JO3Fe6oo2htuDivjvwrBfz+G/D8Ut7PHfvZzahaT3hKSwzTje16WyxKK2wkkhWRDnG56+ovAniaPxh4B0PxJGsSG/tEmkSJtyRyYxIgP+y4YevHPOaAMH4pQ3wt/Cep6eWWTT/ElhI7LswI5ZDbOCG4OVnK8cgkHIxXoSnPbFee/Gizu7z4OeI/sMvk3VnbrqEcnmNGV+zyLOSrLyGxGce+OnWu9tnikgWSF1kjf5lZTlWB7igCaiiigAooooARvumvzn+Kn/JYvF3/YUuP/AEYa/Rhvumvzn+Kn/JYvF3/YUuP/AEYaAPtz4W/8gfxJ/wBjNq3/AKVyV3tcF8Lf+QP4k/7GbVv/AErkrvaAAgHrSFQe1LRQAmK5/VvBfhTXpVm1zwzpOpyqCFku7KOVlBOTgsCR+GOa6GigDzJvgn4DsTe3Ph+21Pw1eXcbxtc6NqtzamLcc5VFfYMHkLt28cqRxXmXhr/hAPC+lv4d+Jkmqadrct1eQi51qOUx3W6aSQTxTkGIMVYZbIO7fj77b/prGetRTQRzwPDJGrxuCrKwyGB6gjvQB8+Ktnp91byaPr8esxTuJIrnwjpVugUtK8YTczujKvmMAOdq7wxyyFeVt/it468P3Fn4J8AvovidLG3EcckumPbbY0AC8/asFVUBNzBeijLE5PqHxO+HfwrsvB2seJtZ8H6ejWNo8u+1b7GzuAdihkKgszFVGc5JAweleJt4Daz0TT/DOl+Ntctde1loBMrQPLHNdhdt4iyLEGAiPkhiX+XbIrYIbYAXvA8e7Vlh8YeVcR+C7V7fVY7F5Hjnt4IA8LPtGx4hsP7sqG3KN+4uFX6H+Emkf2N8IPC1uyyLNJYRXU/mks5mlHmyFiSTku7E+57DgeL3Pwv8UfDr4ezabf8AjDSz4a1HWLU65cpbG2upbaaeOKRGnLY8v5snIzhn5wSK+n4/9WvrQBj+LNJ/t3wXreiibyP7QsZ7XzQu4pvjZd2MjOM5xkfh1rP+G97JqXwq8K38pUyXGlWsj7Om4xLkD8a6h+VxjNef/Bk3Efwi0iyu2YyWEl1p6702NsguZYUyPXbGM++aAPQqKKKACiiigBG+6fpX5z/FT/ksXi7/ALClx/6MNfow33TX5z/FT/ksXi7/ALClx/6MNAH258Lf+QP4k/7GbVv/AErkrva4L4W/8gfxJ/2M2rf+lcld7QAUUUUAFFFFACFlBwTVDVNX0/RtLn1TUryGzsoF3SzzuESNfUk8DniqPijw3J4m0yOxi8RavoLJKJftGkzLFK2ARtJZWG35s4x1A5rm7H4P+D4L231HVo73xNqFvGI0utevHvSvOchHOwHPPCjHbFAHlHxF1zWfixJoGg+F7eSx0PVLtntLrUVmtYNUeBfOw5VS/lFRlAVG9lZsr5QD9b4fk+I/hXSjDpXwX09pdi+dIniKBJLkou1c4gA4ACqnCIuFUKqqB0fxkja0+G8uvW9iby70C7t9WgXazBDFMpdiF52+UZQx/uk16NHuK/NjI9KAPHfiFqni3xJ8Otb0Ob4T64hu7YpE8d7aSFJcgxNiOYuQrhW4HbnjNa9v8VruNbVdT+F/jay8wASSLpqzoj7cniKRnIyCAdvpnFenUYHpQB5zN8X/AAxbSJHqmm+JNKWQEo95oF4itjGQMRk9xXG+Afi74M0uPXtK8Q+IF0vZrN7daeL63mt3mtZ5mlV/nUZ+d5R6gAZHc+74HoKbsG/cO/WgDibP4t/DS7Vmj8eaGihiMz30cJP4OQa2bPxr4Rvrdbi18U6PcQN92SK+idW5weQ2OCDWjcaLpN3cG4u9MtLiUjG+WFXbH1IrEm+G/wAPbmaSe68C+HriaQ7nll0uBmY+pJTJoA6O3vLW8tVurS4jngcZWSNwysPYjg1KJFIBDA5ry3xJ8Ofg54W8L6jr+qeBdJFpYwNM4S3QMwHRV3EDcTgKMjJIFSWPwL+FavHfP4NSSUxCMR391NdCNeDtw8jrx7e+KAPTmYY61+dHxUwfjD4uOR/yFLjqQP8Aloa+2Lj4K/Cm4t5IZPAmlBJFKsY4djYIxwy4IPuCDXwv4+0bT9E+JPiPSNOtxFZ2eoTQwozFyqK5AG5ssePUk0Afdnwt/wCQP4k/7GbVv/SuSu9rxyOX4neBdU1PT/Dnw+g8W6XqF7Nqkd0NXisXiadjJJGySKSSJC+CONpTnIarI8c/Gjcc/AlAOx/4Si1/+JoA9aoryQeOfjRnn4EIP+5otf8A4mgeOfjT3+BKD/uaLX/4mgD1uivJR45+NGTn4EoPT/iqLX/4mkXx18acHd8CEB7D/hKLXn/x2gD1uivJB45+NOzn4Epu9P8AhKLX/wCJpf8AhOvjRjn4EL9B4otf/iaANv4xXlzb/CbXLSyhWe81WEaTbwlsGSS5dYAF9T+8Jx7V3kZYr8wxXzx4iuvjb4m8W+HtT1D4NRHR9Ela7XTP7ftGM9ztKxyNKRwEByoCg7ucnjHXr46+NJ6/Ahf/AAqLX/4mgD1uivJP+E5+NX/RCU/8Ke1/+Jo/4Tn41f8ARCU/8Ke1/wDiaAPW6K8lPjn409vgSn/hUWv/AMTR/wAJz8av+iEp/wCFRa//ABNAHrVFeSf8Jz8auM/AlP8Awp7X/wCJo/4Tn41f9EJT/wAKe1/+JoA6X4pWNtqfgP8As28j8y1vNU0y1nTcV3xyahbo4yCCMqSMgg12kY2oBnNeFeKPEPxw1/QhYWvwThs50u7W8jml8RW0yhoLiOcAqNpIPl4+8Otbg8cfGnH/ACQlP/Cotf8A4mgD1puVNfnP8VMH4w+Lv+wpcf8AoZr69bxz8aMc/AqNR3z4otsf+gVyC/s46Z4kluPEPja+1e28QalcTXd3BpNzb/ZoS8jMqJ5kW47VKgk55B5IoA+i6KKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/Z\" alt=\"New leaflet pictures 121113_Page_1_Page_5\" width=\"156\" height=\"113\"/></p><p><span>5. Para ponerse el enema, recuéstese sobre su lado izquierdo con la pierna izquierda estirada y la derecha flexionada hacia delante. Inserte</span><span>con cuidado</span><span>el extremo del aplicador en el recto. Mantener una presión suficiente y constant</span><span>e</span><span>mientras se dispersa el contenido del envase. El contenido del envase debe aplicarse durante un máximo de 30-40 seg</span><span>undos.</span></p></td><td><p><span>6. Una vez que el envase se ha vaciado, extraer el aplicador con el envase aún presionado.</span></p></td><td><p><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCABzALgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD1f4S6RqXxF8If8LE8WeKNbluddmlkjsLDU7mytrFI5WiWONYZFz9zOWJzkd9zN6N/wr3Q/wDoKeJv/Cl1H/4/XKfs4f8AJu3hf63f/pXNXrNAHI/8K90P/oKeJv8AwpdR/wDj9H/CvdD/AOgp4m/8KXUf/j9ddRQByP8Awr3Q/wDoKeJv/Cl1H/4/R/wr3Q/+gp4m/wDCl1H/AOP111FAHI/8K90P/oKeJv8AwpdR/wDj9H/CvdD/AOgp4m/8KXUf/j9ddRQByP8Awr3Q/wDoKeJv/Cl1H/4/R/wr3Q/+gp4m/wDCl1H/AOP111FAHI/8K90P/oKeJv8AwpdR/wDj9H/CvdD/AOgp4m/8KXUf/j9ddRQByP8Awr3Q/wDoKeJv/Cl1H/4/R/wr3Q/+gp4m/wDCl1H/AOP111c1428Vaf4N8L3WuagzMIVxDbx5L3Mp4SJQATuZiB0IHU8AmgDH1Lwr4R0fT5dR1XxBr9jZxYMlxc+Kr+ONMnAyzXAA5I6+tedzeMvhtKC3hxfiR4sjR3SaXQ9Q1WeOErgkM7TKp4YH5SePqM0PEHw08aeNvCH/AAl/iq+S88U2xiv9O8PMg+xWyoxf7LIjf613XKM7d+MlRk+5WJm1Lw3bPNYvps1zbqz2r43WzMmSh28ZUkg49D2oA8WsfHXw5nsRqerWfxP0DSWgE6alqN9qn2aRTt27XjnfO4OCD93HfkZ9D0nQfA+vWf23Q/FGt6na7tnnWniu+lQNjJUlZyAQCCR2zz2rE+GvxI+HFx4Y8O+ENI8ZWd7e2FjBZIZYpLXz2ijRPkWVVznBIAJPXrg45nQ/hf4tNrqnxB03UD4U8bardyXq6cir9jWLpHbXCKAJDgEmUAMGcnBIyQD1YfD7Qz/zE/E3/hS6h/8AH6X/AIV7of8A0FPE3/hS6j/8fqt8PfG0fi/RZGurc2Gt2ErWup6Y0m97OZTgj/aU43KwyCD1zkCLxT4m1TQPEcNjGq3NveadPcRKsbF4547i2iXcQ2DGftQLcAgRk5OcAAvf8K90P/oKeJv/AApdR/8Aj9H/AAr3Q/8AoKeJv/Cl1H/4/U3hjUtW1hXuLuOKK3h8y1bAZXluIp5YZGCknbGfLVl5JIfnGOeooA8eW01HwN8dPD9jaa/quo6H4thuIH0/UryS7+xzW8RlEsbylnwwLKVz1OckBVUrQ8bf8l0+E/8A131X/wBIjRQBX/Zw/wCTdvC/1u//AErmr1mvJv2cP+TdvC/1u/8A0rmr1mgAooooAKKKKACiiigAooooAKKKKAA9DXiPivQI/in8XR4XutUvrTSvCNkl7JLpt55UseoTn9wSCDykaM6t1BcdASG9uPSvnmxPxCb9oH4nr4Gn8NIitpZuv7ZjnZiTa4TYImGBw4JI54x3oA9f8I6N4j0fSH07xJ4gXX3hlP2e8aAQyvDgECUA4ZwSy7hjICk8k10vlrjGBVLSV1RdLtv7Zktnv/KXzzahhF5mBu2biW25zjJzjFXJN2PloA/KFeRjn9a+zPghH8XNY+GF7omp3dzoUGUOlaxfQedOIWHzKkbspwBgo7ZA3EDcAAvc/Dj4B+CvAEUV09omt60jFhqN5Hkx8/KI0JKoQAPmHzZzzg4Hqk0MnksLYqkmOCRkA9uO/wCYoA8Rj8NJ8J/iX4Z1a31q9vrXxNI+kaxcX80k8t3dbTJbS4Hyhsq0Y6BVPT7zD2e50rTdQAe9sLe5ZoHtyZolcmKTb5iHI+62xdy9DtGegrw/4mab4ztNR+Hcmu+KdM1O1/4TDT8R2+lG0ZWHmEsXM0gIwCMYHJHPHPvkX+rGCCMDkdDQBFaWdrY2sVpZ28VvbQqEihiQIkajgAAcAYqxRRQB5d43/wCS6fCb/rvqv/pEaKPG/wDyXT4Tf9d9V/8ASI0UAV/2cP8Ak3bwv9bv/wBK5q9Zryb9nD/k3bwv9bv/ANK5q9ZoAKKKKACiiigAooooAKKKKACiiigA7V4b8StevPhb8SrHx/8AY21DS9asP7Emthdx2qR3aSGS3ldnYLhg0iFsfIoY852n3KsjxFoWm+JfD95oOsWaXmn3kZjmifPPcEEcgggEEcgjjmgDK8HX/i680ua88Z2em6bdTzb7eysJWm+zwlV2pLIfleTOQSmFOAR1OOojmjl5Q5GBzivnbxT4j+Ifwv8ABWpeGr7fqti4+y6T4sLlns0chQbxVBYNGrORKoO4quQSWr1nwnqWkL4Gto9B8TR+IksbURtffavtDysqn5pGyTuJByM5ySOKAOyZ1QZY4FYniKXXZPD9yPCctimsEL9mOoq5gzuGd4TDdM9Oh65HByNH8X29x8ONB8UeINRsdNbUNPt7qYzSCGFXkhEjAb26fe4ycAexrxjwXr/jjVNEu/h38One+0m2vJLez8Y3AcxWlhkbVG8KZpkyUAUBRhcfKNwAOi0HWPEXxJ+LOnWet6NHpMfgcNcaigeO5imvpVZIvLbqFWImQE/MrHawBUMfd0BVQCc1zfg7wfpPgnw9HoejxP5IZppriZt811M2N8srfxO2OT7ADgAV01ABRRRQB5f43/5Lp8Jv+u+qf+kRopPG/wDyXT4Tf9d9V/8ASI0UAV/2cP8Ak3bwv9bv/wBK5q9Zryb9nD/k3bwv9bv/ANK5q9ZoAKKKKACiiigAoprOqnBzR5ig4PFADqKO1FABRRRQAUdRRRQBE0EbKVKAqRtwemK4bVvg58M9auJLi+8G6eJpX8xpbZTbSFs53boipyTyTnnvXfUUAed6f8EfhXprh4PBVhOwbO6933bfdC4zKWOAAAB0GOK7+G2gt41jghSNEG1VQYCj0A7CpaKACiiigAooooA8u8b/APJdPhN/131X/wBIjRR42/5Lp8J/+u+q/wDpEaKAK/7OH/Ju3hf63f8A6VzV6nLcwwo7yvsVBlmI4A715Z+zh/ybt4X+t3/6VzV4f+1T8QL648Sp8PdPuTFp9tEk2oojj/SJWG5I3HXaq7Wx3LAkfKpoA9vvP2h/hDa31zZv4xDSQswzBZzypJjrsdUKsOOCDg8EEjmu18J+OvCfjbT2vvDGuQalGhxIqZWSLkgb42AZMlWxuAyASMjmvzEwB0z9e/FaWh69rXhnWodY0HUrjT7+BsrNC+C3P3WHRlPdWBB6EEUAfqarBhlelNkO2MsN2QCfl6mvDPgT8a5/iR9u0XXIre21mwjEwMOQtxDwpbBzgqSu7n+MYHWu6+Jni698M+FvL0CM3niXVH+xaPZJjdNcOMBuQVCoDvJbC/KASNwoAwdS1rxX468fzeGvBuujQ9D0GZF1jWIIknkuLjq1pBuUopUffY5KsVBHBDX7rwT8RodagutE+Ll2tmgTzLbVdItbrzSGJPzRiEhSMDAwep3dh0HgPwfaeC/BWneHoG85rVS0s5yDPMx3ySHJJ+ZyxwScdO1dXjjmgDzB7z44aRb3082h+F/FESEfZorG8l064cbsZIlSSPODuxuGMEZbioj8UPEGnGxtfE/wt8V6deXB/evpkEeq28C78bmkhbdjHONm7g4BwCe78Sf8JGdBuR4TFgdYO3yBqRcW33hu37Pm+7uxjvjtXB3Pjnx5oty3/CUfCnUJ7SNV/wBL8P3ceoeax2cCEiOQDk54P3e680AaWk/Gj4Y6pPd26eM7O1ltZPKkTU91k2/cylQJlTccqQQuSDjOMiu6tNQs7+0gvLG5jura4QSwzQuHSVCMhlYcEEEHPTkV5nF8UPhF4oRtC8QahZQTOqPNpniO0NuVb5WVCs6hWYFlIAJ9RwM1Nc/CH4Y6s9trWi6THpk/kg2l/oV49psUglZI/KYITzw2D26jigD0xJEkHyHI9afXlXgLXdb0fxLe/DjxjqDXup2Uf2nTdSkXDanZZwGbk/vUOVbOCRtbn5mr0m71PT9OtGu9RvoLS3TAaaaQIi5OBkngckD6mgC5RXnc3xw+E8GrjSn8cac1xuRN0bM8OWxj96oMeOeTuwOckYNdlpmvaJrVobzR9Ws9Stg23zrSdZUzgHGVJHQg/Qj1oA0qKYsiuSqnkdR6U+gAooooAKKKKAPLvG3/ACXT4T/9d9V/9IjRR43/AOS6fCf/AK76r/6RGigCr+ziyr+zx4YUnn/SuP8At7mr5o/ag0G60z41XGsSRP8AZtZtop45CeC0aLEyjpyNinHP3h68ev8AwN+HsmsfBvw7rlv448WaRLN9qUwWGpAW4AuJF+WKRHVfu5yADkse5rZ8ZfArxF4z02PS9S+Jl1eWcEjSwHUNJgmlhyeAJUKPnHB5wcDjgYAPhqkr3rWv2U/iTp1uZtLuNJ1jt5UVwYpfuns6heoA+91PpzXnnh74V+NPEXjCTwnHYR6bqsQDSQ6lMtuyoTjeFb53UdcoG4+ooA6P4BeDdb8WfEOefRNen0CbTLN7hL6GISbZCQqIVbhlOSSp4IVhX134b8A+IIvHi+MfGviKHX7+ztfsWnRQWgggtUbHmThSzETSYwxUgYLLyNoXyzwZ4a8T/s8aNearq0Wjavol/d2yX91azSR3NqrN5asFZMSIGkB2jDZY9QSV+mo2Pl5c9OtAC70U7c4NRz3VvbwSTTTLHHGpdnY4VQBkknsK5nXbTwd4xvJfC+rXq3NzYFLySztr+S3mhyCFZvKdWwQx4Jwcg46ViSfBP4b3MLxS6TfyxuNrJJrN6ysPQgzYNAHV+GfFmheLrG5vvD+orqFpb3UloZ40YRs6Y3bGIAdeR8y5U84JxW2yKxyRVew0+x0uxisdOs4LK1hXbHBbxiOONfRVAAA+lWqAKF9o+l6nA0Gpafb3sLI0bR3ESyKyt95SGBBB7iuGvvgz4JaZ7rQ7W88L3rqY/tOgXkliwByfuoQnUg8qfugdBivSKKAPCPEPwZ8cX93o91p3xNmuX0W6F1ZPq9hFNcQNli379ArOrZUFGBBCjpgCvPfG2hv4c+OXhTxP8YvE2ma1p+oC9LwPZsbWzjhh/doqEsWBeQYXB5GSWLV9cdBXkVtcx+I/2htVu/MtrjSfCelR2TpMoIivJ5VmLqxU8iOFMncNpwMZJwAcn4t+I1xD8KNefw38KNT0/wAOixaJLu+WCwijLAxxskBO51HyEYHOAOBg1g/8I54X0PS9MtfF3wp8T+Eruyt4bZfEWgyLIyEIqmaR7Vj82VByUbknjJwfQPih4q8N63baH4O0bxDYale6j4isLS7s7O5jnuIYknEkhKqSybTGCSRgY5r2FfLcFcgkc4oA+ddU8T+JND+Gl/42+H/xej8X6ZpWyQ2F9YxzzkNKNyyyqUdcA5+ZAwAPIyNvo7L8aJbMzWeteCZXaPdGG067UMcZGT5xIB+h+lcP428H+D/EmhfFPxBfeH7L+1tDN1FaXlsGhkJXTo5cyFCBId8sgO7IIABBxXY6T8L7mHTIEh+JvjeKNkDhDqEMuzODgNJCzY+pNAGRrvxF+KPgpdMj8S+B9G1NtU1OLTbWXS9XMQeSQEqu2aMf3WGSVGcDjrWvcfEHx9btGbj4Q6iqn5ysWrWcshQEBiqB8tjI6etcf8YfCus+E/hfe+JrHx/4o1G70q5tLqGG9kt5Yg63MWHZRCM7c7uuOBnjNZPxF8KeN7fxN8Pb7xR4yGrWserJpS3emxPpV6sl1iN2DIzAKBGG4xncy4wQQAeiz/GOw01g/iTwl4q8PWOMtqF9poa3T0DPC8m305A6132j67pOuaVFqWkanb6jaSDKzW0gkUnuMr356dq8v0TWtS+H/ioeB/HGsS6jpF8A2i63fn55CTg2lw5+9KMgqcfOM5IPyjl/A/wr8PXGtePbCPUdT0TW7TWpQLjRNRltJhaSxrLAGCnaVHmNj5Tnb6cUAd142ZT8dfhMAefO1U4/7czRXMXvg628K/Hf4XyQ+INe1ZrmTUgRq2pSXYQLZt9zeeOvP4UUAdB+zh/ybt4Y+t3/AOlc1es15J+zm6x/AXRNPkbZeWM15b3Vu3ElvILqVijr1VsMpwcHBHrXreRQA1kVl2sMiuP+IHge08ZaAFjkaz1ywJuNK1KI7ZbO46ghsfdJADL0I9wCOyzTJPmTHUHr9KAPn7/hKr7x1YfDfQZruGDWm8R7NYiYbTv09WmlAQrkBnWJh0xuVTjNfQKpiMKWLcdTjmvA/DPhiWP9rvxTqE/myafZ2K31rHudo7e4uEijd/RWcQvx3AH9zj3HVdQ/s3Rb3UEt57xrWCScW9pH5s021SdiLn5mOMAdyQKAOL8feAZvEE1r4g8OXq6N4t0xSbHUQvysM5aCYfxxN3BBKnJHUq1n4YeMbrxl4Unn1Ow+wazpV5JpeqW6kFEu4gvmbCCcqS2Ryfqepz9O+Nfw61G9XTrnxDHomoLGsk1prUT2EsRKg7T5oVd3zDgE55IyBmt3wToPh7Q7TV7zw7qbaha69qU+syTGZJU82XG7yygA2fLx1PXmgDrKKbvTONwz060b0/vD86AHUU3zE/vj86PMT+8PXrQBV1K6ay065u1UP5MTybT3wM4rwf4T/B/wjr3gXS/FniuWXxVqGryrrE4mu2a0W5bJZvKXahbkK4YMMqR04r6Ak2Ou3eM+x5ry34Fyra+Ab/wthiPC2tX2jCV3DGURzF1Y4UAHbIo6DJXPfAAMD4y/DzwTbeEdEng8H6bBZ22uWK3hs7dLeT7NJKIpFDJtb5tyjAI5IPbIpa14o8WfBq8tNJGoHx3Zaruh0yzuJs6sk21iinA/fQ7lVS+Aw398BT654w8HaD420n+zPEFvc3dkOTbxXc0CSHII3iN134KqQGzgjiuB+AfhPQdN+G9trEem2za1dz3cN3qOwtPceXdPHy7FmAPlKxUHbuyQM80AeX+M0+Inw1+EHim11bS7S6s/FLtc3GoaWXMtpdzsjTx3CSOy+Wyl4VkjOMqCcM/H1dbxrDAkCkkRqFGeuAK8w+OcKar4G0vwjJZzXKeJdbsdNkaE/NAnmea0mMHO1YWPPA+9zjBj/s348aPbW1lpPiDwf4gRVIe91azuLWZyWOPlhdkIAx02/Q9SAb3xevLO1+C/jB7q4jhVtLnjUyNtBdl2Koz3LMqgdSSAOTXI/E7xBoniDXfA/hvQdY07UdWt/F9nNPaW93G0kCwmRpS6bsjaEbPHXjqRnkPjVoPiaTw/a2vjb4mqmma1q9pZxWlhp6Wdtakt88srNK0kkaorvtZ8b9noAI/DfhLw18Y7jXta8PtFoPhnRbkWvh6TRrcWUkd7siea9dEA3E4hCcj5R91WG6gD6H1PQdF8QaVJp+taZb6jZzYLwXMYdM9jg9COx7dq8Y8J/CXwjpvxU8a6La291baYkGnXdrbWWo3VqIN6TI6kxygvlod2TyN5AGBk9HZ+MviV4V0wWfjXwJd6/JaRIp1bw0Y7gXjE7dxtiUkQjgsFBGckBV6cP4R+I2n6f8QPiZ4tuPCniiM381hHBZLo8zXBaG2VHVwoKRkF92GYEqQRnigDo9Y8I6L4Z+PHwtk0n7eGnl1NX+1alc3Y4s2IwJpG29e2M9+goqlL4zbxl8evhxHH4W1/RmsDqU8i6tZi3by2tigfZuLBdxVdzAKScAk5AKANHx58KvAN7qp1qbQdl9qDGa5kgupoRK+BliqOFyepIHJJJySTXH/8Kp8Cf9Am4/8ABhc//HKKKAF/4VT4E/6BM/8A4MLn/wCOUf8ACqfAmP8AkET/APgwuf8A45RRQA0fCXwDuZv7Fm3MAGP2+5yQOn/LT3P50v8AwqjwHnP9jzev/IQuf/jlFFAEUnwh+HszfvtCkkx8w3X1weT/ANtKIvhD8PYSfJ0GSLd12X1wufykoooAk/4VT4EJz/ZE/wD4MLn/AOOUf8Ko8Cf9Aef/AMGFz/8AHKKKAD/hVPgP/oDzf+DC5/8AjlH/AAqnwJ/0B5//AAYXP/xyiigBR8KPAnH/ABJ5/wDwYXP/AMcqGL4T+AirMdGlyXLE/b7jk9M/6z0A/KiigCX/AIVR4EHTSJ+P+ohc/wDxymp8JfAMQ2x6LKgB4xf3P1/56UUUAL/wqfwEWDHRpiw6H7fc5Hb/AJ6Uf8Kn8BKMLo0wH/X/AHP/AMcoooAbJ8I/h/MNs2hySBTkBr64OD6/6ymx/B/4eQDEOgvGM5wt9cD/ANqUUUASn4UeA+T/AGRPn1/tC578f89KSH4SfD+EHydElj3Eudt/cjLHqf8AWdaKKAPVfhr8P/B/hjTl1XRNFjttQut6zXTSPLK672G3e7E7flU7c4yAcZGaKKKAP//Z\" alt=\"New leaflet pictures 121113_Page_1_Page_6\" width=\"185\" height=\"115\"/></p><p><span>7. El enema debe retenerse en el intestino. Permanecer relajado en la misma posición durante 5-10 minutos o hasta que la urgencia de defecar haya desaparecido.</span></p></td><td><p><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCAC1AHMDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3f4o/E+bwTb2GjaDpo1jxXqz+XY2KgsBzy8gU5C5yB6kNyQrEc7Y6Z+0xcWscreJPCVo7DJhlhZmQdgSqEH8Cak8SW9vN+2D4MjkjRwmhTOm5QdrBpcEZ6H/Cvb1QKxIUDPpQB4t/Yv7TH/Q3eDv/AAHk/wDjVH9i/tMf9Dd4O/8AAeT/AONV7ZRQB4n/AGL+0x/0N/g//wAB5P8A43R/Yv7TH/Q3eDv/AAHk/wDjVe2UUAeJ/wBi/tMf9Df4O/8AAeT/AONUf2L+0x/0N3g7/wAB5P8A41XtlFAHif8AYv7TH/Q3eDh/27yf/GqP7F/aY/6G/wAH/wDgPJ/8ar2yigDxP+xf2mP+hu8Hf+A8n/xql/sX9pj/AKG/wf8A+A8n/wAbr2uigDxF9G/aYA/5G7wcR/17yZH/AJCrD1vxn8cPhnCfEfjax0PxJ4eh2pcPp8nkPCXbauGKg/eKA/IRzjjqPokjIxWJ4rsbfUPB2safdKWt7mymhkUNtJVkIOD24JoAt6LqtrrmgWGs2MnmWt7Ck8TEYJRhkZ98GivPP2eppp/2ffC7zyvKypcRguxJCrcyqo57AAADsABRQBja9n/hsXwd/wBgCf8AnLXtteJa9/yeL4O4x/xT8/8AOWvbaACiiigAooooAKKKKACiiigAooooAKz9awdB1DP/AD7Sf+gmtCqGs/8AIC1D/r2k/wDQTQB5t+zr/wAm9eGf+3r/ANK5qKP2dP8Ak3rwz/29f+lc1FAGVr//ACeL4O7/APFPz/zlr22vEtf/AOTxfB3f/iQT8/8AApa9toAKKKKACiiigAooooAKKKKACiiigAqhrP8AyAtQ/wCvaT/0E1dLqB1B/GsXVdU06a01bTYb+3kvre1dprZJVMkYKEgsucjI9aAOD/Z1/wCTevDP/b1/6VzUUfs6/wDJvfhn/t6/9K5qKAMrX/8Ak8Xwdj/oAT/zlr22vEte/wCTxfB3X/kAT9frLXttABRRRQAUUUUAFFFFABRTJCRGSoJPtXl3ir416H4b8Xp4RsNF1bxNrW0vNa6PD5zwDAOGGRzg546DGetAHqZYAgc81wXjn4teCfAEUia5rCG+CkrYW4ElwxwCBtz8ucjBYgHPWvAPiH8WviFqkVwl5J/wrbRypMdvOD/a1zG2V3CLh1+42PuLk43k4NYPgn4N+MPGN7HfWOnz+F9KlYXH9uanma/uGzvEqLuXbucBgV2kAj536kAf46/aB+IXia4Gk+F7Z/D1vdyCKC3t236hMGyoBIyVY4OAoVhuGCeGPVfBr4S+L9EvdT8d+JFbTRNp08IsZpGaeVmQbpJN2cZxnGc5PYAA+2+AvhF4K+HibtC053vSpR766O+ZgcEjOAFGVBwoAzXYauiroWoeptpP/QTQB5x+zoMfs8+GB/19f+lUtFH7Ov8Ayb14Z/7ev/SuaigDK1//AJPF8HZP/MAn6dOste214lr3/J4vg7t/xIJ+B9Za9toAKKKKACiiigAopNwzjPNRtKoBBOPegDB8b+KrDwZ4J1TxHqGGisoS6xs23zX6ImfdiBXyV4I0Cz1q5i1Sz+Jdz4d+KmuTS3T24UrDPHKTJtO1BsZhhwNx4xheRjsf2lPHcLappfgJRFNaQMuo6rG8rReaq5KQ7tyjBxk9TkoV5GD4z4HvrqEeL/ihqLGS9063MNq6gRML66JSNwoXAVFEjYXG0qgAx0APbfgtpF345+JviP4geLpLDWpdJmTTbO9t4kMVxNGeZ0wcDCKhBA58zIxivp3arbW2471598GvBw8G/CXRdKmjdbqaIXdysybXWST5irAjIK5C888V6IOBigAqhrP/ACAtQ/69pP8A0E1fqhrP/IC1D/r2k/8AQTQB5t+zr/yb14Z/7ev/AErmoo/Z1/5N68M/9vX/AKVzUUAZWvD/AIzE8HYz/wAgCfr16y17bXiWv/8AJ4vg7/sAT/zlr20kAZPAoAKKTI9aNw9aABm2qWrJ1rxFo/hzSZdW13UYdNsYiA09w4VQT0A9SfQZNedfEX4xWvha+tfDnhvTf+El8U3pZItPtZMmEjPzPtyeCPu8E4OSBzXmviDwL47vLK2+IHxG1/drKzrHZ6bbnbb6dG6s2GIGVkBJQMgZgdh3rgPGAdPffHXXfEOvz6H8MvAd7q1zE3lfatRP2SNiUZwQr4xlV3LvKkgHjOM8Fr8vxG17VtUt/GXiuSKNM2n2LRbiS0tYdvDyMPLZpVDKVIIL5O5FZMGpIbq70m8i1CHVJ7Sa2kOPKKQ7Cp3FcABRx/rYt3lkHfmeTBp14DcaldPb6ms6uySM8MkjvCZMOuZJD5m8BwiTEeY3QG3jPIBw3gnwBoXi7xnq3grxpqWpWPiJVWXTtS8+N/tMKhVETAuwLBACoVjgB9xO1a2td8Cax8LT4W0XxtdWeqfD0a59uuJbGyy+9UVR9o3J93lgFDNkb/RQMzxlFeWE1l4j0m/8vV9Cm+1pGVCbI93K7Il2pgqAy5VASQrStIzV9b+FNe0n4ieAdP1uOCGex1O3Uz2kqiZEcjDxNkYODkdMHrQBr6D4i0XxBo0Gq6JqUN9YTLuSWHkdM4I6qfYgEelbQ6V816TpcHgH9q2Lw/4O3JpGt6aby/0+OVRFbvmTBC89NikDqA2BxxX0mv3B24oAWqGs/wDIC1D/AK9pP/QTV+qGs/8AIC1D/r2k/wDQTQB5t+zr/wAm9eGf+3r/ANK5qKP2df8Ak3rwz/29f+lc1FAGVr//ACeL4Ozwf7An4H1lr2iZtqjDYJPH1rxfXv8Ak8Twd1x/YE/85a9qlBKcZH0oA+Lf+GmvGsXxF1K9063TVfDrSs8OnSRYZbeMEllcKGVigLEsCB6HFez+PPi/caZ4E8N3nha1S88Q+LBHFpsG8OsTMFy3QbipcKBwCSCcDr538UPBWg/BfxH4B8aeHFkt7az1WRLtV2mWSJ3MmxRgKcIZkGecFBn5c1nf8JZNJ+0jrurWi2V1PYRjT9Igt4TKUjzuZ4kXO/KmRmAIJWRzujHzgAvSfDe48EiztdRna51rV7VptSuIYebiRndniU5BlQKoDxZVdoLnfkRiTSrzSree4tbq4uP9MRYfPhWS6kWcxP5ARg6Mx2NtRs75I2aPy0TmpvEPiA+JIEvte0+1kdYY2N69uu5oGlYRguMqYy5Ijm27ELFR55LNWf50r5tYbVjIontvIYbFB3bpYjGCTwvzywfeb77mD7tAEMZsbdRPZwRtNCkeXtiWEe1jHFmUDK4wUWQLvjIaKNHAzU4tUuYXaS1me2sGdVga33JAn3ZnECs0ceCwEkWVDiRXkdSNlIs2qy3CTvpsUJmuHMRQsq3HmoShtm2nzHkUDOM+codQFCb2fYeQLy3Os6vYWOnSiIPKZdkAVCUVRIW2iJJcbHwRCwKbXb5qAKrLbnTzYW1iz2qxJshVm8o7gI4sOVGAyfKkxG/b+7RHT5xf+EvjCb4a+LNY8H67cKfDckdzqlrJ82+12N80ZBYleFYFBu/eAAE5JrJl1rT21JbWXxBoKSsWkMy6hFc4EoAfDhlUsxIEh3DzgdxEW3B8k8Wa5aa54nsPs2oeTam1itZ72AsIth5IRSFPloGwFJHCYzxmgD6T/Z81q08b+KPHPji8eQeIbi4SEQszOlnasCY1U8BjlCD04jHC7jn6QB4H9a+PLf4meEvAvx4v9Z8IJJrXhfUNJjjks9Mjk3RvCuAdrlRlFjJzzhWPSvqLwj4ktvFnhLTPEdnDLBb6hGJo0mxvUZxg4yOx70AdFVDWv+QFqA/6dpP/AEE1fqhrP/IC1D/r2k/9BNAHm37Ov/JvXhn/ALev/Suaij9nT/k3rwz/ANvX/pXNRQBla9j/AIbF8Hc5/wCJBPz+Mte214lr/wDyeL4Oz/0AJ/5y17ZuX1oA8z+Onh1fEnwc8Q25wZLS2N9EDu6w5c8D7xKggD1Ir5RS+Mc/hTxgJ/tVrrlgmjXpuplMMV3BiJRNgqFTy1hkAZwRkv0G1vvSXbJuXrlcYIPPXvXxnoXg37VqfxH+C8haGVH/ALU0TzBJtiljPG0Yzh4zGpJJyADg0Aa//EwaSQiZLdmZvuqXmDMmA/UFpm6bdg89P9Ui/fqvqlxLpGkvqGti40zTIHW1ZpLOaMzMAxWOJZYwyrlS6fLJsK5dpNwUefr42m8PrFovirQdWXVLddlzFeSNG5VgHAZB5Z2kkMAcNz8zyJ+7qLTLfXvHE1zp3hnwbeTx6nlZnvpkW1ifarLKrRRQIjDywRuLBj/CxoA958Qal4N+Hnw5sz4g03+3PFWuKJksYY1iuJTIq5R2QsQnIJyWBckgY+VfB9etbG11y5vvHGow6jfPL540jStUy1ixY7oXLQTKxXAQqWDKI8EngDudH/Zz1i6nXU/E/imQ3GV3LZLJJMeNuPNZccKBg4IxgdMZ9Dj/AOFLfDULOsdhol5Fyd0n2qcnIGRndKcEDhTgUAeOaN4b8VeKo45tP+GOg6ZYh5BDqWpW7RybHBILKGVJSFKgMIdvXgE12XhX9nfw3alp/Fesy6hMV4jiUxQqecliCHb+EgfLjGDu7XLr46al4o1D+x/hn4VkvrtopJna9cxKFBXDEF+ACQDllyWA6kCvTtNXVP7MtY9TFuuo+WFnW1JMW/gHZnnBPTPP86ALC+E/C9n4audDsdBt9PtbxGhmS3zEbmNwVdNwCs33uOSRuPPPOd+zVqP2r4MW1m4mW40y+ns5xLkFH3B9oz2AkUfXI7VPruu6J4X0yS98QarbaZEp2+TK48x844VMl26fwqTwTXJfsx61/amp/ECOzuJJNLfUor63SaMI4abzN5IBOOI0HX+H60AfSVUNZ/5AWof9e0n/AKCav1Q1n/kBagf+naT/ANBNAHm37On/ACb14Y/7ev8A0qmoo/Z1/wCTevDP/b1/6VzUUAcP8S77xLpv7THhW78I6JFreqDRJFjtJZxAHXdKGbcxA4B9ag8Uy/GQaZJdeNfip4d8CWDWiySW+nKWuM53Y5UuG6j925yRgA5qX4paPrmu/tJ+GtJ8O+IX8PX9xoM6LfRxeY0aFpdwAJGCR0YEEdjWrpPwW8D6D47022163l8VXupRXdx9s1h2lXzUaPCGP7j7llkY79x/d5HegDw69+I3jLQPFUN14C8beKfFNiu3a+qwu8F0Qx8xVjYklcbBn5XHz4xhTXM+JviDrPif4tWvijUY5PC9y/lW8suk5ScQHHz7iw3uY3xklQQoHQCvsbUUsfBnjn/hIrrR1Xw+2kwWMV1bw7jpzxSysVZQMhJFmjGRkZiwRyK+UtW0CP4vfEHxJfeAbK7j0ixt572NriM4+WPesMaL8qB5t5UZBw5JGRggHt+o/Df4RfDnThretXkF/e43NcazMty8qFeNkRG0/cO3Ck443YwBkP8AGtdSMmn/AA68F6r4jMfCyujRQoQwGVCkEDaejBMcdqT9nz4f/DbxR4ItvEmp2K67r9rLJb3MV+7SR25+bYBEfkYGN1OSGG7oQRx1/wAQPBN5q1rb+HrPxDN4b0qGQyXH2UMvnQHGEJU8AfQjOM9BQB4p448W+KrqCOy8U+OrVLmdV/4kPhi3DTKWjPyzTYXHLBSodwTtIU4zVHwx8CvEPiuVNQ1aIeGdMdmIa8dprmc8ZLKBhed3LBc56MMNXcWGvfCn4ZSy6b4NsrjxJ4mKso/s9XmlmPLENLxtXKjITPG04rfs/Cvxl+JlrOdevbfwFodwfmt7eMvdzjcMjJbKA4f+Jc8DBU8AEKyfCH4K2cnlsZNVA2OA3n3Vx3wTlCoyvIO1QV5GaLO6+L3xItJE8LeH4PBWhSgq2o6oN8+MgERDaWBAL4IAHH3lIr07wX8FfAvgy3RrTSY9R1I7WbUL9RLLuHdM8R5yfugdsk4FeivGdw+XG7OcHpQB8k/FX4V+HfA/wru9f1zULzxL4pvpYoI7y9unBRySz+Wgb5vl3feLdO3OfW/2ePCcvhb4RWElzHtu9WlOoSjqQHChOSB/AoOOepPeuElso/j98bdQ0/VopofCXgtmge33KrXU7SFWyyncFbyuxOFjHQtk/TscarGoVdoAGAOg9qAH1Q1n/kBah/17Sf8AoJq/WfrP/IDv/wDr2k/9BNAHm/7Ov/JvXhn/ALev/Suaij9nX/k3rwz/ANvX/pVNRQBj+Izt/bB8INjOPD85447y1zfxa+PHgG2sRp2kiTX9as5hNa3VpJ5MVlMuQHEvU5BYbVBDDcGIBydTx62lD9p7QzrmwaUPCt59sD52+RibzMgc425ziuU+DOk/D3xV+z3qXhvXp7C3vMyz6iySJFcQpGxZJnJwdiB8gtlRk56mgDbv/hb4i8Ww3Pij42+KvsthZxSXC6Lpjlba1jRCTIzcjcNz5wCcY+b+Ecj+y5440vRbHxD4b1rUILG3EialFLOVjTJ2xSbmJ9RFge59s0fBnh/xZ8TNZ1T4b/8ACxrvUPA+gOgmvYYhm8jJAjjXJJx+7crkuowTg5Fey+LP2fPA/i06U0s2paZFpVktjClpOu1oVYsN29W5Bdvrx6CgDwXw78TW8AfGDxRpnw9hj8T6d4hukjsA7mEG4dsoeRlgHkZccbhg5HGL/j261zUIvI+LfxFjtJLuZrWHSNAMU6WMq4Aa7wwYICAdo3tzn5TkVu/Ej9mu20D4fXWo+DtQ1rVL2xYzmxnlR1ZGwJGRVQZfAUnnkJjk4FZWleC/hj4r/Zk13XdB02K08R6XbmW8kkZnkgljVZHVV3nbG4U7c5xvPcYAA34TfGLwZ8N7Obw3rHhmBbreqPrWjbJBcjgbpCzAgLkdD3Pyqcg/YkflyRRyRsGjdQV44IrwjwPoMPjb9kKDR1021s576ymhCW0GwPPBK0ccjDIzITChJJ6+wrpPgL4uuvFfwo09b+8NzqemO1hdFmBkOw4QtyTym3JPJYE0Aet4HpUci5I9BmpKKAPnbxLs+Fv7TGmeKni8nw/4uhFje3UrYjiuNwGT2XOIzk46uc4U19EKflH071wHxa8Dx/EL4e6loCJGb8L59k7pu2TKCV54wG5XPoT16VkfA/xzL4x+HtvDqUrDXtIf7BqME7ZnDLgKzg/MMjPUcsrc5BoA9XqhrP8AyAtQ/wCvaT/0E1fqhrP/ACAtQ/69pP8A0E0Aebfs6/8AJvXhn/t6/wDSuaij9nX/AJN68M/9vX/pXNRQB4v+01q+paT8UdKn0v8A19xoD2jfK24JI8qtjGOSDjp61zOjeEfCfjzWfCHh3wd4L1G6+wS2/wDb2s3GYYpIclpFwOFLZkCnhiFUDPJHsfxG1eDwf+0j4H8Wa0VtdFmsJdPN47bY4pCXzu7qAJEJJwMHr8px7bHq+ksx3ajbAY6GZetAFbwt4V0PwnoKaPoOmxafZoxby4h94nA3EnJZiAMknNb23jnmqP8AbOkD/mJ2v/f5f8aP7a0j/oJ2v/f1f8aALkmfLOBk8YrwPxF+zTpepa7eal4d8V6l4bt9SZvt9lAvmRzg9VHzLhScnDbhz0A4r3D+2dJ/6Clr/wB/l/xo/tnSP+gna/8Af5f8aAKPhXwzpfhLwnp3hvR42jsbCLyo9+C7ckszEADczEk4A5JrxvQyvw9/ak1vQpmSDR/Gkf8AaFplyxN2Dlxy3G5jMemSTGBxkV7l/bOkf9BO1/7/AC/414d+0DFF/YmiePtCvYp9T8L6gtw0cMy75LdmAfhQWJDKn0UueaAPfw2aWsDSfE+hatpVnqlpqtsba6hSeMtKFJV1DDg4I4PcVof2zpP/AEFLT/v8v+NAF0qC27vXzlrY/wCFP/tHWviPd9n8J+MT9nu2zsitrnI+ZyflAyd2SV4aT+6c/QH9s6Tj/kJ2n/f9f8a4T4m+GtC+IXgS/wBBfWbGC5YiW0uDKuYZVOQevQjIPXqeuMUAekK4Y4FUda/5Ad/6/Zpf/QTXmfwV8fW/iDwDDZ61ewwa5ozHTr6OWZCxdOFkGDyGHf1U9cZOn8VPiNofhDwBqF7/AGjbzX1xDJb2Vun70yzMp25VTnaDyxyAB3zgEAofs6/8m9eGf+3r/wBK5qK1Pgnod34d+CPhjS79WW5Fu07o6FGTzZGl2kHkEB8HPcUUAdPrnhvQ/Euiy6T4g0uDUrGfIaGdcgcdQeoOOhGCK8ku/wBlf4X3l9NcRPrFlG7ZEEF0pRPYF0ZsfVjRRQBD/wAMm/DP/oIeIP8AwKi/+NUf8Mm/DP8A6CHiD/wKi/8AjVFFAB/wyb8M/wDoIeIP/AqL/wCNUf8ADJvwz/6CHiD/AMCov/jVFFAB/wAMm/DP/oIeIP8AwKi/+NUn/DKHw1DbRqXiD/wKi/8AjXvRRQAp/ZO+GhIzqOv/APgVF/8AGqT/AIZN+Gf/AEENf/8AAmL/AONUUUAKP2Tfhn/0ENe/8CYf/jVJ/wAMm/DPnGoa+P8At5i/+NUUUAPb9k/4akf8hHX/APwKi/8AjVbvhb9nb4a+FNVj1SCxutTvYHEsEmozCQQsM8hFCqeufmBIIBGCM0UUAeuL90UUUUAf/9k=\" alt=\"New leaflet pictures 121113_Page_1_Page_7\" width=\"115\" height=\"182\"/></p><p><span>8. Envolver el envase vacío en la bolsa de plástico. Deséchelo y lávese las manos.</span></p><p><span> </span></p></td></tr></table><p><span> </span></p><p><span> </span></p><p><span>Nota. Se recomienda proteger la ropa de cama de un posible derrame ya que Pentasa</span><span>s</span><span>uspensión</span><span>r</span><span>ectal puede decolorar los tejidos. Si accidentalmente se derrama Pentasa</span><span>s</span><span>uspensión rectal en el tejido, ponerlo inmediatamente en remojo.</span></p><p><span> </span></p><p><strong><span>La d</span></strong><strong><span>osis recomendada</span></strong><strong><span>es</span></strong><strong><span>:</span></strong></p><p><span> </span></p><p><span>Adultos:</span><span>             </span><span>1 envase de suspensión rectal de 100 mililitros (</span><span>1 gramo</span><span>) al acostarse durante 2-3 semanas. Se puede reducir la dosis dependiendo del peso corporal del paciente.</span></p><p><span> </span></p><p><span>Niños (6-18 años):</span><span>             </span><span>Existe poca experiencia y documentación limitada sobre el efecto en niños.</span></p><p><span> </span></p></div>"
              },
              "section" : [{
                "id" : "c6351189-6bdb-4bc7-b401-3fc2da5864e1",
                "title" : "Si usa más PENTASA suspensión rectal del que debe",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029907",
                    "display" : "Si usa más PENTASA suspensión rectal del que debe"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No se han comunicado casos de sobredosis en humanos, pero si se sospecha una sobredosis se debe consultar al médico.</span></p><p><span>En caso de sobredosis ó ingestión accidental, consult</span><span>e inmediatamente a su médico o farmacéutico o llame</span><span>al Servicio de Información Toxicológica</span><span>,</span><span>t</span><span>eléfono: 91 562 04 20</span><span>indicando el medicamento y la cantidad ingerida</span><span>.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "1ec379a7-0e35-4678-9d20-97180b355cef",
                "title" : "Si interrumpe el tratamiento con Pentasasuspensión rectal",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029909",
                    "display" : "Si interrumpe el tratamiento con Pentasasuspensión rectal"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Su médico le indicará la duración</span><span>de su tratamiento con Pentasa suspensión rectal</span><span>. No suspenda el tratamiento antes aunque se encuentre mejor ya que los síntomas podrían volver a aparecer si termina el tratamiento demasiado pronto. Siga rigurosamente el tratamiento según las instrucciones de su médico en el tiempo de mantenimiento que establezca</span><span>.</span></p><p><span> </span></p><p><span>Si tiene cualquier otra duda sobre el uso de este producto, pregunte a s</span><span>u médico o farmacéutico.</span></p><p><span> </span></p></div>"
                }
              }]
            },
            {
              "id" : "fb4d1b1c-3c1e-44b6-b5f9-73504ca239d0",
              "title" : "4. Posibles efectos adversos",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029910",
                  "display" : "Posibles efectos adversos"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Al igual que todos los medicamentos, Pentasa suspensión rectal</span><span>puede producir efectos adversos, aunque no todas las personas los sufran.</span></p><p><span> </span></p><p><span>Se han notificado muy pocos casos de reacción alérgica grave (incluyendo erosiones cutáneas graves que pueden afectar a la piel como barrera protectora del cuerpo). La reacción alérgica podría dar lugar a la hinchazón de la cara y el cuello y/o dificultad para respirar o tragar (edema de Quincke). Si esto ocurriera contacte con su médico o servicio de urgencias inmediatamente.</span></p><p><span>Deje de tomar mesalazina y solicite ayuda médica inmediatamente si presenta alguno de los siguientes síntomas:</span></p><ul><li><span>                </span><span>parches rojizos no elevados, o parches circulares o en forma de moneda en el tórax, con frecuencia con ampollas centrales, descamación de la piel, úlceras en la boca, garganta, nariz, genitales y ojos, erupción generalizada, fiebre y aumento de los ganglios linfáticos. Estas erupciones cutáneas graves van precedidas a menudo de fiebre o síntomas de tipo gripal.</span></li></ul><p><strong><span>Los siguientes efectos adversos frecuentes</span></strong><span>afectan entre 1 y 10 de cada 100 pacientes tratados:</span></p><ul><li><span>dolor de cabeza</span></li><li><span>diarrea</span></li><li><span>dolor abdominal</span></li><li><span>náuseas</span></li><li><span>vómitos</span></li><li><span>erupción cutánea</span></li><li><span>flatulencia (gases)</span></li><li><span>reacciones locales como prurito, molestias rectales y urgencia de defecar</span></li><li><span>Malestar anal e irritación en el lugar de administración, picor y sensación de necesidad de defecar.</span></li></ul><p><em><span> </span></em></p><p><strong><span>Los siguientes efectos adversos raros,</span></strong><span>afectan entre 1 y 10 de cada 10.000 pacientes tratados:</span></p><ul><li><span>inflamación de algunas áreas del corazón (miocarditis y pericarditis) que pueden causar dificultad para respirar y dolor de pecho o palpitaciones (latidos del corazón rápidos o irregulares)</span></li><li><span>inflamación del páncreas (incluye síntomas de dolor de espalda y/ o estómago) y aumento de la amilasa</span></li><li><span>mareos</span></li><li><span>mayor sensibilidad de la piel a la luz solar y ultravioleta (fotosensibilidad)</span></li></ul><p><em><span> </span></em></p><p><strong><span>Los siguientes efectos adversos muy raros,</span></strong><span>afectan a menos de 1 de 10.000 pacientes tratados:</span></p><ul><li><span>eosinofilia (como parte de una reacción alérgica) y trastornos sanguíneos como reducción de los glóbulos rojos (anemia), de los glóbulos blancos (leucopenia), de las plaquetas (trombocitopenia), que pueden aumentar la probabilidad de tener infecciones o hemorragias.</span></li><li><span>trastornos del hígado (hepatitis) caracterizado por síntomas que incluyen ictericia (amarillamiento de la piel y/o los ojos) y/ o heces blancas.</span></li><li><span>trastornos del riñón de carácter inflamatorio (nefritis) que incluyen los siguientes signos y síntomas: sangre en la orina, edema (hinchazón debido al aumento de fluidos)</span><span>y aumento de la tensión arterial</span></li><li><span>neuropatía periférica (condición que afecta a los nervios de las manos y los pies incluyendo síntomas de cosquilleo y entumecimiento)</span></li><li><span>reacciones alérgicas pulmonares y fibróticas (los síntomas incluyen tos, dificultad para respirar, broncoespasmo, flemas sangrantes y/o excesivas)</span></li><li><span>pérdida de pelo (esta es reversible)</span></li><li><span>dolor muscular o articular</span></li><li><span>inflamación que puede afectar a varias partes del cuerpo como las articulaciones, piel, riñones, corazón, etc (los síntomas incluyen articulaciones doloridas, fatiga, fiebre, sangrado anormal o inexplicable (por ejemplo, sangrado de la nariz), contusión, coloración púrpura de la piel, manchas bajo la piel (incluyendo erosiones cutáneas graves y quemazón grave que pueden afectar a la piel como barrera protectora del cuerpo)</span></li><li><span>semen con baja concentración de espermatozoides (oligospermia) (ésta es reversible)</span></li><li><span>ocasionalmente pueden ocurrir reacciones alérgicas y fiebre</span></li></ul><p><span> </span></p><p><strong><span>Frecuencia no conocida</span></strong><span>(no puede estimarse a partir de los datos disponibles)</span></p><ul><li><span>cálculos renales y dolor renal asociado (ver también sección 2)</span></li><li><span>cambio de color de la orina</span></li></ul><p><span> </span></p><p><span>Algunas de estas reacciones adversas también pueden atribuirse a la enfermedad en si misma.</span></p><p><span> </span></p><p><span>Si estos síntomas continúan o se vuelven más graves, consulte con su médico.</span></p></div>"
              },
              "section" : [{
                "id" : "e9283859-3825-4821-8bc4-53e54730195d",
                "title" : "Comunicación de efectos adversos:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Comunicación de efectos adversos:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>Si experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del Sistema Español de Farmacovigilancia de Medicamentos de Uso Humano: http;//www.notificaram.es. Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.</span></p></div>"
                }
              }]
            },
            {
              "id" : "9d2488d0-9fd4-446e-86e7-613f7f858afd",
              "title" : "5. Conservación de Pentasa suspensión rectal",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029913",
                  "display" : "Conservación de \"X\""
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Mantener fuera de la vista y del alcance de los niños.</span></p><p><span> </span></p><p><span>No conservar a temperatura superior a 25ºC. No refrigerar o congelar. Conservar en el envase original para protegerlo de la luz.</span></p><p><span> </span></p><p><span>No utilice este medicamento después de la fecha de caducidad que aparece en el envase, después de “CAD”. La fecha de caducidad es el último día del mes que se indica.</span></p><p><span> </span></p><p><span>Los medicamentos no se deben tirar por los desagües ni a la basura. Deposite los envases y los medicamentos que no necesita en el Punto SIGRE</span><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCAAUABMDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2uTUPGPxN1TUX8P8AiGTwr4L02eS2+3WkQa81OSPKyGNmGI41YEBgCSVPrxx3h+XV7vwbfeMPg98SPFnil9On8uXS/EIF2t2wCkoN4Rk4YHKmktvDvibxl+zJoHhrwPrUfh/WtAvGt9TVrqS3KNCJkljJiUkksytg8HrXBfst+FfF13r8Hi6z15Lfwvp93PDe6ebqVTNIbYhW8sDY2C6HLEH5fYUDPpH4d+LtR1T4e6VfeK7G70/W3WQXVvPbtG6MsjLypAIyACPYiivKdW+K3xo1PXdQuvh/4c0zU/DIuZYbG7kt3czLG5RmyJACCytg46YooA1fjolx8OIn+J3gy+n0nW7qSO3vYoyrW16M4DSxMCC4HAYYOK8t8GfFLxv8Z/G1l4H8UawbHRLxW+1RaSgt3uFHVGc7m2noQCMg0UUAfYul6ZYaLpFppOl2qWtjaRrDDDGOEUDAFFFFAj//2Q==\" alt=\"null\" width=\"19\" height=\"20\"/><span>de la farmacia. En caso de duda pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que no necesita. De esta forma, ayudará a proteger el medio ambiente.</span></p></div>"
              }
            },
            {
              "id" : "1f7d8289-a59c-4345-bc85-30c53d6a34a4",
              "title" : "6. Contenido del envase e información adicional",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029914",
                  "display" : "Contenido del envase e información adicional"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "86331234-6b81-4707-b870-afd23fd081a7",
                "title" : "Composición dePENTASA suspensión rectal:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029915",
                    "display" : "Composición dePENTASA suspensión rectal:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span> </span></strong></p><p><span>- El principio activo es mesalazina.</span></p><p><span>-Los demás componentes son: edetato disódico, metabisulfito sódico (E-223), acetato sódico, ácido clorhídrico y agua purificada c.s.p. 100 mililitros.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "83ab0500-54f6-4980-8709-b6e377840a6d",
                "title" : "Aspecto del producto y contenido del envase",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029916",
                    "display" : "Aspecto del producto y contenido del envase"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>PENTASA suspensión rectal es una suspensión</span><span>blanca</span><span>a ligeramente amarilla</span><span>de 100 mililitros para administración rectal.</span></p><p><span>Cada caja contiene 7 envases de suspensión rectal de100 mililitros.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "b85ce51d-85d9-4f06-9603-65315b742a25",
                "title" : "Titular de la autorización de comercialización y responsable de la fabricación",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029917",
                    "display" : "Titular de la autorización de comercialización y responsable de la fabricación"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span> </span></strong></p></div>"
                }
              },
              {
                "id" : "19e43aad-d764-45f2-9307-f84c01fbaa1c",
                "title" : "Titular de la autorización de comercialización",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029917",
                    "display" : "Titular de la autorización de comercialización"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Ferring S.A.U</span></p><p><span>C/ del Arquitecto Sánchez Arcas nº3, 1º</span></p><p><span>28040 Madrid</span></p><p><span>España</span></p><p><span> </span></p><p><span> </span></p><p><strong><span>Responsable de la fabricación</span></strong><span>:</span></p><p><span>Ferring Léciva a.s</span></p><p><span>Dirección: K Rybníku 475, 252 42</span></p><p><span>Jesenice cerc</span><span>a de Praga, República Checa</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "8989f13d-6d01-4e1a-a4f8-12a7a5a8ef21",
                "title" : "Fecha de la última revisión de este prospecto en mayo 2023",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Fecha de la última revisión de este prospecto en mayo 2023"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span> </span></strong></p><p><span>La información detallada y actualizada de este medicamento está disponible en la página Web de la Agencia Española de Medicamentos y Productos Sanitarios (AEMPS)</span><span><span>http://www.aemps.gob.es/</span></span></p></div>"
                }
              }]
            }]
          }]
        }
      }]
    }
  }]
}

```
