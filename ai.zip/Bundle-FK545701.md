# FK545701 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK545701**

## Example Bundle: FK545701

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: Informasjon til brukeren

 

# Pakningsvedlegg: Informasjon til brukeren

## Aclasta 5 mg infusjonsvæske, oppløsning

### zoledronsyre


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.
* Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om

 

## I dette pakningsvedlegget finner du informasjon om

1. Hva Aclasta er og hva det brukes mot
1. Hva du må vite før du får Aclasta
1. Hvordan Aclasta gis
1. Mulige bivirkninger
1. Hvordan du oppbevarer Aclasta
1. Innholdet i pakningen og ytterligere informasjon


#### 1. Hva Aclasta er og hva det brukes mot

 

## 1. Hva Aclasta er og hva det brukes mot

Aclasta inneholder virkestoffet zoledronsyre. Aclasta tilhører en gruppe legemidler som kalles bisfosfonater og brukes i behandlingen av kvinner etter overgangsalderen og voksne menn med osteoporose, eller osteoporose forårsaket av behandling med kortikosteroider som brukes ved behandling av betennelse, og ved Pagets bensykdom hos voksne.

Osteoporose
Osteoporose er en sykdom som innebærer at benvevet blir tynnere og svakere. Det er vanlig hos kvinner etter overgangsalderen, men kan også forekomme hos menn. Ved overgangsalderen slutter kvinnens eggstokker å produsere det kvinnelige hormonet østrogen som medvirker til å beholde et friskt benvev. Etter overgangsalderen reduseres benmassen, og benvevet blir svakere og er mer utsatt for brudd. Osteoporose kan også oppstå hos menn og kvinner som følge av langtidsbruk av steroider, noe som kan påvirke benstyrken. Mange pasienter med osteoporose har ingen symptomer, men har likevel en risiko for benbrudd fordi osteoporosen har gjort benvevet svakere. Reduserte nivåer av sirkulerende kjønnshormoner i kroppen, hovedsakelig østrogen som dannes fra androgener, spiller også en rolle for det gradvise tapet av benvev som observeres hos menn. Aclasta styrker benvevet hos både kvinner og menn og gjør det derfor mindre utsatt for brudd. Aclasta brukes også hos pasienter som nylig har brukket hoften ved et uhell som f.eks. et fall, og som derfor har risiko for senere benbrudd.

Pagets bensykdom
Det er normalt at gammelt benvev fjernes og erstattes av ny bensubstans. Prosessen kalles remodellering. Ved Pagets bensykdom er remodelleringen for rask og nytt ben dannes på en uorganisert måte, noe som gjør det svakere enn normalt. Dersom sykdommen ikke behandles, kan misdannelser og smerter i skjelettet oppstå, og benbrudd kan forekomme. Aclasta virker ved å normalisere remodelleringsprosessen, sikrer at normalt ben dannes, og gjenoppretter dermed benstyrken.


#### 2. Hva du må vite før du får Aclasta

 

## 2. Hva du må vite før du får Aclasta

Følg alle instruksjoner fra legen din, apoteket eller sykepleier nøye før du får Aclasta.


#### 3. Hvordan Aclasta gis

 

## 3. Hvordan Aclasta gis

Følg nøye alle instruksjoner du får fra lege eller sykepleier. Kontakt lege eller sykepleier hvis du er usikker.

Osteoporose
Den vanlige dosen er 5 mg gitt av legen din eller en sykepleier som én årlig enkeltinfusjon i en blodåre (vene). Infusjonen tar minimum 15 minutter.

Hvis du nylig har hatt et brudd i hoften, anbefales det at Aclasta gis to eller flere uker etter hofteoperasjonen.

Det er viktig at du tar tilskudd av kalsium og vitamin D (f.eks. tabletter) i henhold til anbefaling fra legen din.

Ved osteoporose virker Aclasta i 1 år. Legen din vil fortelle deg når du skal komme tilbake for å få neste dose.

Pagets bensykdom
Ved behandling av Pagets bensykdom, bør Aclasta kun forskrives av leger med erfaring i behandling av Pagets bensykdom.

Den vanlige dosen er 5 mg, gitt av legen din eller en sykepleier, som en initialinfusjon i en blodåre (vene). Infusjonen tar minimum 15 minutter. Aclasta kan virke i mer enn ett år, og legen din vil fortelle deg om du trenger flere behandlinger.

Legen kan anbefale deg å ta kalsium- og vitamin D-tilskudd (f.eks. tabletter) minimum de ti første dagene etter at du har fått Aclasta. Det er viktig at du følger dette rådet nøye slik at nivået av kalsium i blodet ikke blir for lavt (hypokalsemi) i tiden etter infusjonen. Legen vil informere om symptomer som er forbundet med hypokalsemi.

Inntak av Aclasta sammen med mat og drikke
Sørg for at du drikker tilstrekkelig væske (minimum ett eller to glass) før og etter behandlingen med Aclasta, slik som legen din sier. Dette vil hjelpe deg å forhindre dehydrering. Du kan spise normalt de dagene du får Aclasta. Dette er spesielt viktig for pasienter som bruker diuretika (”vanndrivende”) og hos eldre pasienter (65 år eller eldre).


#### 4. Mulige bivirkninger

 

## 4. Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.

Bivirkninger relatert til den første infusjonen er svært vanlig (oppstår hos mer enn 30 % av pasientene), men er mindre vanlig ved påfølgende infusjoner. De fleste av bivirkningene, slik som feber og frysninger, smerter i muskler eller ledd og hodepine, oppstår i løpet av de tre første dagene etter en dose Aclasta. Symptomene er vanligvis milde til moderate og opphører i løpet av tre dager. Legen din kan anbefale et mildt smertestillende middel som ibuprofen eller paracetamol for å lindre disse bivirkningene. Sannsynligheten for at du får disse bivirkningene med de påfølgende dosene Aclasta er lavere.

Enkelte bivirkninger kan være alvorlige

Vanlige (kan forekomme hos opp til 1 av 10 personer)

Uregelmessig hjerterytme (atrieflimmer) har blitt sett hos pasienter som får Aclasta mot osteoporose etter overgangsalderen. Det er foreløpig uklart om Aclasta forårsaker denne uregelmessige hjerterytmen, men du må si fra til legen din hvis du opplever slike symptomer etter at du har fått Aclasta.

Mindre vanlige (kan forekomme hos opp til 1 av 100 personer)Hevelse, rødhet, smerte og kløe i øynene eller lysfølsomme øyne.

Svært sjeldne (kan forekomme hos opp til 1 av 10 000 personer)

Snakk med legen din dersom du har smerter i øret, pussdannelse fra øret, og/eller en infeksjon i øret. Dette kan være tegn på benskade i øret.

Ikke kjent (frekvens kan ikke estimeres ut ifra tilgjengelige data)

Smerte i munnen og/eller kjeven, hevelse eller sår som ikke gror i munnen eller kjeven, væsker, nummenhet eller en følelse av tung kjeve, eller en tann som løsner; dette kan være tegn på skader i kjevebenet (osteonekrose). Ta øyeblikkelig kontakt med legen og tannlegen din dersom du opplever slike symptomer samtidig som du blir behandlet med Aclasta eller etter at behandlingen er avsluttet.

Nyresykdom (f.eks. redusert urinproduksjon) kan oppstå. Legen din bør ta en blodprøve for å sjekke nyrefunksjonen din før hver dose med Aclasta. Det er viktig at du drikker minst to glass væske (f.eks. vann) i løpet av få timer før du får Aclasta, slik som du har fått beskjed om av helsepersonell.

Informer legen din dersom du merker noen av bivirkningene som er nevnt over.

Aclasta kan også gi andre bivirkninger

Svært vanlige (kan forekomme hos flere enn 1 av 10 personer)Feber

Vanlige (kan forekomme hos opp til 1 av 10 personer)

Hodepine, svimmelhet, kvalme, oppkast, diaré, muskelsmerter, smerter i skjelett og/eller ledd, smerter i rygg, armer eller ben, influensalignende symptomer (f.eks. tretthet, frysninger, ledd- og muskelsmerter), frysninger, tretthetsfølelse og manglende tiltakslyst, svakhet, smerter, følelse av uvelhet, hevelse og/eller smerte på infusjonsstedet.

Hos pasienter med Pagets sykdom er symptomer på lite kalsium i blodet, slik som muskelkramper, nummenhet eller en kriblende følelse, spesielt i området rundt munnen, rapportert.

Mindre vanlige (kan forekomme hos opp til 1 av 100 personer)

Influensa, øvre luftveisinfeksjoner, redusert antall røde blodlegemer, redusert appetitt, søvnløshet, søvnighet som kan omfatte redusert årvåkenhet og oppmerksomhet, kriblende følelse eller nummenhet, ekstrem tretthet, skjelvinger, midlertidig bevisstløshet, øyeinfeksjon eller irritasjon eller betennelse med smerter og rødhet, snurrende følelse, økt blodtrykk, rødming, hoste, kortpustethet, magebesvær, buksmerter, forstoppelse, munntørrhet, halsbrann, hudutslett, kraftig svetting, kløe, rødhet i huden, nakkesmerter, stivhet i muskler, skjelett og/eller ledd, hovne ledd, muskelkramper, skuldersmerter, smerter i brystmuskulaturen og brystkassen, leddbetennelse, muskelsvakhet, unormale nyrefunksjonstester, unormalt hyppig vannlating, hevelser i hender, ankler eller føtter, tørste, tannpine, smaksforstyrrelser.

Sjeldne (kan forekomme hos opp til 1 av 1000 personer)

Uvanlige brudd i lårbenet kan oppstå i sjeldne tilfeller, spesielt hos pasienter som har vært behandlet for osteoporose lenge. Ta kontakt med legen din dersom du merker smerter, svakhet eller ubehag i låret, hoften eller lysken siden dette kan være tidlige tegn på et mulig lårbensbrudd.
Lave fosfatnivåer i blodet.

Ikke kjent (frekvens kan ikke anslås ut ifra tilgjengelige data)

Alvorlige allergiske reaksjoner inkludert svimmelhet og pustevansker, hevelse i hovedsakelig ansikt og hals, redusert blodtrykk, dehydrering (uttørring) på grunn av akuttfasereaksjoner (bivirkninger etter dosering, slik som feber, oppkast og diaré).


#### 5. Hvordan du oppbevarer Aclasta

 

## 5. Hvordan du oppbevarer Aclasta

Legen din, apoteket eller sykepleier vet hvordan Aclasta skal oppbevares.

* Oppbevares utilgjengelig for barn.
* Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken og flasken etter EXP.
* Uåpnet flaske krever ingen spesielle oppbevaringsbetingelser.
* Etter at flasken er åpnet bør legemidlet brukes umiddelbart for å unngå forurensning med bakterier. Dersom den ikke brukes umiddelbart, er oppbevaringstid og –betingelser før bruk brukerens ansvar. Tiden bør normalt ikke overskride 24 timer ved 2-8ºC. Den avkjølte oppløsningen bør nå romtemperatur før administrering.


#### 6. Innholdet i pakningen og ytterligere informasjon

 

## 6. Innholdet i pakningen og ytterligere informasjon


####  Aclasta inf, oppl 5 mg/100 ml 
LEGEMIDDELMERKEVAREID:
** ID_834B988C-01D4-471D-AE6A-B32833006AF3 **
-------

Full name: **Aclasta inf, oppl 5 mg/100 ml**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_DEA4A057-4B2E-4753-8AC1-F83B0360B6C8 ** 

VARENUMMER: ** 113088 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK545701",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "545701"
  },
  "type" : "document",
  "timestamp" : "2022-11-09T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK545701-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK545701-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK545701-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK545701-COMP</b></p><a name=\"FK545701-COMP\"> </a><a name=\"hcFK545701-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/545701</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2022-11-09</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: Aclasta Sandoz</p></div>"
      },
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "545701"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/COPD-MPD-260"
      }],
      "date" : "2022-11-09",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "Aclasta Sandoz",
      "section" : [{
        "title" : "Pakningsvedlegg: Informasjon til brukeren",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: Informasjon til brukeren</h1><h2>Aclasta 5 mg infusjonsvæske, oppløsning</h2><h3>zoledronsyre</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.</li><li>Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om</h2><div class=\"paragraph\"><ol><li>Hva Aclasta er og hva det brukes mot</li><li>Hva du må vite før du får Aclasta</li><li>Hvordan Aclasta gis</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer Aclasta</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "1. Hva Aclasta er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>1. Hva Aclasta er og hva det brukes mot</h2><div class=\"paragraph\">Aclasta inneholder virkestoffet zoledronsyre. Aclasta tilhører en gruppe legemidler som kalles bisfosfonater og brukes i behandlingen av kvinner etter overgangsalderen og voksne menn med osteoporose, eller osteoporose forårsaket av behandling med kortikosteroider som brukes ved behandling av betennelse, og ved Pagets bensykdom hos voksne.</div><span class=\"inline-title\">Osteoporose</span><div class=\"paragraph\">Osteoporose er en sykdom som innebærer at benvevet blir tynnere og svakere. Det er vanlig hos kvinner etter overgangsalderen, men kan også forekomme hos menn. Ved overgangsalderen slutter kvinnens eggstokker å produsere det kvinnelige hormonet østrogen som medvirker til å beholde et friskt benvev. Etter overgangsalderen reduseres benmassen, og benvevet blir svakere og er mer utsatt for brudd. Osteoporose kan også oppstå hos menn og kvinner som følge av langtidsbruk av steroider, noe som kan påvirke benstyrken. Mange pasienter med osteoporose har ingen symptomer, men har likevel en risiko for benbrudd fordi osteoporosen har gjort benvevet svakere. Reduserte nivåer av sirkulerende kjønnshormoner i kroppen, hovedsakelig østrogen som dannes fra androgener, spiller også en rolle for det gradvise tapet av benvev som observeres hos menn. Aclasta styrker benvevet hos både kvinner og menn og gjør det derfor mindre utsatt for brudd. Aclasta brukes også hos pasienter som nylig har brukket hoften ved et uhell som f.eks. et fall, og som derfor har risiko for senere benbrudd.</div><span class=\"inline-title\">Pagets bensykdom</span><div class=\"paragraph\">Det er normalt at gammelt benvev fjernes og erstattes av ny bensubstans. Prosessen kalles remodellering. Ved Pagets bensykdom er remodelleringen for rask og nytt ben dannes på en uorganisert måte, noe som gjør det svakere enn normalt. Dersom sykdommen ikke behandles, kan misdannelser og smerter i skjelettet oppstå, og benbrudd kan forekomme. Aclasta virker ved å normalisere remodelleringsprosessen, sikrer at normalt ben dannes, og gjenoppretter dermed benstyrken.</div></div>"
          }
        },
        {
          "title" : "2. Hva du må vite før du får Aclasta",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>2. Hva du må vite før du får Aclasta</h2><div class=\"paragraph\">Følg alle instruksjoner fra legen din, apoteket eller sykepleier nøye før du får Aclasta.</div></div>"
          },
          "section" : [{
            "title" : "Du må ikke få Aclasta:",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Du må ikke få Aclasta:</h3><div class=\"paragraph\"><ul><li>dersom du er allergisk overfor zoledronsyre, andre bisfosfonater eller noen av de andre innholdsstoffene i dette legemidlet (listet opp i avsnitt 6).</li><li>dersom du har hypokalsemi (dvs. for lavt kalsiumnivå i blodet).</li><li>dersom du har alvorlige nyreproblemer.</li><li>dersom du er gravid.</li><li>dersom du ammer.</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler</h3><div class=\"paragraph\">Snakk med lege før du bruker Aclasta:<ul><li>hvis du blir behandlet med et legemiddel som inneholder zoledronsyre, som også er virkestoffet i Aclasta (zoledronsyre brukes til voksne pasienter med spesifikke krefttyper for å forhindre beinkomplikasjoner eller for å redusere mengden kalsium).</li><li>hvis du har eller har hatt nyreproblemer.</li><li>hvis du er forhindret fra å ta et daglig kalsiumtilskudd.</li><li>hvis du har fått fjernet noen eller alle biskjoldbruskkjertlene i halsen kirurgisk.</li><li>hvis du har fått fjernet deler av tarmene.</li></ul></div><div class=\"paragraph\">Hos pasienter som fikk Aclasta (zoledronsyre) for osteoporose er det etter markedsføring rapportert en bivirkning som kalles osteonekrose i kjeven (benskader i kjeven). Osteonekrose i kjeven kan også oppstå etter at behandlingen er avsluttet.</div><div class=\"paragraph\">Det er viktig å prøve å hindre utvikling av osteonekrose i kjeven, da det er en smertefull tilstand som kan være vanskelig å behandle. Det er noen forholdsregler du bør ta for å redusere risikoen for å utvikle osteonekrose i kjeven.</div><div class=\"paragraph\">Før du blir behandlet med Aclasta, må du fortelle legen din, apotek eller sykepleier dersom<ul><li><span style=\"color: #212121;\">du har noen problemer med munnen din eller tennene dine, som dårlig tannhelse, tannkjøttsykdommer eller en planlagt tanntrekking</span>;</li><li><span style=\"color: #212121;\">du ikke går regelmessig til tannlege eller ikke har hatt en tannsjekk på lang tid</span>;</li><li><span style=\"color: #212121;\">du røyker (da dette kan øke risikoen for tannproblemer)</span>;</li><li><span style=\"color: #212121;\">du har tidligere vært behandlet med et bisfosfonat (brukes til å behandle eller forebygge skjelettlidelser)</span>;</li><li><span style=\"color: #212121;\">du bruker medisiner som kalles kortikosteroider (f.eks. prednisolon eller deksametason)</span></li><li>du har kreft.</li></ul></div><div class=\"paragraph\">Legen din kan be deg om å gjennomgå en tannundersøkelse før du starter behandlingen med Aclasta.</div><div class=\"paragraph\">Samtidig som du blir behandlet med Aclasta, bør du opprettholde god munnhygiene (herunder pusse tennene regelmessig) og ha rutinemessig tannlegesjekk. Hvis du bruker gebiss, bør du sørge for at det er tilpasset ordentlig. Hvis du er under tannbehandling eller skal gjennomgå tannkirurgi (f.eks. tanntrekking), fortell legen din om tannbehandlingen og fortell tannlegen din at du behandles med Aclasta. Ta øyeblikkelig kontakt med legen og tannlegen din hvis du opplever problemer med munnen eller tennene som f.eks. løse tenner, smerte eller hevelse, sår som ikke gror eller væsker, da dette kan være tegn på osteonekrose i kjeven.</div><span class=\"inline-title\">Undersøkelser</span><div class=\"paragraph\">Legen din bør ta en blodprøve for å kontrollere nyrefunksjonen din (kreatininnivå) før hver dose Aclasta. Det er viktig at du drikker minst to glass væske (f.eks. vann) i løpet av noen få timer før du får Aclasta, slik som du har fått beskjed om av helsepersonell.</div></div>"
            }
          },
          {
            "title" : "Barn og ungdom",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029899"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Barn og ungdom</h3><div class=\"paragraph\">Aclasta anbefales ikke til noen under 18 år.</div></div>"
            }
          },
          {
            "title" : "Andre legemidler og Aclasta",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og Aclasta</h3><div class=\"paragraph\">Snakk med lege, apotek eller sykepleier dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler.</div><div class=\"paragraph\">Det er viktig at legen vet om alle legemidlene du bruker, spesielt dersom du bruker legemidler som er kjent for å kunne skade nyrene (f.eks. aminoglykosider) eller diuretika (”vanndrivende”) som kan føre til uttørring/dehydrering.</div></div>"
            }
          },
          {
            "title" : "Graviditet og amming",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet og amming</h3><div class=\"paragraph\">Du skal ikke få Aclasta dersom du er gravid eller ammer, tror at du kan være gravid eller planlegger å bli gravid.</div><div class=\"paragraph\">Snakk med lege, apotek eller sykepleier før du tar dette legemidlet.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\">Dersom du føler deg svimmel mens du bruker Aclasta, skal du ikke kjøre eller bruke maskiner. Vent til du føler deg bedre.</div></div>"
            }
          },
          {
            "title" : "Aclasta inneholder natrium",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Aclasta inneholder natrium</h3><div class=\"paragraph\">Dette legemidlet inneholder mindre enn 1 mmol natrium (23 mg) i hvert 100 ml hetteglass med Aclasta, og er så godt som ”natriumfritt”.</div></div>"
            }
          }]
        },
        {
          "title" : "3. Hvordan Aclasta gis",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>3. Hvordan Aclasta gis</h2><div class=\"paragraph\">Følg nøye alle instruksjoner du får fra lege eller sykepleier. Kontakt lege eller sykepleier hvis du er usikker.</div><span class=\"inline-title\">Osteoporose</span><div class=\"paragraph\">Den vanlige dosen er 5 mg gitt av legen din eller en sykepleier som én årlig enkeltinfusjon i en blodåre (vene). Infusjonen tar minimum 15 minutter.</div><div class=\"paragraph\">Hvis du nylig har hatt et brudd i hoften, anbefales det at Aclasta gis to eller flere uker etter hofteoperasjonen.</div><div class=\"paragraph\">Det er viktig at du tar tilskudd av kalsium og vitamin D (f.eks. tabletter) i henhold til anbefaling fra legen din.</div><div class=\"paragraph\">Ved osteoporose virker Aclasta i 1 år. Legen din vil fortelle deg når du skal komme tilbake for å få neste dose.</div><span class=\"inline-title\">Pagets bensykdom</span><div class=\"paragraph\">Ved behandling av Pagets bensykdom, bør Aclasta kun forskrives av leger med erfaring i behandling av Pagets bensykdom.</div><div class=\"paragraph\">Den vanlige dosen er 5 mg, gitt av legen din eller en sykepleier, som en initialinfusjon i en blodåre (vene). Infusjonen tar minimum 15 minutter. Aclasta kan virke i mer enn ett år, og legen din vil fortelle deg om du trenger flere behandlinger.</div><div class=\"paragraph\">Legen kan anbefale deg å ta kalsium- og vitamin D-tilskudd (f.eks. tabletter) minimum de ti første dagene etter at du har fått Aclasta. Det er viktig at du følger dette rådet nøye slik at nivået av kalsium i blodet ikke blir for lavt (hypokalsemi) i tiden etter infusjonen. Legen vil informere om symptomer som er forbundet med hypokalsemi.</div><span class=\"inline-title\">Inntak av Aclasta sammen med mat og drikke</span><div class=\"paragraph\">Sørg for at du drikker tilstrekkelig væske (minimum ett eller to glass) før og etter behandlingen med Aclasta, slik som legen din sier. Dette vil hjelpe deg å forhindre dehydrering. Du kan spise normalt de dagene du får Aclasta. Dette er spesielt viktig for pasienter som bruker diuretika (”vanndrivende”) og hos eldre pasienter (65 år eller eldre).</div></div>"
          },
          "section" : [{
            "title" : "Dersom du har glemt en dose Aclasta",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029908"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du har glemt en dose Aclasta</h3><div class=\"paragraph\">Kontakt lege eller sykehuset så snart som mulig for å avtale en ny time.</div></div>"
            }
          },
          {
            "title" : "Før Aclasta-behandlingen avsluttes",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029909"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Før Aclasta-behandlingen avsluttes</h3><div class=\"paragraph\">Dersom du vurderer å stoppe behandlingen med Aclasta, skal du møte opp til den neste avtalte timen og diskutere dette med legen din. Legen din vil gi deg råd og bestemme hvor lenge du bør behandles med Aclasta.</div><div class=\"paragraph\">Spør lege, apotek eller sykepleier dersom du har noen spørsmål om bruken av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "4. Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>4. Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.</div><div class=\"paragraph\">Bivirkninger relatert til den første infusjonen er svært vanlig (oppstår hos mer enn 30 % av pasientene), men er mindre vanlig ved påfølgende infusjoner. De fleste av bivirkningene, slik som feber og frysninger, smerter i muskler eller ledd og hodepine, oppstår i løpet av de tre første dagene etter en dose Aclasta. Symptomene er vanligvis milde til moderate og opphører i løpet av tre dager. Legen din kan anbefale et mildt smertestillende middel som ibuprofen eller paracetamol for å lindre disse bivirkningene. Sannsynligheten for at du får disse bivirkningene med de påfølgende dosene Aclasta er lavere.</div><span class=\"inline-title\">Enkelte bivirkninger kan være alvorlige</span><div class=\"paragraph\"><span class=\"underline\">Vanlige (kan forekomme hos opp til 1 av 10 personer)</span><br/>Uregelmessig hjerterytme (atrieflimmer) har blitt sett hos pasienter som får Aclasta mot osteoporose etter overgangsalderen. Det er foreløpig uklart om Aclasta forårsaker denne uregelmessige hjerterytmen, men du må si fra til legen din hvis du opplever slike symptomer etter at du har fått Aclasta.</div><div class=\"paragraph\"><span class=\"underline\">Mindre vanlige (kan forekomme hos opp til 1 av 100 personer)</span> Hevelse, rødhet, smerte og kløe i øynene eller lysfølsomme øyne.</div><div class=\"paragraph\"><span class=\"underline\">Svært sjeldne (kan forekomme hos opp til 1 av 10 000 personer)</span><br/>Snakk med legen din dersom du har smerter i øret, pussdannelse fra øret, og/eller en infeksjon i øret. Dette kan være tegn på benskade i øret.</div><div class=\"paragraph\"><span class=\"underline\">Ikke kjent (frekvens kan ikke estimeres ut ifra tilgjengelige data)</span><br/>Smerte i munnen og/eller kjeven, hevelse eller sår som ikke gror i munnen eller kjeven, væsker, nummenhet eller en følelse av tung kjeve, eller en tann som løsner; dette kan være tegn på skader i kjevebenet (osteonekrose). Ta øyeblikkelig kontakt med legen og tannlegen din dersom du opplever slike symptomer samtidig som du blir behandlet med Aclasta eller etter at behandlingen er avsluttet.</div><div class=\"paragraph\">Nyresykdom (f.eks. redusert urinproduksjon) kan oppstå. Legen din bør ta en blodprøve for å sjekke nyrefunksjonen din før hver dose med Aclasta. Det er viktig at du drikker minst to glass væske (f.eks. vann) i løpet av få timer før du får Aclasta, slik som du har fått beskjed om av helsepersonell.</div><div class=\"paragraph\">Informer legen din dersom du merker noen av bivirkningene som er nevnt over.</div><span class=\"inline-title\">Aclasta kan også gi andre bivirkninger</span><div class=\"paragraph\"><span class=\"underline\">Svært vanlige (kan forekomme hos flere enn 1 av 10 personer)</span> Feber</div><div class=\"paragraph\"><span class=\"underline\">Vanlige (kan forekomme hos opp til 1 av 10 personer)</span><br/>Hodepine, svimmelhet, kvalme, oppkast, diaré, muskelsmerter, smerter i skjelett og/eller ledd, smerter i rygg, armer eller ben, influensalignende symptomer (f.eks. tretthet, frysninger, ledd- og muskelsmerter), frysninger, tretthetsfølelse og manglende tiltakslyst, svakhet, smerter, følelse av uvelhet, hevelse og/eller smerte på infusjonsstedet.</div><div class=\"paragraph\">Hos pasienter med Pagets sykdom er symptomer på lite kalsium i blodet, slik som muskelkramper, nummenhet eller en kriblende følelse, spesielt i området rundt munnen, rapportert.</div><div class=\"paragraph\"><span class=\"underline\">Mindre vanlige (kan forekomme hos opp til 1 av 100 personer)</span><br/>Influensa, øvre luftveisinfeksjoner, redusert antall røde blodlegemer, redusert appetitt, søvnløshet, søvnighet som kan omfatte redusert årvåkenhet og oppmerksomhet, kriblende følelse eller nummenhet, ekstrem tretthet, skjelvinger, midlertidig bevisstløshet, øyeinfeksjon eller irritasjon eller betennelse med smerter og rødhet, snurrende følelse, økt blodtrykk, rødming, hoste, kortpustethet, magebesvær, buksmerter, forstoppelse, munntørrhet, halsbrann, hudutslett, kraftig svetting, kløe, rødhet i huden, nakkesmerter, stivhet i muskler, skjelett og/eller ledd, hovne ledd, muskelkramper, skuldersmerter, smerter i brystmuskulaturen og brystkassen, leddbetennelse, muskelsvakhet, unormale nyrefunksjonstester, unormalt hyppig vannlating, hevelser i hender, ankler eller føtter, tørste, tannpine, smaksforstyrrelser.</div><div class=\"paragraph\"><span class=\"underline\">Sjeldne (kan forekomme hos opp til 1 av 1000 personer)</span><br/>Uvanlige brudd i lårbenet kan oppstå i sjeldne tilfeller, spesielt hos pasienter som har vært behandlet for osteoporose lenge. Ta kontakt med legen din dersom du merker smerter, svakhet eller ubehag i låret, hoften eller lysken siden dette kan være tidlige tegn på et mulig lårbensbrudd. <span style=\"color: #212121;\">Lave fosfatnivåer i blodet.</span></div><div class=\"paragraph\"><span class=\"underline\">Ikke kjent (frekvens kan ikke anslås ut ifra tilgjengelige data)</span><br/>Alvorlige allergiske reaksjoner inkludert svimmelhet og pustevansker, hevelse i hovedsakelig ansikt og hals, redusert blodtrykk, dehydrering (uttørring) på grunn av akuttfasereaksjoner (bivirkninger etter dosering, slik som feber, oppkast og diaré).</div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger. Dette gjelder også bivirkninger som ikke er nevnt i pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "5. Hvordan du oppbevarer Aclasta",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>5. Hvordan du oppbevarer Aclasta</h2><div class=\"paragraph\">Legen din, apoteket eller sykepleier vet hvordan Aclasta skal oppbevares.</div><div class=\"paragraph\"><ul><li>Oppbevares utilgjengelig for barn.</li><li>Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken og flasken etter EXP.</li><li>Uåpnet flaske krever ingen spesielle oppbevaringsbetingelser.</li><li>Etter at flasken er åpnet bør legemidlet brukes umiddelbart for å unngå forurensning med bakterier. Dersom den ikke brukes umiddelbart, er oppbevaringstid og –betingelser før bruk brukerens ansvar. Tiden bør normalt ikke overskride 24 timer ved 2-8ºC. Den avkjølte oppløsningen bør nå romtemperatur før administrering.</li></ul></div></div>"
          }
        },
        {
          "title" : "6. Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>6. Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av Aclasta",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av Aclasta</h3><div class=\"paragraph\"><ul><li>Virkestoff er zoledronsyre. Hver flaske med 100 ml oppløsning inneholder 5 mg zoledronsyre (som monohydrat).<br/>1 ml oppløsning inneholder 0,05 mg zoledronsyre, (som monohydrat).</li><li>Andre innholdsstoffer er mannitol, natriumsitrat og vann til injeksjonsvæsker.</li></ul></div></div>"
            }
          },
          {
            "title" : "Hvordan Aclasta ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan Aclasta ser ut og innholdet i pakningen</h3><div class=\"paragraph\">Aclasta er en klar og fargeløs oppløsning. Den leveres i 100 ml plastflasker som en bruksklar infusjonsvæske. Den leveres i pakninger som inneholder 1 flaske som enkeltpakning eller i flerpakninger bestående av fem pakninger. Hver av disse inneholder en flaske. Ikke alle pakningsstørrelser vil nødvendigvis bli markedsført.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen</h3><div class=\"paragraph\">Sandoz Pharmaceuticals d.d.<br/>Verovškova ulica 57<br/>1000 Ljubljana<br/>Slovenia</div><span class=\"inline-title\">Tilvirker</span><div class=\"paragraph\">Novartis Pharma GmbH<br/>Roonstraße 25<br/>D-90429 Nürnberg Tyskland</div><div class=\"paragraph\">Ta kontakt med den lokale representanten for innehaveren av markedsføringstillatelsen for ytterligere informasjon om dette legemidlet:</div><div class=\"paragraph\">Sandoz A/S<br/>Edvard Thomsens Vej 14<br/>DK-2300 København S<br/>Danmark<br/>Tlf: +45 6395 1000<br/><a href=\"mailto:info.norge@sandoz.com\" title=\"\n               \n                  info.norge@sandoz.com\n               \n            \">info.norge@sandoz.com</a></div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 09.11.2022",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 09.11.2022</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre informasjonskilder</h3><div class=\"paragraph\">Detaljert informasjon om dette legemidlet er tilgjengelig på nettstedet til Det europeiske legemiddelkontoret (the European Medicines Agency): <a href=\"http://www.ema.europa.eu/\" title=\"\n               \n                  http://www.ema.europa.eu\n               \n            \">http://www.ema.europa.eu</a></div></div>"
            }
          },
          {
            "title" : "INFORMASJON TIL HELSEPERSONELL",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029921"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3><b>INFORMASJON TIL HELSEPERSONELL</b></h3><div class=\"paragraph\">Påfølgende informasjon er bare beregnet på helsepersonell (se pkt. 3):</div><span class=\"inline-title\">Hvordan tilberede og administrere Aclasta</span><div class=\"paragraph\"><ul><li>Aclasta 5 mg infusjonsvæske, oppløsning er bruksklar.</li></ul></div><div class=\"paragraph\">Kun til engangsbruk. Ubrukt oppløsning skal kasseres. Kun klar oppløsning uten partikler eller misfarging skal benyttes. Aclasta må ikke blandes eller gis intravenøst sammen med andre legemidler, og må gis gjennom en separat infusjonsslange ved konstant infusjonshastighet. Infusjonstiden må ikke være kortere enn 15 minutter. Aclasta må ikke komme i kontakt med oppløsninger som inneholder kalsium. Oppløsning som oppbevares i kjøleskap må tempereres til romtemperatur før administrering. Aseptisk arbeidsteknikk må benyttes ved tilberedning av infusjonen. Infusjonen må gjennomføres i henhold til standard medisinsk praksis.</div><span class=\"inline-title\">Oppbevaring av Aclasta</span><div class=\"paragraph\"><ul><li>Oppbevares utilgjengelig for barn.</li><li>Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken og flasken etter EXP.</li><li>Uåpnet flaske krever ingen spesielle oppbevaringsbetingelser.</li><li>Preparatet bør tas i bruk umiddelbart etter åpning for å unngå mikrobiell kontaminering.</li></ul></div><div class=\"paragraph\">Dersom preparatet ikke benyttes umiddelbart, er oppbevaringstid og betingelser før anvendelse brukerens ansvar, og bør ikke overskride 24 timer ved 2-8ºC. Oppløsning som oppbevares i kjøleskap må tempereres til romtemperatur før administrering.</div></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/COPD-MPD-260",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "COPD-MPD-260",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_COPD-MPD-260\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition COPD-MPD-260</b></p><a name=\"COPD-MPD-260\"> </a><a name=\"hcCOPD-MPD-260\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_834B988C-01D4-471D-AE6A-B32833006AF3</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Aclasta inf, oppl 5 mg/100 ml</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_834B988C-01D4-471D-AE6A-B32833006AF3"
      }],
      "name" : [{
        "productName" : "Aclasta inf, oppl 5 mg/100 ml"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/COPD-PPD-356",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "COPD-PPD-356",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_COPD-PPD-356\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition COPD-PPD-356</b></p><a name=\"COPD-PPD-356\"> </a><a name=\"hcCOPD-PPD-356\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_DEA4A057-4B2E-4753-8AC1-F83B0360B6C8, <code>https://farmalogg.no/varenummer</code>/113088</p><p><b>name</b>: Aclasta inf, oppl 5 mg/100 ml</p><p><b>packageFor</b>: <a href=\"Bundle-FK545701.html#MedicinalProductDefinition_COPD-MPD-260\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_834B988C-01D4-471D-AE6A-B32833006AF3</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_DEA4A057-4B2E-4753-8AC1-F83B0360B6C8"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "113088"
      }],
      "name" : "Aclasta inf, oppl 5 mg/100 ml",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/COPD-MPD-260"
      }]
    }
  }]
}

```
