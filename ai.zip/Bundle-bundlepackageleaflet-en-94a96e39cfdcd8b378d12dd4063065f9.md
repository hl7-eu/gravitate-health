# ePI document Bundle for Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion Package Leaflet for language en - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion Package Leaflet for language en**

## Example Bundle: ePI document Bundle for Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion Package Leaflet for language en

**Composition category:**Raw

**Composition status:**final

### B. Package Leaflet

 

**Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.**

* Keep this leaflet. You may need to read it again.
* If you have any further questions, ask your doctor or pharmacist.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.
* If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.

**If Biktarvy has been prescribed for your child, please note that all the information in this leaflet is addressed to your child (in this case please read “your child” instead of “you”).**


#### Package leaflet: Information for the user

 

**Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.**

* Keep this leaflet. You may need to read it again.
* If you have any further questions, ask your doctor or pharmacist.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.
* If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.

**If Biktarvy has been prescribed for your child, please note that all the information in this leaflet is addressed to your child (in this case please read “your child” instead of “you”).**


#### What is in this leaflet

 

What is in this leaflet

1. What Biktarvy is and what it is used for
1. What you need to know before you take Biktarvy
1. How to take Biktarvy
1. Possible side effects
1. How to store Biktarvy
1. Contents of the pack and other information


#### 1. What Biktarvy is and what it is used for

 

Biktarvy contains three active substances:

* bictegravir, an antiretroviral medicine known as an integrase strand transfer inhibitor (INSTI)
* emtricitabine, an antiretroviral medicine of a type known as a nucleoside reverse transcriptase inhibitor (NRTI)
* tenofovir alafenamide, an antiretroviral medicine of a type known as a nucleotide reverse transcriptase inhibitor (NtRTI)

Biktarvy is a single tablet for the treatment of human immunodeficiency virus 1 (HIV-1) infection in adults, adolescents and children 2 years of age and older, who weigh at least 14 kg.

Biktarvy reduces the amount of HIV in your body. This will improve your immune system and reduce the risk of developing illnesses linked to HIV infection.


#### 2. What you need to know before you take Biktarvy

 

**Do not take Biktarvy**

* If you are allergic to bictegravir, emtricitabine, tenofovir alafenamide or any of the other ingredients of this medicine (listed in section 6).
* If you are currently taking any of the following medicines:
* If any of these apply to you, **do not take Biktarvy and tell your doctor immediately.**

**Warnings and precautions**

**Talk to your doctor before taking Biktarvy:**

* If you have liver problems or a history of liver disease, including hepatitis. Patients with liver disease including chronic hepatitis B or C, who are treated with antiretrovirals, have a higher risk of severe and potentially fatal liver complications. If you have hepatitis B infection, your doctor will carefully consider the best treatment regimen for you.
* If you have hepatitis B infection. Liver problems may become worse after you stop taking Biktarvy.
* Do not stop taking Biktarvy if you have hepatitis B. Talk to your doctor first. For more details, see section 3, Do not stop taking Biktarvy.
* If you have had kidney disease or if tests have shown problems with your kidneys. Your doctor may order blood tests to monitor how your kidneys work when starting and during treatment with Biktarvy.

**While you are taking Biktarvy**

Once you start taking Biktarvy, look out for:

* Signs of inflammation or infection
* Joint pain, stiffness or bone problems

**If you notice any of these symptoms, tell your doctor immediately. For more information see section 4, Possible side effects.**

There is a possibility that you may experience kidney problems when taking Biktarvy over a long period of time (see Warnings and precautions).

This medicine is not a cure for HIV infection. While taking Biktarvy you may still develop infections or other illnesses associated with HIV infection.

**Children and adolescents**

Do not give this medicine to children under 2 years of age, or weighing less than 14 kg regardless of age. The use of Biktarvy in children under 2 years of age, or weighing less than 14 kg has not yet been studied. For children and adolescents who weigh 25 kg or more, Biktarvy 50 mg/200 mg/25 mg film-coated tablets are available.

Loss of bone mass has been reported in some children from 3 to less than 12 years of age who received one of the medicinal products (tenofovir alafenamide) contained in Biktarvy. The effects on long term bone health and future fracture risk in children is uncertain. Your doctor will monitor your child’s bone health as needed.

**Other medicines and Biktarvy**

Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines. Biktarvy may interact with other medicines. As a result, the amounts of Biktarvy or other medicines in your blood may change. This may stop your medicines from working properly, or may make any side effects worse. In some cases, your doctor may need to adjust your dose or check your blood levels.

**Medicines that must never be taken with Biktarvy:**

* rifampicin used to treat some bacterial infections such as tuberculosis
* St. John’s wort (Hypericum perforatum), a herbal remedy used for depression and anxiety, or products that contain it.
* If you are taking any of these medicines, do not take Biktarvy and tell your doctor immediately.

**Talk to your doctor if you are taking:**

* medicines used for treating HIV and/or hepatitis B, containing:
* adefovir dipivoxil, atazanavir, bictegravir, emtricitabine, lamivudine, tenofovir alafenamide, or tenofovir disoproxil

* antibiotics used to treat bacterial infections, containing:
* azithromycin, clarithromycin, rifabutin or rifapentine

* anticonvulsants used to treat epilepsy, containing:
* carbamazepine, oxcarbazepine, phenobarbital or phenytoin

* immunosuppressants used to control your body’s immune response after a transplant, containing ciclosporin
* ulcer-healing medicines containing sucralfate
* Tell your doctor if you are taking any of these medicines. Do not stop your treatment without contacting your doctor.

**Get advice from a doctor or pharmacist if you are taking:**

* antacids to treat stomach ulcers, heartburn, or acid reflux, containing aluminium and/or magnesium hydroxide
* mineral supplements or vitamins containing magnesium or iron
* Get advice from your doctor or pharmacist before taking Biktarvy if you are taking any of these medicines.

Antacids and magnesium supplements: you will need to take Biktarvy at least 2 hours before antacids or supplements containing aluminium and/or magnesium. Or you can take Biktarvy with food at least 2 hours after.

Iron supplements: you will need to take Biktarvy at least 2 hours before iron supplements, or you can take them together with food.

**Pregnancy and breast-feeding**

* If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor or pharmacist for advice before taking this medicine.
* Tell your doctor immediately if you become pregnant and ask about the potential benefits and risks of your antiretroviral therapy to you and your child.

If you have taken Biktarvy during your pregnancy, your doctor may request regular blood tests and other diagnostic tests to monitor the development of your child. In children whose mothers took nucleoside reverse transcriptase inhibitors (NRTIs) during pregnancy, the benefit from the protection against HIV outweighed the risk of side effects.

**Do not breast-feed during treatment with Biktarvy.** This is because some of the active substances in this medicine pass into human breast milk. Breast-feeding is not recommended in women living with HIV because HIV infection can be passed on to the baby in breast milk. If you are breast-feeding, or thinking about breast-feeding, you should discuss it with your doctor as soon as possible.

**Driving and using machines**

Biktarvy can cause dizziness. If you feel dizzy when taking Biktarvy, do not drive or ride a bicycle and do not use any tools or machines.

**Biktarvy contains sodium**

This medicine contains less than 1 mmol sodium (23 mg) per tablet, that is to say essentially ‘sodium-free’.


#### 3. How to take Biktarvy

 

Always take this medicine exactly as your doctor has told you. Check with your doctor or pharmacist if you are not sure.

There are two strengths of Biktarvy tablets. Your doctor will prescribe the appropriate tablet for your age and weight.

**The recommended dose is:**

Children 2 years of age and older, who weigh at least 14 kg but less than 25 kg: one tablet each day with or without food (one 30 mg/120 mg/15 mg tablet).

Due to the bitter taste, it is recommended not to chew or crush the tablet. If you have difficulty swallowing the tablet whole, you can split it in half. Take both halves of the tablet one after the other to get the full dose. Do not store the split tablet.

The score line on the tablet is only there to help you break the tablet if your child has difficulty swallowing it whole.

The 90-day multipack contains three 30-day packs together.

* Get advice from a doctor or pharmacist if you are taking:
* antacids to treat stomach ulcers, heartburn, or acid reflux, containing aluminium and/or magnesium hydroxide
* mineral supplements or vitamins containing magnesium or iron
* See section 2 for more information on taking these medicines with Biktarvy.

If you are on dialysis, take your daily dose of Biktarvy following completion of dialysis.

**If you take more Biktarvy than you should**

If you take more than the recommended dose of Biktarvy you may be at higher risk of side effects of this medicine (see section 4, Possible side effects). Contact your doctor or nearest emergency department immediately for advice. Keep or take the tablet bottle or carton with you so that you can easily describe what you have taken.

**If you forget to take Biktarvy**

It is important not to miss a dose of Biktarvy.

If you miss a dose:

* If you notice within 18 hours of the time you usually take Biktarvy, you must take the tablet as soon as possible. Then take the next dose as usual.
* If you notice 18 hours or more after the time you usually take Biktarvy, then do not take the missed dose. Wait and take the next dose at your usual time.

If you vomit less than 1 hour after taking Biktarvy, take another tablet. If you vomit more than 1 hour after taking Biktarvy you do not need to take another tablet until your next regularly scheduled tablet.

**Do not stop taking Biktarvy**

Do not stop taking Biktarvy without talking to your doctor. Stopping Biktarvy can seriously affect how future treatment works. If Biktarvy is stopped for any reason, speak to your doctor before you restart taking Biktarvy tablets.

When your supply of Biktarvy starts to run low, get more from your doctor or pharmacist. This is very important because the amount of virus may start to increase if the medicine is stopped for even a short time. The disease may then become harder to treat.

If you have both HIV infection and hepatitis B, it is especially important not to stop your Biktarvy treatment without talking to your doctor first. You may require blood tests for several months after stopping treatment. In some patients with advanced liver disease or cirrhosis, stopping treatment is not recommended as this may lead to worsening of your hepatitis, which may be life-threatening.

* Tell your doctor immediately about new or unusual symptoms after you stop treatment, particularly symptoms you associate with hepatitis B infection. If you have any further questions on the use of this medicine, ask your doctor or pharmacist.


#### 4. Possible side effects

 

Like all medicines, this medicine can cause side effects, although not everybody gets them.

**Possible side effects: tell a doctor immediately**

* Any signs of inflammation or infection. In some patients with advanced HIV infection (AIDS) and a history of opportunistic infections (infections that occur in people with a weak immune system), signs and symptoms of inflammation from previous infections may occur soon after HIV treatment is started. It is thought that these symptoms are due to an improvement in the body’s immune response, enabling the body to fight infections that may have been present with no obvious symptoms.
* Autoimmune disorders, when the immune system attacks healthy body tissue, may also occur after you start taking medicines for HIV infection. Autoimmune disorders may occur many months after the start of treatment. Look out for any symptoms of infection or other symptoms such as:
* muscle weakness
* weakness beginning in the hands and feet and moving up towards the trunk of the body
* palpitations, tremor or hyperactivity

* If you notice these or any symptoms of inflammation or infection, tell your doctor immediately.

**Common side effects** (may affect up to 1 in 10 people)

* depression
* abnormal dreams
* headache
* dizziness
* diarrhoea
* feeling sick (nausea)
* tiredness (fatigue)

**Uncommon side effects**

(may affect up to 1 in 100 people)

* anaemia
* vomiting
* stomach pain
* problems with digestion resulting in discomfort after meals (dyspepsia)
* wind (flatulence)
* swelling of the face, lips, tongue or throat (angioedema)
* itching (pruritus)
* rash
* hives (urticaria)
* joint pain (arthralgia)
* suicidal thoughts and suicide attempt (particularly in patients who have had depression or mental health problems before)
* anxiety
* sleep disorders Blood tests may also show:
* higher levels of substances called bilirubin and/or serum creatinine in the blood

**Rare side effects**

(may affect up to 1 in 1000 people)

* Stevens-Johnson syndrome (SJS) is a serious life-threatening condition which usually starts with flu- like symptoms. A few days later other symptoms appear including:
* Painful red or purple skin that looks burned and peels off
* Blisters on your skin, mouth, nose, and genitals
* Red, painful, watery eyes

* If you have any of these symptoms, stop your medicine immediately and tell your doctor straight away.
* If any of the side effects get serious, tell your doctor.

**Other effects that may be seen during HIV treatment**

The frequency of the following side effects is not known (frequency cannot be estimated from the available data).

* Bone problems. Some patients taking combination antiretroviral medicines such as Biktarvy may develop a bone disease called osteonecrosis (death of bone tissue caused by loss of blood supply to the bone). Taking this type of medicine for a long time, taking corticosteroids, drinking alcohol, having a very weak immune system, and being overweight, may be some of the many risk factors for developing this disease. Signs of osteonecrosis are:
* joint stiffness
* joint aches and pains (especially of the hip, knee and shoulder)
* difficulty with movement

* If you notice any of these symptoms tell your doctor.

During HIV therapy there may be an increase in weight and in levels of blood lipids and glucose. This is partly linked to restored health and life style, and in the case of blood lipids sometimes to the HIV medicines themselves. Your doctor will test for these changes.

**Reporting of side effects** If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the national reporting system listed in Appendix V. By reporting side effects you can help provide more information on the safety of this medicine.


#### 5. How to store Biktarvy

 

Keep this medicine out of the sight and reach of children.

Do not use this medicine after the expiry date which is stated on the carton and bottle or blister strips after {EXP}. The expiry date refers to the last day of that month.

Store in the original package in order to protect from moisture. Keep the bottle tightly closed. Do not use if the seal over the bottle opening is broken or missing.

Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.


#### 6. Contents of the pack and other information

 

**What Biktarvy contains**

The active substances are bictegravir, emtricitabine and tenofovir alafenamide. Each Biktarvy tablet contains bictegravir sodium equivalent to 30 mg of bictegravir, 120 mg of emtricitabine and tenofovir alafenamide fumarate equivalent to 15 mg of tenofovir alafenamide.

**The other ingredients are****Tablet core**Microcrystalline cellulose (E460), croscarmellose sodium (E468), magnesium stearate (E470b).

**Film-coating**Polyvinyl alcohol (E203), titanium dioxide (E171), macrogol (E1521), talc (E553b), iron oxide red (E172), iron oxide black (E172).

**What Biktarvy looks like and contents of the pack**

Biktarvy 30 mg/120 mg/15 mg film-coated tablets are pink, capsule-shaped, film-coated tablets, debossed with “BVY” on one side and a score line on the other side of the tablet.

The tablets are supplied in a bottle. Not all pack sizes may be marketed.

Biktarvy comes in bottles of 30 tablets and in packs made up of 3 bottles, each containing 30 tablets. Each bottle contains a silica gel desiccant that must be kept in the bottle to help protect your tablets. The silica gel desiccant is contained in a separate sachet or canister and should not be swallowed.


####  Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 
PMSWI:
** EU/1/18/1289/001 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E827gy **
-------

Full name: **Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion**

 - Invented name part: ** Biktarvy ** 

 - Scientific name part: ** bictegravir/emtricitabine/tenofovir alafenamide ** 

 - Strength part: ** 50 mg/200 mg/25 mg ** 

 - Pharmaceutical dose form part: ** film-coated tablets ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/18/1289/001 ** 

 Region: ** ** 

Marketing authorisation holder: **Gilead Sciences Ireland UC** 

 Identifier: 
*  **ORG-100008368** 
 

 Status: ** Active (2018-06-21T13:28:17Z) ** 

 Package 1 of 2

PMSWI: ** EU/1/18/1289/001 ** 

GTIN: ** 07612345678904 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **90 Child-resistant closure** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Child-resistant closure** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

 Package 2 of 2

PMSWI: ** EU/1/18/1289/001 ** 

Description:

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-en-94a96e39cfdcd8b378d12dd4063065f9",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/18/1289/001"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-en-2a9c4333cfd126f2e7b73ad3cafd6949",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-en-2a9c4333cfd126f2e7b73ad3cafd6949",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_composition-en-2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-en-2a9c4333cfd126f2e7b73ad3cafd6949</b></p><a name=\"composition-en-2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><a name=\"hccomposition-en-2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/c97bc0c62de4cf4143e63299ba73c5a3</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mah-715f8a161ed438d0584510e5b4512caa\">Organization Gilead Sciences Ireland UC</a></p><p><b>title</b>: TEST PURPOSES ONLY - Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "c97bc0c62de4cf4143e63299ba73c5a3"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-715f8a161ed438d0584510e5b4512caa"
      }],
      "title" : "TEST PURPOSES ONLY - Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. Package Leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.</strong></p><ul><li>Keep this leaflet. You may need to read it again.</li><li>If you have any further questions, ask your doctor or pharmacist.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.</li><li>If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.</li></ul><p><strong>If Biktarvy has been prescribed for your child, please note that all the information in this leaflet is addressed to your child (in this case please read “your child” instead of “you”).</strong></p></div>"
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.</strong></p><ul><li>Keep this leaflet. You may need to read it again.</li><li>If you have any further questions, ask your doctor or pharmacist.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.</li><li>If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.</li></ul><p><strong>If Biktarvy has been prescribed for your child, please note that all the information in this leaflet is addressed to your child (in this case please read “your child” instead of “you”).</strong></p></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>What is in this leaflet</p><ol><li>What Biktarvy is and what it is used for</li><li>What you need to know before you take Biktarvy</li><li>How to take Biktarvy</li><li>Possible side effects</li><li>How to store Biktarvy</li><li>Contents of the pack and other information</li></ol></div>"
          }
        },
        {
          "title" : "1. What Biktarvy is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What Biktarvy is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Biktarvy contains three active substances:</p><ul><li>bictegravir, an antiretroviral medicine known as an integrase strand transfer inhibitor (INSTI)</li><li>emtricitabine, an antiretroviral medicine of a type known as a nucleoside reverse transcriptase inhibitor (NRTI)</li><li>tenofovir alafenamide, an antiretroviral medicine of a type known as a nucleotide reverse transcriptase inhibitor (NtRTI)</li></ul><p>Biktarvy is a single tablet for the treatment of human immunodeficiency virus 1 (HIV-1) infection in adults, adolescents and children 2 years of age and older, who weigh at least 14 kg.</p><p>Biktarvy reduces the amount of HIV in your body. This will improve your immune system and reduce the risk of developing illnesses linked to HIV infection.</p></div>"
          }
        },
        {
          "title" : "2. What you need to know before you take Biktarvy",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take Biktarvy"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Do not take Biktarvy</strong></p><ul><li>If you are allergic to bictegravir, emtricitabine, tenofovir alafenamide or any of the other ingredients of this medicine (listed in section 6).</li><li><p>If you are currently taking any of the following medicines:</p><ul><li>rifampicin used to treat some bacterial infections such as tuberculosis</li><li>St. John’s wort (Hypericum perforatum), a herbal remedy used for depression and anxiety, or products that contain it.</li></ul></li><li><p>If any of these apply to you, <strong>do not take Biktarvy and tell your doctor immediately.</strong></p></li></ul><p><strong>Warnings and precautions</strong></p><p><strong>Talk to your doctor before taking Biktarvy:</strong></p><ul><li>If you have liver problems or a history of liver disease, including hepatitis. Patients with liver disease including chronic hepatitis B or C, who are treated with antiretrovirals, have a higher risk of severe and potentially fatal liver complications. If you have hepatitis B infection, your doctor will carefully consider the best treatment regimen for you.</li><li><p>If you have hepatitis B infection. Liver problems may become worse after you stop taking Biktarvy.</p></li><li><p>Do not stop taking Biktarvy if you have hepatitis B. Talk to your doctor first. For more details, see section 3, Do not stop taking Biktarvy.</p></li><li><p>If you have had kidney disease or if tests have shown problems with your kidneys. Your doctor may order blood tests to monitor how your kidneys work when starting and during treatment with Biktarvy.</p></li></ul><p><strong>While you are taking Biktarvy</strong></p><p>Once you start taking Biktarvy, look out for:</p><ul><li>Signs of inflammation or infection</li><li>Joint pain, stiffness or bone problems</li></ul><p><strong>If you notice any of these symptoms, tell your doctor immediately. For more information see section 4, Possible side effects.</strong></p><p>There is a possibility that you may experience kidney problems when taking Biktarvy over a long period of time (see Warnings and precautions).</p><p>This medicine is not a cure for HIV infection. While taking Biktarvy you may still develop infections or other illnesses associated with HIV infection.</p><p><strong>Children and adolescents</strong></p><p>Do not give this medicine to children under 2 years of age, or weighing less than 14 kg regardless of age. The use of Biktarvy in children under 2 years of age, or weighing less than 14 kg has not yet been studied. For children and adolescents who weigh 25 kg or more, Biktarvy 50 mg/200 mg/25 mg film-coated tablets are available.</p><p>Loss of bone mass has been reported in some children from 3 to less than 12 years of age who received one of the medicinal products (tenofovir alafenamide) contained in Biktarvy. The effects on long term bone health and future fracture risk in children is uncertain. Your doctor will monitor your child’s bone health as needed.</p><p><strong>Other medicines and Biktarvy</strong></p><p>Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines. Biktarvy may interact with other medicines. As a result, the amounts of Biktarvy or other medicines in your blood may change. This may stop your medicines from working properly, or may make any side effects worse. In some cases, your doctor may need to adjust your dose or check your blood levels.</p><p><strong>Medicines that must never be taken with Biktarvy:</strong></p><ul><li>rifampicin used to treat some bacterial infections such as tuberculosis</li><li>St. John’s wort (Hypericum perforatum), a herbal remedy used for depression and anxiety, or products that contain it.</li><li>If you are taking any of these medicines, do not take Biktarvy and tell your doctor immediately.</li></ul><p><strong>Talk to your doctor if you are taking:</strong></p><ul><li>medicines used for treating HIV and/or hepatitis B, containing:<ul><li>adefovir dipivoxil, atazanavir, bictegravir, emtricitabine, lamivudine, tenofovir alafenamide, or tenofovir disoproxil</li></ul></li><li>antibiotics used to treat bacterial infections, containing:<ul><li>azithromycin, clarithromycin, rifabutin or rifapentine</li></ul></li><li>anticonvulsants used to treat epilepsy, containing:<ul><li>carbamazepine, oxcarbazepine, phenobarbital or phenytoin</li></ul></li><li>immunosuppressants used to control your body’s immune response after a transplant, containing ciclosporin</li><li><p>ulcer-healing medicines containing sucralfate</p></li><li><p>Tell your doctor if you are taking any of these medicines. Do not stop your treatment without contacting your doctor.</p></li></ul><p><strong>Get advice from a doctor or pharmacist if you are taking:</strong></p><ul><li>antacids to treat stomach ulcers, heartburn, or acid reflux, containing aluminium and/or magnesium hydroxide</li><li>mineral supplements or vitamins containing magnesium or iron</li><li>Get advice from your doctor or pharmacist before taking Biktarvy if you are taking any of these medicines.</li></ul><p>Antacids and magnesium supplements: you will need to take Biktarvy at least 2 hours before antacids or supplements containing aluminium and/or magnesium. Or you can take Biktarvy with food at least 2 hours after.</p><p>Iron supplements: you will need to take Biktarvy at least 2 hours before iron supplements, or you can take them together with food.</p><p><strong>Pregnancy and breast-feeding</strong></p><ul><li>If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor or pharmacist for advice before taking this medicine.</li><li>Tell your doctor immediately if you become pregnant and ask about the potential benefits and risks of your antiretroviral therapy to you and your child.</li></ul><p>If you have taken Biktarvy during your pregnancy, your doctor may request regular blood tests and other diagnostic tests to monitor the development of your child. In children whose mothers took nucleoside reverse transcriptase inhibitors (NRTIs) during pregnancy, the benefit from the protection against HIV outweighed the risk of side effects.</p><p><strong>Do not breast-feed during treatment with Biktarvy.</strong> This is because some of the active substances in this medicine pass into human breast milk. Breast-feeding is not recommended in women living with HIV because HIV infection can be passed on to the baby in breast milk. If you are breast-feeding, or thinking about breast-feeding, you should discuss it with your doctor as soon as possible.</p><p><strong>Driving and using machines</strong></p><p>Biktarvy can cause dizziness. If you feel dizzy when taking Biktarvy, do not drive or ride a bicycle and do not use any tools or machines.</p><p><strong>Biktarvy contains sodium</strong></p><p>This medicine contains less than 1 mmol sodium (23 mg) per tablet, that is to say essentially ‘sodium-free’.</p></div>"
          }
        },
        {
          "title" : "3. How to take Biktarvy",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take Biktarvy"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Always take this medicine exactly as your doctor has told you. Check with your doctor or pharmacist if you are not sure.</p><p>There are two strengths of Biktarvy tablets. Your doctor will prescribe the appropriate tablet for your age and weight.</p><p><strong>The recommended dose is:</strong></p><p>Children 2 years of age and older, who weigh at least 14 kg but less than 25 kg: one tablet each day with or without food (one 30 mg/120 mg/15 mg tablet).</p><p>Due to the bitter taste, it is recommended not to chew or crush the tablet. If you have difficulty swallowing the tablet whole, you can split it in half. Take both halves of the tablet one after the other to get the full dose. Do not store the split tablet.</p><p>The score line on the tablet is only there to help you break the tablet if your child has difficulty swallowing it whole.</p><p>The 90-day multipack contains three 30-day packs together.</p><ul><li>Get advice from a doctor or pharmacist if you are taking:</li><li>antacids to treat stomach ulcers, heartburn, or acid reflux, containing aluminium and/or magnesium hydroxide</li><li>mineral supplements or vitamins containing magnesium or iron</li><li>See section 2 for more information on taking these medicines with Biktarvy.</li></ul><p>If you are on dialysis, take your daily dose of Biktarvy following completion of dialysis.</p><p><strong>If you take more Biktarvy than you should</strong></p><p>If you take more than the recommended dose of Biktarvy you may be at higher risk of side effects of this medicine (see section 4, Possible side effects). Contact your doctor or nearest emergency department immediately for advice. Keep or take the tablet bottle or carton with you so that you can easily describe what you have taken.</p><p><strong>If you forget to take Biktarvy</strong></p><p>It is important not to miss a dose of Biktarvy.</p><p>If you miss a dose:</p><ul><li>If you notice within 18 hours of the time you usually take Biktarvy, you must take the tablet as soon as possible. Then take the next dose as usual.</li><li>If you notice 18 hours or more after the time you usually take Biktarvy, then do not take the missed dose. Wait and take the next dose at your usual time.</li></ul><p>If you vomit less than 1 hour after taking Biktarvy, take another tablet. If you vomit more than 1 hour after taking Biktarvy you do not need to take another tablet until your next regularly scheduled tablet.</p><p><strong>Do not stop taking Biktarvy</strong></p><p>Do not stop taking Biktarvy without talking to your doctor. Stopping Biktarvy can seriously affect how future treatment works. If Biktarvy is stopped for any reason, speak to your doctor before you restart taking Biktarvy tablets.</p><p>When your supply of Biktarvy starts to run low, get more from your doctor or pharmacist. This is very important because the amount of virus may start to increase if the medicine is stopped for even a short time. The disease may then become harder to treat.</p><p>If you have both HIV infection and hepatitis B, it is especially important not to stop your Biktarvy treatment without talking to your doctor first. You may require blood tests for several months after stopping treatment. In some patients with advanced liver disease or cirrhosis, stopping treatment is not recommended as this may lead to worsening of your hepatitis, which may be life-threatening.</p><ul><li>Tell your doctor immediately about new or unusual symptoms after you stop treatment, particularly symptoms you associate with hepatitis B infection. If you have any further questions on the use of this medicine, ask your doctor or pharmacist.</li></ul></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Like all medicines, this medicine can cause side effects, although not everybody gets them.</p><p><strong>Possible side effects: tell a doctor immediately</strong></p><ul><li>Any signs of inflammation or infection. In some patients with advanced HIV infection (AIDS) and a history of opportunistic infections (infections that occur in people with a weak immune system), signs and symptoms of inflammation from previous infections may occur soon after HIV treatment is started. It is thought that these symptoms are due to an improvement in the body’s immune response, enabling the body to fight infections that may have been present with no obvious symptoms.</li><li>Autoimmune disorders, when the immune system attacks healthy body tissue, may also occur after you start taking medicines for HIV infection. Autoimmune disorders may occur many months after the start of treatment. Look out for any symptoms of infection or other symptoms such as:<ul><li>muscle weakness</li><li>weakness beginning in the hands and feet and moving up towards the trunk of the body</li><li>palpitations, tremor or hyperactivity</li></ul></li><li>If you notice these or any symptoms of inflammation or infection, tell your doctor immediately.</li></ul><p><strong>Common side effects</strong> (may affect up to 1 in 10 people)</p><ul><li>depression</li><li>abnormal dreams</li><li>headache</li><li>dizziness</li><li>diarrhoea</li><li>feeling sick (nausea)</li><li>tiredness (fatigue)</li></ul><p><strong>Uncommon side effects</strong></p><p>(may affect up to 1 in 100 people)</p><ul><li>anaemia</li><li>vomiting</li><li>stomach pain</li><li>problems with digestion resulting in discomfort after meals (dyspepsia)</li><li>wind (flatulence)</li><li>swelling of the face, lips, tongue or throat (angioedema)</li><li>itching (pruritus)</li><li>rash</li><li>hives (urticaria)</li><li>joint pain (arthralgia)</li><li>suicidal thoughts and suicide attempt (particularly in patients who have had depression or mental health problems before)</li><li>anxiety</li><li>sleep disorders Blood tests may also show:</li><li>higher levels of substances called bilirubin and/or serum creatinine in the blood</li></ul><p><strong>Rare side effects</strong></p><p>(may affect up to 1 in 1000 people)</p><ul><li>Stevens-Johnson syndrome (SJS) is a serious life-threatening condition which usually starts with flu- like symptoms. A few days later other symptoms appear including:<ul><li>Painful red or purple skin that looks burned and peels off</li><li>Blisters on your skin, mouth, nose, and genitals</li><li>Red, painful, watery eyes</li></ul></li><li>If you have any of these symptoms, stop your medicine immediately and tell your doctor straight away.</li><li>If any of the side effects get serious, tell your doctor.</li></ul><p><strong>Other effects that may be seen during HIV treatment</strong></p><p>The frequency of the following side effects is not known (frequency cannot be estimated from the available data).</p><ul><li>Bone problems. Some patients taking combination antiretroviral medicines such as Biktarvy may develop a bone disease called osteonecrosis (death of bone tissue caused by loss of blood supply to the bone). Taking this type of medicine for a long time, taking corticosteroids, drinking alcohol, having a very weak immune system, and being overweight, may be some of the many risk factors for developing this disease. Signs of osteonecrosis are:<ul><li>joint stiffness</li><li>joint aches and pains (especially of the hip, knee and shoulder)</li><li>difficulty with movement</li></ul></li><li>If you notice any of these symptoms tell your doctor.</li></ul><p>During HIV therapy there may be an increase in weight and in levels of blood lipids and glucose. This is partly linked to restored health and life style, and in the case of blood lipids sometimes to the HIV medicines themselves. Your doctor will test for these changes.</p><p><strong>Reporting of side effects</strong> If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the national reporting system listed in Appendix V. By reporting side effects you can help provide more information on the safety of this medicine.</p></div>"
          }
        },
        {
          "title" : "5. How to store Biktarvy",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store Biktarvy"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keep this medicine out of the sight and reach of children.</p><p>Do not use this medicine after the expiry date which is stated on the carton and bottle or blister strips after {EXP}. The expiry date refers to the last day of that month.</p><p>Store in the original package in order to protect from moisture. Keep the bottle tightly closed. Do not use if the seal over the bottle opening is broken or missing.</p><p>Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>What Biktarvy contains</strong></p><p>The active substances are bictegravir, emtricitabine and tenofovir alafenamide. Each Biktarvy tablet contains bictegravir sodium equivalent to 30 mg of bictegravir, 120 mg of emtricitabine and tenofovir alafenamide fumarate equivalent to 15 mg of tenofovir alafenamide.</p><p><strong>The other ingredients are</strong><em>Tablet core</em>Microcrystalline cellulose (E460), croscarmellose sodium (E468), magnesium stearate (E470b).</p><p><em>Film-coating</em>Polyvinyl alcohol (E203), titanium dioxide (E171), macrogol (E1521), talc (E553b), iron oxide red (E172), iron oxide black (E172).</p><p><strong>What Biktarvy looks like and contents of the pack</strong></p><p>Biktarvy 30 mg/120 mg/15 mg film-coated tablets are pink, capsule-shaped, film-coated tablets, debossed with “BVY” on one side and a score line on the other side of the tablet.</p><p>The tablets are supplied in a bottle. Not all pack sizes may be marketed.</p><p>Biktarvy comes in bottles of 30 tablets and in packs made up of 3 bottles, each containing 30 tablets. Each bottle contains a silica gel desiccant that must be kept in the bottle to help protect your tablets. The silica gel desiccant is contained in a separate sachet or canister and should not be swallowed.</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-d79af6e660f456c6c7091803d6bd1a92",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-d79af6e660f456c6c7091803d6bd1a92",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-d79af6e660f456c6c7091803d6bd1a92\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-d79af6e660f456c6c7091803d6bd1a92</b></p><a name=\"cud-d79af6e660f456c6c7091803d6bd1a92\"> </a><a name=\"hccud-d79af6e660f456c6c7091803d6bd1a92\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/pregnancy (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr nan}\">nan</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "pregnancy"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "nan",
              "display" : "nan"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-bictegravirsodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-bictegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-bictegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-bictegravirsodium</b></p><a name=\"ingredient-for-biktarvy-bictegravirsodium\"> </a><a name=\"hcingredient-for-biktarvy-bictegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/4L5MP1Y7W7 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 4L5MP1Y7W7}\">BICTEGRAVIR SODIUM</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>50 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "4L5MP1Y7W7"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "4L5MP1Y7W7",
              "display" : "BICTEGRAVIR SODIUM"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 50,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-emtricitabine",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-emtricitabine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-emtricitabine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-emtricitabine</b></p><a name=\"ingredient-for-biktarvy-emtricitabine\"> </a><a name=\"hcingredient-for-biktarvy-emtricitabine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/G70B4ETF4S (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta G70B4ETF4S}\">Emtricitabine</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>200 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "G70B4ETF4S"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "G70B4ETF4S",
              "display" : "Emtricitabine"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 200,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-tenofoviralafenamide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-tenofoviralafenamide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-tenofoviralafenamide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-tenofoviralafenamide</b></p><a name=\"ingredient-for-biktarvy-tenofoviralafenamide\"> </a><a name=\"hcingredient-for-biktarvy-tenofoviralafenamide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EL9943AG5J (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EL9943AG5J}\">tenofovir alafenamide</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>25 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EL9943AG5J"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EL9943AG5J",
              "display" : "tenofovir alafenamide"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 25,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-microcrystallinecellulose</b></p><a name=\"ingredient-for-biktarvy-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-biktarvy-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">Microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "Microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-croscarmellosesodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-croscarmellosesodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-croscarmellosesodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-croscarmellosesodium</b></p><a name=\"ingredient-for-biktarvy-croscarmellosesodium\"> </a><a name=\"hcingredient-for-biktarvy-croscarmellosesodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/M28OL1HH48 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta M28OL1HH48}\">Croscarmellose sodium</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "M28OL1HH48"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "M28OL1HH48",
              "display" : "Croscarmellose sodium"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-magnesiumstearate</b></p><a name=\"ingredient-for-biktarvy-magnesiumstearate\"> </a><a name=\"hcingredient-for-biktarvy-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-94a96e39cfdcd8b378d12dd4063065f9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-94a96e39cfdcd8b378d12dd4063065f9</b></p><a name=\"ap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><a name=\"hcap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization94a96e39cfdcd8b378d12dd4063065f90",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization94a96e39cfdcd8b378d12dd4063065f90",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization94a96e39cfdcd8b378d12dd4063065f90</b></p><a name=\"authorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><a name=\"hcauthorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2018-06-21 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mah-715f8a161ed438d0584510e5b4512caa\">Organization Gilead Sciences Ireland UC</a></p><p><b>regulator</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mra-1133a7374c78f1d40f41885344f06a5a\">Organization European Medicines Agency</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2018-06-21T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-715f8a161ed438d0584510e5b4512caa"
      },
      "regulator" : {
        "reference" : "Organization/mra-1133a7374c78f1d40f41885344f06a5a"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-715f8a161ed438d0584510e5b4512caa",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-715f8a161ed438d0584510e5b4512caa",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-715f8a161ed438d0584510e5b4512caa\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-715f8a161ed438d0584510e5b4512caa</b></p><a name=\"mah-715f8a161ed438d0584510e5b4512caa\"> </a><a name=\"hcmah-715f8a161ed438d0584510e5b4512caa\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100008368 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Gilead Sciences Ireland UC</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carrigtohill, County Cork, T45 County Cork IR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100008368"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Gilead Sciences Ireland UC",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carrigtohill, County Cork, T45 County Cork IR",
          "line" : ["Carrigtohill, County Cork, T45"],
          "city" : "County Cork",
          "country" : "IR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mra-1133a7374c78f1d40f41885344f06a5a",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mra-1133a7374c78f1d40f41885344f06a5a",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mra-1133a7374c78f1d40f41885344f06a5a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mra-1133a7374c78f1d40f41885344f06a5a</b></p><a name=\"mra-1133a7374c78f1d40f41885344f06a5a\"> </a><a name=\"hcmra-1133a7374c78f1d40f41885344f06a5a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100013412 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000032}\">Medicines Regulatory Authority</span></p><p><b>name</b>: European Medicines Agency</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100013412"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000032",
          "display" : "Medicines Regulatory Authority"
        }]
      }],
      "name" : "European Medicines Agency",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL",
          "line" : ["Carretera De Martorell 41 61, Poligono Industrial Nord-Est"],
          "city" : "Amsterdam",
          "postalCode" : "1083 HS",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-e34e4b65abd3fd8e667db05606cc25a9",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-e34e4b65abd3fd8e667db05606cc25a9",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-e34e4b65abd3fd8e667db05606cc25a9</b></p><a name=\"ppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><a name=\"hcppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, ), Gtin/07612345678904 (use: official, )</p><p><b>name</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 90</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 90</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      },
      {
        "use" : "official",
        "system" : "https://www.gs1.org/gtin",
        "value" : "07612345678904"
      }],
      "name" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 90",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 90,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-6d93344139a7793e7b9bd0f5e32b6c91",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-6d93344139a7793e7b9bd0f5e32b6c91",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-6d93344139a7793e7b9bd0f5e32b6c91</b></p><a name=\"ppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><a name=\"hcppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>name</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "name" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp2a9c4333cfd126f2e7b73ad3cafd6949",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp2a9c4333cfd126f2e7b73ad3cafd6949</b></p><a name=\"mp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><a name=\"hcmp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E827gy</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Biktarvy</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: bictegravir/emtricitabine/tenofovir alafenamide</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 50 mg/200 mg/25 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E827gy"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Biktarvy",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "bictegravir/emtricitabine/tenofovir alafenamide",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "50 mg/200 mg/25 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "film-coated tablets",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-94a96e39cfdcd8b378d12dd4063065f9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-94a96e39cfdcd8b378d12dd4063065f9</b></p><a name=\"mid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><a name=\"hcmid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      }
    }
  }]
}

```
