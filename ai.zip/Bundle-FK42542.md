# FK42542 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK42542**

## Example Bundle: FK42542

**Composition category:**

**Composition status:**final

### Indlægsseddel: Information til patienten

 

## Indlægsseddel: Information til brugeren

### Cortiment, depottabletter

Budesonid

### Læs denne indlægsseddel grundigt, inden du begynder at bruge dette lægemiddel, da den indeholder vigtige oplysninger.

* Gem indlægssedlen. Du kan få brug for at læse den igen.
* Spørg lægen, hvis der er mere, du vil vide.
* Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.
* Kontakt lægen, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt her. Se [afsnit 4](#Section4).

Se den nyeste indlægsseddel på
[www.indlaegsseddel.dk](https://www.indlaegsseddel.dk).

### Oversigt over indlægssedlen:

1. Virkning og anvendelse
1. Det skal du vide, før du begynder at bruge Cortiment
1. Sådan skal du bruge Cortiment
1. Bivirkninger
1. Opbevaring
1. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

 

## 1. Virkning og anvendelse

Cortiment depottabletter indeholder det aktive stof kaldet budesonid. Budesonid tilhører en gruppe af lægemidler kaldet kortikosteroider, som anvendes til at reducere inflammation.

 

Cortiment depottabletter anvendes til voksne til behandling af:

* colitis ulcerosa, som er inflammation i tyktarmen (kolon) og endetarmen (rectum)
* akutte episoder af mikroskopisk colitis, som er en sygdom med kronisk inflammation i tyktarmen (kolon) typisk med kronisk vandig diarré.


#### 2. Det skal du vide, før du begynder at bruge Cortiment

 

 

## 2. Det skal du vide, før du begynder at bruge Cortiment

Lægen kan have foreskrevet anden anvendelse eller dosering end angivet i denne information. Følg altid lægens anvisning og oplysningerne på doseringsetiketten.

### Brug ikke Cortiment

Hvis du er allergisk over for budesonid eller et af de øvrige indholdsstoffer i Cortiment (angivet i
[afsnit 6](#Section6)).

 

Hvis du er allergisk over for jordnødder eller soja, idet Cortiment depottabletter indeholder lecithin, udvundet fra sojaolie.

### Advarsler og forsigtighedsregler

Sig det til lægen, hvis du oplever sløret syn eller andre synsforstyrrelser.

 

Kontakt lægen, før du bruger Cortiment.

* Hvis du har en infektion, såsom en virusinfektion, en bakteriel infektion eller en svampeinfektion.
* Hvis du har haft højt blodtryk.
* Hvis du har diabetes.
* Hvis du har haft knogleskørhed.
* Hvis du har haft mavesår.
* Hvis du har haft grøn stær (glaukom) eller grå stær (katarakt).
* Hvis et familiemedlem har diabetes eller grøn stær (glaukom).
* Hvis du har haft leversygdom.
* Hvis du skifter fra anden kortison behandling til Cortiment, da det kan resultere i f.eks. smerter i muskler og led, træthed, hovedpine, kvalme og opkastning.
* Hvis du ved, du skal vaccineres
* Hvis du er blevet behandlet med et stærkere kortison præparat inden behandlingsstart med Cortiment, kan dine symptomer komme igen.
* Hvis du får en infektion under behandlingen, kan Cortiment skjule tegn på infektion og infektionen kan forværres. Du kan være mere modtagelig for infektioner under behandling med Cortiment, da din krops modstand mod infektioner kan være nedsat.
* Hvis du skal opereres snarest eller hvis du udsættes for anden stress.
* Hvis du endnu ikke har haft mæslinger eller skoldkopper.
* Når du bruger Cortiment depottabletter, forsøg at undgå kontakt med personer med mæslinger eller skoldkopper. Informer din læge, hvis du tror at du er blevet smittet med mæslinger eller skoldkopper, mens du tager denne medicin.
* Hvis du eller et familiemedlem har haft mentale helbredsproblemer.

 

At tage kortison præparater i høje doser og over en længere periode kan påvirke alle dele af kroppen og i meget sjældne tilfælde psykologiske problemer (se
[afsnit 4.](#Section4)Bivirkninger).

 

Kontakt lægen, før du bruger Cortiment depottabletter, hvis du er i tvivl om, hvorvidt noget af ovenstående gælder for dig.

### Brug af anden medicin sammen med Cortiment

Fortæl det altid til lægen hvis du bruger anden medicin eller har gjort det for nylig. Det gælder også medicin, som ikke er købt på recept. Dette er nødvendigt da Cortiment depottabletter påvirker, hvordan noget medicin virker og nogle lægemidler kan påvirke, hvordan Cortiment depottablet virker. Nogle lægemidler kan øge virkningen af Cortiment, og din læge vil overvåge dig omhyggeligt, hvis du tager sådanne lægemidler (inklusive visse former for HIV-medicin; ritonavir, cobicistat).

Det er særlig vigtigt at du fortæller din læge, hvis du tager, for nylig har taget eller har tænkt at tage et af følgende lægemidler:

* Ketoconazol eller itraconazol, som er lægemidler, der anvendes til behandling af svampeinfektioner;
* medicin brugt til HIV behandling (såsom ritonavir, nelfinavir, cobicistat-holdige lægemidler);
* Carbamazepin, som anvendes til behandling af epilepsi;
* Hjerteglykosider og diuretika (vanddrivende lægemidler);
* Lægemidler der indeholder østrogener, såsom hormonbehandling (HRT) og nogle orale præventionsmidler;
* Steroider, såsom prednisolon eller dexamethason;
* Cholestyramin, som bruges til at sænke kolesterolniveau eller behandle kløe forårsaget af leverproblemer eller syreneutraliserende middel (antacida).

### Brug af Cortiment sammen med mad, drikke og alkohol

Du må ikke drikke grapefrugtjuice, når du tager Cortiment depottabletter. Dette kan påvirke måden som medicinen virker på.

### Graviditet, amning og frugtbarhed

Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge til råds, før du bruger dette lægemiddel.

### Trafik- og arbejdssikkerhed

Det er usandsynligt, at Cortiment depottabletter vil påvirke din evne til at køre eller betjene maskiner. Der bør udvises forsigtighed, fordi denne type medicin til tider kan medføre svimmelhed eller træthed.

### Cortiment depottabletter indeholder lactose og lecithin (sojaolie)

Cortiment depottabletter indeholder lactose, en form for sukker. Du skal kontakte din læge, hvis du har fået at vide af din læge, at du ikke tåler visse sukkerarter, før du tager dette lægemiddel.

Cortiment depottabletter indeholder lecithin (sojaolie). Brug ikke dette lægemiddel hvis du er allergisk over for jordnødder eller soja.


#### 3. Sådan skal du bruge Cortiment

 

 

## 3. Sådan skal du bruge Cortiment

Brug altid Cortiment nøjagtigt efter lægens anvisning. Er du i tvivl, så spørg lægen.

 

* Den sædvanlige dosis for colitis ulcerosa og mikroskopisk colitis er èn tablet om morgenen før eller sammen med et måltid.
* Synk tabletten hel med et glas vand; tabletten må ikke deles, knuses eller tygges.
* Normalt vil du tage denne medicin dagligt i højst otte uger. Din læge kan derefter gradvist sænke antallet af gange, du skal tage medicinen.
* Fortsæt med at tage Cortiment depottabletter, efter lægens anvisning også selvom du begynder at føle bedring.

### Yderligere oplysninger, når du tager Cortiment depottabletter

Hvis du snart skal opereres, eller udsættes for anden stressende påvirkning, kan lægen bede dig om at tage steroid tabletter. Dette er især tilfældet, hvis du har taget høje doser af Cortiment depottabletter eller lignende medicin i lang tid.

 

**Brug til patienter med nedsat nyre- eller leverfunktion**

Cortiment depottabletter er ikke undersøgt specifikt for patienter med nyre eller lever problemer. Kontakt din læge.

 

**Brug til børn**

Cortiment depottabletter anbefales ikke til børn.

### Hvis du har taget for meget Cortiment

Informer straks din læge, hvis du har taget flere Cortiment depottabletter, end du burde.

### Hvis du har glemt at tage Cortiment

* Hvis du glemmer at tage en Cortiment depottablet, skal du tage den så snart, du husker det. Hvis det er tæt på din næste dosis, skal du springe den glemte dosis over.
* Du må ikke tage en dobbeltdosis som erstatning for den glemte tablet.

### Hvis du holder op med at tage Cortiment

Du må ikke stoppe med at tage Cortiment depottabletter uden først at have aftalt det med din læge. Det kan være nødvendigt gradvist at nedtrappe behandlingen. Hvis du pludselig stopper med at tage medicinen, kan du blive syg.

Spørg lægen, hvis der er noget, du er i tvivl om.


#### 4. Bivirkninger

 

 

## 4. Bivirkninger

Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger.

### Hvis du har fået en allergisk reaktion, skal du straks kontakte din læge eller ringe for akut hjælp. Tegn kan omfatte nældefeber eller hævelse af ansigt, læber, mund, tunge og hals. Dette kan gøre det vanskeligt at trække vejret.

Følgende bivirkninger kan forekomme, når du tager Cortiment depottabletter, de fleste bivirkninger nævnt kan også forventes ved behandling med andre steroider.

 

**Almindelig (kan påvirke op til 1 ud af 10 personer)**

* Cushing-lignende symptomer, såsom et rundt ansigt (måneansigt), akne, vægtøgning og en tendens til lettere at få blå mærker
* Lavt kalium niveau i blodet, hvilket kan forårsage muskelsvaghed eller træthed, tørst eller en prikkende fornemmelse
* Ændring i adfærd, såsom nervøsitet, søvnløshed eller humørsvingninger
* Depression
* Hovedpine
* Hjertebanken
* Kvalme
* Mavesmerter
* Oppustet mave
* Tør mund
* Fordøjelsesbesvær (dyspepsi)
* Hududslæt eller kløe
* Akne
* Muskel smerter, muskel kramper
* Kraftig eller uregelmæssig menstruation hos kvinder
* Ekstrem træthed (fatigue)
* Nedsat mængde af hormonet kortisol i blodet.

 

**Ikke almindelig (kan påvirke op til 1 ud af 100 personer)**

* Influenza
* Øget antal hvide blodceller
* Ændring i adfærd, som humørsvingninger
* Følelse af uro med hyperaktivitet
* Angst
* Svimmelhed
* Rysten
* Flatulens
* Rygsmerter
* Muskel spasmer
* Hævelse i benene

 

**Sjælden (kan påvirke op til 1 ud af 1.000 personer)**

* Aggression
* Glaukom (Grøn stær; øget tryk i øjet)
* Grå stær (katarakt; ugennemsigtig linse eller kapsel i øjet)
* Sløret syn
* Lilla eller sorte-og-blå mærker på huden

 

**Meget sjælden (kan påvirke op til 1 ud af 10.000 personer)**

* En alvorlig allergisk reaktion (kaldet anafylaksi), som kan føre til vejrtrækningsbesvær og potentielt chok.

 

Nogle af bivirkningerne nævnt ovenfor er typiske for steroidbehandling og kan forekomme afhængigt af din dosis, behandlingens varighed, hvorvidt du er eller har været i behandling med andre kortison- præparater og din individuelle modtagelighed.

 

Psykologiske problemer kan udvikle sig, ved brug af steroider såsom Cortiment depottabletter. Diskuter det med din læge, hvis du (eller brugeren af denne medicin) har (haft) symptomer på psykiske problemer. Dette er især vigtigt, hvis du er deprimeret og har tanker om at begå selvmord. I meget sjældne tilfælde har psykiske problemer udviklet sig, når høje doser blev taget i længere tid.

### Indberetning af bivirkninger

Hvis du oplever bivirkninger, bør du tale med din læge, sygeplejerske eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via:

Lægemiddelstyrelsen

Axel Heides Gade 1

DK-2300 København S

Websted: www.meldenbivirkning.dk

Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.

[Meld en bivirkning.](https://www.meldenbivirkning.dk)


#### 5. Opbevaring

 

 

## 5. Opbevaring

Opbevar lægemidlet utilgængeligt for børn.

Brug ikke lægemidlet efter den udløbsdato, der står på æsken og blisterpakningen efter EXP.

Udløbsdatoen er den sidste dag i den nævnte måned.

Opbevares ved temperaturer under 30 °C.

Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

 

## 6. Pakningsstørrelser og yderligere oplysninger

### Cortiment indeholder:

* Aktivt stof: budesonid. Hver tablet indeholder 9 mg budesonid.
* Øvrige indholdsstoffer (hjælpestoffer):
**tabletkerne:** stearinsyre (E570), lecithin (soja) (E322), mikrokrystallinsk cellulose (E460), hydroxypropylcellulose (E463), lactosemonohydrat, silica kolloid (E551), magnesiumstearat (E470b)
**filmovertræk:** methacrylsyre-methylmethacrylat-copolymer (1:1), methacrylsyre-methylmethacrylat-copolymer (1:2), talcum (E553b), titandioxid (E171), triethylcitrat

### Udseende og pakningsstørrelser

Cortiment depottablet er hvid til off-white, rund, bi-konveks, filmovertrukket og præget med 'MX9' på den ene side af tabletten. Tabletterne leveres i blister ark med aluminiums tryk-folie i en karton æske.

 

Dette lægemiddel er tilgængeligt i pakninger med 10, 20, 30, 50, 60 eller 80 tabletter.

Ikke alle pakningsstørrelser er nødvendigvis markedsført.


####  Cortiment depottab 9 mg 
LEGEMIDDELMERKEVAREID:
** ID_E0D85C29-F445-4ABF-BDA0-5AA124209550 **
-------

Full name: **Cortiment depottab 9 mg**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_B0D9AFBA-815A-4C37-A995-F231812A1E14 ** 

VARENUMMER: ** 065339 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK42542",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
    "value" : "42542"
  },
  "type" : "document",
  "timestamp" : "2022-10-18T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK42542-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK42542-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_FK42542-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK42542-COMP</b></p><a name=\"FK42542-COMP\"> </a><a name=\"hcFK42542-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/</code>/42542</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2022-10-18</p><p><b>author</b>: Identifier: <code>https://medicin.dk</code>/medicin.dk</p><p><b>title</b>: Cortiment 9 mg depottabletter</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
        "value" : "42542"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-13"
      }],
      "date" : "2022-10-18",
      "author" : [{
        "identifier" : {
          "system" : "https://medicin.dk",
          "value" : "medicin.dk"
        }
      }],
      "title" : "Cortiment 9 mg depottabletter",
      "section" : [{
        "title" : "Indlægsseddel: Information til patienten",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section0\"/><h2>Indlægsseddel: Information til brugeren</h2><h3>Cortiment, depottabletter</h3><div class=\"paragraph\">Budesonid</div><h3>Læs denne indlægsseddel grundigt, inden du begynder at bruge dette lægemiddel, da den indeholder vigtige oplysninger.</h3><ul><li>Gem indlægssedlen. Du kan få brug for at læse den igen.</li><li>Spørg lægen, hvis der er mere, du vil vide.</li><li>Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.</li><li>Kontakt lægen, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt her. Se <a href=\"#Section4\" title=\"Anchor link til afsnit - afsnit 4\">afsnit 4</a>.</li></ul><div class=\"paragraph\">Se den nyeste indlægsseddel på <a href=\"https://www.indlaegsseddel.dk\" title=\"null\">www.indlaegsseddel.dk</a>.</div><h3>Oversigt over indlægssedlen:</h3><ol><li>Virkning og anvendelse</li><li>Det skal du vide, før du begynder at bruge Cortiment</li><li>Sådan skal du bruge Cortiment</li><li>Bivirkninger</li><li>Opbevaring</li><li>Pakningsstørrelser og yderligere oplysninger</li></ol></div>"
        },
        "section" : [{
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section1\"/><div> </div><h2>1. Virkning og anvendelse</h2><div class=\"paragraph\">Cortiment depottabletter indeholder det aktive stof kaldet budesonid. Budesonid tilhører en gruppe af lægemidler kaldet kortikosteroider, som anvendes til at reducere inflammation.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Cortiment depottabletter anvendes til voksne til behandling af:</div><ul><li>colitis ulcerosa, som er inflammation i tyktarmen (kolon) og endetarmen (rectum)</li><li>akutte episoder af mikroskopisk colitis, som er en sygdom med kronisk inflammation i tyktarmen (kolon) typisk med kronisk vandig diarré.</li></ul></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du begynder at bruge Cortiment",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section2\"/><div> </div><h2>2. Det skal du vide, før du begynder at bruge Cortiment</h2><div class=\"paragraph\">Lægen kan have foreskrevet anden anvendelse eller dosering end angivet i denne information. Følg altid lægens anvisning og oplysningerne på doseringsetiketten.</div><h3>Brug ikke Cortiment</h3><div class=\"paragraph\">Hvis du er allergisk over for budesonid eller et af de øvrige indholdsstoffer i Cortiment (angivet i <a href=\"#Section6\" title=\"Anchor link til afsnit - afsnit 6\">afsnit 6</a>).</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du er allergisk over for jordnødder eller soja, idet Cortiment depottabletter indeholder lecithin, udvundet fra sojaolie.</div><h3>Advarsler og forsigtighedsregler</h3><div class=\"paragraph\">Sig det til lægen, hvis du oplever sløret syn eller andre synsforstyrrelser.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Kontakt lægen, før du bruger Cortiment.</div><ul><li>Hvis du har en infektion, såsom en virusinfektion, en bakteriel infektion eller en svampeinfektion.</li><li>Hvis du har haft højt blodtryk.</li><li>Hvis du har diabetes.</li><li>Hvis du har haft knogleskørhed.</li><li>Hvis du har haft mavesår.</li><li>Hvis du har haft grøn stær (glaukom) eller grå stær (katarakt).</li><li>Hvis et familiemedlem har diabetes eller grøn stær (glaukom).</li><li>Hvis du har haft leversygdom.</li><li>Hvis du skifter fra anden kortison behandling til Cortiment, da det kan resultere i f.eks. smerter i muskler og led, træthed, hovedpine, kvalme og opkastning.</li><li>Hvis du ved, du skal vaccineres</li><li>Hvis du er blevet behandlet med et stærkere kortison præparat inden behandlingsstart med Cortiment, kan dine symptomer komme igen.</li><li>Hvis du får en infektion under behandlingen, kan Cortiment skjule tegn på infektion og infektionen kan forværres. Du kan være mere modtagelig for infektioner under behandling med Cortiment, da din krops modstand mod infektioner kan være nedsat.</li><li>Hvis du skal opereres snarest eller hvis du udsættes for anden stress.</li><li>Hvis du endnu ikke har haft mæslinger eller skoldkopper.</li><li>Når du bruger Cortiment depottabletter, forsøg at undgå kontakt med personer med mæslinger eller skoldkopper. Informer din læge, hvis du tror at du er blevet smittet med mæslinger eller skoldkopper, mens du tager denne medicin.</li><li>Hvis du eller et familiemedlem har haft mentale helbredsproblemer.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">At tage kortison præparater i høje doser og over en længere periode kan påvirke alle dele af kroppen og i meget sjældne tilfælde psykologiske problemer (se <a href=\"#Section4\" title=\"Anchor link til afsnit - afsnit 4.\">afsnit 4.</a> Bivirkninger).</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Kontakt lægen, før du bruger Cortiment depottabletter, hvis du er i tvivl om, hvorvidt noget af ovenstående gælder for dig.</div><h3>Brug af anden medicin sammen med Cortiment</h3><div class=\"paragraph\">Fortæl det altid til lægen hvis du bruger anden medicin eller har gjort det for nylig. Det gælder også medicin, som ikke er købt på recept. Dette er nødvendigt da Cortiment depottabletter påvirker, hvordan noget medicin virker og nogle lægemidler kan påvirke, hvordan Cortiment depottablet virker. Nogle lægemidler kan øge virkningen af Cortiment, og din læge vil overvåge dig omhyggeligt, hvis du tager sådanne lægemidler (inklusive visse former for HIV-medicin; ritonavir, cobicistat).</div><div class=\"paragraph\"><br/>Det er særlig vigtigt at du fortæller din læge, hvis du tager, for nylig har taget eller har tænkt at tage et af følgende lægemidler:</div><ul><li>Ketoconazol eller itraconazol, som er lægemidler, der anvendes til behandling af svampeinfektioner;</li><li>medicin brugt til HIV behandling (såsom ritonavir, nelfinavir, cobicistat-holdige lægemidler);</li><li>Carbamazepin, som anvendes til behandling af epilepsi;</li><li>Hjerteglykosider og diuretika (vanddrivende lægemidler);</li><li>Lægemidler der indeholder østrogener, såsom hormonbehandling (HRT) og nogle orale præventionsmidler;</li><li>Steroider, såsom prednisolon eller dexamethason;</li><li>Cholestyramin, som bruges til at sænke kolesterolniveau eller behandle kløe forårsaget af leverproblemer eller syreneutraliserende middel (antacida).</li></ul><h3>Brug af Cortiment sammen med mad, drikke og alkohol</h3><div class=\"paragraph\">Du må ikke drikke grapefrugtjuice, når du tager Cortiment depottabletter. Dette kan påvirke måden som medicinen virker på.</div><h3>Graviditet, amning og frugtbarhed</h3><div class=\"paragraph\">Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge til råds, før du bruger dette lægemiddel.</div><h3>Trafik- og arbejdssikkerhed</h3><div class=\"paragraph\">Det er usandsynligt, at Cortiment depottabletter vil påvirke din evne til at køre eller betjene maskiner. Der bør udvises forsigtighed, fordi denne type medicin til tider kan medføre svimmelhed eller træthed.</div><h3>Cortiment depottabletter indeholder lactose og lecithin (sojaolie)</h3><div class=\"paragraph\">Cortiment depottabletter indeholder lactose, en form for sukker. Du skal kontakte din læge, hvis du har fået at vide af din læge, at du ikke tåler visse sukkerarter, før du tager dette lægemiddel.<br/>Cortiment depottabletter indeholder lecithin (sojaolie). Brug ikke dette lægemiddel hvis du er allergisk over for jordnødder eller soja.</div></div>"
          }
        },
        {
          "title" : "3. Sådan skal du bruge Cortiment",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section3\"/><div> </div><h2>3. Sådan skal du bruge Cortiment</h2><div class=\"paragraph\">Brug altid Cortiment nøjagtigt efter lægens anvisning. Er du i tvivl, så spørg lægen.</div><div class=\"paragraph\"> </div><ul><li>Den sædvanlige dosis for colitis ulcerosa og mikroskopisk colitis er èn tablet om morgenen før eller sammen med et måltid.</li><li>Synk tabletten hel med et glas vand; tabletten må ikke deles, knuses eller tygges.</li><li>Normalt vil du tage denne medicin dagligt i højst otte uger. Din læge kan derefter gradvist sænke antallet af gange, du skal tage medicinen.</li><li>Fortsæt med at tage Cortiment depottabletter, efter lægens anvisning også selvom du begynder at føle bedring.</li></ul><h3>Yderligere oplysninger, når du tager Cortiment depottabletter</h3><div class=\"paragraph\">Hvis du snart skal opereres, eller udsættes for anden stressende påvirkning, kan lægen bede dig om at tage steroid tabletter. Dette er især tilfældet, hvis du har taget høje doser af Cortiment depottabletter eller lignende medicin i lang tid.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Brug til patienter med nedsat nyre- eller leverfunktion</b></div><div class=\"paragraph\">Cortiment depottabletter er ikke undersøgt specifikt for patienter med nyre eller lever problemer. Kontakt din læge.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Brug til børn</b></div><div class=\"paragraph\">Cortiment depottabletter anbefales ikke til børn.</div><h3>Hvis du har taget for meget Cortiment</h3><div class=\"paragraph\">Informer straks din læge, hvis du har taget flere Cortiment depottabletter, end du burde.</div><h3>Hvis du har glemt at tage Cortiment</h3><ul><li>Hvis du glemmer at tage en Cortiment depottablet, skal du tage den så snart, du husker det. Hvis det er tæt på din næste dosis, skal du springe den glemte dosis over.</li><li>Du må ikke tage en dobbeltdosis som erstatning for den glemte tablet.</li></ul><h3>Hvis du holder op med at tage Cortiment</h3><div class=\"paragraph\">Du må ikke stoppe med at tage Cortiment depottabletter uden først at have aftalt det med din læge. Det kan være nødvendigt gradvist at nedtrappe behandlingen. Hvis du pludselig stopper med at tage medicinen, kan du blive syg.</div><div class=\"paragraph\"><br/>Spørg lægen, hvis der er noget, du er i tvivl om.</div></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section4\"/><div> </div><h2>4. Bivirkninger</h2><div class=\"paragraph\">Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger.</div><h3>Hvis du har fået en allergisk reaktion, skal du straks kontakte din læge eller ringe for akut hjælp. Tegn kan omfatte nældefeber eller hævelse af ansigt, læber, mund, tunge og hals. Dette kan gøre det vanskeligt at trække vejret.</h3><div class=\"paragraph\">Følgende bivirkninger kan forekomme, når du tager Cortiment depottabletter, de fleste bivirkninger nævnt kan også forventes ved behandling med andre steroider.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Almindelig (kan påvirke op til 1 ud af 10 personer)</b></div><ul><li>Cushing-lignende symptomer, såsom et rundt ansigt (måneansigt), akne, vægtøgning og en tendens til lettere at få blå mærker</li><li>Lavt kalium niveau i blodet, hvilket kan forårsage muskelsvaghed eller træthed, tørst eller en prikkende fornemmelse</li><li>Ændring i adfærd, såsom nervøsitet, søvnløshed eller humørsvingninger</li><li>Depression</li><li>Hovedpine</li><li>Hjertebanken</li><li>Kvalme</li><li>Mavesmerter</li><li>Oppustet mave</li><li>Tør mund</li><li>Fordøjelsesbesvær (dyspepsi)</li><li>Hududslæt eller kløe</li><li>Akne</li><li>Muskel smerter, muskel kramper</li><li>Kraftig eller uregelmæssig menstruation hos kvinder</li><li>Ekstrem træthed (fatigue)</li><li>Nedsat mængde af hormonet kortisol i blodet.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ikke almindelig (kan påvirke op til 1 ud af 100 personer)</b></div><ul><li>Influenza</li><li>Øget antal hvide blodceller</li><li>Ændring i adfærd, som humørsvingninger</li><li>Følelse af uro med hyperaktivitet</li><li>Angst</li><li>Svimmelhed</li><li>Rysten</li><li>Flatulens</li><li>Rygsmerter</li><li>Muskel spasmer</li><li>Hævelse i benene</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Sjælden (kan påvirke op til 1 ud af 1.000 personer)</b></div><ul><li>Aggression</li><li>Glaukom (Grøn stær; øget tryk i øjet)</li><li>Grå stær (katarakt; ugennemsigtig linse eller kapsel i øjet)</li><li>Sløret syn</li><li>Lilla eller sorte-og-blå mærker på huden</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Meget sjælden (kan påvirke op til 1 ud af 10.000 personer)</b></div><ul><li>En alvorlig allergisk reaktion (kaldet anafylaksi), som kan føre til vejrtrækningsbesvær og potentielt chok.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Nogle af bivirkningerne nævnt ovenfor er typiske for steroidbehandling og kan forekomme afhængigt af din dosis, behandlingens varighed, hvorvidt du er eller har været i behandling med andre kortison- præparater og din individuelle modtagelighed.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Psykologiske problemer kan udvikle sig, ved brug af steroider såsom Cortiment depottabletter. Diskuter det med din læge, hvis du (eller brugeren af denne medicin) har (haft) symptomer på psykiske problemer. Dette er især vigtigt, hvis du er deprimeret og har tanker om at begå selvmord. I meget sjældne tilfælde har psykiske problemer udviklet sig, når høje doser blev taget i længere tid.</div><h3>Indberetning af bivirkninger</h3><div class=\"paragraph\">Hvis du oplever bivirkninger, bør du tale med din læge, sygeplejerske eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via:</div><div class=\"paragraph\">Lægemiddelstyrelsen</div><div class=\"paragraph\">Axel Heides Gade 1</div><div class=\"paragraph\">DK-2300 København S</div><div class=\"paragraph\">Websted: www.meldenbivirkning.dk</div><div class=\"paragraph\">Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</div><div class=\"paragraph\"><a href=\"https://www.meldenbivirkning.dk\" title=\"Meld en bivirkning\">Meld en bivirkning.</a></div></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section5\"/><div> </div><h2>5. Opbevaring</h2><div class=\"paragraph\">Opbevar lægemidlet utilgængeligt for børn.<br/><br/>Brug ikke lægemidlet efter den udløbsdato, der står på æsken og blisterpakningen efter EXP.<br/>Udløbsdatoen er den sidste dag i den nævnte måned.<br/><br/>Opbevares ved temperaturer under 30 °C.<br/><br/>Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.</div></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section6\"/><div> </div><h2>6. Pakningsstørrelser og yderligere oplysninger</h2><h3>Cortiment indeholder:</h3><ul><li>Aktivt stof: budesonid. Hver tablet indeholder 9 mg budesonid.</li><li>Øvrige indholdsstoffer (hjælpestoffer):<br/><b>tabletkerne:</b> stearinsyre (E570), lecithin (soja) (E322), mikrokrystallinsk cellulose (E460), hydroxypropylcellulose (E463), lactosemonohydrat, silica kolloid (E551), magnesiumstearat (E470b)<br/><b>filmovertræk:</b> methacrylsyre-methylmethacrylat-copolymer (1:1), methacrylsyre-methylmethacrylat-copolymer (1:2), talcum (E553b), titandioxid (E171), triethylcitrat</li></ul><h3>Udseende og pakningsstørrelser</h3><div class=\"paragraph\">Cortiment depottablet er hvid til off-white, rund, bi-konveks, filmovertrukket og præget med 'MX9' på den ene side af tabletten. Tabletterne leveres i blister ark med aluminiums tryk-folie i en karton æske.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Dette lægemiddel er tilgængeligt i pakninger med 10, 20, 30, 50, 60 eller 80 tabletter.</div><div class=\"paragraph\">Ikke alle pakningsstørrelser er nødvendigvis markedsført.</div></div>"
          },
          "section" : [{
            "title" : "Indehaver af markedsføringstilladelsen og fremstiller",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Indehaver af markedsføringstilladelsen og fremstiller</h2><h3>Indehaver af markedsføringstilladelsen</h3><div class=\"paragraph\">Ferring Lægemidler A/S<br/>Amager Strandvej 405<br/>2770 Kastrup</div><h3>Fremstiller</h3><div class=\"paragraph\">Cosmo S.p.A.</div><div class=\"paragraph\">Via C. Colombo 1,</div><div class=\"paragraph\">20045 Lainate,</div><div class=\"paragraph\">Milano, Italien</div><h3>Dette lægemiddel er godkendt i medlemslandene i Det Europæiske Økonomiske Samarbejdsområde og i Det Forenede Kongerige (Nordirland) under følgende navne:</h3><div class=\"paragraph\"><b>Bulgarien, Cypern, Danmark, Det Forenede Kongerige (Nordirland), Finland, Frankrig, Grækenland, Island, Irland, Italien, Holland, Malta, Norge, Romænien, Slovakiet, Spanien, Sverige, Tjekkiet, Tyskland, Ungarn, Østrig: </b>Cortiment<br/><b>Croatien, Polen: </b>CortimentMMX<br/><b>Portugal: </b>Coramen<br/><b>Belgien, Estland, Letland, Litaun, Luxemburg:</b> Budesonide Ferring<br/><b>Slovenien: </b>Budezonid Ferring</div></div>"
            }
          },
          {
            "title" : "Denne indlægsseddel blev senest ændret 30. maj 2022",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Denne indlægsseddel blev senest ændret 30. maj 2022</h2></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/IBD-MPD-13",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "IBD-MPD-13",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_IBD-MPD-13\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition IBD-MPD-13</b></p><a name=\"IBD-MPD-13\"> </a><a name=\"hcIBD-MPD-13\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_E0D85C29-F445-4ABF-BDA0-5AA124209550</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Cortiment depottab 9 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_E0D85C29-F445-4ABF-BDA0-5AA124209550"
      }],
      "name" : [{
        "productName" : "Cortiment depottab 9 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/IBD-PPD-13",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "IBD-PPD-13",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_IBD-PPD-13\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition IBD-PPD-13</b></p><a name=\"IBD-PPD-13\"> </a><a name=\"hcIBD-PPD-13\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_B0D9AFBA-815A-4C37-A995-F231812A1E14, <code>https://farmalogg.no/varenummer</code>/065339</p><p><b>name</b>: Cortiment depottab 9 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK42542.html#MedicinalProductDefinition_IBD-MPD-13\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_E0D85C29-F445-4ABF-BDA0-5AA124209550</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_B0D9AFBA-815A-4C37-A995-F231812A1E14"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "065339"
      }],
      "name" : "Cortiment depottab 9 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-13"
      }]
    }
  }]
}

```
