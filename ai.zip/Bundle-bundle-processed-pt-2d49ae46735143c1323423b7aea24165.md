# ePI document Bundle for Karvea 75 mg Package Leaflet for language pt - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Karvea 75 mg Package Leaflet for language pt**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **14 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

## Example Bundle: ePI document Bundle for Karvea 75 mg Package Leaflet for language pt

**Composition category:**Processed

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

Karvea 300 mg comprimidos

irbesartan

Leia com atenção todo este folheto antes de começar a tomar este medicamento, pois contém informação importante para si.

* Conserve este folheto. Pode ter necessidade de o ler novamente.
* Caso ainda tenha dúvidas, fale com o seu médico ou farmacêutico.
* Este medicamento foi receitado apenas para si. Não deve dá-lo a outros; o medicamento pode serlhes prejudicial mesmo que apresentem os mesmos sinais de doença.
* Se tiver quaisquer efeitos secundários, incluindo efeitos secundários não indicados neste folheto, fale com o seu médico ou farmacêutico.


#### What is in this leaflet

 

**O que contém este folheto:**

1. O que é Karvea e para que é utilizado
1. O que precisa de saber antes de tomar Karvea
1. Como tomar Karvea
1. Efeitos secundários possíveis
1. Como conservar Karvea
1. Conteúdo da embalagem e outras informações


#### 1. What Karvea is and what it is used for

 

Karvea pertence a um grupo de medicamentos conhecidos como antagonistas dos recetores da angiotensina-II. A angiotensina-II é uma substância produzida no organismo que se liga a recetores nos vasos sanguíneos, provocando o seu estreitamento, o que conduz ao aumento da pressão arterial. Karvea impede a ligação da angiotensina-II a estes recetores, fazendo com que os vasos sanguíneos se relaxem e a pressão arterial baixe. Karvea atrasa a diminuição da função renal nos doentes com pressão arterial elevada e diabetes do tipo 2.

Karvea é usado em doentes adultos

* para tratar a pressão arterial elevada (hipertensão essencial)
* para proteger os rins nos doentes com pressão arterial elevada, diabetes do tipo 2 e evidência laboratorial de insuficiência dos rins.


#### 2. What you need to know before you take Karvea

 

**Não tome Karvea**

* se tem alergia ao irbesartan ou a qualquer outro componente deste medicamento (indicados na secção 6).
* se tiver mais do que três meses de gravidez. (Também é preferível não tomar Karvea no início da gravidez - ver secção Gravidez
* se tem diabetes ou função renal diminuída e está a ser tratado com um medicamento que contém aliscireno para diminuir a pressão arterial

**Advertências e precauções**

Fale com o seu médico antes de tomar Karvea e se alguma das seguintes situações se aplicar a si:

* se tiver vómitos ou diarreia prolongados
* se sofrer de problemas nos rins
* se sofre de problemas do coração
* se receber Karvea para doença nos rins diabética. Neste caso, o seu médico pode efetuar-lhe análises ao sangue com regularidade, especialmente para medir os níveis sanguíneos de potássio em caso de insuficiência dos rins se desenvolver baixos níveis de açúcar no sangue (os sintomas podem incluir sudação, fraqueza, fome, tonturas, tremores, dor de cabeça, rubor ou palidez, dormência, batimento cardíaco acelerado e palpitante), especialmente se estiver a ser tratado para a diabetes.
* se vai ser submetido a uma operação (cirurgia) ou se lhe vão ser administrados anestésicos
* se está a tomar algum dos seguintes medicamentos para tratar a pressão arterial elevada:
* um inibidor da ECA (por exemplo enalapril, lisinopril, ramipril), em particular se tiver problemas nos rins relacionados com diabetes.
* aliscireno

O seu médico pode verificar a sua função renal, pressão arterial e a quantidade de eletrólitos (por exemplo, o potássio) no seu sangue em intervalos regulares.

Ver também a informação sob o título “Não tome Karvea”

Deve informar o seu médico se pensa que está (ou pode vir a estar) grávida. Karvea não está recomendado no início da gravidez e não pode ser tomado após o terceiro mês de gravidez, uma vez que pode ser gravemente prejudicial para o bebé se utilizado a partir desta altura (ver secção Gravidez).

**Crianças e adolescentes**

Este medicamento não deve ser utilizado em crianças e adolescentes uma vez que não foram ainda completamente estabelecidas a segurança e eficácia.

**Outros medicamentos e Karvea**

Informe o seu médico ou farmacêutico se estiver a tomar, tiver tomado ou se vier a tomar outros medicamentos. O seu médico pode precisar de alterar a dose e/ou tomar outras precauções se estiver a tomar aliscireno. Se está a tomar um inibidor da ECA ou aliscireno (ver também informações sob os títulos “Não tome Karvea” e “Advertências e precauções”).

**Poderá necessitar de fazer algumas verificações ao sangue caso tome:**

* suplementos de potássio
* substitutos de sal contendo potássio
* medicamentos poupadores de potássio (como sejam alguns diuréticos)
* medicamentos contendo lítio
* repaglinida (medicamento utilizado para baixar os níveis de açúcar no sangue)

Se tomar alguns medicamentos para as dores, denominados anti-inflamatórios não-esteroides, o efeito do irbesartan poderá ser reduzido.

**Karvea com alimentos e bebidas**

Karvea pode ser tomado com ou sem alimentos.

**Gravidez e amamentação**

**Gravidez**

Deve informar o seu médico se pensa que está (ou pode vir a estar) grávida. O seu médico normalmente aconselha-la-á a interromper Karvea antes de engravidar ou assim que estiver grávida e a tomar outro medicamento em vez de Karvea. Karvea não está recomendado no início da gravidez e não pode ser tomado após o terceiro mês de gravidez, uma vez que pode ser gravemente prejudicial para o bebé se utilizado a partir desta altura.

**Amamentação**

Deverá informar o seu médico de que se encontra a amamentar ou que está prestes a iniciar o aleitamento. Karvea não está recomendado em mães a amamentar, especialmente se o bebé for recémnascido ou prematuro; nestes casos o seu médico poderá indicar outro tratamento.

**Condução de veículos e utilização de máquinas**

Não é provável que Karvea afete a sua capacidade de conduzir e usar máquinas. Contudo, ocasionalmente, podem ocorrer tonturas ou fadiga durante o tratamento da hipertensão. Se sentir estes efeitos, fale com o seu médico antes de tentar conduzir ou utilizar máquinas.

**Karvea contém lactose. **Se foi informado pelo seu médico de que é intolerante a alguns açúcares (por exemplo, a lactose), deverá contactá-lo antes de tomar este medicamento.

**Karvea contém sódio.** Este medicamento contém menos de 1 mmol de sódio (23 mg) por comprimido, ou seja, é praticamente 'isento de sódio'.


#### 3. How to take Karvea

 

Tomar este medicamento exatamente como indicado pelo seu médico. Fale com o seu médico ou farmacêutico se tiver dúvidas.

**Modo de administração**

Karvea destina-se à via oral. Engolir os comprimidos com uma quantidade suficiente de líquidos (por exemplo um copo com água). Pode tomar Karvea com ou sem alimentos. Tente tomar a dose diária sempre à mesma hora. É importante que continue a tomar Karvea até que o seu médico lhe dê outra indicação.

* Doentes com pressão arterial elevada

A dose habitual é 150 mg uma vez ao dia. Em função da resposta da pressão arterial, a dose pode ser aumentada para 300 mg, uma vez ao dia.

* Doentes com pressão arterial elevada e diabetes do tipo 2 com doença nos rins

Nos doentes com pressão arterial elevada e diabetes do tipo 2, a dose de manutenção preferível para o tratamento da doença renal associada é de 300 mg uma vez por dia.

O médico pode receitar uma dose mais baixa, sobretudo quando se inicia o tratamento em certos doentes, como sejam os que estão em hemodiálise ou os que têm mais de 75 anos.

O efeito hipotensor máximo deve obter-se às 4 a 6 semanas após o início do tratamento.

**Utilização em crianças e adolescentes**

Karvea não deve ser administrado a crianças com idade idade inferior a 18 anos. Se uma criança engolir alguns comprimidos, deve contactar o médico imediatamente.

**Se tomar mais Karvea do que deveria**

Se, acidentalmente, tomar demasiados comprimidos, contacte o médico imediatamente. Caso se tenha esquecido de tomar Karvea Se, acidentalmente, não tomar uma dose diária, tome a dose seguinte como planeado. Não tome uma dose a dobrar para compensar uma dose que se esqueceu de tomar.

Caso ainda tenha dúvidas sobre a utilização deste medicamento, fale com o seu médico ou farmacêutico.


#### 4. Possible side effects

 

Como todos os medicamentos, este medicamento pode causar efeitos secundários, embora estes não se manifestem em todas as pessoas. Alguns destes efeitos podem ser graves e requerer cuidados médicos.

Tal como acontece com medicamentos semelhantes, em doentes a tomar irbesartan foram notificados casos raros de reações alérgicas na pele (erupção na pele, erupção na pele com comichão), assim como inchaço localizado da face, lábios e/ou língua. Se tiver algum destes sintomas, ou se tiver dificuldade em respirar, **pare de tomar Karvea e contacte o médico imediatamente.**

A frequência dos efeitos adversos listados abaixo é definida utilizando a seguinte convenção:

Muito frequentes: podem afetar mais de 1 em 10 pessoas

Frequentes: podem afetar até 1 em 10 pessoas

Pouco frequentes: podem afetar até 1 em 100 pessoas

Os efeitos secundários notificados em estudos clínicos para os doentes tratados com Karvea foram:

* Muito frequentes (podem afetar mais de 1 em 10 pessoas): se tiver pressão arterial elevada e diabetes do tipo 2 com doença nos rins, as análises ao sangue podem mostrar níveis de potássio aumentados.
* Frequentes (podem afetar até 1 em 10 pessoas): tonturas, mal estar/vómitos, fadiga e as análises ao sangue podem mostrar níveis de uma enzima que avalia a função muscular e cardíaca (enzima creatina cinase) aumentados. Em doentes com pressão arterial elevada e diabetes do tipo 2 com doença nos rins foram também notificados tonturas quando se passa da posição deitada ou sentada para a posição de pé, pressão arterial baixa quando se passa da posição deitada ou sentada para a posição de pé, dor nas articulações ou músculos e níveis de uma proteína nos glóbulos vermelhos (hemoglobina) diminuídos.
* Pouco frequentes (podem afetar até 1 em 100 pessoas): ritmo cardíaco rápido, rubor (vermelhidão), tosse, diarreia, indigestão/pirose (azia), disfunção sexual (problemas com o desempenho sexual) e dor torácica.

Alguns efeitos indesejáveis foram notificados desde a comercialização de Karvea. Os efeitos indesejáveis em que a frequência não é conhecida são: sensação de girar, cefaleias (dores de cabeça), alteração do paladar, zumbidos, cãimbras musculares, dor nas articulações e músculos, redução do número de glóbulos vermelhos (anemia - os sintomas podem incluir cansaço, dores de cabeça, falta de ar durante a prática de exercício físico, tonturas e aparência pálida), redução do número de plaquetas, função hepática (do fígado) alterada, níveis sanguíneos de potássio aumentados, compromisso da função dos rins e inflamação dos vasos sanguíneos pequenos afetando principalmente a pele (uma situação conhecida como vasculite leucocitoclásica) , reacções alérgicas graves (choque anafiláctico) e baixos níveis de açúcar no sangue. Foram também notificados casos pouco frequentes de icterícia (amarelecimento da pele e/ou da zona branca dos olhos).

**Comunicação de efeitos secundários**

Se tiver quaisquer efeitos secundários, incluindo possíveis efeitos secundários não indicados neste folheto, fale com o seu médico ou farmacêutico. Também poderá comunicar efeitos secundários diretamente através do sistema nacional de notificação mencionado no Apêndice V. Ao comunicar efeitos secundários, estará a ajudar a fornecer mais informações sobre a segurança deste medicamento.


#### 5. How to store Karvea

 

Manter este medicamento fora da vista e do alcance das crianças.

Não utilize este medicamento após o prazo de validade impresso na embalagem exterior e no blister, após VAL. O prazo de validade corresponde ao último dia do mês indicado.

Não conservar acima de 30ºC.

Não deite fora quaisquer medicamentos na canalização ou no lixo doméstico. Pergunte ao seu farmacêutico como deitar fora os medicamentos que já não necessita. Estas medidas ajudarão a proteger o ambiente.


#### 6. Contents of the pack and other information

 

**Qual a composição de Karvea**

* A substância ativa é o irbesartan. Cada comprimido de Karvea 300 mg contém 300 mg de irbesartan.
* Os outros componentes são celulose microcristalina, croscarmelose sódica, lactose monohidratada, estearato de magnésio, sílica coloidal hidratada, amido de milho pré-gelificado e poloxamero 188. Por favor ver a secção 2 “Karvea contém lactose”.

**Qual o aspeto de Karvea e conteúdo da embalagem**

Os comprimidos de Karvea 300 mg são de cor branca a esbranquiçada, biconvexos, de forma oval, com um coração marcado numa das faces e o número 2773 gravado na outra face.

Os comprimidos de Karvea a 300 mg são fornecidos em embalagens de 14, 28, 56 ou 98 comprimidos acondicionados em blister. Estão também disponíveis, para uso hospitalar, embalagens de 56 x 1 comprimido em blister para dose unitária.

É possível que não sejam comercializadas todas as apresentações.

**Titular da Autorização de Introdução no Mercado** Sanofi Winthrop Industrie 82 avenue Raspail 94250 Gentilly França

**Fabricante**

SANOFI WINTHROP INDUSTRIE 1, rue de la Vierge Ambarès & Lagrave F-33565 Carbon Blanc Cedex - França

SANOFI WINTHROP INDUSTRIE 30-36 Avenue Gustave Eiffel, BP 7166 F-37071 Tours Cedex 2 - França

Para quaisquer informações sobre este medicamento, queira contactar o representante local do Titular da Autorização de Introdução no Mercado.

**België/Belgique/Belgien** Sanofi Belgium Tél/Tel: +32 (0)2 710 54 00

**България** Swixx Biopharma EOOD Тел.: +359 (0)2 4942 480

**Lietuva** Swixx Biopharma UAB Tel: +370 5 236 91 40

**Luxembourg/Luxemburg** Sanofi Belgium Tél/Tel: +32 (0)2 710 54 00 (Belgique/Belgien)

**Česká republika** sanofi-aventis, s.r.o. Tel: +420 233 086 111

**Magyarország** SANOFI-AVENTIS Zrt. Tel.: +36 1 505 0050

**Danmark** Sanofi A/S Tlf: +45 45 16 70 00

**Malta** Sanofi S.r.l.. Tel: +39 02 39394275

**Deutschland** Sanofi-Aventis Deutschland GmbH Tel: 0800 52 52 010 Tel. aus dem Ausland: +49 69 305 21 131

**Nederland** Sanofi B.V. Tel: +31 20 245 4000

**Eesti** Swixx Biopharma OÜ Tel: +372 640 10 30

**Norge** sanofi-aventis Norge AS Tlf: +47 67 10 71 00

**Ελλάδα** Sanofi-Aventis Μονοπρόσωπη AEBE Τηλ: +30 210 900 16 00

**Österreich** sanofi-aventis GmbH Tel: +43 1 80 185 – 0

**España** sanofi-aventis, S.A. Tel: +34 93 485 94 00

**Polska** sanofi-aventis Sp. z o.o. Tel.: +48 22 280 00 00

**France** Sanofi Winthrop Industrie Tél: 0 800 222 555 Appel depuis l’étranger : +33 1 57 63 23 23

**Portugal** Sanofi - Produtos Farmacêuticos, Lda Tel: +351 21 35 89 400

**Hrvatska** Swixx Biopharma d.o.o. Tel: +385 1 2078 500

**Ireland** sanofi-aventis Ireland Ltd. Tel: +353 (0) 1 403 56 00

**România** Sanofi Romania SRL Tel: +40 (0) 21 317 31 36

**Slovenija** Swixx Biopharma d.o.o. Tel: +386 1 235 51 00

**Ísland** Vistor hf. Sími: +354 535 7000

**Slovenská republika** Swixx Biopharma s.r.o. Tel: +421 2 208 33 600

**Italia** Sanofi S.r.l.Tel: 800536389

**Suomi/Finland** Sanofi Oy Puh/Tel: +358 (0) 201 200 300

**Κύπρος** C.A. Papaellinas Ltd. Τηλ: +357 22 741741

**Sverige** Sanofi AB Tel: +46 (0)8 634 50 00

**Latvija** Swixx Biopharma SIA Tel: +371 6 616 47 50

**United Kingdom (Northern Ireland)** sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +44 (0) 800 035 2525

**Este folheto foi revisto pela última vez em**

Informação pormenorizada sobre este medicamento está disponível na Internet no site da Agência Europeia de Medicamentos [http://www.ema.europa.eu/](http://www.ema.europa.eu/)


####  Karvea 75 mg tablet 
PMSWI:
** EU/1/97/049/001 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E82719 **
-------

Full name: **Karvea 75 mg tablet**

 - Invented name part: ** Karvea ** 

 - Scientific name part: ** irbesartan ** 

 - Strength part: ** 75 mg ** 

 - Pharmaceutical dose form part: ** tablet ** 

 Name usage: **English (Denmark)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 Package 1 of 4

PMSWI: ** EU/1/97/049/010 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **28 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 2 of 4

PMSWI: ** EU/1/97/049/001 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **56 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 3 of 4

PMSWI: ** EU/1/97/049/002 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **98 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 4 of 4

PMSWI: ** EU/1/97/049/003 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundle-processed-pt-2d49ae46735143c1323423b7aea24165",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "pt",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/97/049/001"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-processed-pt-f4d45353edcb21af3718d3a0df94a4d8",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-processed-pt-f4d45353edcb21af3718d3a0df94a4d8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "pt",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"pt\" lang=\"pt\"><a name=\"Composition_composition-processed-pt-f4d45353edcb21af3718d3a0df94a4d8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-processed-pt-f4d45353edcb21af3718d3a0df94a4d8</b></p><a name=\"composition-processed-pt-f4d45353edcb21af3718d3a0df94a4d8\"> </a><a name=\"hccomposition-processed-pt-f4d45353edcb21af3718d3a0df94a4d8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: pt</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: pregnancyCategory</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 77386006}\">Pregnancy</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: breastfeedingCategory</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 69840006}\">Normal breast feeding (finding)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: indication</li><li>concept: <a href=\"Bundle-Processedbundlekarvea.html#ClinicalUseDefinition_cud-585e364c14debe29f6c6b564138aa400\">ClinicalUseDefinition: type = indication</a></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: contraindication</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 410536001}\">Contraindicated (qualifier value)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: contra-indication-pregnancy</li><li>concept: <a href=\"Bundle-Processedbundlekarvea.html#ClinicalUseDefinition_contraindication-pregnancy\">ClinicalUseDefinition: identifier = https://spor.ema.europa.eu/rmswi/#/#pregnancy (use: official, ); type = contraindication</a></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: contra-indication-kidney</li><li>concept: <a href=\"Bundle-Processedbundlekarvea.html#ClinicalUseDefinition_contraindication-kidney\">ClinicalUseDefinition: identifier = https://spor.ema.europa.eu/rmswi/#/#kidney function (use: official, ); type = contraindication</a></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: contra-indication-diabetes-mellitus</li><li>concept: <a href=\"Bundle-Processedbundlekarvea.html#ClinicalUseDefinition_contraindication-diabetes-mellitus\">ClinicalUseDefinition: identifier = https://spor.ema.europa.eu/rmswi/#/#diabetes-mellitus (use: official, ); type = contraindication</a></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: lactose</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 190751001}\">Primary lactose intolerance</span></li></ul></blockquote><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/karvea-pt-processed</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs P}\">Processed</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p><p><b>title</b>: TEST PURPOSES ONLY - Karvea</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "pregnancyCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "77386006",
                "display" : "Pregnancy"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "breastfeedingCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "69840006",
                "display" : "Normal breast feeding (finding)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "indication"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "reference" : {
              "reference" : "ClinicalUseDefinition/cud-585e364c14debe29f6c6b564138aa400"
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "contraindication"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "410536001",
                "display" : "Contraindicated (qualifier value)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "contra-indication-pregnancy"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "reference" : {
              "reference" : "ClinicalUseDefinition/contraindication-pregnancy"
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "contra-indication-kidney"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "reference" : {
              "reference" : "ClinicalUseDefinition/contraindication-kidney"
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "contra-indication-diabetes-mellitus"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "reference" : {
              "reference" : "ClinicalUseDefinition/contraindication-diabetes-mellitus"
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "lactose"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "190751001",
                "display" : "Primary lactose intolerance"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      }],
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "karvea-pt-processed"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "P",
          "display" : "Processed"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }],
      "title" : "TEST PURPOSES ONLY - Karvea",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PACKAGE LEAFLET"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Karvea 300 mg comprimidos</p><p>irbesartan</p><p>Leia com atenção todo este folheto antes de começar a tomar este medicamento, pois contém informação importante para si.</p><ul><li>Conserve este folheto. Pode ter necessidade de o ler novamente.</li><li>Caso ainda tenha dúvidas, fale com o seu médico ou farmacêutico.</li><li>Este medicamento foi receitado apenas para si. Não deve dá-lo a outros; o medicamento pode serlhes prejudicial mesmo que apresentem os mesmos sinais de doença.</li><li>Se tiver quaisquer efeitos secundários, incluindo efeitos secundários não indicados neste folheto, fale com o seu médico ou farmacêutico.</li></ul></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>O que contém este folheto:</strong></p><ol><li>O que é Karvea e para que é utilizado</li><li>O que precisa de saber antes de tomar Karvea</li><li>Como tomar Karvea</li><li>Efeitos secundários possíveis</li><li>Como conservar Karvea</li><li>Conteúdo da embalagem e outras informações</li></ol></div>"
          }
        },
        {
          "title" : "1. What Karvea is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What Karvea is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Karvea pertence a um grupo de medicamentos conhecidos como antagonistas dos recetores da angiotensina-II. A angiotensina-II é uma substância produzida no organismo que se liga a recetores nos vasos sanguíneos, provocando o seu estreitamento, o que conduz ao aumento da pressão arterial. Karvea impede a ligação da angiotensina-II a estes recetores, fazendo com que os vasos sanguíneos se relaxem e a pressão arterial baixe. Karvea atrasa a diminuição da função renal nos doentes com pressão arterial elevada e diabetes do tipo 2.</p><div class=\"indication\"><p>Karvea é usado em doentes adultos</p><ul><li>para tratar a pressão arterial elevada (hipertensão essencial)</li><li>para proteger os rins nos doentes com pressão arterial elevada, diabetes do tipo 2 e evidência laboratorial de insuficiência dos rins.</li></ul></div></div>"
          }
        },
        {
          "title" : "2. What you need to know before you take Karvea",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take Karvea"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Não tome Karvea</strong></p><ul><li>se tem alergia ao irbesartan ou a qualquer outro componente deste medicamento (indicados na secção 6).</li><li class=\"contra-indication-pregnancy\">se tiver mais do que três meses de gravidez. (Também é preferível não tomar Karvea no início da gravidez - ver secção Gravidez</li><li><span class=\"contra-indication-diabetes-mellitus\">se tem diabetes </span>ou <span class=\"contra-indication-kidney\">função renal diminuída</span> e está a ser tratado com um medicamento que contém aliscireno para diminuir a pressão arterial</li></ul><p><strong>Advertências e precauções</strong></p><p>Fale com o seu médico antes de tomar Karvea e se alguma das seguintes situações se aplicar a si:</p><ul><li>se tiver vómitos ou diarreia prolongados</li><li>se sofrer de problemas nos rins</li><li>se sofre de problemas do coração</li><li>se receber Karvea para doença nos rins diabética. Neste caso, o seu médico pode efetuar-lhe análises ao sangue com regularidade, especialmente para medir os níveis sanguíneos de potássio em caso de insuficiência dos rins se desenvolver baixos níveis de açúcar no sangue (os sintomas podem incluir sudação, fraqueza, fome, tonturas, tremores, dor de cabeça, rubor ou palidez, dormência, batimento cardíaco acelerado e palpitante), especialmente se estiver a ser tratado para a diabetes.</li><li>se vai ser submetido a uma operação (cirurgia) ou se lhe vão ser administrados anestésicos</li><li>se está a tomar algum dos seguintes medicamentos para tratar a pressão arterial elevada:<ul><li>um inibidor da ECA (por exemplo enalapril, lisinopril, ramipril), em particular se tiver problemas nos rins relacionados com diabetes.</li><li>aliscireno</li></ul></li></ul><p>O seu médico pode verificar a sua função renal, pressão arterial e a quantidade de eletrólitos (por exemplo, o potássio) no seu sangue em intervalos regulares.</p><p>Ver também a informação sob o título “Não tome Karvea”</p><p>Deve informar o seu médico se pensa que está (ou pode vir a estar) grávida. Karvea não está recomendado no início da gravidez e não pode ser tomado após o terceiro mês de gravidez, uma vez que pode ser gravemente prejudicial para o bebé se utilizado a partir desta altura (ver secção Gravidez).</p><p><strong>Crianças e adolescentes</strong></p><p>Este medicamento não deve ser utilizado em crianças e adolescentes uma vez que não foram ainda completamente estabelecidas a segurança e eficácia.</p><p><strong>Outros medicamentos e Karvea</strong></p><p>Informe o seu médico ou farmacêutico se estiver a tomar, tiver tomado ou se vier a tomar outros medicamentos. O seu médico pode precisar de alterar a dose e/ou tomar outras precauções se estiver a tomar aliscireno. Se está a tomar um inibidor da ECA ou aliscireno (ver também informações sob os títulos “Não tome Karvea” e “Advertências e precauções”).</p><p><strong>Poderá necessitar de fazer algumas verificações ao sangue caso tome:</strong></p><ul><li>suplementos de potássio</li><li>substitutos de sal contendo potássio</li><li>medicamentos poupadores de potássio (como sejam alguns diuréticos)</li><li>medicamentos contendo lítio</li><li>repaglinida (medicamento utilizado para baixar os níveis de açúcar no sangue)</li></ul><p>Se tomar alguns medicamentos para as dores, denominados anti-inflamatórios não-esteroides, o efeito do irbesartan poderá ser reduzido.</p><p><strong>Karvea com alimentos e bebidas</strong></p><p>Karvea pode ser tomado com ou sem alimentos.</p><div class=\"pregnancyCategory\"><p><strong>Gravidez e amamentação</strong></p><p><strong>Gravidez</strong></p><p>Deve informar o seu médico se pensa que está (ou pode vir a estar) grávida. O seu médico normalmente aconselha-la-á a interromper Karvea antes de engravidar ou assim que estiver grávida e a tomar outro medicamento em vez de Karvea. Karvea não está recomendado no início da gravidez e não pode ser tomado após o terceiro mês de gravidez, uma vez que pode ser gravemente prejudicial para o bebé se utilizado a partir desta altura.</p></div><div class=\"breastfeedingCategory\"><p><strong>Amamentação</strong></p><p>Deverá informar o seu médico de que se encontra a amamentar ou que está prestes a iniciar o aleitamento. Karvea não está recomendado em mães a amamentar, especialmente se o bebé for recémnascido ou prematuro; nestes casos o seu médico poderá indicar outro tratamento.</p></div><p><strong>Condução de veículos e utilização de máquinas</strong></p><p>Não é provável que Karvea afete a sua capacidade de conduzir e usar máquinas. Contudo, ocasionalmente, podem ocorrer tonturas ou fadiga durante o tratamento da hipertensão. Se sentir estes efeitos, fale com o seu médico antes de tentar conduzir ou utilizar máquinas.</p><p><strong><span class=\"lactose\">Karvea contém lactose.</span> </strong>Se foi informado pelo seu médico de que é intolerante a alguns açúcares (por exemplo, a lactose), deverá contactá-lo antes de tomar este medicamento.</p><p><strong>Karvea contém sódio.</strong> Este medicamento contém menos de 1 mmol de sódio (23 mg) por comprimido, ou seja, é praticamente &#39;isento de sódio&#39;.</p></div>"
          }
        },
        {
          "title" : "3. How to take Karvea",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take Karvea"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Tomar este medicamento exatamente como indicado pelo seu médico. Fale com o seu médico ou farmacêutico se tiver dúvidas.</p><p><strong>Modo de administração</strong></p><p>Karvea destina-se à via oral. Engolir os comprimidos com uma quantidade suficiente de líquidos (por exemplo um copo com água). Pode tomar Karvea com ou sem alimentos. Tente tomar a dose diária sempre à mesma hora. É importante que continue a tomar Karvea até que o seu médico lhe dê outra indicação.</p><ul><li>Doentes com pressão arterial elevada</li></ul><p>A dose habitual é 150 mg uma vez ao dia. Em função da resposta da pressão arterial, a dose pode ser aumentada para 300 mg, uma vez ao dia.</p><ul><li>Doentes com pressão arterial elevada e diabetes do tipo 2 com doença nos rins</li></ul><p>Nos doentes com pressão arterial elevada e diabetes do tipo 2, a dose de manutenção preferível para o tratamento da doença renal associada é de 300 mg uma vez por dia.</p><p>O médico pode receitar uma dose mais baixa, sobretudo quando se inicia o tratamento em certos doentes, como sejam os que estão em hemodiálise ou os que têm mais de 75 anos.</p><p>O efeito hipotensor máximo deve obter-se às 4 a 6 semanas após o início do tratamento.</p><p><strong>Utilização em crianças e adolescentes</strong></p><p>Karvea não deve ser administrado a crianças com idade idade inferior a 18 anos. Se uma criança engolir alguns comprimidos, deve contactar o médico imediatamente.</p><p><strong>Se tomar mais Karvea do que deveria</strong></p><p>Se, acidentalmente, tomar demasiados comprimidos, contacte o médico imediatamente. Caso se tenha esquecido de tomar Karvea Se, acidentalmente, não tomar uma dose diária, tome a dose seguinte como planeado. Não tome uma dose a dobrar para compensar uma dose que se esqueceu de tomar.</p><p>Caso ainda tenha dúvidas sobre a utilização deste medicamento, fale com o seu médico ou farmacêutico.</p></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Como todos os medicamentos, este medicamento pode causar efeitos secundários, embora estes não se manifestem em todas as pessoas. Alguns destes efeitos podem ser graves e requerer cuidados médicos.</p><p>Tal como acontece com medicamentos semelhantes, em doentes a tomar irbesartan foram notificados casos raros de reações alérgicas na pele (erupção na pele, erupção na pele com comichão), assim como inchaço localizado da face, lábios e/ou língua. Se tiver algum destes sintomas, ou se tiver dificuldade em respirar, <strong>pare de tomar Karvea e contacte o médico imediatamente.</strong></p><p>A frequência dos efeitos adversos listados abaixo é definida utilizando a seguinte convenção:</p><p>Muito frequentes: podem afetar mais de 1 em 10 pessoas</p><p>Frequentes: podem afetar até 1 em 10 pessoas</p><p>Pouco frequentes: podem afetar até 1 em 100 pessoas</p><p>Os efeitos secundários notificados em estudos clínicos para os doentes tratados com Karvea foram:</p><ul><li>Muito frequentes (podem afetar mais de 1 em 10 pessoas): se tiver pressão arterial elevada e diabetes do tipo 2 com doença nos rins, as análises ao sangue podem mostrar níveis de potássio aumentados.</li><li>Frequentes (podem afetar até 1 em 10 pessoas): tonturas, mal estar/vómitos, fadiga e as análises ao sangue podem mostrar níveis de uma enzima que avalia a função muscular e cardíaca (enzima creatina cinase) aumentados. Em doentes com pressão arterial elevada e diabetes do tipo 2 com doença nos rins foram também notificados tonturas quando se passa da posição deitada ou sentada para a posição de pé, pressão arterial baixa quando se passa da posição deitada ou sentada para a posição de pé, dor nas articulações ou músculos e níveis de uma proteína nos glóbulos vermelhos (hemoglobina) diminuídos.</li><li>Pouco frequentes (podem afetar até 1 em 100 pessoas): ritmo cardíaco rápido, rubor (vermelhidão), tosse, diarreia, indigestão/pirose (azia), disfunção sexual (problemas com o desempenho sexual) e dor torácica.</li></ul><p>Alguns efeitos indesejáveis foram notificados desde a comercialização de Karvea. Os efeitos indesejáveis em que a frequência não é conhecida são: sensação de girar, cefaleias (dores de cabeça), alteração do paladar, zumbidos, cãimbras musculares, dor nas articulações e músculos, redução do número de glóbulos vermelhos (anemia - os sintomas podem incluir cansaço, dores de cabeça, falta de ar durante a prática de exercício físico, tonturas e aparência pálida), redução do número de plaquetas, função hepática (do fígado) alterada, níveis sanguíneos de potássio aumentados, compromisso da função dos rins e inflamação dos vasos sanguíneos pequenos afetando principalmente a pele (uma situação conhecida como vasculite leucocitoclásica) , reacções alérgicas graves (choque anafiláctico) e baixos níveis de açúcar no sangue. Foram também notificados casos pouco frequentes de icterícia (amarelecimento da pele e/ou da zona branca dos olhos).</p><p><strong>Comunicação de efeitos secundários</strong></p><p>Se tiver quaisquer efeitos secundários, incluindo possíveis efeitos secundários não indicados neste folheto, fale com o seu médico ou farmacêutico. Também poderá comunicar efeitos secundários diretamente através do sistema nacional de notificação mencionado no Apêndice V. Ao comunicar efeitos secundários, estará a ajudar a fornecer mais informações sobre a segurança deste medicamento.</p></div>"
          }
        },
        {
          "title" : "5. How to store Karvea",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store Karvea"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Manter este medicamento fora da vista e do alcance das crianças.</p><p>Não utilize este medicamento após o prazo de validade impresso na embalagem exterior e no blister, após VAL. O prazo de validade corresponde ao último dia do mês indicado.</p><p>Não conservar acima de 30ºC.</p><p>Não deite fora quaisquer medicamentos na canalização ou no lixo doméstico. Pergunte ao seu farmacêutico como deitar fora os medicamentos que já não necessita. Estas medidas ajudarão a proteger o ambiente.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Qual a composição de Karvea</strong></p><ul><li>A substância ativa é o irbesartan. Cada comprimido de Karvea 300 mg contém 300 mg de irbesartan.</li><li>Os outros componentes são celulose microcristalina, croscarmelose sódica, lactose monohidratada, estearato de magnésio, sílica coloidal hidratada, amido de milho pré-gelificado e poloxamero 188. Por favor ver a secção 2 “Karvea contém lactose”.</li></ul><p><strong>Qual o aspeto de Karvea e conteúdo da embalagem</strong></p><p>Os comprimidos de Karvea 300 mg são de cor branca a esbranquiçada, biconvexos, de forma oval, com um coração marcado numa das faces e o número 2773 gravado na outra face.</p><p>Os comprimidos de Karvea a 300 mg são fornecidos em embalagens de 14, 28, 56 ou 98 comprimidos acondicionados em blister. Estão também disponíveis, para uso hospitalar, embalagens de 56 x 1 comprimido em blister para dose unitária.</p><p>É possível que não sejam comercializadas todas as apresentações.</p><p><strong>Titular da Autorização de Introdução no Mercado</strong> Sanofi Winthrop Industrie 82 avenue Raspail 94250 Gentilly França</p><p><strong>Fabricante</strong></p><p>SANOFI WINTHROP INDUSTRIE 1, rue de la Vierge Ambarès &amp; Lagrave F-33565 Carbon Blanc Cedex - França</p><p>SANOFI WINTHROP INDUSTRIE 30-36 Avenue Gustave Eiffel, BP 7166 F-37071 Tours Cedex 2 - França</p><p>Para quaisquer informações sobre este medicamento, queira contactar o representante local do Titular da Autorização de Introdução no Mercado.</p><p><strong>België/Belgique/Belgien</strong> Sanofi Belgium Tél/Tel: +32 (0)2 710 54 00</p><p><strong>България</strong> Swixx Biopharma EOOD Тел.: +359 (0)2 4942 480</p><p><strong>Lietuva</strong> Swixx Biopharma UAB Tel: +370 5 236 91 40</p><p><strong>Luxembourg/Luxemburg</strong> Sanofi Belgium Tél/Tel: +32 (0)2 710 54 00 (Belgique/Belgien)</p><p><strong>Česká republika</strong> sanofi-aventis, s.r.o. Tel: +420 233 086 111</p><p><strong>Magyarország</strong> SANOFI-AVENTIS Zrt. Tel.: +36 1 505 0050</p><p><strong>Danmark</strong> Sanofi A/S Tlf: +45 45 16 70 00</p><p><strong>Malta</strong> Sanofi S.r.l.. Tel: +39 02 39394275</p><p><strong>Deutschland</strong> Sanofi-Aventis Deutschland GmbH Tel: 0800 52 52 010 Tel. aus dem Ausland: +49 69 305 21 131</p><p><strong>Nederland</strong> Sanofi B.V. Tel: +31 20 245 4000</p><p><strong>Eesti</strong> Swixx Biopharma OÜ Tel: +372 640 10 30</p><p><strong>Norge</strong> sanofi-aventis Norge AS Tlf: +47 67 10 71 00</p><p><strong>Ελλάδα</strong> Sanofi-Aventis Μονοπρόσωπη AEBE Τηλ: +30 210 900 16 00</p><p><strong>Österreich</strong> sanofi-aventis GmbH Tel: +43 1 80 185 – 0</p><p><strong>España</strong> sanofi-aventis, S.A. Tel: +34 93 485 94 00</p><p><strong>Polska</strong> sanofi-aventis Sp. z o.o. Tel.: +48 22 280 00 00</p><p><strong>France</strong> Sanofi Winthrop Industrie Tél: 0 800 222 555 Appel depuis l’étranger : +33 1 57 63 23 23</p><p><strong>Portugal</strong> Sanofi - Produtos Farmacêuticos, Lda Tel: +351 21 35 89 400</p><p><strong>Hrvatska</strong> Swixx Biopharma d.o.o. Tel: +385 1 2078 500</p><p><strong>Ireland</strong> sanofi-aventis Ireland Ltd. Tel: +353 (0) 1 403 56 00</p><p><strong>România</strong> Sanofi Romania SRL Tel: +40 (0) 21 317 31 36</p><p><strong>Slovenija</strong> Swixx Biopharma d.o.o. Tel: +386 1 235 51 00</p><p><strong>Ísland</strong> Vistor hf. Sími: +354 535 7000</p><p><strong>Slovenská republika</strong> Swixx Biopharma s.r.o. Tel: +421 2 208 33 600</p><p><strong>Italia</strong> Sanofi S.r.l.Tel: 800536389</p><p><strong>Suomi/Finland</strong> Sanofi Oy Puh/Tel: +358 (0) 201 200 300</p><p><strong>Κύπρος</strong> C.A. Papaellinas Ltd. Τηλ: +357 22 741741</p><p><strong>Sverige</strong> Sanofi AB Tel: +46 (0)8 634 50 00</p><p><strong>Latvija</strong> Swixx Biopharma SIA Tel: +371 6 616 47 50</p><p><strong>United Kingdom (Northern Ireland)</strong> sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +44 (0) 800 035 2525</p><p><strong>Este folheto foi revisto pela última vez em</strong></p><p>Informação pormenorizada sobre este medicamento está disponível na Internet no site da Agência Europeia de Medicamentos <a href=\"http://www.ema.europa.eu/\">http://www.ema.europa.eu/</a></p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-a40c2367ed3c1c715eacd432105752a0",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-a40c2367ed3c1c715eacd432105752a0",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-a40c2367ed3c1c715eacd432105752a0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-a40c2367ed3c1c715eacd432105752a0</b></p><a name=\"cud-a40c2367ed3c1c715eacd432105752a0\"> </a><a name=\"hccud-a40c2367ed3c1c715eacd432105752a0\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr 10012601}\">Diabetis Mellitus</span></td></tr></table></blockquote></div>"
      },
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "10012601",
              "display" : "Diabetis Mellitus"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-585e364c14debe29f6c6b564138aa400",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-585e364c14debe29f6c6b564138aa400",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-indication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-585e364c14debe29f6c6b564138aa400\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-585e364c14debe29f6c6b564138aa400</b></p><a name=\"cud-585e364c14debe29f6c6b564138aa400\"> </a><a name=\"hccud-585e364c14debe29f6c6b564138aa400\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-indication-uv-epi.html\">ClinicalUseDefinition Indication (ePI)</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr 10020772}\">Hypertension</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "10020772",
              "display" : "Hypertension"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-4fce9d5258f70f7d605059f97c24efa8",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-4fce9d5258f70f7d605059f97c24efa8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-interaction-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-4fce9d5258f70f7d605059f97c24efa8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-4fce9d5258f70f7d605059f97c24efa8</b></p><a name=\"cud-4fce9d5258f70f7d605059f97c24efa8\"> </a><a name=\"hccud-4fce9d5258f70f7d605059f97c24efa8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-interaction-uv-epi.html\">ClinicalUseDefinition Interaction (ePI)</a></p></div><p><b>type</b>: Interaction</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>interaction</b></p><h3>Interactants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ YL5FZ2Y5U1}\">METHOTREXATE</span></td></tr></table></blockquote></div>"
      },
      "type" : "interaction",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "interaction" : {
        "interactant" : [{
          "itemCodeableConcept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "YL5FZ2Y5U1",
              "display" : "METHOTREXATE"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-hypromellose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-hypromellose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-hypromellose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-hypromellose</b></p><a name=\"ingredient-for-karvea-hypromellose\"> </a><a name=\"hcingredient-for-karvea-hypromellose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/3NXW29V3WO (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 3NXW29V3WO}\">Hypromellose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "3NXW29V3WO"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "3NXW29V3WO",
              "display" : "Hypromellose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-macrogol3000",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-macrogol3000",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-macrogol3000\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-macrogol3000</b></p><a name=\"ingredient-for-karvea-macrogol3000\"> </a><a name=\"hcingredient-for-karvea-macrogol3000\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/SA1B764746 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta SA1B764746}\">Macrogol 3000</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "SA1B764746"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "SA1B764746",
              "display" : "Macrogol 3000"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-lactosemonohydrate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-lactosemonohydrate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-lactosemonohydrate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-lactosemonohydrate</b></p><a name=\"ingredient-for-karvea-lactosemonohydrate\"> </a><a name=\"hcingredient-for-karvea-lactosemonohydrate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EWQ57Q8I5X (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EWQ57Q8I5X}\">Lactose Monohydrate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EWQ57Q8I5X"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EWQ57Q8I5X",
              "display" : "Lactose Monohydrate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-silicondioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-silicondioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-silicondioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-silicondioxide</b></p><a name=\"ingredient-for-karvea-silicondioxide\"> </a><a name=\"hcingredient-for-karvea-silicondioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/ETJ7Z6XBU4 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta ETJ7Z6XBU4}\">Silicon dioxide</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "ETJ7Z6XBU4"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "ETJ7Z6XBU4",
              "display" : "Silicon dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-titaniumdioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-titaniumdioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-titaniumdioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-titaniumdioxide</b></p><a name=\"ingredient-for-karvea-titaniumdioxide\"> </a><a name=\"hcingredient-for-karvea-titaniumdioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/15FIX9V2JP (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 15FIX9V2JP}\">Titanium Dioxide</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "15FIX9V2JP"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "15FIX9V2JP",
              "display" : "Titanium Dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-irbesartan",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-irbesartan",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-irbesartan\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-irbesartan</b></p><a name=\"ingredient-for-karvea-irbesartan\"> </a><a name=\"hcingredient-for-karvea-irbesartan\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/J0E2756Z7N (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta J0E2756Z7N}\">irbesartan</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "J0E2756Z7N"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "J0E2756Z7N",
              "display" : "irbesartan"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 75,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-croscarmellosesodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-croscarmellosesodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-croscarmellosesodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-croscarmellosesodium</b></p><a name=\"ingredient-for-karvea-croscarmellosesodium\"> </a><a name=\"hcingredient-for-karvea-croscarmellosesodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/M28OL1HH48 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta M28OL1HH48}\">Croscarmellose sodium</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "M28OL1HH48"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "M28OL1HH48",
              "display" : "Croscarmellose sodium"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-microcrystallinecellulose</b></p><a name=\"ingredient-for-karvea-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-karvea-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">Microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "Microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-magnesiumstearate</b></p><a name=\"ingredient-for-karvea-magnesiumstearate\"> </a><a name=\"hcingredient-for-karvea-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-carnaubawax",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-carnaubawax",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-carnaubawax\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-carnaubawax</b></p><a name=\"ingredient-for-karvea-carnaubawax\"> </a><a name=\"hcingredient-for-karvea-carnaubawax\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/R12CBM0EIZ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta R12CBM0EIZ}\">Carnauba wax</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "R12CBM0EIZ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "R12CBM0EIZ",
              "display" : "Carnauba wax"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-irbesartan",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-irbesartan",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-irbesartan\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-irbesartan</b></p><a name=\"substance-irbesartan\"> </a><a name=\"hcsubstance-irbesartan\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/J0E2756Z7N (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>description</b>: </p><div><p>White to off-white, biconvex, and oval-shaped with a heart debossed on one side and the number 2771 engraved on the other side.</p>\n</div><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>428.53</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C25H28N6O</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(+)-6-methyleneandrosta-1,4-diene-3,17-dione</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "J0E2756Z7N"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "description" : "White to off-white, biconvex, and oval-shaped with a heart debossed on one side and the number 2771 engraved on the other side.",
      "manufacturer" : [{
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 428.53
        }
      }],
      "structure" : {
        "molecularFormula" : "C25H28N6O"
      },
      "name" : [{
        "name" : "(+)-6-methyleneandrosta-1,4-diene-3,17-dione",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-dcaa4d32aa6658a8df831551503e52ee",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-dcaa4d32aa6658a8df831551503e52ee</b></p><a name=\"ap-dcaa4d32aa6658a8df831551503e52ee\"> </a><a name=\"hcap-dcaa4d32aa6658a8df831551503e52ee\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee0</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/010 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-d91b269b209aaa5538a1bfafd1a7434d\">PackagedProductDefinition Karvea 75 mg tablet 14</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/010"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-d91b269b209aaa5538a1bfafd1a7434d"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee1",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee1",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee1</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-f3f2f89544dfc5d20216861bcf90c0c5\">PackagedProductDefinition Karvea 75 mg tablet 28</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-f3f2f89544dfc5d20216861bcf90c0c5"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee2",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee2",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee2</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/002 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-5763619e2b501aeeab53677bd09d5cbf\">PackagedProductDefinition Karvea 75 mg tablet 56</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/002"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-5763619e2b501aeeab53677bd09d5cbf"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee3",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee3",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee3</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/003 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-9b1d5d261d22694685deb35714ec08ea\">PackagedProductDefinition Karvea 75 mg tablet 98</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/003"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-9b1d5d261d22694685deb35714ec08ea"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-511671db37e83e520b00f8a0d817dc96",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-511671db37e83e520b00f8a0d817dc96",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-511671db37e83e520b00f8a0d817dc96\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-511671db37e83e520b00f8a0d817dc96</b></p><a name=\"mah-511671db37e83e520b00f8a0d817dc96\"> </a><a name=\"hcmah-511671db37e83e520b00f8a0d817dc96\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100011564 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Sanofi Winthrop Industrie\t</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>82 avenue Raspail Gentilly FR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100011564"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Sanofi Winthrop Industrie\t",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "82 avenue Raspail Gentilly FR",
          "line" : ["82 avenue Raspail"],
          "city" : "Gentilly",
          "postalCode" : "94250",
          "country" : "FR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/man-4bb7a752921434fd5f9921b5b9473eda",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "man-4bb7a752921434fd5f9921b5b9473eda",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_man-4bb7a752921434fd5f9921b5b9473eda\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization man-4bb7a752921434fd5f9921b5b9473eda</b></p><a name=\"man-4bb7a752921434fd5f9921b5b9473eda\"> </a><a name=\"hcman-4bb7a752921434fd5f9921b5b9473eda\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100011564 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000033}\">Manufacturer</span></p><p><b>name</b>: Sanofi Winthrop Industrie</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>1, rue de la Vierge Ambarès &amp; Lagrave FR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100011564"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000033",
          "display" : "Manufacturer"
        }]
      }],
      "name" : "Sanofi Winthrop Industrie",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "1, rue de la Vierge Ambarès & Lagrave FR",
          "line" : ["1, rue de la Vierge"],
          "city" : "Ambarès & Lagrave",
          "postalCode" : "33565",
          "country" : "FR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-d91b269b209aaa5538a1bfafd1a7434d",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-d91b269b209aaa5538a1bfafd1a7434d",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-d91b269b209aaa5538a1bfafd1a7434d</b></p><a name=\"ppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><a name=\"hcppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/010 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 14</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 14</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/010"
      }],
      "name" : "Karvea 75 mg tablet 14",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 14,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-f3f2f89544dfc5d20216861bcf90c0c5",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-f3f2f89544dfc5d20216861bcf90c0c5",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-f3f2f89544dfc5d20216861bcf90c0c5</b></p><a name=\"ppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><a name=\"hcppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 28</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 28</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "name" : "Karvea 75 mg tablet 28",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 28,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-5763619e2b501aeeab53677bd09d5cbf",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-5763619e2b501aeeab53677bd09d5cbf",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-5763619e2b501aeeab53677bd09d5cbf</b></p><a name=\"ppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><a name=\"hcppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/002 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 56</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 56</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/002"
      }],
      "name" : "Karvea 75 mg tablet 56",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 56,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-9b1d5d261d22694685deb35714ec08ea",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-9b1d5d261d22694685deb35714ec08ea",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-9b1d5d261d22694685deb35714ec08ea\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-9b1d5d261d22694685deb35714ec08ea</b></p><a name=\"ppd-9b1d5d261d22694685deb35714ec08ea\"> </a><a name=\"hcppd-9b1d5d261d22694685deb35714ec08ea\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/003 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 98</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 98</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/003"
      }],
      "name" : "Karvea 75 mg tablet 98",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 98,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp873a1a47330e628770640f9c96c0761e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp873a1a47330e628770640f9c96c0761e</b></p><a name=\"mp873a1a47330e628770640f9c96c0761e\"> </a><a name=\"hcmp873a1a47330e628770640f9c96c0761e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E82719</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Karvea 75 mg tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Karvea</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: irbesartan</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 75 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 DK}\">Denmark</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 DK}\">Denmark</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E82719"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Karvea 75 mg tablet",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Karvea",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "irbesartan",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "75 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "tablet",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "DK",
              "display" : "Denmark"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "DK",
              "display" : "Denmark"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-dcaa4d32aa6658a8df831551503e52ee",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-dcaa4d32aa6658a8df831551503e52ee</b></p><a name=\"mid-dcaa4d32aa6658a8df831551503e52ee\"> </a><a name=\"hcmid-dcaa4d32aa6658a8df831551503e52ee\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/contraindication-kidney",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "contraindication-kidney",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_contraindication-kidney\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition contraindication-kidney</b></p><a name=\"contraindication-kidney\"> </a><a name=\"hccontraindication-kidney\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/kidney function (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 76114004}\">Decreased renal function (finding)</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "kidney function"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "76114004",
              "display" : "Decreased renal function (finding)"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/contraindication-diabetes-mellitus",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "contraindication-diabetes-mellitus",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_contraindication-diabetes-mellitus\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition contraindication-diabetes-mellitus</b></p><a name=\"contraindication-diabetes-mellitus\"> </a><a name=\"hccontraindication-diabetes-mellitus\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/diabetes-mellitus (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 73211009}\">Diabetes mellitus (disorder)</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "diabetes-mellitus"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "73211009",
              "display" : "Diabetes mellitus (disorder)"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/contraindication-pregnancy",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "contraindication-pregnancy",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_contraindication-pregnancy\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition contraindication-pregnancy</b></p><a name=\"contraindication-pregnancy\"> </a><a name=\"hccontraindication-pregnancy\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/pregnancy (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 289908002}\">Pregnancy, function (observable entity)</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "pregnancy"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "289908002",
              "display" : "Pregnancy, function (observable entity)"
            }]
          }
        }
      }
    }
  }]
}

```
