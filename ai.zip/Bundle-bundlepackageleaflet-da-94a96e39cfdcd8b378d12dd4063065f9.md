# ePI document Bundle for Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion Package Leaflet for language da - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion Package Leaflet for language da**

## Example Bundle: ePI document Bundle for Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion Package Leaflet for language da

**Composition category:**Raw

**Composition status:**final

### B. INDLÆGSSEDDEL

 

unavailable


#### Indlægsseddel: Information til brugeren

 

B. INDLÆGSSEDDEL

Indlægsseddel: Information til brugeren

Biktarvy 30 mg/120 mg/15 mg filmovertrukne tabletter bictegravir/emtricitabin/tenofoviralafenamid

Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger. - Gem indlægssedlen. Du kan få brug for at læse den igen. - Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide. - Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give lægemidlet til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har. - Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se punkt 4.
Hvis Biktarvy er ordineret til dit barn, skal du bemærke, at alle oplysninger i denne indlægsseddel er rettet mod dit barn (i det tilfælde skal du læse ”dit barn” i stedet for ”du/dig”).

Se den nyeste indlægsseddel på www.indlaegsseddel.dk


#### Oversigt over indlægssedlen

 

Oversigt over indlægssedlen

1. Virkning og anvendelse
1. Det skal du vide, før du begynder at tage Biktarvy
1. Sådan skal du tage Biktarvy
1. Bivirkninger
1. Opbevaring
1. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

Biktarvy indeholder tre aktive stoffer:

* bictegravir, et antiretroviralt lægemiddel, der kaldes en integrase-streng-transfer-hæmmer (INSTI)
* emtricitabin, et antiretroviralt lægemiddel, af en type, der kaldes en nukleosid-revers transkriptase-hæmmer (NRTI)
* tenofoviralafenamid, et antiretroviralt lægemiddel, af en type, der kaldes en nukleotid-revers transkriptase-hæmmer (NtRTI)

Biktarvy er en enkelt tablet til behandling af infektion med humant immundefekt virus 1 (hiv 1) hos voksne, børn og unge på 2 år og ældre, som vejer mindst 14 kg.

Biktarvy nedsætter mængden af hiv i din krop. Dette vil forbedre dit immunsystem og nedsætte risikoen for at udvikle sygdomme forbundet med hiv-infektionen.


#### 2. Det skal du vide, før du begynder at tage Biktarvy

 

Tag ikke Biktarvy

* Hvis du er allergisk over for bictegravir, emtricitabin, tenofoviralafenamid eller et af de øvrige indholdsstoffer i Biktarvy (angivet i punkt 6 i denne indlægsseddel).
* Hvis du for tiden tager et af disse lægemidler:
* rifampicin anvendes til at behandle visse bakterieinfektioner som f.eks. tuberkulose
* perikon (Hypericum perforatum), et naturlægemiddel, der anvendes mod depression og angst, eller et lægemiddel, der indeholder det.

→ Hvis noget af dette gælder for dig, må du ikke tage Biktarvy. Fortæl det omgående til din læge.

Advarsler og forsigtighedsregler

Kontakt lægen, før du tager Biktarvy:

* Hvis du har eller har haft leverproblemer, herunder hepatitis. Patienter med leversygdom, herunder kronisk hepatitis B eller C, som bliver behandlet med antiretrovirale lægemidler, har en højere risiko for alvorlige og potentielt dødelige leverkomplikationer. Hvis du har hepatitis B-infektion, vil lægen overveje nøje, hvilken behandling, der er bedst for dig.
* Hvis du har hepatitis B-infektion. Leverproblemer kan forværres, når du stopper med at tage Biktarvy.
→ Du må ikke stoppe med at tage Biktarvy, hvis du har hepatitis B. Kontakt lægen først. Du finder yderligere oplysninger i punkt 3, Hold ikke op med at tage Biktarvy.
* Hvis du har haft nyresygdom eller hvis prøver har vist problemer med dine nyrer. Ved påbegyndelse af og under behandling med Biktarvy kan din læge bestille blodprøver for at overvåge, hvordan dine nyrer virker.
* Mens du tager Biktarvy

Når du begynder med at tage Biktarvy, skal du holde øje med:

* Tegn på betændelse eller infektion
* Ledsmerter, stivhed eller knogleproblemer

→ Hvis du bemærker nogle af disse symptomer, skal du straks fortælle det til lægen. Se punkt 4, Bivirkninger, for yderligere oplysninger.

Du kan muligvis opleve nyreproblemer, når du tager Biktarvy i en langvarig periode (se Advarsler og forsigtighedsregler).

Dette lægemiddel helbreder ikke hiv-infektionen. Mens du tager Biktarvy, kan du stadig udvikle infektioner eller andre sygdomme, der er forbundet med hiv-infektion.

Børn og unge

Dette lægemiddel må ikke gives til børn under 2 år, eller som vejer mindre end 14 kg uanset alder. Der er endnu ikke lavet undersøgelser med brug af Biktarvy hos børn under 2 år, eller som vejer mindre end 14 kg. Der findes Biktarvy 50 mg/200 mg/25 mg filmovertrukne tabletter til børn og unge, som vejer 25 kg eller mere.

Der er rapporteret tab af knoglemasse hos nogle børn i alderen 3 til under 12 år, som får et af lægemidlerne (tenofoviralafenamid) indeholdt i Biktarvy. Virkningen på langsigtet knoglesundhed og fremtidig frakturrisiko hos børn er uvis. Din læge vil overvåge dit barns knoglesundhed efter behov.

Brug af andre lægemidler sammen med Biktarvy

Fortæl altid lægen eller apotekspersonalet, hvis du tager andre lægemidler, for nylig har taget andre lægemidler eller planlægger at tage andre lægemidler. Biktarvy kan påvirke eller påvirkes af andre lægemidler. Som et resultat heraf kan mængden af Biktarvy eller andre lægemidler i dit blod

påvirkes. Dette kan forhindre, at dit lægemiddel virker korrekt, eller det kan gøre bivirkninger værre. I nogle tilfælde kan det være nødvendigt, at lægen justerer din dosis eller kontrollerer dit blod.

Lægemidler, der aldrig må tages sammen med Biktarvy:

* rifampicin anvendes til at behandle visse bakterieinfektioner som f.eks. tuberkulose
* Perikon (Hypericum perforatum), et naturlægemiddel, der anvendes til depression og angst, eller et lægemiddel, der indeholder det.

→ Hvis du tager nogen af disse lægemidler, må du ikke tage Biktarvy. Fortæl det straks til lægen.

Kontakt lægen, hvis du tager:

* lægemidler, der anvendes til at behandle hiv og/eller hepatitis B, og som indeholder:
* adefovir-dipivoxil, atazanavir, bictegravir, emtricitabin, lamivudin, tenofoviralafenamid eller tenofovirdisoproxil
* antibiotika, der anvendes til at behandle bakterieinfektioner, og indeholder:
* azithromycin, clarithromycin, rifabutin eller rifapentin
* antikonvulsiva, der anvendes til at behandle epilepsi, og som indeholder:
* carbamazepin, oxcarbazepin, phenobarbital eller phenytoin
* immunundertrykkende midler, der anvendes til at kontrollere kroppens immunrespons efter en transplantation, såsom ciclosporin
* lægemidler til heling af mavesår, der indeholder sucralfat

→ Fortæl det til lægen, hvis du tager nogen af disse lægemidler. Afbryd ikke behandlingen uden først at kontakte din læge.

Spørg lægen eller apotekspersonalet til råds, hvis du tager:

* syreneutraliserende lægemidler til behandling af mavesår, halsbrand eller sure opstød, der indeholder aluminium og/eller magnesiumhydroxid
* mineraltilskud eller vitaminer, der indeholder magnesium eller jern

→ Spørg lægen eller apotekspersonalet til råds, før du tager Biktarvy, hvis du tager et eller flere af disse lægemidler. Syreneutraliserende midler og magnesiumtilskud: Du skal tage Biktarvy mindst 2 timer før syreneutraliserende midler eller tilskud indeholdende aluminium og/eller magnesium. Ellers skal du tage Biktarvy sammen med mad mindst 2 timer efter. Jerntilskud: Du skal tage Biktarvy mindst 2 timer før jerntilskud, eller du kan tage begge præparater i forbindelse med et måltid.

Graviditet og amning

* Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge eller apotekspersonalet til råds, før du tager dette lægemiddel.
* Fortæl det straks til lægen, hvis du bliver gravid, og spørg om de potentielle fordele og risici for dig og dit barn i forbindelse med din antiretrovirale behandling.

Hvis du har taget Biktarvy under din graviditet, kan lægen anmode om regelmæssige blodprøver og andre diagnostiske undersøgelser for at overvåge barnets udvikling. For de børn, hvis mødre har taget nukleosid-revers transkriptase-hæmmere (NRTI’er) i løbet af graviditeten, opvejede fordelen ved beskyttelse mod hiv risikoen ved bivirkningerne.

Du må ikke amme, mens du er i behandling med Biktarvy, fordi nogle af de aktive stoffer i dette lægemiddel udskilles i mælken hos mennesker. Amning anbefales ikke hos kvinder, der er hiv- positive, da hiv-infektion kan overføres til barnet gennem modermælken. Hvis du ammer eller påtænker at amme, bør du drøfte det med lægen hurtigst muligt.

Trafik- og arbejdssikkerhed

Biktarvy kan forårsage svimmelhed. Kør ikke motorkøretøj eller på cykel, og lad være med at arbejde med værktøj eller maskiner, hvis du bliver svimmel, når du tager Biktarvy.

Biktarvy indeholder natrium

Dette lægemiddel indeholder mindre end 1 mmol (23 mg) natrium pr. tablet, dvs. det er i det væsentlige natriumfrit.


#### 3. Sådan skal du tage Biktarvy

 

Tag altid lægemidlet nøjagtigt efter lægens eller apotekspersonalets anvisning. Er du i tvivl, så spørg lægen eller apotekspersonalet.

Biktarvy-tabletter fås i to styrker. Din læge vil ordinere den tablet, der passer til din alder og vægt.

Den anbefalede dosis er:

Børn på 2 år og ældre, som vejer mindst 14 kg, men mindre end 25 kg: én tablet om dagen med eller uden mad (en 30 mg/120 mg/15 mg tablet).

På grund af den bitre smag anbefales det, at tabletten ikke tygges eller knuses. Hvis du har svært ved at sluge tabletten hel, kan du dele den. Tag begge halvdele af tabletten, den ene efter den anden, for at få den fulde dosis. Gem ikke den delte tablet.

Delekærven på tabletter er der kun som en hjælp til at dele tabletten, hvis dit barn har svært ved at sluge den hel.

Multipakningen til 90 dage indeholder tre pakninger til 30 dage. → Spørg lægen eller apotekspersonalet til råds, hvis du tager:

* syreneutraliserende lægemidler til behandling af mavesår, halsbrand eller sure opstød, der indeholder aluminium og/eller magnesiumhydroxid
* mineraltilskud eller vitaminer, der indeholder magnesium eller jern → Se punkt 2 for yderligere oplysninger om brug af disse lægemidler sammen med Biktarvy.

Hvis du er i dialyse, skal du tage din daglige dosis Biktarvy efter dialysen er gennemført.

Hvis du har taget for meget Biktarvy

Hvis du ved et uheld tager mere end den anbefalede dosis Biktarvy, kan du have højere risiko for at få bivirkninger med dette lægemiddel (se punkt 4, Bivirkninger).

Kontakt straks lægen eller den nærmeste skadestue for at få råd. Tag tabletbeholderen eller æsken med, så du let kan vise, hvad du har taget.

Hvis du har glemt at tage Biktarvy

Det er vigtigt, at du husker at tage hver dosis af Biktarvy.

Hvis du har glemt at tage en dosis:

* Hvis du kommer i tanker om det inden for 18 timer efter det tidspunkt, du normalt tager Biktarvy på, skal du tage tabletten så hurtigt som muligt. Derefter tages den næste dosis som sædvanligt.
* Hvis du kommer i tanker om det 18 timer eller længere efter det tidspunkt, du normalt tager Biktarvy på, skal du ikke tage den glemte dosis. Vent og tag den næste dosis til sædvanlig tid.

Hvis du kaster op mindre end 1 time efter, du har taget Biktarvy, skal du tage en ny tablet. Hvis du kaster op mere end 1 time efter, at du har taget Biktarvy, er det ikke nødvendigt at tage en ny tablet før den sædvanlige planlagte tablet.

Hold ikke op med at tage Biktarvy

Hold ikke op med at tage Biktarvy uden at tale med din læge. Hvis du holder op med at tage Biktarvy, kan det i alvorlig grad påvirke virkningen af fremtidig behandling. Hvis Biktarvy stoppes uanset årsagen, skal du tale med din læge, før du igen begynder at tage Biktarvy tabletter.

Når du snart ikke har mere af Biktarvy, skal du bede om mere fra lægen eller på apoteket. Dette er meget vigtigt, da virusmængden igen kan begynde at stige, hvis lægemidlet stoppes, selv i kort tid. Sygdommen kan så blive sværere at behandle.

Hvis du har både hiv-infektion og hepatitis B, er det særlig vigtigt ikke at ophøre med behandlingen med Biktarvy uden først at konsultere din læge. Det kan være nødvendigt at få taget blodprøver i flere måneder efter ophør med behandlingen. Hos nogle patienter med fremskreden leversygdom eller cirrose bør behandlingen ikke ophøre, fordi det kan medføre en forværring af din hepatitis, hvilket kan være livstruende.

→ Bemærker du nogle nye eller usædvanlige symptomer efter behandlingens ophør, skal du omgående oplyse din læge herom, især hvis det drejer sig om symptomer, som du normalt ville forbinde med hepatitis B-infektion.

Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.


#### 4. Bivirkninger

 

Dette lægemiddel kan som alle andre lægemidler give bivirkninger, men ikke alle får bivirkninger.

Mulige bivirkninger: Fortæl det straks til lægen

* Ethvert tegn på betændelse eller infektion. Hos nogle patienter med fremskreden hiv-infektion (aids) og tidligere opportunistiske infektioner (infektioner, der forekommer hos personer med et svagt immunsystem) kan der forekomme tegn og symptomer på betændelse fra tidligere infektioner kort tid efter behandlingen mod hiv startes. Det menes, at disse symptomer skyldes en forbedring af kroppens immunreaktion, hvilket gør kroppen i stand til at bekæmpe infektioner, der kan have været til stede uden nogen tydelige symptomer.
* Autoimmunsygdomme, når immunsystemet angriber sundt kropsvæv, kan også opstå, efter du begynder at tage lægemidler for hiv-infektion. Autoimmunsygdomme kan opstå mange måneder efter behandlingsstart. Vær opmærksom på symptomer på infektion eller andre symptomer, såsom:
* muskelsvaghed
* svaghed, der begynder i hænder og fødder og bevæger sig op mod selve kroppen
* hjertebanken, rysten eller hyperaktivitet

→ Hvis du bemærker disse eller andre symptomer på betændelse eller infektion, skal du straks fortælle det til din læge.

Almindelige bivirkninger (kan forekomme hos op til 1 ud af 10 personer)

* depression
* unormale drømme
* hovedpine
* svimmelhed
* diarré
* kvalme
* træthed

Ikke almindelige bivirkninger (kan forekomme hos op til 1 ud af 100 personer)

* lavt antal røde blodlegemer (anæmi)
* opkastning
* mavesmerter
* problemer med fordøjelsen, som resulterer i ubehag efter måltider (dyspepsi)
* afgang af tarmluft (flatulens)
* hævelse af ansigt, læber, tunge eller svælg (angioødem)
* kløe (pruritus)
* udslæt
* nældefeber (urticaria)
* ledsmerter (artralgi)
* selvmordstanker og selvmordsforsøg (især hos patienter, som tidligere har haft depression eller psykiske problemer)
* angst
* søvnforstyrrelser

Blodprøver kan også vise:

* højere niveauer af stofferne bilirubin og/eller serumkreatinin i blodet

Sjældne bivirkninger (kan forekomme hos op til 1 ud af 1.000 personer)

* Stevens-Johnsons syndrom (SJS) er en alvorlig, livstruende tilstand, som normalt begynder med influenzalignende symptomer. Et par dage senere fremkommer andre symptomer, herunder:
* Smertefuld rød eller lilla hud, der ser brændt ud og skaller af
* Blærer på huden, i munden, næsen og på kønsdelene
* Røde, smertende øjne, der løber i vand

→ Hvis du har nogen af disse symptomer, skal du straks stoppe med lægemidlet og fortælle det til lægen med det samme.

→ Hvis nogle af bivirkningerne bliver alvorlige, skal du fortælle det til lægen.

Andre bivirkninger, der kan observeres under hiv-behandling

Hyppigheden af de følgende bivirkninger er ikke kendt (hyppigheden kan ikke estimeres ud fra forhåndenværende data).

* Knogleproblemer. Nogle patienter, der tager antiretroviral kombinationslægemiddel, såsom Biktarvy kan udvikle en knoglesygdom, der kaldes osteonekrose (knoglevævsdød, forårsaget af manglende blodforsyning til knoglerne). Indtagelse af denne type lægemiddel i lang tid, indtagelse af binyrebarkhormoner, indtagelse af alkohol, et meget svagt immunsystem og overvægt kan være nogle af de mange risikofaktorer for at udvikle denne sygdom. Tegn på osteonekrose er:
* stivhed i led
* smerter (især i hofter, knæ og skuldre)
* bevægelsesbesvær

→ Hvis du bemærker nogle af disse symptomer, skal du fortælle det til lægen.

Under hiv-behandling kan der forekomme vægtstigning samt forhøjede niveauer af lipider og glucose i blodet. Dette er til dels forbundet med forbedret helbredstilstand og med livsstil, og for lipidernes vedkommende sommetider med selve hiv-lægemidlet. Lægen vil holde øje med disse ændringer.

Indberetning af bivirkninger Hvis du oplever bivirkninger, bør du tale med din læge eller apotekspersonalet. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via det nationale rapporteringssystem anført i Appendiks V. Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.


#### 5. Opbevaring

 

Opbevar lægemidlet utilgængeligt for børn.

Brug ikke lægemidlet efter den udløbsdato, der står på æsken og tabletbeholderen eller blisterkortene efter {EXP}. Udløbsdatoen er den sidste dag i den nævnte måned.

Opbevares i den originale yderpakning for at beskytte mod fugt. Hold tabletbeholderen tæt tillukket. Må ikke anvendes, hvis forseglingen over beholderens åbning er brudt eller mangler.

Spørg apotekspersonalet, hvordan du skal bortskaffe lægemiddelrester. Af hensyn til miljøet må du ikke smide lægemiddelrester i afløbet, toilettet eller skraldespanden.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

Biktarvy indeholder

Aktive stoffer: bictegravir, emtricitabin og tenofoviralafenamid. Hver Biktarvy-tablet indeholder bictegravirnatrium svarende til 30 mg bictegravir, 120 mg emtricitabin og tenofoviralafenamidfumarat svarende til 15 mg tenofoviralafenamid.

Øvrige indholdsstoffer

Tabletkerne Microkrystallinsk cellulose (E460), croscarmellosenatrium (E468), magnesiumstearat (E470b).

Filmovertræk Polyvinylalkohol (E203), titandioxid (E171), macrogol (E1521), talcum (E553b), jernoxid, rød (E172), jernoxid, sort (E172).

Udseende og pakningsstørrelser

Biktarvy 30 mg/120 mg/15 mg filmovertrukne tabletter er lyserøde, kapselformede, filmovertrukne tabletter, der er præget med "BVY" på den ene side og en delekærv på den anden side.

Tabletterne fås i en tabletbeholder. Ikke alle pakningsstørrelser er nødvendigvis markedsført.

Biktarvy fås i tabletbeholdere med 30 tabletter samt i pakninger med 3 tabletbeholdere, hver med 30 tabletter. Hver tabletbeholder indeholder et silicagel-tørremiddel, der skal opbevares i tabletbeholderen for at hjælpe med at beskytte tabletterne. Silicagel-tørremidlet er i et separat brev eller en separat beholder og må ikke sluges.

Indehaver af markedsføringstilladelsen Gilead Sciences Ireland UC Carrigtohill County Cork, T45 DPIrland

Fremstiller Gilead Sciences Ireland UC IDA Business & Technology Park Carrigtohill County Cork Irland

Hvis du ønsker yderligere oplysninger om dette lægemiddel, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:

België/Belgique/Belgien Gilead Sciences Belgium SRL-BV Tél/Tel: + 32 (0) 24 01 35
Lietuva Gilead Sciences Ireland UC Tel.: + 353 (0) 1 686 1 България Gilead Sciences Ireland UC Тел.: + 353 (0) 1 686 1 Luxembourg/Luxemburg Gilead Sciences Belgium SRL-BV Tél/Tel: + 32 (0) 24 01 35
Česká republika Gilead Sciences s.r.o. Tel: + 420 (0) 910 871
Magyarország Gilead Sciences Ireland UC Tel.: + 353 (0) 1 686 1 Danmark Gilead Sciences Sweden AB Tlf.: + 46 (0) 8 5057 1 Malta Gilead Sciences Ireland UC Tel: + 353 (0) 1 686 1Deutschland Gilead Sciences GmbH Tel: + 49 (0) 89 899890-0

Nederland Gilead Sciences Netherlands B.V. Tel: + 31 (0) 20 718 36
Eesti Gilead Sciences Ireland UC Tel.: +353 (0) 1 686 1Norge Gilead Sciences Sweden AB Tlf: + 46 (0) 8 5057 1 Ελλάδα Gilead Sciences Ελλάς Μ.ΕΠΕ. Τηλ: + 30 (0) 210 8930
Österreich Gilead Sciences GesmbH Tel: + 43 (0) 1 260
España Gilead Sciences, S.L. Tel: + 34 (0) 91 378 98
Polska Gilead Sciences Poland Sp. z o.o. Tel.: + 48 (0) 22 262 8 France Gilead Sciences Tél: + 33 (0) 1 46 09 41
Portugal Gilead Sciences, Lda. Tel: + 351 (0) 21 7928 Hrvatska Gilead Sciences Ireland UC Tel: + 353 (0) 1 686 1 România Gilead Sciences (GSR) S.R.L Tel: + 40 31 631 18

Ireland Gilead Sciences Ireland UC Tel: + 353 (0) 214 825
Slovenija Gilead Sciences Ireland UC Tel: + 353 (0) 1 686 1 Ísland Gilead Sciences Sweden AB Sími: + 46 (0) 8 5057 1 Slovenská republika Gilead Sciences Slovakia s.r.o. Tel: + 421 (0) 232 121
Italia Gilead Sciences S.r.l. Tel: + 39 02 439 Suomi/Finland Gilead Sciences Sweden AB Puh/Tel: + 46 (0) 8 5057 1 Κύπρος Gilead Sciences Ελλάς Μ.ΕΠΕ. Τηλ: + 30 (0) 210 8930
Sverige Gilead Sciences Sweden AB Tel: + 46 (0) 8 5057 1 Latvija Gilead Sciences Ireland UC Tel.: + 353 (0) 1 686 1 United Kingdom (Northern Ireland) Gilead Sciences Ireland UC Tel: + 44 (0) 8000 113

Denne indlægsseddel blev senest ændret

Du kan finde yderligere oplysninger om dette lægemiddel på Det Europæiske Lægemiddelagenturs hjemmeside http://www.ema.europa.eu/.

Indlægsseddel: Information til brugeren

Biktarvy 50 mg/200 mg/25 mg filmovertrukne tabletter bictegravir/emtricitabin/tenofoviralafenamid

Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger. - Gem indlægssedlen. Du kan få brug for at læse den igen. - Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide. - Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give lægemidlet til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har. - Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se punkt 4.
Hvis Biktarvy er ordineret til dit barn, skal du bemærke, at alle oplysninger i denne indlægsseddel er rettet mod dit barn (i det tilfælde skal du læse ”dit barn” i stedet for ”du/dig”).

Se den nyeste indlægsseddel på www.indlaegsseddel.dk


####  Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 
PMSWI:
** EU/1/18/1289/001 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E827gy **
-------

Full name: **Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion**

 - Invented name part: ** Biktarvy ** 

 - Scientific name part: ** bictegravir/emtricitabine/tenofovir alafenamide ** 

 - Strength part: ** 50 mg/200 mg/25 mg ** 

 - Pharmaceutical dose form part: ** film-coated tablets ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/18/1289/001 ** 

 Region: ** ** 

Marketing authorisation holder: **Gilead Sciences Ireland UC** 

 Identifier: 
*  **ORG-100008368** 
 

 Status: ** Active (2018-06-21T13:28:17Z) ** 

 Package 1 of 2

PMSWI: ** EU/1/18/1289/001 ** 

GTIN: ** 07612345678904 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **90 Child-resistant closure** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Child-resistant closure** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

 Package 2 of 2

PMSWI: ** EU/1/18/1289/001 ** 

Description:

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/18/1289/001"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-da-2a9c4333cfd126f2e7b73ad3cafd6949",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-da-2a9c4333cfd126f2e7b73ad3cafd6949",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_composition-da-2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-da-2a9c4333cfd126f2e7b73ad3cafd6949</b></p><a name=\"composition-da-2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><a name=\"hccomposition-da-2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/c97bc0c62de4cf4143e63299ba73c5a3</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mah-715f8a161ed438d0584510e5b4512caa\">Organization Gilead Sciences Ireland UC</a></p><p><b>title</b>: TEST PURPOSES ONLY - Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "c97bc0c62de4cf4143e63299ba73c5a3"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-715f8a161ed438d0584510e5b4512caa"
      }],
      "title" : "TEST PURPOSES ONLY - Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. INDLÆGSSEDDEL",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. INDLÆGSSEDDEL"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Indlægsseddel: Information til brugeren",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Indlægsseddel: Information til brugeren"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>B. INDLÆGSSEDDEL</p><p>Indlægsseddel: Information til brugeren</p><p>Biktarvy 30 mg/120 mg/15 mg filmovertrukne tabletter bictegravir/emtricitabin/tenofoviralafenamid</p><p>Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger. - Gem indlægssedlen. Du kan få brug for at læse den igen. - Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide. - Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give lægemidlet til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har. - Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se punkt 4.<br/>Hvis Biktarvy er ordineret til dit barn, skal du bemærke, at alle oplysninger i denne indlægsseddel er rettet mod dit barn (i det tilfælde skal du læse ”dit barn” i stedet for ”du/dig”).</p><p>Se den nyeste indlægsseddel på www.indlaegsseddel.dk</p></div>"
          }
        },
        {
          "title" : "Oversigt over indlægssedlen",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Oversigt over indlægssedlen"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Oversigt over indlægssedlen</p><ol><li>Virkning og anvendelse</li><li>Det skal du vide, før du begynder at tage Biktarvy</li><li>Sådan skal du tage Biktarvy</li><li>Bivirkninger</li><li>Opbevaring</li><li>Pakningsstørrelser og yderligere oplysninger</li></ol></div>"
          }
        },
        {
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Virkning og anvendelse"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Biktarvy indeholder tre aktive stoffer:</p><ul><li><p>bictegravir, et antiretroviralt lægemiddel, der kaldes en integrase-streng-transfer-hæmmer (INSTI)</p></li><li><p>emtricitabin, et antiretroviralt lægemiddel, af en type, der kaldes en nukleosid-revers transkriptase-hæmmer (NRTI)</p></li><li><p>tenofoviralafenamid, et antiretroviralt lægemiddel, af en type, der kaldes en nukleotid-revers transkriptase-hæmmer (NtRTI)</p></li></ul><p>Biktarvy er en enkelt tablet til behandling af infektion med humant immundefekt virus 1 (hiv 1) hos voksne, børn og unge på 2 år og ældre, som vejer mindst 14 kg.</p><p>Biktarvy nedsætter mængden af hiv i din krop. Dette vil forbedre dit immunsystem og nedsætte risikoen for at udvikle sygdomme forbundet med hiv-infektionen.</p></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du begynder at tage  Biktarvy",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Det skal du vide, før du begynder at tage  Biktarvy"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Tag ikke Biktarvy</p><ul><li><p>Hvis du er allergisk over for bictegravir, emtricitabin, tenofoviralafenamid eller et af de øvrige indholdsstoffer i Biktarvy (angivet i punkt 6 i denne indlægsseddel).</p></li><li><p>Hvis du for tiden tager et af disse lægemidler:</p></li><li>rifampicin anvendes til at behandle visse bakterieinfektioner som f.eks. tuberkulose</li><li>perikon (Hypericum perforatum), et naturlægemiddel, der anvendes mod depression og angst, eller et lægemiddel, der indeholder det.</li></ul><p>→ Hvis noget af dette gælder for dig, må du ikke tage Biktarvy. Fortæl det omgående til din læge.</p><p>Advarsler og forsigtighedsregler</p><p>Kontakt lægen, før du tager Biktarvy:</p><ul><li><p>Hvis du har eller har haft leverproblemer, herunder hepatitis. Patienter med leversygdom, herunder kronisk hepatitis B eller C, som bliver behandlet med antiretrovirale lægemidler, har en højere risiko for alvorlige og potentielt dødelige leverkomplikationer. Hvis du har hepatitis B-infektion, vil lægen overveje nøje, hvilken behandling, der er bedst for dig.</p></li><li><p>Hvis du har hepatitis B-infektion. Leverproblemer kan forværres, når du stopper med at tage Biktarvy.<br/>→ Du må ikke stoppe med at tage Biktarvy, hvis du har hepatitis B. Kontakt lægen først. Du finder yderligere oplysninger i punkt 3, Hold ikke op med at tage Biktarvy.</p></li><li><p>Hvis du har haft nyresygdom eller hvis prøver har vist problemer med dine nyrer. Ved påbegyndelse af og under behandling med Biktarvy kan din læge bestille blodprøver for at overvåge, hvordan dine nyrer virker.</p></li><li><p>Mens du tager Biktarvy</p></li></ul><p>Når du begynder med at tage Biktarvy, skal du holde øje med:</p><ul><li><p>Tegn på betændelse eller infektion</p></li><li><p>Ledsmerter, stivhed eller knogleproblemer</p></li></ul><p>→ Hvis du bemærker nogle af disse symptomer, skal du straks fortælle det til lægen. Se punkt 4, Bivirkninger, for yderligere oplysninger.</p><p>Du kan muligvis opleve nyreproblemer, når du tager Biktarvy i en langvarig periode (se Advarsler og forsigtighedsregler).</p><p>Dette lægemiddel helbreder ikke hiv-infektionen. Mens du tager Biktarvy, kan du stadig udvikle infektioner eller andre sygdomme, der er forbundet med hiv-infektion.</p><p>Børn og unge</p><p>Dette lægemiddel må ikke gives til børn under 2 år, eller som vejer mindre end 14 kg uanset alder. Der er endnu ikke lavet undersøgelser med brug af Biktarvy hos børn under 2 år, eller som vejer mindre end 14 kg. Der findes Biktarvy 50 mg/200 mg/25 mg filmovertrukne tabletter til børn og unge, som vejer 25 kg eller mere.</p><p>Der er rapporteret tab af knoglemasse hos nogle børn i alderen 3 til under 12 år, som får et af lægemidlerne (tenofoviralafenamid) indeholdt i Biktarvy. Virkningen på langsigtet knoglesundhed og fremtidig frakturrisiko hos børn er uvis. Din læge vil overvåge dit barns knoglesundhed efter behov.</p><p>Brug af andre lægemidler sammen med Biktarvy</p><p>Fortæl altid lægen eller apotekspersonalet, hvis du tager andre lægemidler, for nylig har taget andre lægemidler eller planlægger at tage andre lægemidler. Biktarvy kan påvirke eller påvirkes af andre lægemidler. Som et resultat heraf kan mængden af Biktarvy eller andre lægemidler i dit blod</p><p>påvirkes. Dette kan forhindre, at dit lægemiddel virker korrekt, eller det kan gøre bivirkninger værre. I nogle tilfælde kan det være nødvendigt, at lægen justerer din dosis eller kontrollerer dit blod.</p><p>Lægemidler, der aldrig må tages sammen med Biktarvy:</p><ul><li><p>rifampicin anvendes til at behandle visse bakterieinfektioner som f.eks. tuberkulose</p></li><li><p>Perikon (Hypericum perforatum), et naturlægemiddel, der anvendes til depression og angst, eller et lægemiddel, der indeholder det.</p></li></ul><p>→ Hvis du tager nogen af disse lægemidler, må du ikke tage Biktarvy. Fortæl det straks til lægen.</p><p>Kontakt lægen, hvis du tager:</p><ul><li>lægemidler, der anvendes til at behandle hiv og/eller hepatitis B, og som indeholder:</li><li><p>adefovir-dipivoxil, atazanavir, bictegravir, emtricitabin, lamivudin, tenofoviralafenamid eller tenofovirdisoproxil</p></li><li><p>antibiotika, der anvendes til at behandle bakterieinfektioner, og indeholder:</p></li><li><p>azithromycin, clarithromycin, rifabutin eller rifapentin</p></li><li><p>antikonvulsiva, der anvendes til at behandle epilepsi, og som indeholder:</p></li><li><p>carbamazepin, oxcarbazepin, phenobarbital eller phenytoin</p></li><li><p>immunundertrykkende midler, der anvendes til at kontrollere kroppens immunrespons efter en transplantation, såsom ciclosporin</p></li><li><p>lægemidler til heling af mavesår, der indeholder sucralfat</p></li></ul><p>→ Fortæl det til lægen, hvis du tager nogen af disse lægemidler. Afbryd ikke behandlingen uden først at kontakte din læge.</p><p>Spørg lægen eller apotekspersonalet til råds, hvis du tager:</p><ul><li><p>syreneutraliserende lægemidler til behandling af mavesår, halsbrand eller sure opstød, der indeholder aluminium og/eller magnesiumhydroxid</p></li><li><p>mineraltilskud eller vitaminer, der indeholder magnesium eller jern</p></li></ul><p>→ Spørg lægen eller apotekspersonalet til råds, før du tager Biktarvy, hvis du tager et eller flere af disse lægemidler. Syreneutraliserende midler og magnesiumtilskud: Du skal tage Biktarvy mindst 2 timer før syreneutraliserende midler eller tilskud indeholdende aluminium og/eller magnesium. Ellers skal du tage Biktarvy sammen med mad mindst 2 timer efter. Jerntilskud: Du skal tage Biktarvy mindst 2 timer før jerntilskud, eller du kan tage begge præparater i forbindelse med et måltid.</p><p>Graviditet og amning</p><ul><li><p>Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge eller apotekspersonalet til råds, før du tager dette lægemiddel.</p></li><li><p>Fortæl det straks til lægen, hvis du bliver gravid, og spørg om de potentielle fordele og risici for dig og dit barn i forbindelse med din antiretrovirale behandling.</p></li></ul><p>Hvis du har taget Biktarvy under din graviditet, kan lægen anmode om regelmæssige blodprøver og andre diagnostiske undersøgelser for at overvåge barnets udvikling. For de børn, hvis mødre har taget nukleosid-revers transkriptase-hæmmere (NRTI’er) i løbet af graviditeten, opvejede fordelen ved beskyttelse mod hiv risikoen ved bivirkningerne.</p><p>Du må ikke amme, mens du er i behandling med Biktarvy, fordi nogle af de aktive stoffer i dette lægemiddel udskilles i mælken hos mennesker. Amning anbefales ikke hos kvinder, der er hiv- positive, da hiv-infektion kan overføres til barnet gennem modermælken. Hvis du ammer eller påtænker at amme, bør du drøfte det med lægen hurtigst muligt.</p><p>Trafik- og arbejdssikkerhed</p><p>Biktarvy kan forårsage svimmelhed. Kør ikke motorkøretøj eller på cykel, og lad være med at arbejde med værktøj eller maskiner, hvis du bliver svimmel, når du tager Biktarvy.</p><p>Biktarvy indeholder natrium</p><p>Dette lægemiddel indeholder mindre end 1 mmol (23 mg) natrium pr. tablet, dvs. det er i det væsentlige natriumfrit.</p></div>"
          }
        },
        {
          "title" : "3. Sådan skal du tage Biktarvy",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Sådan skal du tage Biktarvy"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Tag altid lægemidlet nøjagtigt efter lægens eller apotekspersonalets anvisning. Er du i tvivl, så spørg lægen eller apotekspersonalet.</p><p>Biktarvy-tabletter fås i to styrker. Din læge vil ordinere den tablet, der passer til din alder og vægt.</p><p>Den anbefalede dosis er:</p><p>Børn på 2 år og ældre, som vejer mindst 14 kg, men mindre end 25 kg: én tablet om dagen med eller uden mad (en 30 mg/120 mg/15 mg tablet).</p><p>På grund af den bitre smag anbefales det, at tabletten ikke tygges eller knuses. Hvis du har svært ved at sluge tabletten hel, kan du dele den. Tag begge halvdele af tabletten, den ene efter den anden, for at få den fulde dosis. Gem ikke den delte tablet.</p><p>Delekærven på tabletter er der kun som en hjælp til at dele tabletten, hvis dit barn har svært ved at sluge den hel.</p><p>Multipakningen til 90 dage indeholder tre pakninger til 30 dage. → Spørg lægen eller apotekspersonalet til råds, hvis du tager:</p><ul><li><p>syreneutraliserende lægemidler til behandling af mavesår, halsbrand eller sure opstød, der indeholder aluminium og/eller magnesiumhydroxid</p></li><li><p>mineraltilskud eller vitaminer, der indeholder magnesium eller jern → Se punkt 2 for yderligere oplysninger om brug af disse lægemidler sammen med Biktarvy.</p></li></ul><p>Hvis du er i dialyse, skal du tage din daglige dosis Biktarvy efter dialysen er gennemført.</p><p>Hvis du har taget for meget Biktarvy</p><p>Hvis du ved et uheld tager mere end den anbefalede dosis Biktarvy, kan du have højere risiko for at få bivirkninger med dette lægemiddel (se punkt 4, Bivirkninger).</p><p>Kontakt straks lægen eller den nærmeste skadestue for at få råd. Tag tabletbeholderen eller æsken med, så du let kan vise, hvad du har taget.</p><p>Hvis du har glemt at tage Biktarvy</p><p>Det er vigtigt, at du husker at tage hver dosis af Biktarvy.</p><p>Hvis du har glemt at tage en dosis:</p><ul><li><p>Hvis du kommer i tanker om det inden for 18 timer efter det tidspunkt, du normalt tager Biktarvy på, skal du tage tabletten så hurtigt som muligt. Derefter tages den næste dosis som sædvanligt.</p></li><li><p>Hvis du kommer i tanker om det 18 timer eller længere efter det tidspunkt, du normalt tager Biktarvy på, skal du ikke tage den glemte dosis. Vent og tag den næste dosis til sædvanlig tid.</p></li></ul><p>Hvis du kaster op mindre end 1 time efter, du har taget Biktarvy, skal du tage en ny tablet. Hvis du kaster op mere end 1 time efter, at du har taget Biktarvy, er det ikke nødvendigt at tage en ny tablet før den sædvanlige planlagte tablet.</p><p>Hold ikke op med at tage Biktarvy</p><p>Hold ikke op med at tage Biktarvy uden at tale med din læge. Hvis du holder op med at tage Biktarvy, kan det i alvorlig grad påvirke virkningen af fremtidig behandling. Hvis Biktarvy stoppes uanset årsagen, skal du tale med din læge, før du igen begynder at tage Biktarvy tabletter.</p><p>Når du snart ikke har mere af Biktarvy, skal du bede om mere fra lægen eller på apoteket. Dette er meget vigtigt, da virusmængden igen kan begynde at stige, hvis lægemidlet stoppes, selv i kort tid. Sygdommen kan så blive sværere at behandle.</p><p>Hvis du har både hiv-infektion og hepatitis B, er det særlig vigtigt ikke at ophøre med behandlingen med Biktarvy uden først at konsultere din læge. Det kan være nødvendigt at få taget blodprøver i flere måneder efter ophør med behandlingen. Hos nogle patienter med fremskreden leversygdom eller cirrose bør behandlingen ikke ophøre, fordi det kan medføre en forværring af din hepatitis, hvilket kan være livstruende.</p><p>→ Bemærker du nogle nye eller usædvanlige symptomer efter behandlingens ophør, skal du omgående oplyse din læge herom, især hvis det drejer sig om symptomer, som du normalt ville forbinde med hepatitis B-infektion.</p><p>Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.</p></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Bivirkninger"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Dette lægemiddel kan som alle andre lægemidler give bivirkninger, men ikke alle får bivirkninger.</p><p>Mulige bivirkninger: Fortæl det straks til lægen</p><ul><li><p>Ethvert tegn på betændelse eller infektion. Hos nogle patienter med fremskreden hiv-infektion (aids) og tidligere opportunistiske infektioner (infektioner, der forekommer hos personer med et svagt immunsystem) kan der forekomme tegn og symptomer på betændelse fra tidligere infektioner kort tid efter behandlingen mod hiv startes. Det menes, at disse symptomer skyldes en forbedring af kroppens immunreaktion, hvilket gør kroppen i stand til at bekæmpe infektioner, der kan have været til stede uden nogen tydelige symptomer.</p></li><li><p>Autoimmunsygdomme, når immunsystemet angriber sundt kropsvæv, kan også opstå, efter du begynder at tage lægemidler for hiv-infektion. Autoimmunsygdomme kan opstå mange måneder efter behandlingsstart. Vær opmærksom på symptomer på infektion eller andre symptomer, såsom:</p></li><li>muskelsvaghed</li><li>svaghed, der begynder i hænder og fødder og bevæger sig op mod selve kroppen</li><li>hjertebanken, rysten eller hyperaktivitet</li></ul><p>→ Hvis du bemærker disse eller andre symptomer på betændelse eller infektion, skal du straks fortælle det til din læge.</p><p>Almindelige bivirkninger (kan forekomme hos op til 1 ud af 10 personer)</p><ul><li><p>depression</p></li><li><p>unormale drømme</p></li><li><p>hovedpine</p></li><li><p>svimmelhed</p></li><li><p>diarré</p></li><li><p>kvalme</p></li><li><p>træthed</p></li></ul><p>Ikke almindelige bivirkninger (kan forekomme hos op til 1 ud af 100 personer)</p><ul><li><p>lavt antal røde blodlegemer (anæmi)</p></li><li><p>opkastning</p></li><li><p>mavesmerter</p></li><li><p>problemer med fordøjelsen, som resulterer i ubehag efter måltider (dyspepsi)</p></li><li><p>afgang af tarmluft (flatulens)</p></li><li><p>hævelse af ansigt, læber, tunge eller svælg (angioødem)</p></li><li><p>kløe (pruritus)</p></li><li><p>udslæt</p></li><li><p>nældefeber (urticaria)</p></li><li><p>ledsmerter (artralgi)</p></li><li><p>selvmordstanker og selvmordsforsøg (især hos patienter, som tidligere har haft depression eller psykiske problemer)</p></li><li><p>angst</p></li><li><p>søvnforstyrrelser</p></li></ul><p>Blodprøver kan også vise:</p><ul><li>højere niveauer af stofferne bilirubin og/eller serumkreatinin i blodet</li></ul><p>Sjældne bivirkninger (kan forekomme hos op til 1 ud af 1.000 personer)</p><ul><li>Stevens-Johnsons syndrom (SJS) er en alvorlig, livstruende tilstand, som normalt begynder med influenzalignende symptomer. Et par dage senere fremkommer andre symptomer, herunder:</li><li>Smertefuld rød eller lilla hud, der ser brændt ud og skaller af</li><li>Blærer på huden, i munden, næsen og på kønsdelene</li><li>Røde, smertende øjne, der løber i vand</li></ul><p>→ Hvis du har nogen af disse symptomer, skal du straks stoppe med lægemidlet og fortælle det til lægen med det samme.</p><p>→ Hvis nogle af bivirkningerne bliver alvorlige, skal du fortælle det til lægen.</p><p>Andre bivirkninger, der kan observeres under hiv-behandling</p><p>Hyppigheden af de følgende bivirkninger er ikke kendt (hyppigheden kan ikke estimeres ud fra forhåndenværende data).</p><ul><li>Knogleproblemer. Nogle patienter, der tager antiretroviral kombinationslægemiddel, såsom Biktarvy kan udvikle en knoglesygdom, der kaldes osteonekrose (knoglevævsdød, forårsaget af manglende blodforsyning til knoglerne). Indtagelse af denne type lægemiddel i lang tid, indtagelse af binyrebarkhormoner, indtagelse af alkohol, et meget svagt immunsystem og overvægt kan være nogle af de mange risikofaktorer for at udvikle denne sygdom. Tegn på osteonekrose er:</li><li>stivhed i led</li><li>smerter (især i hofter, knæ og skuldre)</li><li>bevægelsesbesvær</li></ul><p>→ Hvis du bemærker nogle af disse symptomer, skal du fortælle det til lægen.</p><p>Under hiv-behandling kan der forekomme vægtstigning samt forhøjede niveauer af lipider og glucose i blodet. Dette er til dels forbundet med forbedret helbredstilstand og med livsstil, og for lipidernes vedkommende sommetider med selve hiv-lægemidlet. Lægen vil holde øje med disse ændringer.</p><p>Indberetning af bivirkninger Hvis du oplever bivirkninger, bør du tale med din læge eller apotekspersonalet. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via det nationale rapporteringssystem anført i Appendiks V. Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</p></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Opbevaring"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Opbevar lægemidlet utilgængeligt for børn.</p><p>Brug ikke lægemidlet efter den udløbsdato, der står på æsken og tabletbeholderen eller blisterkortene efter {EXP}. Udløbsdatoen er den sidste dag i den nævnte måned.</p><p>Opbevares i den originale yderpakning for at beskytte mod fugt. Hold tabletbeholderen tæt tillukket. Må ikke anvendes, hvis forseglingen over beholderens åbning er brudt eller mangler.</p><p>Spørg apotekspersonalet, hvordan du skal bortskaffe lægemiddelrester. Af hensyn til miljøet må du ikke smide lægemiddelrester i afløbet, toilettet eller skraldespanden.</p></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Pakningsstørrelser og yderligere oplysninger"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Biktarvy indeholder</p><p>Aktive stoffer: bictegravir, emtricitabin og tenofoviralafenamid. Hver Biktarvy-tablet indeholder bictegravirnatrium svarende til 30 mg bictegravir, 120 mg emtricitabin og tenofoviralafenamidfumarat svarende til 15 mg tenofoviralafenamid.</p><p>Øvrige indholdsstoffer</p><p>Tabletkerne Microkrystallinsk cellulose (E460), croscarmellosenatrium (E468), magnesiumstearat (E470b).</p><p>Filmovertræk Polyvinylalkohol (E203), titandioxid (E171), macrogol (E1521), talcum (E553b), jernoxid, rød (E172), jernoxid, sort (E172).</p><p>Udseende og pakningsstørrelser</p><p>Biktarvy 30 mg/120 mg/15 mg filmovertrukne tabletter er lyserøde, kapselformede, filmovertrukne tabletter, der er præget med \"BVY\" på den ene side og en delekærv på den anden side.</p><p>Tabletterne fås i en tabletbeholder. Ikke alle pakningsstørrelser er nødvendigvis markedsført.</p><p>Biktarvy fås i tabletbeholdere med 30 tabletter samt i pakninger med 3 tabletbeholdere, hver med 30 tabletter. Hver tabletbeholder indeholder et silicagel-tørremiddel, der skal opbevares i tabletbeholderen for at hjælpe med at beskytte tabletterne. Silicagel-tørremidlet er i et separat brev eller en separat beholder og må ikke sluges.</p><p>Indehaver af markedsføringstilladelsen Gilead Sciences Ireland UC Carrigtohill County Cork, T45 DPIrland</p><p>Fremstiller Gilead Sciences Ireland UC IDA Business &amp; Technology Park Carrigtohill County Cork Irland</p><p>Hvis du ønsker yderligere oplysninger om dette lægemiddel, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:</p><p>België/Belgique/Belgien Gilead Sciences Belgium SRL-BV Tél/Tel: + 32 (0) 24 01 35<br/>Lietuva Gilead Sciences Ireland UC Tel.: + 353 (0) 1 686 1 България Gilead Sciences Ireland UC Тел.: + 353 (0) 1 686 1 Luxembourg/Luxemburg Gilead Sciences Belgium SRL-BV Tél/Tel: + 32 (0) 24 01 35<br/>Česká republika Gilead Sciences s.r.o. Tel: + 420 (0) 910 871<br/>Magyarország Gilead Sciences Ireland UC Tel.: + 353 (0) 1 686 1 Danmark Gilead Sciences Sweden AB Tlf.: + 46 (0) 8 5057 1 Malta Gilead Sciences Ireland UC Tel: + 353 (0) 1 686 1Deutschland Gilead Sciences GmbH Tel: + 49 (0) 89 899890-0</p><p>Nederland Gilead Sciences Netherlands B.V. Tel: + 31 (0) 20 718 36<br/>Eesti Gilead Sciences Ireland UC Tel.: +353 (0) 1 686 1Norge Gilead Sciences Sweden AB Tlf: + 46 (0) 8 5057 1 Ελλάδα Gilead Sciences Ελλάς Μ.ΕΠΕ. Τηλ: + 30 (0) 210 8930<br/>Österreich Gilead Sciences GesmbH Tel: + 43 (0) 1 260<br/>España Gilead Sciences, S.L. Tel: + 34 (0) 91 378 98<br/>Polska Gilead Sciences Poland Sp. z o.o. Tel.: + 48 (0) 22 262 8 France Gilead Sciences Tél: + 33 (0) 1 46 09 41<br/>Portugal Gilead Sciences, Lda. Tel: + 351 (0) 21 7928 Hrvatska Gilead Sciences Ireland UC Tel: + 353 (0) 1 686 1 România Gilead Sciences (GSR) S.R.L Tel: + 40 31 631 18</p><p>Ireland Gilead Sciences Ireland UC Tel: + 353 (0) 214 825<br/>Slovenija Gilead Sciences Ireland UC Tel: + 353 (0) 1 686 1 Ísland Gilead Sciences Sweden AB Sími: + 46 (0) 8 5057 1 Slovenská republika Gilead Sciences Slovakia s.r.o. Tel: + 421 (0) 232 121<br/>Italia Gilead Sciences S.r.l. Tel: + 39 02 439 Suomi/Finland Gilead Sciences Sweden AB Puh/Tel: + 46 (0) 8 5057 1 Κύπρος Gilead Sciences Ελλάς Μ.ΕΠΕ. Τηλ: + 30 (0) 210 8930<br/>Sverige Gilead Sciences Sweden AB Tel: + 46 (0) 8 5057 1 Latvija Gilead Sciences Ireland UC Tel.: + 353 (0) 1 686 1 United Kingdom (Northern Ireland) Gilead Sciences Ireland UC Tel: + 44 (0) 8000 113</p><p>Denne indlægsseddel blev senest ændret</p><p>Du kan finde yderligere oplysninger om dette lægemiddel på Det Europæiske Lægemiddelagenturs hjemmeside http://www.ema.europa.eu/.</p><p>Indlægsseddel: Information til brugeren</p><p>Biktarvy 50 mg/200 mg/25 mg filmovertrukne tabletter bictegravir/emtricitabin/tenofoviralafenamid</p><p>Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger. - Gem indlægssedlen. Du kan få brug for at læse den igen. - Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide. - Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give lægemidlet til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har. - Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se punkt 4.<br/>Hvis Biktarvy er ordineret til dit barn, skal du bemærke, at alle oplysninger i denne indlægsseddel er rettet mod dit barn (i det tilfælde skal du læse ”dit barn” i stedet for ”du/dig”).</p><p>Se den nyeste indlægsseddel på www.indlaegsseddel.dk</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-d79af6e660f456c6c7091803d6bd1a92",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-d79af6e660f456c6c7091803d6bd1a92",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-d79af6e660f456c6c7091803d6bd1a92\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-d79af6e660f456c6c7091803d6bd1a92</b></p><a name=\"cud-d79af6e660f456c6c7091803d6bd1a92\"> </a><a name=\"hccud-d79af6e660f456c6c7091803d6bd1a92\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/pregnancy (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr nan}\">nan</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "pregnancy"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "nan",
              "display" : "nan"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-bictegravirsodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-bictegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-bictegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-bictegravirsodium</b></p><a name=\"ingredient-for-biktarvy-bictegravirsodium\"> </a><a name=\"hcingredient-for-biktarvy-bictegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/4L5MP1Y7W7 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 4L5MP1Y7W7}\">BICTEGRAVIR SODIUM</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>50 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "4L5MP1Y7W7"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "4L5MP1Y7W7",
              "display" : "BICTEGRAVIR SODIUM"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 50,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-emtricitabine",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-emtricitabine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-emtricitabine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-emtricitabine</b></p><a name=\"ingredient-for-biktarvy-emtricitabine\"> </a><a name=\"hcingredient-for-biktarvy-emtricitabine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/G70B4ETF4S (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta G70B4ETF4S}\">Emtricitabine</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>200 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "G70B4ETF4S"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "G70B4ETF4S",
              "display" : "Emtricitabine"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 200,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-tenofoviralafenamide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-tenofoviralafenamide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-tenofoviralafenamide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-tenofoviralafenamide</b></p><a name=\"ingredient-for-biktarvy-tenofoviralafenamide\"> </a><a name=\"hcingredient-for-biktarvy-tenofoviralafenamide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EL9943AG5J (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EL9943AG5J}\">tenofovir alafenamide</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>25 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EL9943AG5J"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EL9943AG5J",
              "display" : "tenofovir alafenamide"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 25,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-microcrystallinecellulose</b></p><a name=\"ingredient-for-biktarvy-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-biktarvy-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">Microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "Microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-croscarmellosesodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-croscarmellosesodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-croscarmellosesodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-croscarmellosesodium</b></p><a name=\"ingredient-for-biktarvy-croscarmellosesodium\"> </a><a name=\"hcingredient-for-biktarvy-croscarmellosesodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/M28OL1HH48 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta M28OL1HH48}\">Croscarmellose sodium</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "M28OL1HH48"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "M28OL1HH48",
              "display" : "Croscarmellose sodium"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-magnesiumstearate</b></p><a name=\"ingredient-for-biktarvy-magnesiumstearate\"> </a><a name=\"hcingredient-for-biktarvy-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-94a96e39cfdcd8b378d12dd4063065f9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-94a96e39cfdcd8b378d12dd4063065f9</b></p><a name=\"ap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><a name=\"hcap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization94a96e39cfdcd8b378d12dd4063065f90",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization94a96e39cfdcd8b378d12dd4063065f90",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization94a96e39cfdcd8b378d12dd4063065f90</b></p><a name=\"authorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><a name=\"hcauthorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2018-06-21 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mah-715f8a161ed438d0584510e5b4512caa\">Organization Gilead Sciences Ireland UC</a></p><p><b>regulator</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mra-1133a7374c78f1d40f41885344f06a5a\">Organization European Medicines Agency</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2018-06-21T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-715f8a161ed438d0584510e5b4512caa"
      },
      "regulator" : {
        "reference" : "Organization/mra-1133a7374c78f1d40f41885344f06a5a"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-715f8a161ed438d0584510e5b4512caa",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-715f8a161ed438d0584510e5b4512caa",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-715f8a161ed438d0584510e5b4512caa\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-715f8a161ed438d0584510e5b4512caa</b></p><a name=\"mah-715f8a161ed438d0584510e5b4512caa\"> </a><a name=\"hcmah-715f8a161ed438d0584510e5b4512caa\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100008368 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Gilead Sciences Ireland UC</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carrigtohill, County Cork, T45 County Cork IR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100008368"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Gilead Sciences Ireland UC",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carrigtohill, County Cork, T45 County Cork IR",
          "line" : ["Carrigtohill, County Cork, T45"],
          "city" : "County Cork",
          "country" : "IR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mra-1133a7374c78f1d40f41885344f06a5a",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mra-1133a7374c78f1d40f41885344f06a5a",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mra-1133a7374c78f1d40f41885344f06a5a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mra-1133a7374c78f1d40f41885344f06a5a</b></p><a name=\"mra-1133a7374c78f1d40f41885344f06a5a\"> </a><a name=\"hcmra-1133a7374c78f1d40f41885344f06a5a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100013412 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000032}\">Medicines Regulatory Authority</span></p><p><b>name</b>: European Medicines Agency</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100013412"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000032",
          "display" : "Medicines Regulatory Authority"
        }]
      }],
      "name" : "European Medicines Agency",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL",
          "line" : ["Carretera De Martorell 41 61, Poligono Industrial Nord-Est"],
          "city" : "Amsterdam",
          "postalCode" : "1083 HS",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-e34e4b65abd3fd8e667db05606cc25a9",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-e34e4b65abd3fd8e667db05606cc25a9",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-e34e4b65abd3fd8e667db05606cc25a9</b></p><a name=\"ppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><a name=\"hcppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, ), Gtin/07612345678904 (use: official, )</p><p><b>name</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 90</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 90</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      },
      {
        "use" : "official",
        "system" : "https://www.gs1.org/gtin",
        "value" : "07612345678904"
      }],
      "name" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 90",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 90,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-6d93344139a7793e7b9bd0f5e32b6c91",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-6d93344139a7793e7b9bd0f5e32b6c91",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-6d93344139a7793e7b9bd0f5e32b6c91</b></p><a name=\"ppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><a name=\"hcppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>name</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "name" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp2a9c4333cfd126f2e7b73ad3cafd6949",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp2a9c4333cfd126f2e7b73ad3cafd6949</b></p><a name=\"mp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><a name=\"hcmp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E827gy</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Biktarvy</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: bictegravir/emtricitabine/tenofovir alafenamide</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 50 mg/200 mg/25 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E827gy"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Biktarvy",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "bictegravir/emtricitabine/tenofovir alafenamide",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "50 mg/200 mg/25 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "film-coated tablets",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-94a96e39cfdcd8b378d12dd4063065f9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-94a96e39cfdcd8b378d12dd4063065f9</b></p><a name=\"mid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><a name=\"hcmid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      }
    }
  }]
}

```
