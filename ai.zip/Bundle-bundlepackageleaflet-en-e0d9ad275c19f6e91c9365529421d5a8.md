# ePI document Bundle for Nurofen 100 mg Chewable Capsules Package Leaflet for language en - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Nurofen 100 mg Chewable Capsules Package Leaflet for language en**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **2 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Chewable capsule, soft ** 

 Unit of presentation: ** Capsule ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Sucrose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** ANHYDROUS DEXTROSE ** 

Ingredient

 Role: ** Active ** 

 Substance: ** IBUPROFEN ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** LECITHIN, SOYBEAN ** 

## Example Bundle: ePI document Bundle for Nurofen 100 mg Chewable Capsules Package Leaflet for language en

**Composition category:**Raw

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

unavailable


#### What is in this leaflet

 

unavailable


#### 1. What Nurofen 100 mg Chewable Capsules is and what it is used for

 

unavailable


#### 2. What you need to know before you take Nurofen 100 mg Chewable Capsules

 

unavailable


#### 3. How to take Nurofen 100 mg Chewable Capsules

 

unavailable


#### 4. Possible side effects

 

unavailable


#### 5. How to store Nurofen 100 mg Chewable Capsules

 

unavailable


#### 6. Contents of the pack and other information

 

unavailable


####  Nurofen 100 mg Chewable Capsules 
1:
** 8B44F06AB13CD28E68DE3255193A4F59 **2:
** 946EDA19CD2DB76813237462884BEFD8 **3:
** EBCFAC0D18CA76B872188AA9E85F0F67 **4:
** 9DE6782842862A9295DAA3C3B96C4882 **
-------

Full name: **Nurofen 100 mg Chewable Capsules**

 - Invented name part: ** Nurofen ** 

 - Scientific name part: ** Ibruprofen ** 

 - Strength part: ** 100 mg ** 

 - Pharmaceutical dose form part: ** chewable capsule ** 

 Name usage: **English (Portugal)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** pt-xxx ** 

 Region: ** ** 

Marketing authorisation holder: **Reckitt Benckiser Healthcare, Lda.** 

 Identifier: 
*  **ORG-100002574** 
 

 Status: ** Active (2022-05-10T00:00:00Z) ** 

 Package 1 of 1

PMSWI: ** 5697008 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****100 

Administrable Product (1 of 1)

 Dose form: ** Chewable capsule, soft ** 

 Unit of presentation: ** Capsule ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Excipient ** 

 Substance: ** Sucrose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** ANHYDROUS DEXTROSE ** 

Ingredient

 Role: ** Active ** 

 Substance: ** IBUPROFEN ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** LECITHIN, SOYBEAN ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "aa4a4793bfd06de750277f993c8c155b"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-en-01eaaf0a81574efda98a52449788e7a2",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-en-01eaaf0a81574efda98a52449788e7a2",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_composition-en-01eaaf0a81574efda98a52449788e7a2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-en-01eaaf0a81574efda98a52449788e7a2</b></p><a name=\"composition-en-01eaaf0a81574efda98a52449788e7a2\"> </a><a name=\"hccomposition-en-01eaaf0a81574efda98a52449788e7a2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/5e2a814d6b8ad04f59db5f5c9ee2b642</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#Organization_mah-fe6b7ee8886997a3f2098e16b925984d\">Organization Reckitt Benckiser Healthcare, Lda.</a></p><p><b>title</b>: TEST PURPOSES ONLY - Nurofen 100 mg Chewable Capsules</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "5e2a814d6b8ad04f59db5f5c9ee2b642"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-fe6b7ee8886997a3f2098e16b925984d"
      }],
      "title" : "TEST PURPOSES ONLY - Nurofen 100 mg Chewable Capsules",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. Package Leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "1. What Nurofen 100 mg Chewable Capsules is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What Nurofen 100 mg Chewable Capsules is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "2. What you need to know before you take Nurofen 100 mg Chewable Capsules",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take Nurofen 100 mg Chewable Capsules"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "3. How to take Nurofen 100 mg Chewable Capsules",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take Nurofen 100 mg Chewable Capsules"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "5. How to store Nurofen 100 mg Chewable Capsules",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store Nurofen 100 mg Chewable Capsules"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-ibuprofen-sucrose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-ibuprofen-sucrose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-ibuprofen-sucrose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-ibuprofen-sucrose</b></p><a name=\"ingredient-for-ibuprofen-sucrose\"> </a><a name=\"hcingredient-for-ibuprofen-sucrose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/C151H8M554 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#ManufacturedItemDefinition_mid-e0d9ad275c19f6e91c9365529421d5a8\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx (use: official, ); status = active; manufacturedDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#MedicinalProductDefinition_mp01eaaf0a81574efda98a52449788e7a2\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/1#8B44F06AB13CD28E68DE3255193A4F59,https://www.who-umc.org/phpid/2#946EDA19CD2DB76813237462884BEFD8,https://www.who-umc.org/phpid/3#EBCFAC0D18CA76B872188AA9E85F0F67,https://www.who-umc.org/phpid/4#9DE6782842862A9295DAA3C3B96C4882; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#AdministrableProductDefinition_ap-e0d9ad275c19f6e91c9365529421d5a8\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx; status = active; administrableDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta C151H8M554}\">Sucrose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "C151H8M554"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e0d9ad275c19f6e91c9365529421d5a8"
      },
      {
        "reference" : "MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e0d9ad275c19f6e91c9365529421d5a8"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "C151H8M554",
              "display" : "Sucrose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-ibuprofen-anhydrousdextrose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-ibuprofen-anhydrousdextrose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-ibuprofen-anhydrousdextrose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-ibuprofen-anhydrousdextrose</b></p><a name=\"ingredient-for-ibuprofen-anhydrousdextrose\"> </a><a name=\"hcingredient-for-ibuprofen-anhydrousdextrose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/5SL0G7R0OK (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#ManufacturedItemDefinition_mid-e0d9ad275c19f6e91c9365529421d5a8\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx (use: official, ); status = active; manufacturedDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#MedicinalProductDefinition_mp01eaaf0a81574efda98a52449788e7a2\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/1#8B44F06AB13CD28E68DE3255193A4F59,https://www.who-umc.org/phpid/2#946EDA19CD2DB76813237462884BEFD8,https://www.who-umc.org/phpid/3#EBCFAC0D18CA76B872188AA9E85F0F67,https://www.who-umc.org/phpid/4#9DE6782842862A9295DAA3C3B96C4882; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#AdministrableProductDefinition_ap-e0d9ad275c19f6e91c9365529421d5a8\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx; status = active; administrableDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 5SL0G7R0OK}\">ANHYDROUS DEXTROSE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "5SL0G7R0OK"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e0d9ad275c19f6e91c9365529421d5a8"
      },
      {
        "reference" : "MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e0d9ad275c19f6e91c9365529421d5a8"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "5SL0G7R0OK",
              "display" : "ANHYDROUS DEXTROSE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-ibuprofen-ibuprofen",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-ibuprofen-ibuprofen",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-ibuprofen-ibuprofen\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-ibuprofen-ibuprofen</b></p><a name=\"ingredient-for-ibuprofen-ibuprofen\"> </a><a name=\"hcingredient-for-ibuprofen-ibuprofen\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/WK2XYI10QM (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#ManufacturedItemDefinition_mid-e0d9ad275c19f6e91c9365529421d5a8\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx (use: official, ); status = active; manufacturedDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#MedicinalProductDefinition_mp01eaaf0a81574efda98a52449788e7a2\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/1#8B44F06AB13CD28E68DE3255193A4F59,https://www.who-umc.org/phpid/2#946EDA19CD2DB76813237462884BEFD8,https://www.who-umc.org/phpid/3#EBCFAC0D18CA76B872188AA9E85F0F67,https://www.who-umc.org/phpid/4#9DE6782842862A9295DAA3C3B96C4882; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#AdministrableProductDefinition_ap-e0d9ad275c19f6e91c9365529421d5a8\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx; status = active; administrableDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta WK2XYI10QM}\">IBUPROFEN</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>100 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "WK2XYI10QM"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e0d9ad275c19f6e91c9365529421d5a8"
      },
      {
        "reference" : "MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e0d9ad275c19f6e91c9365529421d5a8"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "WK2XYI10QM",
              "display" : "IBUPROFEN"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 100,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-ibuprofen-lecithinsoybean",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-ibuprofen-lecithinsoybean",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-ibuprofen-lecithinsoybean\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-ibuprofen-lecithinsoybean</b></p><a name=\"ingredient-for-ibuprofen-lecithinsoybean\"> </a><a name=\"hcingredient-for-ibuprofen-lecithinsoybean\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/1DI56QDM62 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#ManufacturedItemDefinition_mid-e0d9ad275c19f6e91c9365529421d5a8\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx (use: official, ); status = active; manufacturedDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#MedicinalProductDefinition_mp01eaaf0a81574efda98a52449788e7a2\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/1#8B44F06AB13CD28E68DE3255193A4F59,https://www.who-umc.org/phpid/2#946EDA19CD2DB76813237462884BEFD8,https://www.who-umc.org/phpid/3#EBCFAC0D18CA76B872188AA9E85F0F67,https://www.who-umc.org/phpid/4#9DE6782842862A9295DAA3C3B96C4882; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#AdministrableProductDefinition_ap-e0d9ad275c19f6e91c9365529421d5a8\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx; status = active; administrableDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 1DI56QDM62}\">LECITHIN, SOYBEAN</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "1DI56QDM62"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e0d9ad275c19f6e91c9365529421d5a8"
      },
      {
        "reference" : "MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e0d9ad275c19f6e91c9365529421d5a8"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "1DI56QDM62",
              "display" : "LECITHIN, SOYBEAN"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-ibuprofen",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-ibuprofen",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-ibuprofen\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-ibuprofen</b></p><a name=\"substance-ibuprofen\"> </a><a name=\"hcsubstance-ibuprofen\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/WK2XYI10QM (use: official, )</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#Organization_mah-fe6b7ee8886997a3f2098e16b925984d\">Organization Reckitt Benckiser Healthcare, Lda.</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "WK2XYI10QM"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/mah-fe6b7ee8886997a3f2098e16b925984d"
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-e0d9ad275c19f6e91c9365529421d5a8",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-e0d9ad275c19f6e91c9365529421d5a8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-e0d9ad275c19f6e91c9365529421d5a8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-e0d9ad275c19f6e91c9365529421d5a8</b></p><a name=\"ap-e0d9ad275c19f6e91c9365529421d5a8\"> </a><a name=\"hcap-e0d9ad275c19f6e91c9365529421d5a8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/pt-xx</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#MedicinalProductDefinition_mp01eaaf0a81574efda98a52449788e7a2\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/1#8B44F06AB13CD28E68DE3255193A4F59,https://www.who-umc.org/phpid/2#946EDA19CD2DB76813237462884BEFD8,https://www.who-umc.org/phpid/3#EBCFAC0D18CA76B872188AA9E85F0F67,https://www.who-umc.org/phpid/4#9DE6782842862A9295DAA3C3B96C4882; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073377}\">Chewable capsule, soft</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002113}\">Capsule</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#ManufacturedItemDefinition_mid-e0d9ad275c19f6e91c9365529421d5a8\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx (use: official, ); status = active; manufacturedDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "pt-xx"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073377",
          "display" : "Chewable capsule, soft"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002113",
          "display" : "Capsule"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-e0d9ad275c19f6e91c9365529421d5a8"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizatione0d9ad275c19f6e91c9365529421d5a80",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizatione0d9ad275c19f6e91c9365529421d5a80",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizatione0d9ad275c19f6e91c9365529421d5a80\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizatione0d9ad275c19f6e91c9365529421d5a80</b></p><a name=\"authorizatione0d9ad275c19f6e91c9365529421d5a80\"> </a><a name=\"hcauthorizatione0d9ad275c19f6e91c9365529421d5a80\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/pt-xxx (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#MedicinalProductDefinition_mp01eaaf0a81574efda98a52449788e7a2\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/1#8B44F06AB13CD28E68DE3255193A4F59,https://www.who-umc.org/phpid/2#946EDA19CD2DB76813237462884BEFD8,https://www.who-umc.org/phpid/3#EBCFAC0D18CA76B872188AA9E85F0F67,https://www.who-umc.org/phpid/4#9DE6782842862A9295DAA3C3B96C4882; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2022-05-10 00:00:00+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#Organization_mah-fe6b7ee8886997a3f2098e16b925984d\">Organization Reckitt Benckiser Healthcare, Lda.</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "pt-xxx"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2022-05-10T00:00:00Z",
      "holder" : {
        "reference" : "Organization/mah-fe6b7ee8886997a3f2098e16b925984d"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-fe6b7ee8886997a3f2098e16b925984d",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-fe6b7ee8886997a3f2098e16b925984d",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-fe6b7ee8886997a3f2098e16b925984d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-fe6b7ee8886997a3f2098e16b925984d</b></p><a name=\"mah-fe6b7ee8886997a3f2098e16b925984d\"> </a><a name=\"hcmah-fe6b7ee8886997a3f2098e16b925984d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100002574 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Reckitt Benckiser Healthcare, Lda.</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Rua Dom Cristovao Da Gama 1 1 Andar Lisbon PT(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100002574"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Reckitt Benckiser Healthcare, Lda.",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Rua Dom Cristovao Da Gama 1 1 Andar Lisbon PT",
          "line" : ["Rua Dom Cristovao Da Gama 1 1 Andar"],
          "city" : "Lisbon",
          "country" : "PT"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-1f1356f6a8c19d66c5c3f4e40da7536c",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-1f1356f6a8c19d66c5c3f4e40da7536c",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-1f1356f6a8c19d66c5c3f4e40da7536c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-1f1356f6a8c19d66c5c3f4e40da7536c</b></p><a name=\"ppd-1f1356f6a8c19d66c5c3f4e40da7536c\"> </a><a name=\"hcppd-1f1356f6a8c19d66c5c3f4e40da7536c\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/5697008 (use: official, )</p><p><b>name</b>: Nurofen 100 mg Chewable Capsules 2</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#MedicinalProductDefinition_mp01eaaf0a81574efda98a52449788e7a2\">MedicinalProductDefinition: identifier = https://www.who-umc.org/phpid/1#8B44F06AB13CD28E68DE3255193A4F59,https://www.who-umc.org/phpid/2#946EDA19CD2DB76813237462884BEFD8,https://www.who-umc.org/phpid/3#EBCFAC0D18CA76B872188AA9E85F0F67,https://www.who-umc.org/phpid/4#9DE6782842862A9295DAA3C3B96C4882; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 100 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 2</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-en-e0d9ad275c19f6e91c9365529421d5a8.html#ManufacturedItemDefinition_mid-e0d9ad275c19f6e91c9365529421d5a8\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#pt-xx (use: official, ); status = active; manufacturedDoseForm = Chewable capsule, soft; unitOfPresentation = Capsule</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "5697008"
      }],
      "name" : "Nurofen 100 mg Chewable Capsules 2",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 100,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 2,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-e0d9ad275c19f6e91c9365529421d5a8"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp01eaaf0a81574efda98a52449788e7a2",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp01eaaf0a81574efda98a52449788e7a2",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp01eaaf0a81574efda98a52449788e7a2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp01eaaf0a81574efda98a52449788e7a2</b></p><a name=\"mp01eaaf0a81574efda98a52449788e7a2\"> </a><a name=\"hcmp01eaaf0a81574efda98a52449788e7a2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://www.who-umc.org/phpid/1</code>/8B44F06AB13CD28E68DE3255193A4F59, <code>https://www.who-umc.org/phpid/2</code>/946EDA19CD2DB76813237462884BEFD8, <code>https://www.who-umc.org/phpid/3</code>/EBCFAC0D18CA76B872188AA9E85F0F67, <code>https://www.who-umc.org/phpid/4</code>/9DE6782842862A9295DAA3C3B96C4882</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Nurofen 100 mg Chewable Capsules</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Nurofen</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Ibruprofen</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 100 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: chewable capsule</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 PT}\">Portugal</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 PT}\">Portugal</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.who-umc.org/phpid/1",
        "value" : "8B44F06AB13CD28E68DE3255193A4F59"
      },
      {
        "system" : "https://www.who-umc.org/phpid/2",
        "value" : "946EDA19CD2DB76813237462884BEFD8"
      },
      {
        "system" : "https://www.who-umc.org/phpid/3",
        "value" : "EBCFAC0D18CA76B872188AA9E85F0F67"
      },
      {
        "system" : "https://www.who-umc.org/phpid/4",
        "value" : "9DE6782842862A9295DAA3C3B96C4882"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Nurofen 100 mg Chewable Capsules",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Nurofen",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "Ibruprofen",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "100 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "chewable capsule",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "PT",
              "display" : "Portugal"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "PT",
              "display" : "Portugal"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-e0d9ad275c19f6e91c9365529421d5a8",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-e0d9ad275c19f6e91c9365529421d5a8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-e0d9ad275c19f6e91c9365529421d5a8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-e0d9ad275c19f6e91c9365529421d5a8</b></p><a name=\"mid-e0d9ad275c19f6e91c9365529421d5a8\"> </a><a name=\"hcmid-e0d9ad275c19f6e91c9365529421d5a8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/pt-xx (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073377}\">Chewable capsule, soft</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002113}\">Capsule</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "pt-xx"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073377",
          "display" : "Chewable capsule, soft"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002113",
          "display" : "Capsule"
        }]
      }
    }
  }]
}

```
