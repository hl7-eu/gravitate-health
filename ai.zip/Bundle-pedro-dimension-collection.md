# Pedro Persona Vector - Collection - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pedro Persona Vector - Collection**

## Example Bundle: Pedro Persona Vector - Collection



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "pedro-dimension-collection",
  "meta" : {
    "profile" : ["http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/persona-collection"]
  },
  "identifier" : {
    "system" : "http://hl7.eu/fhir/ig/gravitate-health/persona-dimension-collection",
    "value" : "pd-collection-1"
  },
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Observation/pedro-dimension-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "pedro-dimension-1",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_pedro-dimension-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation pedro-dimension-1</b></p><a name=\"pedro-dimension-1\"> </a><a name=\"hcpedro-dimension-1\"> </a><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs EMP}\">employment</span></p><p><b>subject</b>: Pedro-patient</p><p><b>effective</b>: 2019-01-01 00:00:00+0000</p><p><b>value</b>: <span title=\"Codes:{http://example.org currenly-employed}\">Currently employed</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs",
          "code" : "EMP"
        }]
      },
      "subject" : {
        "display" : "Pedro-patient"
      },
      "effectiveDateTime" : "2019-01-01T00:00:00Z",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://example.org",
          "code" : "currenly-employed",
          "display" : "Currently employed"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Observation/pedro-dimension-2",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "pedro-dimension-2",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_pedro-dimension-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation pedro-dimension-2</b></p><a name=\"pedro-dimension-2\"> </a><a name=\"hcpedro-dimension-2\"> </a><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs SHW}\">Share info Willingly</span></p><p><b>subject</b>: Pedro-patient</p><p><b>effective</b>: 2019-01-01 00:00:00+0000</p><p><b>value</b>: <span title=\"Codes:{http://example.org Medium}\">Medium willingness</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs",
          "code" : "SHW"
        }]
      },
      "subject" : {
        "display" : "Pedro-patient"
      },
      "effectiveDateTime" : "2019-01-01T00:00:00Z",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://example.org",
          "code" : "Medium",
          "display" : "Medium willingness"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Observation/pedro-dimension-3",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "pedro-dimension-3",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_pedro-dimension-3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation pedro-dimension-3</b></p><a name=\"pedro-dimension-3\"> </a><a name=\"hcpedro-dimension-3\"> </a><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs WKL}\">WorkLife</span></p><p><b>subject</b>: Pedro-patient</p><p><b>effective</b>: 2019-01-01 00:00:00+0000</p><p><b>value</b>: <span title=\"Codes:{http://example.org work-life}\">Work Life Balance</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs",
          "code" : "WKL"
        }]
      },
      "subject" : {
        "display" : "Pedro-patient"
      },
      "effectiveDateTime" : "2019-01-01T00:00:00Z",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://example.org",
          "code" : "work-life",
          "display" : "Work Life Balance"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Observation/pedro-dimension-4",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "pedro-dimension-4",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_pedro-dimension-4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation pedro-dimension-4</b></p><a name=\"pedro-dimension-4\"> </a><a name=\"hcpedro-dimension-4\"> </a><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs EVI}\">Extrovert/introvert</span></p><p><b>subject</b>: Pedro-patient</p><p><b>effective</b>: 2019-01-01 00:00:00+0000</p><p><b>value</b>: Introvert</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs",
          "code" : "EVI"
        }]
      },
      "subject" : {
        "display" : "Pedro-patient"
      },
      "effectiveDateTime" : "2019-01-01T00:00:00Z",
      "valueString" : "Introvert"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Observation/pedro-dimension-5",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "pedro-dimension-5",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_pedro-dimension-5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation pedro-dimension-5</b></p><a name=\"pedro-dimension-5\"> </a><a name=\"hcpedro-dimension-5\"> </a><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs ER}\">Emotional/Rational</span></p><p><b>subject</b>: Pedro-patient</p><p><b>effective</b>: 2019-01-01 00:00:00+0000</p><p><b>value</b>: 4</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs",
          "code" : "ER"
        }]
      },
      "subject" : {
        "display" : "Pedro-patient"
      },
      "effectiveDateTime" : "2019-01-01T00:00:00Z",
      "valueInteger" : 4
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Observation/pedro-dimension-6",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "pedro-dimension-6",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_pedro-dimension-6\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation pedro-dimension-6</b></p><a name=\"pedro-dimension-6\"> </a><a name=\"hcpedro-dimension-6\"> </a><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs HL}\">Health Literacy</span></p><p><b>subject</b>: Pedro-patient</p><p><b>effective</b>: 2019-01-01 00:00:00+0000</p><p><b>value</b>: medium-high literacy</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs",
          "code" : "HL"
        }]
      },
      "subject" : {
        "display" : "Pedro-patient"
      },
      "effectiveDateTime" : "2019-01-01T00:00:00Z",
      "valueString" : "medium-high literacy"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Observation/pedro-dimension-7",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "pedro-dimension-7",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_pedro-dimension-7\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation pedro-dimension-7</b></p><a name=\"pedro-dimension-7\"> </a><a name=\"hcpedro-dimension-7\"> </a><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs DL}\">Digital Literacy</span></p><p><b>subject</b>: Pedro-patient</p><p><b>effective</b>: 2019-01-01 00:00:00+0000</p><p><b>value</b>: High literacy</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs",
          "code" : "DL"
        }]
      },
      "subject" : {
        "display" : "Pedro-patient"
      },
      "effectiveDateTime" : "2019-01-01T00:00:00Z",
      "valueString" : "High literacy"
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Observation/pedro-dimension-8",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "pedro-dimension-8",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_pedro-dimension-8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation pedro-dimension-8</b></p><a name=\"pedro-dimension-8\"> </a><a name=\"hcpedro-dimension-8\"> </a><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs TSI}\">Tool Support Interest</span></p><p><b>subject</b>: Pedro-patient</p><p><b>effective</b>: 2019-01-01 00:00:00+0000</p><p><b>value</b>: <span title=\"Codes:{http://example.org VW}\">Very Willing</span></p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/pd-type-cs",
          "code" : "TSI"
        }]
      },
      "subject" : {
        "display" : "Pedro-patient"
      },
      "effectiveDateTime" : "2019-01-01T00:00:00Z",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://example.org",
          "code" : "VW",
          "display" : "Very Willing"
        }]
      }
    }
  }]
}

```
