# Bundle Japan JA - Package Insert for Herceptin (trastazumab) 150 mg for Intravenous Use - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle Japan JA - Package Insert for Herceptin (trastazumab) 150 mg for Intravenous Use**

Package: **28 Vial** **(Glass type I)** 

Containing:

## Example Bundle: Bundle Japan JA - Package Insert for Herceptin (trastazumab) 150 mg for Intravenous Use

**Composition category:**

**Composition status:**final

### アロマターゼ阻害剤/閉経後乳癌治療剤

 

unavailable


### 1. 警告

 

unavailable


#### 1.1

 

unavailable


#### 1.2

 

unavailable


#### 1.3

 

unavailable


### 2. 禁忌(次の患者には投与しないこと)

 

unavailable


#### 2.1

 

unavailable


#### 2.2

 

unavailable


#### 2.3

 

unavailable


### 3. 組成・性状

 

unavailable


#### 3.1 組成

 

unavailable


#### 3.2 製剤の性状

 

unavailable


### 4. 効能又は効果

 

unavailable


### 5. 効能又は効果に関連する注意

 

unavailable


### 6. 用法及び用量

 

unavailable


### 7. 用法及び用量に関連する注意

 

unavailable


### 8. 重要な基本的注意

 

unavailable


#### 8.1

 

unavailable


#### 8.2

 

unavailable


#### 8.3

 

unavailable


#### 8.4

 

unavailable


### 9. 特定の背景を有する患者に関する注意

 

unavailable


#### 9.1

 

unavailable


#### 9.2 腎機能障害患者

 

unavailable


#### 9.3 肝機能障害患者

 

unavailable


#### 9.4

 

unavailable


#### 9.5 妊婦

 

unavailable


#### 9.6 授乳婦

 

unavailable


### 10. 相互作用

 

unavailable


#### 10.1

 

unavailable


#### 10.2 併用注意(併用に注意すること)

 

unavailable


### 11. 副作用

 

unavailable


#### 11.1 重大な副作用

 

unavailable


#### 11.2 その他の副作用

 

unavailable


### 12. 臨床検査結果に及ぼす影響

 

unavailable


### 13. 過量投与

 

unavailable


### 14. 適用上の注意

 

unavailable


#### 14.1 薬剤交付時の注意

 

unavailable


### 15. その他の注意

 

unavailable


#### 15.1

 

unavailable


#### 15.2 非臨床試験に基づく情報

 

unavailable


### 16. 薬物動態

 

unavailable


#### 16.1 血中濃度

 

unavailable


#### 16.2 吸収

 

unavailable


#### 16.3 分布

 

unavailable


#### 16.5 排泄

 

unavailable


#### 16.6 特定の背景を有する患者

 

unavailable


### 17. 臨床成績

 

unavailable


#### 17.1 有効性及び安全性に関する試験

 

unavailable


### 18. 薬効薬理

 

unavailable


#### 18.1 作用機序

 

unavailable


#### 18.2 抗腫瘍効果

 

unavailable


#### 18.3 エストロゲン抑制作用

 

unavailable


### 19. 有効成分に関する理化学的知見

 

unavailable


### 20. 取扱い上の注意

 

unavailable


### 21. 承認条件

 

unavailable


### 22. 包装

 

unavailable


### 23. 主要文献

 

unavailable


### 24. 文献請求先及び問い合わせ先

 

unavailable


### 25. 保険給付上の注意

 

unavailable


### 26. 製造販売業者等

 

unavailable


### 26.1 製造販売元

 

unavailable


####  Herceptin (trastazumab) 150 mg 
MEDICINE:
** 4291447D2024 **
-------

Full name: **Herceptin (trastazumab) 150 mg**

 - : ** Herceptin ** 

 - : ** trastazumab ** 

 - : ** 150 mg ** 

 - : ** Intravenous infusion ** 

 Name usage: ** ()** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **** 1 of 1

Authorisation number: ** 21300AMY00128 ** 

 Region: ** ** 

Marketing authorisation holder: **Chugai Pharmaceutical Co., Ltd.** 

 Identifier: 
*  **672212** 
 

 Status: ** (2002-08-01T13:28:17Z) ** 

 Package 1 of 1

PMDA-PACKINSERTNO: ** 4291012F1022 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****150 mg

Administrable Product (1 of 1)

 Dose form: ** ** 

 Unit of presentation: ** ** 

 Route of administration: 
*  ** ** 
 
Ingredients:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlejpiherceptin150",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "ja",
  "identifier" : {
    "system" : "https://www.pmda.jp/",
    "value" : "jpiplaceholder"
  },
  "type" : "document",
  "timestamp" : "2002-08-01T13:28:17Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/trastazumabjpi",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "trastazumabjpi",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "ja",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ja\" lang=\"ja\"><a name=\"Composition_trastazumabjpi\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition trastazumabjpi</b></p><a name=\"trastazumabjpi\"> </a><a name=\"hctrastazumabjpi\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: ja</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/fcats34placeholder</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/ 100000155538}\">Package Leaflet</span></p><p><b>date</b>: 2002-08-01 13:28:17+0000</p><p><b>author</b>: <a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></p><p><b>title</b>: Herceptin (trastazumab) Package Leaflet - 150 mg for Intravenous Use</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2002-08-01 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "fcats34placeholder"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/medprodherceptin150"
      }],
      "date" : "2002-08-01T13:28:17Z",
      "author" : [{
        "reference" : "Organization/orgchugai"
      }],
      "title" : "Herceptin (trastazumab) Package Leaflet - 150 mg for Intravenous Use",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2002-08-01T13:28:17Z"
      }],
      "section" : [{
        "title" : "アロマターゼ阻害剤/閉経後乳癌治療剤",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "0"
          }],
          "text" : "アロマターゼ阻害剤/閉経後乳癌治療剤"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "1. 警告",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "1"
          }],
          "text" : "1. 警告"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "1.1",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "2.1"
            }],
            "text" : "1.1"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "1.2",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "2.1"
            }],
            "text" : "1.2"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "1.3",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "2.1"
            }],
            "text" : "1.3"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "2. 禁忌(次の患者には投与しないこと)",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "2"
          }],
          "text" : "禁忌(次の患者には投与しないこと)"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "2.1",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "2.1"
            }],
            "text" : "2.1"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "2.2",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "2.2"
            }],
            "text" : "2.2"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "2.3",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "2.3"
            }],
            "text" : "2.3"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "3. 組成・性状",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "3"
          }],
          "text" : "3. 組成・性状"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "3.1 組成",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "3.1"
            }],
            "text" : "3.1 組成"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "3.2 製剤の性状",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "3.2"
            }],
            "text" : "3.2 製剤の性状"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "4. 効能又は効果",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "4"
          }],
          "text" : "効能又は効果"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "5. 効能又は効果に関連する注意",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "5"
          }],
          "text" : "効能又は効果に関連する注意"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "6. 用法及び用量",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "6"
          }],
          "text" : "用法及び用量"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "7. 用法及び用量に関連する注意",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "7"
          }],
          "text" : "7. 用法及び用量に関連する注意"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "8. 重要な基本的注意",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "8"
          }],
          "text" : "重要な基本的注意"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "8.1",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "8.1"
            }],
            "text" : "8.1"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "8.2",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "8.2"
            }],
            "text" : "8.2"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "8.3",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "8.3"
            }],
            "text" : "8.3"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "8.4",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "8.4"
            }],
            "text" : "8.4"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "9. 特定の背景を有する患者に関する注意",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "9"
          }],
          "text" : "特定の背景を有する患者に関する注意"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "9.1",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "9.2"
            }],
            "text" : "9.1"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "9.2 腎機能障害患者",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "9.2"
            }],
            "text" : "9.2 腎機能障害患者"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "9.2.1 重度の腎障害のある患者",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "9"
              }],
              "text" : "9.2.1 重度の腎障害のある患者"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        },
        {
          "title" : "9.3 肝機能障害患者",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "9.3"
            }],
            "text" : "9.3 肝機能障害患者"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "9.3.1 重度の肝障害のある患者",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "9.3.1"
              }],
              "text" : "9.3.1 重度の肝障害のある患者"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        },
        {
          "title" : "9.4",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "9.4"
            }],
            "text" : "9.4"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "9.5 妊婦",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "9"
            }],
            "text" : "9.5 妊婦"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "9.6 授乳婦",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "9.6"
            }],
            "text" : "9.6 授乳婦"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "10. 相互作用",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "10"
          }],
          "text" : "10. 相互作用"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "10.1",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "9"
            }],
            "text" : "10.1"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "10.2 併用注意(併用に注意すること)",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "10"
            }],
            "text" : "10.2 併用注意(併用に注意すること)"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "11. 副作用",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "11"
          }],
          "text" : "11. 副作用"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "11.1 重大な副作用",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "11.1"
            }],
            "text" : "11.1 重大な副作用"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "11.1.1",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "11.1.1"
              }],
              "text" : "11.1.1"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        },
        {
          "title" : "11.2 その他の副作用",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "11.2"
            }],
            "text" : "11.2 その他の副作用"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "12. 臨床検査結果に及ぼす影響",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "12"
          }],
          "text" : "12. 臨床検査結果に及ぼす影響"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "13. 過量投与",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "13"
          }],
          "text" : "13. 過量投与"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "14. 適用上の注意",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "14"
          }],
          "text" : "14. 適用上の注意"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "14.1 薬剤交付時の注意",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "14.1"
            }],
            "text" : "14.1 薬剤交付時の注意"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "15. その他の注意",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "13"
          }],
          "text" : "15. その他の注意"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "15.1",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "13"
            }],
            "text" : "15.1"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "15.2 非臨床試験に基づく情報",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "13"
            }],
            "text" : "15.2 非臨床試験に基づく情報"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        }]
      },
      {
        "title" : "16. 薬物動態",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "13"
          }],
          "text" : "16. 薬物動態"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "16.1 血中濃度",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "13"
            }],
            "text" : "16.1 血中濃度"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "16.2 吸収",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "13"
            }],
            "text" : "16.2 吸収"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "16.2.1 食事の影響",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "16.2.1 食事の影響"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        },
        {
          "title" : "16.3 分布",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "13"
            }],
            "text" : "16.3 分布"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "16.3.1 組織内濃度",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "16.3.1 組織内濃度"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "16.3.2 胎児・胎盤移行性",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "16.3.2 胎児・胎盤移行性"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "16.3.3 蛋白結合率",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "16.3.3 蛋白結合率"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        },
        {
          "title" : "16.5 排泄",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "13"
            }],
            "text" : "16.5 排泄"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "16.5.1",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "16.5.1"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "16.5.2",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "16.5.2"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        },
        {
          "title" : "16.6 特定の背景を有する患者",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "13"
            }],
            "text" : "16.6 特定の背景を有する患者"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "16.6.1 腎機能障害患者における体内動態",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "16.6.1 腎機能障害患者における体内動態"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "16.6.2 肝機能障害患者における体内動態",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "16.6.2 肝機能障害患者における体内動態"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        }]
      },
      {
        "title" : "17. 臨床成績",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "17"
          }],
          "text" : "17. 臨床成績"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "17.1 有効性及び安全性に関する試験",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "13"
            }],
            "text" : "17.1 有効性及び安全性に関する試験"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "17.1.1 国内臨床試験",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "17.1.1 国内臨床試験"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "17.1.2 ブリッジング試験",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "17.1.2 ブリッジング試験"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "17.1.3 海外臨床試験(第III相試験)",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "17.1.3 海外臨床試験(第III相試験)"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "17.1.4 海外大規模比較試験(第III相試験 術後補助療法)",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "17.1.4 海外大規模比較試験(第III相試験 術後補助療法)"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "17.1.5 海外比較試験(術後補助療法)",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "13"
              }],
              "text" : "17.1.5 海外比較試験(術後補助療法)"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "17.1.6 非盲検無作為化比較試験(第II/III相試験 転移性乳癌に対する第一次 ホルモン療法)",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "16"
              }],
              "text" : "17.1.6 非盲検無作為化比較試験(第II/III相試験 転移性乳癌に対する第一次 ホルモン療法)"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        }]
      },
      {
        "title" : "18. 薬効薬理",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "18"
          }],
          "text" : "18. 薬効薬理"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "18.1 作用機序",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "17"
            }],
            "text" : "18.1 作用機序"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "18.1.1 アロマターゼ阻害作用",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "17"
              }],
              "text" : "18.1.1 アロマターゼ阻害作用"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        },
        {
          "title" : "18.2 抗腫瘍効果",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "17"
            }],
            "text" : "18.2 抗腫瘍効果"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          }
        },
        {
          "title" : "18.3 エストロゲン抑制作用",
          "code" : {
            "coding" : [{
              "system" : "https://pmda.jp/",
              "code" : "17"
            }],
            "text" : "18.3 エストロゲン抑制作用"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
          },
          "emptyReason" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "unavailable"
            }]
          },
          "section" : [{
            "title" : "18.3.1",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "17"
              }],
              "text" : "18.3.1"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          },
          {
            "title" : "18.3.2",
            "code" : {
              "coding" : [{
                "system" : "https://pmda.jp/",
                "code" : "17"
              }],
              "text" : "18.3.2"
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
            },
            "emptyReason" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                "code" : "unavailable"
              }]
            }
          }]
        }]
      },
      {
        "title" : "19. 有効成分に関する理化学的知見",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "19"
          }],
          "text" : "19. 有効成分に関する理化学的知見"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "20. 取扱い上の注意",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "9"
          }],
          "text" : "20. 取扱い上の注意"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "21. 承認条件",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "9"
          }],
          "text" : "21. 承認条件"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "22. 包装",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "22"
          }],
          "text" : "22. 包装"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "23. 主要文献",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "23"
          }],
          "text" : "23. 主要文献"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "24. 文献請求先及び問い合わせ先",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "24"
          }],
          "text" : "24. 文献請求先及び問い合わせ先"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "25. 保険給付上の注意",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "9"
          }],
          "text" : "25. 保険給付上の注意"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "26. 製造販売業者等",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "26"
          }],
          "text" : "26. 製造販売業者等"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      },
      {
        "title" : "26.1 製造販売元",
        "code" : {
          "coding" : [{
            "system" : "https://pmda.jp/",
            "code" : "26"
          }],
          "text" : "26.1 製造販売元"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/orgchugai",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "orgchugai",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_orgchugai\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization orgchugai</b></p><a name=\"orgchugai\"> </a><a name=\"hcorgchugai\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://pmda-org-id</code>/672212 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://PMDA-org-type.jp/ tbd}\">Marketing authorisation holder</span></p><p><b>name</b>: Chugai Pharmaceutical Co., Ltd.</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Medical Information Department 2-1-1 Nihonbashi Muromachi, Chuo-ku, Tokyo 103-8324(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://pmda-org-id",
        "value" : "672212"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://PMDA-org-type.jp/",
          "code" : "tbd",
          "display" : "Marketing authorisation holder"
        }],
        "text" : "Marketing authorisation holder"
      }],
      "name" : "Chugai Pharmaceutical Co., Ltd.",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Medical Information Department 2-1-1 Nihonbashi Muromachi, Chuo-ku, Tokyo 103-8324",
          "line" : ["2-1-1 Nihonbashi Muromachi"],
          "city" : "Tokyo",
          "postalCode" : "103-8324",
          "country" : "Tokyo"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Authorizations/authherceptin150",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authherceptin150",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authherceptin150\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authherceptin150</b></p><a name=\"authherceptin150\"> </a><a name=\"hcauthherceptin150\"> </a><p><b>identifier</b>: <code>https://pmda-approvalandlicenseno/</code>/21300AMY00128 (use: official, )</p><p><b>subject</b>: <a href=\"MedicinalProductDefinition-medprodherceptin150.html\">MedicinalProductDefinition: identifier = http://iyaku.info/medicine#4291447D2024; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ /#100000072062}\">Marketing Authorisation</span></p><p><b>region</b>: <span title=\"Codes:{urn:iso:std:iso:3166 JP}\">Japan</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2002-08-01 13:28:17+0000</p><p><b>holder</b>: <a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://pmda-approvalandlicenseno/",
        "value" : "21300AMY00128"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/medprodherceptin150"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "/#100000072062"
        }],
        "text" : "Marketing Authorisation"
      },
      "region" : [{
        "coding" : [{
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP"
        }],
        "text" : "Japan"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }],
        "text" : "Active"
      },
      "statusDate" : "2002-08-01T13:28:17Z",
      "holder" : {
        "reference" : "Organization/orgchugai"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/medprodherceptin150",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "medprodherceptin150",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_medprodherceptin150\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition medprodherceptin150</b></p><a name=\"medprodherceptin150\"> </a><a name=\"hcmedprodherceptin150\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>http://iyaku.info/medicine</code>/4291447D2024</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Herceptin (trastazumab) 150 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Herceptin</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: trastazumab</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 150 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Intravenous infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 100000075213}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 JP}\">Japan</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 JP}\">Japan</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 ja-JP}\">Japanese (Japan)</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://iyaku.info/medicine",
        "value" : "4291447D2024"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Herceptin (trastazumab) 150 mg",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001"
          }],
          "text" : "Full name"
        },
        "part" : [{
          "part" : "Herceptin",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002"
            }],
            "text" : "Invented name part"
          }
        },
        {
          "part" : "trastazumab",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003"
            }],
            "text" : "Scientific name part"
          }
        },
        {
          "part" : "150 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004"
            }],
            "text" : "Strength part"
          }
        },
        {
          "part" : "Intravenous infusion",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "100000075213"
            }],
            "text" : "Pharmaceutical dose form part"
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "JP"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "JP"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "ja-JP"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/packherceptinvial",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "packherceptinvial",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_packherceptinvial\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition packherceptinvial</b></p><a name=\"packherceptinvial\"> </a><a name=\"hcpackherceptinvial\"> </a><p><b>identifier</b>: <code>https://pmda-packinsertno/</code>/4291012F1022 (use: official, )</p><p><b>name</b>: Herceptin (trastazumab) 150 mg for Intravenous Use</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medininal Prodcut</span></p><p><b>packageFor</b>: <a href=\"MedicinalProductDefinition-medprodherceptin150.html\">MedicinalProductDefinition: identifier = http://iyaku.info/medicine#4291447D2024; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2002-08-01 13:28:17+0000</p><p><b>containedItemQuantity</b>: 150 mg</p><p><b>manufacturer</b>: <a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></p><h3>Packagings</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Identifier</b></td><td><b>Type</b></td><td><b>Quantity</b></td><td><b>Material</b></td></tr><tr><td style=\"display: none\">*</td><td><code>https://spor.ema.europa.eu/pmswi</code>/123456</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073563}\">Vial</span></td><td>28</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003204}\">Glass type I</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://pmda-packinsertno/",
        "value" : "4291012F1022"
      }],
      "name" : "Herceptin (trastazumab) 150 mg for Intravenous Use",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medininal Prodcut"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/medprodherceptin150"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2002-08-01T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 150,
        "unit" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/orgchugai"
      }],
      "packaging" : {
        "identifier" : [{
          "system" : "https://spor.ema.europa.eu/pmswi",
          "value" : "123456"
        }],
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073563",
            "display" : "Vial"
          }]
        },
        "quantity" : 28,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003204",
            "display" : "Glass type I"
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/adminprodherceptin150",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "adminprodherceptin150",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_adminprodherceptin150\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition adminprodherceptin150</b></p><a name=\"adminprodherceptin150\"> </a><a name=\"hcadminprodherceptin150\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://www.who-umc.org/phpid</code>/7532F47F36A3585D1F348BBDDA057862</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"MedicinalProductDefinition-medprodherceptin150.html\">MedicinalProductDefinition: identifier = http://iyaku.info/medicine#4291447D2024; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 10219000}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 15054000}\">15054000</span></p><p><b>producedFrom</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><h3>RouteOfAdministrations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 20053000}\">20053000</span></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.who-umc.org/phpid",
        "value" : "7532F47F36A3585D1F348BBDDA057862"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/medprodherceptin150"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "10219000"
        }],
        "text" : "Tablet"
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "15054000"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "20053000"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/manitemherceptin150",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "manitemherceptin150",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_manitemherceptin150\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition manitemherceptin150</b></p><a name=\"manitemherceptin150\"> </a><a name=\"hcmanitemherceptin150\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://pmda-sccj</code>/874291 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://standardterms.edqm.eu/browse/get_concepts_by/SOM/SOM/ 10219000}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://standardterms.edqm.eu/browse/get_concepts/UOP/ 15054000}\">15054000</span></p><p><b>manufacturer</b>: <a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://pmda-sccj",
        "value" : "874291"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://standardterms.edqm.eu/browse/get_concepts_by/SOM/SOM/",
          "code" : "10219000"
        }],
        "text" : "Tablet"
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://standardterms.edqm.eu/browse/get_concepts/UOP/",
          "code" : "15054000"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/orgchugai"
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/trastazumab",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "trastazumab",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_trastazumab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient trastazumab</b></p><a name=\"trastazumab\"> </a><a name=\"hctrastazumab\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/P188ANX8CK (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta P188ANX8CK}\">trastazumab</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>150 mg</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "P188ANX8CK"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "P188ANX8CK",
              "display" : "trastazumab"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 150,
            "unit" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB"
            }],
            "text" : "active ingredient - basis of strength"
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/carnubawax",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "carnubawax",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_carnubawax\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient carnubawax</b></p><a name=\"carnubawax\"> </a><a name=\"hccarnubawax\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/R12CBM0EIZ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ R12CBM0EIZ}\">Carnauba wax</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "R12CBM0EIZ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "R12CBM0EIZ",
              "display" : "Carnauba wax"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/crystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "crystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_crystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient crystallinecellulose</b></p><a name=\"crystallinecellulose\"> </a><a name=\"hccrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ OP1R32D61U}\">crystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "OP1R32D61U",
              "display" : "crystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/mannitol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "mannitol",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_mannitol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient mannitol</b></p><a name=\"mannitol\"> </a><a name=\"hcmannitol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/3OWL53L36A (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 3OWL53L36A}\">MANNITOL</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "3OWL53L36A"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "3OWL53L36A",
              "display" : "MANNITOL"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/hypromelose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "hypromelose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_hypromelose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient hypromelose</b></p><a name=\"hypromelose\"> </a><a name=\"hchypromelose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/3NXW29V3WO (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 3NXW29V3WO}\">HYPROMELLOSE, UNSPECIFIED</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "3NXW29V3WO"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "3NXW29V3WO",
              "display" : "HYPROMELLOSE, UNSPECIFIED"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/lightanhydroussilicicacid",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "lightanhydroussilicicacid",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_lightanhydroussilicicacid\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient lightanhydroussilicicacid</b></p><a name=\"lightanhydroussilicicacid\"> </a><a name=\"hclightanhydroussilicicacid\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/ETJ7Z6XBU4 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ ETJ7Z6XBU4}\">light anhydrous silicic acid</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "ETJ7Z6XBU4"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "ETJ7Z6XBU4",
              "display" : "light anhydrous silicic acid"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/magnesiumcarbonate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "magnesiumcarbonate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_magnesiumcarbonate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient magnesiumcarbonate</b></p><a name=\"magnesiumcarbonate\"> </a><a name=\"hcmagnesiumcarbonate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/0E53J927NA (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 0E53J927NA}\">MAGNESIUM CARBONATE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "0E53J927NA"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "0E53J927NA",
              "display" : "MAGNESIUM CARBONATE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient magnesiumstearate</b></p><a name=\"magnesiumstearate\"> </a><a name=\"hcmagnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 70097M6I30}\">MAGNESIUM STEARATE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "70097M6I30",
              "display" : "MAGNESIUM STEARATE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/methylparaben",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "methylparaben",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_methylparaben\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient methylparaben</b></p><a name=\"methylparaben\"> </a><a name=\"hcmethylparaben\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/A2I8C7HI9T (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ A2I8C7HI9T}\">METHYLPARABEN</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "A2I8C7HI9T"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "A2I8C7HI9T",
              "display" : "METHYLPARABEN"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/polyethyleneglycol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "polyethyleneglycol",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_polyethyleneglycol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient polyethyleneglycol</b></p><a name=\"polyethyleneglycol\"> </a><a name=\"hcpolyethyleneglycol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/30IQX730WE (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 30IQX730WE}\">POLYETHYLENE GLYCOL 6000</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "30IQX730WE"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "30IQX730WE",
              "display" : "POLYETHYLENE GLYCOL 6000"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/polysorbate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "polysorbate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_polysorbate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient polysorbate</b></p><a name=\"polysorbate\"> </a><a name=\"hcpolysorbate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/6OZP39ZG8H (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 6OZP39ZG8H}\">POLYSORBATE 80</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "6OZP39ZG8H"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "6OZP39ZG8H",
              "display" : "POLYSORBATE 80"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/polyvinylalcohol",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "polyvinylalcohol",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_polyvinylalcohol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient polyvinylalcohol</b></p><a name=\"polyvinylalcohol\"> </a><a name=\"hcpolyvinylalcohol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/532B59J990 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 532B59J990}\">POLYVINYL ALCOHOL, UNSPECIFIED</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "532B59J990"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "532B59J990",
              "display" : "POLYVINYL ALCOHOL, UNSPECIFIED"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/sucrose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "sucrose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_sucrose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient sucrose</b></p><a name=\"sucrose\"> </a><a name=\"hcsucrose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/C151H8M554 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ C151H8M554}\">SUCROSE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "C151H8M554"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "C151H8M554",
              "display" : "SUCROSE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/silicondioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "silicondioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_silicondioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient silicondioxide</b></p><a name=\"silicondioxide\"> </a><a name=\"hcsilicondioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/ETJ7Z6XBU4 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ ETJ7Z6XBU4}\">SILICON DIOXIDE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "ETJ7Z6XBU4"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "ETJ7Z6XBU4",
              "display" : "SILICON DIOXIDE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/sodiumstarch",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "sodiumstarch",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_sodiumstarch\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient sodiumstarch</b></p><a name=\"sodiumstarch\"> </a><a name=\"hcsodiumstarch\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/5856J3G2A2 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 5856J3G2A2}\">SODIUM STARCH GLYCOLATE TYPE A POTATO</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "5856J3G2A2"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "5856J3G2A2",
              "display" : "SODIUM STARCH GLYCOLATE TYPE A POTATO"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/syntehticwax",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "syntehticwax",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_syntehticwax\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient syntehticwax</b></p><a name=\"syntehticwax\"> </a><a name=\"hcsyntehticwax\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/5M631N9V0S (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 5M631N9V0S}\">synthetic wax</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "5M631N9V0S"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "5M631N9V0S",
              "display" : "synthetic wax"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/talc",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "talc",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_talc\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient talc</b></p><a name=\"talc\"> </a><a name=\"hctalc\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/7SEV7J4R1U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 7SEV7J4R1U}\">talc</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "7SEV7J4R1U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "7SEV7J4R1U",
              "display" : "talc"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/titaniumdioxide2",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "titaniumdioxide2",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_titaniumdioxide2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient titaniumdioxide2</b></p><a name=\"titaniumdioxide2\"> </a><a name=\"hctitaniumdioxide2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/15FIX9V2JP (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: <a href=\"ManufacturedItemDefinition-manitemherceptin150.html\">ManufacturedItemDefinition: identifier = https://pmda-sccj#874291 (use: official, ); status = active; manufacturedDoseForm = 10219000; unitOfPresentation = 15054000</a></p><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><h3>Manufacturers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manufacturer</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></td></tr></table><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 15FIX9V2JP}\">TITANIUM DIOXIDE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "15FIX9V2JP"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/manitemherceptin150"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "manufacturer" : [{
        "manufacturer" : {
          "reference" : "Organization/orgchugai"
        }
      }],
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "15FIX9V2JP",
              "display" : "TITANIUM DIOXIDE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/subherceptin150",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "subherceptin150",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_subherceptin150\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition subherceptin150</b></p><a name=\"subherceptin150\"> </a><a name=\"hcsubherceptin150\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/P188ANX8CK (use: official, )</p><p><b>version</b>: 39</p><p><b>status</b>: <span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 1}\">Validated (UNII)</span></p><p><b>description</b>: </p><div><p>White to pale yellow</p>\n</div><p><b>manufacturer</b>: <a href=\"Organization-orgchugai.html\">Organization Chugai Pharmaceutical Co., Ltd.</a></p><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C20H24O2</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>trastazumab</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ 1}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "P188ANX8CK"
      }],
      "version" : "39",
      "status" : {
        "coding" : [{
          "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
          "code" : "1"
        }],
        "text" : "Validated (UNII)"
      },
      "description" : "White to pale yellow",
      "manufacturer" : [{
        "reference" : "Organization/orgchugai"
      }],
      "structure" : {
        "molecularFormula" : "C20H24O2"
      },
      "name" : [{
        "name" : "trastazumab",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "1"
          }],
          "text" : "Chemical Name"
        }
      }]
    }
  }]
}

```
