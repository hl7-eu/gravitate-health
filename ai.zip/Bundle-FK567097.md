# FK567097 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK567097**

## Example Bundle: FK567097

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: Informasjon til brukeren

 

# Pakningsvedlegg: Informasjon til brukeren

## Lantus 100 enheter/ml injeksjonsvæske, oppløsning i sylinderampulle

### insulin glargin


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg. Les også nøye insulinpennens bruksanvisning som følger med i pakningen.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg. Les også nøye insulinpennens bruksanvisning som følger med i pakningen.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Hvis du har ytterligere spørsmål, kontakt lege eller apotek.
* Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.
* Kontakt lege eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om:

 

## I dette pakningsvedlegget finner du informasjon om:

1. Hva Lantus er og hva det brukes mot
1. Hva du må vite før du bruker Lantus
1. Hvordan du bruker Lantus
1. Mulige bivirkninger
1. Hvordan du oppbevarer Lantus
1. Innholdet i pakningen og ytterligere informasjon


#### 1. Hva Lantus er og hva det brukes mot

 

## 1. Hva Lantus er og hva det brukes mot

Lantus inneholder insulin glargin. Dette er et modifisert insulin, meget likt humaninsulin.

Lantus brukes for å behandle diabetes mellitus (sukkersyke) hos voksne, ungdom og barn fra 2 års alderen. Ved diabetes mellitus produserer ikke kroppen tilstrekkelig insulin til å kunne holde blodets sukkerinnhold under kontroll. Insulin glargin har langvarig og stabil blodsukkersenkende effekt.


#### 2. Hva du må vite før du bruker Lantus

 

## 2. Hva du må vite før du bruker Lantus


#### 3. Hvordan du bruker Lantus

 

## 3. Hvordan du bruker Lantus

Bruk alltid dette legemidlet nøyaktig slik legen din har fortalt deg. Kontakt lege eller apotek hvis du er usikker.

Selv om Lantus inneholder det samme virkestoffet som Toujeo (insulin glargin 300 enheter/ml) er disse legemidlene ikke byttbare. Overgangen fra en insulinbehandling til en annen krever forskrivning og oppfølging fra lege og blodsukkerovervåkning. Rådfør deg med lege for mere informasjon.

Dose
Med utgangspunkt i din livsstil og resultatet av blodsukkermålingene dine, kommer legen din til å:
* avgjøre hvor mye Lantus du trenger daglig, og til hvilket tidspunkt,
* fortelle deg når du skal kontrollere blodsukkernivået, og om du må ta urinprøver,
* fortelle deg når det kan være nødvendig å ta en større eller mindre dose Lantus.

Lantus er et langtidsvirkende insulin. Legen din kan forskrive det i kombinasjon med et korttidsvirkende insulin eller med tabletter for behandling av høye blodsukkernivåer.

Det er mange faktorer som kan påvirke blodsukkernivået. Disse faktorene må du kjenne til for å kunne handle korrekt ved endringer i blodsukkernivået og for å forhindre at det blir for høyt eller for lavt. Du finner ytterligere opplysninger i slutten av dette pakningsvedlegget.

Bruk av Lantus hos barn og ungdom
Lantus kan brukes av ungdom og barn fra 2 år og oppover. Bruk dette legemidlet nøyaktig slik legen din har fortalt deg.

Når skal Lantus injiseres
Du trenger én injeksjon med Lantus i døgnet. Denne tas til et fast tidspunkt.

Hvordan skal Lantus injiseres
Lantus injiseres under huden. Du må ALDRI injisere Lantus i en blodåre, da dette gir en annen effekt og kan forårsake hypoglykemi.

Legen forteller deg i hvilket hudområde du skal injisere Lantus. Bytt injeksjonssted hver gang innenfor det valgte hudområdet.

Håndtering av sylinderampullene
Lantus i sylinderampuller er kun tilpasset injeksjon like under huden ved bruk av en flergangspenn. Rådfør deg med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.

For å sikre at du får riktig dose skal Lantus sylinderampuller kun brukes sammen med følgende penner:
* JuniorSTAR, som leverer doser i trinn på 0,5 enheter
* ClikSTAR, Tactipen, Autopen 24, AllStar eller AllStar PRO, som leverer doser i trinn på 1 enhet. Ikke alle disse pennene er nødvendigvis markedsført i Norge.

Pennen skal brukes som forklart i bruksanvisningen som følger med pennen.

Følg denne bruksanvisningen nøye ved innsetting av insulinampulle, påsetting av injeksjonskanyle og injeksjon av insulinet.

Oppbevar sylinderampullen i romtemperatur i 1 til 2 timer før du setter den i pennen.

Kontroller sylinderampullen før bruk. Du kan bare bruke klare, fargeløse oppløsninger med vannlignende konsistens og uten synlige partikler.

Ikke ryst eller bland den før bruk.

Bytt alltid til en ny sylinderampulle hvis du merker at kontrollen med blodsukkeret uventet holder på å bli dårligere. Dette er fordi insulinet kan ha mistet noe av effekten. Hvis du tror det kan være problemer med Lantus, bør du få det kontrollert hos lege eller på apotek.

Vær spesielt oppmerksom på følgende før injeksjon
Evt. luftbobler må fjernes før injeksjon. Det er viktig å forsikre seg om at insulinet ikke forurenses av alkohol, andre desinfeksjonsmidler eller andre stoffer. Ikke fyll sylinderampullene for gjenbruk. Andre former for insulin må ikke tilsettes sylinderampullen. Ikke bland Lantus med noen andre former for insulin eller legemidler. Lantus skal ikke fortynnes, da blanding eller fortynning kan endre effekten.

Problemer med insulinpennen?
Les bruksanvisningen som følger med pennen.

**Hvis insulinpennen er ødelagt eller ikke virker som den skal (pga. mekanisk feil), må den kastes **
**og en ny insulinpenn må benyttes.**

Forveksling av insulintyper
Du må alltid kontrollere insulinetiketten før hver injeksjon, for å unngå å forveksle Lantus med andre typer insuliner.


#### 4. Mulige bivirkninger

 

## 4. Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.

**Hvis du oppdager tegn på at blodsukkernivået ditt er for lavt (hypoglykemi) **må du gjøre noe for å øke blodsukkernivået umiddelbart (se tekstboksen på slutten av dette pakningsvedlegget).

Hypoglykemi (lavt blodsukker) kan være svært alvorlig og er svært vanlig ved insulinbehandling (kan oppstå hos flere enn 1 av 10 personer). Lavt blodsukker betyr at det ikke er nok sukker i blodet ditt.

Hvis ditt blodsukkernivå faller for lavt kan du besvime (miste bevisstheten). Alvorlig hypoglykemi kan forårsake hjerneskade og være livstruende. For mer informasjon, se tekstboksen på slutten av dette pakningsvedlegget.

**Alvorlige allergiske reaksjoner **(sjeldne, kan oppstå hos inntil 1 av 1000 personer) – tegn kan være omfattende hudreaksjoner (utslett og kløe over hele kroppen), kraftig hevelse av huden eller slimhinne (angioødem), kortpustethet, blodtrykksfall med rask puls eller svetting. Alvorlige allergiske reaksjoner på insuliner kan bli livstruende. Ta øyeblikkelig kontakt med lege dersom du merker tegn på en alvorlig allergisk reaksjon.

* **Hudforandringer på injeksjonsstedet:**
Hvis du injiserer insulin for ofte på samme sted, kan huden på dette stedet enten skrumpe inn (lipoatrofi) (kan oppstå hos 1 av 100 personer) eller fortykkes (lipohypertrofi) (kan oppstå hos 1 av 10 personer). Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.

**Vanlig rapporterte bivirkninger **(kan oppstå hos inntil 1 av 10 personer)

* **Hud og allergiske reaksjoner på injeksjonsstedet**
Tegn kan være rødme, uvanlig intens smerte ved injeksjon, kløe, utslett, hevelse eller betennelse. Dette kan spre seg til området rundt injeksjonsstedet. De fleste milde insulinreaksjoner forsvinner vanligvis i løpet av et par dager til et par uker.

**Sjeldne rapporterte bivirkninger **(kan oppstå hos inntil 1 av 1000 personer)
* **Påvirkning av synet**
En merkbar forandring (forbedring eller forverring) i kontrollen av blodsukkeret ditt kan forbigående forstyrre synet ditt. Hvis du har proliferativ retinopati (en øyesykdom relatert til diabetes), kan alvorlige hypoglykemier forårsake forbigående synstap.

* **Generelle bivirkninger**
I sjeldne tilfeller kan insulinbehandling også gi forbigående vannansamlinger i kroppen, med hevelse i legger og ankler.

**Svært sjeldent rapporterte bivirkninger (**kan oppstå hos inntil 1 av 10 000 personer)

I svært sjeldne tilfeller kan dysgeusi (smaksforandringer) og myalgi (muskelsmerter) oppstå.

Bivirkninger som kan forekomme hos barn og ungdom
Generelt er bivirkningene for barn og ungdom som er 18 år eller yngre lignende de som er sett hos voksne. Klager på reaksjoner på injeksjonsstedet (smerte ved injeksjonsstedet, reaksjoner ved injeksjonsstedet) og hudreaksjoner (utslett, elveblest) er rapportert releativt oftere hos barn og ungdom som er 18 år eller yngre i forhold til voksne.

Det er ikke erfaring med bruk hos barn under 2 år.


#### 5. Hvordan du oppbevarer Lantus

 

## 5. Hvordan du oppbevarer Lantus

Oppbevares utilgjengelig for barn.

Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken og på etiketten på sylinderampullen etter ”EXP”. Utløpsdatoen henviser til den siste dagen i den måneden.

Uåpnete sylinderampuller

Oppbevares i kjøleskap (2-8ºC). Skal ikke fryses, eller plasseres ved fryseboks eller fryseelementer. Oppbevar sylinderampullen i ytteremballasjen for å beskytte mot lys.

Sylinderampuller i bruk

Sylinderampuller som er i bruk (i insulinpennen) eller tatt med som reserve, kan oppbevares i inntil 4 uker ved høyst 30ºC beskyttet fra direkte varme og lys. Sylinderampuller som er i bruk må ikke oppbevares i kjøleskap. Etter denne tiden må sylinderampullen ikke brukes.

Bruk ikke Lantus hvis du ser partikler i oppløsningen. Du må bare bruke Lantus hvis oppløsningen er klar, fargeløs, med vannlignende konsistens.

Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan legemidler som du ikke lenger bruker skal kastes. Disse tiltakene bidrar til å beskytte miljøet.


#### 6. Innholdet i pakningen og ytterligere informasjon

 

## 6. Innholdet i pakningen og ytterligere informasjon


####  Lantus inj, oppl 100 E/ml 
LEGEMIDDELMERKEVAREID:
** ID_1536BD37-E67E-40E3-A88A-F7A2404F63CF **
-------

Full name: **Lantus inj, oppl 100 E/ml**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_F5DDF232-DC47-48FA-82BD-9156E6A7FBDA ** 

VARENUMMER: ** 004746 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK567097",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "567097"
  },
  "type" : "document",
  "timestamp" : "2021-11-24T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK567097-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK567097-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK567097-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK567097-COMP</b></p><a name=\"FK567097-COMP\"> </a><a name=\"hcFK567097-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/567097</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2021-11-24</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: Lantus sanofi-aventis sylinderampuller til AllStar PRO/JuniorSTAR</p></div>"
      },
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "567097"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-64"
      }],
      "date" : "2021-11-24",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "Lantus sanofi-aventis sylinderampuller til AllStar PRO/JuniorSTAR",
      "section" : [{
        "title" : "Pakningsvedlegg: Informasjon til brukeren",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: Informasjon til brukeren</h1><h2>Lantus 100 enheter/ml injeksjonsvæske, oppløsning i sylinderampulle</h2><h3>insulin glargin</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg. Les også nøye insulinpennens bruksanvisning som følger med i pakningen.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg. Les også nøye insulinpennens bruksanvisning som følger med i pakningen.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Hvis du har ytterligere spørsmål, kontakt lege eller apotek.</li><li>Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.</li><li>Kontakt lege eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om:",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om:</h2><div class=\"paragraph\"><ol><li>Hva Lantus er og hva det brukes mot</li><li>Hva du må vite før du bruker Lantus</li><li>Hvordan du bruker Lantus</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer Lantus</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "1. Hva Lantus er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>1. Hva Lantus er og hva det brukes mot</h2><div class=\"paragraph\">Lantus inneholder insulin glargin. Dette er et modifisert insulin, meget likt humaninsulin.</div><div class=\"paragraph\">Lantus brukes for å behandle diabetes mellitus (sukkersyke) hos voksne, ungdom og barn fra 2 års alderen. Ved diabetes mellitus produserer ikke kroppen tilstrekkelig insulin til å kunne holde blodets sukkerinnhold under kontroll. Insulin glargin har langvarig og stabil blodsukkersenkende effekt.</div></div>"
          }
        },
        {
          "title" : "2. Hva du må vite før du bruker Lantus",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>2. Hva du må vite før du bruker Lantus</h2></div>"
          },
          "section" : [{
            "title" : "Bruk ikke Lantus",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Bruk ikke Lantus</h3><div class=\"paragraph\"><ul><li>dersom du er allergisk overfor insulin glargin eller noen av de andre innholdsstoffene i dette legemidlet (listet opp i avsnitt 6).</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler</h3><div class=\"paragraph\">Lantus i sylinderampuller er kun tilpasset injeksjon like under huden ved bruk av en flergangspenn (se også avsnitt 3). Rådfør deg med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.</div><div class=\"paragraph\">Rådfør deg med lege, apotek eller sykepleier før du bruker Lantus.</div><div class=\"paragraph\">Vær nøye med å følge doseringsinstruksjonene og instruksjonene for kontroll av blod og urin, kosthold og fysiske aktiviteter (fysisk arbeid og trening) i samsvar med det som er avtalt med din lege. Hvis blodsukkeret ditt er for lavt (hypoglykemi), følg rådene for hypoglykemi (se boksen sist i pakningsvedlegget).<br/>Hudforandringer på injeksjonsstedet</div><div class=\"paragraph\">Injeksjonsstedet bør roteres for å forebygge hudforandringer som for eksempel kuler under huden. Det kan hende at insulinet ikke virker så godt hvis du injiserer det på et klumpete sted på huden (se Hvordan bruke Lantus). Hvis du pleier å injisere på et klumpete område og vil endre injeksjonssted til et annet område, må du ta kontakt med legen din først. Legen din kan gi deg beskjed om å kontrollere blodsukkeret ditt mer nøye og å justere dosen på insulinet ditt eller andre legemidler du bruker mot diabetes.</div><div class=\"paragraph\">Reiser</div><div class=\"paragraph\">Rådfør deg med din lege før du skal ut og reise. Det kan være nødvendig å ta opp:<ul><li>tilgjengeligheten av din type insulin i det landet du besøker,</li><li>forsyninger av insulin, kanyler osv,</li><li>riktig oppbevaring av insulinet under reisen,</li><li>inntak av måltider og insulintilførsel under reisen,</li><li>eventuelle følger av å krysse tidssoner,</li><li>eventuelle nye helsefarer i de land du besøker,</li><li>hva du skal gjøre i nødsituasjoner når du føler deg uvel eller blir syk.</li></ul></div><div class=\"paragraph\">Sykdommer og skader<br/>I følgende situasjoner krever håndteringen av din diabetes stor omtanke (for eksempel ved justering av insulindosen, blod- og urinprøver):<ul><li>dersom du er syk eller har en større skade kan blodsukkernivået ditt øke (hyperglykemi).</li><li>dersom du ikke spiser nok kan blodsukkernivået ditt bli for lavt (hypoglykemi).</li></ul></div><div class=\"paragraph\">I de fleste tilfeller vil du ha behov for legehjelp. <b>Vær tidlig ute med å kontakte lege.</b><br/>Dersom du har diabetes type 1 (insulinkrevende diabetes mellitus), skal du ikke slutte med insulinbehandlingen og du må sørge for fortsatt tilførsel av karbohydrater. Fortell alle som pleier eller behandler deg at du trenger insulin.</div><div class=\"paragraph\">Insulinbehandling kan føre til at kroppen danner antistoffer mot insulin (stoffer som reagerer mot insulin). Dette vil kun i sjeldne tilfeller gjøre det nødvendig å endre insulindosen.</div><div class=\"paragraph\">Enkelte pasienter med langvarig type 2 diabetes mellitus og hjertesykdom eller som har hatt slag, som har blitt behandlet med pioglitazon (oralt antidiabetes legemiddel som brukes til å behandle type 2 diabetes mellitus) og insulin, har utviklet hjertesvikt. Informer legen din så snart som mulig dersom du får tegn på hjertesvikt, som for eksempel uvanlig kortpustethet, rask vektøkning eller lokal hevelse (ødem).</div></div>"
            }
          },
          {
            "title" : "Barn",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029899"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Barn</h3><div class=\"paragraph\">Det er ingen erfaring med bruk av Lantus hos barn under 2 år.</div></div>"
            }
          },
          {
            "title" : "Andre legemidler og Lantus",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og Lantus</h3><div class=\"paragraph\">Enkelte legemidler forårsaker en endring i blodsukkernivået (økning, reduksjon eller begge deler, avhengig av omstendighetene). Det kan i hvert tilfelle bli nødvendig å justere insulindosen din for å unngå for lavt eller for høyt blodsukkernivå. Vær ekstra oppmerksom når du skal begynne eller slutte å ta et annet legemiddel.</div><div class=\"paragraph\">Rådfør deg med lege eller apotek dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler. Før du tar et legemiddel, må du spørre legen om det vil påvirke blodsukkernivået ditt og hva du eventuelt må gjøre.</div><span class=\"inline-title\">Legemidler som kan forårsake senkning av blodsukkernivået (hypoglykemi) er:</span><div class=\"paragraph\"><ul><li>alle andre medisiner for behandling av diabetes,</li><li>legemidler som hemmer angiotensinkonverterende enzym (ACE) (brukt i behandling av visse hjertelidelser eller høyt blodtrykk),</li><li>disopyramid (brukt i behandling av visse hjertelidelser),</li><li>fluoksetin (brukt i behandling av depresjon),</li><li>fibrater (brukt for å senke høye nivåer av blodlipider),</li><li>legemidler som hemmer enzymet monoaminoksidase (MAO) (brukt i behandling av depresjon),</li><li>pentoksifyllin, propoksyfen, salisylater (for eksempel acetylsalisylsyre, som er smertestillende og febernedsettende),</li><li>antibiotika av typen sulfonamider.</li></ul></div><span class=\"inline-title\">Legemidler som kan forårsake økning av blodsukkernivået (hyperglykemi) er:</span><div class=\"paragraph\"><ul><li>kortikosteroider (for eksempel ”kortison”, brukt i behandling av betennelsestilstander),</li><li>danazol (legemiddel som virker på eggløsningen),</li><li>diazoksid (brukt i behandling av høyt blodtrykk),</li><li>diuretika (brukt i behandling av høyt blodtrykk eller væskeretensjon),</li><li>glukagon (bukspyttkjertelhormon brukt i behandling av alvorlig hypoglykemi),</li><li>isoniazid (brukt i behandling av tuberkulose),</li><li>østrogener og progesteroner (for eksempel i p-piller brukt som prevensjon),</li><li>fenotiazinderivater (brukt i behandling av psykiatriske lidelser),</li><li>somatropin (veksthormon),</li><li>sympatomimetika (for eksempel salbutamol, terbutalin (brukt i behandling av astma) eller adrenalin),</li><li>thyreoideahormoner (brukt i behandling av sykdom i skjoldbruskkjertelen),</li><li>proteasehemmere (brukt i behandling av HIV)</li><li>atypiske antipsykotika (for eksempel olanzapin og klozapin).</li></ul></div><span class=\"inline-title\">Blodsukkernivået kan enten synke eller øke hvis du tar:</span><div class=\"paragraph\"><ul><li>betablokkere (brukt i behandling av høyt blodtrykk),</li><li>klonidin (brukt i behandling av høyt blodtrykk),</li><li>litiumsalter (brukt i behandling av psykiatriske lidelser),</li></ul></div><div class=\"paragraph\">Pentamidin (brukes i behandlingen av visse parasittinfeksjoner) kan forårsake hypoglykemi som enkelte ganger kan følges av hyperglykemi.</div><div class=\"paragraph\">Betablokkere kan i likhet med andre sympatolytiske legemidler (for eksempel klonidin, guanetidin og reserpin) svekke eller totalt undertrykke de første varselsymptomene som hjelper deg å gjenkjenne en hypoglykemisk reaksjon.</div><div class=\"paragraph\">Hvis du er usikker på om du tar noen av disse medisinene, kan du rådspørre lege eller på apotek.</div></div>"
            }
          },
          {
            "title" : "Lantus sammen med alkohol",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029901"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Lantus sammen med alkohol</h3><div class=\"paragraph\">Blodsukkernivået kan enten synke eller øke hvis du drikker alkohol.</div></div>"
            }
          },
          {
            "title" : "Graviditet og amming",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet og amming</h3><div class=\"paragraph\">Rådfør deg med lege eller apotek før du tar dette legemidlet dersom du er gravid eller ammer, tror at du kan være gravid eller planlegger å bli gravid.</div><div class=\"paragraph\">Informer legen dersom du planlegger å bli gravid, eller hvis du allerede er gravid. Det kan være nødvendig å justere insulindosen under svangerskapet eller etter fødselen. For barnets skyld er det særdeles viktig at din diabetes holdes under oppsikt og at hypoglykemi forebygges.</div><div class=\"paragraph\">Rådfør deg med lege, da amming kan kreve endring av kosthold og insulindosering.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\">Konsentrasjons- og reaksjonsevnen din kan nedsettes hvis:<ul><li>du har hypoglykemi (lavt blodsukkernivå)</li><li>du har hyperglykemi (høyt blodsukkernivå)</li><li>du har synsproblemer.</li></ul></div><div class=\"paragraph\">Husk alltid på risikoen for dette i alle situasjoner der du kan utsette deg selv eller andre for fare (for eksempel ved bilkjøring eller bruk av maskiner). Du skal diskutere med legen din om bilkjøring er tilrådelig hvis:<ul><li>du ofte har episoder med hypoglykemi,</li><li>de første varselssymptomer som hjelper deg å gjenkjenne hypoglykemi er svekket eller mangler.</li></ul></div></div>"
            }
          },
          {
            "title" : "Viktige opplysninger om noen av innholdsstoffene i Lantus",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Viktige opplysninger om noen av innholdsstoffene i Lantus</h3><div class=\"paragraph\">Dette legemidlet inneholder mindre enn 1 mmol (23 mg) natrium per dose, dvs. i praksis natriumfritt.</div></div>"
            }
          }]
        },
        {
          "title" : "3. Hvordan du bruker Lantus",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>3. Hvordan du bruker Lantus</h2><div class=\"paragraph\">Bruk alltid dette legemidlet nøyaktig slik legen din har fortalt deg. Kontakt lege eller apotek hvis du er usikker.</div><div class=\"paragraph\">Selv om Lantus inneholder det samme virkestoffet som Toujeo (insulin glargin 300 enheter/ml) er disse legemidlene ikke byttbare. Overgangen fra en insulinbehandling til en annen krever forskrivning og oppfølging fra lege og blodsukkerovervåkning. Rådfør deg med lege for mere informasjon.</div><span class=\"inline-title\">Dose</span><div class=\"paragraph\">Med utgangspunkt i din livsstil og resultatet av blodsukkermålingene dine, kommer legen din til å:<ul><li>avgjøre hvor mye Lantus du trenger daglig, og til hvilket tidspunkt,</li><li>fortelle deg når du skal kontrollere blodsukkernivået, og om du må ta urinprøver,</li><li>fortelle deg når det kan være nødvendig å ta en større eller mindre dose Lantus.</li></ul></div><div class=\"paragraph\">Lantus er et langtidsvirkende insulin. Legen din kan forskrive det i kombinasjon med et korttidsvirkende insulin eller med tabletter for behandling av høye blodsukkernivåer.</div><div class=\"paragraph\">Det er mange faktorer som kan påvirke blodsukkernivået. Disse faktorene må du kjenne til for å kunne handle korrekt ved endringer i blodsukkernivået og for å forhindre at det blir for høyt eller for lavt. Du finner ytterligere opplysninger i slutten av dette pakningsvedlegget.</div><span class=\"inline-title\">Bruk av Lantus hos barn og ungdom</span><div class=\"paragraph\">Lantus kan brukes av ungdom og barn fra 2 år og oppover. Bruk dette legemidlet nøyaktig slik legen din har fortalt deg.</div><span class=\"inline-title\">Når skal Lantus injiseres</span><div class=\"paragraph\">Du trenger én injeksjon med Lantus i døgnet. Denne tas til et fast tidspunkt.</div><span class=\"inline-title\">Hvordan skal Lantus injiseres</span><div class=\"paragraph\">Lantus injiseres under huden. Du må ALDRI injisere Lantus i en blodåre, da dette gir en annen effekt og kan forårsake hypoglykemi.</div><div class=\"paragraph\">Legen forteller deg i hvilket hudområde du skal injisere Lantus. Bytt injeksjonssted hver gang innenfor det valgte hudområdet.</div><span class=\"inline-title\">Håndtering av sylinderampullene</span><div class=\"paragraph\">Lantus i sylinderampuller er kun tilpasset injeksjon like under huden ved bruk av en flergangspenn. Rådfør deg med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.<br/>For å sikre at du får riktig dose skal Lantus sylinderampuller kun brukes sammen med følgende penner:<ul><li>JuniorSTAR, som leverer doser i trinn på 0,5 enheter</li><li>ClikSTAR, Tactipen, Autopen 24, AllStar eller AllStar PRO, som leverer doser i trinn på 1 enhet. Ikke alle disse pennene er nødvendigvis markedsført i Norge.</li></ul></div><div class=\"paragraph\">Pennen skal brukes som forklart i bruksanvisningen som følger med pennen.<br/>Følg denne bruksanvisningen nøye ved innsetting av insulinampulle, påsetting av injeksjonskanyle og injeksjon av insulinet.</div><div class=\"paragraph\">Oppbevar sylinderampullen i romtemperatur i 1 til 2 timer før du setter den i pennen.</div><div class=\"paragraph\">Kontroller sylinderampullen før bruk. Du kan bare bruke klare, fargeløse oppløsninger med vannlignende konsistens og uten synlige partikler.</div><div class=\"paragraph\">Ikke ryst eller bland den før bruk.<br/>Bytt alltid til en ny sylinderampulle hvis du merker at kontrollen med blodsukkeret uventet holder på å bli dårligere. Dette er fordi insulinet kan ha mistet noe av effekten. Hvis du tror det kan være problemer med Lantus, bør du få det kontrollert hos lege eller på apotek.</div><span class=\"inline-title\">Vær spesielt oppmerksom på følgende før injeksjon</span><div class=\"paragraph\">Evt. luftbobler må fjernes før injeksjon. Det er viktig å forsikre seg om at insulinet ikke forurenses av alkohol, andre desinfeksjonsmidler eller andre stoffer. Ikke fyll sylinderampullene for gjenbruk. Andre former for insulin må ikke tilsettes sylinderampullen. Ikke bland Lantus med noen andre former for insulin eller legemidler. Lantus skal ikke fortynnes, da blanding eller fortynning kan endre effekten.</div><span class=\"inline-title\">Problemer med insulinpennen?</span> <span class=\"inline-title\">Les bruksanvisningen som følger med pennen.</span><div class=\"paragraph\"><b><span class=\"underline\">Hvis insulinpennen er ødelagt eller ikke virker som den skal (pga. mekanisk feil), må den kastes</span> </b><b><span class=\"underline\">og en ny insulinpenn må benyttes.</span></b></div><span class=\"inline-title\">Forveksling av insulintyper</span><div class=\"paragraph\">Du må alltid kontrollere insulinetiketten før hver injeksjon, for å unngå å forveksle Lantus med andre typer insuliner.</div></div>"
          },
          "section" : [{
            "title" : "Dersom du tar for mye av Lantus",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029907"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du tar for mye av Lantus</h3><div class=\"paragraph\"><ul><li>Hvis du <b>har injisert for mye Lantus</b>, kan blodsukkernivået bli for lavt (hypoglykemi).<br/>Kontroller blodsukkeret ofte. Hvis du spiser mer mat og kontrollerer blodsukkeret, kan du vanligvis forebygge utvikling av hypoglykemi. Du finner informasjon om behandling av hypoglykemi i rammen ved slutten av dette pakningsvedlegget.</li></ul></div></div>"
            }
          },
          {
            "title" : "Dersom du har glemt å ta Lantus",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029908"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du har glemt å ta Lantus</h3><div class=\"paragraph\"><ul><li>Hvis du har <b>glemt en dose med Lantus </b>eller <b>ikke injisert nok insulin</b>, kan blodsukkernivået bli for høyt (hyperglykemi). Kontroller blodsukkeret ofte. Du finner informasjon om behandling av hyperglykemi i rammen ved slutten av dette pakningsvedlegget.</li><li>Du må ikke ta en dobbelt dose som erstatning for en glemt dose.</li></ul></div></div>"
            }
          },
          {
            "title" : "Dersom du avbryter behandling med Lantus",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029909"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du avbryter behandling med Lantus</h3><div class=\"paragraph\">Dette kan føre til alvorlig hyperglykemi (veldig høyt blodsukker) og ketoacidose (opphoping av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Du må ikke avbryte behandling med Lantus uten at du snakker med en lege, som vil fortelle deg hva som må gjøres.</div><div class=\"paragraph\">Spør lege, apotek eller sykepleier dersom du har noen spørsmål om bruken av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "4. Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>4. Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.</div><div class=\"paragraph\"><b>Hvis du oppdager tegn på at blodsukkernivået ditt er for lavt (hypoglykemi) </b>må du gjøre noe for å øke blodsukkernivået umiddelbart (se tekstboksen på slutten av dette pakningsvedlegget).<br/>Hypoglykemi (lavt blodsukker) kan være svært alvorlig og er svært vanlig ved insulinbehandling (kan oppstå hos flere enn 1 av 10 personer). Lavt blodsukker betyr at det ikke er nok sukker i blodet ditt.<br/>Hvis ditt blodsukkernivå faller for lavt kan du besvime (miste bevisstheten). Alvorlig hypoglykemi kan forårsake hjerneskade og være livstruende. For mer informasjon, se tekstboksen på slutten av dette pakningsvedlegget.</div><div class=\"paragraph\"><b>Alvorlige allergiske reaksjoner </b>(sjeldne, kan oppstå hos inntil 1 av 1000 personer) – tegn kan være omfattende hudreaksjoner (utslett og kløe over hele kroppen), kraftig hevelse av huden eller slimhinne (angioødem), kortpustethet, blodtrykksfall med rask puls eller svetting. Alvorlige allergiske reaksjoner på insuliner kan bli livstruende. Ta øyeblikkelig kontakt med lege dersom du merker tegn på en alvorlig allergisk reaksjon.</div><div class=\"paragraph\"><ul><li><b>Hudforandringer på injeksjonsstedet:</b></li></ul>Hvis du injiserer insulin for ofte på samme sted, kan huden på dette stedet enten skrumpe inn (lipoatrofi) (kan oppstå hos 1 av 100 personer) eller fortykkes (lipohypertrofi) (kan oppstå hos 1 av 10 personer). Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.</div><div class=\"paragraph\"><b>Vanlig rapporterte bivirkninger </b>(kan oppstå hos inntil 1 av 10 personer)</div><div class=\"paragraph\"><ul><li><b>Hud og allergiske reaksjoner på injeksjonsstedet</b></li></ul>Tegn kan være rødme, uvanlig intens smerte ved injeksjon, kløe, utslett, hevelse eller betennelse. Dette kan spre seg til området rundt injeksjonsstedet. De fleste milde insulinreaksjoner forsvinner vanligvis i løpet av et par dager til et par uker.</div><div class=\"paragraph\"><b>Sjeldne rapporterte bivirkninger </b>(kan oppstå hos inntil 1 av 1000 personer)<ul><li><b>Påvirkning av synet</b></li></ul>En merkbar forandring (forbedring eller forverring) i kontrollen av blodsukkeret ditt kan forbigående forstyrre synet ditt. Hvis du har proliferativ retinopati (en øyesykdom relatert til diabetes), kan alvorlige hypoglykemier forårsake forbigående synstap.</div><div class=\"paragraph\"><ul><li><b>Generelle bivirkninger</b></li></ul>I sjeldne tilfeller kan insulinbehandling også gi forbigående vannansamlinger i kroppen, med hevelse i legger og ankler.</div><div class=\"paragraph\"><b>Svært sjeldent rapporterte bivirkninger (</b>kan oppstå hos inntil 1 av 10 000 personer)<br/>I svært sjeldne tilfeller kan dysgeusi (smaksforandringer) og myalgi (muskelsmerter) oppstå.</div><span class=\"inline-title\">Bivirkninger som kan forekomme hos barn og ungdom</span><div class=\"paragraph\">Generelt er bivirkningene for barn og ungdom som er 18 år eller yngre lignende de som er sett hos voksne. Klager på reaksjoner på injeksjonsstedet (smerte ved injeksjonsstedet, reaksjoner ved injeksjonsstedet) og hudreaksjoner (utslett, elveblest) er rapportert releativt oftere hos barn og ungdom som er 18 år eller yngre i forhold til voksne.<br/>Det er ikke erfaring med bruk hos barn under 2 år.</div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger. Dette gjelder også bivirkninger som ikke er nevnt i pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "5. Hvordan du oppbevarer Lantus",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>5. Hvordan du oppbevarer Lantus</h2><div class=\"paragraph\">Oppbevares utilgjengelig for barn.</div><div class=\"paragraph\">Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken og på etiketten på sylinderampullen etter ”EXP”. Utløpsdatoen henviser til den siste dagen i den måneden.</div><div class=\"paragraph\"><span class=\"underline\">Uåpnete sylinderampuller</span><br/>Oppbevares i kjøleskap (2-8ºC). Skal ikke fryses, eller plasseres ved fryseboks eller fryseelementer. Oppbevar sylinderampullen i ytteremballasjen for å beskytte mot lys.</div><div class=\"paragraph\"><span class=\"underline\">Sylinderampuller i bruk</span><br/>Sylinderampuller som er i bruk (i insulinpennen) eller tatt med som reserve, kan oppbevares i inntil 4 uker ved høyst 30ºC beskyttet fra direkte varme og lys. Sylinderampuller som er i bruk må ikke oppbevares i kjøleskap. Etter denne tiden må sylinderampullen ikke brukes.</div><div class=\"paragraph\">Bruk ikke Lantus hvis du ser partikler i oppløsningen. Du må bare bruke Lantus hvis oppløsningen er klar, fargeløs, med vannlignende konsistens.</div><div class=\"paragraph\">Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan legemidler som du ikke lenger bruker skal kastes. Disse tiltakene bidrar til å beskytte miljøet.</div></div>"
          }
        },
        {
          "title" : "6. Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>6. Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av Lantus",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av Lantus</h3><div class=\"paragraph\"><ul><li>Virkestoff er insulin glargin. En ml injeksjonsvæske inneholder 100 enheter med insulin glargin (tilsvarende 3,64 mg).</li><li>Andre innholdsstoffer er sinkklorid, metakresol, glyserol, natriumhydroksid(se avsnitt 2 under ”Viktige opplysninger om noen av innholdsstoffene i Lantus”) og saltsyre (til pH-justering) og vann til injeksjon.</li></ul></div></div>"
            }
          },
          {
            "title" : "Hvordan Lantus ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan Lantus ser ut og innholdet i pakningen</h3><div class=\"paragraph\">Lantus 100 enheter/ml injeksjonsvæske, oppløsning sylinderampuller er en klar og fargeløs oppløsning.</div><div class=\"paragraph\">Lantus leveres i en egen sylinderampulle kun for bruk i pennene ClikSTAR, Tactipen, Autopen 24, AllStar, AllStar PRO eller JuniorSTAR. Hver sylinderampulle inneholder 3 ml injeksjonsvæske, oppløsning (tilsvarende 300 enheter).</div><div class=\"paragraph\">Pakningsstørrelser på 1, 3, 4, 5, 6, 8, 9 og 10 sylinderampuller. Ikke alle pakningsstørrelser vil nødvendigvis bli markedsført.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen og tilvirker",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen og tilvirker</h3><div class=\"paragraph\">Sanofi-Aventis Deutschland GmbH, D-65926 Frankfurt am Main, Tyskland.</div><div class=\"paragraph\">For ytterligere informasjon om dette legemidlet bes henvendelser rettet til den lokale representant for innehaveren av markedsføringstillatelsen:</div><div class=\"paragraph\">sanofi-aventis Norge AS Tlf: +47 67 10 71 00</div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 24.11.2021",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 24.11.2021</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre informasjonskilder</h3><div class=\"paragraph\">Detaljert informasjon om dette legemidlet er tilgjengelig på nettstedet til Det europeiske legemiddelkontoret (The European Medicines Agency) <a href=\"http://www.ema.europa.eu/\" title=\"http://www.ema.europa.eu/\">http://www.ema.europa.eu/</a>, og på nettstedet til <a href=\"http://www.felleskatalogen.no\" title=\"\n               \n                  www.felleskatalogen.no\n               \n            \">www.felleskatalogen.no</a></div></div>"
            }
          },
          {
            "title" : "HYPERGLYKEMI OG HYPOGLYKEMI",
            "code" : {
              "coding" : [{
                "system" : "https://gravitatehealth.eu/section",
                "code" : "patient-info"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3><b>HYPERGLYKEMI OG HYPOGLYKEMI</b></h3><span class=\"inline-title\">Ha alltid med deg minst 20 gram sukker.</span><div class=\"paragraph\"><b>Ha med deg informasjon som viser at du er diabetiker.</b></div><span class=\"inline-title\">HYPERGLYKEMI (for høyt blodsukkernivå)</span><div class=\"paragraph\"><b>Hvis blodsukkeret ditt er for høyt (hyperglykemi) kan du ha injisert for lite insulin Hvorfor oppstår hyperglykemi?</b><br/>For eksempel hvis:<ul><li>insulinet ikke er injisert, utilstrekkelig mengde er injisert eller hvis insulinet har mistet effekten ved for eksempel feil oppbevaring,</li><li>Insulinpennen din virker ikke som den skal</li><li>du får mindre mosjon enn vanlig, er stresset (bekymringer, opphisselse), eller er skadet, gjennomgår en operasjon, har infeksjon eller feber,</li><li>du tar eller har tatt enkelte andre legemidler (se avsnitt 2, ” Andre legemidler og Lantus”).</li></ul></div><span class=\"inline-title\">Varselsymptomene ved hyperglykemi</span><div class=\"paragraph\">Tørste, økt behov for å late vannet, tretthet, tørr hud, ansiktsrødme, dårlig appetitt, lavt blodtrykk, hjertebank, og glukose og ketonlegemer i urinen. Magesmerter, rask og dyp innånding, søvnighet og eventuelt bevisstløshet kan være tegn på en alvorlig tilstand (ketoacidose) som er en følge av mangel på insulin.</div><span class=\"inline-title\">Hva skal du gjøre hvis du får hyperglykemi?</span><div class=\"paragraph\">Kontroller blodsukkernivået og ketoner i urinen så snart symptomer som beskrevet over oppstår. Alvorlig hyperglykemi eller ketoacidose må alltid behandles av lege, vanligvis på sykehus.</div><span class=\"inline-title\">HYPOGLYKEMI (for lavt blodsukkernivå)</span><div class=\"paragraph\">Hvis ditt blodsukkernivå faller for mye kan du miste bevisstheten. Alvorlig hypoglykemi kan forårsake hjerteinfarkt eller hjerneskade og kan være livstruende. Vanligvis bør du være i stand til å merke at blodsukkernivået ditt faller for mye, slik at du kan iverksette nødvendige tiltak.</div><span class=\"inline-title\">Hvorfor oppstår hypoglykemi?</span><div class=\"paragraph\">For eksempel hvis:<ul><li>du injiserer for mye insulin,</li><li>du utelater eller utsetter måltider,</li><li>du ikke spiser nok eller spiser mat med mindre karbohydrater enn vanlig (sukker og stoffer som ligner sukker kalles karbohydrater, mens kunstige søtstoffer IKKE er karbohydrater),</li><li>du taper karbohydrater på grunn av oppkast eller diaré,</li><li>du drikker alkohol, særlig hvis du spiser lite,</li><li>du får mer mosjon enn normalt eller utfører andre former for fysisk aktivitet enn vanlig,</li><li>du er i ferd med å komme deg etter en skade, operasjon eller annen belastning,</li><li>du er i ferd med å komme deg etter en sykdom eller feber,</li><li>du tar eller har sluttet å ta enkelte andre medisiner (se avsnitt 2, ” Andre legemidler og Lantus”).</li></ul></div><span class=\"inline-title\">Det er også større risiko for å få hypoglykemi hvis:</span><div class=\"paragraph\"><ul><li>du nettopp har begynt med insulinbehandling eller har byttet til et annet insulinpreparat (hypoglykemi kan oppstå når du bytter fra ditt tidligere basalinsulin til Lantus, dersom det skjer så er det mer sannsynlig at det oppstår om morgenen enn om natten),</li><li>blodsukkernivået ditt er nesten normalt eller ustabilt,</li><li>du bytter injeksjonsområde (for eksempel fra lår til overarm),</li><li>du lider av alvorlig nyre- eller leversykdom eller av enkelte andre sykdommer, som for eksempel hypotyreoidisme.</li></ul></div><span class=\"inline-title\">Varselsymptomene ved hypoglykemi</span><div class=\"paragraph\"><ul><li>I kroppen din</li></ul>Eksempler på symptomer på at blodsukkeret faller for mye eller for raskt: svette, klam hud, angst, rask puls, høyt blodtrykk, hjertebank og uregelmessig hjerterytme. Slike symptomer forekommer ofte før symptomene på lavt sukkernivå i hjernen.</div><div class=\"paragraph\"><ul><li>I hjernen din</li></ul>Eksempler på symptomer på at det er for lavt sukkernivå i hjernen: hodepine, intens sult, kvalme, oppkast, tretthet, søvnighet, søvnforstyrrelser, rastløshet, aggressivitet, konsentrasjonsvansker, nedsatt reaksjonsevne, depresjon, forvirring, taleforstyrrelser (iblant fullstendig tap av taleevnen), synsforstyrrelser, skjelvinger, lammelser, prikking (parestesi), nummenhet og prikking i området rundt munnen, svimmelhet, manglende selvbeherskelse, hjelpeløshet, kramper og bevisstløshet.</div><div class=\"paragraph\">De første symptomene på at hypoglykemi er i ferd med å oppstå (”varselssymptomer”) kan forandres, bli svakere eller utebli helt hvis du:<ul><li>er eldre,</li><li>har hatt diabetes lenge,</li><li>lider av en spesiell type nervesykdom (diabetisk autonom neuropati),</li><li>nylig har hatt hypoglykemi (for eksempel dagen før) eller hypoglykemien utvikles langsomt,</li><li>har betydelig forbedrede eller nesten normale blodsukkernivåer,</li><li>tar eller har tatt visse andre legemidler (se avsnitt 2, ” Andre legemidler og Lantus”).</li></ul></div><div class=\"paragraph\">I slike tilfelle risikerer du å utvikle alvorlig hypoglykemi (og t.o.m. besvime) før du selv blir klar over problemet. Vær oppmerksom på dine varselssymptomer. Hyppigere blodsukkerprøver kan bidra til å identifisere milde hypoglykemiske episoder som du ellers ville oversett. Hvis du ikke er sikker på at du kjenner igjen varselssymptomene dine, må du unngå situasjoner der du eller andre kan utsettes for risiko på grunn av hypoglykemi (for eksempel bilkjøring).</div><span class=\"inline-title\">Hva skal du gjøre hvis du får hypoglykemi</span><div class=\"paragraph\"><ul><li>Ikke injiser insulin. Spis umiddelbart 10 til 20 g sukker, for eksempel glukose, sukkerbiter eller drikk en sukkerholdig drikk. NB! Kunstige søtningsmidler og mat med kunstige søtningsmidler (for eksempel lett-drikker) har ingen effekt ved behandling av hypoglykemi.</li><li>Deretter spiser du noe som har en langvarig blodsukkerhevende effekt (for eksempel brød eller pasta). Dette skal legen eller sykepleieren din ha gjennomgått med deg tidligere.</li><li>Dersom du får hypoglykemi igjen, innta ytterligere 10 til 20 g sukker.</li><li>Kontakt lege straks hvis du ikke klarer å kontrollere hypoglykemien, eller hvis tilstanden oppstår på nytt.</li></ul></div><div class=\"paragraph\">Fortell dine slektninger, venner og nære kollegaer følgende:<br/>Hvis du ikke er i stand til å svelge, eller hvis du er bevisstløs, må du få en injeksjon med glukose eller glukagon (et legemiddel som hever blodsukkernivået). Det er trygt å få disse injeksjonene også om det ikke er sikkert at du har hypoglykemi.</div><div class=\"paragraph\">Vi anbefaler at du kontrollerer blodsukkeret umiddelbart etter inntak av glukosen, for å kontrollere om du virkelig har hypoglykemi.</div></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-64",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-64",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-64\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-64</b></p><a name=\"Diabetes-MPD-64\"> </a><a name=\"hcDiabetes-MPD-64\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_1536BD37-E67E-40E3-A88A-F7A2404F63CF</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Lantus inj, oppl 100 E/ml</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_1536BD37-E67E-40E3-A88A-F7A2404F63CF"
      }],
      "name" : [{
        "productName" : "Lantus inj, oppl 100 E/ml"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-78",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-78",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-78\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-78</b></p><a name=\"Diabetes-PPD-78\"> </a><a name=\"hcDiabetes-PPD-78\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_F5DDF232-DC47-48FA-82BD-9156E6A7FBDA, <code>https://farmalogg.no/varenummer</code>/004746</p><p><b>name</b>: Lantus inj, oppl 100 E/ml</p><p><b>packageFor</b>: <a href=\"Bundle-FK567097.html#MedicinalProductDefinition_Diabetes-MPD-64\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_1536BD37-E67E-40E3-A88A-F7A2404F63CF</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_F5DDF232-DC47-48FA-82BD-9156E6A7FBDA"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "004746"
      }],
      "name" : "Lantus inj, oppl 100 E/ml",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-64"
      }]
    }
  }]
}

```
