# ePI document Bundle for MIRTAZAPINA CINFA 30 mg Coated Tablet Package Leaflet for language es - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for MIRTAZAPINA CINFA 30 mg Coated Tablet Package Leaflet for language es**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Coated tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** LACTOSE MONOHYDRATE ** 

Ingredient

 Role: ** active ** 

 Substance: ** Mirtazapine ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** HYDROXYPROPYL CELLULOSE, UNSPECIFIED ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** SILICA, COLLOIDAL ANHYDROUS ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** CORN STARCH ** 

## Example Bundle: ePI document Bundle for MIRTAZAPINA CINFA 30 mg Coated Tablet Package Leaflet for language es

**Composition category:**processed

**Composition status:**final

### B. PROSPECTO

 

unavailable


#### PROSPECTO: INFORMACIÓN PARA EL USUARIO

 

**Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.**

* Conserve este prospecto, ya que puede tener que volver a leerlo.
* Si tiene alguna duda, consulte a su médico o farmacéutico.
* Este medicamento se le ha recetado solamente a usted, y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.
* Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver sección 4.


#### Contenido del prospecto

 

Contenido del prospecto

1. Qué es mirtazapina cinfa y para qué se utiliza
1. Qué necesita saber antes de empezar a tomar mirtazapina cinfa
1. Cómo tomar mirtazapina cinfa
1. Posibles efectos adversos
1. Conservación de mirtazapina cinfa
1. Contenido del envase e información adicional


#### 1. Qué es MIRTAZAPINA CINFA y para qué se utiliza

 

mirtazapina cinfa pertenece al grupo de medicamentos llamados antidepresivos.

Mirtazapina se utiliza para tratar la depresión en adultos.

Se requieren de 1 a 2 semanas antes de que mirtazapina empiece a hacer efecto. Después de 2 a 4 semanas usted puede empezar a encontrarse mejor. Debe consultar a su médico si empeora o si no mejora después de 2 a 4 semanas.

Para más información ver la sección 3 "Cuándo puede esperar encontrarse mejor"


#### 2. Qué necesita saber antes de empezar a tomar MIRTAZAPINA CINFA

 

**No tome mirtazapina cinfa**

* si es alérgico a mirtazapina o a alguno de los demás componentes de este medicamento (incluidos en la sección 6). En ese caso, consulte a su médico lo antes posible antes de tomar mirtazapina.
* si está tomando o ha tomado recientemente (en las dos últimas semanas) medicamentos llamados inhibidores de la monoaminooxidasa (IMAO).

**Advertencias y precauciones** Consulte a su médico o farmacéutico antes de empezar a tomar mirtazapina cinfa

NO TOME O CONSULTE A SU MÉDICO ANTES DE EMPEZAR A TOMAR mirtazapina: Si ha sufrido alguna vez una erupción cutánea intensa o descamación de la piel, ampollas o llagas en la boca después de tomar mirtazapina u otros medicamentos.

**Niños y adolescentes**

Mirtazapina no debe utilizarse normalmente en el tratamiento de niños y adolescentes menores de 18 años porque no se demostró su eficacia. A la vez, debe saber que en pacientes menores de 18 años existe un mayor riesgo de efectos adversos como intentos de suicidio, ideación suicida y hostilidad (predominantemente agresión, comportamiento de confrontación e irritación) cuando toman esta clase de medicamentos. Pese a ello, el médico puede prescribir mirtazapina a pacientes menores de 18 años cuando decida que es lo más conveniente para el paciente. Si el médico ha prescrito mirtazapina a un paciente menor de 18 años y desea discutir esta decisión, por favor, vuelva a su médico. Debe informar a su médico si aparecen o empeoran alguno de los síntomas que se detallan anteriormente en pacientes menores de 18 años que están tomando mirtazapina. Además, todavía no se conocen los efectos sobre la seguridad a largo plazo relacionados con el crecimiento, la madurez y el desarrollo del conocimiento y la conducta de mirtazapina en este grupo de edad. También se ha observado con mayor frecuencia un considerable aumento de peso en este grupo de edad cuando son tratados con mirtazapina, en comparación con los adultos.

**Ideas de suicidio y empeoramiento de la depresión**

Si se encuentra deprimido puede que a veces tenga ideas de hacerse daño a si mismo o de suicidarse. Esto podría empeorar cuando empieza a tomar los antidepresivos por primera vez, ya que estos medicamentos tardan en hacer efecto normalmente dos semanas o a veces más. Podría ser más propenso a pensar de esta manera:

* si previamente ha tenido pensamientos suicidas o de hacerse daño a si mismo.
* si es un adulto joven. La información de los ensayos clínicos ha mostrado un riesgo aumentado de comportamiento suicida en adultos menores de 25 años con trastornos psiquiátricos y que estaban en tratamiento con un antidepresivo.
* si tiene pensamiento de hacerse daño a si mismo o suicidarse en algún momento, consulte a su médico o vaya a un hospital inmediatamente.

Puede ser útil decirle a un pariente o amigo cercano que se encuentra deprimido, y pedirle que lea este prospecto. Puede pedirle que le diga si cree que su depresión está empeorando, o si está preocupado por cambios en su comportamiento.

Asimismo, tenga especial cuidado con mirtazapina:

* si tiene o ha tenido alguna vez uno de los siguientes trastornos
* Informe a su médico sobre estas situaciones antes de tomar mirtazapina, si no lo ha hecho ya:
* convulsiones (epilepsia). Si aparecen convulsiones o sus convulsiones son más frecuentes, deje de tomar mirtazapina y contacte con su médico inmediatamente;
* enfermedades del hígado, incluyendo ictericia. Si aparece ictericia, deje de tomar mirtazapina y contacte con su médico inmediatamente;
* enfermedades de los riñones;
* enfermedad del corazón o presión arterial baja;
* esquizofrenia. Si los síntomas psicóticos, como los pensamientos paranoicos, son más frecuentes o graves contacte con su médico inmediatamente;
* depresión bipolar (se alternan períodos de animación/hiperactividad y períodos de depresión). Si empieza a sentirse animado o sobreexcitado, deje de tomar mirtazapina y contacte con su médico inmediatamente;
* diabetes (podría necesitar ajustar su dosis de insulina u otros medicamentos antidiabéticos);
* enfermedades de los ojos, como aumento de la presión en el ojo (glaucoma);
* dificultades para orinar, que podrían deberse a un aumento del tamaño de la próstata;
* ciertos tipos de enfermedades del corazón que pueden cambiar el ritmo de su corazón, un ataque reciente al corazón, un fallo del corazón, o toma de ciertos medicamentos que pueden afectar el ritmo del corazón.

* si aparecen signos de infección como fiebre alta inexplicable, dolor de garganta y llagas en la boca Deje de tomar mirtazapina y contacte con su médico inmediatamente para realizar un análisis de sangre. En raras ocasiones, estos síntomas pueden ser signos de alteraciones en la producción de células sanguíneas en la médula ósea. Aunque raros, estos síntomas aparecen a las 4-6 semanas de tratamiento.
* si es una persona mayor podría ser más sensible a los efectos adversos de los medicamentos antidepresivos.
* se han notificado con el uso de mirtazapina reacciones cutáneas graves, como síndrome de StevensJohnson (SSJ), necrólisis epidérmica tóxica (NET) y reacción medicamentosa con eosinofilia y síntomas sistémicos (DRESS). Interrumpa su uso y busque atención médica inmediatamente si nota alguno de los síntomas descritos en la sección 4 en relación con estas reacciones cutáneas graves. Si ha sufrido alguna vez reacciones cutáneas graves, no debe reiniciarse el tratamiento con mirtazapina.

**Otros medicamentos y mirtazapina cinfa**

Informe a su médico o farmacéutico si está tomando, ha tomado recientemente o pudiera tener que tomar cualquier otro medicamento.

No tome mirtazapina junto con:

* inhibidores de la monoamino oxidasa (inhibidores de la MAO). Asimismo, no tome mirtazapina durante las dos semanas después de haber dejado de tomar los inhibidores de la MAO. Si deja de tomar mirtazapina, tampoco tome inhibidores de la MAO durante las siguientes dos semanas. Ejemplos de inhibidores de la MAO son moclobemida, tranilcipromina (ambos son antidepresivos) y selegilina (para la enfermedad de Parkinson).

Tenga cuidado si toma mirtazapina junto con:

* antidepresivos como los inhibidores selectivos de la recaptación de serotonina (ISRSs), venlafaxina y L-triptófano o triptanos (utilizados para tratar la migraña), tramadol (para el dolor), linezolid (un antibiótico), litio (utilizado para tratar algunos trastornos psiquiátricos), azul de metileno (utilizado para tratar niveles altos de metahemoglobina en la sangre) y preparados a base de Hierba de San Juan – Hypericum perforatum (planta medicinal para la depresión). En casos muy raros, mirtazapina solo o junto con estos medicamentos, puede dar lugar al llamado síndrome serotoninérgico. Algunos de los síntomas de este síndrome son: fiebre inexplicable, sudoración, palpitaciones, diarrea, contracciones musculares (incontrolables), escalofríos, reflejos exagerados, agitación, cambios de humor y pérdida de conciencia. Si presenta una combinación de estos síntomas, consulte a su médico inmediatamente.
* el antidepresivo nefazodona. Puede aumentar la cantidad de mirtazapina en sangre. Informe a su médico si está tomando este medicamento. Podría ser necesario disminuir la dosis de mirtazapina, o aumentarla nuevamente al dejar de tomar nefazodona.
* medicamentos para la ansiedad o el insomnio como las benzodiazepinas. medicamentos para la esquizofrenia como la olanzapina. medicamentos para las alergias como la cetirizina. medicamentos para el dolor intenso como la morfina. En combinación con estos medicamentos, mirtazapina puede aumentar la somnolencia causada por estos medicamentos.
* medicamentos para infecciones: medicamentos para infecciones bacterianas (como la eritromicina), medicamentos para infecciones por hongos (como el ketoconazol) y los medicamentos para el VIH/SIDA (inhibidores de la proteasa del VIH) y medicamentos para la úlcera de estómago (como la cimetidina). Si se toman junto con mirtazapina, estos medicamentos pueden aumentar la cantidad de mirtazapina en sangre. Informe a su médico si está tomando estos medicamentos. Podría ser necesario disminuir la dosis de mirtazapina, o aumentarla nuevamente al dejar de tomar estos medicamentos.
* medicamentos para la epilepsia: como la carbamazepina y la fenitoína.
* medicamentos para la tuberculosis como la rifampicina. Si se toman junto con mirtazapina, estos medicamentos pueden reducir la cantidad de mirtazapina en sangre. Informe a su médico si está tomando estos medicamentos. Podría ser necesario aumentar la dosis de mirtazapina, o disminuirla nuevamente al dejar de tomar estos medicamentos. medicamentos para prevenir la coagulación de la sangre como la warfarina. Mirtazapina puede aumentar los efectos de la warfarina en la sangre. Informe a su médico si está tomando este medicamento. En caso de tomarlos a la vez, se recomienda que el médico le haga controles en sangre.
* medicamentos que pueden afectar el ritmo del corazón, como ciertos antibióticos y algunos antipsicóticos

**Toma de mirtazapina cinfa con alimentos y alcohol**

Puede sentirse somnoliento si bebe alcohol mientras esté en tratamiento con mirtazapina. Se recomienda no beber nada de alcohol. Puede tomar mirtazapina con o sin alimentos.

**Embarazo y lactancia**

Si está embarazada o en periodo de lactancia, cree que podría estar embarazada o tiene intención de quedarse embarazada, consulte a su médico o farmacéutico antes de utilizar este medicamento.

La experiencia limitada de la administración de mirtazapina a mujeres embarazadas no indica un aumento de riesgo. Sin embargo, debe tenerse cuidado si se usa durante el embarazo.

Si usa mirtazapina hasta, o poco antes del parto, su hijo será examinado para detectar posibles efectos adversos.

class="pregnancyCategory"Tomados durante el embarazo, los medicamentos similares (ISRS) pueden aumentar en los bebés el riesgo de padecer una enfermedad grave denominada hipertensión pulmonar persistente neonatal (HPPN), ocasionando que el bebé respire más rápido y adquiera un tono azulado. Estos síntomas comienzan normalmente durante las primeras 24 horas después de que nazca el bebé. Si esto le sucede al bebé, debe consultar a su matrona o médico de inmediato.

**Conducción y uso de máquinas**

Durante el tratamiento con mirtazapina puede que se sienta somnoliento o mareado. No conduzca ni maneje herramientas o máquinas hasta que sepa cómo le afecta el tratamiento con mirtazapina.

**mirtazapina cinfa contiene lactosa.**

Este medicamento contiene lactosa. Si su médico le ha indicado que padece una intolerancia a ciertos azúcares, consulte con él antes de tomar este medicamento.


#### 3. Cómo tomar MIRTAZAPINA CINFA

 

Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico o farmacéutico. En caso de duda, consulte de nuevo a su médico o farmacéutico.

**Cuánto tomar**

La dosis inicial recomendada es de 15 o 30 mg al día. Su médico puede recomendarle aumentar la dosis tras unos días hasta la cantidad que sea mejor para usted (entre 15 y 45 mg al día). Normalmente la dosis es la misma para todas las edades. Sin embargo, si es una persona mayor o si padece una enfermedad del riñón o del hígado, su médico podría cambiar la dosis.

**Cuándo tomar mirtazapina**

Tome mirtazapina a la misma hora cada día. Es mejor tomar la dosis de mirtazapina de una sola vez antes de acostarse. Sin embargo, su médico puede recomendarle que divida su dosis de mirtazapina por la mañana y por la noche antes de acostarse. La dosis más alta debe tomarse antes de acostarse. Los comprimidos se toman por vía oral. Tome la dosis de mirtazapina recetada sin masticar, con agua o zumo.

**Cuándo puede esperar encontrarse mejor**

Normalmente mirtazapina empezará a hacer efecto después de 1 o 2 semanas y después de 2 a 4 semanas podría empezar a encontrarse mejor. Es importante que durante las primeras semanas de tratamiento hable con su médico sobre los efectos de mirtazapina: entre 2 y 4 semanas después de haber empezado a tomar mirtazapina, hable con su médico sobre cómo le ha afectado este medicamento. Si todavía no se encuentra mejor, su médico podría recetarle una dosis mayor. En ese caso, hable nuevamente con su médico después de otras 2-4 semanas. Normalmente necesitará tomar mirtazapina hasta que los síntomas de depresión hayan desaparecido durante 4-6 meses.

El comprimido se puede partir en dosis iguales.

**Si toma más mirtazapina cinfa del que debe**

En caso de sobredosis o ingestión accidental consulte inmediatamente a su médico o farmacéutico o llame al Servicio de Información Toxicológica, teléfono 91 562 04 20, indicando el medicamento y la cantidad ingerida. Se recomienda llevar el prospecto y el envase al profesional sanitario.

Los síntomas más probables de una sobredosis de mirtazapina (sin otros medicamentos o alcohol) son la somnolencia, desorientación y palpitaciones. Los síntomas de una posible sobredosis pueden incluir cambios en el ritmo de su corazón (latido rápido, irregular) y/o desfallecimiento, que podrían ser síntomas de una enfermedad potencialmente mortal conocida como Torsades de pointes.

**Si olvidó tomar mirtazapina cinfa**

Si tiene que tomar su dosis una vez al día

* No tome una dosis doble para compensar las dosis olvidadas. Tome la dosis habitual al día siguiente. Si tiene que tomar su dosis dos veces al día
* Si ha olvidado la dosis de la mañana, simplemente tómesela junto con la dosis de la noche.
* Si ha olvidado la dosis de la noche, no la tome a la mañana siguiente; sáltesela y continúe con sus dosis normales por la mañana y por la noche.
* Si ha olvidado ambas dosis, no intente recuperarlas. Sáltese ambas dosis y al día siguiente continúe con la dosis normal por la mañana y por la noche.

**Si interrumpe el tratamiento con mirtazapina cinfa**

Deje de tomar mirtazapina sólo si lo consulta con su médico. Si lo deja demasiado pronto, la depresión podría reaparecer. Cuando se encuentre mejor, hable con su médico. Su médico decidirá cuándo puede dejar el tratamiento. No deje de tomar mirtazapina bruscamente, aun cuando la depresión haya desaparecido. Si deja de tomar mirtazapina de forma brusca, puede sentirse enfermo, mareado, agitado o ansioso y tener dolores de cabeza. Estos síntomas pueden evitarse dejando el tratamiento gradualmente. Su médico le indicará cómo disminuir la dosis gradualmente.

Si tiene cualquier otra duda sobre el uso de este medicamento, pregunte a su médico o farmacéutico.


#### 4. Posibles efectos adversos

 

Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.

**Si experimenta alguno de los siguientes efectos adversos graves, deje de tomar mirtazapina e informe inmediatamente a su médico.**

Poco frecuentes (pueden afectar hasta 1 de cada 100 pacientes):

* sentimiento de euforia exagerada (manía).

Raros (pueden afectar hasta 1 de cada 1.000 pacientes):

* coloración amarilla de los ojos o la piel; puede sugerir alteraciones en el funcionamiento del hígado (ictericia).

Frecuencia no conocida (no puede estimarse a partir de los datos disponibles):

* signos de infección tales como fiebre alta inexplicable y repentina, dolor de garganta y llagas en la boca (agranulocitosis). En casos raros, mirtazapina puede provocar alteraciones en la producción de células sanguíneas (depresión de la médula ósea). Algunas personas se vuelven menos resistentes a las infecciones porque mirtazapina puede provocar una disminución temporal de los glóbulos blancos de la sangre (granulocitopenia). En casos raros, mirtazapina también puede provocar una disminución de los glóbulos rojos y blancos y de las plaquetas (anemia aplásica), una disminución de las plaquetas (trombocitopenia) o un aumento en el número de glóbulos blancos en sangre (eosinofilia).
* ataque epiléptico (convulsiones).
* combinación de síntomas como fiebre inexplicable, sudoración, palpitaciones, diarrea, contracciones musculares (incontrolables), escalofríos, reflejos exagerados, agitación, cambios de humor, pérdida de conciencia y aumento de la producción de saliva. En casos muy raros, estos síntomas pueden ser señales de un trastorno llamado “síndrome serotoninérgico”.
* pensamientos de hacerse daño a uno mismo o de suicidio.
* reacciones graves en la piel:
* parches rojos en el tronco, como máculas circunscritas o circulares, a menudo con ampollas en el centro, desprendimiento de la piel, úlceras en la boca, la garganta, la nariz, los genitales y los ojos. Estos eritemas cutáneos graves pueden ir precedidos de fiebre y síntomas gripales (síndrome de Stevens-Johnson, necrólisis epidérmica tóxica).
* eritema generalizado, temperatura corporal elevada y aumento de tamaño de los ganglios linfáticos (síndrome DRESS o síndrome de hipersensibilidad medicamentosa).

**Otros posibles efectos adversos con mirtazapina son:**

Muy frecuentes (pueden afectar a más de 1 de cada 10 pacientes)

* aumento del apetito y aumento de peso
* somnolencia
* dolor de cabeza
* boca seca

Frecuentes (pueden afectar hasta 1 de cada 10 pacientes)

* letargia
* mareo
* temblor
* náuseas
* diarrea
* vómitos
* estreñimiento
* urticaria o erupciones en la piel (exantema)
* dolores en las articulaciones (artralgia) o músculos (mialgia)
* dolor de espalda
* mareo o desmayo al levantarse rápidamente (hipotensión ortrtostática)
* hinchazón (normalmente en tobillos o pies) debido a retención de líquidos (edema)
* cansancio
* sueños vívidos
* confusión
* ansiedad
* dificultades para dormir
* problemas de memoria, que en la mayoría de los casos se resolvieron cuando se suspendió el tratamiento

Poco frecuentes (pueden afectar hasta 1 de cada 100 pacientes)

* sensación extraña en la piel por ejemplo quemazón, pinchazos, cosquilleo u hormigueo (parestesia)
* movimientos involuntarios de agitación de las piernas durante el sueño
* desmayos (síncope)
* sensación de adormecimiento de la boca (hipoestesia oral)
* tensión baja
* pesadillas
* agitación
* alucinaciones
* incapacidad para mantenerse quieto

Raros (pueden afectar hasta 1 de cada 1.000 pacientes)

* tics o contracciones musculares (mioclono)
* agresión
* dolor abdominal, náuseas; esto puede indicar inflamación del páncreas (pancreatitis)

Frecuencia no conocida (no puede estimarse a partir de los datos disponibles)

* sensaciones anormales en la boca (parestesia oral)
* hinchazón en la boca (edema bucal)
* hinchazón por todo el cuerpo (edema generalizado)
* hinchazón localizada
* hiponatremia
* secreción inadecuada de hormona antidiurética
* reacciones graves en la piel (dermatitis bullosa, eritema multiforme)
* andar dormido (sonambulismo)
* problema del habla
* aumento de los niveles de creatina cinasa en la sangre
* dificultad para orinar (retención urinaria)
* dolor muscular, rigidez y/o debilidad, oscurecimiento o decoloración de la orina (rabdomiólisis)
* aumento de los niveles de la hormona prolactina en la sangre (hiperprolactinemia, que incluye síntomas de aumento de tamaño de las mamas y/o secreción lechosa por el pezón)
* erección dolorosa y prolongada del pene

**Otros efectos adversos en niños y adolescentes**

En menores de 18 años se observaron frecuentemente los siguientes efectos adversos en los ensayos clínicos: un considerable aumento de peso, urticaria y un aumento de triglicéridos en la sangre.

**Comunicación de efectos adversos**

Si experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del Sistema Español de Farmacovigilancia de Medicamentos de Uso Humano: [https://www.notificaram.es](https://www.notificaram.es). Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.


#### 5. Conservación de MIRTAZAPINA CINFA

 

Mantener este medicamento fuera de la vista y del alcance de los niños.

No utilice este medicamento después de la fecha de caducidad que aparece en el envase y en el blíster, después de CAD. La fecha de caducidad es el último día del mes que se indica.

No conservar a temperatura superior a 30ºC.

Los medicamentos no se deben tirar por los desagües ni a la basura. Deposite los envases y los medicamentos que no necesita en el Punto SIGRE de la farmacia. En caso de duda, pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudará a proteger el medio ambiente.


#### 6. Contenido del envase e información adicional

 

**Composición de mirtazapina cinfa**

* El principio activo es mirtazapina. Cada comprimido recubierto con película contiene 30 mg de mirtazapina.
* Los demás componentes son:
* Núcleo del comprimido: lactosa monohidrato, hidroxipropilcelulosa (E-463), almidón de maíz, sílice coloidal anhidra, hidroxipropilcelulosa de bajo grado de sustitución (E-463) y estearato de magnesio.
* Recubrimiento del comprimido: Opadry Brown 20A56788 (hidroxipropilcelulosa (E-463), hipromelosa (E-464), dióxido de titanio (E-171), óxido de hierro amarillo (E-172), óxido de hierro rojo (E-172) y óxido de hierro negro (E-172)).

**Aspecto del producto y contenido del envase**

Comprimidos de color marrón rojizo, biconvexos, con forma de cápsula, recubiertos, ranurados por una cara y marcados con el código “30” por la otra cara.

Se presenta en blísteres de PVC-PVDC/ALU.

Cada envase contiene 30 o 500 (envase clínico) comprimidos recubiertos con película.

Puede que solamente estén comercializados algunos tamaños de envases.

**Titular de la autorización de comercialización y responsable de la fabricación**

Laboratorios Cinfa, S.A.

Carretera Olaz-Chipi, 10. Polígono Industrial Areta

31620 Huarte (Navarra) - España

**Fecha de la última revisión de este prospecto: Noviembre 2021**

La información detallada y actualizada de este medicamento está disponible en la página web de la Agencia Española de Medicamentos y Productos Sanitarios (AEMPS) www.aemps.gob.es/


####  MIRTAZAPINA CINFA 30 mg Coated Tablet 
PMSWI:
** 67.068 **PHPID:
** 0x6c47381b040e5b588db23b2272f28eec **
-------

Full name: **MIRTAZAPINA CINFA 30 mg Coated Tablet**

 - Invented name part: ** Mirtazapine Cinfa ** 

 - Scientific name part: ** Mirtazapine ** 

 - Strength part: ** 30 mg ** 

 - Pharmaceutical dose form part: ** coated tablet ** 

 Name usage: **English (Spain)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** 67.068 ** 

 Region: ** ** 

Marketing authorisation holder: **LABORATORIOS CINFA, S.A.** 

 Identifier: 
*  **ORG-100003791** 
 

 Status: ** Active (2021-01-01) ** 

 Package 1 of 1

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****30 

Administrable Product (1 of 1)

 Dose form: ** Coated tablet ** 

 Unit of presentation: ** tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** LACTOSE MONOHYDRATE ** 

Ingredient

 Role: ** active ** 

 Substance: ** Mirtazapine ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** HYDROXYPROPYL CELLULOSE, UNSPECIFIED ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** SILICA, COLLOIDAL ANHYDROUS ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** CORN STARCH ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-es-proc-e762a2f54b0b24fca4744b1bb7524a5b",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "es",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "x"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-es-proc-7a7ff0f4e1993c2fdabba6c8d9931a52",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-es-proc-7a7ff0f4e1993c2fdabba6c8d9931a52",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "es",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"es\" lang=\"es\"><a name=\"Composition_composition-es-proc-7a7ff0f4e1993c2fdabba6c8d9931a52\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-es-proc-7a7ff0f4e1993c2fdabba6c8d9931a52</b></p><a name=\"composition-es-proc-7a7ff0f4e1993c2fdabba6c8d9931a52\"> </a><a name=\"hccomposition-es-proc-7a7ff0f4e1993c2fdabba6c8d9931a52\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: es</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: indication</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 238131007}\">Overweight (finding)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: pregnancyCategory</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ W78}\">Pregnancy</span></li></ul></blockquote><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/21c15cbfff3522085d2493e5acc90334</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs P}\">processed</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#Organization_mah-dbf32c7ed470ffbeb6060201f32edb29\">Organization LABORATORIOS CINFA, S.A.</a></p><p><b>title</b>: TEST PURPOSES ONLY - MIRTAZAPINA CINFA 30 mg Coated Tablet</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "indication"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "238131007",
                "display" : "Overweight (finding)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "pregnancyCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "W78",
                "display" : "Pregnancy"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      }],
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "21c15cbfff3522085d2493e5acc90334"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "P",
          "display" : "processed"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-dbf32c7ed470ffbeb6060201f32edb29"
      }],
      "title" : "TEST PURPOSES ONLY - MIRTAZAPINA CINFA 30 mg Coated Tablet",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. PROSPECTO",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PROSPECTO"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.</strong></p><ul><li>Conserve este prospecto, ya que puede tener que volver a leerlo.</li><li>Si tiene alguna duda, consulte a su médico o farmacéutico.</li><li>Este medicamento se le ha recetado solamente a usted, y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.</li><li>Si experimenta efectos adversos, consulte a su médico o farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto. Ver sección 4.</li></ul></div>"
          }
        },
        {
          "title" : "Contenido del prospecto",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Contenido del prospecto"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Contenido del prospecto</p><ol><li>Qué es mirtazapina cinfa y para qué se utiliza</li><li>Qué necesita saber antes de empezar a tomar mirtazapina cinfa</li><li>Cómo tomar mirtazapina cinfa</li><li>Posibles efectos adversos</li><li>Conservación de mirtazapina cinfa</li><li>Contenido del envase e información adicional</li></ol></div>"
          }
        },
        {
          "title" : "1. Qué es MIRTAZAPINA CINFA  y para qué se utiliza",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Qué es MIRTAZAPINA CINFA  y para qué se utiliza"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>mirtazapina cinfa pertenece al grupo de medicamentos llamados antidepresivos.</p><p class=\"indication\">Mirtazapina se utiliza para tratar la depresión en adultos.</p><p>Se requieren de 1 a 2 semanas antes de que mirtazapina empiece a hacer efecto. Después de 2 a 4 semanas usted puede empezar a encontrarse mejor. Debe consultar a su médico si empeora o si no mejora después de 2 a 4 semanas.</p><p>Para más información ver la sección 3 &quot;Cuándo puede esperar encontrarse mejor&quot;</p></div>"
          }
        },
        {
          "title" : "2. Qué necesita saber antes de empezar a tomar MIRTAZAPINA CINFA",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Qué necesita saber antes de empezar a tomar MIRTAZAPINA CINFA"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>No tome mirtazapina cinfa</strong></p><ul><li>si es alérgico a mirtazapina o a alguno de los demás componentes de este medicamento (incluidos en la sección 6). En ese caso, consulte a su médico lo antes posible antes de tomar mirtazapina.</li><li>si está tomando o ha tomado recientemente (en las dos últimas semanas) medicamentos llamados inhibidores de la monoaminooxidasa (IMAO).</li></ul><p><strong>Advertencias y precauciones</strong> Consulte a su médico o farmacéutico antes de empezar a tomar mirtazapina cinfa</p><p>NO TOME O CONSULTE A SU MÉDICO ANTES DE EMPEZAR A TOMAR mirtazapina: Si ha sufrido alguna vez una erupción cutánea intensa o descamación de la piel, ampollas o llagas en la boca después de tomar mirtazapina u otros medicamentos.</p><p><strong>Niños y adolescentes</strong></p><p>Mirtazapina no debe utilizarse normalmente en el tratamiento de niños y adolescentes menores de 18 años porque no se demostró su eficacia. A la vez, debe saber que en pacientes menores de 18 años existe un mayor riesgo de efectos adversos como intentos de suicidio, ideación suicida y hostilidad (predominantemente agresión, comportamiento de confrontación e irritación) cuando toman esta clase de medicamentos. Pese a ello, el médico puede prescribir mirtazapina a pacientes menores de 18 años cuando decida que es lo más conveniente para el paciente. Si el médico ha prescrito mirtazapina a un paciente menor de 18 años y desea discutir esta decisión, por favor, vuelva a su médico. Debe informar a su médico si aparecen o empeoran alguno de los síntomas que se detallan anteriormente en pacientes menores de 18 años que están tomando mirtazapina. Además, todavía no se conocen los efectos sobre la seguridad a largo plazo relacionados con el crecimiento, la madurez y el desarrollo del conocimiento y la conducta de mirtazapina en este grupo de edad. También se ha observado con mayor frecuencia un considerable aumento de peso en este grupo de edad cuando son tratados con mirtazapina, en comparación con los adultos.</p><p><strong>Ideas de suicidio y empeoramiento de la depresión</strong></p><p>Si se encuentra deprimido puede que a veces tenga ideas de hacerse daño a si mismo o de suicidarse. Esto podría empeorar cuando empieza a tomar los antidepresivos por primera vez, ya que estos medicamentos tardan en hacer efecto normalmente dos semanas o a veces más. Podría ser más propenso a pensar de esta manera:</p><ul><li>si previamente ha tenido pensamientos suicidas o de hacerse daño a si mismo.</li><li>si es un adulto joven. La información de los ensayos clínicos ha mostrado un riesgo aumentado de comportamiento suicida en adultos menores de 25 años con trastornos psiquiátricos y que estaban en tratamiento con un antidepresivo.</li><li>si tiene pensamiento de hacerse daño a si mismo o suicidarse en algún momento, consulte a su médico o vaya a un hospital inmediatamente.</li></ul><p>Puede ser útil decirle a un pariente o amigo cercano que se encuentra deprimido, y pedirle que lea este prospecto. Puede pedirle que le diga si cree que su depresión está empeorando, o si está preocupado por cambios en su comportamiento.</p><p>Asimismo, tenga especial cuidado con mirtazapina:</p><ul><li>si tiene o ha tenido alguna vez uno de los siguientes trastornos</li><li>Informe a su médico sobre estas situaciones antes de tomar mirtazapina, si no lo ha hecho ya:<ul><li>convulsiones (epilepsia). Si aparecen convulsiones o sus convulsiones son más frecuentes, deje de tomar mirtazapina y contacte con su médico inmediatamente;</li><li>enfermedades del hígado, incluyendo ictericia. Si aparece ictericia, deje de tomar mirtazapina y contacte con su médico inmediatamente;</li><li>enfermedades de los riñones;</li><li>enfermedad del corazón o presión arterial baja;</li><li>esquizofrenia. Si los síntomas psicóticos, como los pensamientos paranoicos, son más frecuentes o graves contacte con su médico inmediatamente;</li><li>depresión bipolar (se alternan períodos de animación/hiperactividad y períodos de depresión). Si empieza a sentirse animado o sobreexcitado, deje de tomar mirtazapina y contacte con su médico inmediatamente;</li><li>diabetes (podría necesitar ajustar su dosis de insulina u otros medicamentos antidiabéticos);</li><li>enfermedades de los ojos, como aumento de la presión en el ojo (glaucoma);</li><li>dificultades para orinar, que podrían deberse a un aumento del tamaño de la próstata;</li><li>ciertos tipos de enfermedades del corazón que pueden cambiar el ritmo de su corazón, un ataque reciente al corazón, un fallo del corazón, o toma de ciertos medicamentos que pueden afectar el ritmo del corazón.</li></ul></li><li>si aparecen signos de infección como fiebre alta inexplicable, dolor de garganta y llagas en la boca Deje de tomar mirtazapina y contacte con su médico inmediatamente para realizar un análisis de sangre. En raras ocasiones, estos síntomas pueden ser signos de alteraciones en la producción de células sanguíneas en la médula ósea. Aunque raros, estos síntomas aparecen a las 4-6 semanas de tratamiento.</li><li>si es una persona mayor podría ser más sensible a los efectos adversos de los medicamentos antidepresivos.</li><li>se han notificado con el uso de mirtazapina reacciones cutáneas graves, como síndrome de StevensJohnson (SSJ), necrólisis epidérmica tóxica (NET) y reacción medicamentosa con eosinofilia y síntomas sistémicos (DRESS). Interrumpa su uso y busque atención médica inmediatamente si nota alguno de los síntomas descritos en la sección 4 en relación con estas reacciones cutáneas graves. Si ha sufrido alguna vez reacciones cutáneas graves, no debe reiniciarse el tratamiento con mirtazapina.</li></ul><p><strong>Otros medicamentos y mirtazapina cinfa</strong></p><p>Informe a su médico o farmacéutico si está tomando, ha tomado recientemente o pudiera tener que tomar cualquier otro medicamento.</p><p>No tome mirtazapina junto con:</p><ul><li>inhibidores de la monoamino oxidasa (inhibidores de la MAO). Asimismo, no tome mirtazapina durante las dos semanas después de haber dejado de tomar los inhibidores de la MAO. Si deja de tomar mirtazapina, tampoco tome inhibidores de la MAO durante las siguientes dos semanas. Ejemplos de inhibidores de la MAO son moclobemida, tranilcipromina (ambos son antidepresivos) y selegilina (para la enfermedad de Parkinson).</li></ul><p>Tenga cuidado si toma mirtazapina junto con:</p><ul><li>antidepresivos como los inhibidores selectivos de la recaptación de serotonina (ISRSs), venlafaxina y L-triptófano o triptanos (utilizados para tratar la migraña), tramadol (para el dolor), linezolid (un antibiótico), litio (utilizado para tratar algunos trastornos psiquiátricos), azul de metileno (utilizado para tratar niveles altos de metahemoglobina en la sangre) y preparados a base de Hierba de San Juan – Hypericum perforatum (planta medicinal para la depresión). En casos muy raros, mirtazapina solo o junto con estos medicamentos, puede dar lugar al llamado síndrome serotoninérgico. Algunos de los síntomas de este síndrome son: fiebre inexplicable, sudoración, palpitaciones, diarrea, contracciones musculares (incontrolables), escalofríos, reflejos exagerados, agitación, cambios de humor y pérdida de conciencia. Si presenta una combinación de estos síntomas, consulte a su médico inmediatamente.</li><li>el antidepresivo nefazodona. Puede aumentar la cantidad de mirtazapina en sangre. Informe a su médico si está tomando este medicamento. Podría ser necesario disminuir la dosis de mirtazapina, o aumentarla nuevamente al dejar de tomar nefazodona.</li><li>medicamentos para la ansiedad o el insomnio como las benzodiazepinas. medicamentos para la esquizofrenia como la olanzapina. medicamentos para las alergias como la cetirizina. medicamentos para el dolor intenso como la morfina. En combinación con estos medicamentos, mirtazapina puede aumentar la somnolencia causada por estos medicamentos.</li><li>medicamentos para infecciones: medicamentos para infecciones bacterianas (como la eritromicina), medicamentos para infecciones por hongos (como el ketoconazol) y los medicamentos para el VIH/SIDA (inhibidores de la proteasa del VIH) y medicamentos para la úlcera de estómago (como la cimetidina). Si se toman junto con mirtazapina, estos medicamentos pueden aumentar la cantidad de mirtazapina en sangre. Informe a su médico si está tomando estos medicamentos. Podría ser necesario disminuir la dosis de mirtazapina, o aumentarla nuevamente al dejar de tomar estos medicamentos.</li><li>medicamentos para la epilepsia: como la carbamazepina y la fenitoína.</li><li>medicamentos para la tuberculosis como la rifampicina. Si se toman junto con mirtazapina, estos medicamentos pueden reducir la cantidad de mirtazapina en sangre. Informe a su médico si está tomando estos medicamentos. Podría ser necesario aumentar la dosis de mirtazapina, o disminuirla nuevamente al dejar de tomar estos medicamentos. medicamentos para prevenir la coagulación de la sangre como la warfarina. Mirtazapina puede aumentar los efectos de la warfarina en la sangre. Informe a su médico si está tomando este medicamento. En caso de tomarlos a la vez, se recomienda que el médico le haga controles en sangre.</li><li>medicamentos que pueden afectar el ritmo del corazón, como ciertos antibióticos y algunos antipsicóticos</li></ul><p><strong>Toma de mirtazapina cinfa con alimentos y alcohol</strong></p><p>Puede sentirse somnoliento si bebe alcohol mientras esté en tratamiento con mirtazapina. Se recomienda no beber nada de alcohol. Puede tomar mirtazapina con o sin alimentos.</p><p class=\"pregnancyCategory\"><strong>Embarazo y lactancia</strong></p><p class=\"pregnancyCategory\">Si está embarazada o en periodo de lactancia, cree que podría estar embarazada o tiene intención de quedarse embarazada, consulte a su médico o farmacéutico antes de utilizar este medicamento.</p><p class=\"pregnancyCategory\">La experiencia limitada de la administración de mirtazapina a mujeres embarazadas no indica un aumento de riesgo. Sin embargo, debe tenerse cuidado si se usa durante el embarazo.</p><p class=\"pregnancyCategory\">Si usa mirtazapina hasta, o poco antes del parto, su hijo será examinado para detectar posibles efectos adversos.</p><p>class=\"pregnancyCategory\"Tomados durante el embarazo, los medicamentos similares (ISRS) pueden aumentar en los bebés el riesgo de padecer una enfermedad grave denominada hipertensión pulmonar persistente neonatal (HPPN), ocasionando que el bebé respire más rápido y adquiera un tono azulado. Estos síntomas comienzan normalmente durante las primeras 24 horas después de que nazca el bebé. Si esto le sucede al bebé, debe consultar a su matrona o médico de inmediato.</p><p><strong>Conducción y uso de máquinas</strong></p><p>Durante el tratamiento con mirtazapina puede que se sienta somnoliento o mareado. No conduzca ni maneje herramientas o máquinas hasta que sepa cómo le afecta el tratamiento con mirtazapina.</p><p><strong>mirtazapina cinfa contiene lactosa.</strong></p><p>Este medicamento contiene lactosa. Si su médico le ha indicado que padece una intolerancia a ciertos azúcares, consulte con él antes de tomar este medicamento.</p></div>"
          }
        },
        {
          "title" : "3. Cómo tomar MIRTAZAPINA CINFA",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Cómo tomar MIRTAZAPINA CINFA"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico o farmacéutico. En caso de duda, consulte de nuevo a su médico o farmacéutico.</p><p><strong>Cuánto tomar</strong></p><p>La dosis inicial recomendada es de 15 o 30 mg al día. Su médico puede recomendarle aumentar la dosis tras unos días hasta la cantidad que sea mejor para usted (entre 15 y 45 mg al día). Normalmente la dosis es la misma para todas las edades. Sin embargo, si es una persona mayor o si padece una enfermedad del riñón o del hígado, su médico podría cambiar la dosis.</p><p><strong>Cuándo tomar mirtazapina</strong></p><p>Tome mirtazapina a la misma hora cada día. Es mejor tomar la dosis de mirtazapina de una sola vez antes de acostarse. Sin embargo, su médico puede recomendarle que divida su dosis de mirtazapina por la mañana y por la noche antes de acostarse. La dosis más alta debe tomarse antes de acostarse. Los comprimidos se toman por vía oral. Tome la dosis de mirtazapina recetada sin masticar, con agua o zumo.</p><p><strong>Cuándo puede esperar encontrarse mejor</strong></p><p>Normalmente mirtazapina empezará a hacer efecto después de 1 o 2 semanas y después de 2 a 4 semanas podría empezar a encontrarse mejor. Es importante que durante las primeras semanas de tratamiento hable con su médico sobre los efectos de mirtazapina: entre 2 y 4 semanas después de haber empezado a tomar mirtazapina, hable con su médico sobre cómo le ha afectado este medicamento. Si todavía no se encuentra mejor, su médico podría recetarle una dosis mayor. En ese caso, hable nuevamente con su médico después de otras 2-4 semanas. Normalmente necesitará tomar mirtazapina hasta que los síntomas de depresión hayan desaparecido durante 4-6 meses.</p><p>El comprimido se puede partir en dosis iguales.</p><p><strong>Si toma más mirtazapina cinfa del que debe</strong></p><p>En caso de sobredosis o ingestión accidental consulte inmediatamente a su médico o farmacéutico o llame al Servicio de Información Toxicológica, teléfono 91 562 04 20, indicando el medicamento y la cantidad ingerida. Se recomienda llevar el prospecto y el envase al profesional sanitario.</p><p>Los síntomas más probables de una sobredosis de mirtazapina (sin otros medicamentos o alcohol) son la somnolencia, desorientación y palpitaciones. Los síntomas de una posible sobredosis pueden incluir cambios en el ritmo de su corazón (latido rápido, irregular) y/o desfallecimiento, que podrían ser síntomas de una enfermedad potencialmente mortal conocida como Torsades de pointes.</p><p><strong>Si olvidó tomar mirtazapina cinfa</strong></p><p>Si tiene que tomar su dosis una vez al día</p><ul><li>No tome una dosis doble para compensar las dosis olvidadas. Tome la dosis habitual al día siguiente. Si tiene que tomar su dosis dos veces al día</li><li>Si ha olvidado la dosis de la mañana, simplemente tómesela junto con la dosis de la noche.</li><li>Si ha olvidado la dosis de la noche, no la tome a la mañana siguiente; sáltesela y continúe con sus dosis normales por la mañana y por la noche.</li><li>Si ha olvidado ambas dosis, no intente recuperarlas. Sáltese ambas dosis y al día siguiente continúe con la dosis normal por la mañana y por la noche.</li></ul><p><strong>Si interrumpe el tratamiento con mirtazapina cinfa</strong></p><p>Deje de tomar mirtazapina sólo si lo consulta con su médico. Si lo deja demasiado pronto, la depresión podría reaparecer. Cuando se encuentre mejor, hable con su médico. Su médico decidirá cuándo puede dejar el tratamiento. No deje de tomar mirtazapina bruscamente, aun cuando la depresión haya desaparecido. Si deja de tomar mirtazapina de forma brusca, puede sentirse enfermo, mareado, agitado o ansioso y tener dolores de cabeza. Estos síntomas pueden evitarse dejando el tratamiento gradualmente. Su médico le indicará cómo disminuir la dosis gradualmente.</p><p>Si tiene cualquier otra duda sobre el uso de este medicamento, pregunte a su médico o farmacéutico.</p></div>"
          }
        },
        {
          "title" : "4. Posibles efectos adversos",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Posibles efectos adversos"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.</p><p><strong>Si experimenta alguno de los siguientes efectos adversos graves, deje de tomar mirtazapina e informe inmediatamente a su médico.</strong></p><p>Poco frecuentes (pueden afectar hasta 1 de cada 100 pacientes):</p><ul><li>sentimiento de euforia exagerada (manía).</li></ul><p>Raros (pueden afectar hasta 1 de cada 1.000 pacientes):</p><ul><li>coloración amarilla de los ojos o la piel; puede sugerir alteraciones en el funcionamiento del hígado (ictericia).</li></ul><p>Frecuencia no conocida (no puede estimarse a partir de los datos disponibles):</p><ul><li>signos de infección tales como fiebre alta inexplicable y repentina, dolor de garganta y llagas en la boca (agranulocitosis). En casos raros, mirtazapina puede provocar alteraciones en la producción de células sanguíneas (depresión de la médula ósea). Algunas personas se vuelven menos resistentes a las infecciones porque mirtazapina puede provocar una disminución temporal de los glóbulos blancos de la sangre (granulocitopenia). En casos raros, mirtazapina también puede provocar una disminución de los glóbulos rojos y blancos y de las plaquetas (anemia aplásica), una disminución de las plaquetas (trombocitopenia) o un aumento en el número de glóbulos blancos en sangre (eosinofilia).</li><li>ataque epiléptico (convulsiones).</li><li>combinación de síntomas como fiebre inexplicable, sudoración, palpitaciones, diarrea, contracciones musculares (incontrolables), escalofríos, reflejos exagerados, agitación, cambios de humor, pérdida de conciencia y aumento de la producción de saliva. En casos muy raros, estos síntomas pueden ser señales de un trastorno llamado “síndrome serotoninérgico”.</li><li>pensamientos de hacerse daño a uno mismo o de suicidio.</li><li>reacciones graves en la piel:<ul><li>parches rojos en el tronco, como máculas circunscritas o circulares, a menudo con ampollas en el centro, desprendimiento de la piel, úlceras en la boca, la garganta, la nariz, los genitales y los ojos. Estos eritemas cutáneos graves pueden ir precedidos de fiebre y síntomas gripales (síndrome de Stevens-Johnson, necrólisis epidérmica tóxica).</li><li>eritema generalizado, temperatura corporal elevada y aumento de tamaño de los ganglios linfáticos (síndrome DRESS o síndrome de hipersensibilidad medicamentosa).</li></ul></li></ul><p><strong>Otros posibles efectos adversos con mirtazapina son:</strong></p><p>Muy frecuentes (pueden afectar a más de 1 de cada 10 pacientes)</p><ul><li>aumento del apetito y aumento de peso</li><li>somnolencia</li><li>dolor de cabeza</li><li>boca seca</li></ul><p>Frecuentes (pueden afectar hasta 1 de cada 10 pacientes)</p><ul><li>letargia</li><li>mareo</li><li>temblor</li><li>náuseas</li><li>diarrea</li><li>vómitos</li><li>estreñimiento</li><li>urticaria o erupciones en la piel (exantema)</li><li>dolores en las articulaciones (artralgia) o músculos (mialgia)</li><li>dolor de espalda</li><li>mareo o desmayo al levantarse rápidamente (hipotensión ortrtostática)</li><li>hinchazón (normalmente en tobillos o pies) debido a retención de líquidos (edema)</li><li>cansancio</li><li>sueños vívidos</li><li>confusión</li><li>ansiedad</li><li>dificultades para dormir</li><li>problemas de memoria, que en la mayoría de los casos se resolvieron cuando se suspendió el tratamiento</li></ul><p>Poco frecuentes (pueden afectar hasta 1 de cada 100 pacientes)</p><ul><li>sensación extraña en la piel por ejemplo quemazón, pinchazos, cosquilleo u hormigueo (parestesia)</li><li>movimientos involuntarios de agitación de las piernas durante el sueño</li><li>desmayos (síncope)</li><li>sensación de adormecimiento de la boca (hipoestesia oral)</li><li>tensión baja</li><li>pesadillas</li><li>agitación</li><li>alucinaciones</li><li>incapacidad para mantenerse quieto</li></ul><p>Raros (pueden afectar hasta 1 de cada 1.000 pacientes)</p><ul><li>tics o contracciones musculares (mioclono)</li><li>agresión</li><li>dolor abdominal, náuseas; esto puede indicar inflamación del páncreas (pancreatitis)</li></ul><p>Frecuencia no conocida (no puede estimarse a partir de los datos disponibles)</p><ul><li>sensaciones anormales en la boca (parestesia oral)</li><li>hinchazón en la boca (edema bucal)</li><li>hinchazón por todo el cuerpo (edema generalizado)</li><li>hinchazón localizada</li><li>hiponatremia</li><li>secreción inadecuada de hormona antidiurética</li><li>reacciones graves en la piel (dermatitis bullosa, eritema multiforme)</li><li>andar dormido (sonambulismo)</li><li>problema del habla</li><li>aumento de los niveles de creatina cinasa en la sangre</li><li>dificultad para orinar (retención urinaria)</li><li>dolor muscular, rigidez y/o debilidad, oscurecimiento o decoloración de la orina (rabdomiólisis)</li><li>aumento de los niveles de la hormona prolactina en la sangre (hiperprolactinemia, que incluye síntomas de aumento de tamaño de las mamas y/o secreción lechosa por el pezón)</li><li>erección dolorosa y prolongada del pene</li></ul><p><strong>Otros efectos adversos en niños y adolescentes</strong></p><p>En menores de 18 años se observaron frecuentemente los siguientes efectos adversos en los ensayos clínicos: un considerable aumento de peso, urticaria y un aumento de triglicéridos en la sangre.</p><p><strong>Comunicación de efectos adversos</strong></p><p>Si experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del Sistema Español de Farmacovigilancia de Medicamentos de Uso Humano: <a href=\"https://www.notificaram.es\">https://www.notificaram.es</a>. Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.</p></div>"
          }
        },
        {
          "title" : "5. Conservación de MIRTAZAPINA CINFA",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Conservación de MIRTAZAPINA CINFA"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Mantener este medicamento fuera de la vista y del alcance de los niños.</p><p>No utilice este medicamento después de la fecha de caducidad que aparece en el envase y en el blíster, después de CAD. La fecha de caducidad es el último día del mes que se indica.</p><p>No conservar a temperatura superior a 30ºC.</p><p>Los medicamentos no se deben tirar por los desagües ni a la basura. Deposite los envases y los medicamentos que no necesita en el Punto SIGRE de la farmacia. En caso de duda, pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma, ayudará a proteger el medio ambiente.</p></div>"
          }
        },
        {
          "title" : "6. Contenido del envase e información adicional",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contenido del envase e información adicional"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Composición de mirtazapina cinfa</strong></p><ul><li>El principio activo es mirtazapina. Cada comprimido recubierto con película contiene 30 mg de mirtazapina.</li><li>Los demás componentes son:<ul><li>Núcleo del comprimido: lactosa monohidrato, hidroxipropilcelulosa (E-463), almidón de maíz, sílice coloidal anhidra, hidroxipropilcelulosa de bajo grado de sustitución (E-463) y estearato de magnesio.</li><li>Recubrimiento del comprimido: Opadry Brown 20A56788 (hidroxipropilcelulosa (E-463), hipromelosa (E-464), dióxido de titanio (E-171), óxido de hierro amarillo (E-172), óxido de hierro rojo (E-172) y óxido de hierro negro (E-172)).</li></ul></li></ul><p><strong>Aspecto del producto y contenido del envase</strong></p><p>Comprimidos de color marrón rojizo, biconvexos, con forma de cápsula, recubiertos, ranurados por una cara y marcados con el código “30” por la otra cara.</p><p>Se presenta en blísteres de PVC-PVDC/ALU.</p><p>Cada envase contiene 30 o 500 (envase clínico) comprimidos recubiertos con película.</p><p>Puede que solamente estén comercializados algunos tamaños de envases.</p><p><strong>Titular de la autorización de comercialización y responsable de la fabricación</strong></p><p>Laboratorios Cinfa, S.A.</p><p>Carretera Olaz-Chipi, 10. Polígono Industrial Areta</p><p>31620 Huarte (Navarra) - España</p><p><strong>Fecha de la última revisión de este prospecto: Noviembre 2021</strong></p><p>La información detallada y actualizada de este medicamento está disponible en la página web de la Agencia Española de Medicamentos y Productos Sanitarios (AEMPS) www.aemps.gob.es/</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-mirtazapine-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-mirtazapine-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-mirtazapine-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-mirtazapine-magnesiumstearate</b></p><a name=\"ingredient-for-mirtazapine-magnesiumstearate\"> </a><a name=\"hcingredient-for-mirtazapine-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#x (use: official, ); status = active; manufacturedDoseForm = Coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#AdministrableProductDefinition_ap-e762a2f54b0b24fca4744b1bb7524a5b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#identifier; status = active; administrableDoseForm = Coated tablet; unitOfPresentation = tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b"
      },
      {
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e762a2f54b0b24fca4744b1bb7524a5b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-mirtazapine-lactosemonohydrate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-mirtazapine-lactosemonohydrate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-mirtazapine-lactosemonohydrate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-mirtazapine-lactosemonohydrate</b></p><a name=\"ingredient-for-mirtazapine-lactosemonohydrate\"> </a><a name=\"hcingredient-for-mirtazapine-lactosemonohydrate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EWQ57Q8I5X (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#x (use: official, ); status = active; manufacturedDoseForm = Coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#AdministrableProductDefinition_ap-e762a2f54b0b24fca4744b1bb7524a5b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#identifier; status = active; administrableDoseForm = Coated tablet; unitOfPresentation = tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EWQ57Q8I5X}\">LACTOSE MONOHYDRATE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EWQ57Q8I5X"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b"
      },
      {
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e762a2f54b0b24fca4744b1bb7524a5b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EWQ57Q8I5X",
              "display" : "LACTOSE MONOHYDRATE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-mirtazapine-mirtazapine",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-mirtazapine-mirtazapine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-mirtazapine-mirtazapine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-mirtazapine-mirtazapine</b></p><a name=\"ingredient-for-mirtazapine-mirtazapine\"> </a><a name=\"hcingredient-for-mirtazapine-mirtazapine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/A051Q2099Q (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#x (use: official, ); status = active; manufacturedDoseForm = Coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#AdministrableProductDefinition_ap-e762a2f54b0b24fca4744b1bb7524a5b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#identifier; status = active; administrableDoseForm = Coated tablet; unitOfPresentation = tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 72072}\">active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta A051Q2099Q}\">Mirtazapine</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>30 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "A051Q2099Q"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b"
      },
      {
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e762a2f54b0b24fca4744b1bb7524a5b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "72072",
          "display" : "active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "A051Q2099Q",
              "display" : "Mirtazapine"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 30,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-mirtazapine-hydroxypropylcelluloseunspecified",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-mirtazapine-hydroxypropylcelluloseunspecified",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-mirtazapine-hydroxypropylcelluloseunspecified\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-mirtazapine-hydroxypropylcelluloseunspecified</b></p><a name=\"ingredient-for-mirtazapine-hydroxypropylcelluloseunspecified\"> </a><a name=\"hcingredient-for-mirtazapine-hydroxypropylcelluloseunspecified\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/9XZ8H6N6OH (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#x (use: official, ); status = active; manufacturedDoseForm = Coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#AdministrableProductDefinition_ap-e762a2f54b0b24fca4744b1bb7524a5b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#identifier; status = active; administrableDoseForm = Coated tablet; unitOfPresentation = tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 9XZ8H6N6OH}\">HYDROXYPROPYL CELLULOSE, UNSPECIFIED</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "9XZ8H6N6OH"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b"
      },
      {
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e762a2f54b0b24fca4744b1bb7524a5b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "9XZ8H6N6OH",
              "display" : "HYDROXYPROPYL CELLULOSE, UNSPECIFIED"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-mirtazapine-silicacolloidalanhydrous",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-mirtazapine-silicacolloidalanhydrous",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-mirtazapine-silicacolloidalanhydrous\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-mirtazapine-silicacolloidalanhydrous</b></p><a name=\"ingredient-for-mirtazapine-silicacolloidalanhydrous\"> </a><a name=\"hcingredient-for-mirtazapine-silicacolloidalanhydrous\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/ETJ7Z6XBU4 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#x (use: official, ); status = active; manufacturedDoseForm = Coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#AdministrableProductDefinition_ap-e762a2f54b0b24fca4744b1bb7524a5b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#identifier; status = active; administrableDoseForm = Coated tablet; unitOfPresentation = tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta ETJ7Z6XBU4}\">SILICA, COLLOIDAL ANHYDROUS</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "ETJ7Z6XBU4"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b"
      },
      {
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e762a2f54b0b24fca4744b1bb7524a5b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "ETJ7Z6XBU4",
              "display" : "SILICA, COLLOIDAL ANHYDROUS"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-mirtazapine-cornstarch",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-mirtazapine-cornstarch",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-mirtazapine-cornstarch\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-mirtazapine-cornstarch</b></p><a name=\"ingredient-for-mirtazapine-cornstarch\"> </a><a name=\"hcingredient-for-mirtazapine-cornstarch\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/O8232NY3SJ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#x (use: official, ); status = active; manufacturedDoseForm = Coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></li><li><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#AdministrableProductDefinition_ap-e762a2f54b0b24fca4744b1bb7524a5b\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#identifier; status = active; administrableDoseForm = Coated tablet; unitOfPresentation = tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta O8232NY3SJ}\">CORN STARCH</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "O8232NY3SJ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b"
      },
      {
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-e762a2f54b0b24fca4744b1bb7524a5b"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "O8232NY3SJ",
              "display" : "CORN STARCH"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-mirtazapine",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-mirtazapine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-mirtazapine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-mirtazapine</b></p><a name=\"substance-mirtazapine\"> </a><a name=\"hcsubstance-mirtazapine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/A051Q2099Q (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#Organization_mah-dbf32c7ed470ffbeb6060201f32edb29\">Organization LABORATORIOS CINFA, S.A.</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>265.35</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C17H19N3</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>1,2,3,4,10,14b-Hexahydro-2-methylpyrazino[2,1-a]pyrido[2,3-c]benzazepine</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "A051Q2099Q"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/mah-dbf32c7ed470ffbeb6060201f32edb29"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 265.35
        }
      }],
      "structure" : {
        "molecularFormula" : "C17H19N3"
      },
      "name" : [{
        "name" : "1,2,3,4,10,14b-Hexahydro-2-methylpyrazino[2,1-a]pyrido[2,3-c]benzazepine",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-e762a2f54b0b24fca4744b1bb7524a5b",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-e762a2f54b0b24fca4744b1bb7524a5b",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-e762a2f54b0b24fca4744b1bb7524a5b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-e762a2f54b0b24fca4744b1bb7524a5b</b></p><a name=\"ap-e762a2f54b0b24fca4744b1bb7524a5b\"> </a><a name=\"hcap-e762a2f54b0b24fca4744b1bb7524a5b\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/identifier</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073380}\">Coated tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#x (use: official, ); status = active; manufacturedDoseForm = Coated tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "identifier"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073380",
          "display" : "Coated tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizatione762a2f54b0b24fca4744b1bb7524a5b0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizatione762a2f54b0b24fca4744b1bb7524a5b0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizatione762a2f54b0b24fca4744b1bb7524a5b0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizatione762a2f54b0b24fca4744b1bb7524a5b0</b></p><a name=\"authorizatione762a2f54b0b24fca4744b1bb7524a5b0\"> </a><a name=\"hcauthorizatione762a2f54b0b24fca4744b1bb7524a5b0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/67.068 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072062}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2021-01-01</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#Organization_mah-dbf32c7ed470ffbeb6060201f32edb29\">Organization LABORATORIOS CINFA, S.A.</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "67.068"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072062",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2021-01-01",
      "holder" : {
        "reference" : "Organization/mah-dbf32c7ed470ffbeb6060201f32edb29"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-dbf32c7ed470ffbeb6060201f32edb29",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-dbf32c7ed470ffbeb6060201f32edb29",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-dbf32c7ed470ffbeb6060201f32edb29\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-dbf32c7ed470ffbeb6060201f32edb29</b></p><a name=\"mah-dbf32c7ed470ffbeb6060201f32edb29\"> </a><a name=\"hcmah-dbf32c7ed470ffbeb6060201f32edb29\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100003791 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: LABORATORIOS CINFA, S.A.</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera Olaz-Chipi, 10. Polígono Industrial Areta Huarte ES(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100003791"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "LABORATORIOS CINFA, S.A.",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera Olaz-Chipi, 10. Polígono Industrial Areta Huarte ES",
          "line" : ["Carretera Olaz-Chipi, 10. Polígono Industrial Areta"],
          "city" : "Huarte",
          "postalCode" : "31620",
          "country" : "ES"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-660f3150e2ccfb088d576c1767f7fe95",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-660f3150e2ccfb088d576c1767f7fe95",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-660f3150e2ccfb088d576c1767f7fe95\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-660f3150e2ccfb088d576c1767f7fe95</b></p><a name=\"ppd-660f3150e2ccfb088d576c1767f7fe95\"> </a><a name=\"hcppd-660f3150e2ccfb088d576c1767f7fe95\"> </a><p><b>name</b>: MIRTAZAPINA CINFA 30 mg Coated Tablet 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Prodcut</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#67.068,https://www.who-umc.org/phpid#0x6c47381b040e5b588db23b2272f28eec; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = 100000000000</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2021-09-01</p><p><b>containedItemQuantity</b>: 30 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-es-e762a2f54b0b24fca4744b1bb7524a5b.html#ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#x (use: official, ); status = active; manufacturedDoseForm = Coated tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "name" : "MIRTAZAPINA CINFA 30 mg Coated Tablet 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Prodcut"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2021-09-01",
      "containedItemQuantity" : [{
        "value" : 30,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp7a7ff0f4e1993c2fdabba6c8d9931a52",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp7a7ff0f4e1993c2fdabba6c8d9931a52",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp7a7ff0f4e1993c2fdabba6c8d9931a52\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp7a7ff0f4e1993c2fdabba6c8d9931a52</b></p><a name=\"mp7a7ff0f4e1993c2fdabba6c8d9931a52\"> </a><a name=\"hcmp7a7ff0f4e1993c2fdabba6c8d9931a52\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/67.068, <code>https://www.who-umc.org/phpid</code>/0x6c47381b040e5b588db23b2272f28eec</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000000000}\">100000000000</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: MIRTAZAPINA CINFA 30 mg Coated Tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Mirtazapine Cinfa</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Mirtazapine</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 30 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: coated tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 ES}\">Spain</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 ES}\">Spain</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "67.068"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0x6c47381b040e5b588db23b2272f28eec"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000000000"
        }]
      },
      "name" : [{
        "productName" : "MIRTAZAPINA CINFA 30 mg Coated Tablet",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Mirtazapine Cinfa",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "Mirtazapine",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "30 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "coated tablet",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "ES",
              "display" : "Spain"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "ES",
              "display" : "Spain"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-e762a2f54b0b24fca4744b1bb7524a5b",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-e762a2f54b0b24fca4744b1bb7524a5b",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-e762a2f54b0b24fca4744b1bb7524a5b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-e762a2f54b0b24fca4744b1bb7524a5b</b></p><a name=\"mid-e762a2f54b0b24fca4744b1bb7524a5b\"> </a><a name=\"hcmid-e762a2f54b0b24fca4744b1bb7524a5b\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/x (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073380}\">Coated tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "x"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073380",
          "display" : "Coated tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      }
    }
  }]
}

```
