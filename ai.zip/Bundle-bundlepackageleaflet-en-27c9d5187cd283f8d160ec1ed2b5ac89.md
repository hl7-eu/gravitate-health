# ePI document Bundle for Mo Package Leaflet for language en - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Mo Package Leaflet for language en**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **28 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Film-coated tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** DOMPERIDONE ** 

## Example Bundle: ePI document Bundle for Mo Package Leaflet for language en

**Composition category:**Raw

**Composition status:**final

### B. Package Leaflet

 

unavailable


#### Package leaflet: Information for the user

 

PATIENT INFORMATION LEAFLET Read all of this leaflet carefully before you start taking this medicine because it contains important information for you. • Keep this leaflet. You may need to read it again. • If you have any further questions, ask your doctor or pharmacist. • This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours. • If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet (see section 4).


#### What is in this leaflet

 

What is in this leaflet: 1. What Motilium is and what it is used for 2. What you need to know before you take Motilium 3. How to take Motilium 4. Possible side effects 5. How to store Motilium 6. Contents of the pack and other information


#### 1. What Domperidone is and what it is used for

 

"
1. WHAT MOTILIUM IS AND WHAT IT IS USED FOR The name of your medicine is Motilium 10mg Film-Coated Tablets (called Motilium in this leaflet). Motilium contains a medicine called domperidone. This belongs to a group of medicines called ‘dopamine antagonists’. This medicine is used to treat nausea (feeling sick) and vomiting (being sick) in adults and adolescents (years of age and older weighting 35 kg or more).
"


#### 2. What you need to know before you take Domperidone

 

Do not take Motilium tablets if: • You are allergic to domperidone or any of the other ingredients of Motilium 10mg Film-Coated Tablets (listed in section 6). Signs of an allergic reaction include: a rash, swallowing or breathing problems, swelling of your lips, face, throat or tongue. • You have a tumour of the pituitary gland (prolactinoma) • You have a blockage or tear in your intestines • You have black, tarry bowel motions (stools) or notice blood in your bowel motions. This could be a sign of bleeding in the stomach or intestines. • You have a moderate or severe liver disease. • Your ECG (electrocardiogram) shows a heart problem called “prolonged QT corrected interval”. • You have or had a problem where your heart cannot pump the blood round your body as well as it should (condition called heart failure). • You have a problem that gives you a low level of potassium or magnesium, or a high level of potassium in your blood. • You are taking certain medicines (see “Other medicines and Motilium”) Do not take Motilium if any of the above applies to you. If you are not sure, talk to your doctor or pharmacist before taking Motilium. Warnings and precautions Before taking this medicine contact your doctor if: • You suffer from liver problems (liver function impairment or failure) (see “Do not take Motilium tablets if”) • You suffer from kidney problems (kidney function impairment or failure). It is advisable to ask your doctor for advice in case of prolonged treatment as you may need to take a lower dose or take this medicine less often, and your doctor may want to examine you regularly. If you are not sure if any of the above apply to you, talk to your doctor or pharmacist before taking Motilium. Do this even if they have applied in the past. Motilium may be associated with an increased risk of heart rhythm disorder and cardiac arrest. This risk may be more likely in those over 60 years old or taking doses higher than 30 mg per day. The risk also increases when Motilium is given together with some drugs. Tell your doctor or pharmacist if you are taking drugs to treat infection (fungal infections or bacterial infection) and/or if you have heart problems or AIDS/HIV (see “Other medicines and Motilium). Motilium should be used at the lowest effective dose. While taking Motilium, contact your doctor if you experience heart rhythm disorders such as palpitations, trouble breathing, loss of consciousness. Treatment with Motilium should be stopped. Adolescents weighing less than 35 kg and children Motilium should not be given to adolescents 12 years of age and older weighing less than 35 kg, or in any children less than 12 years of age, as it is not effective in these age groups. Other medicines and Motilium Tell your doctor or pharmacist if you are taking or have recently taken any other medicines. This includes medicines you can buy without a prescription, including herbal medicines. This is because Motilium can affect the way some other medicines work. Also, some medicines can affect the way Motilium works. Do not take Motilium if you are taking medicine to treat: • Fungal infections such as azole anti-fungals, specifically oral ketoconazole, fluconazole or voriconazole. • Bacterial infections, specifically erythromycin, clarithromycin, telithromycin, moxifloxacin, pentamidine (these are antibiotics) • Heart problems or high blood pressure (e.g., amiodarone, dronedarone, quinidine, disopyramide, dofetilide, sotalol, diltiazem, verapamil) • Psychoses (e.g., haloperidol, pimozide, sertindole) • Depression (e.g., citalopram, escitalopram) • Gastro-intestinal disorders (e.g., cisapride, dolasetron, prucalopride) • Allergy (e.g., mequitazine, mizolastine) • Malaria (in particular halofantrine) • AIDS/HIV (protease inhibitors) • Cancer (e.g., toremifene, vandetanib, vincamine) Tell your doctor or pharmacist if you are taking drugs to treat infection, heart problems, AIDS/HIV or Parkinson’s disease. Motilium and apomorphine Before you use Motilium and apomorphine, your doctor will ensure that you tolerate both medicines when used simultaneously. Ask your doctor or specialist for a personalised advice. Please refer to the apomorphine leaflet. It is important to ask your doctor or pharmacist if Motilium is safe for you when you are taking any other medicines, including medicines obtained without prescription. Taking Motilium with food and drink It is recommended to take Motilium before meals, as when taken after meals the absorption of the medicine is slightly delayed. Pregnancy and breast-feeding Talk to your doctor or pharmacist before taking Motilium if: • You are pregnant, might become pregnant or think you may be pregnant • You are breast-feeding. It is best not to take Motilium if you are breast-feeding. Small amounts of Motilium have been detected in breast-milk. Motilium may cause unwanted side effects affecting the heart in a breast-fed baby. Motilium should be used during breast feeding only if your physician considers this clearly necessary. Ask your doctor for advice before taking this medicine. Driving and using machines: Motilium can affect your ability to drive or use machinery as it may make you sleepy. Do not drive while taking this medicine until you know how it affects you. Motilium tablets contain lactose. This medicine contains lactose. If you have been told by your doctor that you have an intolerance to some sugars, contact your doctor before taking this medicinal product. fold here 25,5mm 420 mm 148 mm 25,5mm 25,5mm 25,5mm fold here 3380 3380 3380 3380 fold here fold here


#### 3. How to take Domperidone

 

Follow these instructions closely unless your doctor has advised you otherwise. You should check with your doctor or pharmacist if you are not sure. Duration of treatment Your doctor will decide how long you will need to take this medicine.
Symptoms usually resolve with 3-4 days of taking this medicine. Do not take Motilium for longer than 7 days without consulting your doctor. Taking this medicine • Swallow the tablets whole with a drink of water. • Take the tablets 15 to 30 minutes before a meal. • Do not crush or chew them. The usual dose is: • Adults and adolescents 12 years of age and older with a body weight of 35kg or more The usual dose is one tablet taken up to three times per day, if possible before meals. Do not take more than three tablets per day. • This product is not suitable for children under 12 years of age and older with a body weight of less than 35 kg. People with kidney problems Your doctor may tell you to take a lower dose or to take the medicine less often. If you take more Motilium than you should: • If you have used or taken too many Motilium tablets contact your doctor, pharmacist or the poisons centre at your nearest hospital casualty department immediately. Take the carton and any tablets left with you. This is so the doctors know what you have taken. In the event of overdose, symptomatic treatment could be implemented. An ECG monitoring could be undertaken, because of the possibility of a heart problem called prolonged QT interval. • The signs of taking more than you should include feeling sleepy, confused, uncontrolled movements which include unusual eye movements, unusual movements of the tongue or abnormal posture (such as a twisted neck). If you forget to take Motilium: • If you forget to take Motilium, take it as soon as you remember. • However if it is almost time for the next dose, wait until that is due and then continue as normal. • Do not take a double dose to make up for a forgotten dose.


#### 4. Possible side effects

 

Like all medicines, Motilium can have side effects, although not everybody gets them. Stop taking Motilium and see your doctor or go to a hospital straightaway if: • You get swelling of the hands, feet, ankles, face, lips or throat which may cause difficulty in swallowing or breathing. You could also notice an itchy, lumpy rash (hives) or nettle rash (urticaria). This may mean you are having an allergic reaction to Motilium. • You notice any uncontrolled movements. These include irregular eye movements, unusual movements of the tongue, and abnormal posture such as a twisted neck, trembling and muscle stiffness. These symptoms should stop once you stop taking Motilium. • You have a very fast or unusual heartbeat. This could be a sign of a life-threatening heart problem. • You have a fit (seizure). Other side effects include: Common (affects less than 1 in 10 people) • Dry mouth Uncommon (affects less than 1 in 100 people) • Lowering of sexual drive (libido) in men • Feeling anxious • Feeling agitated or irritable • Feeling more nervous than usual • Feeling drowsy • Headaches • Diarrhoea • Itchy skin. You may also have a rash • Unusual production of breast milk in men and women • Painful or tender breasts • A general feeling of weakness Not known (Frequency cannot be estimated from the available data) • Disorders of the cardiovascular system: heart rhythm disorders (rapid or irregular heart beat) have been reported; if this happens, you should stop the treatment immediately. Motilium may be associ- ated with an increased risk of heart rhythm disorder and cardiac arrest. This risk may be more likely in those over 60 years old or taking doses higher than 30 mg per day. Motilium should be used at the lowest effective dose. • Abnormal eye movements • Feeling the urge to move your legs, arms or other parts of your body (restless legs syndrome). These symptoms may become worse in patients suffering from Parkinson’s disease. • Inability to urinate • Breast enlargement in men • In women, menstrual periods may be irregular or stop • A blood test shows changes in the way your liver is working. Some patients who have used Motilium for conditions and dosages requiring longer term medical supervision have experienced the following unwanted effects: Restlessness; swollen or enlarged breasts, unusual discharge from breasts, irregular menstrual periods in women, difficulty breastfeeding, depression, hypersensitivity. Reporting of side effects If you get any side effects, talk to your doctor, pharmacist or nurse. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the Yellow card Scheme at: www.mhra.gov.uk/ yellowcard or search for MHRA Yellow Card in the Google Play or Apple App Store. By reporting side effects, you can help provide more information on the safety of this medicine.


#### 5. How to store Domperidone

 

• Keep out of the sight and reach of children. • Do not store above 25°C. • Do not use this medicine after the expiry date which is stated on the pack. • Do not throw away any medicines via wastewater or household water. Ask your pharmacist how to throw away medicines you no longer use. These medicines will help protect the environment.


#### 6. Contents of the pack and other information

 

What Motilium 10mg Film-Coated Tablets contain • The active ingredient is domperidone. Each tablet contains 10 mg of domperidone. • It also contains lactose, maize starch, microcrystalline cellulose, hypromellose, pregelatinised starch, povi- done, propylene glycol, magnesium stearate, silica colloidal hydrated and polysorbate 20. What Motilium 10mg Film-Coated Tablets look like and contents of the pack Each pack contains 30 or 100 white to cream coloured, film-coated tablets with Motilium stamped on one side. Marketing Authorisation Holder: Zentiva Pharma UK Limited, 12 New Fetter Lane, London EC4A 1JP, United Kingdom Manufacturer: S.C. Zentiva S.A., 50 Theodor Pallady Blvd, District 3, Bucharest, 032266, Romania. This leaflet was last revised in: November 2023 Motilium® is a registered Trademark of Johnson & Johnson Inc. ‘Zentiva is a registered trademark © 2023 Zentiva. 942329


####  Mo 
IDS:
** gh-2 **
-------

Full name: **Mo**

 - Invented name part: ** Motillium ** 

 - Scientific name part: ** Domperidone ** 

 - Strength part: ** 10 mg ** 

 - Pharmaceutical dose form part: ** tablet ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** 4177 ** 

 Region: ** ** 

Marketing authorisation holder: **Zentiva** 

 Identifier: 
*  **xx** 
 

 Status: ** Active (2015-02-07T13:28:17Z) ** 

 Package 1 of 1

PMSWI: ** dd ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****10 

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Active ** 

 Substance: ** DOMPERIDONE ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "gh-2"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-en-c08df9bb5fb44242a6291b1eee5d09ad",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-en-c08df9bb5fb44242a6291b1eee5d09ad",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_composition-en-c08df9bb5fb44242a6291b1eee5d09ad\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-en-c08df9bb5fb44242a6291b1eee5d09ad</b></p><a name=\"composition-en-c08df9bb5fb44242a6291b1eee5d09ad\"> </a><a name=\"hccomposition-en-c08df9bb5fb44242a6291b1eee5d09ad\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/beed2bb9992ec6835c69d1ba0554b00f</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#Organization_mah-3ba8fc4ba9a20220f5e2470c283f7ae3\">Organization Zentiva</a></p><p><b>title</b>: TEST PURPOSES ONLY - Mo</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "beed2bb9992ec6835c69d1ba0554b00f"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpc08df9bb5fb44242a6291b1eee5d09ad"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-3ba8fc4ba9a20220f5e2470c283f7ae3"
      }],
      "title" : "TEST PURPOSES ONLY - Mo",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. Package Leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>PATIENT INFORMATION LEAFLET Read all of this leaflet carefully before you start taking this medicine because it contains important information for you. • Keep this leaflet. You may need to read it again. • If you have any further questions, ask your doctor or pharmacist. • This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours. • If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet (see section 4).</p></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>What is in this leaflet: 1. What Motilium is and what it is used for 2. What you need to know before you take Motilium 3. How to take Motilium 4. Possible side effects 5. How to store Motilium 6. Contents of the pack and other information</p></div>"
          }
        },
        {
          "title" : "1. What Domperidone is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What Domperidone is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">\"<ol><li>WHAT MOTILIUM IS AND WHAT IT IS USED FOR The name of your medicine is Motilium 10mg Film-Coated Tablets (called Motilium in this leaflet). Motilium contains a medicine called domperidone. This belongs to a group of medicines called ‘dopamine antagonists’. This medicine is used to treat nausea (feeling sick) and vomiting (being sick) in adults and adolescents (years of age and older weighting 35 kg or more).</li></ol>\"</div>"
          }
        },
        {
          "title" : "2. What you need to know before you take Domperidone",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take Domperidone"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Do not take Motilium tablets if: • You are allergic to domperidone or any of the other ingredients of Motilium 10mg Film-Coated Tablets (listed in section 6). Signs of an allergic reaction include: a rash, swallowing or breathing problems, swelling of your lips, face, throat or tongue. • You have a tumour of the pituitary gland (prolactinoma) • You have a blockage or tear in your intestines • You have black, tarry bowel motions (stools) or notice blood in your bowel motions. This could be a sign of bleeding in the stomach or intestines. • You have a moderate or severe liver disease. • Your ECG (electrocardiogram) shows a heart problem called “prolonged QT corrected interval”. • You have or had a problem where your heart cannot pump the blood round your body as well as it should (condition called heart failure). • You have a problem that gives you a low level of potassium or magnesium, or a high level of potassium in your blood. • You are taking certain medicines (see “Other medicines and Motilium”) Do not take Motilium if any of the above applies to you. If you are not sure, talk to your doctor or pharmacist before taking Motilium. Warnings and precautions Before taking this medicine contact your doctor if: • You suffer from liver problems (liver function impairment or failure) (see “Do not take Motilium tablets if”) • You suffer from kidney problems (kidney function impairment or failure). It is advisable to ask your doctor for advice in case of prolonged treatment as you may need to take a lower dose or take this medicine less often, and your doctor may want to examine you regularly. If you are not sure if any of the above apply to you, talk to your doctor or pharmacist before taking Motilium. Do this even if they have applied in the past. Motilium may be associated with an increased risk of heart rhythm disorder and cardiac arrest. This risk may be more likely in those over 60 years old or taking doses higher than 30 mg per day. The risk also increases when Motilium is given together with some drugs. Tell your doctor or pharmacist if you are taking drugs to treat infection (fungal infections or bacterial infection) and/or if you have heart problems or AIDS/HIV (see “Other medicines and Motilium). Motilium should be used at the lowest effective dose. While taking Motilium, contact your doctor if you experience heart rhythm disorders such as palpitations, trouble breathing, loss of consciousness. Treatment with Motilium should be stopped. Adolescents weighing less than 35 kg and children Motilium should not be given to adolescents 12 years of age and older weighing less than 35 kg, or in any children less than 12 years of age, as it is not effective in these age groups. Other medicines and Motilium Tell your doctor or pharmacist if you are taking or have recently taken any other medicines. This includes medicines you can buy without a prescription, including herbal medicines. This is because Motilium can affect the way some other medicines work. Also, some medicines can affect the way Motilium works. Do not take Motilium if you are taking medicine to treat: • Fungal infections such as azole anti-fungals, specifically oral ketoconazole, fluconazole or voriconazole. • Bacterial infections, specifically erythromycin, clarithromycin, telithromycin, moxifloxacin, pentamidine (these are antibiotics) • Heart problems or high blood pressure (e.g., amiodarone, dronedarone, quinidine, disopyramide, dofetilide, sotalol, diltiazem, verapamil) • Psychoses (e.g., haloperidol, pimozide, sertindole) • Depression (e.g., citalopram, escitalopram) • Gastro-intestinal disorders (e.g., cisapride, dolasetron, prucalopride) • Allergy (e.g., mequitazine, mizolastine) • Malaria (in particular halofantrine) • AIDS/HIV (protease inhibitors) • Cancer (e.g., toremifene, vandetanib, vincamine) Tell your doctor or pharmacist if you are taking drugs to treat infection, heart problems, AIDS/HIV or Parkinson’s disease. Motilium and apomorphine Before you use Motilium and apomorphine, your doctor will ensure that you tolerate both medicines when used simultaneously. Ask your doctor or specialist for a personalised advice. Please refer to the apomorphine leaflet. It is important to ask your doctor or pharmacist if Motilium is safe for you when you are taking any other medicines, including medicines obtained without prescription. Taking Motilium with food and drink It is recommended to take Motilium before meals, as when taken after meals the absorption of the medicine is slightly delayed. Pregnancy and breast-feeding Talk to your doctor or pharmacist before taking Motilium if: • You are pregnant, might become pregnant or think you may be pregnant • You are breast-feeding. It is best not to take Motilium if you are breast-feeding. Small amounts of Motilium have been detected in breast-milk. Motilium may cause unwanted side effects affecting the heart in a breast-fed baby. Motilium should be used during breast feeding only if your physician considers this clearly necessary. Ask your doctor for advice before taking this medicine. Driving and using machines: Motilium can affect your ability to drive or use machinery as it may make you sleepy. Do not drive while taking this medicine until you know how it affects you. Motilium tablets contain lactose. This medicine contains lactose. If you have been told by your doctor that you have an intolerance to some sugars, contact your doctor before taking this medicinal product. fold here 25,5mm 420 mm 148 mm 25,5mm 25,5mm 25,5mm fold here 3380 3380 3380 3380 fold here fold here</p></div>"
          }
        },
        {
          "title" : "3. How to take Domperidone",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take Domperidone"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Follow these instructions closely unless your doctor has advised you otherwise. You should check with your doctor or pharmacist if you are not sure. Duration of treatment Your doctor will decide how long you will need to take this medicine.<br/>Symptoms usually resolve with 3-4 days of taking this medicine. Do not take Motilium for longer than 7 days without consulting your doctor. Taking this medicine • Swallow the tablets whole with a drink of water. • Take the tablets 15 to 30 minutes before a meal. • Do not crush or chew them. The usual dose is: • Adults and adolescents 12 years of age and older with a body weight of 35kg or more The usual dose is one tablet taken up to three times per day, if possible before meals. Do not take more than three tablets per day. • This product is not suitable for children under 12 years of age and older with a body weight of less than 35 kg. People with kidney problems Your doctor may tell you to take a lower dose or to take the medicine less often. If you take more Motilium than you should: • If you have used or taken too many Motilium tablets contact your doctor, pharmacist or the poisons centre at your nearest hospital casualty department immediately. Take the carton and any tablets left with you. This is so the doctors know what you have taken. In the event of overdose, symptomatic treatment could be implemented. An ECG monitoring could be undertaken, because of the possibility of a heart problem called prolonged QT interval. • The signs of taking more than you should include feeling sleepy, confused, uncontrolled movements which include unusual eye movements, unusual movements of the tongue or abnormal posture (such as a twisted neck). If you forget to take Motilium: • If you forget to take Motilium, take it as soon as you remember. • However if it is almost time for the next dose, wait until that is due and then continue as normal. • Do not take a double dose to make up for a forgotten dose.</p></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Like all medicines, Motilium can have side effects, although not everybody gets them. Stop taking Motilium and see your doctor or go to a hospital straightaway if: • You get swelling of the hands, feet, ankles, face, lips or throat which may cause difficulty in swallowing or breathing. You could also notice an itchy, lumpy rash (hives) or nettle rash (urticaria). This may mean you are having an allergic reaction to Motilium. • You notice any uncontrolled movements. These include irregular eye movements, unusual movements of the tongue, and abnormal posture such as a twisted neck, trembling and muscle stiffness. These symptoms should stop once you stop taking Motilium. • You have a very fast or unusual heartbeat. This could be a sign of a life-threatening heart problem. • You have a fit (seizure). Other side effects include: Common (affects less than 1 in 10 people) • Dry mouth Uncommon (affects less than 1 in 100 people) • Lowering of sexual drive (libido) in men • Feeling anxious • Feeling agitated or irritable • Feeling more nervous than usual • Feeling drowsy • Headaches • Diarrhoea • Itchy skin. You may also have a rash • Unusual production of breast milk in men and women • Painful or tender breasts • A general feeling of weakness Not known (Frequency cannot be estimated from the available data) • Disorders of the cardiovascular system: heart rhythm disorders (rapid or irregular heart beat) have been reported; if this happens, you should stop the treatment immediately. Motilium may be associ- ated with an increased risk of heart rhythm disorder and cardiac arrest. This risk may be more likely in those over 60 years old or taking doses higher than 30 mg per day. Motilium should be used at the lowest effective dose. • Abnormal eye movements • Feeling the urge to move your legs, arms or other parts of your body (restless legs syndrome). These symptoms may become worse in patients suffering from Parkinson’s disease. • Inability to urinate • Breast enlargement in men • In women, menstrual periods may be irregular or stop • A blood test shows changes in the way your liver is working. Some patients who have used Motilium for conditions and dosages requiring longer term medical supervision have experienced the following unwanted effects: Restlessness; swollen or enlarged breasts, unusual discharge from breasts, irregular menstrual periods in women, difficulty breastfeeding, depression, hypersensitivity. Reporting of side effects If you get any side effects, talk to your doctor, pharmacist or nurse. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the Yellow card Scheme at: www.mhra.gov.uk/ yellowcard or search for MHRA Yellow Card in the Google Play or Apple App Store. By reporting side effects, you can help provide more information on the safety of this medicine.</p></div>"
          }
        },
        {
          "title" : "5. How to store Domperidone",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store Domperidone"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>• Keep out of the sight and reach of children. • Do not store above 25°C. • Do not use this medicine after the expiry date which is stated on the pack. • Do not throw away any medicines via wastewater or household water. Ask your pharmacist how to throw away medicines you no longer use. These medicines will help protect the environment.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>What Motilium 10mg Film-Coated Tablets contain • The active ingredient is domperidone. Each tablet contains 10 mg of domperidone. • It also contains lactose, maize starch, microcrystalline cellulose, hypromellose, pregelatinised starch, povi- done, propylene glycol, magnesium stearate, silica colloidal hydrated and polysorbate 20. What Motilium 10mg Film-Coated Tablets look like and contents of the pack Each pack contains 30 or 100 white to cream coloured, film-coated tablets with Motilium stamped on one side. Marketing Authorisation Holder: Zentiva Pharma UK Limited, 12 New Fetter Lane, London EC4A 1JP, United Kingdom Manufacturer: S.C. Zentiva S.A., 50 Theodor Pallady Blvd, District 3, Bucharest, 032266, Romania. This leaflet was last revised in: November 2023 Motilium® is a registered Trademark of Johnson &amp; Johnson Inc. ‘Zentiva is a registered trademark © 2023 Zentiva. 942329</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-domperidone-domperidone",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-domperidone-domperidone",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-domperidone-domperidone\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-domperidone-domperidone</b></p><a name=\"ingredient-for-domperidone-domperidone\"> </a><a name=\"hcingredient-for-domperidone-domperidone\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/5587267Z69 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#ManufacturedItemDefinition_mid-27c9d5187cd283f8d160ec1ed2b5ac89\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#gh-2 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#MedicinalProductDefinition_mpc08df9bb5fb44242a6291b1eee5d09ad\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#gh-2; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#AdministrableProductDefinition_ap-27c9d5187cd283f8d160ec1ed2b5ac89\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#gh-2; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 5587267Z69}\">DOMPERIDONE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "5587267Z69"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-27c9d5187cd283f8d160ec1ed2b5ac89"
      },
      {
        "reference" : "MedicinalProductDefinition/mpc08df9bb5fb44242a6291b1eee5d09ad"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-27c9d5187cd283f8d160ec1ed2b5ac89"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "5587267Z69",
              "display" : "DOMPERIDONE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-27c9d5187cd283f8d160ec1ed2b5ac89",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-27c9d5187cd283f8d160ec1ed2b5ac89",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-27c9d5187cd283f8d160ec1ed2b5ac89\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-27c9d5187cd283f8d160ec1ed2b5ac89</b></p><a name=\"ap-27c9d5187cd283f8d160ec1ed2b5ac89\"> </a><a name=\"hcap-27c9d5187cd283f8d160ec1ed2b5ac89\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/gh-2</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#MedicinalProductDefinition_mpc08df9bb5fb44242a6291b1eee5d09ad\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#gh-2; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#ManufacturedItemDefinition_mid-27c9d5187cd283f8d160ec1ed2b5ac89\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#gh-2 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "gh-2"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mpc08df9bb5fb44242a6291b1eee5d09ad"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-27c9d5187cd283f8d160ec1ed2b5ac89"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization27c9d5187cd283f8d160ec1ed2b5ac890",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization27c9d5187cd283f8d160ec1ed2b5ac890",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization27c9d5187cd283f8d160ec1ed2b5ac890\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization27c9d5187cd283f8d160ec1ed2b5ac890</b></p><a name=\"authorization27c9d5187cd283f8d160ec1ed2b5ac890\"> </a><a name=\"hcauthorization27c9d5187cd283f8d160ec1ed2b5ac890\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/4177 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#MedicinalProductDefinition_mpc08df9bb5fb44242a6291b1eee5d09ad\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#gh-2; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#Organization_mah-3ba8fc4ba9a20220f5e2470c283f7ae3\">Organization Zentiva</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "4177"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpc08df9bb5fb44242a6291b1eee5d09ad"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-3ba8fc4ba9a20220f5e2470c283f7ae3"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-3ba8fc4ba9a20220f5e2470c283f7ae3",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-3ba8fc4ba9a20220f5e2470c283f7ae3",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-3ba8fc4ba9a20220f5e2470c283f7ae3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-3ba8fc4ba9a20220f5e2470c283f7ae3</b></p><a name=\"mah-3ba8fc4ba9a20220f5e2470c283f7ae3\"> </a><a name=\"hcmah-3ba8fc4ba9a20220f5e2470c283f7ae3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/xx (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Zentiva</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>First Floor, Andrews House, College Road, Guildford, Surrey UK(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "xx"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Zentiva",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "First Floor, Andrews House, College Road, Guildford, Surrey UK",
          "line" : ["First Floor, Andrews House, College Road, Guildford,"],
          "city" : "Surrey",
          "country" : "UK"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-c40decbddc475d768d3f1dad1c6f77a4",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-c40decbddc475d768d3f1dad1c6f77a4",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-c40decbddc475d768d3f1dad1c6f77a4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-c40decbddc475d768d3f1dad1c6f77a4</b></p><a name=\"ppd-c40decbddc475d768d3f1dad1c6f77a4\"> </a><a name=\"hcppd-c40decbddc475d768d3f1dad1c6f77a4\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/dd (use: official, )</p><p><b>name</b>: Mo 28</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#MedicinalProductDefinition_mpc08df9bb5fb44242a6291b1eee5d09ad\">MedicinalProductDefinition: identifier = http://fakesys.com/ids#gh-2; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 10 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 28</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-en-27c9d5187cd283f8d160ec1ed2b5ac89.html#ManufacturedItemDefinition_mid-27c9d5187cd283f8d160ec1ed2b5ac89\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#gh-2 (use: official, ); status = active; manufacturedDoseForm = Film-coated tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "dd"
      }],
      "name" : "Mo 28",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mpc08df9bb5fb44242a6291b1eee5d09ad"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 10,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 28,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-27c9d5187cd283f8d160ec1ed2b5ac89"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mpc08df9bb5fb44242a6291b1eee5d09ad",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mpc08df9bb5fb44242a6291b1eee5d09ad",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mpc08df9bb5fb44242a6291b1eee5d09ad\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mpc08df9bb5fb44242a6291b1eee5d09ad</b></p><a name=\"mpc08df9bb5fb44242a6291b1eee5d09ad\"> </a><a name=\"hcmpc08df9bb5fb44242a6291b1eee5d09ad\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>http://fakesys.com/ids</code>/gh-2</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Mo</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Motillium</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Domperidone</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 10 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 UK}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 UK}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "http://fakesys.com/ids",
        "value" : "gh-2"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Mo",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Motillium",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "Domperidone",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "10 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "tablet",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "UK",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "UK",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-27c9d5187cd283f8d160ec1ed2b5ac89",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-27c9d5187cd283f8d160ec1ed2b5ac89",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-27c9d5187cd283f8d160ec1ed2b5ac89\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-27c9d5187cd283f8d160ec1ed2b5ac89</b></p><a name=\"mid-27c9d5187cd283f8d160ec1ed2b5ac89\"> </a><a name=\"hcmid-27c9d5187cd283f8d160ec1ed2b5ac89\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/gh-2 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073665}\">Film-coated tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "gh-2"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073665",
          "display" : "Film-coated tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      }
    }
  }]
}

```
