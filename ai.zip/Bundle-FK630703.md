# FK630703 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK630703**

## Example Bundle: FK630703

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: Informasjon til brukeren

 

# Pakningsvedlegg: Informasjon til brukeren

## NovoRapid 100 enheter/ml injeksjonsvæske, oppløsning i hetteglass

### insulin aspart


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.
* Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.
* Kontakt lege, sykepleier eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om:

 

## I dette pakningsvedlegget finner du informasjon om:

1. Hva NovoRapid er og hva det brukes mot
1. Hva du må vite før du bruker NovoRapid
1. Hvordan du bruker NovoRapid
1. Mulige bivirkninger
1. Hvordan du oppbevarer NovoRapid
1. Innholdet i pakningen og ytterligere informasjon


#### 1. Hva NovoRapid er og hva det brukes mot

 

## 1. Hva NovoRapid er og hva det brukes mot

NovoRapid er et moderne insulin (insulinanalog) med en hurtigvirkende effekt. Moderne insulinpreparater er forbedrete versjoner av humant insulin.

NovoRapid brukes til å senke det høye blodsukkernivået hos voksne, ungdom og barn fra 1 år og oppover med diabetes mellitus (diabetes). Diabetes er en sykdom hvor kroppen ikke produserer nok insulin til å kontrollere blodsukkernivået. Behandling med NovoRapid hjelper med å forhindre komplikasjoner fra din diabetes.

NovoRapid vil begynne å senke blodsukkeret ditt 10-20 minutter etter injeksjon, og har en maksimal effekt mellom 1 og 3 timer etter injeksjonen. Effekten vil vare i 3-5 timer. På grunn av den korte virketiden bør NovoRapid normalt tas i kombinasjon med middels langtidsvirkende eller langtidsvirkende insulinpreparater. Dessuten kan NovoRapid brukes til kontinuerlig infusjon i et pumpesystem.


#### 2. Hva du må vite før du bruker NovoRapid

 

## 2. Hva du må vite før du bruker NovoRapid


#### 3. Hvordan du bruker NovoRapid

 

## 3. Hvordan du bruker NovoRapid

Dose og når skal du ta insulin
Bruk alltid insulinet og innstill dosen din nøyaktig slik legen har fortalt deg. Kontakt lege, sykepleier eller apotek hvis du er usikker.

NovoRapid tas vanligvis rett før et måltid. Spis et måltid eller mellommåltid innen 10 minutter etter injeksjonen for å unngå lavt blodsukker (føling). Om nødvendig, kan NovoRapid gis umiddelbart etter et måltid. For informasjon se under Hvordan og hvor skal det injiseres.

Ikke skift insulinet ditt med mindre legen din har gitt deg beskjed om det. Skifte av insulintype eller - merke kan medføre at legen vil justere dosen.

Bruk hos barn og ungdom
NovoRapid kan brukes til ungdom og barn fra 1 år og oppover i stedet for hurtigvirkende humant insulin der en rask innsettende virkning er å foretrekke, som for eksempel når det er vanskelig med insulindosering i forbindelse med barnets måltider.

Bruk hos spesielle pasientgrupper
Dersom du har redusert nyre- eller leverfunksjon eller dersom du er over 65 år, må du kontrollere blodsukkeret ditt mer regelmessig og diskutere endringer av insulindosen med legen.

Hvordan og hvor skal det injiseres
NovoRapid er beregnet til injeksjon under huden (subkutant), eller til kontinuerlig infusjon i et pumpesystem. Administrering i et pumpesystem vil kreve en omfattende opplæring fra helsepersonellet. Du må aldri selv injisere direkte i en blodåre (intravenøst) eller muskel (intramuskulært). Om nødvendig kan NovoRapid gis direkte i en blodåre, men dette må bare gjøres av leger eller annet helsepersonell.

For hver injeksjon bytt injeksjonssted innenfor det bestemte hudområdet du bruker. Dette kan redusere risikoen for utvikling av kuler eller fordypninger i huden (se avsnitt 4, Mulige bivirkninger). De stedene på kroppen som egner seg best for injeksjon er: foran ved midjen (magen), på overarmen eller foran på lårene. Effekten av insulinet inntrer raskere hvis det injiseres foran ved midjen. Du bør alltid måle blodsukkeret regelmessig.

NPH-insulin (nøytralt protamin Hagedorn-insulin) er den eneste insulintypen som kan blandes med NovoRapid, og blandingen må injiseres umiddelbart under huden (subkutant). NovoRapid skal trekkes inn i sprøyten før NPH-insulinet trekkes inn.

Hvordan du bruker NovoRapid

Hvis du kun bruker en type insulin
1. Trekk inn den mengde med luft i sprøyten som tilsvarer den dosen insulin du skal ta. Injiser luften i hetteglasset.
1. Snu hetteglasset og sprøyten opp ned, og trekk riktig dose insulin inn i sprøyten. Trekk nålen ut av hetteglasset. Fjern deretter luften fra sprøyten og kontroller at dosen er riktig.

Hvis du må blande to typer insulin
1. Rett før bruk rulles hetteglasset med NPH-insulin mellom hendene inntil væsken er jevnt hvit og uklar.
1. Trekk inn den mengde med luft i sprøyten som tilsvarer den dosen med NPH-insulin du skal ta. Injiser luften i hetteglasset med NPH-insulin og trekk deretter ut nålen.
1. Trekk inn den mengde med luft i sprøyten som tilsvarer den dosen med NovoRapid du skal ta. Injiser luften i hetteglasset med NovoRapid. Snu deretter hetteglasset og sprøyten opp ned og trekk foreskrevet dose NovoRapid inn i sprøyten. Fjern all luft fra sprøyten og kontroller at dosen er riktig.
1. Skyv nålen inn i hetteglasset med NPH-insulin. Snu deretter hetteglasset og sprøyten opp ned og trekk foreskrevet dose inn i sprøyten. Fjern all luft fra sprøyten og kontroller dosen. Injiser blandingen umiddelbart.
1. Bland alltid NovoRapid og NPH-insulin i denne rekkefølge.

Hvordan injisere NovoRapid

* Injiser insulinet under huden. Følg legens eller sykepleierens råd angående injeksjonsteknikk.
* Hold nålen under huden i minst 6 sekunder for å sikre at hele insulindosen er injisert.
* Kast nålen etter hver injeksjon.

Ved bruk i et infusjonspumpesystem
NovoRapid må aldri blandes med noe annet insulin når det brukes i en insulinpumpe.

Følg legens instruksjoner og anbefalinger vedrørende bruk av NovoRapid i pumpe. Før bruk av NovoRapid i pumpesystemet skal du ha fått en omfattende opplæring i bruk og informasjon om hva som skal gjøres ved sykdom, for høyt eller for lavt blodsukker eller feil med pumpesystemet.
* Før innsetting av nålen vaskes hendene og huden der nålen skal settes inn, med såpe og vann for å unngå infeksjon på infusjonsstedet.
* Når du fyller et nytt reservoar må du forvisse deg om at det ikke er igjen store luftbobler hverken i sprøyten eller i kateteret.
* Bytte av infusjonssettet (kateter og nål) må utføres i henhold til instruksene som er i bruksanvisningen vedlagt infusjonssettet.

For å oppnå fordel av insulininfusjonen og for å oppdage mulige feil med insulinpumpen, anbefales det at du måler blodsukkeret jevnlig.

Hva skal gjøres hvis det oppstår feil med pumpesystemet
Du bør alltid ha tilgjengelig et alternativt injeksjonsystem for ditt insulin for injisering under huden i tilfelle det oppstår feil med pumpesystemet.


#### 4. Mulige bivirkninger

 

## 4. Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.

a) Sammendrag av alvorlige og svært vanlige bivirkninger

**Lavt blodsukker (føling, hypoglykemi) **er en svært vanlig bivirkning. Den kan berøre flere enn 1 av 10 personer.

Lavt blodsukker kan inntreffe hvis du:
* Injiserer for mye insulin.
* Spiser for lite eller hopper over et måltid.
* Mosjonerer mer enn vanlig.
* Drikker alkohol (se Inntak av alkohol sammen med NovoRapid under avsnitt 2).

Symptomer på lavt blodsukker:Kaldsvetting, kald og blek hud, hodepine, hjertebank, kvalme, usedvanlig stor sultfølelse, forbigående synsforstyrrelser, døsighet, unormal tretthet og svakhet, nervøsitet eller skjelving, angst, forvirring og konsentrasjonsproblemer.

Alvorlig lavt blodsukker kan føre til bevisstløshet. Dersom langvarig alvorlig lavt blodsukker ikke behandles, kan det føre til hjerneskade (midlertidig eller livsvarig) og til og med død. Du kan komme raskere til bevissthet igjen hvis du får en injeksjon av hormonet glukagon av en person som er blitt instruert i hvordan det skal brukes. Dersom glukagon er injisert, må du så snart du kommer til bevissthet få glukose eller et sukkerholdig mellommåltid. Hvis du ikke reagerer på glukagonbehandling, må du behandles ved et sykehus.

Hva skal du gjøre hvis du får lavt blodsukker:
* Dersom du opplever lavt blodsukker, spis glukosetabletter eller et annet mellommåltid med høyt sukkerinnhold (for eksempel søtsaker, kjeks, fruktjuice). Hvis mulig, mål blodsukkeret ditt og ta en hvil. For sikkerhets skyld må du alltid ha med deg glukosetabletter eller et mellommåltid med høyt sukkerinnhold.
* Når symptomer på lavt blodsukker har forsvunnet, eller når blodsukkernivået er stabilisert, fortsettes insulinbehandlingen som vanlig.
* Dersom du får et så lavt blodsukker at du besvimer, dersom du har hatt behov for en injeksjon av glukagon, eller dersom du har hatt gjentatte episoder med lavt blodsukker skal du snakke med legen. Det kan være nødvendig å justere insulindosen, tidspunktet for insulindosering, matinntak eller mengde fysisk aktivitet.

Fortell relevante personer at du har diabetes og hva konsekvensene kan være, inkludert risikoen for å besvime (bli bevisstløs) på grunn av lavt blodsukker. La dem få vite at hvis du besvimer må de legge deg i stabilt sideleie og tilkalle lege med det samme. De må ikke gi deg noe å spise eller drikke på grunn av risiko for kvelning.

**Alvorlige allergiske reaksjoner **overfor NovoRapid eller et av innholdsstoffene i preparatet (en såkalt systemisk allergisk reaksjon) er en svært sjelden bivirkning, men kan potensielt være livstruende. Den kan berøre færre enn 1 av 10 000 personer.

Søk råd hos helsepersonell omgående:
* Dersom symptomene på allergi sprer seg til andre deler av kroppen.
* Dersom du plutselig føler deg dårlig og du: begynner å svette, blir kvalm (kaster opp), får pustebesvær, får hjertebank, føler deg svimmel.
* Dersom du merker noen av disse symptomene, søk råd hos helsepersonell omgående.

**Hudforandringer på injeksjonsstedet: **Fettvevet kan skrumpe (lipoatrofi) eller fortykkes (lipohypertrofi) (kan berøre færre enn 1 av 100 personer) hvis du injiserer insulin på samme sted. Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete, innskrumpet eller fortykket område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.

b) Liste over andre bivirkninger

**Mindre vanlige bivirkninger**

Kan berøre færre enn 1 av 100 personer.

Symptomer på allergi:Lokale allergiske reaksjoner (smerte, rødhet, elveblest, inflammasjon, blåmerker, hevelse og kløe) på injeksjonsstedet kan forekomme. Disse forsvinner vanligvis i løpet av få uker ved fortsatt bruk av insulinet. Hvis de ikke forsvinner, eller det sprer seg over hele kroppen, snakk med lege omgående. Se også Alvorlige allergiske reaksjoner ovenfor.

Synsforstyrrelser:Synsforstyrrelser kan oppstå i begynnelsen av en insulinbehandling, men er vanligvis av forbigående karakter.

Hovne ledd:Når du begynner insulinbehandlingen, kan væskeansamling forårsake hevelse rundt ankler og andre ledd. Dette er normalt av forbigående karakter, hvis ikke, snakk med legen.

Diabetisk retinopati(en øyesykdom relatert til diabetes som kan føre til synstap): Dersom du har diabetisk retinopati og blodsukkernivået ditt forbedres veldig raskt, kan retinopatien bli verre. Spør legen om dette.

Sjeldne bivirkninger
Kan berøre færre enn 1 av 1000 personer.

Smertefull neuropati(smerte som skyldes nerveskade): Hvis blodsukkernivået ditt forbedres veldig raskt kan du få en nerverelatert smerte. Dette kalles akutt smertefull neuropati og er vanligvis forbigående.

c) Følger ved diabetes
Høyt blodsukker (hyperglykemi)

Høyt blodsukker kan inntreffe hvis du:
* Ikke har injisert nok insulin.
* Glemmer å ta insulin eller avbryter behandlingen med insulin.
* Gjentatte ganger tar mindre insulin enn det du trenger.
* Får en infeksjon og/eller feber.
* Spiser mer enn vanlig.
* Mosjonerer mindre enn vanlig.

Varselsymptomer på høyt blodsukker:

Varselsymptomene utvikler seg gradvis. De inkluderer: økt vannlating, tørste, manglende appetitt, uvelhet (kvalme eller oppkast), døsighet eller tretthet, rødmende hud, tørr hud, munntørrhet og fruktluktende (acetonluktende) ånde.

Hva gjør du hvis du får høyt blodsukker:
* Dersom du får noen av symptomene nevnt ovenfor: kontroller blodsukkernivået, hvis mulig kontroller urinen for ketoner, søk deretter råd hos helsepersonell omgående.
* Dette kan være symptomer på en meget alvorlig tilstand kalt diabetisk ketoacidose (opphopning av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Dersom den ikke behandles, kan den føre til diabetisk koma og til slutt død.


#### 5. Hvordan du oppbevarer NovoRapid

 

## 5. Hvordan du oppbevarer NovoRapid

Oppbevares utilgjengelig for barn.

Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på hetteglassets etikett og eske etter “EXP”. Utløpsdatoen er den siste dagen i den angitte måneden.

Oppbevar hetteglasset i ytteremballasjen for å beskytte det mot lys.

**Før anbrudd: **Oppbevares i kjøleskap 2-8ºC, borte fra kjøleelementet. Skal ikke fryses.

**Under bruk eller medbrakt som reserve: **Preparatet kan oppbevares i opptil 4 uker. Oppbevares ved høyst 30ºC. Skal ikke oppbevares i kjøleskap eller fryses.

Kast nålen etter hver injeksjon.

Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.


#### 6. Innholdet i pakningen og ytterligere informasjon

 

## 6. Innholdet i pakningen og ytterligere informasjon


####  NovoRapid inj, oppl 100 E/ml 
LEGEMIDDELMERKEVAREID:
** ID_C72E0BDC-52DB-4D5F-9E17-29CE2977DA1D **
-------

Full name: **NovoRapid inj, oppl 100 E/ml**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_7204E0F5-CEC4-4EE5-8553-2BA28256E4A6 ** 

VARENUMMER: ** 093856 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK630703",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "630703"
  },
  "type" : "document",
  "timestamp" : "2023-03-20T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK630703-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK630703-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK630703-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK630703-COMP</b></p><a name=\"FK630703-COMP\"> </a><a name=\"hcFK630703-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/630703</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2023-03-20</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: NovoRapid Novo Nordisk hetteglass</p></div>"
      },
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "630703"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-93"
      }],
      "date" : "2023-03-20",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "NovoRapid Novo Nordisk hetteglass",
      "section" : [{
        "title" : "Pakningsvedlegg: Informasjon til brukeren",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: Informasjon til brukeren</h1><h2>NovoRapid 100 enheter/ml injeksjonsvæske, oppløsning i hetteglass</h2><h3>insulin aspart</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.</li><li>Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.</li><li>Kontakt lege, sykepleier eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om:",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om:</h2><div class=\"paragraph\"><ol><li>Hva NovoRapid er og hva det brukes mot</li><li>Hva du må vite før du bruker NovoRapid</li><li>Hvordan du bruker NovoRapid</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer NovoRapid</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "1. Hva NovoRapid er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>1. Hva NovoRapid er og hva det brukes mot</h2><div class=\"paragraph\">NovoRapid er et moderne insulin (insulinanalog) med en hurtigvirkende effekt. Moderne insulinpreparater er forbedrete versjoner av humant insulin.</div><div class=\"paragraph\">NovoRapid brukes til å senke det høye blodsukkernivået hos voksne, ungdom og barn fra 1 år og oppover med diabetes mellitus (diabetes). Diabetes er en sykdom hvor kroppen ikke produserer nok insulin til å kontrollere blodsukkernivået. Behandling med NovoRapid hjelper med å forhindre komplikasjoner fra din diabetes.</div><div class=\"paragraph\">NovoRapid vil begynne å senke blodsukkeret ditt 10-20 minutter etter injeksjon, og har en maksimal effekt mellom 1 og 3 timer etter injeksjonen. Effekten vil vare i 3-5 timer. På grunn av den korte virketiden bør NovoRapid normalt tas i kombinasjon med middels langtidsvirkende eller langtidsvirkende insulinpreparater. Dessuten kan NovoRapid brukes til kontinuerlig infusjon i et pumpesystem.</div></div>"
          }
        },
        {
          "title" : "2. Hva du må vite før du bruker NovoRapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>2. Hva du må vite før du bruker NovoRapid</h2></div>"
          },
          "section" : [{
            "title" : "Bruk ikke NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Bruk ikke NovoRapid</h3><div class=\"paragraph\"><ul><li>Dersom du er allergisk overfor insulin aspart eller noen av de andre innholdsstoffene i dette legemidlet (listet opp i avsnitt 6, Innholdet i pakningen og ytterligere informasjon).</li><li>Dersom du tror at du begynner å få føling (hypoglykemi, lavt blodsukker) (se a) Sammendrag av alvorlige og svært vanlige bivirkninger under avsnitt 4).</li><li>Dersom beskyttelseshetten er løs eller mangler. Hvert hetteglass har en beskyttende, garantiforseglet plasthette. Hvis hetteglasset ikke er i perfekt stand når du mottar det, skal hetteglasset returneres til apoteket.</li><li>Dersom det ikke har vært riktig oppbevart, eller dersom det har vært frosset <b>(</b>se avsnitt 5, Hvordan du oppbevarer NovoRapid).</li><li>Dersom insulinet ikke fremstår som klart og fargeløst.</li></ul></div><div class=\"paragraph\">Bruk ikke NovoRapid hvis noe av dette forekommer. Snakk med lege, sykepleier eller apotek.</div><span class=\"inline-title\">Før du bruker NovoRapid</span><div class=\"paragraph\"><ul><li>Kontroller etiketten for å forsikre deg om at det er riktig type insulin.</li><li>Fjern beskyttelseshetten.</li><li>Bruk alltid en ny nål til hver injeksjon for å unngå urenheter.</li><li>Nåler og sprøyter må ikke deles med andre.</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler</h3><div class=\"paragraph\">Noen tilstander og aktiviteter kan påvirke insulinbehovet ditt. Rådfør deg med lege:<ul><li>Dersom du har nyre- eller leverproblemer, eller problemer med binyrene, hypofysen eller skjoldbruskkjertelen.</li><li>Dersom du mosjonerer mer enn vanlig eller hvis du ønsker å endre ditt vanlige kosthold, da dette kan påvirke blodsukkernivået ditt.</li><li>Dersom du er syk, fortsett å ta insulin og rådfør deg med lege.</li><li>Dersom du skal reise utenlands, tidsforskjellen mellom ulike land kan påvirke insulinbehovet og tidspunktene for dine injeksjoner.</li></ul></div><span class=\"inline-title\">Hudforandringer på injeksjonsstedet</span><div class=\"paragraph\">Injeksjonsstedet bør roteres for å bidra til å forebygge forandringer i fettvevet under huden, som f.eks. fortykning av huden, innskrumping av huden eller kuler under huden. Det kan hende at insulinet ikke virker så godt hvis du injiserer det på et klumpete, innskrumpet eller fortykket sted på huden (se avsnitt 3, ”Hvordan du bruker NovoRapid”). Snakk med legen din hvis du merker noen hudforandringer på injeksjonsstedet. Hvis du pleier å injisere på områder med reaksjoner og vil endre injeksjonssted til et annet område, må du snakke med legen din først. Legen din kan gi deg beskjed om å kontrollere blodsukkeret ditt mer nøye og å justere dosen på insulinet ditt eller andre legemidler du bruker mot diabetes.</div></div>"
            }
          },
          {
            "title" : "Barn og ungdom",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029899"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Barn og ungdom</h3><div class=\"paragraph\">Ikke gi dette legemidlet til barn under 1 år, da det ikke er utført kliniske studier hos barn under 1 år.</div></div>"
            }
          },
          {
            "title" : "Andre legemidler og NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og NovoRapid</h3><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler.<br/>Noen legemidler påvirker blodsukkernivået, og dette kan bety at insulindosen må endres. Nedenfor følger en oversikt over de vanligste legemidlene som kan påvirke insulinbehandlingen din.</div><div class=\"paragraph\"><span class=\"underline\">Blodsukkernivået ditt kan synke (hypoglykemi, føling) dersom du bruker:</span><ul><li>Andre medisiner til behandling av diabetes</li><li>Monoaminoksidasehemmere (MAOH) (brukes til behandling av depresjon)</li><li>Betablokkere (brukes til behandling av høyt blodtrykk)</li><li>Angiotensinkonverterende enzym (ACE)-hemmere (brukes til behandling av visse hjertelidelser eller høyt blodtrykk)</li><li>Salisylater (brukes til å lindre smerte og som febernedsettende)</li><li>Anabole steroider (slik som testosteron)</li><li>Sulfonamider (brukes til behandling av infeksjoner).</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Blodsukkernivået ditt kan stige (hyperglykemi) dersom du bruker:</span><ul><li>Orale antikonsepsjonsmidler (p-piller)</li><li>Tiazider (brukes til behandling av høyt blodtrykk eller ved omfattende væskeopphopning)</li><li>Glukokortikoider (slik som ”kortison”, som brukes til behandling av inflammasjon)</li><li>Thyreoideahormoner (brukes til behandling av sykdommer i skjoldbruskkjertelen)</li><li>Sympatomimetika (som adrenalin eller salbutamol, terbutalin som brukes til behandling av astma)</li><li>Veksthormon (legemiddel til stimulering av skjelett- og kroppslig vekst og med omfattende påvirkning på kroppens stoffskifteprosesser)</li><li>Danazol (legemiddel som påvirker eggløsningen).</li></ul></div><div class=\"paragraph\">Oktreotid og lanreotid (brukes til behandling av akromegali, en sjelden hormonell sykdom som vanligvis oppstår hos middelaldrende voksne og som kommer av at hypofysen produserer for mye veksthormon) kan enten øke eller senke blodsukkernivået ditt.</div><div class=\"paragraph\">Betablokkere (brukes til behandling av høyt blodtrykk) kan svekke eller fullstendig dempe de første varselsymptomene som hjelper deg til å gjenkjenne lavt blodsukker.</div><div class=\"paragraph\"><span class=\"underline\">Pioglitazon (tabletter brukt til behandling av type 2 diabetes)</span><br/>Noen pasienter med mangeårig type 2 diabetes og hjertesykdom eller som har hatt slag og som ble behandlet med pioglitazon og insulin, utviklet hjertesvikt. Snakk med lege så snart som mulig hvis du opplever tegn på hjertesvikt slik som uvanlig kortpustethet eller rask vektøkning eller lokale væskeansamlinger (hevelse i bena, ødem).</div><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek dersom du bruker noen av legemidlene som er nevnt her.</div></div>"
            }
          },
          {
            "title" : "Inntak av alkohol sammen med NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029901"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Inntak av alkohol sammen med NovoRapid</h3><div class=\"paragraph\"><ul><li>Dersom du drikker alkohol, kan behovet for insulin endre seg fordi blodsukkernivået enten kan stige eller synke. Nøye blodsukkerkontroll anbefales.</li></ul></div></div>"
            }
          },
          {
            "title" : "Graviditet og amming",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet og amming</h3><div class=\"paragraph\"><ul><li>Snakk med lege før du tar dette legemidlet dersom du er gravid, tror at du kan være gravid eller planlegger å bli gravid. NovoRapid kan brukes under graviditet. Det kan være behov for å endre insulindosen under svangerskapet og etter fødselen. Det er viktig med nøye kontroll av din diabetes, særlig er det viktig å forhindre føling, dette for ditt barns helse.</li><li>Det er ingen restriksjoner for behandling med NovoRapid under amming.</li></ul></div><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek før du tar dette legemidlet dersom du er gravid eller ammer.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\"><ul><li>Spør legen om du kan kjøre bil eller betjene en maskin:<ul><li>Dersom du ofte får føling.</li><li>Dersom du har problemer med å gjenkjenne føling.</li></ul></li></ul></div><div class=\"paragraph\">Dersom blodsukkeret ditt er lavt eller høyt, kan det påvirke konsentrasjons- og reaksjonsevnen og derfor også evnen til å kjøre eller betjene en maskin. Tenk på at du kan utsette deg selv eller andre for fare.</div><div class=\"paragraph\">NovoRapid har en hurtig innsettende effekt, derfor kan du, hvis føling inntreffer, merke den tidligere enn etter en injeksjon med hurtigvirkende humant insulin.</div></div>"
            }
          },
          {
            "title" : "Viktig informasjon om noen av innholdsstoffene i NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Viktig informasjon om noen av innholdsstoffene i NovoRapid</h3><div class=\"paragraph\">NovoRapid inneholder mindre enn 1 mmol natrium (23 mg) pr. dose, det vil si at NovoRapid praktisk talt er ”natriumfritt”.</div></div>"
            }
          }]
        },
        {
          "title" : "3. Hvordan du bruker NovoRapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>3. Hvordan du bruker NovoRapid</h2><span class=\"inline-title\">Dose og når skal du ta insulin</span><div class=\"paragraph\">Bruk alltid insulinet og innstill dosen din nøyaktig slik legen har fortalt deg. Kontakt lege, sykepleier eller apotek hvis du er usikker.<br/>NovoRapid tas vanligvis rett før et måltid. Spis et måltid eller mellommåltid innen 10 minutter etter injeksjonen for å unngå lavt blodsukker (føling). Om nødvendig, kan NovoRapid gis umiddelbart etter et måltid. For informasjon se under Hvordan og hvor skal det injiseres.</div><div class=\"paragraph\">Ikke skift insulinet ditt med mindre legen din har gitt deg beskjed om det. Skifte av insulintype eller - merke kan medføre at legen vil justere dosen.</div><span class=\"inline-title\">Bruk hos barn og ungdom</span><div class=\"paragraph\">NovoRapid kan brukes til ungdom og barn fra 1 år og oppover i stedet for hurtigvirkende humant insulin der en rask innsettende virkning er å foretrekke, som for eksempel når det er vanskelig med insulindosering i forbindelse med barnets måltider.</div><span class=\"inline-title\">Bruk hos spesielle pasientgrupper</span><div class=\"paragraph\">Dersom du har redusert nyre- eller leverfunksjon eller dersom du er over 65 år, må du kontrollere blodsukkeret ditt mer regelmessig og diskutere endringer av insulindosen med legen.</div><span class=\"inline-title\">Hvordan og hvor skal det injiseres</span><div class=\"paragraph\">NovoRapid er beregnet til injeksjon under huden (subkutant), eller til kontinuerlig infusjon i et pumpesystem. Administrering i et pumpesystem vil kreve en omfattende opplæring fra helsepersonellet. Du må aldri selv injisere direkte i en blodåre (intravenøst) eller muskel (intramuskulært). Om nødvendig kan NovoRapid gis direkte i en blodåre, men dette må bare gjøres av leger eller annet helsepersonell.</div><div class=\"paragraph\">For hver injeksjon bytt injeksjonssted innenfor det bestemte hudområdet du bruker. Dette kan redusere risikoen for utvikling av kuler eller fordypninger i huden (se avsnitt 4, Mulige bivirkninger). De stedene på kroppen som egner seg best for injeksjon er: foran ved midjen (magen), på overarmen eller foran på lårene. Effekten av insulinet inntrer raskere hvis det injiseres foran ved midjen. Du bør alltid måle blodsukkeret regelmessig.</div><div class=\"paragraph\">NPH-insulin (nøytralt protamin Hagedorn-insulin) er den eneste insulintypen som kan blandes med NovoRapid, og blandingen må injiseres umiddelbart under huden (subkutant). NovoRapid skal trekkes inn i sprøyten før NPH-insulinet trekkes inn.</div><span class=\"inline-title\">Hvordan du bruker NovoRapid</span><div class=\"paragraph\"><span class=\"underline\">Hvis du kun bruker en type insulin</span><ol><li>Trekk inn den mengde med luft i sprøyten som tilsvarer den dosen insulin du skal ta. Injiser luften i hetteglasset.</li><li>Snu hetteglasset og sprøyten opp ned, og trekk riktig dose insulin inn i sprøyten. Trekk nålen ut av hetteglasset. Fjern deretter luften fra sprøyten og kontroller at dosen er riktig.</li></ol></div><div class=\"paragraph\"><span class=\"underline\">Hvis du må blande to typer insulin</span><ol><li>Rett før bruk rulles hetteglasset med NPH-insulin mellom hendene inntil væsken er jevnt hvit og uklar.</li><li>Trekk inn den mengde med luft i sprøyten som tilsvarer den dosen med NPH-insulin du skal ta. Injiser luften i hetteglasset med NPH-insulin og trekk deretter ut nålen.</li><li>Trekk inn den mengde med luft i sprøyten som tilsvarer den dosen med NovoRapid du skal ta. Injiser luften i hetteglasset med NovoRapid. Snu deretter hetteglasset og sprøyten opp ned og trekk foreskrevet dose NovoRapid inn i sprøyten. Fjern all luft fra sprøyten og kontroller at dosen er riktig.</li><li>Skyv nålen inn i hetteglasset med NPH-insulin. Snu deretter hetteglasset og sprøyten opp ned og trekk foreskrevet dose inn i sprøyten. Fjern all luft fra sprøyten og kontroller dosen. Injiser blandingen umiddelbart.</li><li>Bland alltid NovoRapid og NPH-insulin i denne rekkefølge.</li></ol></div><span class=\"inline-title\">Hvordan injisere NovoRapid</span><div class=\"paragraph\"><ul><li>Injiser insulinet under huden. Følg legens eller sykepleierens råd angående injeksjonsteknikk.</li><li>Hold nålen under huden i minst 6 sekunder for å sikre at hele insulindosen er injisert.</li><li>Kast nålen etter hver injeksjon.</li></ul></div><span class=\"inline-title\">Ved bruk i et infusjonspumpesystem</span><div class=\"paragraph\">NovoRapid må aldri blandes med noe annet insulin når det brukes i en insulinpumpe.<br/>Følg legens instruksjoner og anbefalinger vedrørende bruk av NovoRapid i pumpe. Før bruk av NovoRapid i pumpesystemet skal du ha fått en omfattende opplæring i bruk og informasjon om hva som skal gjøres ved sykdom, for høyt eller for lavt blodsukker eller feil med pumpesystemet.<ul><li>Før innsetting av nålen vaskes hendene og huden der nålen skal settes inn, med såpe og vann for å unngå infeksjon på infusjonsstedet.</li><li>Når du fyller et nytt reservoar må du forvisse deg om at det ikke er igjen store luftbobler hverken i sprøyten eller i kateteret.</li><li>Bytte av infusjonssettet (kateter og nål) må utføres i henhold til instruksene som er i bruksanvisningen vedlagt infusjonssettet.</li></ul></div><div class=\"paragraph\">For å oppnå fordel av insulininfusjonen og for å oppdage mulige feil med insulinpumpen, anbefales det at du måler blodsukkeret jevnlig.</div><span class=\"inline-title\">Hva skal gjøres hvis det oppstår feil med pumpesystemet</span><div class=\"paragraph\">Du bør alltid ha tilgjengelig et alternativt injeksjonsystem for ditt insulin for injisering under huden i tilfelle det oppstår feil med pumpesystemet.</div></div>"
          },
          "section" : [{
            "title" : "Dersom du tar for mye insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029907"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du tar for mye insulin</h3><div class=\"paragraph\">Dersom du tar for mye insulin blir blodsukkeret for lavt (hypoglykemi). Se a) Sammendrag av alvorlige og svært vanlige bivirkninger under avsnitt 4.</div></div>"
            }
          },
          {
            "title" : "Dersom du har glemt å ta insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029908"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du har glemt å ta insulin</h3><div class=\"paragraph\">Dersom du glemmer å ta insulinet ditt kan blodsukkeret bli for høyt (hyperglykemi). Se c) Følger ved diabetes under avsnitt 4.</div></div>"
            }
          },
          {
            "title" : "Dersom du avbryter behandling med insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029909"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du avbryter behandling med insulin</h3><div class=\"paragraph\">Ikke slutt med å ta insulin uten å snakke med en lege, som vil fortelle deg hva som må gjøres. Dette kan føre til veldig høyt blodsukker (alvorlig hyperglykemi) og ketoacidose. Se c) Følger ved diabetes under avsnitt 4.</div><div class=\"paragraph\">Spør lege, sykepleier eller apotek dersom du har noen spørsmål om bruken av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "4. Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>4. Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.</div><span class=\"inline-title\">a) Sammendrag av alvorlige og svært vanlige bivirkninger</span><div class=\"paragraph\"><b>Lavt blodsukker (føling, hypoglykemi) </b>er en svært vanlig bivirkning. Den kan berøre flere enn 1 av 10 personer.</div><div class=\"paragraph\"><span class=\"underline\">Lavt blodsukker kan inntreffe hvis du:</span><ul><li>Injiserer for mye insulin.</li><li>Spiser for lite eller hopper over et måltid.</li><li>Mosjonerer mer enn vanlig.</li><li>Drikker alkohol (se Inntak av alkohol sammen med NovoRapid under avsnitt 2).</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Symptomer på lavt blodsukker:</span> Kaldsvetting, kald og blek hud, hodepine, hjertebank, kvalme, usedvanlig stor sultfølelse, forbigående synsforstyrrelser, døsighet, unormal tretthet og svakhet, nervøsitet eller skjelving, angst, forvirring og konsentrasjonsproblemer.</div><div class=\"paragraph\">Alvorlig lavt blodsukker kan føre til bevisstløshet. Dersom langvarig alvorlig lavt blodsukker ikke behandles, kan det føre til hjerneskade (midlertidig eller livsvarig) og til og med død. Du kan komme raskere til bevissthet igjen hvis du får en injeksjon av hormonet glukagon av en person som er blitt instruert i hvordan det skal brukes. Dersom glukagon er injisert, må du så snart du kommer til bevissthet få glukose eller et sukkerholdig mellommåltid. Hvis du ikke reagerer på glukagonbehandling, må du behandles ved et sykehus.</div><div class=\"paragraph\"><span class=\"underline\">Hva skal du gjøre hvis du får lavt blodsukker:</span><ul><li>Dersom du opplever lavt blodsukker, spis glukosetabletter eller et annet mellommåltid med høyt sukkerinnhold (for eksempel søtsaker, kjeks, fruktjuice). Hvis mulig, mål blodsukkeret ditt og ta en hvil. For sikkerhets skyld må du alltid ha med deg glukosetabletter eller et mellommåltid med høyt sukkerinnhold.</li><li>Når symptomer på lavt blodsukker har forsvunnet, eller når blodsukkernivået er stabilisert, fortsettes insulinbehandlingen som vanlig.</li><li>Dersom du får et så lavt blodsukker at du besvimer, dersom du har hatt behov for en injeksjon av glukagon, eller dersom du har hatt gjentatte episoder med lavt blodsukker skal du snakke med legen. Det kan være nødvendig å justere insulindosen, tidspunktet for insulindosering, matinntak eller mengde fysisk aktivitet.</li></ul></div><div class=\"paragraph\">Fortell relevante personer at du har diabetes og hva konsekvensene kan være, inkludert risikoen for å besvime (bli bevisstløs) på grunn av lavt blodsukker. La dem få vite at hvis du besvimer må de legge deg i stabilt sideleie og tilkalle lege med det samme. De må ikke gi deg noe å spise eller drikke på grunn av risiko for kvelning.</div><div class=\"paragraph\"><b>Alvorlige allergiske reaksjoner </b>overfor NovoRapid eller et av innholdsstoffene i preparatet (en såkalt systemisk allergisk reaksjon) er en svært sjelden bivirkning, men kan potensielt være livstruende. Den kan berøre færre enn 1 av 10 000 personer.</div><div class=\"paragraph\">Søk råd hos helsepersonell omgående:<ul><li>Dersom symptomene på allergi sprer seg til andre deler av kroppen.</li><li>Dersom du plutselig føler deg dårlig og du: begynner å svette, blir kvalm (kaster opp), får pustebesvær, får hjertebank, føler deg svimmel.<ul><li>Dersom du merker noen av disse symptomene, søk råd hos helsepersonell omgående.</li></ul></li></ul></div><div class=\"paragraph\"><b>Hudforandringer på injeksjonsstedet: </b>Fettvevet kan skrumpe (lipoatrofi) eller fortykkes (lipohypertrofi) (kan berøre færre enn 1 av 100 personer) hvis du injiserer insulin på samme sted. Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete, innskrumpet eller fortykket område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.</div><span class=\"inline-title\">b) Liste over andre bivirkninger</span><div class=\"paragraph\"><b>Mindre vanlige bivirkninger</b><br/>Kan berøre færre enn 1 av 100 personer.</div><div class=\"paragraph\"><span class=\"underline\">Symptomer på allergi:</span> Lokale allergiske reaksjoner (smerte, rødhet, elveblest, inflammasjon, blåmerker, hevelse og kløe) på injeksjonsstedet kan forekomme. Disse forsvinner vanligvis i løpet av få uker ved fortsatt bruk av insulinet. Hvis de ikke forsvinner, eller det sprer seg over hele kroppen, snakk med lege omgående. Se også Alvorlige allergiske reaksjoner ovenfor.</div><div class=\"paragraph\"><span class=\"underline\">Synsforstyrrelser:</span> Synsforstyrrelser kan oppstå i begynnelsen av en insulinbehandling, men er vanligvis av forbigående karakter.</div><div class=\"paragraph\"><span class=\"underline\">Hovne ledd:</span> Når du begynner insulinbehandlingen, kan væskeansamling forårsake hevelse rundt ankler og andre ledd. Dette er normalt av forbigående karakter, hvis ikke, snakk med legen.</div><div class=\"paragraph\"><span class=\"underline\">Diabetisk retinopati</span> (en øyesykdom relatert til diabetes som kan føre til synstap): Dersom du har diabetisk retinopati og blodsukkernivået ditt forbedres veldig raskt, kan retinopatien bli verre. Spør legen om dette.</div><span class=\"inline-title\">Sjeldne bivirkninger</span><div class=\"paragraph\">Kan berøre færre enn 1 av 1000 personer.</div><div class=\"paragraph\"><span class=\"underline\">Smertefull neuropati</span> (smerte som skyldes nerveskade): Hvis blodsukkernivået ditt forbedres veldig raskt kan du få en nerverelatert smerte. Dette kalles akutt smertefull neuropati og er vanligvis forbigående.</div><span class=\"inline-title\">c) Følger ved diabetes</span> <span class=\"inline-title\">Høyt blodsukker (hyperglykemi)</span><div class=\"paragraph\"><span class=\"underline\">Høyt blodsukker kan inntreffe hvis du:</span><ul><li>Ikke har injisert nok insulin.</li><li>Glemmer å ta insulin eller avbryter behandlingen med insulin.</li><li>Gjentatte ganger tar mindre insulin enn det du trenger.</li><li>Får en infeksjon og/eller feber.</li><li>Spiser mer enn vanlig.</li><li>Mosjonerer mindre enn vanlig.</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Varselsymptomer på høyt blodsukker:</span><br/>Varselsymptomene utvikler seg gradvis. De inkluderer: økt vannlating, tørste, manglende appetitt, uvelhet (kvalme eller oppkast), døsighet eller tretthet, rødmende hud, tørr hud, munntørrhet og fruktluktende (acetonluktende) ånde.</div><div class=\"paragraph\"><span class=\"underline\">Hva gjør du hvis du får høyt blodsukker:</span><ul><li>Dersom du får noen av symptomene nevnt ovenfor: kontroller blodsukkernivået, hvis mulig kontroller urinen for ketoner, søk deretter råd hos helsepersonell omgående.</li><li>Dette kan være symptomer på en meget alvorlig tilstand kalt diabetisk ketoacidose (opphopning av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Dersom den ikke behandles, kan den føre til diabetisk koma og til slutt død.</li></ul></div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger. Dette gjelder også bivirkninger som ikke er nevnt i pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "5. Hvordan du oppbevarer NovoRapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>5. Hvordan du oppbevarer NovoRapid</h2><div class=\"paragraph\">Oppbevares utilgjengelig for barn.</div><div class=\"paragraph\">Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på hetteglassets etikett og eske etter “EXP”. Utløpsdatoen er den siste dagen i den angitte måneden.<br/>Oppbevar hetteglasset i ytteremballasjen for å beskytte det mot lys.</div><div class=\"paragraph\"><b><span class=\"underline\">Før anbrudd:</span> </b>Oppbevares i kjøleskap 2-8ºC, borte fra kjøleelementet. Skal ikke fryses.</div><div class=\"paragraph\"><b><span class=\"underline\">Under bruk eller medbrakt som reserve:</span> </b>Preparatet kan oppbevares i opptil 4 uker. Oppbevares ved høyst 30ºC. Skal ikke oppbevares i kjøleskap eller fryses.</div><div class=\"paragraph\">Kast nålen etter hver injeksjon.</div><div class=\"paragraph\">Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.</div></div>"
          }
        },
        {
          "title" : "6. Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>6. Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av NovoRapid</h3><div class=\"paragraph\"><ul><li>Virkestoff er insulin aspart. Hver ml inneholder 100 enheter insulin aspart. Hvert hetteglass inneholder 1000 enheter insulin aspart i 10 ml oppløsning til injeksjon.</li><li>Andre innholdstoffer er glyserol, fenol, metakresol, sinkklorid, dinatriumfosfatdihydrat, natriumklorid, saltsyre, natriumhydroksid og vann til injeksjonsvæsker.</li></ul></div></div>"
            }
          },
          {
            "title" : "Hvordan NovoRapid ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan NovoRapid ser ut og innholdet i pakningen</h3><div class=\"paragraph\">NovoRapid finnes som injeksjonsvæske, oppløsning.</div><div class=\"paragraph\">Pakningsstørrelser på 1 eller 5 hetteglass à 10 ml eller en flerpakning med 5 pakninger à 1 × 10 ml hetteglass. Ikke alle pakningsstørrelser vil nødvendigvis bli markedsført.</div><div class=\"paragraph\">Oppløsningen er klar og fargeløs.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen og tilvirker",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen og tilvirker</h3><div class=\"paragraph\">Novo Nordisk A/S, Novo Allé, DK-2880 Bagsværd, Danmark</div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 20.03.2023",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 20.03.2023</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre informasjonskilder</h3><div class=\"paragraph\">Detaljert informasjon om dette legemidlet er tilgjengelig på nettstedet til Det europeiske legemiddelkontoret (the European Medicines Agency): <a href=\"http://www.ema.europa.eu/\" title=\"\n               \n                  http://www.ema.europa.eu\n               \n            \">http://www.ema.europa.eu </a>og på nettstedet til <a href=\"http://www.felleskatalogen.no\" title=\"\n               \n                  www.felleskatalogen.no\n               \n            \">www.felleskatalogen.no</a></div></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-93",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-93",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-93\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-93</b></p><a name=\"Diabetes-MPD-93\"> </a><a name=\"hcDiabetes-MPD-93\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_C72E0BDC-52DB-4D5F-9E17-29CE2977DA1D</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>NovoRapid inj, oppl 100 E/ml</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_C72E0BDC-52DB-4D5F-9E17-29CE2977DA1D"
      }],
      "name" : [{
        "productName" : "NovoRapid inj, oppl 100 E/ml"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-119",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-119",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-119\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-119</b></p><a name=\"Diabetes-PPD-119\"> </a><a name=\"hcDiabetes-PPD-119\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_7204E0F5-CEC4-4EE5-8553-2BA28256E4A6, <code>https://farmalogg.no/varenummer</code>/093856</p><p><b>name</b>: NovoRapid inj, oppl 100 E/ml</p><p><b>packageFor</b>: <a href=\"Bundle-FK630703.html#MedicinalProductDefinition_Diabetes-MPD-93\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_C72E0BDC-52DB-4D5F-9E17-29CE2977DA1D</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_7204E0F5-CEC4-4EE5-8553-2BA28256E4A6"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "093856"
      }],
      "name" : "NovoRapid inj, oppl 100 E/ml",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-93"
      }]
    }
  }]
}

```
