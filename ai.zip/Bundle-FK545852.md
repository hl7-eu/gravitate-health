# FK545852 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK545852**

## Example Bundle: FK545852

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: Informasjon til pasienten

 

# Pakningsvedlegg: Informasjon til pasienten

## Alendronat Mylan 70 mg tabletter

### alendronsyre


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Hvis du har ytterligere spørsmål, kontakt lege eller apotek.
* Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.
* Kontakt lege eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om:

 

## I dette pakningsvedlegget finner du informasjon om:

1. Hva Alendronat Mylan er og hva det brukes mot
1. Hva du må vite før du bruker Alendronat Mylan
1. Hvordan du bruker Alendronat Mylan
1. Mulige bivirkninger
1. Hvordan du oppbevarer Alendronat Mylan
1. Innholdet i pakningen og ytterligere informasjon


#### Hva Alendronat Mylan er og hva det brukes mot

 

## Hva Alendronat Mylan er og hva det brukes mot

Vær oppmerksom på at legen kan ha forskrevet legemidlet til en annen bruk og/eller med en annen dosering enn angitt i pakningsvedlegget. Følg alltid legens forskrivning som er angitt på apoteketiketten.

Virkestoffet i Alendronat Mylan er natriumalendronat.

Alendronat Mylan tilhører en gruppe legemidler som kalles bisfosfonater. Bisfosfonater kan brukes til behandling av skjelettsykdommer slik som beinskjørhet (osteoporose).

Beinskjørhet gjør at beina i kroppen (skjelettet) blir tynnere og svakere. Alendronat Mylan kan brukes ved behandling av beinskjørhet hos kvinner etter overgangsalderen. Alendronat Mylan reduserer risikoen for brudd i hoftene eller i ryggsøylen.


#### Hva du må vite før du bruker Alendronat Mylan

 

## Hva du må vite før du bruker Alendronat Mylan


#### Hvordan du bruker Alendronat Mylan

 

## Hvordan du bruker Alendronat Mylan

Bruk alltid dette legemidlet nøyaktig slik legen din eller apoteket har fortalt deg. Kontakt lege eller apotek hvis du er usikker.

Voksne og eldre:
Den anbefalte dosen er 70 mg én gang i uken.

Bruk av Alendronat Mylan hos pasienter med nyreproblemer:
Alendronat Mylan anbefales ikke til pasienter med alvorlige nyreproblemer.

Bruk av Alendronat Mylan hos barn og ungdom:
Alendronat skal ikke gis til barn og ungdom under 18 år.

Hvordan legemidlet skal tas

* Ta tabletten på tom mage så snart du har stått opp om morgenen, **før **du spiser eller drikker noe annet.
* Svelg tabletten hel mens du forblir i oppreist stilling (sittende, stående eller gående). Drikk et helt glass (minst 2 dl) vanlig vann (ikke mineralvann).
* Skal ikke tas sammen med mineralvann (med eller uten kullsyre).
* Skal ikke tas sammen med kaffe eller te.
* Skal ikke tas sammen med juice eller melk.

* Ikke knus eller tygg tabletten eller la den løse seg opp i munnen.
* **Ikke **ta tabletten ved leggetid. Etter at du har tatt Alendronat Mylan skal du ikke legge deg ned igjen før du har spist.
* Du må imidlertid vente i minst 30 minutter etter at du har svelget tabletten før du spiser, drikker eller tar andre legemidler.

Slutt å ta dette legemidlet og informer legen din dersom du opplever:

* sårhet, smerter og vanskeligheter med å svelge
* smerter midt i brystet
* halsbrann eller forverret halsbrann
* sår i munn og svelg.


#### Mulige bivirkninger

 

## Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.

Stopp å ta dette legemidlet og kontakt legen din umiddelbart dersom du får noen av følgende symptomer:
Vanlige (forekommer hos inntil 1 av 10 personer):

* smerter i munn, svelg, bryst eller mage som kan være forbundet med spising. Du kan føle deg oppblåst, kvalm eller kaste opp, miste matlysten eller gå ned i vekt. Dette kan være tegn på betennelse eller sår i fordøyelseskanalen. Dersom du kaster opp kan det også hende at du ser partikler som ligner kaffegrut, eller avføringen kan være svart og tjæreaktig.
* ny eller forverret halsbrann eller fordøyelsesproblemer, smerter midt i brystet eller smerter ved svelging. Kontakt lege så raskt som mulig dersom noe av dette oppstår.

Mindre vanlige (forekommer hos inntil 1 av 100 personer):

* sårhet eller smerter i ett eller begge øynene. Du kan få rødhet, tåkesyn, rennende øyne, lysfølsomhet eller skygger som flyter over synsfeltet (”flygende fluer”).

Sjeldne (forekommer hos inntil 1 av 1000 personer):

* allergiske reaksjoner slik som elveblest, hevelse i ansikt, lepper, tunge og/eller svelg som kan føre til vanskeligheter med å puste eller svelge (angioødem)
* en hudlidelse med kraftige blemmer og blødninger i lepper, øyne, munn, nese og kjønnsorganer (Stevens-Johnsons syndrom) eller alvorlige hudreaksjoner som starter med smertefulle rødfargede områder på huden, deretter store blemmer og til slutt avskalling av huden. Samtidig oppstår feber og frysninger, verkende muskler og en generell følelse av uvelhet (toksisk epidermal nekrolyse).
* smerter i munn og/eller kjeve, hevelser eller sår på innsiden av munnen, nummenhet eller en følelse av tunghet i kjeven eller løsning av en tann. Dette kan være tegn på beinskade i kjeven (osteonekrose) som vanligvis er forbundet med forsinket sårtilheling og infeksjon, ofte etter tanntrekking. Kontakt legen og tannlegen din hvis du får slike symptomer.
* uvanlige brudd i lårbeinet kan oppstå i sjeldne tilfeller, spesielt hos pasienter som får langtidsbehandling mot osteoporose. Kontakt legen din dersom du får smerter, svakhet eller ubehag i lår, hofte eller lyske, da dette kan være tidlige tegn på et mulig lårbeinsbrudd.

Svært sjeldne (forekommer hos inntil 1 av 10 000 personer):

* snakk med legen din dersom du har smerter i øret, pussdannelse fra øret, og/eller en infeksjon i øret. Dette kan være tegn på beinskade i øret.

Kontakt legen din dersom du får noen av disse symptomene.

Andre mulige bivirkninger:
Svært vanlige (forekommer hos flere enn 1 av 10 personer):

* smerter i skjelett, muskler og/eller ledd som i enkelte tilfeller kan være kraftige

Vanlige (forekommer hos inntil 1 av 10 personer):

* hevelser i ledd, hevelser i hender eller føtter
* magesmerter, ubehag i magen eller metthetsfølelse eller raping etter måltid, forstoppelse, diaré, promping
* hårtap, kløende hud
* hodepine, svimmelhet, manglende balanse eller følelse av at en selv eller omgivelsene går rundt (vertigo), uvanlig svakhet

Mindre vanlige (forekommer hos inntil 1 av 100 personer):

* kvalme, oppkast
* utslett, rødhet i huden
* influensalignende symptomer som varer en kort stund, slik som verkende muskler, generelt ubehag og enkelte ganger med feber. Dette ses vanligvis i begynnelsen av behandlingen.
* endret smak

Sjeldne (forekommer hos inntil 1 av 1000 personer):

* symptomer på lite kalsium i blodet, inkludert muskelkramper eller spasmer og/eller prikkende følelse i fingrene eller rundt munnen
* innsnevring i spiserøret
* utslett som forverres av sollys

Informer lege eller apotek øyeblikkelig om du får disse eller andre uvanlige symptomer.

Det vil være til hjelp om du noterer ned hva du opplevde, når det startet og hvor lenge det varte.


#### Hvordan du oppbevarer Alendronat Mylan

 

## Hvordan du oppbevarer Alendronat Mylan

Oppbevares utilgjengelig for barn.

Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken etter ”Utl.dato” og blisteret etter ”EXP”. Utløpsdatoen henviser til den siste dagen i måneden.

Dette legemidlet krever ingen spesielle oppbevaringsbetingelser.

Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.


#### Innholdet i pakningen og ytterligere informasjon

 

## Innholdet i pakningen og ytterligere informasjon


####  Alendronat Mylan tab 70 mg 
LEGEMIDDELMERKEVAREID:
** ID_BA15CC1C-C0C9-472D-A368-3C639E6A9D0B **
-------

Full name: **Alendronat Mylan tab 70 mg**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 2

LEGEMIDDELPAKNINGID: ** ID_F556FCD5-9D92-42D7-B7FA-4C1A9C019CCA ** 

VARENUMMER: ** 153895 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:

 Package 2 of 2

LEGEMIDDELPAKNINGID: ** ID_7AD6DBD3-AF77-46C8-94C7-DCD4C55ED167 ** 

VARENUMMER: ** 153884 ** 

Description:

## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK545852",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "545852"
  },
  "type" : "document",
  "timestamp" : "2021-06-28T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK545852-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK545852-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK545852-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK545852-COMP</b></p><a name=\"FK545852-COMP\"> </a><a name=\"hcFK545852-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/545852</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2021-06-28</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: Alendronat Mylan tabletter 70 mg</p></div>"
      },
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "545852"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/COPD-MPD-21"
      }],
      "date" : "2021-06-28",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "Alendronat Mylan tabletter 70 mg",
      "section" : [{
        "title" : "Pakningsvedlegg: Informasjon til pasienten",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: Informasjon til pasienten</h1><h2>Alendronat Mylan 70 mg tabletter</h2><h3>alendronsyre</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Hvis du har ytterligere spørsmål, kontakt lege eller apotek.</li><li>Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.</li><li>Kontakt lege eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om:",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om:</h2><div class=\"paragraph\"><ol><li>Hva Alendronat Mylan er og hva det brukes mot</li><li>Hva du må vite før du bruker Alendronat Mylan</li><li>Hvordan du bruker Alendronat Mylan</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer Alendronat Mylan</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "Hva Alendronat Mylan er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hva Alendronat Mylan er og hva det brukes mot</h2><div class=\"paragraph\">Vær oppmerksom på at legen kan ha forskrevet legemidlet til en annen bruk og/eller med en annen dosering enn angitt i pakningsvedlegget. Følg alltid legens forskrivning som er angitt på apoteketiketten.</div><div class=\"paragraph\">Virkestoffet i Alendronat Mylan er natriumalendronat.</div><div class=\"paragraph\">Alendronat Mylan tilhører en gruppe legemidler som kalles bisfosfonater. Bisfosfonater kan brukes til behandling av skjelettsykdommer slik som beinskjørhet (osteoporose).<br/>Beinskjørhet gjør at beina i kroppen (skjelettet) blir tynnere og svakere. Alendronat Mylan kan brukes ved behandling av beinskjørhet hos kvinner etter overgangsalderen. Alendronat Mylan reduserer risikoen for brudd i hoftene eller i ryggsøylen.</div></div>"
          }
        },
        {
          "title" : "Hva du må vite før du bruker Alendronat Mylan",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hva du må vite før du bruker Alendronat Mylan</h2></div>"
          },
          "section" : [{
            "title" : "Bruk ikke Alendronat Mylan:",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Bruk ikke Alendronat Mylan:</h3><div class=\"paragraph\"><ul><li>dersom du er allergisk overfor natriumalendronat eller noen av de andre innholdsstoffene i dette legemidlet (listet opp i avsnitt 6)</li><li>dersom du har problemer med spiserøret som gjør det vanskelig å svelge eller at mat setter seg fast</li><li>dersom du ikke kan stå eller sitte oppreist i minst 30 minutter</li><li>dersom du har svært lavt nivå av kalsium i blodet (hypokalsemi).</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler:",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler:</h3><div class=\"paragraph\">Rådfør deg med lege eller apotek før du bruker Alendronat Mylan:<ul><li>dersom du har nyreproblemer</li><li>dersom du har svelge-, fordøyelses- eller tarmproblemer</li><li>dersom du i løpet av det siste året har hatt magesår, blødning eller en operasjon i magen, spiserøret eller svelget</li><li>dersom du har smerter når du svelger</li><li>dersom legen din har fortalt deg at du har Barrets øsofagus (en tilstand forbundet med celleforandringer på overflaten av nedre del i spiserøret)</li><li>dersom du er blitt fortalt at du har for lavt nivå av kalsium i blodet, eller du lider av vitamin D- mangel eller såkalt hypoparatyroeoidisme (som kan påvirke kalsiumnivået). Dette må behandles før du begynner å bruke Alendronat Mylan.</li></ul></div><div class=\"paragraph\">Irritasjon, betennelse eller sårdannelse i spiserøret, ofte med symptomer som brystsmerter, halsbrann eller problemer eller smerter ved svelging kan oppstå, særlig dersom tablettene ikke tas sammen med et helt glass vann og/eller dersom du legger deg ned mindre enn 30 minutter etter å ha tatt tablettene. Disse bivirkningene kan forverres dersom du fortsetter å ta tablettene etter å ha fått disse symptomene. Se instruksjoner for hvordan du skal ta tablettene i avsnittet ”Hvordan du bruker Alendronat Mylan” nedenfor i dette pakningsvedlegget. Kontakt lege eller apotek dersom du har spørsmål.</div><span class=\"inline-title\">Tann- og kjeveproblemer</span><div class=\"paragraph\">Alendronat Mylan kan gi skade (inkludert vevsdød eller tap) av bein i kjeven. Denne risikoen øker:<ul><li>dersom du har dårlig tannhelse, sykdom i tannkjøttet, dårlig tilpasset tannprotese, en planlagt tanntrekking eller du ikke går til tannlegen regelmessig</li><li>dersom du har kreft</li><li>dersom du får cellegift eller strålebehandling</li><li>dersom du bruker kortikosteroider (slik som prednison eller deksametason)</li><li>dersom du behandles med legemidler mot kreft som hindrer vekst av nye blodårer (såkalte angiogenesehemmere slik som bevacizumab eller talidomid)</li><li>dersom du røyker eller tidligere har røykt.</li></ul></div><div class=\"paragraph\">Det kan hende at du blir anbefalt å ha en tannlegetime før oppstart av behandling med Alendronat Mylan.</div><div class=\"paragraph\">Det er viktig med god munnhygiene mens du bruker Alendronat Mylan. Du bør gå til tannlegen regelmessig under behandlingen, og du bør kontakte legen eller tannlegen hvis du får problemer i munnen eller med tennene, slik som løse tenner, smerter eller hevelser.</div></div>"
            }
          },
          {
            "title" : "Andre legemidler og Alendronat Mylan",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og Alendronat Mylan</h3><div class=\"paragraph\">Rådfør deg med lege eller apotek dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler, dette gjelder også reseptfrie legemidler, eller noen av de følgende:<ul><li>kalsiumtilskudd</li><li>syrenøytraliserende legemidler (antacider) ved fordøyelsesproblemer</li><li>kortikosteroider, slik som prednisolon eller deksametason, som brukes for å dempe betennelser.<br/>Det er viktig at du får nok kalsium og vitamin D gjennom kosten (en risikofaktor for tannproblemer, se avsnittet ”Tann- og kjeveproblemer”).</li><li>visse legemidler mot revmatisme eller langvarige smerter, såkalte NSAIDs (f.eks. acetysalisylsyre eller ibuprofen), kan gi problemer med fordøyelsen. Forsiktighet bør derfor utvises når disse legemidlene brukes samtidig med Alendronat Mylan.</li></ul></div><div class=\"paragraph\">Vent minst 30 minutter etter at du har tatt Alendronat Mylan før du tar andre legemidler.</div></div>"
            }
          },
          {
            "title" : "Inntak av Alendronat Mylan sammen med mat og drikke",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029901"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Inntak av Alendronat Mylan sammen med mat og drikke</h3><div class=\"paragraph\">Mat og drikke kan redusere opptaket av Alendronat Mylan i blodet. Derfor skal du ta Alendronat Mylan med vanlig vann minst 30 minutter før du spiser eller drikker.</div></div>"
            }
          },
          {
            "title" : "Graviditet og amming",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet og amming</h3><div class=\"paragraph\">Alendronat Mylan skal kun brukes av kvinner etter overgangsalderen. Rådfør deg med lege eller apotek før du tar dette legemidlet dersom du er gravid eller ammer, tror at du kan være gravid eller planlegger å bli gravid.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\">Du må bare kjøre bil eller utføre risikofylt arbeid når det er trygt for deg. Legemidler kan påvirke din evne til å kjøre bil eller utføre risikofylt arbeid. Les informasjonen i pakningsvedlegget nøye. Er du i tvil, må du snakke med lege eller apotek.</div><div class=\"paragraph\">Det er rapportert bivirkninger ved bruk av alendronat som kan påvirke evnen til å kjøre bil eller bruke maskiner (inkludert tåkesyn, svimmelhet og kraftige smerter i skjelett, muskler eller ledd). Ikke kjør bil eller bruk maskiner før du er sikker på at du ikke påvirkes.</div></div>"
            }
          },
          {
            "title" : "Alendronat Mylan inneholder laktose",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Alendronat Mylan inneholder laktose</h3><div class=\"paragraph\">Dersom legen din har fortalt deg at du er allergisk overfor noen sukkertyper, bør du kontakte legen din før du tar dette legemidlet.</div><div class=\"paragraph\"><b>Alendronat Mylan inneholder mindre enn 1 mmol natrium </b>(23 mg) i hver tablett, og er så godt som «natriumfritt».</div></div>"
            }
          }]
        },
        {
          "title" : "Hvordan du bruker Alendronat Mylan",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hvordan du bruker Alendronat Mylan</h2><div class=\"paragraph\">Bruk alltid dette legemidlet nøyaktig slik legen din eller apoteket har fortalt deg. Kontakt lege eller apotek hvis du er usikker.</div><span class=\"inline-title\">Voksne og eldre:</span><div class=\"paragraph\">Den anbefalte dosen er 70 mg én gang i uken.</div><span class=\"inline-title\">Bruk av Alendronat Mylan hos pasienter med nyreproblemer:</span><div class=\"paragraph\">Alendronat Mylan anbefales ikke til pasienter med alvorlige nyreproblemer.</div><span class=\"inline-title\">Bruk av Alendronat Mylan hos barn og ungdom:</span><div class=\"paragraph\">Alendronat skal ikke gis til barn og ungdom under 18 år.</div><span class=\"inline-title\">Hvordan legemidlet skal tas</span><div class=\"paragraph\"><ul><li>Ta tabletten på tom mage så snart du har stått opp om morgenen, <b>før </b>du spiser eller drikker noe annet.</li><li>Svelg tabletten hel mens du forblir i oppreist stilling (sittende, stående eller gående). Drikk et helt glass (minst 2 dl) vanlig vann (ikke mineralvann).<ul><li>Skal ikke tas sammen med mineralvann (med eller uten kullsyre).</li><li>Skal ikke tas sammen med kaffe eller te.</li><li>Skal ikke tas sammen med juice eller melk.</li></ul></li><li>Ikke knus eller tygg tabletten eller la den løse seg opp i munnen.</li><li><b>Ikke </b>ta tabletten ved leggetid. Etter at du har tatt Alendronat Mylan skal du ikke legge deg ned igjen før du har spist.</li><li>Du må imidlertid vente i minst 30 minutter etter at du har svelget tabletten før du spiser, drikker eller tar andre legemidler.</li></ul></div><span class=\"inline-title\">Slutt å ta dette legemidlet og informer legen din dersom du opplever:</span><div class=\"paragraph\"><ul><li>sårhet, smerter og vanskeligheter med å svelge</li><li>smerter midt i brystet</li><li>halsbrann eller forverret halsbrann</li><li>sår i munn og svelg.</li></ul></div></div>"
          },
          "section" : [{
            "title" : "Dersom du tar for mye av Alendronat Mylan",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029907"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du tar for mye av Alendronat Mylan</h3><div class=\"paragraph\">Drikk et helt glass melk. Kontakt øyeblikkelig lege, sykehus eller Giftinformasjonen (tlf. 22 59 13 00) hvis du har fått i deg for mye legemiddel eller hvis barn har fått i seg legemiddel ved et uhell. Ta med deg pakningen og gjenværende tabletter. Du skal <b>ikke </b>forsøke å kaste opp og <b>ikke </b>legge deg ned. Ved overdosering kan du få oppblåst mage, halsbrann, betennelse i spiserøret, magesmerter, kvalme, oppkast, oppkast av blod, blod i avføringen, magesår. Du kan også få forandringer i resultater fra blodprøver (slik som lavt nivå av kalsium og fosfat i blodet).</div></div>"
            }
          },
          {
            "title" : "Dersom du har glemt å ta Alendronat Mylan",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029908"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du har glemt å ta Alendronat Mylan</h3><div class=\"paragraph\">Ta tabletten om morgenen dagen etter at du kommer på det. Du må ikke ta to tabletter den samme uken. Fortsett å ta én tablett én gang i uken.</div></div>"
            }
          },
          {
            "title" : "Dersom du avbryter behandling med Alendronat Mylan",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029909"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du avbryter behandling med Alendronat Mylan</h3><div class=\"paragraph\">Rådfør deg alltid med lege eller apotek før du slutter å bruke Alendronat Mylan.</div><div class=\"paragraph\">Spør lege eller apotek dersom du har noen spørsmål om bruken av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.</div><span class=\"inline-title\">Stopp å ta dette legemidlet og kontakt legen din umiddelbart dersom du får noen av følgende symptomer:</span> <span class=\"inline-title\">Vanlige (forekommer hos inntil 1 av 10 personer):</span><div class=\"paragraph\"><ul><li>smerter i munn, svelg, bryst eller mage som kan være forbundet med spising. Du kan føle deg oppblåst, kvalm eller kaste opp, miste matlysten eller gå ned i vekt. Dette kan være tegn på betennelse eller sår i fordøyelseskanalen. Dersom du kaster opp kan det også hende at du ser partikler som ligner kaffegrut, eller avføringen kan være svart og tjæreaktig.</li><li>ny eller forverret halsbrann eller fordøyelsesproblemer, smerter midt i brystet eller smerter ved svelging. Kontakt lege så raskt som mulig dersom noe av dette oppstår.</li></ul></div><span class=\"inline-title\">Mindre vanlige (forekommer hos inntil 1 av 100 personer):</span><div class=\"paragraph\"><ul><li>sårhet eller smerter i ett eller begge øynene. Du kan få rødhet, tåkesyn, rennende øyne, lysfølsomhet eller skygger som flyter over synsfeltet (”flygende fluer”).</li></ul></div><span class=\"inline-title\">Sjeldne (forekommer hos inntil 1 av 1000 personer):</span><div class=\"paragraph\"><ul><li>allergiske reaksjoner slik som elveblest, hevelse i ansikt, lepper, tunge og/eller svelg som kan føre til vanskeligheter med å puste eller svelge (angioødem)</li><li>en hudlidelse med kraftige blemmer og blødninger i lepper, øyne, munn, nese og kjønnsorganer (Stevens-Johnsons syndrom) eller alvorlige hudreaksjoner som starter med smertefulle rødfargede områder på huden, deretter store blemmer og til slutt avskalling av huden. Samtidig oppstår feber og frysninger, verkende muskler og en generell følelse av uvelhet (toksisk epidermal nekrolyse).</li><li>smerter i munn og/eller kjeve, hevelser eller sår på innsiden av munnen, nummenhet eller en følelse av tunghet i kjeven eller løsning av en tann. Dette kan være tegn på beinskade i kjeven (osteonekrose) som vanligvis er forbundet med forsinket sårtilheling og infeksjon, ofte etter tanntrekking. Kontakt legen og tannlegen din hvis du får slike symptomer.</li><li>uvanlige brudd i lårbeinet kan oppstå i sjeldne tilfeller, spesielt hos pasienter som får langtidsbehandling mot osteoporose. Kontakt legen din dersom du får smerter, svakhet eller ubehag i lår, hofte eller lyske, da dette kan være tidlige tegn på et mulig lårbeinsbrudd.</li></ul></div><span class=\"inline-title\">Svært sjeldne (forekommer hos inntil 1 av 10 000 personer):</span><div class=\"paragraph\"><ul><li>snakk med legen din dersom du har smerter i øret, pussdannelse fra øret, og/eller en infeksjon i øret. Dette kan være tegn på beinskade i øret.</li></ul></div><div class=\"paragraph\">Kontakt legen din dersom du får noen av disse symptomene.</div><span class=\"inline-title\">Andre mulige bivirkninger:</span> <span class=\"inline-title\">Svært vanlige (forekommer hos flere enn 1 av 10 personer):</span><div class=\"paragraph\"><ul><li>smerter i skjelett, muskler og/eller ledd som i enkelte tilfeller kan være kraftige</li></ul></div><span class=\"inline-title\">Vanlige (forekommer hos inntil 1 av 10 personer):</span><div class=\"paragraph\"><ul><li>hevelser i ledd, hevelser i hender eller føtter</li><li>magesmerter, ubehag i magen eller metthetsfølelse eller raping etter måltid, forstoppelse, diaré, promping</li><li>hårtap, kløende hud</li><li>hodepine, svimmelhet, manglende balanse eller følelse av at en selv eller omgivelsene går rundt (vertigo), uvanlig svakhet</li></ul></div><span class=\"inline-title\">Mindre vanlige (forekommer hos inntil 1 av 100 personer):</span><div class=\"paragraph\"><ul><li>kvalme, oppkast</li><li>utslett, rødhet i huden</li><li>influensalignende symptomer som varer en kort stund, slik som verkende muskler, generelt ubehag og enkelte ganger med feber. Dette ses vanligvis i begynnelsen av behandlingen.</li><li>endret smak</li></ul></div><span class=\"inline-title\">Sjeldne (forekommer hos inntil 1 av 1000 personer):</span><div class=\"paragraph\"><ul><li>symptomer på lite kalsium i blodet, inkludert muskelkramper eller spasmer og/eller prikkende følelse i fingrene eller rundt munnen</li><li>innsnevring i spiserøret</li><li>utslett som forverres av sollys</li></ul></div><div class=\"paragraph\">Informer lege eller apotek øyeblikkelig om du får disse eller andre uvanlige symptomer.</div><div class=\"paragraph\">Det vil være til hjelp om du noterer ned hva du opplevde, når det startet og hvor lenge det varte.</div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "Hvordan du oppbevarer Alendronat Mylan",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hvordan du oppbevarer Alendronat Mylan</h2><div class=\"paragraph\">Oppbevares utilgjengelig for barn.</div><div class=\"paragraph\">Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på esken etter ”Utl.dato” og blisteret etter ”EXP”. Utløpsdatoen henviser til den siste dagen i måneden.</div><div class=\"paragraph\">Dette legemidlet krever ingen spesielle oppbevaringsbetingelser.</div><div class=\"paragraph\">Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.</div></div>"
          }
        },
        {
          "title" : "Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av Alendronat Mylan",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av Alendronat Mylan</h3><div class=\"paragraph\"><ul><li>Virkestoff er natriumalendronat tilsvarende 70 mg alendronsyre.</li><li>Andre innholdsstoffer er laktosemonohydrat, cellulose, mikrokrystallinsk, povidon, krysskarmellosenatrium og magnesiumstearat.</li></ul></div></div>"
            }
          },
          {
            "title" : "Hvordan Alendronat Mylan ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan Alendronat Mylan ser ut og innholdet i pakningen</h3><div class=\"paragraph\">Alendronat Mylan 70 mg tabletter er hvite med to buede sider og merket med ”AD70” på den ene siden og ”G” på den andre.</div><div class=\"paragraph\">Alendronat Mylan 70 mg tabletter finnes i blisterpakninger med 4, 8 eller 12 tabletter. Alendronat Mylan 70 mg tabletter finnes også i bokser med 4, 8 eller 12 tabletter og i bokser med 100 tabletter (dispenseringspakning).<br/>Øverst i boksene kan det ligge et plastmateriale som fyller restvolumet.</div><div class=\"paragraph\">Ikke alle pakninger vil nødvendigvis bli markedsført.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen og tilvirker",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen og tilvirker</h3><div class=\"paragraph\"><i>Innehaver av markedsføringstillatelsen:</i><br/>Mylan AB, P.O. Box 23033, S-10435 Stockholm, Sverige<br/>Tlf: +46 (0)8 555 227 50<br/>Faks: +46 (0)8 555 227 51<br/>E-post: inform@mylan.se</div><div class=\"paragraph\"><i>Tilvirker:</i><br/>McDermott Laboratories t/a Gerard Laboratories<br/>35/36 Baldoyle Industrial Estate<br/>Grange Road<br/>IRL-Dublin 13<br/>Irland</div><div class=\"paragraph\">eller<br/>Mylan Hungary Kft. Mylan utca 1.,<br/>Komárom, 2900, Ungarn</div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 28.06.2021",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 28.06.2021</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Detaljert informasjon om dette legemidlet er tilgjengelig på nettstedet til <a href=\"http://www.felleskatalogen.no/\" title=\"www.felleskatalogen.no.\">www.felleskatalogen.no.</a></div></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/COPD-MPD-21",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "COPD-MPD-21",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_COPD-MPD-21\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition COPD-MPD-21</b></p><a name=\"COPD-MPD-21\"> </a><a name=\"hcCOPD-MPD-21\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_BA15CC1C-C0C9-472D-A368-3C639E6A9D0B</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Alendronat Mylan tab 70 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_BA15CC1C-C0C9-472D-A368-3C639E6A9D0B"
      }],
      "name" : [{
        "productName" : "Alendronat Mylan tab 70 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/COPD-PPD-28",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "COPD-PPD-28",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_COPD-PPD-28\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition COPD-PPD-28</b></p><a name=\"COPD-PPD-28\"> </a><a name=\"hcCOPD-PPD-28\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_F556FCD5-9D92-42D7-B7FA-4C1A9C019CCA, <code>https://farmalogg.no/varenummer</code>/153895</p><p><b>name</b>: Alendronat Mylan tab 70 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK545852.html#MedicinalProductDefinition_COPD-MPD-21\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_BA15CC1C-C0C9-472D-A368-3C639E6A9D0B</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_F556FCD5-9D92-42D7-B7FA-4C1A9C019CCA"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "153895"
      }],
      "name" : "Alendronat Mylan tab 70 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/COPD-MPD-21"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/COPD-PPD-27",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "COPD-PPD-27",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_COPD-PPD-27\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition COPD-PPD-27</b></p><a name=\"COPD-PPD-27\"> </a><a name=\"hcCOPD-PPD-27\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_7AD6DBD3-AF77-46C8-94C7-DCD4C55ED167, <code>https://farmalogg.no/varenummer</code>/153884</p><p><b>name</b>: Alendronat Mylan tab 70 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK545852.html#MedicinalProductDefinition_COPD-MPD-21\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_BA15CC1C-C0C9-472D-A368-3C639E6A9D0B</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_7AD6DBD3-AF77-46C8-94C7-DCD4C55ED167"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "153884"
      }],
      "name" : "Alendronat Mylan tab 70 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/COPD-MPD-21"
      }]
    }
  }]
}

```
