# ePI document Bundle for Xenical 120mg hard capsules Package Leaflet for language es - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Xenical 120mg hard capsules Package Leaflet for language es**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **1 Box** **(Cardboard)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Capsule, hard ** 

 Unit of presentation: ** Capsule, hard ** 

Ingredient

 Role: ** active ** 

 Substance: ** ORLISTAT ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** MICROCRYSTALLINE CELLULOSE ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** SODIUM STARCH GLYCOLATE TYPE A ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** POVIDONE, UNSPECIFIED ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** SODIUM LAURYL SULFATE ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** GELATIN, UNSPECIFIED ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** TITANIUM DIOXIDE ** 

## Example Bundle: ePI document Bundle for Xenical 120mg hard capsules Package Leaflet for language es

**Composition category:**Raw

**Composition status:**final

### B. PROSPECTO

 

unavailable


#### PROSPECTO: INFORMACIÓN PARA EL USUARIO

 

XENICAL 120 mg cápsulas duras Orlistat

Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.

• Conserve este prospecto, ya que puede tener que volver a leerlo.

• Si tiene alguna duda, consulte a su médico* farmacéutico.

• Este medicamento se le ha recetado solamente a usted y no debe dárselo a otras personas, aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.

• Si experimenta efectos adversos, consulte a su médico* farmacéutico, incluso si se trata deefectos adversos que no aparecen en este prospecto. Ver sección 4


#### Contenido del prospecto

 

Contenido del prospecto:

1. Qué es Xenical y para qué se utiliza
1. Qué necesita saber antes de empezar a tomar Xenical
1. Cómo tomar Xenical
1. Posibles efectos adversos
1. Conservación de Xenical
1. Contenido del envase e información adicional


#### 1. Qué es XENICAL 120 mg cápsulas duras y para qué se utiliza

 

Xenical es un medicamento utilizado para tratar la obesidad. Actúa sobre su sistema digestivo evitando que se digiera alrededor de un tercio de la grasa contenida en la comida que ingiere.Xenical se une a enzimas de su sistema digestivo (lipasas) evitando que hidrolicen parte de las grasas que ha ingerido durante la comida. La grasa no digerida no puede absorberse y su cuerpo la elimina.

Xenical está indicado para el tratamiento de la obesidad, junto con una dieta con bajo contenido en calorías.


#### 2. Qué necesita saber antes de empezar a tomar XENICAL 120 mg cápsulas duras 

 

No tome XENICAL

* Si es alérgico (hipersensible) a orlistat o a cualquiera de los demás componentes de Xenical.
* Si tiene síndrome de malabsorción crónica (absorción insuficiente de nutrientes a través del tracto digestivo).
* Si tiene colestasis (trastorno del hígado).
* Si está en periodo de lactancia

Advertencias y precauciones La pérdida de peso puede también afectar a la dosis de los medicamentos que tome para otras situaciones (p. ej. colesterol alto o diabetes). Asegúrese de informar a su médico si está tomando éstos u otros medicamentos. La pérdida de peso puede significar que usted necesite un ajuste de la dosis de estos medicamentos.

Para obtener el máximo beneficio de Xenical debe seguir el programa de nutrición recomendado por su médico. Como ocurre con cualquier otro programa de control de peso, el consumo excesivo de grasa y calorías puede reducir el efecto en la pérdida de peso.

Este medicamento puede causar un cambio no perjudicial en sus hábitos de evacuación intestinal, tal como puede ser la presencia de heces grasas o aceitosas, debido a la eliminación por las heces de grasa sin digerir. La posibilidad de que esto ocurra puede aumentar si Xenical se toma con una dieta rica en grasa. Además, su ingesta diaria de grasa debe ser distribuida equitativamente entre las tres principales comidas ya que si Xenical se toma con una comida muy alta en grasa se puede incrementar la posibilidad de que se den efectos gastrointestinales.

En caso de diarrea grave podría haber un fallo de los anticonceptivos orales, por lo que se recomienda el uso de un método anticonceptivo adicional.

En pacientes con enfermedad renal crónica, el uso de Orlistat puede estar asociado a cálculos renales. Informe a su médico si tiene problemas de riñón.

Este medicamento contiene menos de 1 mmol de sodio (23 mg) por cápsula; esto es, esencialmente “exento de sodio”.

**Niños**

Xenical no está indicado para su uso en niños.

Toma de XENICAL con otros medicamentos Informe a su médico o farmacéutico si está tomando o ha tomado recientemente o podría tener que tomar cualquier otro medicamento.

Esto es importante ya que al utilizar más de un medicamento al mismo tiempo puede aumentar o disminuir su efecto.

Xenical puede modificar la acción de:

* Anticoagulantes (p. ej. warfarina), por ello, su médico puede necesitar monitorizar su coagulación sanguínea.
* Ciclosporina. No se recomienda la administración conjunta con ciclosporina. Su médico puede necesitar monitorizar sus niveles plasmáticos de ciclosporina con mayor frecuencia de lo habitual.
* Sales de yodo y/o levotiroxina. Pueden producir casos de hipotiroidismo y/o alteraciones del control del hipotiroidismo.
* Amiodarona. Consulte con su médico.
* Medicamentos para tratar el SIDA.
* Medicamentos para la depresión, para trastornos psiquiátricos o para la ansiedad.

Xenical reduce la absorción de suplementos de algunos nutrientes solubles en grasa, especialmente de beta-caroteno y vitamina E. Por lo tanto, deberá seguir el consejo de su médico y tomar una dieta equilibrada rica en fruta y verduras. Puede que su médico le recomiende un suplemento polivitamínico.

Orlistat puede alterar el tratamiento anticonvulsionante al disminuir la absorción de los medicamentos antiepilépticos, lo que puede llevar a la aparición de convulsiones. Consulte con su médico si considera que la frecuencia o gravedad de las convulsiones ha cambiado al tomar Xenical junto con medicamentos antiepilépticos.

No se recomienda Xenical para los que esten tomando acarbosa (fármaco anti-diabético usado para la diabetes Tipo 2).

Toma de XENICAL con alimentos, bebida y alcohol Xenical se puede tomar inmediatamente antes, durante la comida o hasta una hora después. Se debe tragar la cápsula con agua.

**Embarazo y lactancia**

No se recomienda tomar Xenical durante el embarazo. No debe amamantar a su hijo durante el tratamiento con Xenical, ya que se desconoce si Xenical pasa a la leche materna.

**Conducción y uso de máquinas**

Xenical no tiene ningún efecto conocido sobre la capacidad para conducir o utilizar maquinas.


#### 3. Cómo tomar XENICAL 120 mg cápsulas duras 

 

Siga exactamente las instrucciones de administración de Xenical indicadas por su médico. En caso de duda, consulte a su médico o farmacéutico.La dosis recomendada de Xenical es de una cápsula de 120 mg tomada con cada una de las tres comidas principales del día. Se puede tomar inmediatamente antes, durante o hasta una hora después de la comida. La cápsula debe ser ingerida con agua.

Xenical debe ser tomado con una dieta con control de calorías, bien equilibrada, rica en frutas y verduras y que contenga una media del 30 % de las calorías provenientes de la grasa. Su ingesta diaria de grasas, hidratos de carbono y proteínas debe ser distribuida en tres comidas. Esto quiere decir que habitualmente tomará una cápsula en el desayuno, otra en la comida y otra en la cena. Para lograr beneficios óptimos, evite la ingesta de alimentos que contengan grasa entre las comidas, tales como galletas, chocolate o aperitivos salados.

Xenical actúa solamente en presencia de la grasas de la dieta. Por lo tanto, no necesita tomar Xenical si no toma alguna comida principal o si toma una comida que no contenga grasa. Si por cualquier motivo no ha tomado su medicina exactamente como se la han prescrito, dígaselo a su médico. De lo contrario, su médico puede pensar que éste medicamento no fue eficaz o bien tolerado y puede cambiar su tratamiento sin necesidad de ello.

Su médico interrumpirá el tratamiento con Xenical si después de 12 semanas no ha perdido al menos el 5 % de su peso al inicio del tratamiento.

Xenical ha sido estudiado en ensayos clínicos de hasta 4 años de duración.

Si toma más XENICAL del que debe Si toma más cápsulas de las que le ha indicado su médico, o si alguna otra persona ingiere su medicamento accidentalmente, contacte con su médico, farmacéutico u hospital ya que puede precisar atención médica.

Si olvidó tomar XENICAL Si olvida tomar su medicamento en cualquier momento, tómelo tan pronto como se acuerde a condición de que sea hasta una hora después de ingerir su comida y a continuación continúe tomándolo a los intervalos habituales. No tome una dosis doble para compensar las dosis olvidadas. Si ha dejado de tomar varias dosis, por favor, informe a su médico y siga el consejo que éste le dé.

No cambie por sí mismo la dosis prescrita a menos que se lo diga su médico.

Si tiene cualquier duda sobre el uso de este producto, pregunte a su medico o farmacéutico.


#### 4. Posibles efectos adversos

 

Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.

Si no se encuentra bien mientras está tomando Xenical, coménteselo a su médico o farmacéutico lo antes posible.

La mayoría de los efectos no deseados relacionados con el uso de Xenical son resultado de su acción local sobre el sistema digestivo. Estos síntomas son generalmente moderados, ocurren al comienzo del tratamiento, y se presentan sobre todo después de comidas que tienen altos niveles de grasa. Normalmente, estos síntomas desaparecen si continúa con el tratamiento y sigue la dieta recomendada.

Efectos adversos muy frecuentes (afectan a más de 1 de cada 10 pacientes)

Cefalea, dolor o molestias abdominales, urgencia o aumento de la necesidad de defecar, flatulencia (gases) con incontinencia fecal, incontinencia fecal aceitosa, heces aceitosas o grasas, heces líquidas, bajos niveles de azúcar en sangre (experimentado por algunos pacientes con diabetes tipo 2)

Efectos adversos frecuentes (afectan a entre 1 y 10 de cada 100 pacientes)

Dolor o molestias rectales, heces blandas, incontinencia (fecal), hinchazón (experimentado por algunos pacientes con diabetes tipo 2), alteraciones en los dientes y las encías, irregularidad del ciclo menstrual, fatiga.

También se han comunicado los siguientes efectos adversos pero no se pueden estimar sus frecuencias a partir de los datos disponibles:

Reacciones alérgicas. Los síntomas principales son: picor, erupción cutánea, ronchas (zonas de piel ligeramente elevadas que pican y que están más pálidas o enrojecidas que la piel de alrededor), gran dificultad para respirar, náuseas, vómitos y malestar. Ampollas en la piel (incluyen las ampollas que se explotan). Diverticulitis. Sangrado rectal. Pueden detectarse incrementos en los niveles de enzimas del hígado en los análisis de sangre. Hepatitis (inflamación del hígado). Los síntomas pueden incluir coloración amarillenta de la piel y de los ojos, picor, orina de color oscuro, dolor de estómago y sensibilidad del hígado (indicado por dolor debajo de la parte frontal de la caja torácica en el lado derecho), algunas veces con pérdida de apetito. Deje de tomar Xenical si aparecen estos síntomas e informe a su médico. Cálculos biliares. Pancreatitis (inflamación del páncreas). Nefropatía por oxalato (desarrollada por el oxalato de calcio que puede originar cálculos renales). Véase Capítulo 2, Tenga especial cuidado con Xenical.Interacciones con anticoagulantes.

Comunicación de efectos adversosSi experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del sistema nacional de notificación incluido en el Anexo V*. Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.


#### 5. Conservación de XENICAL 120 mg cápsulas duras 

 

Mantener fuera de la vista y del alcance de los niños.

**Blisters **No utilice este medicamento después de la fecha de caducidad que aparece en el envase. No conservar a temperatura superior a 25 ºC Conservar en el embalaje original y mantener el blíster en el embalaje exterior para protegerlo de la luz y de la humedad.

**Frascos de cristal**No utilice este medicamento después de la fecha de caducidad que aparece en el envase. No conservar a temperatura superior a 30 ºC Mantener el envase perfectamente cerrado para protegerlo de la humedad

Los medicamentos no se deben tirar por los desagües ni a la basura. Pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma ayudará a proteger el medio ambiente.


#### 6. Contenido del envase e información adicional

 

Composición de Xenical

* El principio activo es orlistat. Cada cápsula contiene 120 mg de orlistat.
* Los demás componentes son celulosa microcristalina (E460), carboximetilalmidón sódico (tipo A), povidona (E1201), laurilsulfato de sodio y talco. La cubierta de la cápsula está compuesta de gelatina, índigo carmín (E132), dióxido de titanio (E171) y tinta comestible.

Aspecto del producto y contenido del envase

Xenical son cápsulas de color turquesa con la inscripción "XENICAL 120" y se suministran en envases blister y frascos de vidrio conteniendo 21, 42 y 84 cápsulas.Puede que solamente estén comercializados algunos tamaños de envases.

Titular de la autorización de comercialización CHEPLAPHARM Arzneimittel GmbH Ziegelhof 17489 GreifswaldAlemania

Responsable de la fabricación CHEPLAPHARM Arzneimittel GmbH Bahnhofstr. 1a 17498 Mesekenhagen Alemania

o

CHEPLAPHARM Arzneimittel GmbH Ziegelhof 23-17489 GreifswaldAlemania

Fecha de la última revisión de este prospecto

La información detallada de este medicamento está disponible en la página web de la Agencia Europea de Medicamentos [http://www.ema.europa.eu/](http://www.ema.europa.eu/).


####  Xenical 120mg hard capsules 
PMSWI:
** EU/1/98/071/004 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E82809 **
-------

Full name: **Xenical 120mg hard capsules**

 - Invented name part: ** Xenical ** 

 - Scientific name part: ** Orlistat ** 

 - Strength part: ** 120mg ** 

 - Pharmaceutical dose form part: ** hard capsules ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/98/071/004 ** 

 Region: ** ** 

Marketing authorisation holder: **CHEPLAPHARM Arzneimittel GmbH** 

 Identifier: 
*  **ORG-100000214** 
 

 Status: ** Active (2018-06-21) ** 

 Package 1 of 1

PMSWI: ** EU/1/98/071/004 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****16 

Administrable Product (1 of 1)

 Dose form: ** Capsule, hard ** 

 Unit of presentation: ** Capsule, hard ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** active ** 

 Substance: ** ORLISTAT ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** MICROCRYSTALLINE CELLULOSE ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** SODIUM STARCH GLYCOLATE TYPE A ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** POVIDONE, UNSPECIFIED ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** SODIUM LAURYL SULFATE ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** GELATIN, UNSPECIFIED ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** TITANIUM DIOXIDE ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-es-4fab126d28f65a1084e7b50a23200363",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "es",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/98/071/004"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-es-bc60fa1aa0bfe774d11ee13c0c131622",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-es-bc60fa1aa0bfe774d11ee13c0c131622",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"es\" lang=\"es\"><a name=\"Composition_composition-es-bc60fa1aa0bfe774d11ee13c0c131622\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-es-bc60fa1aa0bfe774d11ee13c0c131622</b></p><a name=\"composition-es-bc60fa1aa0bfe774d11ee13c0c131622\"> </a><a name=\"hccomposition-es-bc60fa1aa0bfe774d11ee13c0c131622\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: es</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/EU/1/13/853/001</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#Organization_mah-4aaf055c3c7bab96579cd18496b045eb\">Organization CHEPLAPHARM Arzneimittel GmbH</a></p><p><b>title</b>: TEST PURPOSES ONLY - Xenical 120mg hard capsules</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "EU/1/13/853/001"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-4aaf055c3c7bab96579cd18496b045eb"
      }],
      "title" : "TEST PURPOSES ONLY - Xenical 120mg hard capsules",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. PROSPECTO",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PROSPECTO"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "PROSPECTO: INFORMACIÓN PARA EL USUARIO"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>XENICAL 120 mg cápsulas duras Orlistat</p><p>Lea todo el prospecto detenidamente antes de empezar a tomar este medicamento, porque contiene información importante para usted.</p><p>• Conserve este prospecto, ya que puede tener que volver a leerlo.</p><p>• Si tiene alguna duda, consulte a su médico* farmacéutico.</p><p>• Este medicamento se le ha recetado solamente a usted y no debe dárselo a otras personas, aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.</p><p>• Si experimenta efectos adversos, consulte a su médico* farmacéutico, incluso si se trata deefectos adversos que no aparecen en este prospecto. Ver sección 4</p></div>"
          }
        },
        {
          "title" : "Contenido del prospecto",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Contenido del prospecto"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Contenido del prospecto:</p><ol><li>Qué es Xenical y para qué se utiliza</li><li>Qué necesita saber antes de empezar a tomar Xenical</li><li>Cómo tomar Xenical</li><li>Posibles efectos adversos</li><li>Conservación de Xenical</li><li>Contenido del envase e información adicional</li></ol></div>"
          }
        },
        {
          "title" : "1. Qué es XENICAL 120 mg cápsulas duras  y para qué se utiliza",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Qué es XENICAL 120 mg cápsulas duras  y para qué se utiliza"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Xenical es un medicamento utilizado para tratar la obesidad. Actúa sobre su sistema digestivo evitando que se digiera alrededor de un tercio de la grasa contenida en la comida que ingiere.Xenical se une a enzimas de su sistema digestivo (lipasas) evitando que hidrolicen parte de las grasas que ha ingerido durante la comida. La grasa no digerida no puede absorberse y su cuerpo la elimina.</p><p>Xenical está indicado para el tratamiento de la obesidad, junto con una dieta con bajo contenido en calorías.</p></div>"
          }
        },
        {
          "title" : "2. Qué necesita saber antes de empezar a tomar XENICAL 120 mg cápsulas duras ",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Qué necesita saber antes de empezar a tomar XENICAL 120 mg cápsulas duras "
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>No tome XENICAL</p><ul><li>Si es alérgico (hipersensible) a orlistat o a cualquiera de los demás componentes de Xenical.</li><li>Si tiene síndrome de malabsorción crónica (absorción insuficiente de nutrientes a través del tracto digestivo).</li><li>Si tiene colestasis (trastorno del hígado).</li><li>Si está en periodo de lactancia</li></ul><p>Advertencias y precauciones La pérdida de peso puede también afectar a la dosis de los medicamentos que tome para otras situaciones (p. ej. colesterol alto o diabetes). Asegúrese de informar a su médico si está tomando éstos u otros medicamentos. La pérdida de peso puede significar que usted necesite un ajuste de la dosis de estos medicamentos.</p><p>Para obtener el máximo beneficio de Xenical debe seguir el programa de nutrición recomendado por su médico. Como ocurre con cualquier otro programa de control de peso, el consumo excesivo de grasa y calorías puede reducir el efecto en la pérdida de peso.</p><p>Este medicamento puede causar un cambio no perjudicial en sus hábitos de evacuación intestinal, tal como puede ser la presencia de heces grasas o aceitosas, debido a la eliminación por las heces de grasa sin digerir. La posibilidad de que esto ocurra puede aumentar si Xenical se toma con una dieta rica en grasa. Además, su ingesta diaria de grasa debe ser distribuida equitativamente entre las tres principales comidas ya que si Xenical se toma con una comida muy alta en grasa se puede incrementar la posibilidad de que se den efectos gastrointestinales.</p><p>En caso de diarrea grave podría haber un fallo de los anticonceptivos orales, por lo que se recomienda el uso de un método anticonceptivo adicional.</p><p>En pacientes con enfermedad renal crónica, el uso de Orlistat puede estar asociado a cálculos renales. Informe a su médico si tiene problemas de riñón.</p><p>Este medicamento contiene menos de 1 mmol de sodio (23 mg) por cápsula; esto es, esencialmente “exento de sodio”.</p><p><strong>Niños</strong></p><p>Xenical no está indicado para su uso en niños.</p><p>Toma de XENICAL con otros medicamentos Informe a su médico o farmacéutico si está tomando o ha tomado recientemente o podría tener que tomar cualquier otro medicamento.</p><p>Esto es importante ya que al utilizar más de un medicamento al mismo tiempo puede aumentar o disminuir su efecto.</p><p>Xenical puede modificar la acción de:</p><ul><li><p>Anticoagulantes (p. ej. warfarina), por ello, su médico puede necesitar monitorizar su coagulación sanguínea.</p></li><li><p>Ciclosporina. No se recomienda la administración conjunta con ciclosporina. Su médico puede necesitar monitorizar sus niveles plasmáticos de ciclosporina con mayor frecuencia de lo habitual.</p></li><li><p>Sales de yodo y/o levotiroxina. Pueden producir casos de hipotiroidismo y/o alteraciones del control del hipotiroidismo.</p></li><li><p>Amiodarona. Consulte con su médico.</p></li><li><p>Medicamentos para tratar el SIDA.</p></li><li><p>Medicamentos para la depresión, para trastornos psiquiátricos o para la ansiedad.</p></li></ul><p>Xenical reduce la absorción de suplementos de algunos nutrientes solubles en grasa, especialmente de beta-caroteno y vitamina E. Por lo tanto, deberá seguir el consejo de su médico y tomar una dieta equilibrada rica en fruta y verduras. Puede que su médico le recomiende un suplemento polivitamínico.</p><p>Orlistat puede alterar el tratamiento anticonvulsionante al disminuir la absorción de los medicamentos antiepilépticos, lo que puede llevar a la aparición de convulsiones. Consulte con su médico si considera que la frecuencia o gravedad de las convulsiones ha cambiado al tomar Xenical junto con medicamentos antiepilépticos.</p><p>No se recomienda Xenical para los que esten tomando acarbosa (fármaco anti-diabético usado para la diabetes Tipo 2).</p><p>Toma de XENICAL con alimentos, bebida y alcohol Xenical se puede tomar inmediatamente antes, durante la comida o hasta una hora después. Se debe tragar la cápsula con agua.</p><p><strong>Embarazo y lactancia</strong></p><p>No se recomienda tomar Xenical durante el embarazo. No debe amamantar a su hijo durante el tratamiento con Xenical, ya que se desconoce si Xenical pasa a la leche materna.</p><p><strong>Conducción y uso de máquinas</strong></p><p>Xenical no tiene ningún efecto conocido sobre la capacidad para conducir o utilizar maquinas.</p></div>"
          }
        },
        {
          "title" : "3. Cómo tomar XENICAL 120 mg cápsulas duras ",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Cómo tomar XENICAL 120 mg cápsulas duras "
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Siga exactamente las instrucciones de administración de Xenical indicadas por su médico. En caso de duda, consulte a su médico o farmacéutico.La dosis recomendada de Xenical es de una cápsula de 120 mg tomada con cada una de las tres comidas principales del día. Se puede tomar inmediatamente antes, durante o hasta una hora después de la comida. La cápsula debe ser ingerida con agua.</p><p>Xenical debe ser tomado con una dieta con control de calorías, bien equilibrada, rica en frutas y verduras y que contenga una media del 30 % de las calorías provenientes de la grasa. Su ingesta diaria de grasas, hidratos de carbono y proteínas debe ser distribuida en tres comidas. Esto quiere decir que habitualmente tomará una cápsula en el desayuno, otra en la comida y otra en la cena. Para lograr beneficios óptimos, evite la ingesta de alimentos que contengan grasa entre las comidas, tales como galletas, chocolate o aperitivos salados.</p><p>Xenical actúa solamente en presencia de la grasas de la dieta. Por lo tanto, no necesita tomar Xenical si no toma alguna comida principal o si toma una comida que no contenga grasa. Si por cualquier motivo no ha tomado su medicina exactamente como se la han prescrito, dígaselo a su médico. De lo contrario, su médico puede pensar que éste medicamento no fue eficaz o bien tolerado y puede cambiar su tratamiento sin necesidad de ello.</p><p>Su médico interrumpirá el tratamiento con Xenical si después de 12 semanas no ha perdido al menos el 5 % de su peso al inicio del tratamiento.</p><p>Xenical ha sido estudiado en ensayos clínicos de hasta 4 años de duración.</p><p>Si toma más XENICAL del que debe Si toma más cápsulas de las que le ha indicado su médico, o si alguna otra persona ingiere su medicamento accidentalmente, contacte con su médico, farmacéutico u hospital ya que puede precisar atención médica.</p><p>Si olvidó tomar XENICAL Si olvida tomar su medicamento en cualquier momento, tómelo tan pronto como se acuerde a condición de que sea hasta una hora después de ingerir su comida y a continuación continúe tomándolo a los intervalos habituales. No tome una dosis doble para compensar las dosis olvidadas. Si ha dejado de tomar varias dosis, por favor, informe a su médico y siga el consejo que éste le dé.</p><p>No cambie por sí mismo la dosis prescrita a menos que se lo diga su médico.</p><p>Si tiene cualquier duda sobre el uso de este producto, pregunte a su medico o farmacéutico.</p></div>"
          }
        },
        {
          "title" : "4. Posibles efectos adversos",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Posibles efectos adversos"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Al igual que todos los medicamentos, este medicamento puede producir efectos adversos, aunque no todas las personas los sufran.</p><p>Si no se encuentra bien mientras está tomando Xenical, coménteselo a su médico o farmacéutico lo antes posible.</p><p>La mayoría de los efectos no deseados relacionados con el uso de Xenical son resultado de su acción local sobre el sistema digestivo. Estos síntomas son generalmente moderados, ocurren al comienzo del tratamiento, y se presentan sobre todo después de comidas que tienen altos niveles de grasa. Normalmente, estos síntomas desaparecen si continúa con el tratamiento y sigue la dieta recomendada.</p><p>Efectos adversos muy frecuentes (afectan a más de 1 de cada 10 pacientes)</p><p>Cefalea, dolor o molestias abdominales, urgencia o aumento de la necesidad de defecar, flatulencia (gases) con incontinencia fecal, incontinencia fecal aceitosa, heces aceitosas o grasas, heces líquidas, bajos niveles de azúcar en sangre (experimentado por algunos pacientes con diabetes tipo 2)</p><p>Efectos adversos frecuentes (afectan a entre 1 y 10 de cada 100 pacientes)</p><p>Dolor o molestias rectales, heces blandas, incontinencia (fecal), hinchazón (experimentado por algunos pacientes con diabetes tipo 2), alteraciones en los dientes y las encías, irregularidad del ciclo menstrual, fatiga.</p><p>También se han comunicado los siguientes efectos adversos pero no se pueden estimar sus frecuencias a partir de los datos disponibles:</p><p>Reacciones alérgicas. Los síntomas principales son: picor, erupción cutánea, ronchas (zonas de piel ligeramente elevadas que pican y que están más pálidas o enrojecidas que la piel de alrededor), gran dificultad para respirar, náuseas, vómitos y malestar. Ampollas en la piel (incluyen las ampollas que se explotan). Diverticulitis. Sangrado rectal. Pueden detectarse incrementos en los niveles de enzimas del hígado en los análisis de sangre. Hepatitis (inflamación del hígado). Los síntomas pueden incluir coloración amarillenta de la piel y de los ojos, picor, orina de color oscuro, dolor de estómago y sensibilidad del hígado (indicado por dolor debajo de la parte frontal de la caja torácica en el lado derecho), algunas veces con pérdida de apetito. Deje de tomar Xenical si aparecen estos síntomas e informe a su médico. Cálculos biliares. Pancreatitis (inflamación del páncreas). Nefropatía por oxalato (desarrollada por el oxalato de calcio que puede originar cálculos renales). Véase Capítulo 2, Tenga especial cuidado con Xenical.Interacciones con anticoagulantes.</p><p>Comunicación de efectos adversosSi experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del sistema nacional de notificación incluido en el Anexo V*. Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.</p></div>"
          }
        },
        {
          "title" : "5. Conservación de XENICAL 120 mg cápsulas duras ",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Conservación de XENICAL 120 mg cápsulas duras "
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Mantener fuera de la vista y del alcance de los niños.</p><p><strong>Blisters </strong>No utilice este medicamento después de la fecha de caducidad que aparece en el envase. No conservar a temperatura superior a 25 ºC Conservar en el embalaje original y mantener el blíster en el embalaje exterior para protegerlo de la luz y de la humedad.</p><p><strong>Frascos de cristal</strong>No utilice este medicamento después de la fecha de caducidad que aparece en el envase. No conservar a temperatura superior a 30 ºC Mantener el envase perfectamente cerrado para protegerlo de la humedad</p><p>Los medicamentos no se deben tirar por los desagües ni a la basura. Pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que ya no necesita. De esta forma ayudará a proteger el medio ambiente.</p></div>"
          }
        },
        {
          "title" : "6. Contenido del envase e información adicional",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contenido del envase e información adicional"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Composición de Xenical</p><ul><li>El principio activo es orlistat. Cada cápsula contiene 120 mg de orlistat.</li><li>Los demás componentes son celulosa microcristalina (E460), carboximetilalmidón sódico (tipo A), povidona (E1201), laurilsulfato de sodio y talco. La cubierta de la cápsula está compuesta de gelatina, índigo carmín (E132), dióxido de titanio (E171) y tinta comestible.</li></ul><p>Aspecto del producto y contenido del envase</p><p>Xenical son cápsulas de color turquesa con la inscripción &quot;XENICAL 120&quot; y se suministran en envases blister y frascos de vidrio conteniendo 21, 42 y 84 cápsulas.Puede que solamente estén comercializados algunos tamaños de envases.</p><p>Titular de la autorización de comercialización CHEPLAPHARM Arzneimittel GmbH Ziegelhof 17489 GreifswaldAlemania</p><p>Responsable de la fabricación CHEPLAPHARM Arzneimittel GmbH Bahnhofstr. 1a 17498 Mesekenhagen Alemania</p><p>o</p><p>CHEPLAPHARM Arzneimittel GmbH Ziegelhof 23-17489 GreifswaldAlemania</p><p>Fecha de la última revisión de este prospecto</p><p>La información detallada de este medicamento está disponible en la página web de la Agencia Europea de Medicamentos <a href=\"http://www.ema.europa.eu/\">http://www.ema.europa.eu/</a>.</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-xenical-orlistat",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-xenical-orlistat",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-xenical-orlistat\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-xenical-orlistat</b></p><a name=\"ingredient-for-xenical-orlistat\"> </a><a name=\"hcingredient-for-xenical-orlistat\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/95M8R751W8 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#AdministrableProductDefinition_ap-4fab126d28f65a1084e7b50a23200363\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004; status = active; administrableDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 72072}\">active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 95M8R751W8}\">ORLISTAT</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>120 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "95M8R751W8"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-4fab126d28f65a1084e7b50a23200363"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "72072",
          "display" : "active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "95M8R751W8",
              "display" : "ORLISTAT"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 120,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-xenical-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-xenical-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-xenical-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-xenical-microcrystallinecellulose</b></p><a name=\"ingredient-for-xenical-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-xenical-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#AdministrableProductDefinition_ap-4fab126d28f65a1084e7b50a23200363\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004; status = active; administrableDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">MICROCRYSTALLINE CELLULOSE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-4fab126d28f65a1084e7b50a23200363"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "MICROCRYSTALLINE CELLULOSE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-xenical-sodiumstarchglycolatetypea",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-xenical-sodiumstarchglycolatetypea",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-xenical-sodiumstarchglycolatetypea\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-xenical-sodiumstarchglycolatetypea</b></p><a name=\"ingredient-for-xenical-sodiumstarchglycolatetypea\"> </a><a name=\"hcingredient-for-xenical-sodiumstarchglycolatetypea\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/H8AV0SQX4D (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#AdministrableProductDefinition_ap-4fab126d28f65a1084e7b50a23200363\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004; status = active; administrableDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta H8AV0SQX4D}\">SODIUM STARCH GLYCOLATE TYPE A</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "H8AV0SQX4D"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-4fab126d28f65a1084e7b50a23200363"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "H8AV0SQX4D",
              "display" : "SODIUM STARCH GLYCOLATE TYPE A"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-xenical-povidoneunspecified",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-xenical-povidoneunspecified",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-xenical-povidoneunspecified\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-xenical-povidoneunspecified</b></p><a name=\"ingredient-for-xenical-povidoneunspecified\"> </a><a name=\"hcingredient-for-xenical-povidoneunspecified\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/FZ989GH94E (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#AdministrableProductDefinition_ap-4fab126d28f65a1084e7b50a23200363\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004; status = active; administrableDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta FZ989GH94E}\">POVIDONE, UNSPECIFIED</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "FZ989GH94E"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-4fab126d28f65a1084e7b50a23200363"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "FZ989GH94E",
              "display" : "POVIDONE, UNSPECIFIED"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-xenical-sodiumlaurylsulfate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-xenical-sodiumlaurylsulfate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-xenical-sodiumlaurylsulfate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-xenical-sodiumlaurylsulfate</b></p><a name=\"ingredient-for-xenical-sodiumlaurylsulfate\"> </a><a name=\"hcingredient-for-xenical-sodiumlaurylsulfate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/368GB5141J (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#AdministrableProductDefinition_ap-4fab126d28f65a1084e7b50a23200363\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004; status = active; administrableDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 368GB5141J}\">SODIUM LAURYL SULFATE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "368GB5141J"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-4fab126d28f65a1084e7b50a23200363"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "368GB5141J",
              "display" : "SODIUM LAURYL SULFATE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-xenical-gelatinunspecified",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-xenical-gelatinunspecified",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-xenical-gelatinunspecified\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-xenical-gelatinunspecified</b></p><a name=\"ingredient-for-xenical-gelatinunspecified\"> </a><a name=\"hcingredient-for-xenical-gelatinunspecified\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/2G86QN327L (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#AdministrableProductDefinition_ap-4fab126d28f65a1084e7b50a23200363\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004; status = active; administrableDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 2G86QN327L}\">GELATIN, UNSPECIFIED</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "2G86QN327L"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-4fab126d28f65a1084e7b50a23200363"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "2G86QN327L",
              "display" : "GELATIN, UNSPECIFIED"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-xenical-titaniumdioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-xenical-titaniumdioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-xenical-titaniumdioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-xenical-titaniumdioxide</b></p><a name=\"ingredient-for-xenical-titaniumdioxide\"> </a><a name=\"hcingredient-for-xenical-titaniumdioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/15FIX9V2JP (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#AdministrableProductDefinition_ap-4fab126d28f65a1084e7b50a23200363\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004; status = active; administrableDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 15FIX9V2JP}\">TITANIUM DIOXIDE</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "15FIX9V2JP"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
      },
      {
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-4fab126d28f65a1084e7b50a23200363"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "15FIX9V2JP",
              "display" : "TITANIUM DIOXIDE"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-orlistat",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-orlistat",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-orlistat\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-orlistat</b></p><a name=\"substance-orlistat\"> </a><a name=\"hcsubstance-orlistat\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/95M8R751W8 (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>manufacturer</b>: <a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#Organization_mah-4aaf055c3c7bab96579cd18496b045eb\">Organization CHEPLAPHARM Arzneimittel GmbH</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>495.74</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C29H53NO5</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>L-LEUCINE, N-FORMYL-, 1-((3-HEXYL-4-OXO-2-OXETANYL)METHYL)DODECYL ESTER, (2S-(2.ALPHA.(R*),3.BETA.))-</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "95M8R751W8"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/mah-4aaf055c3c7bab96579cd18496b045eb"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 495.74
        }
      }],
      "structure" : {
        "molecularFormula" : "C29H53NO5"
      },
      "name" : [{
        "name" : "L-LEUCINE, N-FORMYL-, 1-((3-HEXYL-4-OXO-2-OXETANYL)METHYL)DODECYL ESTER, (2S-(2.ALPHA.(R*),3.BETA.))-",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-4fab126d28f65a1084e7b50a23200363",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-4fab126d28f65a1084e7b50a23200363",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-4fab126d28f65a1084e7b50a23200363\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-4fab126d28f65a1084e7b50a23200363</b></p><a name=\"ap-4fab126d28f65a1084e7b50a23200363\"> </a><a name=\"hcap-4fab126d28f65a1084e7b50a23200363\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/98/071/004</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073375}\">Capsule, hard</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073375}\">Capsule, hard</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/98/071/004"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073375",
          "display" : "Capsule, hard"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073375",
          "display" : "Capsule, hard"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization4fab126d28f65a1084e7b50a232003630",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization4fab126d28f65a1084e7b50a232003630",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization4fab126d28f65a1084e7b50a232003630\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization4fab126d28f65a1084e7b50a232003630</b></p><a name=\"authorization4fab126d28f65a1084e7b50a232003630\"> </a><a name=\"hcauthorization4fab126d28f65a1084e7b50a232003630\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/98/071/004 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072062}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2018-06-21</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#Organization_mah-4aaf055c3c7bab96579cd18496b045eb\">Organization CHEPLAPHARM Arzneimittel GmbH</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/98/071/004"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072062",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2018-06-21",
      "holder" : {
        "reference" : "Organization/mah-4aaf055c3c7bab96579cd18496b045eb"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-4aaf055c3c7bab96579cd18496b045eb",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-4aaf055c3c7bab96579cd18496b045eb",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-4aaf055c3c7bab96579cd18496b045eb\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-4aaf055c3c7bab96579cd18496b045eb</b></p><a name=\"mah-4aaf055c3c7bab96579cd18496b045eb\"> </a><a name=\"hcmah-4aaf055c3c7bab96579cd18496b045eb\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100000214 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: CHEPLAPHARM Arzneimittel GmbH</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Ziegelhof 24 17489 Greifswald Germany Greifswald Germany(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100000214"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "CHEPLAPHARM Arzneimittel GmbH",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Ziegelhof 24 17489 Greifswald Germany Greifswald Germany",
          "line" : ["Ziegelhof 24 17489 Greifswald Germany"],
          "city" : "Greifswald",
          "postalCode" : "17489",
          "country" : "Germany"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-352d83277f894aa6147981b6a4f36c07",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-352d83277f894aa6147981b6a4f36c07",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-352d83277f894aa6147981b6a4f36c07\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-352d83277f894aa6147981b6a4f36c07</b></p><a name=\"ppd-352d83277f894aa6147981b6a4f36c07\"> </a><a name=\"hcppd-352d83277f894aa6147981b6a4f36c07\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/98/071/004 (use: official, )</p><p><b>name</b>: Xenical 120mg hard capsules 1</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Prodcut</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82809; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 16 {capsules}<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{capsules} = '{capsules}')</span></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/7777</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-en-4fab126d28f65a1084e7b50a23200363.html#ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/98/071/004 (use: official, ); status = active; manufacturedDoseForm = Capsule, hard; unitOfPresentation = Capsule, hard</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/98/071/004"
      }],
      "name" : "Xenical 120mg hard capsules 1",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Prodcut"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 16,
        "system" : "http://unitsofmeasure.org",
        "code" : "{capsules}"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "7777"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073498",
              "display" : "Box"
            }]
          },
          "quantity" : 1,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003529",
              "display" : "Cardboard"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mpbc60fa1aa0bfe774d11ee13c0c131622",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mpbc60fa1aa0bfe774d11ee13c0c131622",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mpbc60fa1aa0bfe774d11ee13c0c131622\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mpbc60fa1aa0bfe774d11ee13c0c131622</b></p><a name=\"mpbc60fa1aa0bfe774d11ee13c0c131622\"> </a><a name=\"hcmpbc60fa1aa0bfe774d11ee13c0c131622\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/98/071/004, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E82809</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Xenical 120mg hard capsules</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Xenical</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Orlistat</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 120mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: hard capsules</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/98/071/004"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E82809"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Xenical 120mg hard capsules",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Xenical",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "Orlistat",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "120mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "hard capsules",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-4fab126d28f65a1084e7b50a23200363",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-4fab126d28f65a1084e7b50a23200363",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-4fab126d28f65a1084e7b50a23200363\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-4fab126d28f65a1084e7b50a23200363</b></p><a name=\"mid-4fab126d28f65a1084e7b50a23200363\"> </a><a name=\"hcmid-4fab126d28f65a1084e7b50a23200363\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/98/071/004 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073375}\">Capsule, hard</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073375}\">Capsule, hard</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/98/071/004"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073375",
          "display" : "Capsule, hard"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073375",
          "display" : "Capsule, hard"
        }]
      }
    }
  }]
}

```
