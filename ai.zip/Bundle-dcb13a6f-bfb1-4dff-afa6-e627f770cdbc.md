# dcb13a6f-bfb1-4dff-afa6-e627f770cdbc - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **dcb13a6f-bfb1-4dff-afa6-e627f770cdbc**

## Bundle: dcb13a6f-bfb1-4dff-afa6-e627f770cdbc



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "dcb13a6f-bfb1-4dff-afa6-e627f770cdbc",
  "identifier" : {
    "system" : "http://ema.europa.eu/fhir/epiGuid",
    "value" : "dcb13a6f-bfb1-4dff-afa6-e627f770cdbc"
  },
  "type" : "collection",
  "timestamp" : "2024-12-13T18:58:38.41052+01:00",
  "entry" : [{
    "fullUrl" : "adfcf1db-4486-4d5f-8be8-e98000ca2cbc",
    "resource" : {
      "resourceType" : "List",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_null\"> </a>electronic Product Information (ePI) master document list</div>"
      },
      "identifier" : [{
        "system" : "http://ema.europa.eu/fhir/epiId",
        "value" : "EPI/24/129"
      }],
      "status" : "current",
      "mode" : "working",
      "title" : "all sections Spanish document",
      "code" : {
        "coding" : [{
          "system" : "http://ema.europa.eu/fhir/documentType",
          "code" : "00001",
          "display" : "epiMasterList"
        }]
      },
      "subject" : [{
        "reference" : "subjectReference"
      }],
      "entry" : [{
        "item" : {
          "reference" : "referenceToDocument",
          "display" : "Ficha técnica o resumen de las características del producto"
        }
      },
      {
        "item" : {
          "reference" : "referenceToDocument",
          "display" : "Prospecto"
        }
      }]
    }
  },
  {
    "fullUrl" : "e6f73fef-cd9b-440c-86aa-04e566546f7d",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "e6f73fef-cd9b-440c-86aa-04e566546f7d",
      "identifier" : {
        "system" : "http://ema.europa.eu/fhir/epiDocument",
        "value" : "e6f73fef-cd9b-440c-86aa-04e566546f7d"
      },
      "type" : "document",
      "timestamp" : "2024-12-13T18:58:38.41052+01:00",
      "entry" : [{
        "fullUrl" : "e6f73fef-cd9b-440c-86aa-04e566546f7d",
        "resource" : {
          "resourceType" : "Composition",
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">electronic Product Information (ePI) document</div>"
          },
          "status" : "final",
          "type" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/100000155531",
              "code" : "100000155532",
              "display" : "Ficha técnica o resumen de las características del producto"
            }]
          },
          "subject" : [{
            "reference" : "subjectReference"
          }],
          "date" : "2024-12-13",
          "author" : [{
            "reference" : "systemUser"
          }],
          "title" : "Ficha técnica o resumen de las características del producto",
          "section" : [{
            "title" : "Ficha técnica o resumen de las características del producto",
            "code" : {
              "coding" : [{
                "system" : "http://spor.ema.europa.eu/v1/lists/100000155531",
                "code" : "200000029791",
                "display" : "Ficha técnica o resumen de las características del producto"
              }]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
            },
            "section" : [{
              "id" : "2de15bed-8eef-4626-89c5-1a02a257cf9c",
              "title" : "1. Nombre del medicamento",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029792",
                  "display" : "Nombre del medicamento"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>P</span><span>ENTASA</span><span>1g Supositorios</span></p></div>"
              }
            },
            {
              "id" : "8a176df1-591d-4d6c-89cd-551b8b3f775d",
              "title" : "2. Composición cualitativa y cuantitativa",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029793",
                  "display" : "Composición cualitativa y cuantitativa"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Cada supositorio contiene 1g de mesalazina.</span></p><p><span> </span></p><p><span>Para</span><span>consultar la</span><span>lista completa de</span><span>excipientes ver sección 6.1.</span></p><p><span> </span></p></div>"
              }
            },
            {
              "id" : "e56ad4ad-c0e3-47a2-8923-c89b8fe983cc",
              "title" : "3. Forma farmacéutica",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029797",
                  "display" : "Forma farmacéutica"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Cada supositorio contiene 1g de mesalazina.</span></p><p><span> </span></p><p><span>Para</span><span>consultar la</span><span>lista completa de</span><span>excipientes ver sección 6.1.</span></p></div>"
              }
            },
            {
              "id" : "cd3cc6e7-6045-4984-8cba-f191c2a133a9",
              "title" : "4. Datos clínicos",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029798",
                  "display" : "Datos clínicos"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "6053049c-9564-4484-b483-c166737fe8a7",
                "title" : "4.1. Indicaciones terapéuticas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029799",
                    "display" : "Indicaciones terapéuticas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Tratam</span><span>iento de la proctitis ulcerosa.</span></p></div>"
                }
              },
              {
                "id" : "a3c198a4-1650-42af-9ec4-9a6dee4ebe1d",
                "title" : "4.2. Posología y forma de administración",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029800",
                    "display" : "Posología y forma de administración"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
                },
                "section" : [{
                  "id" : "7c40786b-faad-4782-8425-d9b1628f25df",
                  "title" : "4.2.1. Posología",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029801",
                      "display" : "Posología"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Durante la terapia de mantenimiento a largo plazo, el paciente debe seguir rigurosamente el tratamiento establecido por el médico para asegurar el efecto terapéutico deseado.</span></p><p><span> </span></p><p><span>La dosificación deberá ajustarse en función de la respuesta del paciente. Se recomienda la siguiente dosificación:</span></p><p><span> </span></p><p><span><span>Adultos</span></span></p><p><span>Uno a dos supositorios al día vía rectal.</span></p><p><span> </span></p><p><span><span>Ancianos</span></span></p><p><span>La administración de Pentasa 1g</span><span>s</span><span>upositorios en ancianos debe realizarse con precaución y siempre limitada a aquellos pacientes con la función renal normal.</span></p><p><span> </span></p><p><span><span>Población pediátrica</span></span></p><p><span>Existe</span><span>poca experiencia y</span><span>documentación limitada sobre el</span><span>efecto en niños</span><span>.</span></p></div>"
                  }
                },
                {
                  "id" : "d927f6ed-e351-45d8-82f2-52213d341d38",
                  "title" : "4.2.2. Forma de administración",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029803",
                      "display" : "Forma de administración"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span><span>Se recomienda realizar una evacuación intestinal antes de la administración de la suspensión rectal y los supositorios.</span></span></p><p><span>Se recomienda evacuar antes de la administración del supositorio.</span></p><p><span>Sacar un supositorio del blister.</span></p><p><span>Introducir el supositorio hasta que desaparezca la resistencia.</span></p><p><span>Si se expulsa el supositorio durante los primeros 10 minutos, debe administrar uno nuevo</span></p></div>"
                  }
                }]
              },
              {
                "id" : "739fdb67-94af-46a9-875f-03f1de99fd78",
                "title" : "4.3. Contraindicaciones",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029805",
                    "display" : "Contraindicaciones"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No debe administrarse Pentasa 1g Supositorios en los siguientes casos:</span></p><p><span> </span></p><ul><li><span>Hipersensibilidad a la mesalazina o a los salicilatos, o a algunos de los excipientes incluidos en la sección 6.1.</span></li></ul><p><span>Pacientes con insuficiencia renal o hepática grave.</span></p></div>"
                }
              },
              {
                "id" : "90e17e71-6df7-47e4-a24c-ff8a5963d30d",
                "title" : "4.4. Advertencias y precauciones especiales de empleo",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029806",
                    "display" : "Advertencias y precauciones especiales de empleo"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><a name=\"_Hlk62458863\"/><a name=\"_Hlk125622049\"><span>Debe tenerse especial precaución en el tratamiento de pacientes alérgicos a la sulfasalazina (riesgo de alergia a salicilatos). Se han observado reacciones adversas cutáneas graves, como reacción al medicamento con eosinofilia y síntomas sistémicos (DRESS), síndrome de Stevens-Johnson (SSJ) y necrólisis epidérmica tóxica (NET) con el tratamiento de mesalazina. La administración de mesalazina debe suspenderse inmediatamente en caso de reacciones de intolerancia agudas, tales como calambres abdominales, dolor abdominal agudo, fiebre y dolor de cabeza intenso y/o ante los primeros signos o síntomas de reacciones cutáneas graves, como exantema cutáneo,  erupciones, lesiones mucosas o cualquier otro signo de hipersensibilidad. </span></a></p><p><span> </span></p><p><span>Deben tomarse precauciones especiales en pacientes con la función hepática deteriorada. Se deben evaluar, antes y durante el tratamiento, a criterio del médico, los parámetros de la función hepática como ALT o AST.</span></p><p><span> </span></p><p><span>No se recomienda el uso de Pentasa en pacientes con insuficiencia renal Se debe monitorizar la función renal a intervalos regulares (creatinina sérica), especialmente al inicio del tratamiento. Se debe determinar el estado urinario (tiras reactivas) antes y durante el tratamiento, a criterio del médico. En los pacientes que desarrollen una alteración renal durante el tratamiento se debe sospechar nefrotoxicidad, inducida por la mesalazina.</span><span>El uso concomitante de otros fármacos nefrotóxicos conocidos,</span><span>debe aumentar la frecuencia de monitorización de la función renal.</span></p><p><span> </span></p><p><span>Los pacientes con enfermedad pulmonar, en particular asma, deben ser monitorizados cuidadosamente durante el tratamiento, consultar sección 4.8.</span></p><p><span> </span></p><p><span>Se han comunicado raramente reacciones de hipersensibilidad cardiaca inducidas por mesalazina (mio- y pericarditis). Se han descrito muy raramente discrasias sanguíneas graves. Se recomienda realizar análisis de sangre para el recuento diferencial</span><span>antes y durante el tratamiento, a criterio del médico. Como se señala en la sección 4.5,</span><span>el tratamiento concomitante con mesalazina puede incrementar el riesgo de discrasia sanguínea en pacientes que están siendo tratados con azatioprina, 6-mercaptopurina o tioguanina. Debe interrumpirse el tratamiento cuando exista sospecha ó evidencia de la aparición de dichas reacciones.</span></p><p><span> </span></p><p><span>Se han notificado casos de nefrolitiasis con el uso de mesalazina, lo que incluye la aparición de</span></p><p><span>cálculos con un contenido de mesalazina del 100 %. Se recomienda garantizar una ingesta</span></p><p><span>suficiente de líquidos durante el tratamiento.</span></p><p><span> </span></p><p><span>A título orientativo, se recomienda pruebas de seguimiento 14 días después del inicio del tratamiento y posteriormente otras 2 a 3 pruebas a intervalos de 4 semanas. Si los resultados son normales, las pruebas de seguimiento se deben realizar cada 3 meses. Si se producen síntomas adicionales, estas pruebas se deben realizar inmediatamente.</span></p><p><span> </span></p><p><span>Se debe utilizar con precaución en ancianos y siempre limitada a aquellos pacientes con la función renal normal.</span></p><p><span> </span></p><p><span>La mesalazina puede producir un cambio de color de la orina de color rojo-marrón tras el contacto con lejía de hipoclorito de sodio (por ejemplo, en los inodoros limpiados con ciertas lejías que contienen hipoclorito de sodio).</span></p></div>"
                }
              },
              {
                "id" : "abe6b8fd-5174-47ed-99b1-8fc399a161f3",
                "title" : "4.5. Interacción con otros medicamentos y otras formas de interacción",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029809",
                    "display" : "Interacción con otros medicamentos y otras formas de interacción"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>En varios estudios se ha mostrado una mayor frecuencia de efectos mielosupresores en la terapia combinada con Pentasa y</span><span>azatioprina</span><span>,</span><span>6-mercaptopurina</span><span>o tioguanina</span><span>, y parece existir una interacción, sin embargo, el mecanismo no se ha podido establecer.</span><span>Se recomienda una monitorización de las células blancas sanguíneas y en consecuencia debería ajustarse la dosificación de tiopurinas</span><span>.</span></p><p><span> </span></p><p><span>Existe una evidencia débil de que la mesalazina podría disminuir el efecto anticoagulante de la warfarina.</span></p></div>"
                }
              },
              {
                "id" : "c307f8f9-98b8-44a3-ab2f-8bb848099a70",
                "title" : "4.6. Fertilidad, embarazo y lactancia",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029811",
                    "display" : "Fertilidad, embarazo y lactancia"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No se debe utilizar Pentasa 1 g supositorios durante el embarazo y la lactancia, excepto cuando según la opinión del médico especialista el beneficio potencial supere al riesgo. La enfermedad de base en sí misma (Enfermedad inflamatoria intestinal EII)) puede aumentar los riesgos de resultado adverso del embarazo.</span></p></div>"
                },
                "section" : [{
                  "id" : "36df8a7e-e026-4545-8990-45d908776242",
                  "title" : "4.6.1. Embarazo",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029812",
                      "display" : "Embarazo"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Se sabe que la mesalazina atraviesa la barrera placentaria y la concentración en el cordón umbilical es una décima parte de la concentración en el plasma materno. El metabolito acetil mesalazina se encuentra en la misma concentración en el cordón umbilical y en el plasma de la madre. Los estudios en animales con mesalazina oral, no muestran efectos perjudiciales directos o indirectos en relación al embarazo, desarrollo embrionario/fetal, parto y desarrollo postnatal. No existen estudios adecuados y controlados del uso de Pentasa en mujeres embarazadas. Los datos publicados sobre mesalazina en humanos son limitados  y muestran que no hay un aumento de la tasa global de malformaciones congénitas. Algunos datos muestran un aumento de la tasa de partos pretérmino, muerte fetal, y bajo peso al nacer; sin embargo estos resultados adversos del embarazo también están asociados con la enfermedad inflamatoria intestinal activa.</span></p><p><span>Se han reportado trastornos sanguíneos (pancitopenia, leucopenia, trombocitopenia, anemia) en recién nacidos de madres tratadas con Pentasa.</span></p><p><span> </span></p><p><span>En un caso aislado de utilización a largo plazo de dosis altas de mesalazina (2-4g, vía oral) durante el embarazo, se notificó fallo renal en el neonato.</span></p></div>"
                  }
                },
                {
                  "id" : "09ce3bdc-e98c-4722-80b2-e87f7a8b26ea",
                  "title" : "4.6.2. Lactancia",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029813",
                      "display" : "Lactancia"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>La mesalazina pasa a la leche materna. La concentración de mesalazina en la leche materna es mucho menor que en la sangre materna, mientras que su metabolito, acetil mesalazina, aparece en concentraciones similares o superiores. Hasta la fecha, solo existe una experiencia limitada tras la administración oral en mujeres durante el periodo de lactancia. No se han realizado estudios controlados de Pentasa durante la lactancia. No pueden excluirse reacciones de hipersensibilidad como diarrea.</span></p></div>"
                  }
                },
                {
                  "id" : "d417fe1d-a3fe-44d8-b558-346abb387db1",
                  "title" : "4.6.3. Fertilidad",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029814",
                      "display" : "Fertilidad"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Los datos de mesalazina en animales muestran que no tiene efecto sobre la fertilidad masculina o femenina</span><span><span>.</span></span></p></div>"
                  }
                }]
              },
              {
                "id" : "bb99bf26-cfb4-4b58-8b05-783d6c3e0b04",
                "title" : "4.7. Efectos sobre la capacidad para conducir y utilizar máquinas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029815",
                    "display" : "Efectos sobre la capacidad para conducir y utilizar máquinas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No hay indicios de que Pentasa tenga efecto sobre la capacidad para conducir o utilizar m</span><span>á</span><span>quina</span><span>s.</span></p></div>"
                }
              },
              {
                "id" : "4b7b7d77-ac49-4f52-8438-c40ad53427d5",
                "title" : "4.8. Reacciones adversas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029816",
                    "display" : "Reacciones adversas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><a name=\"_Hlk62458972\"><span>Las reacciones adversas observadas más frecuentemente en los ensayos clínicos son diarrea, náuseas, dolor abdominal, dolor de cabeza, vómitos y erupciones cutáneas.</span></a></p><p><span> </span></p><p><span>Ocasionalmente pueden aparecer reacciones de hipersensibilidad y fiebre medicamentosa.</span></p><p><span>Se han observado reacciones adversas cutáneas graves (RACG), como reacción al medicamento con eosinofilia y síntomas sistémicos (DRESS), el síndrome de Stevens-Johnson (SSJ) y la necrólisis epidérmica tóxica (NET), asociados a la administración de mesalazina (ver sección</span><span> </span><span>4.4).</span></p><p><span> </span></p><p><span>Tras la administración rectal pueden aparecer reacciones locales como prurito, molestias rectales y urgencia de defecar.</span></p><p><span> </span></p><p><span>A continuación se incluye una tabla con la frecuencia de las reacciones adversas, basada en los ensayos clínicos y estudios epidemiológicos:</span></p><p><span> </span></p><table cellpadding=\"0\" cellspacing=\"0\"><tr><td><p><span>Clasificación de órganos del sistema MedDRA</span></p></td><td><p><span>Frecuentes</span></p><p><span>(</span><span>?</span><span>1/100 a &lt; 1/10)</span></p></td><td><p><span>Raras</span></p><p><span>(</span><span>?</span><span>10/10.000 a &lt; 1/1.000)</span></p></td><td><p><span>Muy raras</span></p><p><span>(&lt; 1/10.000)</span></p></td><td><p><span>Frecuencia no conocida (no puede estimarse a partir de los datos disponibles)</span></p></td></tr><tr><td><p><span>Trastornos de la sangre y del sistema linfático:</span></p><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Recuento sanguíneo alterado (anemia, anemia aplásica, agranulocitosis, neutropenia, leucopenia (incluida granulocitopenia) trombocitopenia, pancitopenia y eosinofilia (como parte de una reacción alérgica))</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos del sistema inmunológico</span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p><p><span>Reacción de hipersensibilidad que incluye reacción anafiláctica</span></p><p><span> </span></p><p><span> </span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos del sistema nervioso:</span></p></td><td><p><span>Dolor de cabeza</span></p><p><span> </span></p></td><td><p><span>Mareos</span></p></td><td><p><span>Neuropatía periférica</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos cardíacos</span></p></td><td><p><span> </span></p></td><td><p><span>Miocarditis*</span></p><p><span> </span></p><p><span>Pericarditis*</span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos respiratorios, torácicos y mediastínicos</span></p><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Reacciones pulmonares alérgicas y fibróticas (incluida disnea, tos, broncoespasmo, alveolitis alérgica), eosinofilia pulmonar, enfermedad pulmonar intersticial, infiltración pulmonar, neumonitis.</span></p><p><span> </span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos</span><span>gastrointestinales</span></p></td><td><p><span>Diarrea, dolor abdominal, náuseas, vómitos, flatulencia</span></p></td><td><p><span>Aumento de la amilasa, pancreatitis aguda*</span></p></td><td><p><span>Pancolitis</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos hepatobiliares</span></p><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Aumento de las transaminasas, aumento de los parámetros colestásicos (p.e. fostasa alcalina, gamma-glutamil transferasa y bilirrubina), hepatotoxicidad (incluida hepatitis*, hepatitis colestásica, cirrosis, fallo hepático)</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos de la piel y el tejido subcutáneo</span></p></td><td><p><span>Erupciones (incluida urticaria, erupción eritematosa)</span></p></td><td><p><span>Fotosensibilidad**</span></p></td><td><p><span>Alopecia reversible</span></p><p><span> </span></p><p><span>Dermatitis alérgica</span></p><p><span> </span></p><p><span>Eritema multiforme</span></p></td><td><p><span>Síndrome de Stevens-Johson (SJS),</span><span>Nnecrólisis epidérmica tóxica (TEN),</span></p><p><span>Reacción al medicamento con eosinofilia y síntomas sistémicos (DRESS)</span></p></td></tr><tr><td><p><span>Trastorno</span><span>musculoesqueléticos y del tejido conjuntivo</span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Mialgia, artralgia, Síndrome de pseudolupus</span></p><p><span>(lupus eritematoso sistémico)</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos renales y urinarios***</span></p><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Alteración de la función renal (incl. nefritis intersticial* aguda y crónica,</span></p><p><span>síndrome nefrótico, insuficiencia renal)</span></p></td><td><p><span>Nefrolitiasis*** Decoloración de la orina***</span></p></td></tr><tr><td><p><span>Trastornos del aparato reproductor</span></p></td><td><p><span> </span></p></td><td><p><span> </span></p></td><td><p><span>Oligospermia (reversible)</span></p></td><td><p><span> </span></p></td></tr><tr><td><p><span>Trastornos generales y alteraciones en el lugar de administración:</span></p></td><td><p><span>Malestar anal e irritación en el lugar de la administración, prurito, tenesmo</span></p></td><td><p><span> </span></p></td><td><p><span>Fiebre medicamentosa</span></p></td><td><p><span> </span></p></td></tr></table><p><span> </span></p><p><span>(*) No se conoce el mecanismo de la mesalazina para inducir mio- y pericarditis, pancreatitis, nefritis y hepatitis, pero puede tener un origen alérgico. (La forma de presentación y resolución de los cuadros citados dentro de su posible origen alérgico están sujetos a una alta variabilidad inter e intraindividual, por lo que es imposible prever la gravedad y la evolución de los mismos.)</span></p><p><span>(**) Se han notificado reacciones más graves en pacientes con afecciones cutáneas preexistentes, como dermatitis atópica y eccema atópico.</span></p><p><span>(***)Véase la sección 4.4 si desea más información.</span></p><p><span> </span></p><p><span>Es importante resaltar que varias de estas alteraciones pueden también atribuirse a la enfermedad inflamatoria intestinal en sí misma.</span></p><p><span> </span></p><p><strong><span>Notificación de sospechas de reacciones adversas</span></strong></p><p><strong><span> </span></strong></p><p><span>Es importante notificar sospechas de reacciones adversas al medicamento tras su  autorización. Ello permite una supervisión continuada de la relación beneficio/riesgo del medicamento. Se invita a los profesionales sanitarios a notificar las sospechas de reacciones adversas a través del</span><span>Sistema Español de Farmacovigilancia de Medicamentos de Uso Humano</span><span>:</span><a href=\"http://www.notificaRAM.es\"><span><span>www.notificaRAM.es</span></span></a><span>.</span></p></div>"
                }
              },
              {
                "id" : "4cd0db52-614e-451f-91fc-9460db31d2d7",
                "title" : "4.9. Sobredosis",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029819",
                    "display" : "Sobredosis"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span><span>Experiencia en animales:</span></span></p><p><span>La administración de una dosis única intravenosa de mesalazina de 920 mg/kg en ratas ó de dosis orales únicas de mesalazina de hasta 5 g/kg en cerdos no dieron lugar a mortalidad.</span></p><p><span><span>Experiencia en humanos:</span></span></p><p><span>Existe una experiencia clínica limitada en relación a la sobredosis con Pentasa, que  no indica toxicidad renal o hepática. Teniendo en cuenta que Pentasa es un aminosalicilato, pueden ocurrir síntomas de toxicidad a los salicilatos tales como alteraciones del equilibrio ácido-base, hiperventilación, edema pulmonar, vómitos, deshidratación e hipoglucemia. Los síntomas de sobredosificación de salicilatos están correctamente descritos en la literatura.</span></p><p><span> </span></p><p><span>Existen informes de pacientes que han tomado dosis diarias de 8g durante un mes sin reacciones adversas</span></p><p><span>No hay un antídoto específico y el tratamiento es sintomático y de mantenimiento. El tratamiento hospitalario incluye monitorización cuidadosa de la función renal.</span></p></div>"
                }
              }]
            },
            {
              "id" : "84051408-3b78-4f93-8a12-37c596af0778",
              "title" : "5. Propiedades farmacológicas",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029821",
                  "display" : "Propiedades farmacológicas"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "e10703f0-812e-48d6-a4f7-57777d8cd148",
                "title" : "5.1. Propiedades farmacodinámicas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029822",
                    "display" : "Propiedades farmacodinámicas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Grupo farmacoterapéutico: Agentes antiinflamatorios intestinales, ácido aminosalicílico y similares.</span></p><p><span>Código ATC: A07E C02.</span></p><p><span> </span></p><p><span>Se ha establecido que la mesalazina es el componente activo de la sulfasalazina, utilizada para el tratamiento de la colitis ulcerosa y enfermedad de Crohn.</span></p></div>"
                },
                "section" : [{
                  "id" : "82d780b7-51ae-4c2a-b008-ec21fff43ced",
                  "title" : "5.1.1. Mecanismo de acción",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029823",
                      "display" : "Mecanismo de acción"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>La acción terapéutica de la mesalazina parece ser debida al efecto local ejercido sobre el tejido intestinal inflamado, más que a un efecto sistémico. Hay información que sugiere que la gravedad de la inflamación colónica en pacientes con colitis ulcerosa tratados con mesalazina está inversamente correlacionada con las concentraciones mucosas de mesalazina.</span></p></div>"
                  }
                },
                {
                  "id" : "aebf1d72-0dd9-4eeb-a153-fbb206dd1ff2",
                  "title" : "5.1.2. Efectos farmacodinámicos",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029824",
                      "display" : "Efectos farmacodinámicos"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>En pacientes con enfermedad inflamatoria intestinal se produce un aumento de la migración de los leucocitos, una producción anormal de citoquinas, un aumento de la producción de metabolitos del ácido araquidónico, particularmente del leucotrieno B4, y un aumento de la formación de radicales libres en el tejido intestinal inflamado. El mecanismo de acción de mesalazina no se conoce completamente aunque están implicados mecanismos tales como la activación de la forma</span><span>γ</span><span>de los receptores activadores de proliferación de peroxisomas (PPAR- γ) e inhibición del factor nuclear kappa B (NF-κB) de la mucosa intestinal. La mesalazina presenta efectos farmacológicos tanto</span><em><span>in vivo</span></em><span>como</span><em><span>in vitro</span></em><span>que inhiben la quimiotaxis leucocit</span><span>aria, disminuyen las citoquinas y la formación de leucotrienos y eliminan radicales libres. Actualmente se desconoce cuál de estos mecanismos, si hay alguno, tiene un papel predominante en la eficacia clínica de mesalazina</span></p></div>"
                  }
                }]
              },
              {
                "id" : "27456685-0072-466d-82c9-55abce018b7f",
                "title" : "5.2. Propiedades farmacocinéticas",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029827",
                    "display" : "Propiedades farmacocinéticas"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Características generales de la sustancia activa:</span></strong></p><p><span><span>Disposición y disponibilidad local:</span></span><span>La actividad terapéutica de la mesalazina depende probablemente del contacto local del fármaco con el área afectada de la mucosa intestinal</span></p><p><span>Pentasa 1g supositorios está diseñado para proporcionar a la parte distal del tracto intestinal altas concentraciones de mesalazina y una lenta absorción sistémica. Los supositorios cubren el recto.</span></p></div>"
                },
                "section" : [{
                  "id" : "33504106-f5af-4104-ae14-e840563fefcd",
                  "title" : "5.2.1. Absorción",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029828",
                      "display" : "Absorción"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>La absorción tras una administración rectal es baja, aunque depende de la dosis administrada, de la formulación y del alcance de la suspensión. En base a la recuperación en la orina en voluntarios sanos en estado de equilibrio a los que les fue administrada una dosis diaria de 2 g (1 g x 2), aproximadamente un 10% de la dosis se absorbe después de la admi</span><span>nistración de los supositorios.</span></p></div>"
                  }
                },
                {
                  "id" : "1a68e026-bfdb-44cc-a42f-1135f9c77f65",
                  "title" : "5.2.2. Distribución",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029829",
                      "display" : "Distribución"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>La unión</span><span>a proteínas</span><span>de la mesalazina es de aproximadamente un 50% y de la acetil</span><span>mesalazina de un 80%.</span></p></div>"
                  }
                },
                {
                  "id" : "fef84562-1ac9-41ee-b8fe-0ab401cae5da",
                  "title" : "5.2.4. Eliminación",
                  "code" : {
                    "coding" : [{
                      "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                      "code" : "200000029831",
                      "display" : "Eliminación"
                    }]
                  },
                  "text" : {
                    "status" : "generated",
                    "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>Una vez que la formulación no está presente en el tracto gastrointestinal la eliminación seguirá la semivida plasmática de la mesalazina oral o intravenosa sin recubrimiento, que es aproximadamente 40 minutos y 70 minutos para la acetilmesalazina.</span></p><p><span> </span></p><p><span> </span></p><p><strong><span>Características en los pacientes</span></strong></p><p><span>En pacientes con disfunción hepática y renal, el descenso resultante en la velocidad de eliminación y el aumento de la concentración sistémica de la mesalazina conlleva un aumento del riesgo de reacciones adversas nefrotóxicas.</span></p></div>"
                  }
                }]
              },
              {
                "id" : "96772fe2-4ceb-4dd1-8bda-bfc9703a6272",
                "title" : "5.3. Datos preclínicos sobre seguridad",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029834",
                    "display" : "Datos preclínicos sobre seguridad"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Se han demostrado efectos renales tóxicos en todas las especies en las que se ha analizado. Las dosis en ratas y monos y las concentraciones plasmáticas al nivel sin efecto adverso observable (NOAELs) excedieron a aquellas utilizadas en humanos por un factor de 2-7.2.</span></p><p><span> </span></p><p><span>Los sistemas de ensayo</span><em><span>in vitro</span></em><span>y los estudios</span><em><span>in vivo</span></em><span>no mostraron evidencia de efectos mutagénicos o clastogénicos. Los estudios acerca del potencial cancerígeno realizados en ratas y ratones no mostraron evidencia de un incremento en la incidencia de tumores relacionado con la sustancia.</span></p></div>"
                }
              }]
            },
            {
              "id" : "7139571e-349f-4ed8-99ef-62411e81595d",
              "title" : "6. Datos farmacéuticos",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029836",
                  "display" : "Datos farmacéuticos"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "e73d249f-daee-429c-80a8-b94a69819aa3",
                "title" : "6.1. Lista de excipientes",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029837",
                    "display" : "Lista de excipientes"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Macrogol 6000, povido</span><span>na, estearato magnésico, talco.</span></p></div>"
                }
              },
              {
                "id" : "6bbc36b1-c81e-423c-be6c-8a11a5ca5019",
                "title" : "6.2. Incompatibilidades",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029838",
                    "display" : "Incompatibilidades"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No se conocen</span><span>.</span></p></div>"
                }
              },
              {
                "id" : "c5dc3a79-9057-48da-98a2-09ba0d3247d2",
                "title" : "6.3. Periodo de validez",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029839",
                    "display" : "Periodo de validez"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>3 años.</span></p></div>"
                }
              },
              {
                "id" : "983636c3-0044-477c-a036-09f731e2b795",
                "title" : "6.4. Precauciones especiales de conservación",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029840",
                    "display" : "Precauciones especiales de conservación"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No conservar a temperatura superior a 25ºC. Conservar</span><span>en el envase original para protegerlo de la luz.</span></p></div>"
                }
              },
              {
                "id" : "a47a1c8a-36be-4886-bdc3-7eecdae70c62",
                "title" : "6.5. Naturaleza y contenido del envase",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029841",
                    "display" : "Naturaleza y contenido del envase"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Blister de doble lámina de aluminio cada uno conteniendo 7 supositorios.</span></p><p><span>Cajas de: 28 supositorios y 56 supositorios.</span></p><p><span>Puede que solamente estén comercializados algunos tamaños de envases</span><span>.</span></p></div>"
                }
              },
              {
                "id" : "554d8c25-ac06-4ded-836e-526d04932465",
                "title" : "6.6. Precauciones especiales de eliminación y otras manipulaciones",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029842",
                    "display" : "Precauciones especiales de eliminación y otras manipulaciones"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>La eliminación del medicamento no utilizado y de todos los materiales que hayan estado en contacto con él, se realizará de acuerdo con la normativa local.</span></p><p><span> </span></p><p><span> </span></p></div>"
                }
              }]
            },
            {
              "id" : "960e52cc-164a-4a7f-9e28-09c92b366926",
              "title" : "7. Titular de la autorización de comercialización",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029844",
                  "display" : "Titular de la autorización de comercialización"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>FERRING S.A.U.</span></p><p><span>C/ del Arquitecto Sánchez Arcas nº 3, 1º</span></p><p><span>28040 Madrid</span></p><p><span>España</span></p></div>"
              }
            },
            {
              "id" : "927bfc35-c169-4f76-a88a-4e315e26b84e",
              "title" : "8. Número(s) de autorización de comercialización",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029845",
                  "display" : "Número(s) de autorización de comercialización"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Nº Registro: 60.151</span></p></div>"
              }
            },
            {
              "id" : "cc3d30b5-ab86-4515-b8b1-528a796cbeeb",
              "title" : "9. Fecha de la primera autorización/ renovación de la autorización",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029846",
                  "display" : "Fecha de la primera autorización/ renovación de la autorización"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>Primera autorización:Noviembre de 2002</span></p><p><span>Renovación de la autorización: Mayo 2007</span></p></div>"
              }
            },
            {
              "id" : "422d0ffc-06eb-4fb2-aafa-2c1f2e9edd99",
              "title" : "10. Fecha de la revisión del texto",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029847",
                  "display" : "Fecha de la revisión del texto"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Mayo 2023</span></p><p><span> </span></p><p><span> </span></p><p><span>La información detallada y actualizada de este medicamento está disponible en la página Web de la Agencia Española de Medicamentos y Productos Sanitarios (AEMPS) http://www.aemps.gob.es/</span></p></div>"
              }
            }]
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "03208281-b579-417f-b808-46e3301fd206",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "03208281-b579-417f-b808-46e3301fd206",
      "identifier" : {
        "system" : "http://ema.europa.eu/fhir/epiDocument",
        "value" : "03208281-b579-417f-b808-46e3301fd206"
      },
      "type" : "document",
      "timestamp" : "2024-12-13T18:58:38.41052+01:00",
      "entry" : [{
        "fullUrl" : "03208281-b579-417f-b808-46e3301fd206",
        "resource" : {
          "resourceType" : "Composition",
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">electronic Product Information (ePI) document</div>"
          },
          "status" : "final",
          "type" : {
            "coding" : [{
              "system" : "http://spor.ema.europa.eu/v1/lists/100000155531",
              "code" : "100000155538",
              "display" : "Prospecto"
            }]
          },
          "subject" : [{
            "reference" : "subjectReference"
          }],
          "date" : "2024-12-13",
          "author" : [{
            "reference" : "systemUser"
          }],
          "title" : "Prospecto",
          "section" : [{
            "title" : "Prospecto",
            "code" : {
              "coding" : [{
                "system" : "http://spor.ema.europa.eu/v1/lists/100000155531",
                "code" : "200000029894",
                "display" : "Prospecto"
              }]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span>Prospecto: información para el</span></strong><strong><span>usuario</span></strong></p><p><span> </span></p><p><strong><span>PENTASA 1 gramo supositorios</span></strong></p><p><span>Mesalazina</span></p><p><strong><span>Lea todo el prospecto detenidamente antes de empezar a usar</span></strong><strong><span>este medicamento, porque contiene información importante para usted.</span></strong></p><ul><li><span>Conserve este prospecto, ya que puede tener que volver a leerlo.</span></li><li><span>Si tiene alguna duda, consulte a su</span><span>médico</span><span>o</span><span>farmacéutico.</span></li><li><span>Este medicamento se le ha recetado solamente a usted,</span><span>y no debe dárselo a otras personas aunque tengan los mismos síntomas que usted, ya que puede perjudicarles.</span></li><li><span>Si experimenta efectos adversos, consulte a su médico</span><span>o</span><span>farmacéutico, incluso si se trata de efectos adversos que no aparecen en este prospecto.</span><span>Ver sección 4.</span></li></ul><p><strong><span>Contenido del prospecto</span></strong></p><p><span>1.   Qué es</span><span>Pentasa supositorios</span><span>y para qué se utiliza</span></p><p><span>2.   Qué necesita saber antes de empezar a</span><span>usar</span><span>Pentasa supositorios</span></p><p><span>3.   Cómo usar</span><span>Pentasa supositorios</span></p><p><span>4.   Posibles efectos adversos</span></p><p><span>5.   Conservación de</span><span>Pentasa supositorios</span></p><p><span>6.   Contenido del envase e información adicional</span></p></div>"
            },
            "section" : [{
              "id" : "02493cb4-f60a-45cf-9f5d-4c857560a4f2",
              "title" : "1. Qué es Pentasa supositorios y para qué se utiliza",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029895",
                  "display" : "Qué es \"X\" y para qué se utiliza"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Pentasa supositorios contiene mesalazina. La mesalazina pertenece al grupo de medicamentos llamados antiinflamatorios intestinales.</span></p><p><span> </span></p><p><span>Pentasa supositorios está indicado para el tratamiento de la proctitis ulcerosa.</span></p></div>"
              }
            },
            {
              "id" : "cdd86af9-952b-43cd-bd8f-7b150e84360d",
              "title" : "2. Qué necesita saber antes de empezar a <tomar><usar> Qué necesita saber antes de empezar a usar Pentasa supositorios",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029896",
                  "display" : "Qué necesita saber antes de empezar a <tomar><usar> \"X\""
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "b2858697-d3ab-4934-8834-18869ba61090",
                "title" : "No use Pentasa supositorios:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029897",
                    "display" : "No use Pentasa supositorios:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ul><li><span>si es alérgico a la mesalazina o a cualquiera de los demás componentes de este medicamento (incluidos en la sección 6).</span></li></ul><ul><li><span>si es alérgico al ácido acetil salicílico.</span></li></ul><ul><li><span>si tiene deterioro de la función renal o hepática.</span><span>Se debe controlar habitualmente la función renal, especialmente durante la fase inicial del tratamiento.</span></li></ul><p><strong><span> </span></strong></p></div>"
                }
              },
              {
                "id" : "96beff5d-f572-4924-8737-946b47cbad54",
                "title" : "Advertencias y precauciones",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029898",
                    "display" : "Advertencias y precauciones"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Consulte a su médico o farmacéutico antes de empezar a usar Pentasa supositorios.</span></p><p><span> </span></p><p><span>Antes de empezar a usar este medicamento indíquele a su médico:</span></p><ul><li><span>si usted es alérgico a la sulfasalazina (riesgo de alergias a salicilatos).</span></li><li><span>si tiene actualmente o ha tenido anteriormente deterioro de la función del hígado o riñón.</span></li></ul><ul><li><span>si tiene una enfermedad que pueda hacerle propenso a sufrir hemorragia</span><strong><span>s</span></strong></li></ul><ul><li><span>si está con un tratamiento que pueda afectar a la función renal por ejemplo fármacos antiinflamatorios no esteroideos (AINES) como la aspirina</span></li><li><span>si tiene problemas respiratorios, en particular asma.</span></li><li><span>se deberá interrumpir el tratamiento inmediatamente en caso calambres, dolor abdominal, fiebre, dolor de cabeza intenso y erupción</span><span>.</span></li><li><span>Pueden producirse cálculos renales con el uso de mesalazina. Los síntomas incluyen dolor en los lados del abdomen y presencia de sangre en la orina. Asegúrese de beber una cantidad suficiente de líquido durante el tratamiento con mesalazina.</span></li><li><span>Si ha sufrido alguna vez un exantema cutáneo intenso o descamación de la piel, ampollas o llagas en la boca después de utilizar mesalazina</span></li></ul><p><span>Mesalazina puede producir una decoloración de la orina de color rojo-marrón tras el contacto con lejía de hipoclorito de sodio en el agua del inodoro. Se trata de una reacción química entre mesalazina y la lejía y es inofensiva.</span></p><p><strong><span>Tenga especial cuidado con la mesalazina:</span></strong></p><p><span>Se han observado erupciones cutáneas graves, como reacción al medicamento con eosinofilia y síntomas sistémicos (DRESS), síndrome de Stevens-Johnson</span><a name=\"_Hlk125626179\"><span>(SSJ)</span></a><span>y necrólisis epidérmica tóxica (NET), con el tratamiento a base de mesalazina. Deje de tomar mesalazina y solicite atención médica inmediatamente si observa alguno de los síntomas relacionados con estas reacciones cutáneas graves descritos en la sección 4.</span></p><p><span> </span></p><p><span> </span></p><p><strong><span>Mientras esté en tratamiento con este medicamento, su médico le realizará análisis de sangre y orina para controlar su función renal, especialmente al inicio del tratamiento.</span></strong></p><p><span> </span></p><p><strong><span>Uso en ancianos</span></strong><span>:</span></p><p><span>Se debe utilizar con cuidado en ancianos y solamente en pacientes con la función renal normal.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "5a48aa04-f203-404d-a261-370aaa13ad26",
                "title" : "Uso en niños:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Uso en niños:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Existe poca experiencia y documentación limitada sobre el efecto en niños.</span></p><p><strong><span> </span></strong></p><p><strong><span>Interacción de Pentasa supositorios con otros medicamentos:</span></strong></p><p><span>Informe a su médico o farmacéutico si está utilizando, ha utilizado recientemente o podría tener que utilizar cualquier otro medicamento.</span></p><p><span>Esto es especialmente importante si usted está tomando cualquiera de los siguientes medicamentos:</span></p><ul><li><span>azatioprina</span><span>(usado tras trasplantes o para tratar enfermedades autoinmunes)</span></li></ul><ul><li><span>6-mercaptopurina</span><span>o tioguanina (quimioterápico, usado para tratar la leucemia)</span></li><li><span>ciertos fármacos que inhiban la coagulación de la sangre (medicamentos para la trombosis o para fluidificar su sangre).</span></li></ul><p><span> </span></p></div>"
                }
              },
              {
                "id" : "2816cd1e-3eda-41ed-9835-880c0f605f1a",
                "title" : "Embarazo, lactancia y fertilidad",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029902",
                    "display" : "Embarazo, lactancia y fertilidad"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Si está embarazada o en periodo de lactancia, o cree que podría estar embarazada o tiene intención de quedarse embarazada, consulte a su médico o farmacéutico antes de utilizar este medicamento.</span></p><p><span> </span></p><p><span>Existe una experiencia limitada con el uso de mesalazina durante el embarazo y la lactancia.</span><span>Se han observado alteraciones sanguíneas en recién nacidos de madres tratadas con este medicamento. Los recién nacidos pueden desarrollar reacciones alérgicas tras la lactancia, por ejemplo, diarrea. En caso de que el recién nacido presente diarrea, se deberá interrumpir la lactancia.</span></p><p><span> </span></p><p><span><span>Fertilidad:</span></span></p><p><span>Los datos de mesalazina en animales muestran que no tiene efecto sobre la fertilidad masculina o femenina</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "ddeacf82-832d-4044-9dea-b5cc7a0e5747",
                "title" : "Conducción y uso de máquinas:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Conducción y uso de máquinas:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>El tratamiento con Pentasa supositorios no parece ejercer ninguna influencia en la capacidad de conducir y/o utilizar máquinas.</span></p></div>"
                }
              }]
            },
            {
              "id" : "0632373a-7be5-4ea4-9732-2b2b3fba1dde",
              "title" : "3. Cómo usar Pentasa supositorios",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029905",
                  "display" : "Cómo \"<tomar><usar> X\""
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Siga exactamente las instrucciones de administración de este medicamento indicadas por su médico o farmacéutico. En caso de duda consulte de nuevo a su médico o farmacéutico.</span></p><p><span>Recuerde usar su medicamento.</span></p><p><span> </span></p><p><span>Cada supositorio de Pentasa</span><span>1 gramo</span><span>está protegido por un blister de aluminio que hay que abrir inmediatamente antes de su empleo.</span></p><p><span> </span></p><ol><li><span>Se recomienda evacuar antes de la administración del supositorio.</span></li><li><span>Sacar un supositorio del blister de aluminio.</span></li><li><span>Introducir el supositorio hasta que desaparezca la resistencia.</span></li><li><span>Si se expulsa el supositorio durante los primeros 10 minutos, debe administrar uno nuevo</span></li></ol><p><span> </span></p><p><strong><span>Dosis recomendada:</span></strong></p><p><span> </span></p><p><span>Adultos: 1 supositorio una a dos veces al día por vía rectal.</span></p><p><span> </span></p><p><span>Niños: Existe poca experiencia y documentación limitada sobre el efecto en niños.</span></p><p><span> </span></p><p><span>La dosificación deberá ajustarse en función de la respuesta del paciente.</span></p><p><span>Si estima que la acción de este medicamento es demasiado fuerte o débil, comuníqueselo a su médico o farmacéutico.</span></p><p><span>Su médico le indicará la duración de su tratamiento con Pentasa supositorios.</span></p></div>"
              },
              "section" : [{
                "id" : "22dab1ae-f702-4b0a-b88d-70c99c10f830",
                "title" : "Si usa más Pentasa supositorios del que debe",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029907",
                    "display" : "Si usa más Pentasa supositorios del que debe"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>No se han comunicado casos de sobredosis en humanos, pero si se sospecha una sobredosis inmediatamente debe consultar a su médico o farmacéutico.</span></p><p><span>En caso de sobredosis ó ingestión accidental, consulte inmediatamente a su médico o farmacéutico o llame al Servicio de Información Toxicológica. Teléfono: 91 562 04 20 indicando el medicamento y la cantidad ingerida.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "490b59af-b0db-40b8-83c9-f6abef65f81c",
                "title" : "Si olvidó usar Pentasa supositorios:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029908",
                    "display" : "Si olvidó usar Pentasa supositorios:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Póngase el supositorio en cuanto se acuerde y continúe con el siguiente a la hora de costumbre.</span></p><p><span>No use una dosis doble para compensar las dosis olvidadas.</span></p><p><strong><span> </span></strong></p></div>"
                }
              },
              {
                "id" : "ad55dd0a-15ca-4fa3-aca8-95c5f03d3c70",
                "title" : "Si interrumpe el tratamiento con Pentasa1 gramosupositorios",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029909",
                    "display" : "Si interrumpe el tratamiento con Pentasa1 gramosupositorios"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Su médico le indicará la duración de su tratamiento con Pentasa</span><span>1 gramo</span><span>supositorios</span><span>. No suspenda el tratamiento antes aunque se encuentre mejor ya que los síntomas podrían volver a aparecer si termina el tratamiento demasiado pronto. Siga rigurosamente el tratamiento según las instrucciones de su médico en el tiempo de mantenimiento que establezca.</span></p><p><span> </span></p><p><span>Si tiene cualquier otra duda sobre el uso de este producto, pregunte a su médico o farmacéutico.</span></p><p><span> </span></p></div>"
                }
              }]
            },
            {
              "id" : "69004126-66a7-4e43-983e-517561025aad",
              "title" : "4. Posibles efectos adversos",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029910",
                  "display" : "Posibles efectos adversos"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Al igual que todos los medicamentos, Pentasa supositorios</span><span>puede producir efectos adversos, aunque no todas las personas los sufran.</span></p><p><span> </span></p><p><span>Se han notificado muy pocos casos de reacción alérgica grave (incluyendo erosiones cutáneas graves que pueden afectar a la piel como como barrera protectora del cuerpo). La reacción alérgica podría dar lugar a la hinchazón de la cara y el cuello y/o dificultad para respirar o tragar Si esto ocurriera contacte con su médico o servicio de urgencias inmediatamente.</span></p><p><span>Deje de tomar mesalazina y solicite ayuda médica inmediatamente si presenta alguno de los siguientes síntomas:</span></p><ul><li><span>                </span><span>parches rojizos no elevados, o parches circulares o en forma de moneda en el tórax, con frecuencia con ampollas centrales, desescamación de la piel, úlceras en la boca, garganta, nariz, genitales y ojos</span><a name=\"_Hlk125626329\"><span>, erupción generalizada, fiebre y aumento de los ganglios linfáticos</span></a><span>. Estas erupciones cutáneas graves van precedidas a menudo de fiebre o síntomas de tipo gripal.</span></li></ul><p><strong><span>Los siguientes efectos adversos frecuentes</span></strong><span>afectan entre 1 y 10 de cada 100 pacientes tratados:</span></p><ul><li><span>dolor de cabeza</span></li><li><span>diarrea</span></li><li><span>dolor abdominal</span></li><li><span>náuseas</span></li><li><span>vómitos</span></li><li><span>erupción cutánea</span></li><li><span>flatulencia (gases)</span></li><li><span>reacciones locales como prurito, molestias rectales y urgencia de defecar</span></li></ul><p><span>Malestar anal e irritación en el lugar de administración, picor, , sensación de necesidad de defecar.</span></p><p><em><span> </span></em></p><p><strong><span>Los siguientes efectos adversos raros,</span></strong><span>afectan entre 1 y 10 de cada 10.000 pacientes tratados:</span></p><ul><li><span>inflamación de algunas áreas del corazón (miocarditis y pericarditis) que pueden causar dificultad para respirar y dolor de pecho o palpitaciones (latidos del corazón rápidos o irregulares)</span></li><li><span>inflamación del páncreas (incluye síntomas de dolor de espalda y/ o estómago) y aumento de la amilasa</span></li><li><span>mareos</span></li><li><span>mayor sensibilidad de la piel a la luz solar y ultravioleta (fotosensibilidad)</span></li></ul><p><em><span> </span></em></p><p><strong><span>Los siguientes efectos adversos muy raros,</span></strong><span>afectan a menos de 1 de 10.000 pacientes tratados:</span></p><ul><li><span>eosinofilia (como parte de una reacción alérgica) y trastornos sanguíneos como reducción de los glóbulos rojos (anemia), de los glóbulos blancos (leucopenia), de las plaquetas (trombocitopenia), que pueden aumentar la probabilidad de tener infecciones o hemorragias.</span></li><li><span>trastornos del hígado (hepatitis) caracterizado por síntomas que incluyen ictericia (amarillamiento de la piel y/o los ojos) y/ o heces blancas.</span></li><li><span>trastornos del riñón de carácter inflamatorio (nefritis) que incluyen los siguientes signos y síntomas: sangre en la orina, edema (hinchazón debido al aumento de fluidos)</span><span>y aumento de la tensión arterial</span></li><li><span>neuropatía periférica (condición que afecta a los nervios de las manos y los pies incluyendo síntomas de cosquilleo y entumecimiento)</span></li><li><span>reacciones alérgicas pulmonares y fibróticas (los síntomas incluyen tos, dificultad para respirar, broncoespasmo, flemas sangrantes y/o excesivas)</span></li><li><span>pérdida de pelo (esta es reversible)</span></li><li><span>dolor muscular o articular</span></li><li><span>inflamación que puede afectar a varias partes del cuerpo como las articulaciones, piel, riñones, corazón, etc (los síntomas incluyen articulaciones doloridas, fatiga, fiebre, sangrado anormal o inexplicable (por ejemplo, sangrado de la nariz), contusión, coloración púrpura de la piel, manchas bajo la piel (incluyendo erosiones cutáneas graves y quemazón grave que pueden afectar a la piel como barrera protectora del cuerpo))</span></li><li><span>semen con baja concentración de espermatozoides (oligospermia) (ésta es reversible)</span></li><li><span>ocasionalmente pueden ocurrir reacciones alérgicas y fiebre</span></li></ul><p><span> </span></p><p><span> </span></p><p><strong><span>Frecuencia no conocida</span></strong><span>(no puede estimarse a partir de los datos disponibles)</span></p><ul><li><span>cálculos renales y dolor renal asociado (ver también sección 2)</span></li><li><span>cambio de color de la orina</span></li></ul><p><span> </span></p><p><span>Algunas de estas reacciones adversas también pueden atribuirse a la enfermedad en si misma.</span></p><p><span> </span></p><p><span>Si estos síntomas continúan o se vuelven más graves, consulte con su médico.</span></p></div>"
              },
              "section" : [{
                "id" : "3e65c4e8-e653-45f0-9e76-cda619112f62",
                "title" : "Comunicación de efectos adversos:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Comunicación de efectos adversos:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>Si experimenta cualquier tipo de efecto adverso, consulte a su médico o farmacéutico, incluso si se trata de posibles efectos adversos que no aparecen en este prospecto. También puede comunicarlos directamente a través del Sistema Español de Farmacovigilancia de Medicamentos de Uso Humano: http;//www.notificaram.es. Mediante la comunicación de efectos adversos usted puede contribuir a proporcionar más información sobre la seguridad de este medicamento.</span></p></div>"
                }
              }]
            },
            {
              "id" : "514c6084-0faf-463c-97f5-1ba16e43f18b",
              "title" : "5. Conservación de Pentasa supositorios",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029913",
                  "display" : "Conservación de \"X\""
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Mantener este medicamento</span><span>fuera de la vista y del alcance de los niños.</span></p><p><span> </span></p><p><span>No conservar a una temperatura superior a 25º C. Conservar en el envase original para protegerlo de la luz.</span></p><p><span> </span></p><p><span>No utilice este medicamento después de la fecha de caducidad que aparece en el envase. La fecha de caducidad es el último día del mes que se indica.</span></p><p><span> </span></p><h3><span>Los medicamentos no se deben tirar por los desagües ni a la basura.</span><a name=\"OLE_LINK1\" id=\"OLE_LINK1\"><span>Deposite los envases y los medicamentos que no necesita en el Punto SIGRE</span><img src=\"data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCAASABwDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD6z1/xDZ+HrSCS4jlubm6lFvaWduu6W5lPIVRwOgJJJAUAkkAVxHjTxtrnhLR7TWvEWu6D4QsriUQLHcafc6q5kKlgpaF48cK2flI9/XovFdjqMOs6J4p02zfUTpLTJPZRn95JDKoDNGDwXUqpA4yNw6kV4D8V/hvpPj+5nu/CPj+SfXJr37RdaNrWqLDHZoUb7sDIHjbOAM9iaBnp/jbx94/8D6LBL/wi6+KZpGjf7XpVnOkapvUuGj/ebcpuAYvwcHBFej+Htf07xN4ftNb0uUvbXK7gGGGQ91YdmB4Iryzwfp/h3wPNqKeEPFWu+PdaniSA2EuoreRW79QXdVCwDPUsc4HAJ4r2K2E/2SI3aRrclAZRFkqHxzgnkjPrQImqC4srO7x9qtIZ8dPMjDY/OiigCSOKKFBHDGsaDoqLgU+iigD/2Q==\" alt=\"null\" width=\"28\" height=\"18\"/><span>de la farmacia. En caso de duda</span></a><span>pregunte a su farmacéutico cómo deshacerse de los envases y de los medicamentos que no necesita. De esta forma ayudará a proteger el medio ambiente.</span></h3><p><span> </span></p></div>"
              }
            },
            {
              "id" : "e5b66d94-758f-40b1-a56a-d72813d37693",
              "title" : "6. Contenido del envase e información adicional",
              "code" : {
                "coding" : [{
                  "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                  "code" : "200000029914",
                  "display" : "Contenido del envase e información adicional"
                }]
              },
              "text" : {
                "status" : "generated",
                "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p> </p></div>"
              },
              "section" : [{
                "id" : "101d123b-4fe9-4672-8b80-0d2e243876c6",
                "title" : "Composición dePentasa 1 gramo supositorios:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029915",
                    "display" : "Composición dePentasa 1 gramo supositorios:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>- El principio activo es mesalazina. Cada supositorio de Pentasa contiene 1 gramo de mesalazina.</span></p><p><span> </span></p><p><span>- Los demás componentes son: macrogol 6000, povidona, estearato magnésico y talco.</span></p><p><span> </span></p></div>"
                }
              },
              {
                "id" : "a896f878-7d9b-419d-bba3-fe6b2620369e",
                "title" : "Aspecto del producto y contenido del envase",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029916",
                    "display" : "Aspecto del producto y contenido del envase"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>Pentasa 1 gramo supositorios es de</span><span>administración rectal. Los supositorios son blancos a marrón claro, moteados y forma ovoide.</span></p><p><span>Se presenta en cajas de 28 supositorios o 56 supositorios.</span></p><p><span>No todas las presentaciones están comercializadas.</span></p></div>"
                }
              },
              {
                "id" : "be219b09-f02c-48de-8ec8-2550f05bfa67",
                "title" : "Titular de la autorización de comercialización y responsable de la fabricación",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029917",
                    "display" : "Titular de la autorización de comercialización y responsable de la fabricación"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong><span> </span></strong></p></div>"
                }
              },
              {
                "id" : "81fc7806-1779-487a-9e51-93cfce7eed36",
                "title" : "Titular de la autorización de comercialización:",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "200000029917",
                    "display" : "Titular de la autorización de comercialización:"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span>Ferring S.A.U</span></p><p><span>C/ del Arquitecto Sánchez Arcas nº3, 1º</span></p><p><span>28040 Madrid</span></p><p><span>España</span></p><p><span> </span></p><p><strong><span>Responsable de la fabricación</span></strong><span>:</span></p><p><span> </span></p><p><span>Ferring GmbH</span></p><p><span>Wittland 11</span></p><p><span>D-24109 Kiel</span></p><p><span>Alemania</span></p><p><strong><span> </span></strong></p></div>"
                }
              },
              {
                "id" : "91aaa8d8-d4a3-40f0-9ef2-dd33061bae34",
                "title" : "Fecha de la última revisión de este prospecto en mayo 2023",
                "code" : {
                  "coding" : [{
                    "system" : "http://spor.ema.europa.eu/v1/lists/200000029659",
                    "code" : "XXXXXXXXXXXX",
                    "display" : "Fecha de la última revisión de este prospecto en mayo 2023"
                  }]
                },
                "text" : {
                  "status" : "generated",
                  "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><span> </span></p><p><span>La información detallada y actualizada de este medicamento está disponible en la página Web de la Agencia Española de Medicamentos y Productos Sanitarios (AEMPS)</span><a href=\"http://www.aemps.gob.es/\"><span><span>http://www.aemps.gob.es/</span></span></a></p></div>"
                }
              }]
            }]
          }]
        }
      }]
    }
  }]
}

```
