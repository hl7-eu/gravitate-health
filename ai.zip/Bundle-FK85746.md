# FK85746 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK85746**

## Example Bundle: FK85746

**Composition category:**

**Composition status:**final

### Lisätietoa

 

**Januvia 25 mg kalvopäällysteiset tabletit
Januvia 50 mg kalvopäällysteiset tabletit
Januvia 100 mg kalvopäällysteiset tabletit**
sitagliptiini


#### Yleisiä ohjeita

 

## Yleisiä ohjeita

**Lue tämä pakkausseloste huolellisesti ennen kuin aloitat tämän lääkkeen ottamisen, sillä se sisältää sinulle tärkeitä tietoja.**

* Säilytä tämä pakkausseloste. Voit tarvita sitä myöhemmin.
* Jos sinulla on kysyttävää, käänny lääkärin, apteekkihenkilökunnan tai sairaanhoitajan puoleen.
* Tämä lääke on määrätty vain sinulle eikä sitä pidä antaa muiden käyttöön. Se voi aiheuttaa haittaa muille, vaikka heillä olisikin samanlaiset oireet kuin sinulla.
* Jos havaitset haittavaikutuksia, kerro niistä lääkärille, apteekkihenkilökunnalle tai sairaanhoitajalle. Tämä koskee myös sellaisia mahdollisia haittavaikutuksia, joita ei ole mainittu tässä pakkausselosteessa. Ks. kohta Mahdolliset haittavaikutukset.


#### Tässä pakkausselosteessa kerrotaan

 

## Tässä pakkausselosteessa kerrotaan

1. Mitä Januvia on ja mihin sitä käytetään
2. Mitä sinun on tiedettävä, ennen kuin otat Januviaa
3. Miten Januviaa otetaan
4. Mahdolliset haittavaikutukset
5. Januvian säilyttäminen
6. Pakkauksen sisältö ja muuta tietoa


#### Mitä valmiste on ja mihin sitä käytetään

 

## Mitä valmiste on ja mihin sitä käytetään

Januvian vaikuttava aine on sitagliptiini, joka kuuluu DPP‑4‑estäjiksi (dipeptidyylipeptidaasi 4:n estäjiksi) kutsuttujen lääkkeiden ryhmään. DPP‑4-estäjät alentavat tyypin 2 diabetesta sairastavien aikuisten potilaiden verensokeriarvoja.

Tämä lääke auttaa nostamaan aterianjälkeisiä insuliinipitoisuuksia ja vähentää elimistön tuottaman sokerin määrää.

Lääkäri on määrännyt sinulle tätä lääkettä alentamaan verensokeriasi, joka on liian korkea tyypin 2 diabeteksen vuoksi. Tätä lääkettä voidaan käyttää yksinään tai yhdessä tiettyjen muiden verensokeria alentavien lääkkeiden (insuliinin, metformiinin, sulfonyyliureoiden tai glitatsonien) kanssa, joita ehkä jo käytät diabeteksen hoitoon suositellun ruokavalion ja liikuntaohjelman ohella.

Mikä on tyypin 2 diabetes?
Tyypin 2 diabetes on sairaus, jossa elimistö ei tuota riittävästi insuliinia ja jossa elimistön tuottama insuliini ei vaikuta niin hyvin kuin sen pitäisi. Elimistö voi myös tuottaa liian paljon sokeria, jolloin sokeria (glukoosia) kertyy vereen. Tämä voi johtaa vakaviin sairauksiin, kuten sydän- tai munuaissairauksiin, sokeuteen tai amputaatioon.


#### Mitä sinun on tiedettävä ennen valmisteen käyttöä

 

## Mitä sinun on tiedettävä ennen valmisteen käyttöä

**Älä ota Januviaa**

* jos olet allerginen sitagliptiinille tai tämän lääkkeen jollekin muulle aineelle (lueteltu kohdassa Pakkauksen sisältö ja muuta tietoa).

**Varoitukset ja varotoimet**

Januviaa saaneilla potilailla on raportoitu esiintyneen haimatulehdusta (pankreatiittia) (ks. kohta Mahdolliset haittavaikutukset).

Jos huomaat rakkuloita iholla, ne voivat olla merkki sairaudesta, jota kutsutaan rakkulaiseksi pemfigoidiksi. Lääkäri voi pyytää sinua lopettamaan Januvian käytön.

Keskustele lääkärin kanssa, jos sinulla on tai on ollut

* haimasairaus (esim. haimatulehdus)
* sappikiviä, alkoholiriippuvuutta tai hyvin korkeat veren triglyseridiarvot (eräs rasvan muoto). Nämä tilat voivat lisätä haimatulehduksen mahdollisuutta (ks. kohta Mahdolliset haittavaikutukset).
* tyypin 1 diabetes
* diabeettinen ketoasidoosi (diabeteksen komplikaatio, johon liittyy korkea verensokeri, nopea painon lasku, pahoinvointi tai oksentelu)
* aiempi tai nykyinen munuaissairaus
* Januvian aiheuttama allerginen reaktio (ks. kohta Mahdolliset haittavaikutukset).

Tämä lääke ei todennäköisesti aiheuta alhaista verensokeria, koska se ei tehoa silloin kun verensokeri on alhainen. Jos tätä lääkettä kuitenkin käytetään sulfonyyliureavalmisteen tai insuliinin kanssa samanaikaisesti, alhaista verensokeria (hypoglykemiaa) saattaa esiintyä. Lääkäri voi pienentää sulfonyyliurea- tai insuliiniannostasi.

**Lapset ja nuoret**
Alle 18‑vuotiaiden lasten ja nuorten ei pidä käyttää tätä lääkettä. Se ei ole tehokas 10–17‑vuotiailla lapsilla ja nuorilla. Tämän lääkkeen turvallisuudesta ja tehosta alle 10‑vuotiailla lapsilla ei ole tietoa.

**Muut lääkevalmisteet ja Januvia**
Kerro lääkärille tai apteekkihenkilökunnalle, jos parhaillaan käytät, olet äskettäin käyttänyt tai saatat käyttää muita lääkkeitä.

Kerro lääkärille etenkin, jos käytät digoksiinia (lääke, jota käytetään sydämen rytmihäiriöiden ja muiden sydänongelmien hoitoon). Veren digoksiinipitoisuutta saatetaan joutua tarkistamaan, jos Januviaa käytetään samanaikaisesti.

**Raskaus ja imetys**
Jos olet raskaana tai imetät, epäilet olevasi raskaana tai jos suunnittelet lapsen hankkimista, kysy lääkäriltä tai apteekista neuvoa ennen tämän lääkkeen käyttöä.
Älä ota tätä lääkettä raskauden aikana.

Ei tiedetä, erittyykö tämä lääke äidinmaitoon. Älä ota tätä lääkettä jos imetät tai aiot imettää.

**Ajaminen ja koneiden käyttö**
Tällä lääkkeellä ei ole haitallista vaikutusta ajokykyyn eikä koneiden käyttökykyyn. On kuitenkin raportoitu heitehuimausta ja uneliaisuutta, jotka voivat vaikuttaa ajokykyyn tai koneiden käyttökykyyn.

Tämän lääkkeen käyttäminen yhdessä sulfonyyliureoiden tai insuliinin kanssa voi aiheuttaa hypoglykemiaa, joka voi vaikuttaa ajokykyyn ja koneiden käyttökykyyn tai työskentelyyn epävakaalla alustalla.

**Januvia sisältää natriumia**
Tämä lääkevalmiste sisältää alle 1 mmol natriumia (23 mg) per tabletti eli sen voidaan sanoa olevan ”natriumiton”.


#### Miten valmistetta käytetään

 

## Miten valmistetta käytetään

Ota tätä lääkettä juuri siten kuin lääkäri on määrännyt. Tarkista ohjeet lääkäriltä tai apteekista, jos olet epävarma.

Tavanomainen suositeltu annos on

* yksi 100 mg:n kalvopäällysteinen tabletti
* kerran vuorokaudessa
* suun kautta.

Jos sinulla on munuaisten toimintahäiriöitä, lääkäri saattaa määrätä sinulle pienempiä annoksia (kuten 25 mg tai 50 mg).

Voit ottaa tämän lääkkeen aterian yhteydessä tai tyhjään mahaan.

Lääkäri saattaa määrätä sinulle tätä lääkettä yksinään tai yhdessä tiettyjen muiden verensokeria alentavien lääkkeiden kanssa.

Ruokavalio ja liikunta voivat auttaa elimistöäsi käyttämään verensokeria tehokkaammin. On tärkeää, että samalla kun käytät Januviaa, noudatat lääkärin suosittelemaa ruokavaliota sekä harrastat liikuntaa.

**Jos otat enemmän Januviaa kuin sinun pitäisi**
Jos otat tätä lääkettä enemmän kuin sinulle on määrätty, ota heti yhteys lääkäriin.

**Jos unohdat ottaa Januviaa**
Jos unohdat ottaa annoksen, ota se heti muistaessasi. Jos huomaat unohtaneesi ottaa annoksen vasta kun on aika ottaa seuraava annos, jätä unohtunut annos väliin ja palaa takaisin normaaliin aikatauluun. Älä ota kaksinkertaista annosta tätä lääkettä.

**Jos lopetat Januvian oton**
Jatka tämän lääkkeen ottamista niin kauan kuin lääkäri on määrännyt, jotta verensokeriarvosi pysyvät hallinnassa. Älä lopeta tämän lääkkeen ottamista keskustelematta siitä ensin lääkärin kanssa.

Jos sinulla on kysymyksiä tämän lääkkeen käytöstä, käänny lääkärin tai apteekkihenkilökunnan puoleen.


#### Mahdolliset haittavaikutukset

 

## Mahdolliset haittavaikutukset

Kuten kaikki lääkkeet, tämäkin lääke voi aiheuttaa haittavaikutuksia. Kaikki eivät kuitenkaan niitä saa.

LOPETA Januvian käyttö ja ota heti yhteys lääkäriin, jos havaitset jonkin seuraavista vakavista haittavaikutuksista:

* voimakas ja jatkuva vatsakipu (mahan alueella), joka saattaa ulottua selkään ja johon voi liittyä pahoinvointia ja oksentelua, koska nämä voivat olla haimatulehduksen (pankreatiitin) oireita.

Jos saat vakavan allergisen reaktion (esiintymistiheys on tuntematon), johon voi kuulua ihottuma, nokkosihottuma, ihorakkuloita/ihon kuoriutumista sekä kasvojen, huulten, kielen ja nielun turvotus, jotka voivat aiheuttaa hengitys- tai nielemisvaikeuksia, lopeta tämän lääkkeen käyttö ja ota heti yhteys lääkäriin. Lääkäri voi määrätä sinulle lääkkeen allergisen reaktion hoitoon sekä vaihtoehtoisen diabeteslääkkeen.

Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia, kun sitagliptiini on lisätty metformiinihoitoon:
Yleinen (enintään yhdellä potilaalla 10:stä): alhainen verensokeri, pahoinvointi, ilmavaivat, oksentelu
Melko harvinainen (enintään yhdellä potilaalla 100:sta): vatsakipu, ripuli, ummetus, uneliaisuus.

Joillakin potilailla on esiintynyt erityyppistä epämukavaa tunnetta vatsassa, kun he ovat aloittaneet sitagliptiinin käytön yhdessä metformiinin kanssa (esiintymistiheys on yleinen).

Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia, kun sitagliptiinia on käytetty yhdessä sulfonyyliurean ja metformiinin kanssa:
Hyvin yleinen (yli yhdellä potilaalla 10:stä): alhainen verensokeri
Yleinen: ummetus

Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia sitagliptiinin ja pioglitatsonin käytön aikana:
Yleinen: ilmavaivat, käsien tai jalkojen turvotus

Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia, kun sitagliptiinia on käytetty yhdessä pioglitatsonin ja metformiinin kanssa:
Yleinen: käsien tai jalkojen turvotus

Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia, kun sitagliptiinia on käytetty yhdessä insuliinin kanssa (metformiiniin yhdistettynä tai ilman sitä):
Yleinen: nuhakuume
Melko harvinainen: suun kuivuminen

Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia kliinisissä tutkimuksissa pelkästään sitagliptiinia käytettäessä tai tämän lääkkeen markkinoille tulemisen jälkeen, kun sitagliptiinia on käytetty yksin ja/tai yhdessä muiden diabeteslääkkeiden kanssa:
Yleinen: alhainen verensokeri, päänsärky, ylähengitystieinfektio, tukkoinen tai vuotava nenä ja kurkkukipu, nivelrikko, käsivarsien ja säärten kipu
Melko harvinainen: heitehuimaus, ummetus, kutina
Harvinainen: verihiutaleiden vähentynyt määrä
Esiintymistiheys tuntematon: munuaisongelmat, jotka joissain tapauksissa vaativat keinomunuaishoitoa, oksentelu, nivelsärky, lihassärky, selkäsärky, interstitiaalinen keuhkosairaus, rakkulainen pemfigoidi (eräänlainen rakkulamuodostuma iholla)

**Haittavaikutuksista ilmoittaminen**
Jos havaitset haittavaikutuksia, kerro niistä lääkärille, apteekkihenkilökunnalle tai sairaanhoitajalle. Tämä koskee myös sellaisia mahdollisia haittavaikutuksia, joita ei ole mainittu tässä pakkausselosteessa. Voit ilmoittaa haittavaikutuksista myös suoraan (ks. yhteystiedot alla). Ilmoittamalla haittavaikutuksista voit auttaa saamaan enemmän tietoa tämän lääkevalmisteen turvallisuudesta.

www-sivusto: www.fimea.fi
Lääkealan turvallisuus- ja kehittämiskeskus Fimea
Lääkkeiden haittavaikutusrekisteri
PL 55
00034 FIMEA


#### Valmisteen säilyttäminen

 

## Valmisteen säilyttäminen

Ei lasten ulottuville eikä näkyville.

Älä käytä tätä lääkettä läpipainopakkauksessa ja kotelossa mainitun viimeisen käyttöpäivämäärän (Käyt. viim. tai EXP) jälkeen. Viimeinen käyttöpäivämäärä tarkoittaa kuukauden viimeistä päivää.

Säilytä alle 25 °C.

Lääkkeitä ei pidä heittää viemäriin eikä hävittää talousjätteiden mukana. Kysy käyttämättömien lääkkeiden hävittämisestä apteekista. Näin menetellen suojelet luontoa.


#### Pakkauksen sisältö ja muuta tietoa

 

## Pakkauksen sisältö ja muuta tietoa

**Mitä Januvia sisältää**

* Vaikuttava aine on sitagliptiini:
* Yksi Januvia 25 mg kalvopäällysteinen tabletti (tabletti) sisältää sitagliptiinifosfaattimonohydraattia, joka vastaa 25 mg:a sitagliptiinia.
* Yksi Januvia 50 mg kalvopäällysteinen tabletti (tabletti) sisältää sitagliptiinifosfaattimonohydraattia, joka vastaa 50 mg:a sitagliptiinia.
* Yksi Januvia 100 mg kalvopäällysteinen tabletti (tabletti) sisältää sitagliptiinifosfaattimonohydraattia, joka vastaa 100 mg:a sitagliptiinia.

* Muut aineet ovat:
* Tabletin ydin: mikrokiteinen selluloosa (E460), vedetön kalsiumvetyfosfaatti (E341), kroskarmelloosinatrium (E468), magnesiumstearaatti (E470b), natriumstearyylifumaraatti ja propyyligallaatti.
* Kalvopäällyste: poly(vinyylialkoholi), makrogoli 3350, talkki (E553b), titaanidioksidi (E171), punainen rautaoksidi (E172) ja keltainen rautaoksidi (E172).

**Lääkevalmisteen kuvaus ja pakkauskoot**
- Januvia 25 mg kalvopäällysteinen tabletti on pyöreä, vaaleanpunainen kalvopäällysteinen tabletti, jossa on toisella puolella merkintä "221".
- Januvia 50 mg kalvopäällysteinen tabletti on pyöreä, vaaleanbeigen värinen kalvopäällysteinen tabletti, jossa on toisella puolella merkintä "112".
- Januvia 100 mg kalvopäällysteinen tabletti on pyöreä, beigen värinen kalvopäällysteinen tabletti, jossa on toisella puolella merkintä "277".

Läpinäkymätön läpipainopakkaus (PVC/PE/PVDC ja alumiini). Pakkauksissa on 14, 28, 30, 56, 84, 90 tai 98 kalvopäällysteistä tablettia, tai 50x1 kalvopäällysteistä tablettia perforoiduissa, yksittäispakatuissa läpipainopakkauksissa.

Kaikkia pakkauskokoja ei välttämättä ole myynnissä.

**Myyntiluvan haltija ja valmistaja**
Merck Sharp & Dohme B.V.
Waarderweg 39
2031 BN Haarlem
Alankomaat

Lisätietoja tästä lääkevalmisteesta antaa myyntiluvan haltijan paikallinen edustaja:

**Suomi/Finland**
MSD Finland Oy
Puh/Tel: +358 (0)9 804 650
info@msd.fi

**Tämä pakkausseloste on tarkistettu viimeksi 09/2023**

Lisätietoa tästä lääkevalmisteesta on saatavilla Euroopan lääkeviraston verkkosivulla [http://www.ema.europa.eu](http://www.ema.europa.eu.).


####  Januvia tab 100 mg 
LEGEMIDDELMERKEVAREID:
** ID_25A0CD14-4F68-46B0-9BF1-2464CCAC3114 **
-------

Full name: **Januvia tab 100 mg**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 4

LEGEMIDDELPAKNINGID: ** ID_98BC2493-2B3A-418C-81AC-BE73F3154AC0 ** 

VARENUMMER: ** 076033 ** 

VNR: ** 076033 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:

 Package 2 of 4

LEGEMIDDELPAKNINGID: ** ID_DD24F7AE-7C5B-4F0B-B8E9-BDDF3221770B ** 

VARENUMMER: ** 076024 ** 

VNR: ** 076024 ** 

Description:

## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK85746",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "fi",
  "identifier" : {
    "system" : "https://pharmaca.fi/documentId",
    "value" : "85746"
  },
  "type" : "document",
  "timestamp" : "2023-10-01T12:17:20Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK85746-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK85746-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "fi",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fi\" lang=\"fi\"><a name=\"Composition_FK85746-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK85746-COMP</b></p><a name=\"FK85746-COMP\"> </a><a name=\"hcFK85746-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fi</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://pharmaca.fi/documentId</code>/85746</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2023-10-01 12:17:20+0000</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/Pharmaca Health Intelligence Oy</p><p><b>title</b>: JANUVIA tabletti, kalvopäällysteinen 25 mg, 50 mg, 100 mg</p></div>"
      },
      "identifier" : [{
        "system" : "https://pharmaca.fi/documentId",
        "value" : "85746"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-55"
      },
      {
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-56"
      },
      {
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-57"
      }],
      "date" : "2023-10-01T12:17:20Z",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "Pharmaca Health Intelligence Oy"
        }
      }],
      "title" : "JANUVIA tabletti, kalvopäällysteinen 25 mg, 50 mg, 100 mg",
      "section" : [{
        "title" : "Lisätietoa",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Januvia 25 mg kalvopäällysteiset tabletit<br/>Januvia 50 mg kalvopäällysteiset tabletit<br/>Januvia 100 mg kalvopäällysteiset tabletit</strong><br/>sitagliptiini</p></div>"
        },
        "section" : [{
          "title" : "Yleisiä ohjeita",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Yleisiä ohjeita</h2><p><b>Lue tämä pakkausseloste huolellisesti ennen kuin aloitat tämän lääkkeen ottamisen, sillä se sisältää sinulle tärkeitä tietoja.</b></p><ul><li>Säilytä tämä pakkausseloste. Voit tarvita sitä myöhemmin.</li><li>Jos sinulla on kysyttävää, käänny lääkärin, apteekkihenkilökunnan tai sairaanhoitajan puoleen.</li><li>Tämä lääke on määrätty vain sinulle eikä sitä pidä antaa muiden käyttöön. Se voi aiheuttaa haittaa muille, vaikka heillä olisikin samanlaiset oireet kuin sinulla.</li><li>Jos havaitset haittavaikutuksia, kerro niistä lääkärille, apteekkihenkilökunnalle tai sairaanhoitajalle. Tämä koskee myös sellaisia mahdollisia haittavaikutuksia, joita ei ole mainittu tässä pakkausselosteessa. Ks. kohta <a class=\"cross-reference\">Mahdolliset haittavaikutukset</a>.</li></ul></div>"
          }
        },
        {
          "title" : "Tässä pakkausselosteessa kerrotaan",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Tässä pakkausselosteessa kerrotaan</h2><p>1. Mitä Januvia on ja mihin sitä käytetään<br/>2. Mitä sinun on tiedettävä, ennen kuin otat Januviaa<br/>3. Miten Januviaa otetaan<br/>4. Mahdolliset haittavaikutukset<br/>5. Januvian säilyttäminen<br/>6. Pakkauksen sisältö ja muuta tietoa</p></div>"
          }
        },
        {
          "title" : "Mitä valmiste on ja mihin sitä käytetään",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mitä valmiste on ja mihin sitä käytetään</h2><p>Januvian vaikuttava aine on sitagliptiini, joka kuuluu DPP‑4‑estäjiksi (dipeptidyylipeptidaasi 4:n estäjiksi) kutsuttujen lääkkeiden ryhmään. DPP‑4-estäjät alentavat tyypin 2 diabetesta sairastavien aikuisten potilaiden verensokeriarvoja.</p><p>Tämä lääke auttaa nostamaan aterianjälkeisiä insuliinipitoisuuksia ja vähentää elimistön tuottaman sokerin määrää.</p><p>Lääkäri on määrännyt sinulle tätä lääkettä alentamaan verensokeriasi, joka on liian korkea tyypin 2 diabeteksen vuoksi. Tätä lääkettä voidaan käyttää yksinään tai yhdessä tiettyjen muiden verensokeria alentavien lääkkeiden (insuliinin, metformiinin, sulfonyyliureoiden tai glitatsonien) kanssa, joita ehkä jo käytät diabeteksen hoitoon suositellun ruokavalion ja liikuntaohjelman ohella.</p><p>Mikä on tyypin 2 diabetes?<br/>Tyypin 2 diabetes on sairaus, jossa elimistö ei tuota riittävästi insuliinia ja jossa elimistön tuottama insuliini ei vaikuta niin hyvin kuin sen pitäisi. Elimistö voi myös tuottaa liian paljon sokeria, jolloin sokeria (glukoosia) kertyy vereen. Tämä voi johtaa vakaviin sairauksiin, kuten sydän- tai munuaissairauksiin, sokeuteen tai amputaatioon.</p></div>"
          }
        },
        {
          "title" : "Mitä sinun on tiedettävä ennen valmisteen käyttöä",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mitä sinun on tiedettävä ennen valmisteen käyttöä</h2><p><strong>Älä ota Januviaa</strong></p><ul><li>jos olet allerginen sitagliptiinille tai tämän lääkkeen jollekin muulle aineelle (lueteltu kohdassa <a class=\"cross-reference\">Pakkauksen sisältö ja muuta tietoa</a>).</li></ul><p><strong>Varoitukset ja varotoimet</strong></p><p>Januviaa saaneilla potilailla on raportoitu esiintyneen haimatulehdusta (pankreatiittia) (ks. kohta <a class=\"cross-reference\">Mahdolliset haittavaikutukset</a>).</p><p>Jos huomaat rakkuloita iholla, ne voivat olla merkki sairaudesta, jota kutsutaan rakkulaiseksi pemfigoidiksi. Lääkäri voi pyytää sinua lopettamaan Januvian käytön.</p><p>Keskustele lääkärin kanssa, jos sinulla on tai on ollut</p><ul><li>haimasairaus (esim. haimatulehdus)</li><li>sappikiviä, alkoholiriippuvuutta tai hyvin korkeat veren triglyseridiarvot (eräs rasvan muoto). Nämä tilat voivat lisätä haimatulehduksen mahdollisuutta (ks. kohta <a class=\"cross-reference\">Mahdolliset haittavaikutukset</a>).</li><li>tyypin 1 diabetes</li><li>diabeettinen ketoasidoosi (diabeteksen komplikaatio, johon liittyy korkea verensokeri, nopea painon lasku, pahoinvointi tai oksentelu)</li><li>aiempi tai nykyinen munuaissairaus</li><li>Januvian aiheuttama allerginen reaktio (ks. kohta <a class=\"cross-reference\">Mahdolliset haittavaikutukset</a>).</li></ul><p>Tämä lääke ei todennäköisesti aiheuta alhaista verensokeria, koska se ei tehoa silloin kun verensokeri on alhainen. Jos tätä lääkettä kuitenkin käytetään sulfonyyliureavalmisteen tai insuliinin kanssa samanaikaisesti, alhaista verensokeria (hypoglykemiaa) saattaa esiintyä. Lääkäri voi pienentää sulfonyyliurea- tai insuliiniannostasi.</p><p><strong>Lapset ja nuoret</strong><br/>Alle 18‑vuotiaiden lasten ja nuorten ei pidä käyttää tätä lääkettä. Se ei ole tehokas 10–17‑vuotiailla lapsilla ja nuorilla. Tämän lääkkeen turvallisuudesta ja tehosta alle 10‑vuotiailla lapsilla ei ole tietoa.</p><p><strong>Muut lääkevalmisteet ja Januvia</strong><br/>Kerro lääkärille tai apteekkihenkilökunnalle, jos parhaillaan käytät, olet äskettäin käyttänyt tai saatat käyttää muita lääkkeitä.</p><p>Kerro lääkärille etenkin, jos käytät digoksiinia (lääke, jota käytetään sydämen rytmihäiriöiden ja muiden sydänongelmien hoitoon). Veren digoksiinipitoisuutta saatetaan joutua tarkistamaan, jos Januviaa käytetään samanaikaisesti.</p><p><strong>Raskaus ja imetys</strong><br/>Jos olet raskaana tai imetät, epäilet olevasi raskaana tai jos suunnittelet lapsen hankkimista, kysy lääkäriltä tai apteekista neuvoa ennen tämän lääkkeen käyttöä.<br/>Älä ota tätä lääkettä raskauden aikana.</p><p>Ei tiedetä, erittyykö tämä lääke äidinmaitoon. Älä ota tätä lääkettä jos imetät tai aiot imettää.</p><p><strong>Ajaminen ja koneiden käyttö</strong><br/>Tällä lääkkeellä ei ole haitallista vaikutusta ajokykyyn eikä koneiden käyttökykyyn. On kuitenkin raportoitu heitehuimausta ja uneliaisuutta, jotka voivat vaikuttaa ajokykyyn tai koneiden käyttökykyyn.</p><p>Tämän lääkkeen käyttäminen yhdessä sulfonyyliureoiden tai insuliinin kanssa voi aiheuttaa hypoglykemiaa, joka voi vaikuttaa ajokykyyn ja koneiden käyttökykyyn tai työskentelyyn epävakaalla alustalla.</p><p><strong>Januvia sisältää natriumia</strong><br/>Tämä lääkevalmiste sisältää alle 1 mmol natriumia (23 mg) per tabletti eli sen voidaan sanoa olevan ”natriumiton”.</p></div>"
          }
        },
        {
          "title" : "Miten valmistetta käytetään",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Miten valmistetta käytetään</h2><p>Ota tätä lääkettä juuri siten kuin lääkäri on määrännyt. Tarkista ohjeet lääkäriltä tai apteekista, jos olet epävarma.</p><p>Tavanomainen suositeltu annos on</p><ul><li>yksi 100 mg:n kalvopäällysteinen tabletti</li><li>kerran vuorokaudessa</li><li>suun kautta.</li></ul><p>Jos sinulla on munuaisten toimintahäiriöitä, lääkäri saattaa määrätä sinulle pienempiä annoksia (kuten 25 mg tai 50 mg).</p><p>Voit ottaa tämän lääkkeen aterian yhteydessä tai tyhjään mahaan.</p><p>Lääkäri saattaa määrätä sinulle tätä lääkettä yksinään tai yhdessä tiettyjen muiden verensokeria alentavien lääkkeiden kanssa.</p><p>Ruokavalio ja liikunta voivat auttaa elimistöäsi käyttämään verensokeria tehokkaammin. On tärkeää, että samalla kun käytät Januviaa, noudatat lääkärin suosittelemaa ruokavaliota sekä harrastat liikuntaa.</p><p><strong>Jos otat enemmän Januviaa kuin sinun pitäisi</strong><br/>Jos otat tätä lääkettä enemmän kuin sinulle on määrätty, ota heti yhteys lääkäriin.</p><p><strong>Jos unohdat ottaa Januviaa</strong><br/>Jos unohdat ottaa annoksen, ota se heti muistaessasi. Jos huomaat unohtaneesi ottaa annoksen vasta kun on aika ottaa seuraava annos, jätä unohtunut annos väliin ja palaa takaisin normaaliin aikatauluun. Älä ota kaksinkertaista annosta tätä lääkettä.</p><p><strong>Jos lopetat Januvian oton</strong><br/>Jatka tämän lääkkeen ottamista niin kauan kuin lääkäri on määrännyt, jotta verensokeriarvosi pysyvät hallinnassa. Älä lopeta tämän lääkkeen ottamista keskustelematta siitä ensin lääkärin kanssa.</p><p>Jos sinulla on kysymyksiä tämän lääkkeen käytöstä, käänny lääkärin tai apteekkihenkilökunnan puoleen.</p></div>"
          }
        },
        {
          "title" : "Mahdolliset haittavaikutukset",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mahdolliset haittavaikutukset</h2><p>Kuten kaikki lääkkeet, tämäkin lääke voi aiheuttaa haittavaikutuksia. Kaikki eivät kuitenkaan niitä saa.</p><p>LOPETA Januvian käyttö ja ota heti yhteys lääkäriin, jos havaitset jonkin seuraavista vakavista haittavaikutuksista:</p><ul><li>voimakas ja jatkuva vatsakipu (mahan alueella), joka saattaa ulottua selkään ja johon voi liittyä pahoinvointia ja oksentelua, koska nämä voivat olla haimatulehduksen (pankreatiitin) oireita.</li></ul><p>Jos saat vakavan allergisen reaktion (esiintymistiheys on tuntematon), johon voi kuulua ihottuma, nokkosihottuma, ihorakkuloita/ihon kuoriutumista sekä kasvojen, huulten, kielen ja nielun turvotus, jotka voivat aiheuttaa hengitys- tai nielemisvaikeuksia, lopeta tämän lääkkeen käyttö ja ota heti yhteys lääkäriin. Lääkäri voi määrätä sinulle lääkkeen allergisen reaktion hoitoon sekä vaihtoehtoisen diabeteslääkkeen.</p><p>Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia, kun sitagliptiini on lisätty metformiinihoitoon:<br/>Yleinen (enintään yhdellä potilaalla 10:stä): alhainen verensokeri, pahoinvointi, ilmavaivat, oksentelu<br/>Melko harvinainen (enintään yhdellä potilaalla 100:sta): vatsakipu, ripuli, ummetus, uneliaisuus.</p><p>Joillakin potilailla on esiintynyt erityyppistä epämukavaa tunnetta vatsassa, kun he ovat aloittaneet sitagliptiinin käytön yhdessä metformiinin kanssa (esiintymistiheys on yleinen).</p><p>Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia, kun sitagliptiinia on käytetty yhdessä sulfonyyliurean ja metformiinin kanssa:<br/>Hyvin yleinen (yli yhdellä potilaalla 10:stä): alhainen verensokeri<br/>Yleinen: ummetus</p><p>Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia sitagliptiinin ja pioglitatsonin käytön aikana:<br/>Yleinen: ilmavaivat, käsien tai jalkojen turvotus</p><p>Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia, kun sitagliptiinia on käytetty yhdessä pioglitatsonin ja metformiinin kanssa:<br/>Yleinen: käsien tai jalkojen turvotus</p><p>Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia, kun sitagliptiinia on käytetty yhdessä insuliinin kanssa (metformiiniin yhdistettynä tai ilman sitä):<br/>Yleinen: nuhakuume<br/>Melko harvinainen: suun kuivuminen</p><p>Joillakin potilailla on esiintynyt seuraavia haittavaikutuksia kliinisissä tutkimuksissa pelkästään sitagliptiinia käytettäessä tai tämän lääkkeen markkinoille tulemisen jälkeen, kun sitagliptiinia on käytetty yksin ja/tai yhdessä muiden diabeteslääkkeiden kanssa:<br/>Yleinen: alhainen verensokeri, päänsärky, ylähengitystieinfektio, tukkoinen tai vuotava nenä ja kurkkukipu, nivelrikko, käsivarsien ja säärten kipu<br/>Melko harvinainen: heitehuimaus, ummetus, kutina<br/>Harvinainen: verihiutaleiden vähentynyt määrä<br/>Esiintymistiheys tuntematon: munuaisongelmat, jotka joissain tapauksissa vaativat keinomunuaishoitoa, oksentelu, nivelsärky, lihassärky, selkäsärky, interstitiaalinen keuhkosairaus, rakkulainen pemfigoidi (eräänlainen rakkulamuodostuma iholla)</p><p><strong><span class=\"underline\">Haittavaikutuksista ilmoittaminen</span></strong><br/>Jos havaitset haittavaikutuksia, kerro niistä lääkärille, apteekkihenkilökunnalle tai sairaanhoitajalle. Tämä koskee myös sellaisia mahdollisia haittavaikutuksia, joita ei ole mainittu tässä pakkausselosteessa. Voit ilmoittaa haittavaikutuksista myös suoraan (ks. yhteystiedot alla). Ilmoittamalla haittavaikutuksista voit auttaa saamaan enemmän tietoa tämän lääkevalmisteen turvallisuudesta.</p><p>www-sivusto: www.fimea.fi<br/>Lääkealan turvallisuus- ja kehittämiskeskus Fimea<br/>Lääkkeiden haittavaikutusrekisteri<br/>PL 55<br/>00034 FIMEA</p></div>"
          }
        },
        {
          "title" : "Valmisteen säilyttäminen",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Valmisteen säilyttäminen</h2><p>Ei lasten ulottuville eikä näkyville.</p><p>Älä käytä tätä lääkettä läpipainopakkauksessa ja kotelossa mainitun viimeisen käyttöpäivämäärän (Käyt. viim. tai EXP) jälkeen. Viimeinen käyttöpäivämäärä tarkoittaa kuukauden viimeistä päivää.</p><p><span>Säilytä alle 25 °C.</span></p><p>Lääkkeitä ei pidä heittää viemäriin eikä hävittää talousjätteiden mukana. Kysy käyttämättömien lääkkeiden hävittämisestä apteekista. Näin menetellen suojelet luontoa.</p></div>"
          }
        },
        {
          "title" : "Pakkauksen sisältö ja muuta tietoa",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Pakkauksen sisältö ja muuta tietoa</h2><p><strong>Mitä Januvia sisältää</strong></p><ul><li>Vaikuttava aine on sitagliptiini:<ul><li>Yksi Januvia 25 mg kalvopäällysteinen tabletti (tabletti) sisältää sitagliptiinifosfaattimonohydraattia, joka vastaa 25 mg:a sitagliptiinia.</li><li>Yksi Januvia 50 mg kalvopäällysteinen tabletti (tabletti) sisältää sitagliptiinifosfaattimonohydraattia, joka vastaa 50 mg:a sitagliptiinia.</li><li>Yksi Januvia 100 mg kalvopäällysteinen tabletti (tabletti) sisältää sitagliptiinifosfaattimonohydraattia, joka vastaa 100 mg:a sitagliptiinia.</li></ul></li><li>Muut aineet ovat:<ul><li>Tabletin ydin: mikrokiteinen selluloosa (E460), vedetön kalsiumvetyfosfaatti (E341), kroskarmelloosinatrium (E468), magnesiumstearaatti (E470b), natriumstearyylifumaraatti ja propyyligallaatti.</li><li>Kalvopäällyste: poly(vinyylialkoholi), makrogoli 3350, talkki (E553b), titaanidioksidi (E171), punainen rautaoksidi (E172) ja keltainen rautaoksidi (E172).</li></ul></li></ul><p><strong>Lääkevalmisteen kuvaus ja pakkauskoot</strong><br/>- Januvia 25 mg kalvopäällysteinen tabletti on pyöreä, vaaleanpunainen kalvopäällysteinen tabletti, jossa on toisella puolella merkintä &quot;221&quot;.<br/>- Januvia 50 mg kalvopäällysteinen tabletti on pyöreä, vaaleanbeigen värinen kalvopäällysteinen tabletti, jossa on toisella puolella merkintä &quot;112&quot;.<br/>- Januvia 100 mg kalvopäällysteinen tabletti on pyöreä, beigen värinen kalvopäällysteinen tabletti, jossa on toisella puolella merkintä &quot;277&quot;.</p><p>Läpinäkymätön läpipainopakkaus (PVC/PE/PVDC ja alumiini). Pakkauksissa on 14, 28, 30, 56, 84, 90 tai 98 kalvopäällysteistä tablettia, tai 50x1 kalvopäällysteistä tablettia perforoiduissa, yksittäispakatuissa läpipainopakkauksissa.</p><p>Kaikkia pakkauskokoja ei välttämättä ole myynnissä.</p><p><strong>Myyntiluvan haltija ja valmistaja</strong><br/>Merck Sharp &amp; Dohme B.V.<br/>Waarderweg 39<br/>2031 BN Haarlem<br/>Alankomaat</p><p>Lisätietoja tästä lääkevalmisteesta antaa myyntiluvan haltijan paikallinen edustaja:</p><p><strong>Suomi/Finland</strong><br/>MSD Finland Oy<br/>Puh/Tel: +358 (0)9 804 650<br/>info@msd.fi</p><p><strong>Tämä pakkausseloste on tarkistettu viimeksi 09/2023</strong></p><p>Lisätietoa tästä lääkevalmisteesta on saatavilla Euroopan lääkeviraston verkkosivulla <a href=\"http://www.ema.europa.eu.\">http://www.ema.europa.eu</a>.</p></div>"
          },
          "section" : [{
            "title" : "Tekstin muuttamispäivämäärä",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Tekstin muuttamispäivämäärä</h2>14.09.2023</div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-55",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-55",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-55\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-55</b></p><a name=\"Diabetes-MPD-55\"> </a><a name=\"hcDiabetes-MPD-55\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_25A0CD14-4F68-46B0-9BF1-2464CCAC3114</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Januvia tab 100 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_25A0CD14-4F68-46B0-9BF1-2464CCAC3114"
      }],
      "name" : [{
        "productName" : "Januvia tab 100 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-63",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-63",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-63\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-63</b></p><a name=\"Diabetes-PPD-63\"> </a><a name=\"hcDiabetes-PPD-63\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_98BC2493-2B3A-418C-81AC-BE73F3154AC0, <code>https://farmalogg.no/varenummer</code>/076033, <code>https://pharmaca.fi/vnr</code>/076033</p><p><b>name</b>: Januvia tab 100 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK85746.html#MedicinalProductDefinition_Diabetes-MPD-55\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_25A0CD14-4F68-46B0-9BF1-2464CCAC3114</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_98BC2493-2B3A-418C-81AC-BE73F3154AC0"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "076033"
      },
      {
        "system" : "https://pharmaca.fi/vnr",
        "value" : "076033"
      }],
      "name" : "Januvia tab 100 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-55"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-62",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-62",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-62\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-62</b></p><a name=\"Diabetes-PPD-62\"> </a><a name=\"hcDiabetes-PPD-62\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_DD24F7AE-7C5B-4F0B-B8E9-BDDF3221770B, <code>https://farmalogg.no/varenummer</code>/076024, <code>https://pharmaca.fi/vnr</code>/076024</p><p><b>name</b>: Januvia tab 100 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK85746.html#MedicinalProductDefinition_Diabetes-MPD-55\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_25A0CD14-4F68-46B0-9BF1-2464CCAC3114</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_DD24F7AE-7C5B-4F0B-B8E9-BDDF3221770B"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "076024"
      },
      {
        "system" : "https://pharmaca.fi/vnr",
        "value" : "076024"
      }],
      "name" : "Januvia tab 100 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-55"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-56",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-56",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-56\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-56</b></p><a name=\"Diabetes-MPD-56\"> </a><a name=\"hcDiabetes-MPD-56\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_D441A17A-03AC-4D40-9E07-60D5185742DA</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Januvia tab 25 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_D441A17A-03AC-4D40-9E07-60D5185742DA"
      }],
      "name" : [{
        "productName" : "Januvia tab 25 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-64",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-64",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-64\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-64</b></p><a name=\"Diabetes-PPD-64\"> </a><a name=\"hcDiabetes-PPD-64\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_6C9CB0AA-ADF9-4F8B-981C-6FCF36D4DB1D, <code>https://farmalogg.no/varenummer</code>/076043, <code>https://pharmaca.fi/vnr</code>/076043</p><p><b>name</b>: Januvia tab 25 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK85746.html#MedicinalProductDefinition_Diabetes-MPD-56\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_D441A17A-03AC-4D40-9E07-60D5185742DA</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_6C9CB0AA-ADF9-4F8B-981C-6FCF36D4DB1D"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "076043"
      },
      {
        "system" : "https://pharmaca.fi/vnr",
        "value" : "076043"
      }],
      "name" : "Januvia tab 25 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-56"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-57",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-57",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-57\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-57</b></p><a name=\"Diabetes-MPD-57\"> </a><a name=\"hcDiabetes-MPD-57\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_E828BB54-3AA9-4681-B754-693722DF187D</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Januvia tab 50 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_E828BB54-3AA9-4681-B754-693722DF187D"
      }],
      "name" : [{
        "productName" : "Januvia tab 50 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-65",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-65",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-65\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-65</b></p><a name=\"Diabetes-PPD-65\"> </a><a name=\"hcDiabetes-PPD-65\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_CF3E56A7-BD36-4F62-BF6C-2CDB52750757, <code>https://farmalogg.no/varenummer</code>/076052, <code>https://pharmaca.fi/vnr</code>/076052</p><p><b>name</b>: Januvia tab 50 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK85746.html#MedicinalProductDefinition_Diabetes-MPD-57\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_E828BB54-3AA9-4681-B754-693722DF187D</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_CF3E56A7-BD36-4F62-BF6C-2CDB52750757"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "076052"
      },
      {
        "system" : "https://pharmaca.fi/vnr",
        "value" : "076052"
      }],
      "name" : "Januvia tab 50 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-57"
      }]
    }
  }]
}

```
