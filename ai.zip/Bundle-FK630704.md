# FK630704 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK630704**

## Example Bundle: FK630704

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: Informasjon til brukeren

 

# Pakningsvedlegg: Informasjon til brukeren

## NovoRapid Penfill 100 enheter/ml injeksjonsvæske, oppløsning i sylinderampulle

### insulin aspart


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.
* Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.
* Kontakt lege, sykepleier eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om:

 

## I dette pakningsvedlegget finner du informasjon om:

1. Hva NovoRapid er og hva det brukes mot
1. Hva du må vite før du bruker NovoRapid
1. Hvordan du bruker NovoRapid
1. Mulige bivirkninger
1. Hvordan du oppbevarer NovoRapid
1. Innholdet i pakningen og ytterligere informasjon


#### 1. Hva NovoRapid er og hva det brukes mot

 

## 1. Hva NovoRapid er og hva det brukes mot

NovoRapid er et moderne insulin (insulinanalog) med en hurtigvirkende effekt. Moderne insulinpreparater er forbedrete versjoner av humant insulin.

NovoRapid brukes til å senke det høye blodsukkernivået hos voksne, ungdom og barn fra 1 år og oppover med diabetes mellitus (diabetes). Diabetes er en sykdom hvor kroppen ikke produserer nok insulin til å kontrollere blodsukkernivået. Behandling med NovoRapid hjelper med å forhindre komplikasjoner fra din diabetes.

NovoRapid vil begynne å senke blodsukkeret ditt 10-20 minutter etter injeksjon, og har en maksimal effekt mellom 1 og 3 timer etter injeksjonen. Effekten vil vare i 3-5 timer. På grunn av den korte virketiden bør NovoRapid normalt tas i kombinasjon med middels langtidsvirkende eller langtidsvirkende insulinpreparater


#### 2. Hva du må vite før du bruker NovoRapid

 

## 2. Hva du må vite før du bruker NovoRapid


#### 3. Hvordan du bruker NovoRapid

 

## 3. Hvordan du bruker NovoRapid

Dose og når skal du ta insulin
Bruk alltid insulinet og innstill dosen din nøyaktig slik legen har fortalt deg. Kontakt lege, sykepleier eller apotek hvis du er usikker.

NovoRapid tas vanligvis rett før et måltid. Spis et måltid eller mellommåltid innen 10 minutter etter injeksjonen for å unngå lavt blodsukker (føling). Om nødvendig, kan NovoRapid gis umiddelbart etter et måltid. For informasjon se under Hvordan og hvor skal det injiseres.

Ikke skift insulinet ditt med mindre legen din har gitt deg beskjed om det. Skifte av insulintype eller - merke kan medføre at legen vil justere dosen.

Bruk hos barn og ungdom
NovoRapid kan brukes til ungdom og barn fra 1 år og oppover i stedet for hurtigvirkende humant insulin der en rask innsettende virkning er å foretrekke, som for eksempel når det er vanskelig med insulindosering i forbindelse med barnets måltider.

Bruk hos spesielle pasientgrupper
Dersom du har redusert nyre- eller leverfunksjon eller dersom du er over 65 år, må du kontrollere blodsukkeret ditt mer regelmessig og diskutere endringer av insulindosen med legen.

Hvordan og hvor skal det injiseres
NovoRapid er beregnet til injeksjon under huden (subkutant). Du må aldri selv injisere direkte i en blodåre (intravenøst) eller muskel (intramuskulært). NovoRapid Penfill er kun tilpasset injeksjon under huden ved bruk av en flergangspenn. Snakk med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.

For hver injeksjon bytt injeksjonssted innenfor det bestemte hudområdet du bruker. Dette kan redusere risikoen for utvikling av kuler eller fordypninger i huden (se avsnitt 4, Mulige bivirkninger). De stedene på kroppen som egner seg best for injeksjon er: foran ved midjen (magen), på overarmen eller foran på lårene. Effekten av insulinet inntrer raskere hvis det injiseres foran ved midjen. Du bør alltid måle blodsukkeret regelmessig.

* Du må ikke etterfylle sylinderampullen. Når den er tom, skal den kastes.
* NovoRapid Penfill sylinderampuller er utformet til bruk sammen med insulininjeksjonssystemer fra Novo Nordisk og NovoFine eller NovoTwist nåler.
* Dersom du behandles med NovoRapid Penfill og en annen insulintype i Penfill sylinderampulle, må du bruke to insulininjeksjonssystemer, ett for hver insulintype.
* Ha alltid med deg en ekstra Penfill sylinderampulle i tilfelle den mistes eller ødelegges.

Hvordan injisere NovoRapid

* Injiser insulinet under huden. Følg legens eller sykepleierens råd angående injeksjonsteknikk, og som beskrevet i bruksanvisningen til pennen din.
* Hold nålen under huden i minst 6 sekunder. Hold trykknappen helt inne inntil nålen er trukket ut av huden. Dette sikrer riktig levering og begrenser muligheten for at det kommer blod inn i nålen eller i insulinbeholderen.
* Fjern og kast nålen etter hver injeksjon. Oppbevar alltid NovoRapid uten påsatt nål. Hvis ikke, kan det lekke ut væske som kan medføre feil dosering.


#### 4. Mulige bivirkninger

 

## 4. Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.

a) Sammendrag av alvorlige og svært vanlige bivirkninger

**Lavt blodsukker (føling, hypoglykemi) **er en svært vanlig bivirkning. Den kan berøre flere enn 1 av 10 personer.

Lavt blodsukker kan inntreffe hvis du:
* Injiserer for mye insulin.
* Spiser for lite eller hopper over et måltid.
* Mosjonerer mer enn vanlig.
* Drikker alkohol (se Inntak av alkohol sammen med NovoRapid under avsnitt 2).

Symptomer på lavt blodsukker:Kaldsvetting, kald og blek hud, hodepine, hjertebank, kvalme, usedvanlig stor sultfølelse, forbigående synsforstyrrelser, døsighet, unormal tretthet og svakhet, nervøsitet eller skjelving, angst, forvirring og konsentrasjonsproblemer.

Alvorlig lavt blodsukker kan føre til bevisstløshet. Dersom langvarig alvorlig lavt blodsukker ikke behandles, kan det føre til hjerneskade (midlertidig eller livsvarig) og til og med død. Du kan komme raskere til bevissthet igjen hvis du får en injeksjon av hormonet glukagon av en person som er blitt instruert i hvordan det skal brukes. Dersom glukagon er injisert, må du så snart du kommer til bevissthet få glukose eller et sukkerholdig mellommåltid. Hvis du ikke reagerer på glukagonbehandling, må du behandles ved et sykehus.

Hva skal du gjøre hvis du får lavt blodsukker:
* Dersom du opplever lavt blodsukker, spis glukosetabletter eller et annet mellommåltid med høyt sukkerinnhold (for eksempel søtsaker, kjeks, fruktjuice). Hvis mulig, mål blodsukkeret ditt og ta en hvil. For sikkerhets skyld må du alltid ha med deg glukosetabletter eller et mellommåltid med høyt sukkerinnhold.
* Når symptomer på lavt blodsukker har forsvunnet, eller når blodsukkernivået er stabilisert, fortsettes insulinbehandlingen som vanlig.
* Dersom du får et så lavt blodsukker at du besvimer, dersom du har hatt behov for en injeksjon av glukagon, eller dersom du har hatt gjentatte episoder med lavt blodsukker skal du snakke med legen. Det kan være nødvendig å justere insulindosen, tidspunktet for insulindosering, matinntak eller mengde fysisk aktivitet.

Fortell relevante personer at du har diabetes og hva konsekvensene kan være, inkludert risikoen for å besvime (bli bevisstløs) på grunn av lavt blodsukker. La dem få vite at hvis du besvimer må de legge deg i stabilt sideleie og tilkalle lege med det samme. De må ikke gi deg noe å spise eller drikke på grunn av risiko for kvelning.

**Alvorlige allergiske reaksjoner **overfor NovoRapid eller et av innholdsstoffene i preparatet (en såkalt systemisk allergisk reaksjon) er en svært sjelden bivirkning, men kan potensielt være livstruende. Den kan berøre færre enn 1 av 10 000 personer.

Søk råd hos helsepersonell omgående:
* Dersom symptomene på allergi sprer seg til andre deler av kroppen.
* Dersom du plutselig føler deg dårlig og du: begynner å svette, blir kvalm (kaster opp), får pustebesvær, får hjertebank, føler deg svimmel.
* Dersom du merker noen av disse symptomene, søk råd hos helsepersonell omgående.

**Hudforandringer på injeksjonsstedet: **Fettvevet kan skrumpe (lipoatrofi) eller fortykkes (lipohypertrofi) (kan berøre færre enn 1 av 100 personer) hvis du injiserer insulin på samme sted. Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete, innskrumpet eller fortykket område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.

b) Liste over andre bivirkninger

**Mindre vanlige bivirkninger**

Kan berøre færre enn 1 av 100 personer.

Symptomer på allergi:Lokale allergiske reaksjoner (smerte, rødhet, elveblest, inflammasjon, blåmerker, hevelse og kløe) på injeksjonsstedet kan forekomme. Disse forsvinner vanligvis i løpet av få uker ved fortsatt bruk av insulinet. Hvis de ikke forsvinner, eller det sprer seg over hele kroppen, snakk med lege omgående. Se også Alvorlige allergiske reaksjoner ovenfor.

Synsforstyrrelser:Synsforstyrrelser kan oppstå i begynnelsen av en insulinbehandling, men er vanligvis av forbigående karakter.

Hovne ledd:Når du begynner insulinbehandlingen, kan væskeansamling forårsake hevelse rundt ankler og andre ledd. Dette er normalt av forbigående karakter, hvis ikke, snakk med legen.

Diabetisk retinopati(en øyesykdom relatert til diabetes som kan føre til synstap): Dersom du har diabetisk retinopati og blodsukkernivået ditt forbedres veldig raskt, kan retinopatien bli verre. Spør legen om dette.

Sjeldne bivirkninger
Kan berøre færre enn 1 av 1000 personer.

Smertefull neuropati(smerte som skyldes nerveskade): Hvis blodsukkernivået ditt forbedres veldig raskt kan du få en nerverelatert smerte. Dette kalles akutt smertefull neuropati og er vanligvis forbigående.

c) Følger ved diabetes
Høyt blodsukker (hyperglykemi)

Høyt blodsukker kan inntreffe hvis du:
* Ikke har injisert nok insulin.
* Glemmer å ta insulin eller avbryter behandlingen med insulin.
* Gjentatte ganger tar mindre insulin enn det du trenger.
* Får en infeksjon og/eller feber.
* Spiser mer enn vanlig.
* Mosjonerer mindre enn vanlig.

Varselsymptomer på høyt blodsukker:

Varselsymptomene utvikler seg gradvis. De inkluderer: økt vannlating, tørste, manglende appetitt, uvelhet (kvalme eller oppkast), døsighet eller tretthet, rødmende hud, tørr hud, munntørrhet og fruktluktende (acetonluktende) ånde.

Hva gjør du hvis du får høyt blodsukker:
* Dersom du får noen av symptomene nevnt ovenfor: kontroller blodsukkernivået, hvis mulig kontroller urinen for ketoner, søk deretter råd hos helsepersonell omgående.
* Dette kan være symptomer på en meget alvorlig tilstand kalt diabetisk ketoacidose (opphopning av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Dersom den ikke behandles, kan den føre til diabetisk koma og til slutt død.


#### 5. Hvordan du oppbevarer NovoRapid

 

## 5. Hvordan du oppbevarer NovoRapid

Oppbevares utilgjengelig for barn.

Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på sylinderampullens etikett og eske etter “EXP”. Utløpsdatoen er den siste dagen i den angitte måneden.

Oppbevar alltid sylinderampullen i ytteremballasjen når den ikke er i bruk for å beskytte mot lys.

NovoRapid skal beskyttes mot sterk varme og lys.

**Før anbrudd: **NovoRapid Penfill som ikke er tatt i bruk skal oppbevares i kjøleskap ved 2-8ºC, borte fra kjøleelementet. Skal ikke fryses.

**Under bruk eller medbrakt som reserve: **NovoRapid Penfill som er tatt i bruk eller medbrakt som reserve skal ikke oppbevares i kjøleskap. Den kan medbringes og oppbevares i romtemperatur (ved høyst 30ºC) i opptil 4 uker.

Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.


#### 6. Innholdet i pakningen og ytterligere informasjon

 

## 6. Innholdet i pakningen og ytterligere informasjon


####  NovoRapid Penfill inj, oppl 100 E/ml 
LEGEMIDDELMERKEVAREID:
** ID_B6913F2C-99FD-486D-83D8-BE7A8094DA2F **
-------

Full name: **NovoRapid Penfill inj, oppl 100 E/ml**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_AE39172F-30A5-4AF7-8449-68C3B6BCF09F ** 

VARENUMMER: ** 093948 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK630704",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "630704"
  },
  "type" : "document",
  "timestamp" : "2023-03-20T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK630704-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK630704-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK630704-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK630704-COMP</b></p><a name=\"FK630704-COMP\"> </a><a name=\"hcFK630704-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/630704</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2023-03-20</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: NovoRapid Penfill Novo Nordisk sylinderampuller til bruk i insulininjeksjonssystemer fra Novo Nordisk og NovoFine eller NovoTwist nåler</p></div>"
      },
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "630704"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-91"
      }],
      "date" : "2023-03-20",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "NovoRapid Penfill Novo Nordisk sylinderampuller til bruk i insulininjeksjonssystemer fra Novo Nordisk og NovoFine eller NovoTwist nåler",
      "section" : [{
        "title" : "Pakningsvedlegg: Informasjon til brukeren",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: Informasjon til brukeren</h1><h2>NovoRapid Penfill 100 enheter/ml injeksjonsvæske, oppløsning i sylinderampulle</h2><h3>insulin aspart</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.</li><li>Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.</li><li>Kontakt lege, sykepleier eller apotek dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om:",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om:</h2><div class=\"paragraph\"><ol><li>Hva NovoRapid er og hva det brukes mot</li><li>Hva du må vite før du bruker NovoRapid</li><li>Hvordan du bruker NovoRapid</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer NovoRapid</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "1. Hva NovoRapid er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>1. Hva NovoRapid er og hva det brukes mot</h2><div class=\"paragraph\">NovoRapid er et moderne insulin (insulinanalog) med en hurtigvirkende effekt. Moderne insulinpreparater er forbedrete versjoner av humant insulin.</div><div class=\"paragraph\">NovoRapid brukes til å senke det høye blodsukkernivået hos voksne, ungdom og barn fra 1 år og oppover med diabetes mellitus (diabetes). Diabetes er en sykdom hvor kroppen ikke produserer nok insulin til å kontrollere blodsukkernivået. Behandling med NovoRapid hjelper med å forhindre komplikasjoner fra din diabetes.</div><div class=\"paragraph\">NovoRapid vil begynne å senke blodsukkeret ditt 10-20 minutter etter injeksjon, og har en maksimal effekt mellom 1 og 3 timer etter injeksjonen. Effekten vil vare i 3-5 timer. På grunn av den korte virketiden bør NovoRapid normalt tas i kombinasjon med middels langtidsvirkende eller langtidsvirkende insulinpreparater</div></div>"
          }
        },
        {
          "title" : "2. Hva du må vite før du bruker NovoRapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>2. Hva du må vite før du bruker NovoRapid</h2></div>"
          },
          "section" : [{
            "title" : "Bruk ikke NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Bruk ikke NovoRapid</h3><div class=\"paragraph\"><ul><li>Dersom du er allergisk overfor insulin aspart eller noen av de andre innholdsstoffene i dette legemidlet (listet opp i avsnitt 6, Innholdet i pakningen og ytterligere informasjon).</li><li>Dersom du tror at du begynner å få føling (hypoglykemi, lavt blodsukker) (se a) Sammendrag av alvorlige og svært vanlige bivirkninger under avsnitt 4).</li><li>Dersom sylinderampullen eller injeksjonssystemet som inneholder sylinderampullen utsettes for støt, skades eller klemmes.</li><li>Dersom det ikke har vært riktig oppbevart, eller dersom det har vært frosset (se avsnitt 5, Hvordan du oppbevarer NovoRapid).</li><li>Dersom insulinet ikke fremstår som klart og fargeløst.</li></ul></div><div class=\"paragraph\">Bruk ikke NovoRapid hvis noe av dette forekommer. Snakk med lege, sykepleier eller apotek.</div><span class=\"inline-title\">Før du bruker NovoRapid</span><div class=\"paragraph\"><ul><li>Kontroller etiketten for å forsikre deg om at det er riktig type insulin.</li><li>Du må alltid kontrollere sylinderampullen samt gummistemplet i bunnen av sylinderampullen. Ikke bruk den hvis det er synlig skade på den, eller hvis gummistemplet er trukket over det hvite etikettbåndet i bunnen av sylinderampullen. Dette kan være et resultat av insulinlekkasje. Hvis du tror sylinderampullen er skadet, returneres preparatet til apoteket. Se pennens bruksanvisning for nærmere instruksjoner.</li><li>Bruk alltid en ny nål til hver injeksjon for å unngå urenheter.</li><li>Nåler og NovoRapid Penfill må ikke deles med andre.</li><li>NovoRapid Penfill er kun tilpasset injeksjon under huden ved bruk av en flergangspenn. Snakk med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler</h3><div class=\"paragraph\">Noen tilstander og aktiviteter kan påvirke insulinbehovet ditt. Rådfør deg med lege:<ul><li>Dersom du har nyre- eller leverproblemer, eller problemer med binyrene, hypofysen eller skjoldbruskkjertelen.</li><li>Dersom du mosjonerer mer enn vanlig eller hvis du ønsker å endre ditt vanlige kosthold, da dette kan påvirke blodsukkernivået ditt.</li><li>Dersom du er syk, fortsett å ta insulin og rådfør deg med lege.</li><li>Dersom du skal reise utenlands, tidsforskjellen mellom ulike land kan påvirke insulinbehovet og tidspunktene for dine injeksjoner.</li></ul></div><span class=\"inline-title\">Hudforandringer på injeksjonsstedet</span><div class=\"paragraph\">Injeksjonsstedet bør roteres for å bidra til å forebygge forandringer i fettvevet under huden, som f.eks. fortykning av huden, innskrumping av huden eller kuler under huden. Det kan hende at insulinet ikke virker så godt hvis du injiserer det på et klumpete, innskrumpet eller fortykket sted på huden (se avsnitt 3, ”Hvordan du bruker NovoRapid”). Snakk med legen din hvis du merker noen hudforandringer på injeksjonsstedet. Hvis du pleier å injisere på områder med reaksjoner og vil endre injeksjonssted til et annet område, må du snakke med legen din først. Legen din kan gi deg beskjed om å kontrollere blodsukkeret ditt mer nøye og å justere dosen på insulinet ditt eller andre legemidler du bruker mot diabetes.</div></div>"
            }
          },
          {
            "title" : "Barn og ungdom",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029899"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Barn og ungdom</h3><div class=\"paragraph\">Ikke gi dette legemidlet til barn under 1 år, da det ikke er utført kliniske studier hos barn under 1 år.</div></div>"
            }
          },
          {
            "title" : "Andre legemidler og NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og NovoRapid</h3><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler.<br/>Noen legemidler påvirker blodsukkernivået, og dette kan bety at insulindosen må endres. Nedenfor følger en oversikt over de vanligste legemidlene som kan påvirke insulinbehandlingen din.</div><div class=\"paragraph\"><span class=\"underline\">Blodsukkernivået ditt kan synke (hypoglykemi, føling) dersom du bruker:</span><ul><li>Andre medisiner til behandling av diabetes</li><li>Monoaminoksidasehemmere (MAOH) (brukes til behandling av depresjon)</li><li>Betablokkere (brukes til behandling av høyt blodtrykk)</li><li>Angiotensinkonverterende enzym(ACE)hemmere (brukes til behandling av visse hjertelidelser eller høyt blodtrykk)</li><li>Salisylater (brukes til å lindre smerte og som febernedsettende)</li><li>Anabole steroider (slik som testosteron)</li><li>Sulfonamider (brukes til behandling av infeksjoner).</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Blodsukkernivået ditt kan stige (hyperglykemi) dersom du bruker:</span><ul><li>Orale antikonsepsjonsmidler (p-piller)</li><li>Tiazider (brukes til behandling av høyt blodtrykk eller ved omfattende væskeopphopning)</li><li>Glukokortikoider (slik som ”kortison”, som brukes til behandling av inflammasjon)</li><li>Thyreoideahormoner (brukes til behandling av sykdommer i skjoldbruskkjertelen)</li><li>Sympatomimetika (som adrenalin eller salbutamol, terbutalin som brukes til behandling av astma)</li><li>Veksthormon (legemiddel til stimulering av skjelett- og kroppslig vekst og med omfattende påvirkning på kroppens stoffskifteprosesser)</li><li>Danazol (legemiddel som påvirker eggløsningen).</li></ul></div><div class=\"paragraph\">Oktreotid og lanreotid (brukes til behandling av akromegali, en sjelden hormonell sykdom som vanligvis oppstår hos middelaldrende voksne og som kommer av at hypofysen produserer for mye veksthormon) kan enten øke eller senke blodsukkernivået ditt.</div><div class=\"paragraph\">Betablokkere (brukes til behandling av høyt blodtrykk) kan svekke eller fullstendig dempe de første varselsymptomene som hjelper deg til å gjenkjenne lavt blodsukker.</div><div class=\"paragraph\"><span class=\"underline\">Pioglitazon (tabletter brukt til behandling av type 2 diabetes)</span><br/>Noen pasienter med mangeårig type 2 diabetes og hjertesykdom eller som har hatt slag og som ble behandlet med pioglitazon og insulin, utviklet hjertesvikt. Snakk med lege så snart som mulig hvis du opplever tegn på hjertesvikt slik som uvanlig kortpustethet eller rask vektøkning eller lokale væskeansamlinger (hevelse i bena, ødem).</div><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek dersom du bruker noen av legemidlene som er nevnt her.</div></div>"
            }
          },
          {
            "title" : "Inntak av alkohol sammen med NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029901"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Inntak av alkohol sammen med NovoRapid</h3><div class=\"paragraph\"><ul><li>Dersom du drikker alkohol, kan behovet for insulin endre seg fordi blodsukkernivået enten kan stige eller synke. Nøye blodsukkerkontroll anbefales.</li></ul></div></div>"
            }
          },
          {
            "title" : "Graviditet og amming",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet og amming</h3><div class=\"paragraph\"><ul><li>Snakk med lege før du tar dette legemidlet dersom du er gravid, tror at du kan være gravid eller planlegger å bli gravid. NovoRapid kan brukes under graviditet. Det kan være behov for å endre insulindosen under svangerskapet og etter fødselen. Det er viktig med nøye kontroll av din diabetes, særlig er det viktig å forhindre føling, dette for ditt barns helse.</li><li>Det er ingen restriksjoner for behandling med NovoRapid under amming.</li></ul></div><div class=\"paragraph\">Snakk med lege, sykepleier eller apotek før du tar dette legemidlet dersom du er gravid eller ammer.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\"><ul><li>Spør legen om du kan kjøre bil eller betjene en maskin:<ul><li>Dersom du ofte får føling.</li><li>Dersom du har problemer med å gjenkjenne føling.</li></ul></li></ul></div><div class=\"paragraph\">Dersom blodsukkeret ditt er lavt eller høyt, kan det påvirke konsentrasjons- og reaksjonsevnen og derfor også evnen til å kjøre eller betjene en maskin. Tenk på at du kan utsette deg selv eller andre for fare.</div><div class=\"paragraph\">NovoRapid har en hurtig innsettende effekt, derfor kan du, hvis føling inntreffer, merke den tidligere enn etter en injeksjon med hurtigvirkende humant insulin.</div></div>"
            }
          },
          {
            "title" : "Viktig informasjon om noen av innholdsstoffene i NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Viktig informasjon om noen av innholdsstoffene i NovoRapid</h3><div class=\"paragraph\">NovoRapid inneholder mindre enn 1 mmol natrium (23 mg) pr. dose, det vil si at NovoRapid praktisk talt er ”natriumfritt”.</div></div>"
            }
          }]
        },
        {
          "title" : "3. Hvordan du bruker NovoRapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>3. Hvordan du bruker NovoRapid</h2><span class=\"inline-title\">Dose og når skal du ta insulin</span><div class=\"paragraph\">Bruk alltid insulinet og innstill dosen din nøyaktig slik legen har fortalt deg. Kontakt lege, sykepleier eller apotek hvis du er usikker.</div><div class=\"paragraph\">NovoRapid tas vanligvis rett før et måltid. Spis et måltid eller mellommåltid innen 10 minutter etter injeksjonen for å unngå lavt blodsukker (føling). Om nødvendig, kan NovoRapid gis umiddelbart etter et måltid. For informasjon se under Hvordan og hvor skal det injiseres.</div><div class=\"paragraph\">Ikke skift insulinet ditt med mindre legen din har gitt deg beskjed om det. Skifte av insulintype eller - merke kan medføre at legen vil justere dosen.</div><span class=\"inline-title\">Bruk hos barn og ungdom</span><div class=\"paragraph\">NovoRapid kan brukes til ungdom og barn fra 1 år og oppover i stedet for hurtigvirkende humant insulin der en rask innsettende virkning er å foretrekke, som for eksempel når det er vanskelig med insulindosering i forbindelse med barnets måltider.</div><span class=\"inline-title\">Bruk hos spesielle pasientgrupper</span><div class=\"paragraph\">Dersom du har redusert nyre- eller leverfunksjon eller dersom du er over 65 år, må du kontrollere blodsukkeret ditt mer regelmessig og diskutere endringer av insulindosen med legen.</div><span class=\"inline-title\">Hvordan og hvor skal det injiseres</span><div class=\"paragraph\">NovoRapid er beregnet til injeksjon under huden (subkutant). Du må aldri selv injisere direkte i en blodåre (intravenøst) eller muskel (intramuskulært). NovoRapid Penfill er kun tilpasset injeksjon under huden ved bruk av en flergangspenn. Snakk med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.</div><div class=\"paragraph\">For hver injeksjon bytt injeksjonssted innenfor det bestemte hudområdet du bruker. Dette kan redusere risikoen for utvikling av kuler eller fordypninger i huden (se avsnitt 4, Mulige bivirkninger). De stedene på kroppen som egner seg best for injeksjon er: foran ved midjen (magen), på overarmen eller foran på lårene. Effekten av insulinet inntrer raskere hvis det injiseres foran ved midjen. Du bør alltid måle blodsukkeret regelmessig.</div><div class=\"paragraph\"><ul><li>Du må ikke etterfylle sylinderampullen. Når den er tom, skal den kastes.</li><li>NovoRapid Penfill sylinderampuller er utformet til bruk sammen med insulininjeksjonssystemer fra Novo Nordisk og NovoFine eller NovoTwist nåler.</li><li>Dersom du behandles med NovoRapid Penfill og en annen insulintype i Penfill sylinderampulle, må du bruke to insulininjeksjonssystemer, ett for hver insulintype.</li><li>Ha alltid med deg en ekstra Penfill sylinderampulle i tilfelle den mistes eller ødelegges.</li></ul></div><span class=\"inline-title\">Hvordan injisere NovoRapid</span><div class=\"paragraph\"><ul><li>Injiser insulinet under huden. Følg legens eller sykepleierens råd angående injeksjonsteknikk, og som beskrevet i bruksanvisningen til pennen din.</li><li>Hold nålen under huden i minst 6 sekunder. Hold trykknappen helt inne inntil nålen er trukket ut av huden. Dette sikrer riktig levering og begrenser muligheten for at det kommer blod inn i nålen eller i insulinbeholderen.</li><li>Fjern og kast nålen etter hver injeksjon. Oppbevar alltid NovoRapid uten påsatt nål. Hvis ikke, kan det lekke ut væske som kan medføre feil dosering.</li></ul></div></div>"
          },
          "section" : [{
            "title" : "Dersom du tar for mye insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029907"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du tar for mye insulin</h3><div class=\"paragraph\">Dersom du tar for mye insulin blir blodsukkeret for lavt (hypoglykemi). Se a) Sammendrag av alvorlige og svært vanlige bivirkninger under avsnitt 4.</div></div>"
            }
          },
          {
            "title" : "Dersom du har glemt å ta insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029908"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du har glemt å ta insulin</h3><div class=\"paragraph\">Dersom du glemmer å ta insulinet ditt kan blodsukkeret bli for høyt (hyperglykemi). Se c) Følger ved diabetes under avsnitt 4.</div></div>"
            }
          },
          {
            "title" : "Dersom du avbryter behandling med insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029909"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du avbryter behandling med insulin</h3><div class=\"paragraph\">Ikke slutt med å ta insulin uten å snakke med en lege, som vil fortelle deg hva som må gjøres. Dette kan føre til veldig høyt blodsukker (alvorlig hyperglykemi) og ketoacidose. Se c) Følger ved diabetes under avsnitt 4.</div><div class=\"paragraph\">Spør lege, sykepleier eller apotek dersom du har noen spørsmål om bruken av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "4. Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>4. Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.</div><span class=\"inline-title\">a) Sammendrag av alvorlige og svært vanlige bivirkninger</span><div class=\"paragraph\"><b>Lavt blodsukker (føling, hypoglykemi) </b>er en svært vanlig bivirkning. Den kan berøre flere enn 1 av 10 personer.</div><div class=\"paragraph\"><span class=\"underline\">Lavt blodsukker kan inntreffe hvis du:</span><ul><li>Injiserer for mye insulin.</li><li>Spiser for lite eller hopper over et måltid.</li><li>Mosjonerer mer enn vanlig.</li><li>Drikker alkohol (se Inntak av alkohol sammen med NovoRapid under avsnitt 2).</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Symptomer på lavt blodsukker:</span> Kaldsvetting, kald og blek hud, hodepine, hjertebank, kvalme, usedvanlig stor sultfølelse, forbigående synsforstyrrelser, døsighet, unormal tretthet og svakhet, nervøsitet eller skjelving, angst, forvirring og konsentrasjonsproblemer.</div><div class=\"paragraph\">Alvorlig lavt blodsukker kan føre til bevisstløshet. Dersom langvarig alvorlig lavt blodsukker ikke behandles, kan det føre til hjerneskade (midlertidig eller livsvarig) og til og med død. Du kan komme raskere til bevissthet igjen hvis du får en injeksjon av hormonet glukagon av en person som er blitt instruert i hvordan det skal brukes. Dersom glukagon er injisert, må du så snart du kommer til bevissthet få glukose eller et sukkerholdig mellommåltid. Hvis du ikke reagerer på glukagonbehandling, må du behandles ved et sykehus.</div><div class=\"paragraph\"><span class=\"underline\">Hva skal du gjøre hvis du får lavt blodsukker:</span><ul><li>Dersom du opplever lavt blodsukker, spis glukosetabletter eller et annet mellommåltid med høyt sukkerinnhold (for eksempel søtsaker, kjeks, fruktjuice). Hvis mulig, mål blodsukkeret ditt og ta en hvil. For sikkerhets skyld må du alltid ha med deg glukosetabletter eller et mellommåltid med høyt sukkerinnhold.</li><li>Når symptomer på lavt blodsukker har forsvunnet, eller når blodsukkernivået er stabilisert, fortsettes insulinbehandlingen som vanlig.</li><li>Dersom du får et så lavt blodsukker at du besvimer, dersom du har hatt behov for en injeksjon av glukagon, eller dersom du har hatt gjentatte episoder med lavt blodsukker skal du snakke med legen. Det kan være nødvendig å justere insulindosen, tidspunktet for insulindosering, matinntak eller mengde fysisk aktivitet.</li></ul></div><div class=\"paragraph\">Fortell relevante personer at du har diabetes og hva konsekvensene kan være, inkludert risikoen for å besvime (bli bevisstløs) på grunn av lavt blodsukker. La dem få vite at hvis du besvimer må de legge deg i stabilt sideleie og tilkalle lege med det samme. De må ikke gi deg noe å spise eller drikke på grunn av risiko for kvelning.</div><div class=\"paragraph\"><b>Alvorlige allergiske reaksjoner </b>overfor NovoRapid eller et av innholdsstoffene i preparatet (en såkalt systemisk allergisk reaksjon) er en svært sjelden bivirkning, men kan potensielt være livstruende. Den kan berøre færre enn 1 av 10 000 personer.</div><div class=\"paragraph\">Søk råd hos helsepersonell omgående:<ul><li>Dersom symptomene på allergi sprer seg til andre deler av kroppen.</li><li>Dersom du plutselig føler deg dårlig og du: begynner å svette, blir kvalm (kaster opp), får pustebesvær, får hjertebank, føler deg svimmel.<ul><li>Dersom du merker noen av disse symptomene, søk råd hos helsepersonell omgående.</li></ul></li></ul></div><div class=\"paragraph\"><b>Hudforandringer på injeksjonsstedet: </b>Fettvevet kan skrumpe (lipoatrofi) eller fortykkes (lipohypertrofi) (kan berøre færre enn 1 av 100 personer) hvis du injiserer insulin på samme sted. Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete, innskrumpet eller fortykket område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.</div><span class=\"inline-title\">b) Liste over andre bivirkninger</span><div class=\"paragraph\"><b>Mindre vanlige bivirkninger</b><br/>Kan berøre færre enn 1 av 100 personer.</div><div class=\"paragraph\"><span class=\"underline\">Symptomer på allergi:</span> Lokale allergiske reaksjoner (smerte, rødhet, elveblest, inflammasjon, blåmerker, hevelse og kløe) på injeksjonsstedet kan forekomme. Disse forsvinner vanligvis i løpet av få uker ved fortsatt bruk av insulinet. Hvis de ikke forsvinner, eller det sprer seg over hele kroppen, snakk med lege omgående. Se også Alvorlige allergiske reaksjoner ovenfor.</div><div class=\"paragraph\"><span class=\"underline\">Synsforstyrrelser:</span> Synsforstyrrelser kan oppstå i begynnelsen av en insulinbehandling, men er vanligvis av forbigående karakter.</div><div class=\"paragraph\"><span class=\"underline\">Hovne ledd:</span> Når du begynner insulinbehandlingen, kan væskeansamling forårsake hevelse rundt ankler og andre ledd. Dette er normalt av forbigående karakter, hvis ikke, snakk med legen.</div><div class=\"paragraph\"><span class=\"underline\">Diabetisk retinopati</span> (en øyesykdom relatert til diabetes som kan føre til synstap): Dersom du har diabetisk retinopati og blodsukkernivået ditt forbedres veldig raskt, kan retinopatien bli verre. Spør legen om dette.</div><span class=\"inline-title\">Sjeldne bivirkninger</span><div class=\"paragraph\">Kan berøre færre enn 1 av 1000 personer.</div><div class=\"paragraph\"><span class=\"underline\">Smertefull neuropati</span> (smerte som skyldes nerveskade): Hvis blodsukkernivået ditt forbedres veldig raskt kan du få en nerverelatert smerte. Dette kalles akutt smertefull neuropati og er vanligvis forbigående.</div><span class=\"inline-title\">c) Følger ved diabetes</span> <span class=\"inline-title\">Høyt blodsukker (hyperglykemi)</span><div class=\"paragraph\"><span class=\"underline\">Høyt blodsukker kan inntreffe hvis du:</span><ul><li>Ikke har injisert nok insulin.</li><li>Glemmer å ta insulin eller avbryter behandlingen med insulin.</li><li>Gjentatte ganger tar mindre insulin enn det du trenger.</li><li>Får en infeksjon og/eller feber.</li><li>Spiser mer enn vanlig.</li><li>Mosjonerer mindre enn vanlig.</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Varselsymptomer på høyt blodsukker:</span><br/>Varselsymptomene utvikler seg gradvis. De inkluderer: økt vannlating, tørste, manglende appetitt, uvelhet (kvalme eller oppkast), døsighet eller tretthet, rødmende hud, tørr hud, munntørrhet og fruktluktende (acetonluktende) ånde.</div><div class=\"paragraph\"><span class=\"underline\">Hva gjør du hvis du får høyt blodsukker:</span><ul><li>Dersom du får noen av symptomene nevnt ovenfor: kontroller blodsukkernivået, hvis mulig kontroller urinen for ketoner, søk deretter råd hos helsepersonell omgående.</li><li>Dette kan være symptomer på en meget alvorlig tilstand kalt diabetisk ketoacidose (opphopning av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Dersom den ikke behandles, kan den føre til diabetisk koma og til slutt død.</li></ul></div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger. Dette gjelder også bivirkninger som ikke er nevnt i pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "5. Hvordan du oppbevarer NovoRapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>5. Hvordan du oppbevarer NovoRapid</h2><div class=\"paragraph\">Oppbevares utilgjengelig for barn.<br/>Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på sylinderampullens etikett og eske etter “EXP”. Utløpsdatoen er den siste dagen i den angitte måneden.<br/>Oppbevar alltid sylinderampullen i ytteremballasjen når den ikke er i bruk for å beskytte mot lys.<br/>NovoRapid skal beskyttes mot sterk varme og lys.</div><div class=\"paragraph\"><b><span class=\"underline\">Før anbrudd:</span> </b>NovoRapid Penfill som ikke er tatt i bruk skal oppbevares i kjøleskap ved 2-8ºC, borte fra kjøleelementet. Skal ikke fryses.</div><div class=\"paragraph\"><b><span class=\"underline\">Under bruk eller medbrakt som reserve:</span> </b>NovoRapid Penfill som er tatt i bruk eller medbrakt som reserve skal ikke oppbevares i kjøleskap. Den kan medbringes og oppbevares i romtemperatur (ved høyst 30ºC) i opptil 4 uker.</div><div class=\"paragraph\">Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.</div></div>"
          }
        },
        {
          "title" : "6. Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>6. Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av NovoRapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av NovoRapid</h3><div class=\"paragraph\"><ul><li>Virkestoff er insulin aspart. Hver ml inneholder 100 enheter insulin aspart. Hver sylinderampulle inneholder 300 enheter insulin aspart i 3 ml oppløsning til injeksjon.</li><li>Andre innholdstoffer er glyserol, fenol, metakresol, sinkklorid, dinatriumfosfatdihydrat, natriumklorid, saltsyre, natriumhydroksid og vann til injeksjonsvæsker.</li></ul></div></div>"
            }
          },
          {
            "title" : "Hvordan NovoRapid ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan NovoRapid ser ut og innholdet i pakningen</h3><div class=\"paragraph\">NovoRapid finnes som injeksjonsvæske, oppløsning.</div><div class=\"paragraph\">Pakningsstørrelser på 5 og 10 sylinderampuller à 3 ml. Ikke alle pakningsstørrelser vil nødvendigvis bli markedsført.</div><div class=\"paragraph\">Oppløsningen er klar og fargeløs.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen og tilvirker",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen og tilvirker</h3><span class=\"inline-title\">Innehaver av markedsføringstillatelsen</span><div class=\"paragraph\">Novo Nordisk A/S, Novo Allé, DK-2880 Bagsværd, Danmark</div><span class=\"inline-title\">Tilvirker</span><div class=\"paragraph\">Tilvirkeren kan identifiseres via batchnummeret som er trykket på kartongfliken og på etiketten:</div><div class=\"paragraph\"><ul><li>Hvis andre og tredje tegn er S6, P5, K7, R7, VG, FG eller ZF er tilvirkeren Novo Nordisk A/S, Novo Allé, DK-2880 Bagsværd, Danmark.</li></ul></div><div class=\"paragraph\"><ul><li>Hvis andre og tredje tegn er H7 eller T6 er tilvirkeren Novo Nordisk Production SAS, 45 Avenue d’Orléans, F-28000 Chartres, Frankrike.</li></ul></div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 20.03.2023",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 20.03.2023</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre informasjonskilder</h3><div class=\"paragraph\">Detaljert informasjon om dette legemidlet er tilgjengelig på nettstedet til Det europeiske legemiddelkontoret (the European Medicines Agency): <a href=\"http://www.ema.europa.eu/\" title=\"\n               \n                  http://www.ema.europa.eu\n               \n            \">http://www.ema.europa.eu </a>og på nettstedet til <a href=\"http://www.felleskatalogen.no\" title=\"\n               \n                  www.felleskatalogen.no\n               \n            \">www.felleskatalogen.no</a></div></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-91",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-91",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-91\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-91</b></p><a name=\"Diabetes-MPD-91\"> </a><a name=\"hcDiabetes-MPD-91\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_B6913F2C-99FD-486D-83D8-BE7A8094DA2F</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>NovoRapid Penfill inj, oppl 100 E/ml</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_B6913F2C-99FD-486D-83D8-BE7A8094DA2F"
      }],
      "name" : [{
        "productName" : "NovoRapid Penfill inj, oppl 100 E/ml"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-117",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-117",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-117\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-117</b></p><a name=\"Diabetes-PPD-117\"> </a><a name=\"hcDiabetes-PPD-117\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_AE39172F-30A5-4AF7-8449-68C3B6BCF09F, <code>https://farmalogg.no/varenummer</code>/093948</p><p><b>name</b>: NovoRapid Penfill inj, oppl 100 E/ml</p><p><b>packageFor</b>: <a href=\"Bundle-FK630704.html#MedicinalProductDefinition_Diabetes-MPD-91\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_B6913F2C-99FD-486D-83D8-BE7A8094DA2F</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_AE39172F-30A5-4AF7-8449-68C3B6BCF09F"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "093948"
      }],
      "name" : "NovoRapid Penfill inj, oppl 100 E/ml",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-91"
      }]
    }
  }]
}

```
