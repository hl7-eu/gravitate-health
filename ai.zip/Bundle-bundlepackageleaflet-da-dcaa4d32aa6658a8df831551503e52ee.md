# ePI document Bundle for Karvea 75 mg tablet Package Leaflet for language da - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Karvea 75 mg tablet Package Leaflet for language da**

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **14 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

## Example Bundle: ePI document Bundle for Karvea 75 mg tablet Package Leaflet for language da

**Composition category:**Raw

**Composition status:**final

### B. INDLÆGSSEDDEL

 

unavailable


#### Indlægsseddel: Information til brugeren

 

B. INDLÆGSSEDDEL

Indlægsseddel: Information til brugeren Karvea 75 mg tabletter irbesartan

Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger. - Gem indlægssedlen. Du kan få brug for at læse den igen. - Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide. - Lægen har ordineret Karvea til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har. - Kontakt lægen eller apotekspersonalet, hvis en bivirkning bliver værre, eller du får bivirkninger, som ikke er nævnt her. Se punkt 4.
Se den nyeste indlægsseddel på www.indlaegsseddel.dk.


#### Oversigt over indlægssedlen

 

Oversigt over indlægssedlen: 1. Virkning og anvendelse 2. Det skal du vide, før du begynder at tage Karvea 3. Sådan skal du tage Karvea 4. Bivirkninger 5. Opbevaring 6. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

Karvea tilhører en medicingruppe, der kaldes angiotensin-II receptorantagonister. Angiotensin-II er et stof, der produceres i kroppen, og som binder sig til receptorer i blodårerne og får dem til at trække sig sammen. Dette medfører, at blodtrykket øges. Karvea forebygger at angiotensin-II binder sig til disse receptorer. Derved afslappes blodårerne, og blodtrykket falder. Karvea mindsker faldende nyrefunktion hos patienter med forhøjet blodtryk og type 2 diabetes (sukkersyge).

Karvea anvendes til voksne patienter

* til at behandle forhøjet blodtryk (hypertension)
* til at beskytte nyrerne hos patienter med for højt blodtryk, type 2 diabetes og blodprøver, der viser nedsat nyrefunktion.


#### 2. Det skal du vide, før du begynder at tage Karvea

 

Tag ikke Karvea:

* hvis du er overfølsom (allergisk) over for irbesartan eller et af de øvrige indholdsstoffer i Karvea (angivet i punkt 6).
* hvis du er længere end 3 måneder henne i din graviditet. (Det er også bedre at lade være med at tage Karvea i begyndelsen af graviditeten – se afsnittet om graviditet)
* hvis du har diabetes eller nedsat nyrefunktion, og du bliver behandlet med et lægemiddel, der sænker blodtrykket, som indeholder aliskiren

Advarsler og forsigtighedsregler Kontakt lægen, før du tager Karvea, hvis noget af det følgende gælder for dig:

* hvis du får hyppig opkastning eller diarré
* hvis du lider af nyreproblemer
* hvis du lider af hjerteproblemer
* hvis du får Karvea for diabetisk nyresygdom. I dette tilfælde kan lægen tage regelmæssige blodprøver med særlig henblik på at måle kaliumniveauet i blodet, hvis nyrefunktionen er nedsat
* hvis du udvikler lavt blodsukkerniveau (symptomerne kan inkludere svedtendens, svaghed, sult, svimmelhed, skælven, hovedpine, rødmen eller bleghed, følelsesløshed, hurtige og hamrende hjerteslag), især hvis du er i behandling for diabetes
* hvis du skal opereres eller bedøves
* hvis du tager en af følgende lægemidler, der anvendes til at behandle forhøjet blodtryk: * en ACE-hæmmer (f.eks. enalapril, lisinopril, remipril) især hvis du har nyreproblemer, der skyldes diabetes. * Aliskiren.

Din læge vil måske regelmæssigt kontrollere din nyrefunktion, dit blodtryk og mængden af elektrolytter (f.eks. kalium) i dit blod.

Se også information under ”Tag ikke Karvea”.

Du skal fortælle det til din læge, hvis du tror du er gravid eller planlægger at blive gravid. Karvea bør ikke bruges tidligt i graviditeten og du må ikke tage Karvea, hvis du er længere end 3 måneder henne i din graviditet, da det kan skade dit barn alvorligt, hvis det bruges i den periode (se afsnittet om graviditet).

Børn og unge
Dette lægemiddel bør ikke anvendes til børn og unge, da sikkerhed og virkning ikke er blevet fuldstændig klarlagt.

Brug af anden medicin sammen med Karvea Fortæl det altid til lægen eller apotekspersonalet, hvis du tager anden medicin eller har gjort det for nylig.

Din læge kan blive nødt til at ændre din dosis og/eller tage andre forholdsregler: Hvis du tager en ACE-hæmmer eller aliskiren (se også information under ”Tag ikke Karvea” og ”Advarsler og forsigtighedsregler”).

Det kan være nødvendigt at tage blodprøver, hvis du tager:

* kaliumtilskud
* salterstatninger, der indeholder kalium
* kaliumsparende medicin (som visse vanddrivende lægemidler)
* medicin, der indeholder lithium
* repaglinid (medicin, der anvendes til at sænke blodsukkerniveauet).

Hvis du tager en bestemt slags smertestillende medicin, der kaldes non-steroide anti-inflammatoriske lægemidler, kan virkningen af irbesartan nedsættes.

Brug af Karvea sammen med mad og drikke Karvea kan tages med og uden mad.

Graviditet og amning Graviditet Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge til råds, før du tager Karvea.
Din læge vil normalt anbefale, at du stopper med at tage Karvea, inden du bliver gravid, eller så snart du ved, at du er gravid, og anbefale, at du tager anden medicin i stedet for Karvea. Karvea frarådes tidligt i graviditeten, og du må ikke tage det, hvis du er længere end 3 måneder henne i graviditeten, da det kan skade dit barn alvorligt, hvis du tager det efter tredje måned af graviditeten.

Amning Fortæl det til lægen, hvis du ammer eller skal til at amme. Karvea anbefales ikke til ammende mødre, og lægen vil sædvanligvis vælge en anden behandling til dig, hvis du ønsker at amme dit barn, især hvis dit barn er nyfødt eller født for tidligt.

Trafik- og arbejdssikkerhed Karvea påvirker sandsynligvis ikke din evne til at køre bil eller betjene maskiner.Men man kan opleve svimmelhed eller træthed, når man behandles for forhøjet blodtryk. Hvis du bliver svimmel eller træt, skal du kontakte lægen, inden du kører bil eller betjener maskiner.

Karvea indeholder lactose Kontakt lægen, før du tager dette lægemiddel, hvis lægen har fortalt dig, at du ikke tåler visse sukkerarter.

Karvea indeholder natrium Dette lægemiddel indeholder mindre end 1 mmol (23 mg) natrium pr. tablet, dvs. det er i det væsentlige natriumfrit.


#### 3. Sådan skal du tage Karvea

 

Tag altid Karvea nøjagtigt efter lægen anvisning. Er du i tvivl, så spørg lægen eller på apoteket.

Sådan tages tabletterne Karvea skal tages gennem munden. Tabletterne skal synkes med en tilstrækkelig mængde væske (for eksempel 1 glas vand). Du kan tage Karvea med eller uden mad. Prøv at tage medicinen på ca. samme tidspunkt hver dag. Det er vigtigt, at du fortsætter med at tage Karvea, indtil lægen siger du kan stoppe.

* Patienter med højt blodtryk Den sædvanlige dosis er 150 mg 1 gang dagligt (to tabletter dagligt). Dosis kan senere øges til 300 mg 1 gang dagligt (fire tabletter dagligt) afhængig af blodtryksmålingerne.
* Patienter med højt blodtryk og type 2 diabetes med nyresygom Hos patienter med højt blodtryk og type 2 diabetes er 300 mg 1 gang dagligt (fire tabletter dagligt) den foretrukne vedligeholdelsesdosis til behandling af ledsagende nyresygdom.

Lægen kan anbefale en lavere dosis, specielt til patienter, som bliver behandlet med hæmodialyse eller til ældre patienter over 75 år.

Den maksimale blodtryksnedsættende virkning skal være nået 4-6 uger efter behandlingsstart.

Børn og unge må ikke få Karvea
Karvea må ikke gives til børn under 18 år. Hvis et barn sluger en eller flere tabletter, skal du straks kontakte lægen.

Hvis du har taget for mange Karvea Hvis du ved et uheld har taget for mange tabletter, skal du omgående kontakte lægen.

Hvis du har glemt at tage Karvea Hvis du har glemt at tage en dosis, skal du blot tage den næste til sædvanlig tid. Tag ikke dobbeltdosis som erstatning for den glemte dosis.

Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.


#### 4. Bivirkninger

 

Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger. Nogle af disse bivirkninger kan være alvorlige og kan kræve medicinsk behandling.

Som ved anden medicin af samme type, er der hos patienter, der har modtaget behandling med irbesartan, rapporteret sjældne tilfælde af allergiske hudreaktioner (udslæt, nældefeber) samt opsvulmet ansigt, læber og/eller tunge. Hvis du får et eller flere af disse symptomer eller får åndenød, skal du holde op med at tage Karvea og straks søge lægehjælp.

Hyppigheden af nedenstående bivirkninger er angivet på følgende måde: Meget almindelig: kan påvirke flere end 1 ud af 10 patienter
Almindelig: kan påvirke op til 1 ud af 10 patienter Ikke almindelig: kan påvirke op til 1 ud af 100 patienter

Følgende bivirkninger blev indberettet i kliniske forsøg med patienter, der fik Karvea:

* Meget almindelig (kan påvirke flere end 1 ud af 10 patienter): hvis du har højt blodtryk og type 2 diabetes med nyresygdom, kan blodprøver vise, at du har for meget kalium i blodet.
* Almindelig (kan påvirke op til 1 ud af 10 patienter): svimmelhed, kvalme/opkastning, træthed og blodprøver, der viser en forhøjet mængde af et enzym, der måler muskel- og hjertefunktionen (kreatinin-kinase-enzym).Der er hos patienter med forhøjet blodtryk og type 2 diabetes med nyresygdom også indberettet svimmelhed, når man rejser sig op fra liggende eller siddende stilling, lavt blodtryk når man rejser sig op fra liggende eller siddende stilling, led- og muskelsmerter og en nedsat mængde protein i de røde blodlegemer (hæmoglobin).
* Ikke almindelig (kan påvirke op til 1 ud af 100 patienter): hurtig hjerterytme, rødme, hoste, diarré, fordøjelsesbesvær/halsbrand, seksuelle problemer, brystsmerter.

Der er indberettet bivirkninger efter markedsføring af Karvea. Bivirkninger, hvor hyppigheden ikke er kendt, er: følelse af, at omgivelserne kører rundt, hovedpine, smagsforstyrrelser, ringen for ørerne, muskelkramper, led- og muskelsmerter, nedsat antal røde blodlegemer (blodmangel – symptomerne kan inkludere træthed, hovedpine, stakåndethed under motion, svimmelhed og bleghed), nedsat antal blodplader, unormal leverfunktion, forhøjet mængde af kalium i blodet, nedsat nyrefunktion, betændelseslignende tilstand i de små blodkar, der primært påvirker huden (en tilstand der kaldes leukocytoklastisk vaskulitis), alvorlige allergiske reaktioner (anafylaktisk shock) samt lavt blodsukkerniveau. Der er i sjældne tilfælde også indberettet gulsot (gulfarvning af huden og/eller det hvide i øjnene).

Indberetning af bivirkninger Hvis du oplever bivirkninger, bør du tale med din læge, sygeplejerske eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via det nationale rapporteringssystem anført i Appendiks V. Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.


#### 5. Opbevaring

 

Opbevar lægemidlet utilgængeligt for børn.

Brug ikke lægemidlet efter den udløbsdato, der står på æsken og blisterpakningen efter Exp. Udløbsdatoen er den sidste dag i den nævnte måned.

Må ikke opbevares ved temperaturer over 30°C.

Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

Karvea indeholder:

* Aktivt stof: irbesartan. Hver Karvea-tablet 75 mg indeholder 75 mg irbesartan.
* Øvrige indholdsstoffer: lactosemonohydrat, mikrokrystallinsk cellulose, croscarmellosenatrium, magnesiumstearat, kolloid silica, prægelatineret majsstivelse, poloaxamer 188.
Se punkt 2 ”Aprovel indeholder lactose”

Udseende og pakningstørrelser Karvea 75 mg tabletter er hvide til mathvide, bikonvekse og ovale med et hjerte præget på den ene side og nummeret 2771 på den anden side.

Karvea 75 mg tabletter leveres i blisterpakninger af 14, 28, 56 eller 98 tabletter. Der fås også enkeltdosisblisterpakninger med 56 x 1 tablet til hospitalsbrug.

Ikke alle pakningsstørrelser er nødvendigvis markedsført.

Indehaveren af markedsføringstilladelsen: Sanofi Winthrop Industrie 82 avenue Raspail 94250 Gentilly Frankrig

Fremstiller: SANOFI WINTHROP INDUSTRIE 1, rue de la Vierge Ambarès & Lagrave F-33565 Carbon Blanc Cedex - Frankrig

SANOFI WINTHROP INDUSTRIE 30-36 Avenue Gustave Eiffel, BP 7F-37071 Tours Cedex 2 - Frankrig

Hvis du vil have yderligere oplysninger om Karvea, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:

België/Belgique/Belgien Sanofi Belgium Tél/Tel: +32 (0)2 710 54
Lietuva Swixx Biopharma UAB Tel: +370 5 236 91
България Swixx Biopharma EOOD Тел.: +359 (0)2 4942
Luxembourg/Luxemburg Sanofi Belgium
Tél/Tel: +32 (0)2 710 54 00 (Belgique/Belgien)

Česká republika sanofi-aventis, s.r.o. Tel: +420 233 086
Magyarország SANOFI-AVENTIS Zrt. Tel.: +36 1 505 0 Danmark Sanofi A/S Tlf: +45 45 16 70
Malta Sanofi S.r.l. Tel: +39 02 39394

Deutschland Sanofi-Aventis Deutschland GmbH Tel: 0800 52 52 Tel. aus dem Ausland: +49 69 305 21
Nederland Sanofi B.V. Tel: +31 20 245 4 Eesti Swixx Biopharma OÜ Tel: +372 640 10
Norge sanofi-aventis Norge AS Tlf: +47 67 10 71
Ελλάδα Sanofi-Aventis Μονοπρόσωπη AEBE Τηλ: +30 210 900 16
Österreich sanofi-aventis GmbH Tel: +43 1 80 185 – 0

España sanofi-aventis, S.A. Tel: +34 93 485 94
Polska sanofi-aventis Sp. z o.o. Tel.: +48 22 280 00
France Sanofi Winthrop Industrie Tél:
0 800 222 Appel depuis l’étranger : +33 1 57 63 23
Portugal Sanofi - Produtos Farmacêuticos, Lda Tel: +351 21 35 89
Hrvatska Swixx Biopharma d.o.o. Tel: +385 1 2078 România Sanofi Romania SRL Tel: +40 (0) 21 317 31
Ireland sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +353 (0) 1 403 56
Slovenija Swixx Biopharma d.o.o. Tel: +386 1 235 51
Ísland Vistor hf. Sími: +354 535 7 Slovenská republika Swixx Biopharma s.r.o. Tel: +421 2 208 33
Italia Sanofi S.r.l. Tel: 800.536 Suomi/Finland Sanofi Oy Puh/Tel: +358 (0) 201 200
Κύπρος C.A. Papaellinas Ltd. Τηλ: +357 22 741 Sverige Sanofi AB Tel: +46 (0)8 634 50
Latvija Swixx Biopharma SIA Tel: +371 6 616 47
United Kingdom (Northern Ireland) sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +44 (0) 800 035 2 Denne indlægsseddel blev senest ændret

Du kan finde yderligere information om Karvea på Det Europæiske Lægemiddelagenturs hjemmeside


####  Karvea 75 mg tablet 
PMSWI:
** EU/1/97/049/001 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E82719 **
-------

Full name: **Karvea 75 mg tablet**

 - Invented name part: ** Karvea ** 

 - Scientific name part: ** irbesartan ** 

 - Strength part: ** 75 mg ** 

 - Pharmaceutical dose form part: ** tablet ** 

 Name usage: **English (Denmark)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 Package 1 of 4

PMSWI: ** EU/1/97/049/010 ** 

 Description:  * * 

 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **28 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 2 of 4

PMSWI: ** EU/1/97/049/001 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **56 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 3 of 4

PMSWI: ** EU/1/97/049/002 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **98 Blister** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 

 Package 4 of 4

PMSWI: ** EU/1/97/049/003 ** 

Description:
 Marketing status: 
 

Pack size:

*  ****75 

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Excipient ** 

 Substance: ** Hypromellose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Macrogol 3000 ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Lactose Monohydrate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Silicon dioxide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Titanium Dioxide ** 

Ingredient

 Role: ** active ** 

 Substance: ** irbesartan ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Carnauba wax ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-da-dcaa4d32aa6658a8df831551503e52ee",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/97/049/001"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-da-873a1a47330e628770640f9c96c0761e",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-da-873a1a47330e628770640f9c96c0761e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_composition-da-873a1a47330e628770640f9c96c0761e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-da-873a1a47330e628770640f9c96c0761e</b></p><a name=\"composition-da-873a1a47330e628770640f9c96c0761e\"> </a><a name=\"hccomposition-da-873a1a47330e628770640f9c96c0761e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/EU/1/97/049/001</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p><p><b>title</b>: TEST PURPOSES ONLY - Karvea 75 mg tablet</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "EU/1/97/049/001"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }],
      "title" : "TEST PURPOSES ONLY - Karvea 75 mg tablet",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. INDLÆGSSEDDEL",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. INDLÆGSSEDDEL"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">unavailable</div>"
        },
        "emptyReason" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
            "code" : "unavailable"
          }]
        },
        "section" : [{
          "title" : "Indlægsseddel: Information til brugeren",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Indlægsseddel: Information til brugeren"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>B. INDLÆGSSEDDEL</p><p>Indlægsseddel: Information til brugeren Karvea 75 mg tabletter irbesartan</p><p>Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger. - Gem indlægssedlen. Du kan få brug for at læse den igen. - Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide. - Lægen har ordineret Karvea til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har. - Kontakt lægen eller apotekspersonalet, hvis en bivirkning bliver værre, eller du får bivirkninger, som ikke er nævnt her. Se punkt 4.<br/>Se den nyeste indlægsseddel på www.indlaegsseddel.dk.</p></div>"
          }
        },
        {
          "title" : "Oversigt over indlægssedlen",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Oversigt over indlægssedlen"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Oversigt over indlægssedlen: 1. Virkning og anvendelse 2. Det skal du vide, før du begynder at tage Karvea 3. Sådan skal du tage Karvea 4. Bivirkninger 5. Opbevaring 6. Pakningsstørrelser og yderligere oplysninger</p></div>"
          }
        },
        {
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. Virkning og anvendelse"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Karvea tilhører en medicingruppe, der kaldes angiotensin-II receptorantagonister. Angiotensin-II er et stof, der produceres i kroppen, og som binder sig til receptorer i blodårerne og får dem til at trække sig sammen. Dette medfører, at blodtrykket øges. Karvea forebygger at angiotensin-II binder sig til disse receptorer. Derved afslappes blodårerne, og blodtrykket falder. Karvea mindsker faldende nyrefunktion hos patienter med forhøjet blodtryk og type 2 diabetes (sukkersyge).</p><p>Karvea anvendes til voksne patienter</p><ul><li><p>til at behandle forhøjet blodtryk (hypertension)</p></li><li><p>til at beskytte nyrerne hos patienter med for højt blodtryk, type 2 diabetes og blodprøver, der viser nedsat nyrefunktion.</p></li></ul></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du begynder at tage  Karvea",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. Det skal du vide, før du begynder at tage  Karvea"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Tag ikke Karvea:</p><ul><li><p>hvis du er overfølsom (allergisk) over for irbesartan eller et af de øvrige indholdsstoffer i Karvea (angivet i punkt 6).</p></li><li><p>hvis du er længere end 3 måneder henne i din graviditet. (Det er også bedre at lade være med at tage Karvea i begyndelsen af graviditeten – se afsnittet om graviditet)</p></li><li><p>hvis du har diabetes eller nedsat nyrefunktion, og du bliver behandlet med et lægemiddel, der sænker blodtrykket, som indeholder aliskiren</p></li></ul><p>Advarsler og forsigtighedsregler Kontakt lægen, før du tager Karvea, hvis noget af det følgende gælder for dig:</p><ul><li><p>hvis du får hyppig opkastning eller diarré</p></li><li><p>hvis du lider af nyreproblemer</p></li><li><p>hvis du lider af hjerteproblemer</p></li><li><p>hvis du får Karvea for diabetisk nyresygdom. I dette tilfælde kan lægen tage regelmæssige blodprøver med særlig henblik på at måle kaliumniveauet i blodet, hvis nyrefunktionen er nedsat</p></li><li><p>hvis du udvikler lavt blodsukkerniveau (symptomerne kan inkludere svedtendens, svaghed, sult, svimmelhed, skælven, hovedpine, rødmen eller bleghed, følelsesløshed, hurtige og hamrende hjerteslag), især hvis du er i behandling for diabetes</p></li><li><p>hvis du skal opereres eller bedøves</p></li><li><p>hvis du tager en af følgende lægemidler, der anvendes til at behandle forhøjet blodtryk: * en ACE-hæmmer (f.eks. enalapril, lisinopril, remipril) især hvis du har nyreproblemer, der skyldes diabetes. * Aliskiren.</p></li></ul><p>Din læge vil måske regelmæssigt kontrollere din nyrefunktion, dit blodtryk og mængden af elektrolytter (f.eks. kalium) i dit blod.</p><p>Se også information under ”Tag ikke Karvea”.</p><p>Du skal fortælle det til din læge, hvis du tror du er gravid eller planlægger at blive gravid. Karvea bør ikke bruges tidligt i graviditeten og du må ikke tage Karvea, hvis du er længere end 3 måneder henne i din graviditet, da det kan skade dit barn alvorligt, hvis det bruges i den periode (se afsnittet om graviditet).</p><p>Børn og unge<br/>Dette lægemiddel bør ikke anvendes til børn og unge, da sikkerhed og virkning ikke er blevet fuldstændig klarlagt.</p><p>Brug af anden medicin sammen med Karvea Fortæl det altid til lægen eller apotekspersonalet, hvis du tager anden medicin eller har gjort det for nylig.</p><p>Din læge kan blive nødt til at ændre din dosis og/eller tage andre forholdsregler: Hvis du tager en ACE-hæmmer eller aliskiren (se også information under ”Tag ikke Karvea” og ”Advarsler og forsigtighedsregler”).</p><p>Det kan være nødvendigt at tage blodprøver, hvis du tager:</p><ul><li><p>kaliumtilskud</p></li><li><p>salterstatninger, der indeholder kalium</p></li><li><p>kaliumsparende medicin (som visse vanddrivende lægemidler)</p></li><li><p>medicin, der indeholder lithium</p></li><li><p>repaglinid (medicin, der anvendes til at sænke blodsukkerniveauet).</p></li></ul><p>Hvis du tager en bestemt slags smertestillende medicin, der kaldes non-steroide anti-inflammatoriske lægemidler, kan virkningen af irbesartan nedsættes.</p><p>Brug af Karvea sammen med mad og drikke Karvea kan tages med og uden mad.</p><p>Graviditet og amning Graviditet Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge til råds, før du tager Karvea.<br/>Din læge vil normalt anbefale, at du stopper med at tage Karvea, inden du bliver gravid, eller så snart du ved, at du er gravid, og anbefale, at du tager anden medicin i stedet for Karvea. Karvea frarådes tidligt i graviditeten, og du må ikke tage det, hvis du er længere end 3 måneder henne i graviditeten, da det kan skade dit barn alvorligt, hvis du tager det efter tredje måned af graviditeten.</p><p>Amning Fortæl det til lægen, hvis du ammer eller skal til at amme. Karvea anbefales ikke til ammende mødre, og lægen vil sædvanligvis vælge en anden behandling til dig, hvis du ønsker at amme dit barn, især hvis dit barn er nyfødt eller født for tidligt.</p><p>Trafik- og arbejdssikkerhed Karvea påvirker sandsynligvis ikke din evne til at køre bil eller betjene maskiner.Men man kan opleve svimmelhed eller træthed, når man behandles for forhøjet blodtryk. Hvis du bliver svimmel eller træt, skal du kontakte lægen, inden du kører bil eller betjener maskiner.</p><p>Karvea indeholder lactose Kontakt lægen, før du tager dette lægemiddel, hvis lægen har fortalt dig, at du ikke tåler visse sukkerarter.</p><p>Karvea indeholder natrium Dette lægemiddel indeholder mindre end 1 mmol (23 mg) natrium pr. tablet, dvs. det er i det væsentlige natriumfrit.</p></div>"
          }
        },
        {
          "title" : "3. Sådan skal du tage Karvea",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. Sådan skal du tage Karvea"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Tag altid Karvea nøjagtigt efter lægen anvisning. Er du i tvivl, så spørg lægen eller på apoteket.</p><p>Sådan tages tabletterne Karvea skal tages gennem munden. Tabletterne skal synkes med en tilstrækkelig mængde væske (for eksempel 1 glas vand). Du kan tage Karvea med eller uden mad. Prøv at tage medicinen på ca. samme tidspunkt hver dag. Det er vigtigt, at du fortsætter med at tage Karvea, indtil lægen siger du kan stoppe.</p><ul><li><p>Patienter med højt blodtryk Den sædvanlige dosis er 150 mg 1 gang dagligt (to tabletter dagligt). Dosis kan senere øges til 300 mg 1 gang dagligt (fire tabletter dagligt) afhængig af blodtryksmålingerne.</p></li><li><p>Patienter med højt blodtryk og type 2 diabetes med nyresygom Hos patienter med højt blodtryk og type 2 diabetes er 300 mg 1 gang dagligt (fire tabletter dagligt) den foretrukne vedligeholdelsesdosis til behandling af ledsagende nyresygdom.</p></li></ul><p>Lægen kan anbefale en lavere dosis, specielt til patienter, som bliver behandlet med hæmodialyse eller til ældre patienter over 75 år.</p><p>Den maksimale blodtryksnedsættende virkning skal være nået 4-6 uger efter behandlingsstart.</p><p>Børn og unge må ikke få Karvea<br/>Karvea må ikke gives til børn under 18 år. Hvis et barn sluger en eller flere tabletter, skal du straks kontakte lægen.</p><p>Hvis du har taget for mange Karvea Hvis du ved et uheld har taget for mange tabletter, skal du omgående kontakte lægen.</p><p>Hvis du har glemt at tage Karvea Hvis du har glemt at tage en dosis, skal du blot tage den næste til sædvanlig tid. Tag ikke dobbeltdosis som erstatning for den glemte dosis.</p><p>Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.</p></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Bivirkninger"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Dette lægemiddel kan som al anden medicin give bivirkninger, men ikke alle får bivirkninger. Nogle af disse bivirkninger kan være alvorlige og kan kræve medicinsk behandling.</p><p>Som ved anden medicin af samme type, er der hos patienter, der har modtaget behandling med irbesartan, rapporteret sjældne tilfælde af allergiske hudreaktioner (udslæt, nældefeber) samt opsvulmet ansigt, læber og/eller tunge. Hvis du får et eller flere af disse symptomer eller får åndenød, skal du holde op med at tage Karvea og straks søge lægehjælp.</p><p>Hyppigheden af nedenstående bivirkninger er angivet på følgende måde: Meget almindelig: kan påvirke flere end 1 ud af 10 patienter<br/>Almindelig: kan påvirke op til 1 ud af 10 patienter Ikke almindelig: kan påvirke op til 1 ud af 100 patienter</p><p>Følgende bivirkninger blev indberettet i kliniske forsøg med patienter, der fik Karvea:</p><ul><li><p>Meget almindelig (kan påvirke flere end 1 ud af 10 patienter): hvis du har højt blodtryk og type 2 diabetes med nyresygdom, kan blodprøver vise, at du har for meget kalium i blodet.</p></li><li><p>Almindelig (kan påvirke op til 1 ud af 10 patienter): svimmelhed, kvalme/opkastning, træthed og blodprøver, der viser en forhøjet mængde af et enzym, der måler muskel- og hjertefunktionen (kreatinin-kinase-enzym).Der er hos patienter med forhøjet blodtryk og type 2 diabetes med nyresygdom også indberettet svimmelhed, når man rejser sig op fra liggende eller siddende stilling, lavt blodtryk når man rejser sig op fra liggende eller siddende stilling, led- og muskelsmerter og en nedsat mængde protein i de røde blodlegemer (hæmoglobin).</p></li><li><p>Ikke almindelig (kan påvirke op til 1 ud af 100 patienter): hurtig hjerterytme, rødme, hoste, diarré, fordøjelsesbesvær/halsbrand, seksuelle problemer, brystsmerter.</p></li></ul><p>Der er indberettet bivirkninger efter markedsføring af Karvea. Bivirkninger, hvor hyppigheden ikke er kendt, er: følelse af, at omgivelserne kører rundt, hovedpine, smagsforstyrrelser, ringen for ørerne, muskelkramper, led- og muskelsmerter, nedsat antal røde blodlegemer (blodmangel – symptomerne kan inkludere træthed, hovedpine, stakåndethed under motion, svimmelhed og bleghed), nedsat antal blodplader, unormal leverfunktion, forhøjet mængde af kalium i blodet, nedsat nyrefunktion, betændelseslignende tilstand i de små blodkar, der primært påvirker huden (en tilstand der kaldes leukocytoklastisk vaskulitis), alvorlige allergiske reaktioner (anafylaktisk shock) samt lavt blodsukkerniveau. Der er i sjældne tilfælde også indberettet gulsot (gulfarvning af huden og/eller det hvide i øjnene).</p><p>Indberetning af bivirkninger Hvis du oplever bivirkninger, bør du tale med din læge, sygeplejerske eller apoteket. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via det nationale rapporteringssystem anført i Appendiks V. Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</p></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. Opbevaring"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Opbevar lægemidlet utilgængeligt for børn.</p><p>Brug ikke lægemidlet efter den udløbsdato, der står på æsken og blisterpakningen efter Exp. Udløbsdatoen er den sidste dag i den nævnte måned.</p><p>Må ikke opbevares ved temperaturer over 30°C.</p><p>Spørg på apoteket, hvordan du skal bortskaffe medicinrester. Af hensyn til miljøet må du ikke smide medicinrester i afløbet, toilettet eller skraldespanden.</p></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Pakningsstørrelser og yderligere oplysninger"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Karvea indeholder:</p><ul><li><p>Aktivt stof: irbesartan. Hver Karvea-tablet 75 mg indeholder 75 mg irbesartan.</p></li><li><p>Øvrige indholdsstoffer: lactosemonohydrat, mikrokrystallinsk cellulose, croscarmellosenatrium, magnesiumstearat, kolloid silica, prægelatineret majsstivelse, poloaxamer 188.<br/>Se punkt 2 ”Aprovel indeholder lactose”</p></li></ul><p>Udseende og pakningstørrelser Karvea 75 mg tabletter er hvide til mathvide, bikonvekse og ovale med et hjerte præget på den ene side og nummeret 2771 på den anden side.</p><p>Karvea 75 mg tabletter leveres i blisterpakninger af 14, 28, 56 eller 98 tabletter. Der fås også enkeltdosisblisterpakninger med 56 x 1 tablet til hospitalsbrug.</p><p>Ikke alle pakningsstørrelser er nødvendigvis markedsført.</p><p>Indehaveren af markedsføringstilladelsen: Sanofi Winthrop Industrie 82 avenue Raspail 94250 Gentilly Frankrig</p><p>Fremstiller: SANOFI WINTHROP INDUSTRIE 1, rue de la Vierge Ambarès &amp; Lagrave F-33565 Carbon Blanc Cedex - Frankrig</p><p>SANOFI WINTHROP INDUSTRIE 30-36 Avenue Gustave Eiffel, BP 7F-37071 Tours Cedex 2 - Frankrig</p><p>Hvis du vil have yderligere oplysninger om Karvea, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:</p><p>België/Belgique/Belgien Sanofi Belgium Tél/Tel: +32 (0)2 710 54<br/>Lietuva Swixx Biopharma UAB Tel: +370 5 236 91<br/>България Swixx Biopharma EOOD Тел.: +359 (0)2 4942<br/>Luxembourg/Luxemburg Sanofi Belgium<br/>Tél/Tel: +32 (0)2 710 54 00 (Belgique/Belgien)</p><p>Česká republika sanofi-aventis, s.r.o. Tel: +420 233 086<br/>Magyarország SANOFI-AVENTIS Zrt. Tel.: +36 1 505 0 Danmark Sanofi A/S Tlf: +45 45 16 70<br/>Malta Sanofi S.r.l. Tel: +39 02 39394</p><p>Deutschland Sanofi-Aventis Deutschland GmbH Tel: 0800 52 52 Tel. aus dem Ausland: +49 69 305 21<br/>Nederland Sanofi B.V. Tel: +31 20 245 4 Eesti Swixx Biopharma OÜ Tel: +372 640 10<br/>Norge sanofi-aventis Norge AS Tlf: +47 67 10 71<br/>Ελλάδα Sanofi-Aventis Μονοπρόσωπη AEBE Τηλ: +30 210 900 16<br/>Österreich sanofi-aventis GmbH Tel: +43 1 80 185 – 0</p><p>España sanofi-aventis, S.A. Tel: +34 93 485 94<br/>Polska sanofi-aventis Sp. z o.o. Tel.: +48 22 280 00<br/>France Sanofi Winthrop Industrie Tél:<br/>0 800 222 Appel depuis l’étranger : +33 1 57 63 23<br/>Portugal Sanofi - Produtos Farmacêuticos, Lda Tel: +351 21 35 89<br/>Hrvatska Swixx Biopharma d.o.o. Tel: +385 1 2078 România Sanofi Romania SRL Tel: +40 (0) 21 317 31<br/>Ireland sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +353 (0) 1 403 56<br/>Slovenija Swixx Biopharma d.o.o. Tel: +386 1 235 51<br/>Ísland Vistor hf. Sími: +354 535 7 Slovenská republika Swixx Biopharma s.r.o. Tel: +421 2 208 33<br/>Italia Sanofi S.r.l. Tel: 800.536 Suomi/Finland Sanofi Oy Puh/Tel: +358 (0) 201 200<br/>Κύπρος C.A. Papaellinas Ltd. Τηλ: +357 22 741 Sverige Sanofi AB Tel: +46 (0)8 634 50<br/>Latvija Swixx Biopharma SIA Tel: +371 6 616 47<br/>United Kingdom (Northern Ireland) sanofi-aventis Ireland Ltd. T/A SANOFI Tel: +44 (0) 800 035 2 Denne indlægsseddel blev senest ændret</p><p>Du kan finde yderligere information om Karvea på Det Europæiske Lægemiddelagenturs hjemmeside</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-a40c2367ed3c1c715eacd432105752a0",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-a40c2367ed3c1c715eacd432105752a0",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-a40c2367ed3c1c715eacd432105752a0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-a40c2367ed3c1c715eacd432105752a0</b></p><a name=\"cud-a40c2367ed3c1c715eacd432105752a0\"> </a><a name=\"hccud-a40c2367ed3c1c715eacd432105752a0\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr 10012601}\">Diabetis Mellitus</span></td></tr></table></blockquote></div>"
      },
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "10012601",
              "display" : "Diabetis Mellitus"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-585e364c14debe29f6c6b564138aa400",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-585e364c14debe29f6c6b564138aa400",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-indication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-585e364c14debe29f6c6b564138aa400\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-585e364c14debe29f6c6b564138aa400</b></p><a name=\"cud-585e364c14debe29f6c6b564138aa400\"> </a><a name=\"hccud-585e364c14debe29f6c6b564138aa400\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-indication-uv-epi.html\">ClinicalUseDefinition Indication (ePI)</a></p></div><p><b>type</b>: Indication</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>indication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr 10020772}\">Hypertension</span></td></tr></table></blockquote></div>"
      },
      "type" : "indication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "indication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "10020772",
              "display" : "Hypertension"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-4fce9d5258f70f7d605059f97c24efa8",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-4fce9d5258f70f7d605059f97c24efa8",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-interaction-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-4fce9d5258f70f7d605059f97c24efa8\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-4fce9d5258f70f7d605059f97c24efa8</b></p><a name=\"cud-4fce9d5258f70f7d605059f97c24efa8\"> </a><a name=\"hccud-4fce9d5258f70f7d605059f97c24efa8\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-interaction-uv-epi.html\">ClinicalUseDefinition Interaction (ePI)</a></p></div><p><b>type</b>: Interaction</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>interaction</b></p><h3>Interactants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ YL5FZ2Y5U1}\">METHOTREXATE</span></td></tr></table></blockquote></div>"
      },
      "type" : "interaction",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "interaction" : {
        "interactant" : [{
          "itemCodeableConcept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
              "code" : "YL5FZ2Y5U1",
              "display" : "METHOTREXATE"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-hypromellose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-hypromellose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-hypromellose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-hypromellose</b></p><a name=\"ingredient-for-karvea-hypromellose\"> </a><a name=\"hcingredient-for-karvea-hypromellose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/3NXW29V3WO (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 3NXW29V3WO}\">Hypromellose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "3NXW29V3WO"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "3NXW29V3WO",
              "display" : "Hypromellose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-macrogol3000",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-macrogol3000",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-macrogol3000\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-macrogol3000</b></p><a name=\"ingredient-for-karvea-macrogol3000\"> </a><a name=\"hcingredient-for-karvea-macrogol3000\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/SA1B764746 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta SA1B764746}\">Macrogol 3000</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "SA1B764746"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "SA1B764746",
              "display" : "Macrogol 3000"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-lactosemonohydrate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-lactosemonohydrate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-lactosemonohydrate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-lactosemonohydrate</b></p><a name=\"ingredient-for-karvea-lactosemonohydrate\"> </a><a name=\"hcingredient-for-karvea-lactosemonohydrate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EWQ57Q8I5X (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EWQ57Q8I5X}\">Lactose Monohydrate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EWQ57Q8I5X"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EWQ57Q8I5X",
              "display" : "Lactose Monohydrate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-silicondioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-silicondioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-silicondioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-silicondioxide</b></p><a name=\"ingredient-for-karvea-silicondioxide\"> </a><a name=\"hcingredient-for-karvea-silicondioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/ETJ7Z6XBU4 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta ETJ7Z6XBU4}\">Silicon dioxide</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "ETJ7Z6XBU4"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "ETJ7Z6XBU4",
              "display" : "Silicon dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-titaniumdioxide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-titaniumdioxide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-titaniumdioxide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-titaniumdioxide</b></p><a name=\"ingredient-for-karvea-titaniumdioxide\"> </a><a name=\"hcingredient-for-karvea-titaniumdioxide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/15FIX9V2JP (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 15FIX9V2JP}\">Titanium Dioxide</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "15FIX9V2JP"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "15FIX9V2JP",
              "display" : "Titanium Dioxide"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-irbesartan",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-irbesartan",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-irbesartan\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-irbesartan</b></p><a name=\"ingredient-for-karvea-irbesartan\"> </a><a name=\"hcingredient-for-karvea-irbesartan\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/J0E2756Z7N (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta J0E2756Z7N}\">irbesartan</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "J0E2756Z7N"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "J0E2756Z7N",
              "display" : "irbesartan"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 75,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-croscarmellosesodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-croscarmellosesodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-croscarmellosesodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-croscarmellosesodium</b></p><a name=\"ingredient-for-karvea-croscarmellosesodium\"> </a><a name=\"hcingredient-for-karvea-croscarmellosesodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/M28OL1HH48 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta M28OL1HH48}\">Croscarmellose sodium</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "M28OL1HH48"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "M28OL1HH48",
              "display" : "Croscarmellose sodium"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-microcrystallinecellulose</b></p><a name=\"ingredient-for-karvea-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-karvea-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">Microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "Microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-magnesiumstearate</b></p><a name=\"ingredient-for-karvea-magnesiumstearate\"> </a><a name=\"hcingredient-for-karvea-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-karvea-carnaubawax",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-karvea-carnaubawax",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-karvea-carnaubawax\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-karvea-carnaubawax</b></p><a name=\"ingredient-for-karvea-carnaubawax\"> </a><a name=\"hcingredient-for-karvea-carnaubawax\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/R12CBM0EIZ (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-Processedbundlekarvea.html#AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta R12CBM0EIZ}\">Carnauba wax</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "R12CBM0EIZ"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      },
      {
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "R12CBM0EIZ",
              "display" : "Carnauba wax"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/SubstanceDefinition/substance-irbesartan",
    "resource" : {
      "resourceType" : "SubstanceDefinition",
      "id" : "substance-irbesartan",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/SubstanceDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SubstanceDefinition_substance-irbesartan\"> </a><p class=\"res-header-id\"><b>Generated Narrative: SubstanceDefinition substance-irbesartan</b></p><a name=\"substance-irbesartan\"> </a><a name=\"hcsubstance-irbesartan\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-SubstanceDefinition-uv-epi.html\">SubstanceDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta/</code>/J0E2756Z7N (use: official, )</p><p><b>version</b>: 1</p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>description</b>: </p><div><p>White to off-white, biconvex, and oval-shaped with a heart debossed on one side and the number 2771 engraved on the other side.</p>\n</div><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p><h3>MolecularWeights</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Amount</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">exact</span></td><td>428.53</td></tr></table><h3>Structures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>MolecularFormula</b></td></tr><tr><td style=\"display: none\">*</td><td>C25H28N6O</td></tr></table><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>(+)-6-methyleneandrosta-1,4-diene-3,17-dione</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta/ x}\">Chemical Name</span></td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
        "value" : "J0E2756Z7N"
      }],
      "version" : "1",
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active"
        }]
      },
      "description" : "White to off-white, biconvex, and oval-shaped with a heart debossed on one side and the number 2771 engraved on the other side.",
      "manufacturer" : [{
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }],
      "molecularWeight" : [{
        "type" : {
          "text" : "exact"
        },
        "amount" : {
          "value" : 428.53
        }
      }],
      "structure" : {
        "molecularFormula" : "C25H28N6O"
      },
      "name" : [{
        "name" : "(+)-6-methyleneandrosta-1,4-diene-3,17-dione",
        "type" : {
          "coding" : [{
            "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta/",
            "code" : "x",
            "display" : "Chemical Name"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-dcaa4d32aa6658a8df831551503e52ee",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-dcaa4d32aa6658a8df831551503e52ee",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-dcaa4d32aa6658a8df831551503e52ee\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-dcaa4d32aa6658a8df831551503e52ee</b></p><a name=\"ap-dcaa4d32aa6658a8df831551503e52ee\"> </a><a name=\"hcap-dcaa4d32aa6658a8df831551503e52ee\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee0",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee0",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee0</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee0\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/010 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-d91b269b209aaa5538a1bfafd1a7434d\">PackagedProductDefinition Karvea 75 mg tablet 14</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/010"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-d91b269b209aaa5538a1bfafd1a7434d"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee1",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee1",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee1</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee1\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-f3f2f89544dfc5d20216861bcf90c0c5\">PackagedProductDefinition Karvea 75 mg tablet 28</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-f3f2f89544dfc5d20216861bcf90c0c5"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee2",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee2",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee2</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee2\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/002 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-5763619e2b501aeeab53677bd09d5cbf\">PackagedProductDefinition Karvea 75 mg tablet 56</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/002"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-5763619e2b501aeeab53677bd09d5cbf"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorizationdcaa4d32aa6658a8df831551503e52ee3",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorizationdcaa4d32aa6658a8df831551503e52ee3",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorizationdcaa4d32aa6658a8df831551503e52ee3</b></p><a name=\"authorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><a name=\"hcauthorizationdcaa4d32aa6658a8df831551503e52ee3\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/003 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-Processedbundlekarvea.html#PackagedProductDefinition_ppd-9b1d5d261d22694685deb35714ec08ea\">PackagedProductDefinition Karvea 75 mg tablet 98</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_mah-511671db37e83e520b00f8a0d817dc96\">Organization Sanofi Winthrop Industrie\t</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/003"
      }],
      "subject" : [{
        "reference" : "PackagedProductDefinition/ppd-9b1d5d261d22694685deb35714ec08ea"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-511671db37e83e520b00f8a0d817dc96"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-511671db37e83e520b00f8a0d817dc96",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-511671db37e83e520b00f8a0d817dc96",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-511671db37e83e520b00f8a0d817dc96\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-511671db37e83e520b00f8a0d817dc96</b></p><a name=\"mah-511671db37e83e520b00f8a0d817dc96\"> </a><a name=\"hcmah-511671db37e83e520b00f8a0d817dc96\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100011564 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Sanofi Winthrop Industrie\t</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>82 avenue Raspail Gentilly FR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100011564"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Sanofi Winthrop Industrie\t",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "82 avenue Raspail Gentilly FR",
          "line" : ["82 avenue Raspail"],
          "city" : "Gentilly",
          "postalCode" : "94250",
          "country" : "FR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/man-4bb7a752921434fd5f9921b5b9473eda",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "man-4bb7a752921434fd5f9921b5b9473eda",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_man-4bb7a752921434fd5f9921b5b9473eda\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization man-4bb7a752921434fd5f9921b5b9473eda</b></p><a name=\"man-4bb7a752921434fd5f9921b5b9473eda\"> </a><a name=\"hcman-4bb7a752921434fd5f9921b5b9473eda\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100011564 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000033}\">Manufacturer</span></p><p><b>name</b>: Sanofi Winthrop Industrie</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>1, rue de la Vierge Ambarès &amp; Lagrave FR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100011564"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000033",
          "display" : "Manufacturer"
        }]
      }],
      "name" : "Sanofi Winthrop Industrie",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "1, rue de la Vierge Ambarès & Lagrave FR",
          "line" : ["1, rue de la Vierge"],
          "city" : "Ambarès & Lagrave",
          "postalCode" : "33565",
          "country" : "FR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-d91b269b209aaa5538a1bfafd1a7434d",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-d91b269b209aaa5538a1bfafd1a7434d",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-d91b269b209aaa5538a1bfafd1a7434d</b></p><a name=\"ppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><a name=\"hcppd-d91b269b209aaa5538a1bfafd1a7434d\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/010 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 14</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 14</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/010"
      }],
      "name" : "Karvea 75 mg tablet 14",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 14,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-f3f2f89544dfc5d20216861bcf90c0c5",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-f3f2f89544dfc5d20216861bcf90c0c5",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-f3f2f89544dfc5d20216861bcf90c0c5</b></p><a name=\"ppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><a name=\"hcppd-f3f2f89544dfc5d20216861bcf90c0c5\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 28</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 28</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "name" : "Karvea 75 mg tablet 28",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 28,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-5763619e2b501aeeab53677bd09d5cbf",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-5763619e2b501aeeab53677bd09d5cbf",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-5763619e2b501aeeab53677bd09d5cbf</b></p><a name=\"ppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><a name=\"hcppd-5763619e2b501aeeab53677bd09d5cbf\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/002 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 56</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 56</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/002"
      }],
      "name" : "Karvea 75 mg tablet 56",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 56,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-9b1d5d261d22694685deb35714ec08ea",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-9b1d5d261d22694685deb35714ec08ea",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-9b1d5d261d22694685deb35714ec08ea\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-9b1d5d261d22694685deb35714ec08ea</b></p><a name=\"ppd-9b1d5d261d22694685deb35714ec08ea\"> </a><a name=\"hcppd-9b1d5d261d22694685deb35714ec08ea\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/003 (use: official, )</p><p><b>name</b>: Karvea 75 mg tablet 98</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-Processedbundlekarvea.html#MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E82719; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2015-02-07 13:28:17+0000</p><p><b>containedItemQuantity</b>: 75 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/123456</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073496}\">Blister</span></p><p><b>quantity</b>: 98</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-Processedbundlekarvea.html#ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/97/049/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/003"
      }],
      "name" : "Karvea 75 mg tablet 98",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2015-02-07T13:28:17Z",
      "containedItemQuantity" : [{
        "value" : 75,
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }],
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }],
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "123456"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073496",
              "display" : "Blister"
            }]
          },
          "quantity" : 98,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp873a1a47330e628770640f9c96c0761e",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp873a1a47330e628770640f9c96c0761e",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp873a1a47330e628770640f9c96c0761e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp873a1a47330e628770640f9c96c0761e</b></p><a name=\"mp873a1a47330e628770640f9c96c0761e\"> </a><a name=\"hcmp873a1a47330e628770640f9c96c0761e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E82719</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Karvea 75 mg tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Karvea</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: irbesartan</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 75 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: tablet</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 DK}\">Denmark</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 DK}\">Denmark</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E82719"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Karvea 75 mg tablet",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Karvea",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "irbesartan",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "75 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "tablet",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "DK",
              "display" : "Denmark"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "DK",
              "display" : "Denmark"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-dcaa4d32aa6658a8df831551503e52ee",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-dcaa4d32aa6658a8df831551503e52ee",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-dcaa4d32aa6658a8df831551503e52ee\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-dcaa4d32aa6658a8df831551503e52ee</b></p><a name=\"mid-dcaa4d32aa6658a8df831551503e52ee\"> </a><a name=\"hcmid-dcaa4d32aa6658a8df831551503e52ee\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/97/049/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>manufacturer</b>: <a href=\"Bundle-Processedbundlekarvea.html#Organization_man-4bb7a752921434fd5f9921b5b9473eda\">Organization Sanofi Winthrop Industrie</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/97/049/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "manufacturer" : [{
        "reference" : "Organization/man-4bb7a752921434fd5f9921b5b9473eda"
      }]
    }
  }]
}

```
