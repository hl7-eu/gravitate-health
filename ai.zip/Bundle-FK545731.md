# FK545731 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK545731**

## Example Bundle: FK545731

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: Informasjon til brukeren

 

# Pakningsvedlegg: Informasjon til brukeren

## Actrapid Penfill 100 IE/ml (internasjonale enheter/ml) injeksjonsvæske, oppløsning i sylinderampulle

### insulin, human


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.
* Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.
* Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om:

 

## I dette pakningsvedlegget finner du informasjon om:

1. Hva Actrapid er og hva det brukes mot
1. Hva du må vite før du bruker Actrapid
1. Hvordan du bruker Actrapid
1. Mulige bivirkninger
1. Hvordan du oppbevarer Actrapid
1. Innholdet i pakningen og ytterligere informasjon


#### Hva Actrapid er og hva det brukes mot

 

## Hva Actrapid er og hva det brukes mot

Actrapid er et humant insulin med en hurtigvirkende effekt.

Actrapid brukes til å senke det høye blodsukkernivået hos pasienter med diabetes mellitus (diabetes). Diabetes er en sykdom hvor kroppen ikke produserer nok insulin til å kontrollere blodsukkernivået. Behandling med Actrapid hjelper med å forebygge komplikasjoner i forbindelse med din diabetes.

Actrapid vil begynne å senke blodsukkeret ditt ca. time etter injeksjon. Effekten varer omtrent 8 timer. Actrapid gis ofte i kombinasjon med middels langtidsvirkende eller langtidsvirkende insulinpreparater.


#### Hva du må vite før du bruker Actrapid

 

## Hva du må vite før du bruker Actrapid


#### Hvordan du bruker Actrapid

 

## Hvordan du bruker Actrapid

Dose og når du skal ta insulin
Bruk alltid insulinet og innstill dosen din nøyaktig slik legen har fortalt deg. Kontakt lege, apotek eller sykepleier hvis du er usikker.

Spis et måltid eller mellommåltid som inneholder karbohydrater innen 30 minutter etter injeksjonen for å unngå lavt blodsukker (føling).

Ikke skift insulinet ditt med mindre legen din har gitt deg beskjed om det. Skifte av insulintype eller -merke, kan medføre at legen vil justere dosen.

Bruk hos barn og ungdom
Actrapid kan brukes av barn og ungdom.

Bruk hos spesielle pasientgrupper
Dersom du har redusert nyre- eller leverfunksjon, eller dersom du er over 65 år, må du kontrollere blodsukkeret ditt mer regelmessig og diskutere endringer av insulindosen med legen.

Hvordan og hvor skal det injiseres
Actrapid er beregnet til injeksjon under huden (subkutant). Du må aldri selv injisere direkte i en blodåre (intravenøst) eller muskel (intramuskulært). Actrapid Penfill er kun tilpasset injeksjon under huden ved bruk av en flergangspenn. Rådfør deg med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.

For hver injeksjon bytt injeksjonssted innenfor det bestemte hudområdet du bruker. Dette kan redusere risikoen for utvikling av kuler eller fordypninger i huden, se avsnitt 4. De stedene på kroppen som egner seg best for injeksjon er: foran ved midjen (magen), bakenden, foran på lårene eller på overarmene.

Effekten av insulinet inntrer raskere hvis det injiseres rundt midjen (magen). Du bør alltid måle blodsukkeret regelmessig.

* Du må ikke etterfylle sylinderampullen. Når den er tom, skal den kastes.
* Actrapid Penfill sylinderampuller er utformet til bruk sammen med insulininjeksjonssystemer fra Novo Nordisk og NovoFine eller NovoTwist nåler.
* Dersom du behandles med Actrapid Penfill og en annen insulintype i Penfill sylinderampulle, må du bruke to insulininjeksjonssystemer, ett for hver insulintype.
* Ha alltid med deg en ekstra Penfill sylinderampulle i tilfelle den du bruker mistes eller ødelegges.

Hvordan injisere Actrapid

* Injiser insulinet under huden. Følg legens eller sykepleierens råd angående injeksjonsteknikk, og som beskrevet i pennens bruksanvisning.
* Hold nålen under huden i minst 6 sekunder. Hold trykknappen helt inne inntil nålen er trukket ut av huden. Dette vil sikre at korrekt dose er injisert og begrenser muligheten for at det kommer blod inn i nålen eller i insulinbeholderen.
* Fjern og kast nålen etter hver injeksjon, og oppbevar Actrapid uten påsatt nål. Hvis ikke, kan det lekke ut væske som kan medføre feil dosering.


#### Mulige bivirkninger

 

## Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.

Sammendrag av alvorlige og svært vanlige bivirkninger

**Lavt blodsukker (føling, hypoglykemi) **er en svært vanlig bivirkning. Den kan berøre flere enn 1 av 10 brukere.

Lavt blodsukker kan inntreffe hvis du:
* Injiserer for mye insulin.
* Spiser for lite eller hopper over et måltid.
* Mosjonerer mer enn vanlig.
* Drikker alkohol, se Inntak av Actrapid sammen med alkohol i avsnitt 2.

Symptomer på lavt blodsukker:Kaldsvetting, kald og blek hud, hodepine, hjertebank, kvalme, usedvanlig stor sultfølelse, forbigående synsforstyrrelser, døsighet, unormal tretthet og svakhet, nervøsitet eller skjelving, angst, forvirring og konsentrasjonsproblemer.

Alvorlig lavt blodsukker kan føre til bevisstløshet. Dersom langvarig alvorlig lavt blodsukker ikke behandles, kan det føre til hjerneskade (midlertidig eller livsvarig) og til og med død. Du kan komme raskere til bevissthet igjen hvis du får en injeksjon av hormonet glukagon av en person som er blitt instruert i hvordan det skal brukes. Dersom glukagon er injisert, må du så snart du kommer til bevissthet få glukose eller et sukkerholdig mellommåltid. Hvis du ikke reagerer på glukagonbehandling, må du behandles ved et sykehus.

Hva skal du gjøre hvis du får lavt blodsukker:
* Dersom du opplever lavt blodsukker, spis glukosetabletter eller et annet mellommåltid med høyt sukkerinnhold (for eksempel søtsaker, kjeks, fruktjuice). Hvis mulig, mål blodsukkeret ditt og ta en hvil. For sikkerhets skyld må du alltid ha med deg glukosetabletter eller et mellommåltid med høyt sukkerinnhold.
* Når symptomene på lavt blodsukker har forsvunnet, eller når blodsukkernivået ditt er stabilisert, fortsettes insulinbehandlingen som vanlig.
* Dersom du får så lavt blodsukker at det fører til at du besvimer, dersom du har hatt behov for en injeksjon av glukagon, eller dersom du har hatt gjentatte episoder med lavt blodsukker skal du snakke med en lege. Det kan være nødvendig å justere insulindosen, tidspunktet for insulindosering, matinntak eller mengde fysisk aktivitet.

Fortell relevante personer at du har diabetes og hva konsekvensene kan være, inkludert risikoen for å besvime (bli bevisstløs) på grunn av lavt blodsukker. La dem få vite at hvis du besvimer må de legge deg i stabilt sideleie og tilkalle lege med det samme. De må ikke gi deg noe å spise eller drikke fordi du kan bli kvalt.

**Alvorlig allergisk reaksjon **overfor Actrapid eller et av innholdsstoffene i preparatet (en såkalt systemisk allergisk reaksjon) er en svært sjelden bivirkning, men den kan potensielt være livstruende. Den kan berøre færre enn 1 av 10 000 brukere.

Søk råd hos helsepersonell omgående:
* Dersom symptomene på allergi sprer seg til andre deler av kroppen.
* Dersom du plutselig føler deg dårlig og du: begynner å svette, blir kvalm (kaster opp), får pustebesvær, får hjertebank, føler deg svimmel.
➔Dersom du merker noen av disse symptomene, søk råd hos helsepersonell omgående.

**Hudforandringer på injeksjonsstedet: **Fettvevet kan skrumpe (lipoatrofi) eller fortykkes (lipohypertrofi) (noe som kan forekomme hos færre enn 1 av 100 personer) hvis du injiserer insulin på samme sted.

Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete, innskrumpet eller fortykket område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.

Liste over andre bivirkninger

**Mindre vanlige bivirkninger**

Kan berøre færre enn 1 av 100 personer.

**Symptomer på allergi: **Lokale allergiske reaksjoner (smerte, rødhet, elveblest, inflammasjon, blåmerker, hevelse og kløe) på injeksjonsstedet kan forekomme. Disse forsvinner vanligvis i løpet av få uker ved fortsatt bruk av insulinet. Hvis de ikke forsvinner, eller det sprer seg over hele kroppen, snakk med lege omgående. Se også Alvorlig allergisk reaksjon ovenfor.

**Synsforstyrrelser: **Synsforstyrrelser kan oppstå i begynnelsen av en insulinbehandling, men er normalt av forbigående karakter.

**Hovne ledd: **Når du begynner insulinbehandlingen, kan væskeansamling forårsake hevelser rundt ankler og andre ledd. Dette er normalt av forbigående karakter, hvis ikke, snakk med legen.

**Smertefull neuropati **(smerte som skyldes nerveskade): Hvis blodsukkernivået ditt forbedres veldig raskt kan du få en nerverelatert smerte. Dette kalles akutt smertefull neuropati og er vanligvis forbigående.

Svært sjeldne bivirkninger
Kan berøre færre enn 1 av 10 000 personer.

**Diabetisk retinopati **(en øyesykdom relatert til diabetes som kan føre til synstap): Dersom du har diabetisk retinopati og blodsukkernivået ditt forbedres veldig raskt, kan retinopatien bli verre. Spør legen om dette.

Følger ved diabetes
Høyt blodsukker (hyperglykemi)

Høyt blodsukker kan inntreffe hvis du:
* Ikke har injisert nok insulin.
* Glemmer å ta insulin eller avbryter behandlingen med insulin.
* Gjentatte ganger tar mindre insulin enn det du trenger.
* Får en infeksjon og/eller feber.
* Spiser mer enn vanlig.
* Mosjonerer mindre enn vanlig.

Varselsymptomer på høyt blodsukker:

Varselsymptomene utvikler seg gradvis. De inkluderer: økt vannlating, tørste, manglende appetitt, uvelhet (kvalme eller oppkast), døsighet eller tretthet, rødmende hud, tørr hud, munntørrhet og fruktluktende (acetonluktende) ånde.

Hva gjør du hvis du får høyt blodsukker:
* Dersom du får noen av symptomene nevnt ovenfor: kontroller blodsukkernivået, hvis mulig kontroller urinen for ketoner, søk deretter råd hos helsepersonell omgående.
* Dette kan være symptomer på en meget alvorlig tilstand kalt diabetisk ketoacidose (opphopning av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Dersom den ikke behandles, kan den føre til diabetisk koma og til slutt død.


#### Hvordan du oppbevarer Actrapid

 

## Hvordan du oppbevarer Actrapid

Oppbevares utilgjengelig for barn.

Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på sylinderampullens etikett og eske etter “Utl. dato”. Utløpsdatoen er den siste dagen i den angitte måneden.

**Før anbrudd: **Oppbevares i kjøleskap ved 2-8ºC. Holdes borte fra kjøleelementet. Skal ikke fryses.

**Under bruk eller medbrakt som reserve: **Skal ikke oppbevares i kjøleskap eller fryses. Den kan medbringes og oppbevares i romtemperatur (ved høyst 30ºC) i opptil 6 uker.

For å beskytte mot lys, oppbevares alltid sylinderampullen i ytteremballasjen når den ikke er i bruk.

Kast nålen etter hver injeksjon.

Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.


#### Innholdet i pakningen og ytterligere informasjon

 

## Innholdet i pakningen og ytterligere informasjon


####  Actrapid Penfill inj, oppl 100 IE/ml 
LEGEMIDDELMERKEVAREID:
** ID_DB67B960-0E88-46E3-8935-A90F2A18AE2E **
-------

Full name: **Actrapid Penfill inj, oppl 100 IE/ml**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_1090FDF5-3215-42D2-BA40-0A2BE53B7042 ** 

VARENUMMER: ** 014398 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK545731",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "545731"
  },
  "type" : "document",
  "timestamp" : "2020-09-24T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK545731-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK545731-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK545731-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK545731-COMP</b></p><a name=\"FK545731-COMP\"> </a><a name=\"hcFK545731-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/545731</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2020-09-24</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: Actrapid Penfill Novo Nordisk</p></div>"
      },
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "545731"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-4"
      }],
      "date" : "2020-09-24",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "Actrapid Penfill Novo Nordisk",
      "section" : [{
        "title" : "Pakningsvedlegg: Informasjon til brukeren",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: Informasjon til brukeren</h1><h2>Actrapid Penfill 100 IE/ml (internasjonale enheter/ml) injeksjonsvæske, oppløsning i sylinderampulle</h2><h3>insulin, human</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke dette legemidlet. Det inneholder informasjon som er viktig for deg.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Spør lege, apotek eller sykepleier hvis du har flere spørsmål eller trenger mer informasjon.</li><li>Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.</li><li>Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om:",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om:</h2><div class=\"paragraph\"><ol><li>Hva Actrapid er og hva det brukes mot</li><li>Hva du må vite før du bruker Actrapid</li><li>Hvordan du bruker Actrapid</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer Actrapid</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "Hva Actrapid er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hva Actrapid er og hva det brukes mot</h2><div class=\"paragraph\">Actrapid er et humant insulin med en hurtigvirkende effekt.</div><div class=\"paragraph\">Actrapid brukes til å senke det høye blodsukkernivået hos pasienter med diabetes mellitus (diabetes). Diabetes er en sykdom hvor kroppen ikke produserer nok insulin til å kontrollere blodsukkernivået. Behandling med Actrapid hjelper med å forebygge komplikasjoner i forbindelse med din diabetes.</div><div class=\"paragraph\">Actrapid vil begynne å senke blodsukkeret ditt ca. time etter injeksjon. Effekten varer omtrent 8 timer. Actrapid gis ofte i kombinasjon med middels langtidsvirkende eller langtidsvirkende insulinpreparater.</div></div>"
          }
        },
        {
          "title" : "Hva du må vite før du bruker Actrapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hva du må vite før du bruker Actrapid</h2></div>"
          },
          "section" : [{
            "title" : "Bruk ikke Actrapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Bruk ikke Actrapid</h3><div class=\"paragraph\"><ul><li>Dersom du er allergisk overfor humant insulin eller noen av de andre innholdsstoffene i dette legemidlet listet opp i avsnitt 6.</li><li>Dersom du tror at du begynner å få føling (hypoglykemi, lavt blodsukker), se Sammendrag av alvorlige og svært vanlige bivirkninger i avsnitt 4.</li><li>I insulininfusjonspumper.</li><li>Dersom sylinderampullen eller injeksjonssystemet som inneholder sylinderampullen utsettes for støt, skades eller klemmes.</li><li>Dersom det ikke har vært riktig oppbevart, eller dersom det har vært frosset, se avsnitt 5.</li><li>Dersom insulinet ikke fremstår som klart og fargeløst.</li></ul></div><div class=\"paragraph\">Bruk ikke Actrapid hvis noe av dette forekommer. Snakk med lege, apotek eller sykepleier.</div></div>"
            }
          },
          {
            "title" : "Før du bruker Actrapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Før du bruker Actrapid</h3><div class=\"paragraph\"><ul><li>Kontroller etiketten for å forsikre deg om at det er riktig type insulin.</li><li>Du må alltid kontrollere sylinderampullen samt gummistempelet i bunnen av sylinderampullen. Ikke bruk den hvis det er synlig skade på den, eller hvis gummistempelet er trukket over det hvite etikettbåndet i bunnen av sylinderampullen. Dette kan være resultatet av en insulinlekkasje. Hvis du tror at sylinderampullen er skadet, returneres preparatet til apoteket. Se pennens bruksanvisning for nærmere instruksjoner.</li><li>Bruk alltid en ny nål til hver injeksjon for å unngå urenheter.</li><li>Nåler og Actrapid Penfill må ikke deles med andre.</li><li>Actrapid Penfill er kun tilpasset injeksjon under huden ved bruk av en flergangspenn. Rådfør deg med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler</h3><div class=\"paragraph\">Noen tilstander og aktiviteter kan påvirke insulinbehovet ditt. Rådfør deg med lege:<ul><li>Dersom du har nyre- eller leverproblemer, eller problemer med binyrer, hypofysen eller skjoldbruskkjertelen.</li><li>Dersom du mosjonerer mer enn vanlig, eller hvis du ønsker å endre ditt vanlige kosthold, da dette kan påvirke blodsukkernivået ditt.</li><li>Dersom du er syk, fortsett å ta insulin og rådfør deg med lege.</li><li>Dersom du skal reise utenlands, tidsforskjellen mellom de ulike land kan påvirke insulinbehovet og tidspunktene for injeksjoner.</li></ul></div><span class=\"inline-title\">Hudforandringer på injeksjonsstedet</span><div class=\"paragraph\">Injeksjonsstedet bør roteres for å bidra til å forebygge forandringer i fettvevet under huden, som f.eks. fortykning av huden, innskrumping av huden eller kuler under huden. Det kan hende at insulinet ikke virker så godt hvis du injiserer det på et klumpete, innskrumpet eller fortykket sted på huden (se avsnitt 3). Snakk med legen din hvis du merker noen hudforandringer på injeksjonsstedet. Hvis du pleier å injisere på områder med reaksjoner og vil endre injeksjonssted til et annet område, må du snakke med legen din først. Legen din kan gi deg beskjed om å kontrollere blodsukkeret ditt mer nøye og å justere dosen på insulinet ditt eller andre legemidler du bruker mot diabetes.</div></div>"
            }
          },
          {
            "title" : "Andre legemidler og Actrapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og Actrapid</h3><div class=\"paragraph\">Snakk med lege, apotek eller sykepleier dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler.<br/>Noen legemidler påvirker blodsukkernivået, og dette kan bety at insulindosen må endres. Nedenfor følger en oversikt over de vanligste legemidlene som kan påvirke insulinbehandlingen din.</div><div class=\"paragraph\"><span class=\"underline\">Blodsukkernivået ditt kan synke (hypoglykemi, føling) dersom du bruker:</span><ul><li>Andre medisiner til behandling av diabetes</li><li>Monoaminoksidasehemmere (MAOH) (brukes til behandling av depresjon)</li><li>Betablokkere (brukes til behandling av høyt blodtrykk)</li><li>Angiotensinkonverterende enzym(ACE)hemmere (brukes til behandling av visse hjertelidelser eller høyt blodtrykk)</li><li>Salisylater (brukes til å lindre smerte og som febernedsettende)</li><li>Anabole steroider (slik som testosteron)</li><li>Sulfonamider (brukes til behandling av infeksjoner).</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Blodsukkernivået ditt kan stige (hyperglykemi) dersom du bruker:</span><ul><li>Orale antikonsepsjonsmidler (p-piller)</li><li>Tiazider (brukes til behandling av høyt blodtrykk eller ved omfattende væskeopphopning)</li><li>Glukokortikoider (slik som ”kortison”, som brukes til behandling av inflammasjon)</li><li>Thyreoideahormoner (brukes til behandling av sykdommer i skjoldbruskkjertelen)</li><li>Sympatomimetika (som adrenalin, salbutamol eller terbutalin som brukes til behandling av astma)</li><li>Veksthormon (legemiddel til stimulering av skjelett- og kroppslig vekst og med omfattende påvirkning på kroppens stoffskifteprosesser)</li><li>Danazol (legemiddel som påvirker eggløsningen).</li></ul></div><div class=\"paragraph\">Oktreotid og lanreotid (brukes til behandling av akromegali, en sjelden hormonell sykdom som vanligvis oppstår hos middelaldrende voksne og som kommer av at hypofysen produserer for mye veksthormon) kan enten øke eller senke blodsukkernivået ditt.</div><div class=\"paragraph\">Betablokkere (brukes til behandling av høyt blodtrykk) kan svekke eller fullstendig dempe de første varselsymptomene som hjelper deg til å gjenkjenne lavt blodsukker.</div><div class=\"paragraph\"><span class=\"underline\">Pioglitazon (tabletter brukt til behandling av type 2 diabetes)</span><br/>Noen pasienter med mangeårig type 2 diabetes og hjertesykdom eller som har hatt slag, og som ble behandlet med pioglitazon og insulin, utviklet hjertesvikt. Snakk med lege så snart som mulig hvis du opplever tegn på hjertesvikt slik som uvanlig kortpustethet eller rask vektøkning eller lokale væskeansamlinger (hevelse i bena, ødem).</div><div class=\"paragraph\">Snakk med lege, apotek eller sykepleier dersom du har brukt noen av legemidlene som er nevnt her.</div></div>"
            }
          },
          {
            "title" : "Inntak av Actrapid sammen med alkohol",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029901"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Inntak av Actrapid sammen med alkohol</h3><div class=\"paragraph\"><ul><li>Dersom du drikker alkohol, kan behovet for insulin endre seg fordi blodsukkernivået enten kan stige eller synke. Nøye kontroll anbefales.</li></ul></div></div>"
            }
          },
          {
            "title" : "Graviditet og amming",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet og amming</h3><div class=\"paragraph\"><ul><li>Snakk med lege før du tar dette legemidlet dersom du er gravid, tror at du kan være gravid eller planlegger å bli gravid. Actrapid kan brukes under graviditet. Det kan være behov for å endre insulindosen under svangerskapet og etter fødselen. Det er viktig med nøye kontroll av din diabetes, særlig er det viktig å forhindre føling, dette for ditt barns helse.</li><li>Det er ingen restriksjoner for behandling med Actrapid under amming.</li></ul></div><div class=\"paragraph\">Snakk med lege, apotek eller sykepleier før du tar dette legemidlet dersom du er gravid eller ammer.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\"><ul><li>Spør legen om du kan kjøre bil eller betjene en maskin:<ul><li>Dersom du ofte får føling.</li><li>Dersom du har problemer med å gjenkjenne føling.</li></ul></li></ul></div><div class=\"paragraph\">Dersom blodsukkeret ditt er lavt eller høyt, kan det påvirke konsentrasjons- og reaksjonsevnen og derfor også evnen til å kjøre eller betjene en maskin. Tenk på at du kan utsette deg selv eller andre for fare.</div></div>"
            }
          },
          {
            "title" : "Actrapid inneholder natrium",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Actrapid inneholder natrium</h3><div class=\"paragraph\">Actrapid inneholder mindre enn 1 mmol natrium (23 mg) pr. dose, det vil si at Actrapid praktisk talt er ”natriumfritt”.</div></div>"
            }
          }]
        },
        {
          "title" : "Hvordan du bruker Actrapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hvordan du bruker Actrapid</h2><span class=\"inline-title\">Dose og når du skal ta insulin</span><div class=\"paragraph\">Bruk alltid insulinet og innstill dosen din nøyaktig slik legen har fortalt deg. Kontakt lege, apotek eller sykepleier hvis du er usikker.</div><div class=\"paragraph\">Spis et måltid eller mellommåltid som inneholder karbohydrater innen 30 minutter etter injeksjonen for å unngå lavt blodsukker (føling).</div><div class=\"paragraph\">Ikke skift insulinet ditt med mindre legen din har gitt deg beskjed om det. Skifte av insulintype eller -merke, kan medføre at legen vil justere dosen.</div><span class=\"inline-title\">Bruk hos barn og ungdom</span><div class=\"paragraph\">Actrapid kan brukes av barn og ungdom.</div><span class=\"inline-title\">Bruk hos spesielle pasientgrupper</span><div class=\"paragraph\">Dersom du har redusert nyre- eller leverfunksjon, eller dersom du er over 65 år, må du kontrollere blodsukkeret ditt mer regelmessig og diskutere endringer av insulindosen med legen.</div><span class=\"inline-title\">Hvordan og hvor skal det injiseres</span><div class=\"paragraph\">Actrapid er beregnet til injeksjon under huden (subkutant). Du må aldri selv injisere direkte i en blodåre (intravenøst) eller muskel (intramuskulært). Actrapid Penfill er kun tilpasset injeksjon under huden ved bruk av en flergangspenn. Rådfør deg med legen din dersom du trenger å injisere insulinet ved hjelp av en annen metode.</div><div class=\"paragraph\">For hver injeksjon bytt injeksjonssted innenfor det bestemte hudområdet du bruker. Dette kan redusere risikoen for utvikling av kuler eller fordypninger i huden, se avsnitt 4. De stedene på kroppen som egner seg best for injeksjon er: foran ved midjen (magen), bakenden, foran på lårene eller på overarmene.<br/>Effekten av insulinet inntrer raskere hvis det injiseres rundt midjen (magen). Du bør alltid måle blodsukkeret regelmessig.</div><div class=\"paragraph\"><ul><li>Du må ikke etterfylle sylinderampullen. Når den er tom, skal den kastes.</li><li>Actrapid Penfill sylinderampuller er utformet til bruk sammen med insulininjeksjonssystemer fra Novo Nordisk og NovoFine eller NovoTwist nåler.</li><li>Dersom du behandles med Actrapid Penfill og en annen insulintype i Penfill sylinderampulle, må du bruke to insulininjeksjonssystemer, ett for hver insulintype.</li><li>Ha alltid med deg en ekstra Penfill sylinderampulle i tilfelle den du bruker mistes eller ødelegges.</li></ul></div><span class=\"inline-title\">Hvordan injisere Actrapid</span><div class=\"paragraph\"><ul><li>Injiser insulinet under huden. Følg legens eller sykepleierens råd angående injeksjonsteknikk, og som beskrevet i pennens bruksanvisning.</li><li>Hold nålen under huden i minst 6 sekunder. Hold trykknappen helt inne inntil nålen er trukket ut av huden. Dette vil sikre at korrekt dose er injisert og begrenser muligheten for at det kommer blod inn i nålen eller i insulinbeholderen.</li><li>Fjern og kast nålen etter hver injeksjon, og oppbevar Actrapid uten påsatt nål. Hvis ikke, kan det lekke ut væske som kan medføre feil dosering.</li></ul></div></div>"
          },
          "section" : [{
            "title" : "Dersom du tar for mye insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029907"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du tar for mye insulin</h3><div class=\"paragraph\">Dersom du tar for mye insulin blir blodsukkeret for lavt (hypoglykemi). Se Sammendrag av alvorlige og svært vanlige bivirkninger i avsnitt 4.</div></div>"
            }
          },
          {
            "title" : "Dersom du har glemt å ta insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029908"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du har glemt å ta insulin</h3><div class=\"paragraph\">Dersom du glemmer å ta insulinet ditt kan blodsukkeret bli for høyt (hyperglykemi). Se Følger ved diabetes i avsnitt 4.</div></div>"
            }
          },
          {
            "title" : "Dersom du avbryter behandling med insulin",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029909"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du avbryter behandling med insulin</h3><div class=\"paragraph\">Ikke slutt med å ta insulin uten å snakke med en lege, som vil fortelle deg hva som må gjøres. Dette kan føre til veldig høyt blodsukker (alvorlig hyperglykemi) og ketoacidose. Se Følger ved diabetes i avsnitt 4.</div><div class=\"paragraph\">Spør lege, apotek eller sykepleier dersom du har noen spørsmål om bruken av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.</div><span class=\"inline-title\">Sammendrag av alvorlige og svært vanlige bivirkninger</span><div class=\"paragraph\"><b>Lavt blodsukker (føling, hypoglykemi) </b>er en svært vanlig bivirkning. Den kan berøre flere enn 1 av 10 brukere.</div><div class=\"paragraph\"><span class=\"underline\">Lavt blodsukker kan inntreffe hvis du:</span><ul><li>Injiserer for mye insulin.</li><li>Spiser for lite eller hopper over et måltid.</li><li>Mosjonerer mer enn vanlig.</li><li>Drikker alkohol, se Inntak av Actrapid sammen med alkohol i avsnitt 2.</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Symptomer på lavt blodsukker:</span> Kaldsvetting, kald og blek hud, hodepine, hjertebank, kvalme, usedvanlig stor sultfølelse, forbigående synsforstyrrelser, døsighet, unormal tretthet og svakhet, nervøsitet eller skjelving, angst, forvirring og konsentrasjonsproblemer.</div><div class=\"paragraph\">Alvorlig lavt blodsukker kan føre til bevisstløshet. Dersom langvarig alvorlig lavt blodsukker ikke behandles, kan det føre til hjerneskade (midlertidig eller livsvarig) og til og med død. Du kan komme raskere til bevissthet igjen hvis du får en injeksjon av hormonet glukagon av en person som er blitt instruert i hvordan det skal brukes. Dersom glukagon er injisert, må du så snart du kommer til bevissthet få glukose eller et sukkerholdig mellommåltid. Hvis du ikke reagerer på glukagonbehandling, må du behandles ved et sykehus.</div><div class=\"paragraph\"><span class=\"underline\">Hva skal du gjøre hvis du får lavt blodsukker:</span><ul><li>Dersom du opplever lavt blodsukker, spis glukosetabletter eller et annet mellommåltid med høyt sukkerinnhold (for eksempel søtsaker, kjeks, fruktjuice). Hvis mulig, mål blodsukkeret ditt og ta en hvil. For sikkerhets skyld må du alltid ha med deg glukosetabletter eller et mellommåltid med høyt sukkerinnhold.</li><li>Når symptomene på lavt blodsukker har forsvunnet, eller når blodsukkernivået ditt er stabilisert, fortsettes insulinbehandlingen som vanlig.</li><li>Dersom du får så lavt blodsukker at det fører til at du besvimer, dersom du har hatt behov for en injeksjon av glukagon, eller dersom du har hatt gjentatte episoder med lavt blodsukker skal du snakke med en lege. Det kan være nødvendig å justere insulindosen, tidspunktet for insulindosering, matinntak eller mengde fysisk aktivitet.</li></ul></div><div class=\"paragraph\">Fortell relevante personer at du har diabetes og hva konsekvensene kan være, inkludert risikoen for å besvime (bli bevisstløs) på grunn av lavt blodsukker. La dem få vite at hvis du besvimer må de legge deg i stabilt sideleie og tilkalle lege med det samme. De må ikke gi deg noe å spise eller drikke fordi du kan bli kvalt.</div><div class=\"paragraph\"><b>Alvorlig allergisk reaksjon </b>overfor Actrapid eller et av innholdsstoffene i preparatet (en såkalt systemisk allergisk reaksjon) er en svært sjelden bivirkning, men den kan potensielt være livstruende. Den kan berøre færre enn 1 av 10 000 brukere.</div><div class=\"paragraph\">Søk råd hos helsepersonell omgående:<ul><li>Dersom symptomene på allergi sprer seg til andre deler av kroppen.</li><li>Dersom du plutselig føler deg dårlig og du: begynner å svette, blir kvalm (kaster opp), får pustebesvær, får hjertebank, føler deg svimmel.</li></ul>➔Dersom du merker noen av disse symptomene, søk råd hos helsepersonell omgående.</div><div class=\"paragraph\"><b>Hudforandringer på injeksjonsstedet: </b>Fettvevet kan skrumpe (lipoatrofi) eller fortykkes (lipohypertrofi) (noe som kan forekomme hos færre enn 1 av 100 personer) hvis du injiserer insulin på samme sted.<br/>Opphopning av et protein kalt amyloid kan også forårsake kuler under huden (kutan amyloidose; det er ikke kjent hvor ofte dette forekommer). Det kan hende at insulinet ikke virker så godt hvis du injiserer det i et klumpete, innskrumpet eller fortykket område. Bytt injeksjonssted for hver injeksjon for å bidra til å forebygge disse hudforandringene.</div><span class=\"inline-title\">Liste over andre bivirkninger</span><div class=\"paragraph\"><b>Mindre vanlige bivirkninger</b><br/>Kan berøre færre enn 1 av 100 personer.</div><div class=\"paragraph\"><b>Symptomer på allergi: </b>Lokale allergiske reaksjoner (smerte, rødhet, elveblest, inflammasjon, blåmerker, hevelse og kløe) på injeksjonsstedet kan forekomme. Disse forsvinner vanligvis i løpet av få uker ved fortsatt bruk av insulinet. Hvis de ikke forsvinner, eller det sprer seg over hele kroppen, snakk med lege omgående. Se også Alvorlig allergisk reaksjon ovenfor.</div><div class=\"paragraph\"><b>Synsforstyrrelser: </b>Synsforstyrrelser kan oppstå i begynnelsen av en insulinbehandling, men er normalt av forbigående karakter.</div><div class=\"paragraph\"><b>Hovne ledd: </b>Når du begynner insulinbehandlingen, kan væskeansamling forårsake hevelser rundt ankler og andre ledd. Dette er normalt av forbigående karakter, hvis ikke, snakk med legen.</div><div class=\"paragraph\"><b>Smertefull neuropati </b>(smerte som skyldes nerveskade): Hvis blodsukkernivået ditt forbedres veldig raskt kan du få en nerverelatert smerte. Dette kalles akutt smertefull neuropati og er vanligvis forbigående.</div><span class=\"inline-title\">Svært sjeldne bivirkninger</span><div class=\"paragraph\">Kan berøre færre enn 1 av 10 000 personer.</div><div class=\"paragraph\"><b>Diabetisk retinopati </b>(en øyesykdom relatert til diabetes som kan føre til synstap): Dersom du har diabetisk retinopati og blodsukkernivået ditt forbedres veldig raskt, kan retinopatien bli verre. Spør legen om dette.</div><span class=\"inline-title\">Følger ved diabetes</span> <span class=\"inline-title\">Høyt blodsukker (hyperglykemi)</span><div class=\"paragraph\"><span class=\"underline\">Høyt blodsukker kan inntreffe hvis du:</span><ul><li>Ikke har injisert nok insulin.</li><li>Glemmer å ta insulin eller avbryter behandlingen med insulin.</li><li>Gjentatte ganger tar mindre insulin enn det du trenger.</li><li>Får en infeksjon og/eller feber.</li><li>Spiser mer enn vanlig.</li><li>Mosjonerer mindre enn vanlig.</li></ul></div><div class=\"paragraph\"><span class=\"underline\">Varselsymptomer på høyt blodsukker:</span><br/>Varselsymptomene utvikler seg gradvis. De inkluderer: økt vannlating, tørste, manglende appetitt, uvelhet (kvalme eller oppkast), døsighet eller tretthet, rødmende hud, tørr hud, munntørrhet og fruktluktende (acetonluktende) ånde.</div><div class=\"paragraph\"><span class=\"underline\">Hva gjør du hvis du får høyt blodsukker:</span><ul><li>Dersom du får noen av symptomene nevnt ovenfor: kontroller blodsukkernivået, hvis mulig kontroller urinen for ketoner, søk deretter råd hos helsepersonell omgående.</li><li>Dette kan være symptomer på en meget alvorlig tilstand kalt diabetisk ketoacidose (opphopning av syre i blodet fordi kroppen bryter ned fett i stedet for sukker). Dersom den ikke behandles, kan den føre til diabetisk koma og til slutt død.</li></ul></div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "Hvordan du oppbevarer Actrapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hvordan du oppbevarer Actrapid</h2><div class=\"paragraph\">Oppbevares utilgjengelig for barn.</div><div class=\"paragraph\">Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på sylinderampullens etikett og eske etter “Utl. dato”. Utløpsdatoen er den siste dagen i den angitte måneden.</div><div class=\"paragraph\"><b>Før anbrudd: </b>Oppbevares i kjøleskap ved 2-8ºC. Holdes borte fra kjøleelementet. Skal ikke fryses.</div><div class=\"paragraph\"><b>Under bruk eller medbrakt som reserve: </b>Skal ikke oppbevares i kjøleskap eller fryses. Den kan medbringes og oppbevares i romtemperatur (ved høyst 30ºC) i opptil 6 uker.</div><div class=\"paragraph\">For å beskytte mot lys, oppbevares alltid sylinderampullen i ytteremballasjen når den ikke er i bruk.<br/>Kast nålen etter hver injeksjon.<br/>Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.</div></div>"
          }
        },
        {
          "title" : "Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av Actrapid",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av Actrapid</h3><div class=\"paragraph\"><ul><li>Virkestoff er humant insulin. Hver ml inneholder 100 IE humant insulin. Hver sylinderampulle inneholder 300 IE humant insulin à 3 ml injeksjonsvæske, oppløsning.</li><li>Andre innholdsstoffer er sinkklorid, glyserol, metakresol, natriumhydroksid, saltsyre og vann til injeksjonsvæsker.</li></ul></div></div>"
            }
          },
          {
            "title" : "Hvordan Actrapid ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan Actrapid ser ut og innholdet i pakningen</h3><div class=\"paragraph\">Actrapid finnes som injeksjonsvæske, oppløsning.<br/>Pakningsstørrelser på 1, 5 og 10 sylinderampuller à 3 ml. Ikke alle pakningsstørrelser vil bli markedsført.<br/>Oppløsningen er klar og fargeløs.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen og tilvirker",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen og tilvirker</h3><div class=\"paragraph\"><span class=\"underline\">Innehaver av markedsføringstillatelsen</span></div><div class=\"paragraph\">Novo Nordisk A/S, Novo Allé, DK-2880 Bagsværd, Danmark</div><div class=\"paragraph\"><span class=\"underline\">Tilvirker</span><br/>Tilvirkeren kan identifiseres via batchnummeret som er trykket på kartongfliken og på etiketten:</div><div class=\"paragraph\"><ul><li>Hvis andre og tredje tegn er S6, P5, K7, R7, VG, FG eller ZF er tilvirkeren Novo Nordisk A/S, Novo Allé, DK-2880 Bagsværd, Danmark.</li></ul></div><div class=\"paragraph\"><ul><li>Hvis andre og tredje tegn er H7 eller T6 er tilvirkeren Novo Nordisk Production SAS, 45 Avenue d’Orléans, F-28000 Chartres, Frankrike.</li></ul></div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 24.09.2020",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 24.09.2020</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre informasjonskilder</h3><div class=\"paragraph\">Detaljert informasjon om dette legemidlet er tilgjengelig på nettstedet til Det europeiske legemiddelkontoret (the European Medicines Agency): <a href=\"http://www.ema.europa.eu/\" title=\"\n               http://www.ema.europa.eu\n            \">http://www.ema.europa.eu </a><a href=\"http://www.ema.europa.eu/\" title=\"/.\">/.</a></div></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/Diabetes-MPD-4",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "Diabetes-MPD-4",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_Diabetes-MPD-4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition Diabetes-MPD-4</b></p><a name=\"Diabetes-MPD-4\"> </a><a name=\"hcDiabetes-MPD-4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_DB67B960-0E88-46E3-8935-A90F2A18AE2E</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Actrapid Penfill inj, oppl 100 IE/ml</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_DB67B960-0E88-46E3-8935-A90F2A18AE2E"
      }],
      "name" : [{
        "productName" : "Actrapid Penfill inj, oppl 100 IE/ml"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/Diabetes-PPD-4",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "Diabetes-PPD-4",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_Diabetes-PPD-4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition Diabetes-PPD-4</b></p><a name=\"Diabetes-PPD-4\"> </a><a name=\"hcDiabetes-PPD-4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_1090FDF5-3215-42D2-BA40-0A2BE53B7042, <code>https://farmalogg.no/varenummer</code>/014398</p><p><b>name</b>: Actrapid Penfill inj, oppl 100 IE/ml</p><p><b>packageFor</b>: <a href=\"Bundle-FK545731.html#MedicinalProductDefinition_Diabetes-MPD-4\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_DB67B960-0E88-46E3-8935-A90F2A18AE2E</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_1090FDF5-3215-42D2-BA40-0A2BE53B7042"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "014398"
      }],
      "name" : "Actrapid Penfill inj, oppl 100 IE/ml",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/Diabetes-MPD-4"
      }]
    }
  }]
}

```
