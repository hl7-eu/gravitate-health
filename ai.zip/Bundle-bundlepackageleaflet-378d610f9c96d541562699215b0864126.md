# ePI document Bundle for zithromax (azithromycin) 250 mg capsules - Jordanian Package Leaflet - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for zithromax (azithromycin) 250 mg capsules - Jordanian Package Leaflet**

## Example Bundle: ePI document Bundle for zithromax (azithromycin) 250 mg capsules - Jordanian Package Leaflet

**Composition category:**

**Composition status:**final

### B. Package Leaflet

 

Zithromax®

ZITHROMAX 250 mg hard capsules

Azithromycin

Reference Market : UK

PACKAGE LEAFLET


#### Package leaflet: Information for the patient

 

ZITHROMAX® 250 mg Capsules

azithromycin

Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.

* Keep this leaflet. You may need to read it again.
* If you have any further questions, ask your doctor or pharmacist.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.
* If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.


#### What is in this leaflet

 

1. What Zithromax is and what it is used for
1. What you need to know before you take Zithromax
1. How to take Zithromax
1. Possible side effects
1. How to store Zithromax
1. Contents of the pack and other information


#### 1. What Zithromax is and what it is used for

 

This medicine contains azithromycin, which is one of a group of antibiotics called macrolides. It is used to treat infections caused by certain bacteria and other micro-organisms, which include:

* chest, throat or nasal infections (such as bronchitis, pneumonia, tonsillitis, sore throat (pharyngitis) and sinusitis)
* ear infections
* skin and soft tissue infections (such as an abscess or boil)
* sexually transmitted diseases caused by organisms called Chlamydia trachomatis and Neisseria gonorrhoea.

You must talk to a doctor if you do not feel better or if you feel worse.


#### 2. What you need to know before you take Zithromax

 

**Do not take Zithromax:**

• if you are allergic to azithromycin or any other macrolide antibiotic such as erythromycin or clarithromycin or any of the ingredients of this medicine (listed in section 6). An allergic reaction may cause skin rash or wheezing.

**Warnings and precautions**

Talk to your doctor or pharmacist before taking Zithromax if you have or have had any of the following conditions:

* kidney problems
* heart conditions
* liver problems: your doctor may need to monitor your liver function or stop the treatment
* myasthenia gravis (a condition that causes certain muscles to become weak)
* or if you are taking any ergot derivatives such as ergotamine (used to treat migraine) as these medicines should not be taken together with Zithromax.

Tell your doctor immediately if you feel your heart beating in your chest or have an abnormal heartbeat, or get dizzy or faint or suffer from any muscle weakness when taking Zithromax.

If you develop diarrhoea or loose stools during or after treatment, tell your doctor at once. Do not take any medicine to treat your diarrhoea without first checking with your doctor. If your diarrhoea continues, please inform your doctor.

**Other medicines and Zithromax**

Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines.

In particular, Zithromax may interact with the medicines listed below:

* ergot or ergotamine – see ‘Warnings and precautions’ section
* warfarin or any similar medicine to prevent blood clots
* ciclosporin (used to suppress the immune system to prevent and treat rejection of a transplanted organ or bone marrow)
* antacids (for indigestion)
* digoxin (used to treat heart failure)
* colchicine (used for gout and familial Mediterranean fever)
* terfenadine (for hay fever or a skin allergy).

**Zithromax with food and drink**

You should take Zithromax either 1 hour before a meal or 2 hours after a meal.

**Pregnancy, breast-feeding and fertility**

If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor or pharmacist for advice before taking this medicine.

**Driving and using machines**

Zithromax is not expected to affect your ability to drive or use machines.

**Zithromax capsules contain lactose**, a type of sugar. If you have been told by your doctor that you have an intolerance to some sugars contact your doctor before taking this medicine.

**Zithromax capsules contain sulfur dioxide**, which may rarely cause severe allergic (hypersensitivity) reactions and wheezing (bronchospasm).

**Information on sodium content**

Zithromax contains less than 1 mmol sodium (23 mg) per capsule, that is to say essentially ‘sodium free’.


#### 3. How to take Zithromax

 

Always take this medicine exactly as your doctor has told you. Check with your doctor or pharmacist if you are not sure. The capsules should be swallowed whole.

The recommended dose in adults and children over 7 stones (45 kg) is 500 mg (2 capsules) taken together, once a day, for 3 days. For some diseases such as Chlamydia the recommended dose is 1 g (4 capsules) taken all together on one day only. For gonorrhoea the recommended dose is 1 g or 2 g of azithromycin in combination with 250 or 500 mg of ceftriaxone.

Zithromax capsules should not be taken by children weighing less than 45 kg.

You should tell your doctor if you have kidney or liver problems as your doctor may need to alter the normal dose.

Doctors sometimes prescribe different doses to the recommended dose. The label on the pack will tell you which dose you should take. If you are still not sure, ask your doctor or pharmacist.

Always continue with the course even if you feel better. If your infection gets worse or you do not start to feel better within a few days or a new infection develops, go back and see your doctor.

**If you take more Zithromax than you should**

If you take too much Zithromax you may feel unwell. Tell your doctor or contact your nearest hospital casualty department immediately.

**If you forget to take Zithromax**

If you forget to take Zithromax take it as soon as you can. Take your next dose at the right time. Do not take a double dose to make up for a forgotten dose.

**If you stop taking Zithromax**

If you stop taking Zithromax too soon, the infection may return. Take the capsules for the full time of treatment, even when you begin to feel better.

If you have any further questions about the use of this medicine, ask your doctor or pharmacist.


#### 4. Possible side effects

 

Like all medicines, this medicine can cause side effects although not everybody gets them.

**Tell your doctor immediately if you experience any of the following symptoms after taking this medicine as the symptoms can be severe.**

* sudden wheeziness, difficulty in breathing, swelling of eyelids, face or lips, rash or itching (especially affecting the whole body)
* severe or prolonged diarrhoea, which may have blood or mucus in it, during or after treatment with Zithromax as this may be a sign of serious bowel inflammation
* severe skin rash causing redness and flaking
* rapid or irregular heartbeat
* low blood pressure
* Serious skin reactions:
* 
* blistering of the skin, mouth, eyes and genitals (Stevens-Johnson Syndrome (SJS))
* blistering of the skin, severe skin reaction (Toxic Epidermal Necrosis (TEN))
* skin rash accompanied by other symptoms such as fever, swollen glands and an increase of eosinophils (a type of white blood cell). A rash appears as small, itchy red bumps (Drug Reaction with Eosinophilia and Systemic Symptoms (DRESS))
* skin eruption that is characterised by the rapid appearance of areas of red skin studded with small pustules (small blisters filled with white/yellow fluid) (Acute Generalized Exanthematous Pustulosis (AGEP)).

Stop taking azithromycin if you develop these skin symptoms and contact your doctor or seek medical attention immediately.

The most common side effects that occur when taking Zithromax are listed below. These may go away during treatment as your body adjusts to the medicine. Tell your doctor if any of these side effects continue to bother you.

**Very common:** may affect more than 1 in 10 people

* stomach cramps, feeling sick, diarrhoea, wind

**Common:** may affect up to 1 in 10 people

* dizziness, headache
* numbness or pins and needles
* being sick, indigestion
* loss of appetite, taste disturbance
* visual disturbances, deafness
* skin rash and /or itching
* joint pain
* low numbers of lymphocytes (a type of white blood cell), higher number of eosinophils (a type of white blood cell)
* low blood bicarbonate
* tiredness or weakness

**Uncommon:** may affect up to 1 in 100 people

* yeast infections of the mouth and vagina (thrush)
* low numbers of leukocytes (a type of white blood cell), low number of neutrophils (a type of white blood cell)
* allergic reactions of various severity
* skin more sensitive to sunlight than normal
* feeling nervous
* reduced sense of touch or sensation (hypoesthesia)
* sleepiness or sleeplessness (insomnia)
* poor hearing or ringing in the ears
* heart palpitations, chest pain
* constipation, stomach pain associated with diarrhoea and fever
* inflammation of the liver (hepatitis), changes in liver enzymes
* general loss of strength
* swelling
* general discomfort
* abnormal laboratory test values (e.g. blood or liver tests).

**Rare:** may affect up to 1 in 1,000 people

* agitation
* vertigo
* changes in liver function

**Not known: frequency cannot be estimated from the available data**

* fits or fainting
* aggression or anxiety
* feeling hyperactive
* localised muscle weakness
* loss of smell or altered sense of smell, loss of taste
* tongue discolouration
* inflammation of the pancreas (pancreatitis)
* inflammation of the kidney or kidney failure
* yellowing of the skin or eyes (jaundice) or liver failure (rarely life-threatening)
* bruising or prolonged bleeding after injury
* abnormal electrocardiogram (ECG)
* reduction in red blood cells which can make the skin pale and cause weakness or breathlessness.

**Reporting of side effects**

If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly

By reporting side affects you can help provide more information on the safety of this medicine.


#### 5. How to store Zithromax

 

Keep out of the sight and reach of children.

Store below 30°C.

Do not use this Zithromax after the expiry date which is stated on the carton and blister after “EXP”. The expiry date refers to the last day of that month.

Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.


#### 6. Contents of the pack and other information

 

**What Zithromax contains**

The active substance is azithromycin (250 mg).

The other ingredients are lactose anhydrous (see section 2, Zithromax capsules contain lactose), magnesium stearate, maize starch, sodium lauryl sulfate, gelatin, iron oxide (black) E172, shellac, propylene glycol, sulfur dioxide (see section 2 Zithromax capsules contain sulfur dioxide) and titanium dioxide.

**What Zithromax looks like and contents of the pack**

Zithromax capsules are white hard gelatin capsules marked Pfizer and ZTM 250. They come in blister packs of 4 or 6.

Not all pack sizes may be marketed.

**MARKETING AUTHORISATION HOLDER**

Pfizer Limited, Ramsgate Road, Sandwich, Kent, CT13 9NJ, United Kingdom.

**MANUFACTURER, PACKAGER & RELEASER**

Haupt Pharma Latina S.r.l. S.S. 156, Km 47.600; Borgo San Michele, 04100 Latina, Italy

This leaflet was last revised in: **November 2020**

* * Medicament is a product which affects your health and its consumption contrary to instructions is dangerous for you.
* Follow strictly the doctor's prescription, the method of use and the instructions of the Pharmacist who sold the medicament.
* The doctor and the Pharmacist are experts in medicines, their benefits and risks.
* Do not by yourself interrupt the period of treatment prescribed.
* Do not repeat the same prescription without consulting your doctor.
**Keep all medicaments out of reach and sight of children****Council of Arab Health Ministers****Union of Arabic Pharmacists**: **THIS IS A MEDICAMENT**


####  zithromax (azithromycin) 250 mg capsules 
JFDA.JO:
** placeholder **
-------

Full name: **zithromax (azithromycin) 250 mg capsules**

 - : ** zithromax ** 

 - : ** azithromycin ** 

 - : ** 250 mg ** 

 - : ** Capsule, hard ** 

 Name usage: **English (Jordan)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundlepackageleaflet-378d610f9c96d541562699215b0864126",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.jfda.jo",
    "value" : "placeholder"
  },
  "type" : "document",
  "timestamp" : "2023-06-20T13:28:17Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/compositionzi1846d2b12fecbbb0310cd8c196c98a58",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "compositionzi1846d2b12fecbbb0310cd8c196c98a58",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_compositionzi1846d2b12fecbbb0310cd8c196c98a58\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition compositionzi1846d2b12fecbbb0310cd8c196c98a58</b></p><a name=\"compositionzi1846d2b12fecbbb0310cd8c196c98a58\"> </a><a name=\"hccompositionzi1846d2b12fecbbb0310cd8c196c98a58\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>https://www.jfda.jo</code>/placeholder</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://www.jfda.jo/ 100000155538}\">Package Leaflet</span></p><p><b>date</b>: 2023-06-20 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-378d610f9c96d541562699215b0864126.html#Organization_org-1134a7374c78f1d40f41885344f06a5a\">Organization Pfizer Limited</a></p><p><b>title</b>: TEST PURPOSES ONLY - Zithromax (azithromycin) 250 mg capsules</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2023-06-20 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://www.jfda.jo",
        "value" : "placeholder"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://www.jfda.jo/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/zi5fb1761a0a38bea0a9b49f146371c68b"
      }],
      "date" : "2023-06-20T13:28:17Z",
      "author" : [{
        "reference" : "Organization/org-1134a7374c78f1d40f41885344f06a5a"
      }],
      "title" : "TEST PURPOSES ONLY - Zithromax (azithromycin) 250 mg capsules",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2023-06-20T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://www.jfda.jo/",
            "code" : "100000155538"
          }],
          "text" : "B. PACKAGE LEAFLET"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Zithromax®</p><p>ZITHROMAX 250 mg hard capsules</p><p>Azithromycin</p><p>Reference Market : UK</p><p>PACKAGE LEAFLET</p></div>"
        },
        "section" : [{
          "title" : "Package leaflet: Information for the patient",
          "code" : {
            "coding" : [{
              "system" : "https://www.jfda.jo/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the patient"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>ZITHROMAX® 250 mg Capsules</p><p>azithromycin</p><p>Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.</p><ul><li>Keep this leaflet. You may need to read it again.</li><li>If you have any further questions, ask your doctor or pharmacist.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.</li><li>If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.</li></ul></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://www.jfda.jo/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><ol><li>What Zithromax is and what it is used for</li><li>What you need to know before you take Zithromax</li><li>How to take Zithromax</li><li>Possible side effects</li><li>How to store Zithromax</li><li>Contents of the pack and other information</li></ol></div>"
          }
        },
        {
          "title" : "1. What Zithromax is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://www.jfda.jo/",
              "code" : "100000155538"
            }],
            "text" : "1. What x is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>This medicine contains azithromycin, which is one of a group of antibiotics called macrolides. It is used to treat infections caused by certain bacteria and other micro-organisms, which include:</p><ul><li>chest, throat or nasal infections (such as bronchitis, pneumonia, tonsillitis, sore throat (pharyngitis) and sinusitis)</li><li>ear infections</li><li>skin and soft tissue infections (such as an abscess or boil)</li><li>sexually transmitted diseases caused by organisms called Chlamydia trachomatis and Neisseria gonorrhoea.</li></ul><p>You must talk to a doctor if you do not feel better or if you feel worse.</p></div>"
          }
        },
        {
          "title" : "2. What you need to know before you take Zithromax",
          "code" : {
            "coding" : [{
              "system" : "https://www.jfda.jo/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take x"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><b>Do not take Zithromax:</b></p><p>• if you are allergic to azithromycin or any other macrolide antibiotic such as erythromycin or clarithromycin or any of the ingredients of this medicine (listed in section 6). An allergic reaction may cause skin rash or wheezing.</p><p><b>Warnings and precautions</b></p><p>Talk to your doctor or pharmacist before taking Zithromax if you have or have had any of the following conditions:</p><ul><li>kidney problems</li><li>heart conditions</li><li>liver problems: your doctor may need to monitor your liver function or stop the treatment</li><li>myasthenia gravis (a condition that causes certain muscles to become weak)</li><li>or if you are taking any ergot derivatives such as ergotamine (used to treat migraine) as these medicines should not be taken together with Zithromax.</li></ul><p>Tell your doctor immediately if you feel your heart beating in your chest or have an abnormal heartbeat, or get dizzy or faint or suffer from any muscle weakness when taking Zithromax.</p><p>If you develop diarrhoea or loose stools during or after treatment, tell your doctor at once. Do not take any medicine to treat your diarrhoea without first checking with your doctor. If your diarrhoea continues, please inform your doctor.</p><p><b>Other medicines and Zithromax</b></p><p>Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines.</p><p>In particular, Zithromax may interact with the medicines listed below:</p><ul><li>ergot or ergotamine – see ‘Warnings and precautions’ section</li><li>warfarin or any similar medicine to prevent blood clots</li><li>ciclosporin (used to suppress the immune system to prevent and treat rejection of a transplanted organ or bone marrow)</li><li>antacids (for indigestion)</li><li>digoxin (used to treat heart failure)</li><li>colchicine (used for gout and familial Mediterranean fever)</li><li>terfenadine (for hay fever or a skin allergy).</li></ul><p><b>Zithromax with food and drink</b></p><p>You should take Zithromax either 1 hour before a meal or 2 hours after a meal.</p><p><b>Pregnancy, breast-feeding and fertility</b></p><p>If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor or pharmacist for advice before taking this medicine.</p><p><b>Driving and using machines</b></p><p>Zithromax is not expected to affect your ability to drive or use machines.</p><p><b>Zithromax capsules contain lactose</b>, a type of sugar. If you have been told by your doctor that you have an intolerance to some sugars contact your doctor before taking this medicine.</p><p><b>Zithromax capsules contain sulfur dioxide</b>, which may rarely cause severe allergic (hypersensitivity) reactions and wheezing (bronchospasm).</p><p><b>Information on sodium content</b></p><p>Zithromax contains less than 1 mmol sodium (23 mg) per capsule, that is to say essentially ‘sodium free’.</p></div>"
          }
        },
        {
          "title" : "3. How to take Zithromax",
          "code" : {
            "coding" : [{
              "system" : "https://www.jfda.jo/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take x"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Always take this medicine exactly as your doctor has told you. Check with your doctor or pharmacist if you are not sure. The capsules should be swallowed whole.</p><p>The recommended dose in adults and children over 7 stones (45 kg) is 500 mg (2 capsules) taken together, once a day, for 3 days. For some diseases such as Chlamydia the recommended dose is 1 g (4 capsules) taken all together on one day only. For gonorrhoea the recommended dose is 1 g or 2 g of azithromycin in combination with 250 or 500 mg of ceftriaxone.</p><p>Zithromax capsules should not be taken by children weighing less than 45 kg.</p><p>You should tell your doctor if you have kidney or liver problems as your doctor may need to alter the normal dose.</p><p>Doctors sometimes prescribe different doses to the recommended dose. The label on the pack will tell you which dose you should take. If you are still not sure, ask your doctor or pharmacist.</p><p>Always continue with the course even if you feel better. If your infection gets worse or you do not start to feel better within a few days or a new infection develops, go back and see your doctor.</p><p><b>If you take more Zithromax than you should</b></p><p>If you take too much Zithromax you may feel unwell. Tell your doctor or contact your nearest hospital casualty department immediately.</p><p><b>If you forget to take Zithromax</b></p><p>If you forget to take Zithromax take it as soon as you can. Take your next dose at the right time. Do not take a double dose to make up for a forgotten dose.</p><p><b>If you stop taking Zithromax</b></p><p>If you stop taking Zithromax too soon, the infection may return. Take the capsules for the full time of treatment, even when you begin to feel better.</p><p>If you have any further questions about the use of this medicine, ask your doctor or pharmacist.</p></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://www.jfda.jo/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Like all medicines, this medicine can cause side effects although not everybody gets them.</p><p><b>Tell your doctor immediately if you experience any of the following symptoms after taking this medicine as the symptoms can be severe.</b></p><ul><li>sudden wheeziness, difficulty in breathing, swelling of eyelids, face or lips, rash or itching (especially affecting the whole body)</li><li>severe or prolonged diarrhoea, which may have blood or mucus in it, during or after treatment with Zithromax as this may be a sign of serious bowel inflammation</li><li>severe skin rash causing redness and flaking</li><li>rapid or irregular heartbeat</li><li>low blood pressure</li><li>Serious skin reactions:</li><li><ul><li>blistering of the skin, mouth, eyes and genitals (Stevens-Johnson Syndrome (SJS))</li><li>blistering of the skin, severe skin reaction (Toxic Epidermal Necrosis (TEN))</li><li>skin rash accompanied by other symptoms such as fever, swollen glands and an increase of eosinophils (a type of white blood cell). A rash appears as small, itchy red bumps (Drug Reaction with Eosinophilia and Systemic Symptoms (DRESS))</li><li>skin eruption that is characterised by the rapid appearance of areas of red skin studded with small pustules (small blisters filled with white/yellow fluid) (Acute Generalized Exanthematous Pustulosis (AGEP)).</li></ul></li></ul><p>Stop taking azithromycin if you develop these skin symptoms and contact your doctor or seek medical attention immediately.</p><p>The most common side effects that occur when taking Zithromax are listed below. These may go away during treatment as your body adjusts to the medicine. Tell your doctor if any of these side effects continue to bother you.</p><p><b>Very common:</b> may affect more than 1 in 10 people</p><ul><li>stomach cramps, feeling sick, diarrhoea, wind</li></ul><p><b>Common:</b> may affect up to 1 in 10 people</p><ul><li>dizziness, headache</li><li>numbness or pins and needles</li><li>being sick, indigestion</li><li>loss of appetite, taste disturbance</li><li>visual disturbances, deafness</li><li>skin rash and /or itching</li><li>joint pain</li><li>low numbers of lymphocytes (a type of white blood cell), higher number of eosinophils (a type of white blood cell)</li><li>low blood bicarbonate</li><li>tiredness or weakness</li></ul><p><b>Uncommon:</b> may affect up to 1 in 100 people</p><ul><li>yeast infections of the mouth and vagina (thrush)</li><li>low numbers of leukocytes (a type of white blood cell), low number of neutrophils (a type of white blood cell)</li><li>allergic reactions of various severity</li><li>skin more sensitive to sunlight than normal</li><li>feeling nervous</li><li>reduced sense of touch or sensation (hypoesthesia)</li><li>sleepiness or sleeplessness (insomnia)</li><li>poor hearing or ringing in the ears</li><li>heart palpitations, chest pain</li><li>constipation, stomach pain associated with diarrhoea and fever</li><li>inflammation of the liver (hepatitis), changes in liver enzymes</li><li>general loss of strength</li><li>swelling</li><li>general discomfort</li><li>abnormal laboratory test values (e.g. blood or liver tests).</li></ul><p><b>Rare:</b> may affect up to 1 in 1,000 people</p><ul><li>agitation</li><li>vertigo</li><li>changes in liver function</li></ul><p><b>Not known: frequency cannot be estimated from the available data</b></p><ul><li>fits or fainting</li><li>aggression or anxiety</li><li>feeling hyperactive</li><li>localised muscle weakness</li><li>loss of smell or altered sense of smell, loss of taste</li><li>tongue discolouration</li><li>inflammation of the pancreas (pancreatitis)</li><li>inflammation of the kidney or kidney failure</li><li>yellowing of the skin or eyes (jaundice) or liver failure (rarely life-threatening)</li><li>bruising or prolonged bleeding after injury</li><li>abnormal electrocardiogram (ECG)</li><li>reduction in red blood cells which can make the skin pale and cause weakness or breathlessness.</li></ul><p><b>Reporting of side effects</b></p><p>If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly</p><p></p><p>By reporting side affects you can help provide more information on the safety of this medicine.</p></div>"
          }
        },
        {
          "title" : "5. How to store Zithromax",
          "code" : {
            "coding" : [{
              "system" : "https://www.jfda.jo/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store x"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keep out of the sight and reach of children.</p><p>Store below 30°C.</p><p>Do not use this Zithromax after the expiry date which is stated on the carton and blister after “EXP”. The expiry date refers to the last day of that month.</p><p>Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://www.jfda.jo/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><b>What Zithromax contains</b></p><p>The active substance is azithromycin (250 mg).</p><p>The other ingredients are lactose anhydrous (see section 2, Zithromax capsules contain lactose), magnesium stearate, maize starch, sodium lauryl sulfate, gelatin, iron oxide (black) E172, shellac, propylene glycol, sulfur dioxide (see section 2 Zithromax capsules contain sulfur dioxide) and titanium dioxide.</p><p><b>What Zithromax looks like and contents of the pack</b></p><p>Zithromax capsules are white hard gelatin capsules marked Pfizer and ZTM 250. They come in blister packs of 4 or 6.</p><p>Not all pack sizes may be marketed.</p><p><b>MARKETING AUTHORISATION HOLDER</b></p><p>Pfizer Limited, Ramsgate Road, Sandwich, Kent, CT13 9NJ, United Kingdom.</p><p><b>MANUFACTURER, PACKAGER &amp; RELEASER</b></p><p>Haupt Pharma Latina S.r.l. S.S. 156, Km 47.600; Borgo San Michele, 04100 Latina, Italy</p><p>This leaflet was last revised in: <b>November 2020</b></p><table border=\"1\" cellpadding=\"1\" cellspacing=\"1\"><tbody><tr><td><strong>THIS IS A MEDICAMENT</strong></td></tr><tr><td><ul><li>Medicament is a product which affects your health and its consumption contrary to instructions is dangerous for you.</li><li>Follow strictly the doctor's prescription, the method of use and the instructions of the Pharmacist who sold the medicament.</li><li>The doctor and the Pharmacist are experts in medicines, their benefits and risks.</li><li>Do not by yourself interrupt the period of treatment prescribed.</li><li>Do not repeat the same prescription without consulting your doctor.</li></ul><p><b>Keep all medicaments out of reach and sight of children</b></p><p><b>Council of Arab Health Ministers</b></p><p><b>Union of Arabic Pharmacists</b></p></td></tr></tbody></table></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/org-1134a7374c78f1d40f41885344f06a5a",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "org-1134a7374c78f1d40f41885344f06a5a",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_org-1134a7374c78f1d40f41885344f06a5a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization org-1134a7374c78f1d40f41885344f06a5a</b></p><a name=\"org-1134a7374c78f1d40f41885344f06a5a\"> </a><a name=\"hcorg-1134a7374c78f1d40f41885344f06a5a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100008368 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Pfizer Limited</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Ramsgate Road, Sandwich, Kent, CT13 9NJ, United Kingdom(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100008368"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }],
        "text" : "Marketing authorisation holder"
      }],
      "name" : "Pfizer Limited",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Ramsgate Road, Sandwich, Kent, CT13 9NJ, United Kingdom",
          "line" : ["Ramsgate Road, Sandwich, Kent, CT13 9NJ"],
          "city" : "Sandwich, Kent",
          "country" : "UK"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/zi5fb1761a0a38bea0a9b49f146371c68b",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "zi5fb1761a0a38bea0a9b49f146371c68b",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_zi5fb1761a0a38bea0a9b49f146371c68b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition zi5fb1761a0a38bea0a9b49f146371c68b</b></p><a name=\"zi5fb1761a0a38bea0a9b49f146371c68b\"> </a><a name=\"hczi5fb1761a0a38bea0a9b49f146371c68b\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://jfda.jo</code>/placeholder</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: zithromax (azithromycin) 250 mg capsules</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: zithromax</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: azithromycin</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 250 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Capsule, hard</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 JO}\">Jordan</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 JO}\">Jordan</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://jfda.jo",
        "value" : "placeholder"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "zithromax (azithromycin) 250 mg capsules",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001"
          }],
          "text" : "Full name"
        },
        "part" : [{
          "part" : "zithromax",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002"
            }],
            "text" : "Invented name part"
          }
        },
        {
          "part" : "azithromycin",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003"
            }],
            "text" : "Scientific name part"
          }
        },
        {
          "part" : "250 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004"
            }],
            "text" : "Strength part"
          }
        },
        {
          "part" : "Capsule, hard",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005"
            }],
            "text" : "Pharmaceutical dose form part"
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "JO",
              "display" : "Jordan"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "JO",
              "display" : "Jordan"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  }]
}

```
