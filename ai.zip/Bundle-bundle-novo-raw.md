# ePI document Bundle for Novorapid Flexpen 100 units/ml solution for injection in pre-filled pen Package Leaflet for language en - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ePI document Bundle for Novorapid Flexpen 100 units/ml solution for injection in pre-filled pen Package Leaflet for language en**

## Example Bundle: ePI document Bundle for Novorapid Flexpen 100 units/ml solution for injection in pre-filled pen Package Leaflet for language en

**Composition category:**Raw

**Composition status:**final

### B. Package Leaflet

#### Package leaflet: Information for the user

#### What is in this leaflet

 

What is in this leaflet

1. What NovoRapid is and what it is used for
1. What you need to know before you use NovoRapid
1. How to use NovoRapid
1. Possible side effects
1. How to store NovoRapid
1. Contents of the pack and other information


#### 1. What novorapid is and what it is used for

 

NovoRapid is a modern insulin (insulin analogue) with a rapid-acting effect. Modern insulin products are improved versions of human insulin.

NovoRapid is used to reduce the high blood sugar level in adults, adolescents and children aged 1 year and above with diabetes mellitus (diabetes). Diabetes is a disease where your body does not produce enough insulin to control the level of your blood sugar. Treatment with NovoRapid helps to prevent complications from your diabetes.

NovoRapid will start to lower your blood sugar 10 20 minutes after you inject it, a maximum effect occurs between 1 and 3 hours after the injection and the effect lasts for 3 5 hours. Due to this short action NovoRapid should normally be taken in combination with intermediate-acting or long-acting insulin preparations. Moreover NovoRapid can be used for continuous infusion in a pump system.


#### 2. What you need to know before you take novorapid

 

Do not use NovoRapid

If you are allergic to insulin aspart, or any of the other ingredients in this medicine (see section 6, Contents of the pack and other information).

If you suspect hypoglycaemia (low blood sugar) is starting (see a) Summary of serious and very common side effects in section 4).

If the protective cap is loose or missing. Each vial has a protective, tamper-proof plastic cap. If it is not in perfect condition when you get the vial, return the vial to your supplier.

If it has not been stored correctly or been frozen (see section 5, How to store NovoRapid).

If the insulin does not appear clear and colourless.

If any of these applies, do not use NovoRapid. Talk with your doctor, nurse or pharmacist for advice.

Before using NovoRapid

Check the label to make sure it is the right type of insulin.

Remove the protective cap.

Always use a new needle for each injection to prevent contamination.

Needles and syringes must not be shared.

Warnings and precautions

Some conditions and activities can affect your need for insulin. Consult your doctor:

If you have trouble with your kidneys or liver, or with your adrenal, pituitary or thyroid glands.

If you exercise more than usual or if you want to change your usual diet, as this may affect your blood sugar level.

If you are ill, carry on taking your insulin and consult your doctor.

If you are going abroad, travelling over time zones may affect your insulin needs and the timing of your injections.

Skin changes at the injection site

The injection site should be rotated to help prevent changes to the fatty tissue under the skin, such as skin thickening, skin shrinking or lumps under the skin. The insulin may not work very well if you inject into a lumpy, shrunken or thickened area (see section 3, How to use NovoRapid). Tell your doctor if you notice any skin changes at the injection site. Tell your doctor if you are currently injecting into these affected areas before you start injecting in a different area. Your doctor may tell you to check your blood sugar more closely, and to adjust your insulin or your other antidiabetic medications dose.

Children and adolescents

Do not give this medicine to children below 1 year of age since no clinical studies have been carried out in children below the age of 1 year.

Other medicines and NovoRapid

Tell your doctor, nurse or pharmacist if you are taking, have recently taken or might take any other medicines. Some medicines affect your blood sugar level and this may mean that your insulin dose has to change. Listed below are the most common medicines which may affect your insulin treatment.

Your blood sugar level may fall (hypoglycaemia) if you take: * Other medicines for the treatment of diabetes * Monoamine oxidase inhibitors (MAOI) (used to treat depression) * Beta-blockers (used to treat high blood pressure) * Angiotensin converting enzyme (ACE) inhibitors (used to treat certain heart conditions or high blood pressure) * Salicylates (used to relieve pain and lower fever) * Anabolic steroids (such as testosterone) * Sulphonamides (used to treat infections).

Your blood sugar level may rise (hyperglycaemia) if you take: * Oral contraceptives (birth control pills) * Thiazides (used to treat high blood pressure or excessive fluid retention) * Glucocorticoids (such as cortisone used to treat inflammation) * Thyroid hormones (used to treat thyroid gland disorders) * Sympathomimetics (such as epinephrine [adrenaline], or salbutamol, terbutaline used to treat asthma) * Growth hormone (medicine for stimulation of skeletal and somatic growth and pronounced influence on the body s metabolic processes) * Danazol (medicine acting on ovulation).

Octreotide and lanreotide (used for treatment of acromegaly, a rare hormonal disorder that usually occurs in middle-aged adults, caused by the pituitary gland producing excess growth hormone) may either increase or decrease your blood sugar level.

Beta-blockers (used to treat high blood pressure) may weaken or suppress entirely the first warning symptoms which help you to recognise low blood sugar.

Pioglitazone (tablets used for the treatment of type 2 diabetes) Some patients with long-standing type 2 diabetes and heart disease or previous stroke who were treated with pioglitazone and insulin experienced the development of heart failure. Inform your doctor as soon as possible if you experience signs of heart failure such as unusual shortness of breath or rapid increase in weight or localised swelling (oedema).

If you have taken any of the medicines listed here, tell your doctor, nurse or pharmacist.

Drinking alcohol and taking NovoRapid

If you drink alcohol, your need for insulin may change as your blood sugar level may either rise or fall. Careful monitoring is recommended.

Pregnancy and breast-feeding

If you are pregnant, think you may be pregnant or are planning to have a baby, ask your doctor for advice before taking this medicine. NovoRapid can be used during pregnancy. Your insulin dose may need to be changed during pregnancy and after delivery. Careful control of your diabetes, particularly prevention of hypoglycaemia, is important for the health of your baby.

There are no restrictions on treatment with NovoRapid during breast-feeding.

Ask your doctor, nurse or pharmacist for advice before taking this medicine while pregnant or breast- feeding.

Driving and using machines

Please ask your doctor whether you can drive a car or operate a machine: * If you have frequent hypoglycaemia.
* If you find it hard to recognise hypoglycaemia.

If your blood sugar is low or high, your concentration and ability to react might be affected and therefore also your ability to drive or operate a machine. Bear in mind that you could endanger yourself or others.

NovoRapid has a rapid onset of effect therefore if hypoglycaemia occurs, you may experience it earlier after an injection when compared to soluble human insulin.

Important information about some of the ingredients of NovoRapid

NovoRapid contains less than 1 mmol sodium (23 mg) per dose, i.e. NovoRapid is essentially sodium-free .


#### 3. How to take novorapid

 

Dose and when to take your insulin

Always use your insulin and adjust your dose exactly as your doctor has told you. Check with your doctor, nurse or pharmacist if you are not sure.

NovoRapid is generally taken immediately before a meal. Eat a meal or snack within 10 minutes of the injection to avoid low blood sugar. When necessary, NovoRapid can be given soon after a meal. See How and where to inject below for information.

Do not change your insulin unless your doctor tells you to. If your doctor has switched you from one type or brand of insulin to another, your dose may have to be adjusted by your doctor.

Use in children and adolescents

NovoRapid can be used in adolescents and children aged 1 year and above instead of soluble human insulin when a rapid onset of effect is preferred. For example, when it is difficult to dose the child in relation to meals.

Use in special patient groups

If you have reduced kidney or liver function, or if you are above 65 years of age, you need to check your blood sugar more regularly and discuss changes in your insulin dose with your doctor.

How and where to inject

NovoRapid is for injection under the skin (subcutaneously) or for continuous infusion in a pump system. Administration in a pump system will require a comprehensive instruction by your healthcare professional. You must never inject yourself directly into a vein (intravenously) or muscle (intramuscularly). If necessary NovoRapid can be given directly into a vein but this must only be done by physicians or other healthcare staff.

With each injection, change the injection site within the particular area of skin that you use. This may reduce the risk of developing lumps or skin pitting (see section 4, Possible side effects). The best places to give yourself an injection are: the front of your waist (abdomen), the upper arm or the front of your thighs. The insulin will work more quickly if injected into the front of your waist. You should always measure your blood sugar regularly.

NPH (Neutral Protamine Hagedorn) insulin is the only type of insulin that can be mixed with NovoRapid and the mixture must be injected immediately under your skin (subcutaneously). NovoRapid should be drawn into the syringe before you draw your NPH insulin.

How to take NovoRapid

If you use only one type of insulin 1. Draw into the syringe the same amount of air as the dose of insulin you are going to inject. Inject the air into the vial. 2. Turn the vial and syringe upside down and draw the correct insulin dose into the syringe. Pull the needle out of the vial. Then expel the air from the syringe and check that the dose is correct.

If you have to mix two types of insulin 1. Just before use, roll the NPH insulin between your hands until the liquid is uniformly white and cloudy. 2. Draw into the syringe the same amount of air as the dose of the NPH insulin. Inject the air into the vial containing the NPH insulin and pull out the needle. 3. Draw into the syringe the same amount of air as the dose of NovoRapid. Inject the air into the vial containing NovoRapid. Turn the vial and syringe upside down and draw up the prescribed dose of NovoRapid. Expel any air from the syringe and check that the dose is correct. 4. Push the needle into the vial of the NPH insulin, turn the vial and syringe upside down and draw out the dose you have been prescribed. Expel any air from the syringe and check the dose. Inject the mixture immediately. 5. Always mix NovoRapid and the NPH insulin in the same sequence.

How to inject NovoRapid

Inject the insulin under the skin. Use the injection technique advised by your doctor or nurse.

Keep the needle under your skin for at least 6 seconds to make sure you have injected all the insulin.

Discard the needle after each injection.

For use in an infusion pump system

NovoRapid should never be mixed with any other insulin when used in a pump.
Follow the instructions and recommendations from your doctor regarding the use of NovoRapid in a pump. Before use of NovoRapid in the pump system, you must have received a comprehensive instruction in the use and information about any actions to be taken in case of illness, too high or too low blood sugar or failure of the pump system.
* Before inserting the needle, use soap and water to clean your hands and the skin where the needle is inserted to avoid any infection at the infusion site. * When you fill a new reservoir, be certain not to leave large air bubbles in either the syringe or the tubing. * Changing of the infusion set (tubing and needle) must be done according to the instructions in the product information supplied with the infusion set.

To get the benefit of insulin infusion, and to detect possible malfunction of the insulin pump, it is recommended that you measure your blood sugar level regularly.

What to do in case of pump system failure

You should always have an alternative delivery method for your insulin available for injection under the skin in case of pump system failure.

If you take more insulin than you should

If you take too much insulin your blood sugar gets too low (hypoglycaemia). See a) Summary of serious and very common side effects in section 4. If you forget to take your insulin

If you forget to take your insulin your blood sugar may get too high (hyperglycaemia). See c) Effects from diabetes in section 4. If you stop taking your insulin

Do not stop taking your insulin without speaking with a doctor, who will tell you what needs to be done. This could lead to very high blood sugar (severe hyperglycaemia) and ketoacidosis. See c) Effects from diabetes in section 4. If you have any further questions on the use of this medicine, ask your doctor, nurse or pharmacist.


#### 4. Possible side effects

 

Like all medicines, this medicine can cause side effects, although not everybody gets them.

a) Summary of serious and very common side effects

Low blood sugar (hypoglycaemia) is a very common side effect. It may affect more than 1 in people.

Low blood sugar may occur if you: * Inject too much insulin. * Eat too little or miss a meal. * Exercise more than usual. * Drink alcohol (see Drinking alcohol and taking NovoRapid in section 2).

Signs of low blood sugar: Cold sweat; cool pale skin; headache; rapid heartbeat; feeling sick; feeling very hungry; temporary changes in vision; drowsiness; unusual tiredness and weakness; nervousness or tremor; feeling anxious; feeling confused; difficulty in concentrating.

Severe low blood sugar can lead to unconsciousness. If prolonged severe low blood sugar is not treated, it can cause brain damage (temporary or permanent) and even death. You may recover more quickly from unconsciousness with an injection of the hormone glucagon by someone who knows how to use it. If you are given glucagon, you will need glucose or a sugar snack as soon as you are conscious. If you do not respond to glucagon treatment, you will have to be treated in a hospital.

What to do if you experience low blood sugar:

If you experience low blood sugar, eat glucose tablets or another high sugar snack (e.g. sweets, biscuits, fruit juice). Measure your blood sugar if possible and rest. Always carry glucose tablets or high sugar snacks with you, just in case.

When symptoms of low blood sugar have disappeared or when blood sugar level is stabilised, continue insulin treatment as usual.

If you have such a low blood sugar that it makes you pass out, if you have had need for injection of glucagon, or if you have experienced many incidents of low blood sugar, talk with a doctor. The amount or timing of insulin, food or exercise may need to be adjusted.

Tell relevant people that you have diabetes and what the consequences may be, including the risk of passing out (become unconscious) due to low blood sugar. Let them know that if you pass out, they must turn you on your side and get medical help straight away. They must not give you any food or drink due to risk of suffocation.

Serious allergic reactions to NovoRapid or one of its ingredients (called a systemic allergic reaction) is a very rare side effect but can potentially be life threatening. It may affect less than 1 in 10,people.

Seek medical advice immediately: * If signs of allergy spread to other parts of your body. * If you suddenly feel unwell, and you: start sweating; start being sick (vomiting); have difficulty in breathing; have a rapid heartbeat; feel dizzy.

If you notice any of these signs, seek medical advice immediately.

Skin changes at the injection site: If you inject insulin at the same place, the fatty tissue may shrink (lipoatrophy) or thicken (lipohypertrophy) (may affect less than 1 in 100 people). Lumps under the skin may also be caused by build-up of a protein called amyloid (cutaneous amyloidosis; how often this occurs is not known). The insulin may not work very well if you inject into a lumpy, shrunken or thickened area. Change the injection site with each injection to help prevent these skin changes.

b) List of other side effects

Uncommon side effects May affect less than 1 in 100 people.

Signs of allergy: Local allergic reactions (pain, redness, hives, inflammation, bruising, swelling and itching) at the injection site may occur. These usually disappear after a few weeks of taking your insulin. If they do not disappear, or if they spread throughout your body, talk to your doctor immediately. See also Serious allergic reactions above.

Vision problems: When you first start your insulin treatment, it may disturb your vision, but the disturbance is usually temporary.

Swollen joints: When you start taking insulin, water retention may cause swelling around your ankles and other joints. Normally this soon disappears. If not, talk to your doctor.

Diabetic retinopathy (an eye disease related to diabetes which can lead to loss of vision): If you have diabetic retinopathy and your blood sugar level improves very fast, the retinopathy may get worse. Ask your doctor about this.

Rare side effects
May affect less than 1 in 1,000 people.

Painful neuropathy (pain due to nerve damage): If your blood sugar level improves very fast, you may get nerve related pain. This is called acute painful neuropathy and is usually transient.

Reporting of side effects

If you get any side effects, talk with your doctor, nurse or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the national reporting system listed in Appendix V. By reporting side effects you can help provide more information on the safety of this medicine.

c) Effects from diabetes

High blood sugar (hyperglycaemia)

High blood sugar may occur if you: * Have not injected enough insulin. * Forget to inject your insulin or stop taking insulin. * Repeatedly inject less insulin than you need. * Get an infection and/or a fever. * Eat more than usual. * Exercise less than usual.

Warning signs of high blood sugar: The warning signs appear gradually. They include: increased urination; feeling thirsty; losing your appetite; feeling sick (nausea or vomiting); feeling drowsy or tired; flushed; dry skin; dry mouth and a fruity (acetone) smell of the breath.

What to do if you experience high blood sugar:

If you get any of the above signs: test your blood sugar level, test your urine for ketones if you can, then seek medical advice immediately.

These may be signs of a very serious condition called diabetic ketoacidosis (build-up of acid in the blood because the body is breaking down fat instead of sugar). If you do not treat it, this could lead to diabetic coma and eventually death.


#### 5. How to store novorapid

 

Keep this medicine out of the sight and reach of children. Do not use this medicine after the expiry date which is stated on the vial label and carton, after EXP . The expiry date refers to the last day of that month. Keep the vial in the outer carton in order to protect it from light.

Before opening: Store in a refrigerator at 2 C to 8 C, away from the cooling element. Do not freeze.

During use or when carried as a spare: The product may be stored for a maximum of 4 weeks. Store below 30 C. Do not refrigerate or freeze.

Discard the needle after each injection.

Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.


#### 6. Contents of the pack and other information

 

What NovoRapid contains

* The active substance is insulin aspart. Each ml contains 100 units of insulin aspart. Each vial contains 1,000 units of insulin aspart in 10 ml solution for injection.
* The other ingredients are glycerol, phenol, metacresol, zinc chloride, disodium phosphate dihydrate, sodium chloride, hydrochloric acid, sodium hydroxide and water for injections.

What NovoRapid looks like and contents of the pack

NovoRapid is presented as a solution for injection.

Pack sizes of 1 or 5 vials of 10 ml or a multipack of 5 packs of 1 x 10 ml vial. Not all pack sizes may be marketed.

The solution is clear and colourless.

Marketing Authorisation Holder and Manufacturer

Novo Nordisk A/S, Novo All , DK-2880 Bagsv rd, Denmark

This leaflet was last revised in

Other sources of information

Detailed information on this medicine is available on the European Medicines Agency website: http://www.ema.europa.eu. Package leaflet: Information for the user

NovoRapid Penfill 100 units/ml solution for injection in cartridge
insulin aspart

Read all of this leaflet carefully before you start using this medicine because it contains important information for you.

* Keep this leaflet. You may need to read it again.
* If you have any further questions, ask your doctor, nurse or pharmacist.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.
* If you get any side effects, talk with your doctor, nurse or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.


####  Novorapid Flexpen 100 units/ml solution for injection in pre-filled pens 
DOC:
** himss-novorapid **
-------

Full name: **Novorapid Flexpen 100 units/ml solution for injection in pre-filled pens**

 - Invented name part: ** Novorapid FlexPen ** 

 - Scientific name part: ** Insulin ** 

 - Strength part: ** 100 units/ml ** 

 - Pharmaceutical dose form part: ** solution for injection in pre-filled pens ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundle-novo-raw",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "himss-novorapid"
  },
  "type" : "document",
  "timestamp" : "2023-06-27T10:09:22Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/composition-en-novorapid",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "composition-en-novorapid",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_composition-en-novorapid\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition composition-en-novorapid</b></p><a name=\"composition-en-novorapid\"> </a><a name=\"hccomposition-en-novorapid\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>identifier</b>: <code>http://ema.europa.eu/identifier</code>/himss-novorapid</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs R}\">Raw</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: EMA</p><p><b>title</b>: TEST PURPOSES ONLY - novorapid</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://ema.europa.eu/identifier",
        "value" : "himss-novorapid"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "R",
          "display" : "Raw"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/himss-novorapid-mpd"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "display" : "EMA"
      }],
      "title" : "TEST PURPOSES ONLY - novorapid",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. Package Leaflet"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"></div>"
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>What is in this leaflet</p><ol><li>What NovoRapid is and what it is used for</li><li>What you need to know before you use NovoRapid</li><li>How to use NovoRapid</li><li>Possible side effects</li><li>How to store NovoRapid</li><li>Contents of the pack and other information</li></ol></div>"
          }
        },
        {
          "title" : "1. What novorapid is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What novorapid is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>NovoRapid is a modern insulin (insulin analogue) with a rapid-acting effect. Modern insulin products are improved versions of human insulin.</p><p>NovoRapid is used to reduce the high blood sugar level in adults, adolescents and children aged 1 year and above with diabetes mellitus (diabetes). Diabetes is a disease where your body does not produce enough insulin to control the level of your blood sugar. Treatment with NovoRapid helps to prevent complications from your diabetes.</p><p>NovoRapid will start to lower your blood sugar 10 20 minutes after you inject it, a maximum effect occurs between 1 and 3 hours after the injection and the effect lasts for 3 5 hours. Due to this short action NovoRapid should normally be taken in combination with intermediate-acting or long-acting insulin preparations. Moreover NovoRapid can be used for continuous infusion in a pump system.</p></div>"
          }
        },
        {
          "title" : "2. What you need to know before you take novorapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take novorapid"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Do not use NovoRapid</p><p>If you are allergic to insulin aspart, or any of the other ingredients in this medicine (see section 6, Contents of the pack and other information).</p><p>If you suspect hypoglycaemia (low blood sugar) is starting (see a) Summary of serious and very common side effects in section 4).</p><p>If the protective cap is loose or missing. Each vial has a protective, tamper-proof plastic cap. If it is not in perfect condition when you get the vial, return the vial to your supplier.</p><p>If it has not been stored correctly or been frozen (see section 5, How to store NovoRapid).</p><p>If the insulin does not appear clear and colourless.</p><p>If any of these applies, do not use NovoRapid. Talk with your doctor, nurse or pharmacist for advice.</p><p>Before using NovoRapid</p><p>Check the label to make sure it is the right type of insulin.</p><p>Remove the protective cap.</p><p>Always use a new needle for each injection to prevent contamination.</p><p>Needles and syringes must not be shared.</p><p>Warnings and precautions</p><p>Some conditions and activities can affect your need for insulin. Consult your doctor:</p><p>If you have trouble with your kidneys or liver, or with your adrenal, pituitary or thyroid glands.</p><p>If you exercise more than usual or if you want to change your usual diet, as this may affect your blood sugar level.</p><p>If you are ill, carry on taking your insulin and consult your doctor.</p><p>If you are going abroad, travelling over time zones may affect your insulin needs and the timing of your injections.</p><p>Skin changes at the injection site</p><p>The injection site should be rotated to help prevent changes to the fatty tissue under the skin, such as skin thickening, skin shrinking or lumps under the skin. The insulin may not work very well if you inject into a lumpy, shrunken or thickened area (see section 3, How to use NovoRapid). Tell your doctor if you notice any skin changes at the injection site. Tell your doctor if you are currently injecting into these affected areas before you start injecting in a different area. Your doctor may tell you to check your blood sugar more closely, and to adjust your insulin or your other antidiabetic medications dose.</p><p>Children and adolescents</p><p>Do not give this medicine to children below 1 year of age since no clinical studies have been carried out in children below the age of 1 year.</p><p>Other medicines and NovoRapid</p><p>Tell your doctor, nurse or pharmacist if you are taking, have recently taken or might take any other medicines. Some medicines affect your blood sugar level and this may mean that your insulin dose has to change. Listed below are the most common medicines which may affect your insulin treatment.</p><p>Your blood sugar level may fall (hypoglycaemia) if you take: * Other medicines for the treatment of diabetes * Monoamine oxidase inhibitors (MAOI) (used to treat depression) * Beta-blockers (used to treat high blood pressure) * Angiotensin converting enzyme (ACE) inhibitors (used to treat certain heart conditions or high blood pressure) * Salicylates (used to relieve pain and lower fever) * Anabolic steroids (such as testosterone) * Sulphonamides (used to treat infections).</p><p>Your blood sugar level may rise (hyperglycaemia) if you take: * Oral contraceptives (birth control pills) * Thiazides (used to treat high blood pressure or excessive fluid retention) * Glucocorticoids (such as cortisone used to treat inflammation) * Thyroid hormones (used to treat thyroid gland disorders) * Sympathomimetics (such as epinephrine [adrenaline], or salbutamol, terbutaline used to treat asthma) * Growth hormone (medicine for stimulation of skeletal and somatic growth and pronounced influence on the body s metabolic processes) * Danazol (medicine acting on ovulation).</p><p>Octreotide and lanreotide (used for treatment of acromegaly, a rare hormonal disorder that usually occurs in middle-aged adults, caused by the pituitary gland producing excess growth hormone) may either increase or decrease your blood sugar level.</p><p>Beta-blockers (used to treat high blood pressure) may weaken or suppress entirely the first warning symptoms which help you to recognise low blood sugar.</p><p>Pioglitazone (tablets used for the treatment of type 2 diabetes) Some patients with long-standing type 2 diabetes and heart disease or previous stroke who were treated with pioglitazone and insulin experienced the development of heart failure. Inform your doctor as soon as possible if you experience signs of heart failure such as unusual shortness of breath or rapid increase in weight or localised swelling (oedema).</p><p>If you have taken any of the medicines listed here, tell your doctor, nurse or pharmacist.</p><p>Drinking alcohol and taking NovoRapid</p><p>If you drink alcohol, your need for insulin may change as your blood sugar level may either rise or fall. Careful monitoring is recommended.</p><p>Pregnancy and breast-feeding</p><p>If you are pregnant, think you may be pregnant or are planning to have a baby, ask your doctor for advice before taking this medicine. NovoRapid can be used during pregnancy. Your insulin dose may need to be changed during pregnancy and after delivery. Careful control of your diabetes, particularly prevention of hypoglycaemia, is important for the health of your baby.</p><p>There are no restrictions on treatment with NovoRapid during breast-feeding.</p><p>Ask your doctor, nurse or pharmacist for advice before taking this medicine while pregnant or breast- feeding.</p><p>Driving and using machines</p><p>Please ask your doctor whether you can drive a car or operate a machine: * If you have frequent hypoglycaemia.<br/>* If you find it hard to recognise hypoglycaemia.</p><p>If your blood sugar is low or high, your concentration and ability to react might be affected and therefore also your ability to drive or operate a machine. Bear in mind that you could endanger yourself or others.</p><p>NovoRapid has a rapid onset of effect therefore if hypoglycaemia occurs, you may experience it earlier after an injection when compared to soluble human insulin.</p><p>Important information about some of the ingredients of NovoRapid</p><p>NovoRapid contains less than 1 mmol sodium (23 mg) per dose, i.e. NovoRapid is essentially sodium-free .</p></div>"
          }
        },
        {
          "title" : "3. How to take novorapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take novorapid"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Dose and when to take your insulin</p><p>Always use your insulin and adjust your dose exactly as your doctor has told you. Check with your doctor, nurse or pharmacist if you are not sure.</p><p>NovoRapid is generally taken immediately before a meal. Eat a meal or snack within 10 minutes of the injection to avoid low blood sugar. When necessary, NovoRapid can be given soon after a meal. See How and where to inject below for information.</p><p>Do not change your insulin unless your doctor tells you to. If your doctor has switched you from one type or brand of insulin to another, your dose may have to be adjusted by your doctor.</p><p>Use in children and adolescents</p><p>NovoRapid can be used in adolescents and children aged 1 year and above instead of soluble human insulin when a rapid onset of effect is preferred. For example, when it is difficult to dose the child in relation to meals.</p><p>Use in special patient groups</p><p>If you have reduced kidney or liver function, or if you are above 65 years of age, you need to check your blood sugar more regularly and discuss changes in your insulin dose with your doctor.</p><p>How and where to inject</p><p>NovoRapid is for injection under the skin (subcutaneously) or for continuous infusion in a pump system. Administration in a pump system will require a comprehensive instruction by your healthcare professional. You must never inject yourself directly into a vein (intravenously) or muscle (intramuscularly). If necessary NovoRapid can be given directly into a vein but this must only be done by physicians or other healthcare staff.</p><p>With each injection, change the injection site within the particular area of skin that you use. This may reduce the risk of developing lumps or skin pitting (see section 4, Possible side effects). The best places to give yourself an injection are: the front of your waist (abdomen), the upper arm or the front of your thighs. The insulin will work more quickly if injected into the front of your waist. You should always measure your blood sugar regularly.</p><p>NPH (Neutral Protamine Hagedorn) insulin is the only type of insulin that can be mixed with NovoRapid and the mixture must be injected immediately under your skin (subcutaneously). NovoRapid should be drawn into the syringe before you draw your NPH insulin.</p><p>How to take NovoRapid</p><p>If you use only one type of insulin 1. Draw into the syringe the same amount of air as the dose of insulin you are going to inject. Inject the air into the vial. 2. Turn the vial and syringe upside down and draw the correct insulin dose into the syringe. Pull the needle out of the vial. Then expel the air from the syringe and check that the dose is correct.</p><p>If you have to mix two types of insulin 1. Just before use, roll the NPH insulin between your hands until the liquid is uniformly white and cloudy. 2. Draw into the syringe the same amount of air as the dose of the NPH insulin. Inject the air into the vial containing the NPH insulin and pull out the needle. 3. Draw into the syringe the same amount of air as the dose of NovoRapid. Inject the air into the vial containing NovoRapid. Turn the vial and syringe upside down and draw up the prescribed dose of NovoRapid. Expel any air from the syringe and check that the dose is correct. 4. Push the needle into the vial of the NPH insulin, turn the vial and syringe upside down and draw out the dose you have been prescribed. Expel any air from the syringe and check the dose. Inject the mixture immediately. 5. Always mix NovoRapid and the NPH insulin in the same sequence.</p><p>How to inject NovoRapid</p><p>Inject the insulin under the skin. Use the injection technique advised by your doctor or nurse.</p><p>Keep the needle under your skin for at least 6 seconds to make sure you have injected all the insulin.</p><p>Discard the needle after each injection.</p><p>For use in an infusion pump system</p><p>NovoRapid should never be mixed with any other insulin when used in a pump.<br/>Follow the instructions and recommendations from your doctor regarding the use of NovoRapid in a pump. Before use of NovoRapid in the pump system, you must have received a comprehensive instruction in the use and information about any actions to be taken in case of illness, too high or too low blood sugar or failure of the pump system.<br/>* Before inserting the needle, use soap and water to clean your hands and the skin where the needle is inserted to avoid any infection at the infusion site. * When you fill a new reservoir, be certain not to leave large air bubbles in either the syringe or the tubing. * Changing of the infusion set (tubing and needle) must be done according to the instructions in the product information supplied with the infusion set.</p><p>To get the benefit of insulin infusion, and to detect possible malfunction of the insulin pump, it is recommended that you measure your blood sugar level regularly.</p><p>What to do in case of pump system failure</p><p>You should always have an alternative delivery method for your insulin available for injection under the skin in case of pump system failure.</p><p>If you take more insulin than you should</p><p>If you take too much insulin your blood sugar gets too low (hypoglycaemia). See a) Summary of serious and very common side effects in section 4. If you forget to take your insulin</p><p>If you forget to take your insulin your blood sugar may get too high (hyperglycaemia). See c) Effects from diabetes in section 4. If you stop taking your insulin</p><p>Do not stop taking your insulin without speaking with a doctor, who will tell you what needs to be done. This could lead to very high blood sugar (severe hyperglycaemia) and ketoacidosis. See c) Effects from diabetes in section 4. If you have any further questions on the use of this medicine, ask your doctor, nurse or pharmacist.</p></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Like all medicines, this medicine can cause side effects, although not everybody gets them.</p><p>a) Summary of serious and very common side effects</p><p>Low blood sugar (hypoglycaemia) is a very common side effect. It may affect more than 1 in people.</p><p>Low blood sugar may occur if you: * Inject too much insulin. * Eat too little or miss a meal. * Exercise more than usual. * Drink alcohol (see Drinking alcohol and taking NovoRapid in section 2).</p><p>Signs of low blood sugar: Cold sweat; cool pale skin; headache; rapid heartbeat; feeling sick; feeling very hungry; temporary changes in vision; drowsiness; unusual tiredness and weakness; nervousness or tremor; feeling anxious; feeling confused; difficulty in concentrating.</p><p>Severe low blood sugar can lead to unconsciousness. If prolonged severe low blood sugar is not treated, it can cause brain damage (temporary or permanent) and even death. You may recover more quickly from unconsciousness with an injection of the hormone glucagon by someone who knows how to use it. If you are given glucagon, you will need glucose or a sugar snack as soon as you are conscious. If you do not respond to glucagon treatment, you will have to be treated in a hospital.</p><p>What to do if you experience low blood sugar:</p><p>If you experience low blood sugar, eat glucose tablets or another high sugar snack (e.g. sweets, biscuits, fruit juice). Measure your blood sugar if possible and rest. Always carry glucose tablets or high sugar snacks with you, just in case.</p><p>When symptoms of low blood sugar have disappeared or when blood sugar level is stabilised, continue insulin treatment as usual.</p><p>If you have such a low blood sugar that it makes you pass out, if you have had need for injection of glucagon, or if you have experienced many incidents of low blood sugar, talk with a doctor. The amount or timing of insulin, food or exercise may need to be adjusted.</p><p>Tell relevant people that you have diabetes and what the consequences may be, including the risk of passing out (become unconscious) due to low blood sugar. Let them know that if you pass out, they must turn you on your side and get medical help straight away. They must not give you any food or drink due to risk of suffocation.</p><p>Serious allergic reactions to NovoRapid or one of its ingredients (called a systemic allergic reaction) is a very rare side effect but can potentially be life threatening. It may affect less than 1 in 10,people.</p><p>Seek medical advice immediately: * If signs of allergy spread to other parts of your body. * If you suddenly feel unwell, and you: start sweating; start being sick (vomiting); have difficulty in breathing; have a rapid heartbeat; feel dizzy.</p><p>If you notice any of these signs, seek medical advice immediately.</p><p>Skin changes at the injection site: If you inject insulin at the same place, the fatty tissue may shrink (lipoatrophy) or thicken (lipohypertrophy) (may affect less than 1 in 100 people). Lumps under the skin may also be caused by build-up of a protein called amyloid (cutaneous amyloidosis; how often this occurs is not known). The insulin may not work very well if you inject into a lumpy, shrunken or thickened area. Change the injection site with each injection to help prevent these skin changes.</p><p>b) List of other side effects</p><p>Uncommon side effects May affect less than 1 in 100 people.</p><p>Signs of allergy: Local allergic reactions (pain, redness, hives, inflammation, bruising, swelling and itching) at the injection site may occur. These usually disappear after a few weeks of taking your insulin. If they do not disappear, or if they spread throughout your body, talk to your doctor immediately. See also Serious allergic reactions above.</p><p>Vision problems: When you first start your insulin treatment, it may disturb your vision, but the disturbance is usually temporary.</p><p>Swollen joints: When you start taking insulin, water retention may cause swelling around your ankles and other joints. Normally this soon disappears. If not, talk to your doctor.</p><p>Diabetic retinopathy (an eye disease related to diabetes which can lead to loss of vision): If you have diabetic retinopathy and your blood sugar level improves very fast, the retinopathy may get worse. Ask your doctor about this.</p><p>Rare side effects<br/>May affect less than 1 in 1,000 people.</p><p>Painful neuropathy (pain due to nerve damage): If your blood sugar level improves very fast, you may get nerve related pain. This is called acute painful neuropathy and is usually transient.</p><p>Reporting of side effects</p><p>If you get any side effects, talk with your doctor, nurse or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the national reporting system listed in Appendix V. By reporting side effects you can help provide more information on the safety of this medicine.</p><p>c) Effects from diabetes</p><p>High blood sugar (hyperglycaemia)</p><p>High blood sugar may occur if you: * Have not injected enough insulin. * Forget to inject your insulin or stop taking insulin. * Repeatedly inject less insulin than you need. * Get an infection and/or a fever. * Eat more than usual. * Exercise less than usual.</p><p>Warning signs of high blood sugar: The warning signs appear gradually. They include: increased urination; feeling thirsty; losing your appetite; feeling sick (nausea or vomiting); feeling drowsy or tired; flushed; dry skin; dry mouth and a fruity (acetone) smell of the breath.</p><p>What to do if you experience high blood sugar:</p><p>If you get any of the above signs: test your blood sugar level, test your urine for ketones if you can, then seek medical advice immediately.</p><p>These may be signs of a very serious condition called diabetic ketoacidosis (build-up of acid in the blood because the body is breaking down fat instead of sugar). If you do not treat it, this could lead to diabetic coma and eventually death.</p></div>"
          }
        },
        {
          "title" : "5. How to store novorapid",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store novorapid"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keep this medicine out of the sight and reach of children. Do not use this medicine after the expiry date which is stated on the vial label and carton, after EXP . The expiry date refers to the last day of that month. Keep the vial in the outer carton in order to protect it from light.</p><p>Before opening: Store in a refrigerator at 2 C to 8 C, away from the cooling element. Do not freeze.</p><p>During use or when carried as a spare: The product may be stored for a maximum of 4 weeks. Store below 30 C. Do not refrigerate or freeze.</p><p>Discard the needle after each injection.</p><p>Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>What NovoRapid contains</p><ul><li>The active substance is insulin aspart. Each ml contains 100 units of insulin aspart. Each vial contains 1,000 units of insulin aspart in 10 ml solution for injection.</li><li>The other ingredients are glycerol, phenol, metacresol, zinc chloride, disodium phosphate dihydrate, sodium chloride, hydrochloric acid, sodium hydroxide and water for injections.</li></ul><p>What NovoRapid looks like and contents of the pack</p><p>NovoRapid is presented as a solution for injection.</p><p>Pack sizes of 1 or 5 vials of 10 ml or a multipack of 5 packs of 1 x 10 ml vial. Not all pack sizes may be marketed.</p><p>The solution is clear and colourless.</p><p>Marketing Authorisation Holder and Manufacturer</p><p>Novo Nordisk A/S, Novo All , DK-2880 Bagsv rd, Denmark</p><p>This leaflet was last revised in</p><p>Other sources of information</p><p>Detailed information on this medicine is available on the European Medicines Agency website: http://www.ema.europa.eu. Package leaflet: Information for the user</p><p>NovoRapid Penfill 100 units/ml solution for injection in cartridge<br/>insulin aspart</p><p>Read all of this leaflet carefully before you start using this medicine because it contains important information for you.</p><ul><li>Keep this leaflet. You may need to read it again.</li><li>If you have any further questions, ask your doctor, nurse or pharmacist.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.</li><li>If you get any side effects, talk with your doctor, nurse or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.</li></ul></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/himss-novorapid-mpd",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "himss-novorapid-mpd",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_himss-novorapid-mpd\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition himss-novorapid-mpd</b></p><a name=\"himss-novorapid-mpd\"> </a><a name=\"hchimss-novorapid-mpd\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://www.gravitatehealth.eu/sid/doc</code>/himss-novorapid</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Novorapid Flexpen 100 units/ml solution for injection in pre-filled pens</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Novorapid FlexPen</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: Insulin</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 100 units/ml</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: solution for injection in pre-filled pens</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://www.gravitatehealth.eu/sid/doc",
        "value" : "himss-novorapid"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Novorapid Flexpen 100 units/ml solution for injection in pre-filled pens",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Novorapid FlexPen",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "Insulin",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "100 units/ml",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "solution for injection in pre-filled pens",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  }]
}

```
