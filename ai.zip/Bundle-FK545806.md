# FK545806 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK545806**

## Example Bundle: FK545806

**Composition category:**

**Composition status:**final

### Pakningsvedlegg: Informasjon til brukeren

 

# Pakningsvedlegg: Informasjon til brukeren

## Airomir Autohaler 0,1 mg/dose inhalasjonsaerosol, suspensjon

### salbutamol


#### Les nøye gjennom dette pakningsvedlegget før du begynner å bruke legemidlet. Det inneholder informasjon som er viktig for deg.

 

## Les nøye gjennom dette pakningsvedlegget før du begynner å bruke legemidlet. Det inneholder informasjon som er viktig for deg.

* Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.
* Spør lege eller apotek hvis du har flere spørsmål eller trenger mer informasjon.
* Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.
* Kontakt lege eller apotek dersom du opplever bivirkninger. Dette gjelder også bivirkninger som ikke er nevnt i pakningsvedlegget. Se avsnitt 4.


#### I dette pakningsvedlegget finner du informasjon om:

 

## I dette pakningsvedlegget finner du informasjon om:

1. Hva Airomir Autohaler er og hva det brukes mot
1. Hva du må vite før du bruker Airomir Autohaler
1. Hvordan du bruker Airomir Autohaler
1. Mulige bivirkninger
1. Hvordan du oppbevarer Airomir Autohaler
1. Innholdet i pakningen og ytterligere informasjon


#### Hva Airomir Autohaler er og hva det brukes mot

 

## Hva Airomir Autohaler er og hva det brukes mot

Salbutamol, som er virkestoffet i Airomir Autohaler, er en selektiv adrenerg beta2-stimulator som virker ved å utvide bronkiene, og derved gjør at du puster lettere.

Airomir Autohaler brukes hos voksne og barn over 4 år mot bronkospasme ved bronkialastma, kronisk bronkitt, emfysem og andre lungesykdommer hvor bronkokonstriksjon er en kompliserende faktor.


#### Hva du må vite før du bruker Airomir Autohaler

 

## Hva du må vite før du bruker Airomir Autohaler


#### Hvordan du bruker Airomir Autohaler

 

## Hvordan du bruker Airomir Autohaler

Bruk alltid dette legemidlet nøyaktig slik legen har fortalt deg. Kontakt lege eller apotek hvis du er usikker
**. **Dosen bestemmes av legen som tilpasser den for deg.

Hvis dosen som vanligvis brukes ikke virker tilfredsstillende og du/barnet ditt føler at dosen må økes for å få effekt, skal du ta kontakt med din lege. Det er viktig at dosen ikke økes på egen hånd.

Den vanlige dosen er:

**Voksne**: En til to inhalasjoner ved behov, opp til 3-4 ganger daglig. I alvorlige tilfeller kan dosen økes ytterligere etter avtale med lege.

**Barn fra 12 år**: Dosering som for voksne.

**Barn 4-11 år**: En inhalasjon ved behov, inntil 4 ganger daglig. I samråd med legen, kan dosen økes til to inhalasjoner hvis det er nødvendig.

**Barn under 4 år**: Airomir Autohaler er ikke egnet for barn under 4 år. For yngre barn anbefales i stedet Airomir inhalasjonsaerosol sammen med et inhalasjonskammer.

Før du bruker Airomir Autohaler første gang
Før du bruker Airomir Autohaler første gang, trykk fire “puffer” ut i luften. Hvis du ikke har brukt legemidlet på 2 uker, gjør det samme før du tar en dose.

Følg denne fremgangsmåten:

1. Ta av beskyttelseshetten på munnstykket ved å trekke ned flippen bak (fig 1).
Rist inhalatoren et par ganger.
1. Hold munnstykket fra deg slik at puffet går ut i luften.
Hev hendelen på toppen, slik at den står rett opp.(fig 2).
1. Utløs et puff ved å skyve utløseren i bunden av inhalatoren i pilens retning (mot munnstykket) (fig 3).
1. Slipp hendelen på toppen ned igjen (fig 4).
Gjenta punktene 2-4 inntil 4 puff er utløst.

Slipp hendelen på toppen ned, og inhalatoren er klar til bruk.

Husk å sette på beskyttelseshetten etter bruk.

Bruksanvisning

1. Fjern beskyttelseshetten fra munnstykket og rist inhalatoren.
1. Hold inhalatoren som vist. Hev hendelen på toppen, slik at den står rett opp.
1. Pust rolig ut.
1. Ta munnstykket i munnen slik at leppene slutter tett om dette. Pust rolig inn. Stopp ikke når du hører et klikk og kjenner sprayen i munnen, men fortsett til lungene er fylt.
1. Hold pusten i ca 10 sekunder, eller så lenge som det er komfortabelt. Pust så rolig ut.
1. Slipp hendelen på toppen ned, og inhalatoren er klar til bruk igjen. Husk å sette på beskyttelseshetten etter bruk.

Rengjøring
For normal hygiene bør munnstykket tørkes av med en ren tørr klut.

**ADVARSEL: **Ikke trykk noe inn i munnstykket, da dette kan ødelegge bevegelige deler i inhalatoren. Ta ikke inhalatoren i fra hverandre eller putt den i vann.

Merk:
Beholderen er under trykk. Den må ikke brennes eller stikkes hull på, selv når den er tom.

Når er Airomir Autohaler tom?
Airomir Autohaler er tom når du verken kjenner eller hører at det utløses noen dose.


#### Mulige bivirkninger

 

## Mulige bivirkninger

Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.

Bivirkninger kan forekomme med følgende hyppighet:

| | |
| :--- | :--- |
| Svært vanlige | kan forekomme hos flere enn 1 av 10 brukere |
| Vanlige | kan forekomme hos opptil 1 av 10 brukere |
| Mindre vanlige | kan forekomme hos opptil 1 av 100 brukere |
| Sjeldne | kan forekomme hos opptil 1 av 1000 brukere |
| Svært sjeldne | kan forekomme hos opptil 1 av 10 000 brukere |
| Ikke kjent | hyppigheten kan ikke anslås ut ifra tilgjengelige data |

*Vanlige:*
* Hjertebank
* Rask hjerterytme (takykardi)
* Skjelving i muskulatur (tremor)
* Hodepine
* Svimmelhet

*Sjeldne:*
* Reduserte nivåer av kalium i blodet (hypokalemi)
* Endret adferdsmønster
* Irritasjon i munn og svelg
* Muskelkramper

*Svært sjeldne:*
* Forstyrrelse av hjerterytmen (arrytmi)
* Overfølsomhetsreaksjoner som hevelse i ansikt og svelg (angioødem), elveblest, pusteproblemer (sammentrekninger i bronkiene, bronkospasme), lavt blodtrykk og kollaps

*Ikke kjent:*
* Hyperaktivitet hos barn
* Problemer med å sovne

Selv om det ikke er kjent nøyaktig hvor ofte det inntreffer, kan noen personer av og til oppleve å få brystsmerter (på grunn av hjerteproblemer som angina). Informer legen din dersom du får slike symptomer under behandling med Airomir Autohaler
*, *men avbryt ikke behandlingen uten at du har fått beskjed om å gjøre det.

Hvis du umiddelbart etter en inhalasjon blir verre av din astma, skal du ikke ta flere inhalasjoner, men ta kontakt med din lege omgående.


#### Hvordan du oppbevarer Airomir Autohaler

 

## Hvordan du oppbevarer Airomir Autohaler

Oppbevares utilgjengelig for barn.

Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på pakningen. Utløpsdatoen er den siste dagen i den angitte måneden.

Airomir Autohaler skal oppbevares ved høyst 25ºC. Unngå å legge aerosolen direkte i solen eller i nærheten av sterk varme. Beholderen er under trykk. Stikk ikke hull på den eller brenn den, selv om den er tom.

Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.

Klor-fluor-karboner (KFK) gasser har vist seg å påvirke ozonlaget i atmosfæren. Din Airomir Autohaler inhalasjonsaerosol inneholder ikke KFK-gasser, men hydro-fluor-alkan (HFA-134a) som drivgass. HFA gasser er utviklet som en erstatning for KFK, fordi de ikke har skadelige effekter på ozonlaget.

Dersom du tidligere har brukt KFK-aerosol, vil du kanskje føle inhalasjonen annerledes. Dette er normalt og har ingen betydning for effekten.


#### Innholdet i pakningen og ytterligere informasjon

 

## Innholdet i pakningen og ytterligere informasjon


####  Airomir Autohaler inh aerosol, susp 0,1 mg/dose 
LEGEMIDDELMERKEVAREID:
** ID_0E8C5CA3-25BE-4FC0-BAB9-3070A797BE79 **
-------

Full name: **Airomir Autohaler inh aerosol, susp 0,1 mg/dose**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 1

LEGEMIDDELPAKNINGID: ** ID_1978B8B3-6A7F-4E0B-BC10-677F0FDE0C30 ** 

VARENUMMER: ** 529269 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK545806",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "no",
  "identifier" : {
    "system" : "https://felleskatalogen.no/vsid",
    "value" : "545806"
  },
  "type" : "document",
  "timestamp" : "2021-01-01T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK545806-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK545806-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "no",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"no\" lang=\"no\"><a name=\"Composition_FK545806-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK545806-COMP</b></p><a name=\"FK545806-COMP\"> </a><a name=\"hcFK545806-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: no</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://felleskatalogen.no/vsid</code>/545806</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2021-01-01</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/felleskatalogen</p><p><b>title</b>: Airomir Autohaler Teva</p><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Binary #13935878</b></p><a name=\"FK545806-COMP/13935878\"> </a><a name=\"hcFK545806-COMP/13935878\"> </a><p><b>contentType</b>: image/jpeg</p><p><b>data</b>: <code>/9j/4AAQSkZJRgABAQEAYABgAAD/2wBD...</code> (base64 data - 26,704 base64 chars)</p></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Binary #13935877</b></p><a name=\"FK545806-COMP/13935877\"> </a><a name=\"hcFK545806-COMP/13935877\"> </a><p><b>contentType</b>: image/jpeg</p><p><b>data</b>: <code>iVBORw0KGgoAAAANSUhEUgAAAVcAAADv...</code> (base64 data - 61,600 base64 chars)</p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Binary",
        "id" : "13935878",
        "contentType" : "image/jpeg",
        "data" : "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCACNASADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7Y+CXwl0nxf8ABjwDrura341u9V1Tw/YXt3cf8JvrKebNJbRu7bVuwoyzE4AAGeAK7X/hQfhn/oJ+Nf8Awutb/wDkyj9m3/k3b4W/9irpX/pJFXo1dNWrNTklJ7vqctKlTdOLcVsuh5z/AMKD8M/9BPxr/wCF1rf/AMmUf8KD8M/9BPxr/wCF1rf/AMmV6NRWftan8z+819jT/lX3HkXi74U+DvBXhPWvEOoan43NhpNlPf3Hl+Ota3eXFGztjN6BnCnqQPevIF+Ifwy0NynjnTvjD8ORuAW61/xHrzWbg9Ctzb3ssWPdmGP1r65liSeJ45EWSNwVZGGQwPUEdxXhmq/DVbLxx4I8CDV31PwRm81ZvDeoWqTIlvboI44PM/igSW7gKxuGI8qMBsJg706rekm/vZjOjHeKX3In8KeF/hN46ihk8O+P9b1xZs7BYfEnV5i2Oowt6TkZ5Haup/4UH4Z/6CfjX/wutb/+TKr65+zH8JvEerQanf8Aw68OS38LrIJ00+ONnI6b9gG8YAGGyMDFRaXaQ/DL4l2ui6ff3EPhe+0e91K4sr64aSDTngmtlV4pJCTGjidwY87B5YKhMNul1G/gkylSivigi7/woPwz/wBBPxr/AOF1rf8A8mUf8KD8M/8AQT8a/wDhda3/APJlWYPjZ4a1V1GhDU/E6OgkS50TTJ7m0dT0K3ITyW9eH6U7/hblnYXllDruha54YgvJlt4b3U7ZDbGVjhEeSJ5FiLHCgybQWKqCWYAzz1u7+8r2dH+VfcVP+FB+Gf8AoJ+Nf/C61v8A+TKP+FB+Gf8AoJ+Nf/C61v8A+TK9GoqPa1P5n95Xsaf8q+485/4UH4Z/6CfjX/wutb/+TKP+FB+Gf+gn41/8LrW//kyvRqKPa1P5n94exp/yr7jzn/hQfhn/AKCfjX/wutb/APkyj/hQfhn/AKCfjX/wutb/APkyvRq5P4gfEC38D2drFFayavr+ouYNL0a2YCa8lAyeTwkaj5nkPyovJ5wC1Uqt2Un94nSpLVxX3Hn/AI2+HXhTwlBawQXXjfVde1BjFpukwePNbWS5cDJJP2zCRqCC8h4UepKqYvgb4T1TwB8T/GOgaj4k1fX86Fo+pOmo6pdXsNtPNc6osi2/2iSR1TbDEvLEt5YJ5rufh/8AD+40O8uvEXiK6j1fxnqKBLq9jUiG2iBytrbKeUhU/wDAnb5m5wBR0L/k4nxv/wBiroH/AKV6xWvO3GUW76fqjL2cYyjJK2v6Mo+O9GtfE3xy8E6VqSyXGnN4c1y6a2EzojSpc6UqOQpGSqySAZ6b29a6H/hT3hD/AKBH/kzN/wDF1ma7/wAnE+CP+xV1/wD9K9Hr0aspNqMbdv1ZrBJylfv+iOM/4U94Q/6BH/kzN/8AF0f8Ke8If9Aj/wAmZv8A4uuzorPml3NbLscZ/wAKe8If9Aj/AMmZv/i6P+FPeEP+gR/5Mzf/ABddnTJZUgieSR1jjQFmdjgKB1JPYUc0u4WXY4//AIU94Q/6BH/kzN/8XWbr/gL4deFNOk1DW0s9IsI/v3N9qLwxr9WaQCvCviJZeKfiv4i8Iax4P1OfTfFuqauupaeTJJGul+Hobe4RJp1U/dnnkilMZ2mYMsZ4iYr9DeGfhRouh38OsX/meJPE6KQde1jbNcruxuEXAWBCVHyRKi8A4J5raS5Um5GSfM2kjgDqPwo/fSLo2uPYwkCXUl0jVfsaAjO7z9mxkHd1JVe5GDXc2Pwr8EanZQXlnp8d1aXEaywzw3krpIjDKsrB8EEEEEV0fiXxhoXgywN7r+tafolmOPP1C6SBCfQFiMnkce9eT/CH4keGdL8TeKvDkN5Pp+k3Gu7vD32yymtrS4Wa1gmkitZnQRSfv2uCI1bcPmwu0KSvekm430HdRdnY7z/hT3hD/oEf+TM3/wAXR/wp7wh/0CP/ACZm/wDi67OisuaXc0suxxn/AAp7wh/0CP8AyZm/+Lo/4U94Q/6BH/kzN/8AF12dFHNLuFl2OM/4U94Q/wCgR/5Mzf8AxdH/AAp7wh/0CP8AyZm/+Lrs6RmCKWYhVAySTgAUc0u4WXY4xvhB4PRSzaSFUDJJupgAP++68P8AH3hDTvGvhPWvEXhiO50LwpotvJdWmp2t1Ms2s3CAlWjJb5bVSM7usxHGIxmX1B3k+Os5jjLw/DaNsPICVbxCwPKqe1mD1P8Ay36D91/rdv40RJB8HvFkcaLHGmlzKqKMBQE4AFbxk4SSb1/r8fy9dspJST7FL9m3/k3b4W/9irpX/pJFXo1ec/s2/wDJu3wt/wCxV0r/ANJIq9GrOr/El6sdH+HH0QUVj+LvFmmeB/D15rWrzmCxtVBbYhkkkYkBI40UFndmIVUUEszAAEmuZ+Hnxp0L4iXz6dBb6hpGroksn9n6pCqtIsUvlTGKWNnhm8uTCP5cjbGK7sblzCi2rpaFuSTs2ddr+u2XhjQ7/V9Rm8iwsYXuJ5ApYhFGTgDknjgDknAHNeK+Hr7x546+KniDxJYW+neHk0ewtNKi0PWP9IkdpQ1zL50kWPs8u17T5VMygA5ySNvrnjnwufGXha90lbtrGabZJDchBJ5UsbrJGxU8MA6LleMjIyM5ryP4RfFzR9D0PVL7xvcR+GNU1fVbm+l1C7heDTbpN/kQSRXTjyyGhhh+VnDjoRwCdYL3W0rsiW6TOi8WfGbxF8ONDj1DxN8PL66zIkGzwxqVremSV+FSJZ2t5JSTgBVQsc8Lwai0n4W3PxF8TR+M/iBZrE3kxx6f4T83zbe0jV2dHusfLPPlgxHMcZVQu9kEp81vr7wn8VviN448S+MfHZg8OeEbuLRtI0nR9Se1KGe1hkF15sLiWSWV5mjiERGdm3524XuPAXxI8V674Xs/DemQLqXjG08yLUNU1VT5GnwiVxbvdCPG67eERSNbIVIZjuMYwTo4uMfdVn1M1Lmeruj1rxD4p0Twbppvtd1fT9D09ODc6jcpbxLgZ+85AHArhfFnxV8AeJvCesafLfnxBp15ZywzRaXZTXwljZCCB5SMDwcZ6ZIrY8LfCXSdB1yTxFqMk3iTxbMgjk1zU8PKiAkiOBAAkEYJ+7GBnqxZsse3rn91bG+rOK+DvipfFnw60Kee+hvNZt7KC31ZY8q0N4Ik85HRgGQ7iThgDgg967WvOb23tbH476LNpoEV5qmi3x1UwgbLiO3ltlhMuB99GuGCEnO15BggZX0aiW911CPYKKK5zxr41t/B1nbgW8mpavfSGDTtKtiPOvJcZ2jPCqByzn5UUEn3lJt2Q27B418a2/g6ztwLeTUtXvpDBp2lWxHnXkuM7RnhVA5Zz8qKCT75ngTwBLouoXviTX7iPVPGGpKEubtM+Vawg5W1tgeViU9+C7ZZuSAJvBXgq40y8uPEHiC4j1LxZfRiOa4jB8m0izkW1uDysYPJJ+Z2G5v4QvYVTdlZCSvqwrznQv8Ak4nxv/2Kugf+lesV6NXnOhf8nE+N/wDsVdA/9K9YqofDL0/VET+KPr+jDXf+TifBH/Yq6/8A+lej16NXnOu/8nE+CP8AsVdf/wDSvR69Gon8MfT9WEPil6/ogooorI1PJvi18TPEWgr4ki8MR6dbp4c0c6vqOp6paS3ibiHMVrDbxSRNJI6xOSfMG3MeFcvheZ+Ing7wN8Pfhg3iX4maNY+P/EASNZH1+Bbxbm/cYCQxyB0gj3E8IoVEDMchSan+OPhDxBL4n0i38LarZQP4v1Syh1Cy1K1eWJRZhrkzho3VgCluInjPDhkAaMkk5vx10fxJ4MtfC3xC128PjrSfB2pNquo6Lb2cNqFi+zzR/aYVZiWliaRWVWfBAPIbDV1wt7qT/wA/v9Tmn9ptG7+zNp/hnwxpmpaLZabLoviuQRahqtpcaYdP3o4IiNvF91bZADGiqTs2kPhy2eg1zxLq/wASdUuPD/grUn0nTrK48nWPE8cAkCFWxJa2m75Xm6q0mGWI5GGf5V868PnxZ8d/FcfiZdH1fwTZtYzaXFdahayWV1ZWMskTzIiSKrvczGCL95jyoVUbGkYkn6B0rStM8I6DbWFjBBpmkafAI4okwkUMSDj6AAdTUVNJXe5cNVZbGJ4Z+FXhXwle/wBoWGjwyauyCOTV70tdX8qgkgPcylpGGSTgtjmtfxRoOk+KNCutJ1y2gvNMvFEMsFx91skbcHs27BUjkHBHOK4uL4k6x48K/wDCvtNtb3SWGf8AhKNWd0sHBBwbaNRvuhkD5gY4yDlZGIxWb4i+DXiXxCbTV7n4g3s/ibTd1xpsX2C3TSIbnGFdrUozsOq5MxdQzbHUnNRZ3952ZV1b3UdV8HL+81P4U+EbnULuS/vpNLt/Pu5seZO4jALtjA3MRk4AGSa7GvPP2epXPwR8F21wxbUbDTIdO1AN95L2BfJuVb3E0cgPbjivQ6matJoqOsUFFFITgZPAqCgJwMngV5BNNP8AtCXUltbSSW3wvhcpcXUZKv4icHBijI5FmCMM4/13Kr+7yX0bi4m+NdzJZ2cjwfD6JzHdXkTFX1tgcNDEw5FsDkO4/wBZyq/Jkt6XbW0VnbxQQRJBBEoSOKNQqooGAABwAB2rRe56/l/wfyI+L0Fhhjt4kiiRY4kUKiIMKoHAAHYVxnxt/wCSR+L/APsGzf8AoJrtq4n42/8AJI/F/wD2DZv/AEE0ofEhy2Zn/s2/8m7fC3/sVdK/9JIqteMfjT4c8I62vh+N7jxD4reIzp4c0NBcXxjA5dk3ARJ/tSMoJ4BJ4rzz9n7wv4o8XfAT4bR6vrY0LQB4Z01IrDQJGW6uY/sqANNdkBo9y7TshVGU8eawr2nwz4T0bwbpv2DQ9MttLtC7StHbRhfMkY5aRz1Z2JJLNkkkkkmtavKqkr66sxpXdONuyPJde+HHxB+J3irS9Q1+90zw5oEEbGPTbCaSe7s3OVZw+0RtO6HaJRxADIEEjOJUf468U+DfAPxF+F3hSHU7DQJdKFzfDToyoYWAtJbZYgg+bDSyxMABk+Qx6K1ei+NPH9l4Q+z2aQyat4gvQ39n6LaEG4uSOreiRgkbpWwq5GTkgHz/APZ50XUNO8T/ABeudemt77xHN4nhW6vII8AIdJ0+WO3RiNxiiM7qmexLEAsacW2m3sl/wP1HLRpLq/8Agk/in9obTnuIvDnhjStb1Pxfq8FyNHtrnTJtPhmeNFLyebdLErRx+ZGzlN5xnarEYrpNT1HTfgP8GoDJbzX1l4f0yCxgtLZd0t26qkMUSA9Xkfao92rzf9oeBrT4u+A/EkEe+78LaBreuR4hMr+VFd6Qt0qKvJd7WS5jGOcuOD0PqPxW8Br8V/h5e6La6o2lXUxgvNO1WBRIbW6hlSe3mC5G4LJGhIyMjIyM0NRSh2e/3iUpNz7rb7j58sfhHdXnxF8P+O/in4R06yvNeuP7Mgi8OX89rJohkDNDHcNAUFyJSBHIzF8O0YA2E7Pom+17wZ8H9F0/TpJtO8O2RzDYaZaxhXmbBYpBBGC0jcE7UUnqa8A1e28UaR8RNLT4rfETw/4duWsbq+sdXjISCBIiscgtFuAsEM4SVWaSVZ3Adwm1CQPQvgFomgaG3jDVdPv49d0s3qG18Xagyy3V3CYI3dHuyAZkSQuVfJUBto+4aupeSTk9PLb5Cho2ktTp/wDhJvG/jLA8PaFF4X01wf8Aia+J1Zrg9MGOxjYNg5P+tkiZSvKEGnN8LNV1KK4TWPiJ4pvROu3y7N7awSLjB8swQrIPX5pGPvwKc3xs0DU5Gh8LRXvjm5BK48PRCa3DBtrBrpitupBzlTJu4PBxUkF58StVMjHTfDXh2Ld+6We6n1GUrj+NVSFVbOeFdx7npWOq6W/r7zXR9bnE/BXwNcfD/wCK3i/QZr9bzTNN0yyfRRJCq3It7ie6knaZ1AErmVNu/G4iNS5ZmLH3KvOvCct1q/xV126m+zzf2TpNnpV1eWqFI5b1mknljCksQER4GGScecRyQa6Lxr41t/B1nbgW8mpavfSGDTtKtiPOvJcZ2jPCqByzn5UUEn3U7yl5hG0UHjXxrb+DrO3At5NS1e+kMGnaVbEedeS4ztGeFUDlnPyooJPvS8FeCrjTLy48QeILiPUvFl9GI5riMHybSLORbW4PKxg8kn5nYbm/hCngrwVcaZeXHiDxBcR6l4svoxHNcRg+TaRZyLa3B5WMHkk/M7Dc38IXsKltJWRSV9WFFUNO17TNYnvILDUbS+mspPKuY7adZGgfGdrgE7TjnBwav1BQV5zoX/JxPjf/ALFXQP8A0r1ivRq850L/AJOJ8b/9iroH/pXrFaw+GXp+qMp/FH1/Rhrv/JxPgj/sVdf/APSvR69GryP4gatf6P8AH3wHNp+iXWvTP4a15Gt7SaGJkX7VpB3kyugxkAYBJyw4xkjpz4t8XKu9vAkrL1KR6rbl/wAASBn/AIFj3qpK8Y+n6sUH70/X9EdrRXilr+1V4bN7qdnf6Zeabd6beSWN1FLe2BaKVMbgUFzv6n+7yMEZBBPpXgTx3pPxH8PJrWiyvNZNNLBl1wQ8blGHBIPIPIJBGKzlCUdWjRST2PPPE/jG6/4X3FZ6b4Z1bxLPoWhZ22Jhjt4pLybkySSyIqsqWi4AyxE5wCNxHL+JNK1f9oH4vy+DfE8Uvh3wh4YsbPWL7Sba/Im1O6mll+zkyRhSIovs5bKsPnIx8yhk9N+ECtqNr4n8RyK6vruuXU8Yds/uICtnCV5wFeO2WQAf89STyTWd8YvgP4V+KUkWrarf6l4c1a1tWsv7b0a9FrMbVnDPBLuDRyxEjlJVZeWGPmbO0ZRjK23n2Zk4uUb7+Rxui/GjTfhToXiJLzU9T8W6Fa3pt/DJjR7zUL9EiUzxrISWnihk3KbpyFA+VmJXc3Y6X4IvPifFZa342vrTUdJkCXdh4c0qVn01VKgq878G8bncNwWIfLiMsoc+V6V4guPgV4x1fw5ovg258UahfC3nsfFMaXF6Dp7s6xQzfZoJXiWF1mWOMKkO0D5oyxx13whvvFuqfDbRNH8J6dBoOlWiyWr63rsa7wySssiW9jFIxVVYOiiaVSmwZV+9yjZcy+/+v+HJi0/df3HrvifxfongbTEu9Zv4dOt2YQwo2S8zn7scUagtI57IgJPYVzlt4z8XeIJ4H0bwUbLTWkw934lvxZStH/fjgjSZyT02y+UR1I7HmNK1HwV4O8RTy29zqXxF8eopgubu2i/tC9iyATGWQCCyQ8HZmJTwSCeT3cnjZ9I8Eat4m8R6XL4attNt5ryeC7nikkjhjTezMYmZAcBuAzdOprDlt0ua3v1Mr4UEzXXjq4ilWSwm8S3ItQo4TZFDFMM5IJ+0R3BOMckgjIJPfVyXwn0S78PfDjw/aaiiJqrWq3OoBBhftcpMtwRnnmV3PPrXVyOsSM7sERQSzMcAD1NRL4mVHYUnAyeBXmNxcTfGu5ks7OR4Ph9E5juryJir62wOGhiYci2ByHcf6zlV+TJZhvz8dXMOm3BX4cqSs+oW74OukHBihYdLXs0g/wBZyqnZkt6dbW0VnbxQQRJBBEoSOKNQqooGAABwAB2qvg9fyF8XoFtbRWdvFBBEkEEShI4o1CqigYAAHAAHapKKKzLCuJ+Nv/JI/F//AGDZv/QTXbVxPxt/5JH4v/7Bs3/oJq4fEiZbMz/2bf8Ak3b4W/8AYq6V/wCkkVcv8R/i/wCJp/ino/w68FafDDLdziHVPFN3tmg00m3ln8pIQwLzmOIkBuE3xsysrDPS/s6CQ/s4fDAQlVl/4RPS9hcEqD9jixkDGRXHap4e8XeGv+EdaPwFbah/Y/iL+2BeaBqomkm85JorqaWO58tw5juZsKry9FAOOB0O3tZX8znjf2ULdkep+C/h7pXgkXM9uZ7/AFe92m+1nUJPNvLwjON74GFGTtjUKiZIVVHFYWr6Lr/gjxTqviLwzpsWv2GsyR3GraP56wXPnxwpCJ7Z2+R2McUKNHIyAiNWDggq13/hbNgOH0HxSjDqv/CP3bYPpkIQfqCRXmvjn4z+H/FPjvRfC0l/4ksNMWwv77VrDTdP1G21MyxvapbRmOGMXAjkE87Bo8BzDgMcMKzjGcnsaycYrc5j4i/HTSdQ8deCfHHhy7t9R0PS9P1XS/EFheQvFPFDcyWbANvwIAfskpWaT907RiMN+9VhN8L/ANrHwb4R8I/2Jqzasml+HP8AiXprtzaukbQoD5KyrKVmEywiPflCpPzK7A5rPvYY9Y8D3XhfT/CHjLV10W7tT4a1o6Nd6dfpZNKvmwCa4SF0kjQSx7mIDo0ZLMd5GXpX7PN78MtYfxxrXiDV9Jub2aPTtL8KeGJ4baW6dy4iiurmONEyxdnfy1RFYFt7kbm6rU+Xll02/P8AU51zc3NHr/w36Fr4hfEC2/aF8YeDdf8Ahz4db4keHfDkd0b9JpLrSDbT3GxIp42eISM8axS/Ig3ETKQQORu+AtN0q+1LUbS7+FmpeKfElrem5uBq91bzQaXvUeSE+2z+dtKLkOsRy3mdOlSeH/Euu/A7/hPbnU/En/CRaLoPh+fWNUspZJ7iLS9RLGSC1guZmaSXzIy5dHYFSIWVY1mCi98BPid4c/bJ+H1t4xtrXUPCnizSZDYT3unSeXNazbVcrHIQVmhO4N5cqsucbkJANKSajeK91aX9dddgjJc3LJ+89benY9NR/iZqUDx29n4U8JovywNLJcasQuBjdGotgp/2Vdhx154t6r4i1H4b+CNR1fxNqNvrt3EyrbR2Fn9j+0TSFY4bdFaV8vJKyouW6uB2zVNU+Jvh8pEh8O+MbcPjzrmWXSblY8dWCRzxyvnHQRKfQVy/jDWdV0zWdK13xfZW8l1BKYfDXg3Rbo3U1/fspBnkd0jGUQsBxsiUvIzElQnMld20t/XzOi9kbmn6jH8FvAOj6fqLf254t1OZyLSz+WTVNSmZpZzGGJ2Rh2dizHbHGBk4UVu+CvBVxpl5ceIPEFxHqXiy+jEc1xGD5NpFnItrcHlYweST8zsNzfwhaXw/+H95pupXHirxVcQ6p40v4/KklhybfT4M5Fpag8iMHBZzhpGG5sYVV3vGfjbTPAumwXeotNJJdXC2dnZ2sRluLy4YMVhiQfeYhWPYBVZmIVSRLd3aOrY0rK7PKvjuPFN7qurf8I9rup6RcaNo1vq9tHp0oUzbLmQ3I2MCkjGNECpICpJx8u4sOY8Waf8AED9rb9mzTLnwt4qf4ba1dNdW+o2qRkrcywTyW8kRmVi8SF4WPybjg4O4Zzp/EeP4m+KdZmksvAN3ZWGq6Dc6WJbLXLUXlsWmhb/SAxVIsxiZVaCSZgzfw/erkPCHiT4yfs6+HvBGm+LtN8GHwRALfTbuaxjnhuopCMyyvKZ3RicSPvKL5jcEIXFdUFaKcWuZbbM55vmbTTs9+n9fI+Tvhd+zl+1l8FY/Eq+BJLjSHsbxRcabBeQtHffL8txCkw8qVSvGc7vl2lcjFfY37F/7Q/xF+Lt/4v8ADHxN8NR6B4i8NrbMz/ZZLWSZZTKPnifIGPK4ZeDngcZP1FTdi79+0bsY3Y5x6U62L9vF88Ffut/+CZ0cH9Xa9nN27PVf8AdXnOhf8nE+N/8AsVdA/wDSvWK9GrznQv8Ak4nxv/2Kugf+lesVyQ+GXp+qOufxR9f0Zk/ELxbong349eBb3XdWs9ItJPDWuwRy3syxCSQ3ekFY1yfmY4OFGScHitiw+OGkancXcdvoPi2SK3fYt1/wjV6IZ/8Aaiby8OvuKreJrm2tv2ivARuJYoi/hjX1jMrAZb7VpHC574B6ds13niDxHpPhPSZ9U1zVLLRtMgAM17qFwkEMYJwNzuQByQOTVytyxVun6smN+abv1/RHFar43vdbQJ4e8B6lqmoSAolzrVsNPtYT2aVpf3u32jjc+3eori0u/g78Gtcujcrq3iCOC5vXmiiEKXV/KSVSNMnYhkZERSThdoJJyTieJPi/qOrad4o1/wAHa/4bj8IeF7IXl9q09q+qLeYt/tMiQ+TcRKgWExHeS+TIflG3LeaftReNPiJ4b+D+marrmoeGdBE99ZTy6fBDI9xbSRsZ0CzSOUkYSxwgfuSA3UOODUYNtR7g5pJs9q1bxb4S/Zu+Fui22taklnYaXZRWFpE0m64u2iiA2xhjl3IUsSTgDLMQASPMdF+GPiD9pTU18UfE21uNF8KIN2ieE1keGVB1W4uCCCHPB7NjAwi71k+YPhh8edF8P+IbfxJ4r01/EvjiYPLFca3ezXbWCj5iIYnAIwDvwzExl2VGCjn6pm8a+JvGPhbSLzQPiH9on8U2N4mk6jplhawaYl+iHy7X98ssqOcSkMxYZgfI5VDrKnKk/N9f8jOM1NeXY+evCHw21j4X/tBL4D1Lxi/hCDVNMMK3lveuiag7SZj5gnjkiZn84oXdZDvZRu8vfJ9D3Pw+vfh+slt4yGteNPA0DBrQ6XdCCKzQrtaO6s4yjXKlizbma4ZmfLKCoY+EeGvAvw98W6BFF4ovRpvjWO5uE8SyeK3vFLXAZY8m7jkCW6MN8YDu2/bIpMpjdq9R0rwVrHjz4ipAvhfw34l03w5vSXWtX1KaaW5m2DZbO0nmzNCBMZVVk2M6K6n5FL6VHd6v+u6Igrf1+Z6j4P8A2hPgzbeHok0jxVoHhvSLcKq214o0hIARlR5Uyx7M9sgZ7VN4h8TWPxkutK8OeGbkaroElxHea1q1qC1qLaJhItukuNkjzOEUqpOI/MJIJXNTxt4R0XwX4s8D+I7fQobOWGaz0RrzTrjbcxQDfHb2cUZA32++dndVIwI92xsZX2OuKTivejc6VzPSQjMEUsxCqBkkngCvI7y+uPj5eT6bpk8lr8N7eRor/U4HKPrjqcNb27DkW4IIklH3+UQ43NXM+I/FWsftKXWu+GfAs1lH4J0i/Ol69rk95NE99cIiPJaW6w4cxAOgkk3x7wxVCRlqk8A/AzxN8BrGa68LeI7C6sMmS48KypPbaW5JLM1u009w9q+ScYYxnOGXoy2oqC1dpdP67kuTm9FodafC2pfBy4a58G6WuoeDZHaW88L2gCS2TNy01iOFIJyWtztBJLIQ3yP3fhXxZpPjbRYtW0W8S9sZGaPeFKskiMVeN0YBkdWBVkYBlIIIBFZXw5+Idr8RdIubpLG70e/s7l7S90nUNgubV1OV3hGZcOhSRWUkMrqQTmvFtIvvFPgnx/r2qXFzZp4kkD3ereE7ezFrba5aodq3tjK0hDXCRKituOThY5No8p1nlc7p7r+v6ZV+WzWx7pF8RPC83jKTwlH4h0x/E8cH2l9IW6Q3Sx/3jHnOPw7g9xXQ1+ev7T/7E/hzU/C8/wAbvhJ4jHhq8NuNfImv/ItrhXHmieG4ZgYZG3AjLbSSANnWtL9if9vDxR8XPH3hz4beLLWxuLxrC6Da4jkTXs0aiRMoAFBEaS7iM7iARtwc9TwnNS9rRd7brZo5FiuWr7KqrX2e6Z98VxPxt/5JH4v/AOwbN/6Ca7auJ+Nv/JI/F/8A2DZv/QTXDD4kd0tmZ/7Nv/Ju3wt/7FXSv/SSKvRq85/Zt/5N2+Fv/Yq6V/6SRVseJfD3i2e/mvPDfi6300yBR9i1fSVvrRCMAlRHJBKCR1zKRnkAcg3UV6kterM6TtSj6I66oo7WGKeWZIY0mlx5kiqAz44GT3x2zXFxWHxLSJFk1zwpLIAA0iaNcoGPchftbbQfTJx6nrVeTw/8Tb6d1n8aeHdPsXGNum+G5ftcfHVZpbx485yfmhI7YPUxyrv+Zpd9jrfEninSPB+lvqWt6la6VYoQpnu5RGpYnCqM9WJ4CjkngCvG/GfjXV/i/r2neANE0SbTNA1i3kudT1nWbQrOlioxvgtZFOx3lKIjXAU8OyxuEJXrb3wx4Q+FcbeKtZa61zXsiGHUdUkN5fzythVhtU6Rs5A/dwKik5JHU1rfDLwvf6VZ3+ua/Gi+KdelF1qCo+9bZACILVG7rEh25HDOZHwC5q1yxXMS7y0Pzw/bi/aCtfBeheJv2dfCmhf2ZZWN/Z+bqCXDTSXsDwR3LhyfmMpncbnZmLAc8k19tfsdfBqT4F/ADw34dvIfJ1mZG1DU1wMrcy4ZkPui7I/+AV4zrv8AwTa0r4l/GPxJ48+IPi+61SPVr9rtNI0q3FsqR5wkTzMzMwCBFyqoflPPPH1BrOt6R8JfCml6fa2txcsqpp2kaPbuZbm7kC/JEhdsnCrkuxwqqzMQATXdiKtOVGFGjr1fm7Hn4elUVadat6L0v/wxe8beNrPwTpsMssM1/qF3J9m0/S7QA3F7OQSI4wSB0BLMSFRQzMQoJrJ8EeBLmz1a48VeJpIL7xhexeSzw5MGn2+dwtbfIB2A8s5AaRhuIACIj/BPgm8tNSm8T+J5ob/xbdx+UTCSbfToCQfsttkA7cgF5CA0jAE4AREv/EbxY/gzwfqGo20aXOplRb6daOcfabyQ7IIvX5pGUE9hk9Aa8/b3Yno76s5xtQ8S/EfXdZttE1o+FvDWmTtYHU7OCKe9vLpOJfK85XijjjYlPmR2Z1fhQvz8v8SvgV4o8Zw+HvO8XnxJDol7/aCWuqIdOuLmQQSxDF7Y+W1uf3u/ekROVA+6WU6Xgv4oeAfh/wCHtP8ACKeI21PW9Pt/39pDZzS6jdzbszT/AGaOPezPKzM21MZc9K37n4x2ekx/a9a8PeINA0bgtq+oWai2jBOMybHZ4l7lpEVVHUjmtE5xfur8CLRkveNDwX8QLPXryfQru1udC8SWMYM+kai+6Vo+gmikyRPEf+eik88NtbKi38SfBuk+P/A2t6Frdva3Gn3lpLE5vEVo4iUYCT5uAVzkHtjNL4t8IaH490i3a/5EB+1WWqWkvlz2j44mhmXlDjuDhgSCCpIPz58NddtPF3iC1034j3fiLxZpOq3Mo8L+INXSODRddhwHRTawBIxJtzs89MShN8fXAUY396Olv60HKVvdfU99+FPi0ePPhn4V8RblZ9T0y3uZNrhwsjRguuQSCQ24cEjjrXVV5/8AB4Jplr4q8Oq7sdE8QXkSh127Y7grexqvABVUu1QY/uYzkGvQKzmrSdi4u6QV5zoX/JxPjf8A7FXQP/SvWK9GrznQv+TifG//AGKugf8ApXrFVD4Zen6oifxR9f0ZneO/Dmk+Kfjz4KsNa0uz1exbwtr5a1v7dJ4iftejjJVgR0J/OrNx+zz4Wa/sbmzuNb0yOwlM9pZ2urT/AGa2kMZj3QxOzLCQhZR5YUDc2Bkk1S8f32q6f8fPAkukaXFq9x/wjOvCSCS7FviP7VpGWVirAnOBtOOp5452m+JXiOCSaOb4WeKWdACj211pckcxwOFJvFI69XVRx1rR83LHlfTv5szXLzSuuv6IxJf2WPh/cW2s28sPiFrfW2kfVII/FWqQw3zOgjczRR3Ko5ZAFOV5AAOan8bfDaw8GeBvEeq+C7Ww0bxWLPK65eur3Toh3MjXdxvIJXeqvIWVGfcQQCDqXfiTx9qMDPZ+G9K8MWwjZ5L7xDqIme3wDyYLfKuB1P79OO9eWWGi2fj3V7Lx3418Rzah4F8PPJeR6jrbrY6ZfShdqyw2nCC2jOXSaYvI7AFG8vDO05y+KWi+Y3GEfhjq/kec+J/hTZ/tI+FtL1L4WeCLOw+zyJNceKfHJuIZtYR4islv5hSSedVL585/lWSJTET99el+C37KPjvwjp2seHPEGvaZY+DLy+t9QjsdPun1O7SSFw6FLie3i8p8pFmTa7fu12+WQGHi37Rf/BTrVfDHj2TTfhTdeHvEXh2KNQ97e6VcBlmBIZFfz1Ei8ZDCNRyMFup9Z/Yj+P8A8Z/2ldRvfEHie20TSPAun7oBJY2DpLf3JA+RGeRsKg5ZgOpVRnnb31KWIhR55JKPnv8A8OcEK9CpW9nF3l5bHtifsveAk8SX3iL7NqreIrtAj6u2sXRuVwFGQ3mdwiKcghlUKQRkHhvg3pGg/DHx1r9h4gu7nwz4jiv5fs6Sz21pYaxYuZzbypBAEjd9scksrGNXSUy8hCBX0lVPUdG0/V45I76xtr2OSGS2dLiFZA8T43xkEHKtgZXocDNeYqsrNSdz0+RXujynxLap8YviTc+GvPnOheGJba5vJUsU2LfBopkhEs0RPmeXtPmW7/IrurbWKMNW9vrj4x3k+maXPJa+B4HaHUNUgco+quDhra3cciIEESSjryiH7zDjIPEvhHxZrKfDbQLi08LeCkd45WhQ2i67IWfzbWxfAV03CTzpIyWJ3KMZZh2XgaY/C3W7bwBfyH+xpg3/AAi9244MKLlrB2/56QqCUzy8Q7mNybastN/61/rYlO5y/wAWtZX9nOafxdoOk50TULCa0vrC1tm+zQXcFszWVy5QbYYysP2Z2I/it+QE5l8G+BYfG/jLU28V+IJPiHpWmWtlJZQX6wSWP2iVWeW4WONFRwcRiPfvMeG2n5zXuNePa7+y54N1Px7Y+K9Ojl8PX0UhluYtMVEiuH+ZklClSIpVc7vMj2lssG3ZBCjNNWej7g4tPTY4yx+Cuq6l8SvFmpeAvEFv8OdP025h02KK20/7S7usKTSbE81IkgYzgeSyOAys6eU0j7qfxq8G654gvdE8KfEr4jeHYvBuqWs81zcyaDa2x8+HyAEDXTzIpcSSMGXa6bBjOcroeJrjUPB1x4rm+HN/4h1LV9JuHutYn1u7hj0fzlgidop5J1DMTD5ZzBgA43SJzXaD4q/C3x14Y8K6l4quvDSX99aQ6ha6PrEkE15bSyQq7IsTZfzFBwQq546VrzTTUt/lrt/TIai04/8ADHmvwT8WX3iv4g2Gg+Dtdu/FPwr0q3n026N5FYiwWOBPJjW3WGzVseYqqu+c71WRtgTy2f0Cw/ZH+Gmg/GHRPiVoGhJ4c8Q6aZyY9LxDa3HmwyRNvhA2ggSE5ULk9c1r/A3xNZeJG8ef2dDdQWln4kkhjS8s5LV8PZ2s4IjkVWCnzsglRkEEZGCfT6znUlGT5dNPv9RxpxlFc2tv60CuJ+Nv/JI/F/8A2DZv/QTXbVxPxt/5JH4v/wCwbN/6Caxh8SNpbM8y+Afwwms/gF8OdT8Ha7c+FtVuvDOmzywspu9OuJWtUZmltWYAbmYszQtE7Hqxq7488afE/wAJM+oTaPqTwxxBHXw3p0OtWr4YnzFiaS3uY5GBwV/eoMDByCW7D9m3/k3b4W/9irpX/pJFXo1bVJ2qSur6sxpR/dxt2R8k3PxA+KvjuWGHRfEGuaIzhJvL0vw7DdXDKGy8TiWL7LAxBABa8Y99p2kt2un/AAh+I/iG2SHUPG2t6BaO5eW5n1X7TqTgr0VbdIbe3IOMD9+uByCTkfQNFS6ulopItU9btnE+Evg/4d8IX1vqEY1LWdXgjKR6pr+qXOpXMeRhzG07uIt3cRhFPpjiu2ornfG3jaz8E6bDLLDNf6hdyfZtP0u0ANxezkEiOMEgdASzEhUUMzEKCayvKb7l2UVoHjbxtZ+CdNhllhmv9Qu5Ps2n6XaAG4vZyCRHGCQOgJZiQqKGZiFBNZngnwTeWmpTeJ/E80N/4tu4/KJhJNvp0BIP2W2yAduQC8hAaRgCcAIiHgnwTeWmpTeJ/E80N/4tu4/KJhJNvp0BIP2W2yAduQC8hAaRgCcAIidrVNqKshJX1ZU1fVrPQdKvNT1G5js7Czhe4uLiZtqRRqCzMx7AAE1wXg3Q7/xvrVv438SwSWyxbm8P6LMpX7BCy7fPmU/8vMikg5/1aNsGCZC1L4+avcWyeAdGg0ybWIdd8U2lndWdvKqMYUjmuS7busavbxmQd03DDZ2n1C78/wCyzfZvL+07G8rzc7N2ON2OcZxnFHwxv3C/M7dilovhvSPDaXCaRpVlpaXMz3E62VukIlldizyNtA3MzEkk8kkk1osodSrAMpGCCMgiuAvNM+Kd0yta+JPB+lrzmObw9dXpPp8wvocY+nOe2OalzrfxB8BWx1HxH/Y/i/R42zdyeHdLnsbu0i7yLA89x54XqyqytjO1XOFJy31vqLmtpbQ47xhHq3wNvVsdO0RPEXwv1+Q2TaNDcJbT6RcSgqIrdnZY/ImY7Vjdowkj4DgMqjC1mH4n694G1X4e6T4Kl1DTZLaO103xLr93Bp72KgHb5saCUvNCVQpLEhVjtJGVO76CurXRfH/hV4ZVtta8P6vaYOGEkNzBIvBBHVWU5BHrkVy3w71XUtC1a68DeILt7/ULGD7VpmpTNmTUbDcFDP6zRMVjkPfdG/HmbRop6XtqiXHpfRmL4Asde8NfGDxDD4j1e11C68R6Vb6nFBZ2/kw2728jQzLHklnUJLaDcxyWyflBVF9arx/9onxFc/Dqz8O+NtLhgvtbsr5NHttLlADaiL2SKM26OXVY33pE4Zjt/dEHrkdVoHxl8Ia/qMOljVl0vW5gxTR9ZiewvW2nDFYJgrsAf4lBU8EEgg1MoyklNL+kUpKL5bnbV5zoX/JxPjf/ALFXQP8A0r1ivRq850L/AJOJ8b/9iroH/pXrFKHwy9P1Qp/FH1/Rnnv7RniXxN4W+LfgC68J3GjWurSaDrkIk1+OZ7QIbjSidwhBfqo6e4yM5Enh34n/ABd1S6trGy0rQfFl07g3F9b6VfaNptrGf4jPcu7SnrhYkfjaTtBrvtd/5OJ8Ef8AYq6//wClej16NWrmlCKt0/VmcYtzk79f0R53N8O9a8aXkUvjfWILrSYmDr4b0mJorOVgQQbmRiXuACOE/dxnPzI+ARxf7Vf7J2kftQeF7GwuNcv/AA/qOmsXsp4HaW1BIwfMtiwVuCcMNrD+9jIPvFFZQqzhJTi7NGk6UKkXCaumeJ/BL9j74ZfAzQ2tNJ8P2+qajPC0F5q+rRLcXNwrLh1yRhEYdUUAHvnrXqfhDwfovgDw3YeH/DumwaRo1inl29nbLhIxkk+5JJJJPJJJPJrZopTqTqNubuOFOFNJQVgryTW7y9+OGp3vh3SZ5rDwHayPa6zrEDlJNTkUlZLK1ccrGDlZZhz1jQ53Mt7VNUvPi7qV1oeh3U1l4RtZGg1bXLZykl66nD2do45ABBWWZfu8oh37mi9D0vS7PRNNtdP0+1hsrG1jWGC2t0CRxIowqqo4AAGMCmvc16j+L0PnfwNrdx4Itrv4PeN/CkninS9IiMWm3VvbQ3BvNLHELyWpwzlFxEzRK/zIdwXKl11m68P3VodG0nxAup6ddOrjwP40mn069VlYMHsJ7gJcQyIcFQ25QQoVoQM17z4m8HaH4ytYrfXNJtNVihcSwi6iDmF+zo3VG/2lINcle/Afw5eWc9o174hNnOcva3GvXd3B7gRTySIFxxtxt9ADzWiqRbu9yORrRHN+EdTk1rUZbHRviRrWma1GoMvhjxXZ20s9sASMhdkc0ik8eYsro2PlY5yeb8V/GX4ieGL1tH0ufwv401KGVbO4vbXTrizt47yQ4gtQv2mUvO24MyK2I41aR2QFQdXVP2N/Bl/p8NhBqeuWNhCMR6cJbe5sFAxgCzuIZLcYwP8Aln2x04rpNP8ABXhD4MW8PiHxL4ltraz08fZ7G41l7TTrDTFcBSkEcaRRIz4wWILncVDbTtqrw6a+VibS66edzkPB/wAKrbW/i94ztPH1xF4t1CTT9J1qfTzAY9IWaU3MAZbUsyuVFggVpi7LsBBGcD3fT9HsNIj2WNlbWSf3beJYx+QArxSzn8M/Fr41tqej6lrMYGgLHBqunPdWUNysVwSfKchY7mP/AEkfMA65xtIIau+ufhHYakgj1HXvE99CCD5X9u3NuDznBMDRlhwMgkg9OhIOc3drmZUFZaEXgu7tU+KPxFsIZo3uBLYX00aEFkMlsIhux0yLboefwxXfV41pFj4U+C/xQ8TTJ9i8N6Jd+H9OkMSqI0eaO7vFeTjmSV2uoVJ5Zj5Y5JFemeGfGOi+MbeebRtRhv1t5PKnRCRJA+A2yRDhkbBBwwBwRUTWt1toXF9GbNcT8bf+SR+L/wDsGzf+gmu2rifjb/ySPxf/ANg2b/0E0ofEhy2Zn/s2/wDJu3wt/wCxV0r/ANJIq9Grxz4TeJLjwh+yV8P9YtNFv/EV1a+EdKaLS9MUNcXLG1hUKoJA6nJPYAntXmP7M/xv+Kfj39o/4h+E/iJb2uhx6Rpdrdw+HbQRSLZNKI5FDTqN0j+XIob5tuc4ArolSlN1JrZf5/8ABOWFWMI04PeX+V/0PrGiiuX+IPxB0/4eaPFc3MU9/qF3KLXTdJsgGutQuSCVhiUkDOASWJCooZmKqpI5UnJ2R1tqKuw+IPxB0/4eaPFc3MU9/qF3KLXTdJsgGutQuSCVhiUkDOASWJCooZmKqpIo+CPBN5a6jL4n8TyxX3i27i8omEk2+nQEg/ZbbIztyAXkIDSMATgBESl8Pvh9qEGsS+MfGMsF/wCNLuIwqkBLWukWxIP2S1yAcZAMkpAaVgCQqqiJ6HWjaiuWJEby95hRRRWRoeeeHlbxZ8W/EOsyEtYeHYl0OwQggefIqT3co5w3BtowcZUxSjJ3EDqPFHjPRvBVrDda5fLptnI5T7VMjeTHgEkySAbY1wD8zkD3rA+C1uIvAUdwWZ5L/UNQ1CRnYsd015NKRk9l3hR6BQBgACu6q5W5rdiY7HKn4reCVWNj4x0ALIodCdTgwynoR83IPrXTW9xFeW8c8EqTwSKHSSNgyup5BBHBB9aqRaBpcO7y9NtI9zFm2wKMk9SeOteeppMPwe8Z2cmmg2/g/wASXn2a408NiDTr9wTHNEvREmYeWyLx5rxsAC8hIknsF2tw0eVfhT48bw20qw+HPEkktzofnMFitL7G+axXjhZBunjXk5FwBgKgry/w9oM+PhX4/l1q9m8ey64+ma9bXl3KUuXkR4L61ity5RFgeLzECDAW3ZjnczH0z9qHTdNvfgb4ou9RtIr59JgGq2UEhIMl3AwkgjQjkNI6rGNvJ8zA614z4C/aF+BWlazdX/gnQdY1rXmaQLdTq8k8hIRX2T3swxuwikBgTt6HFdMFJx5or1/r5mErKXK2e0eKNJsviX8YLLQdRsrbU9B8N6ZJf3ttdwCWKS7uw9vAvPynbAt5uXBOJ4zxkZ4n9of4eaV4e+FVxpEWoaiNH1zVNP0qW0v7s3cNtDNdRrN5TT72izFvQBWwob5QpwRc8H6vr2vWeqWXh+K6tPFXiO/fUNY8Qy6Vcw2WmQELHGkD3EarczJBHFGoTKb1aRwoO1u51X4GeHvEdsltr194g121EiSva3uu3YgmZTlRJFHIqOuQMoylTjkGpT5JK70RVueLstz0MAKAB0HFedaF/wAnE+N/+xV0D/0r1ivRq850L/k4nxv/ANiroH/pXrFZQ+GXp+qKn8UfX9GGu/8AJxPgj/sVdf8A/SvR6wPiv+1j4E+EniRvDV3/AGt4h8VLD9obQvDunveXSpgEFgMKuQc8sOOfSt/Xf+TifBH/AGKuv/8ApXo9Wvir4n1L4eaSuv8Ah3wHdeN9YnmS1nttLeKG5EAWRw7O/wB5VYY29cycDrWqUXyKSvp3t1fUyfMudxdte1+i6GR8D/2k/BX7QEGor4aubu31TTCFv9H1S3NveWhJIw6ZIPIIJUkAjBr1Ovhz9jxofiJ+1Z8VPiNrhj8JeM5rcWD+BJVkS6tIcQAzyl0QPnyIz8uRmTJxlc/cdGJpxpVOWPZfl+PqGGqSq0+aXd/n26egV5lqmqXnxd1K60PQ7qay8I2sjQatrls5SS9dTh7O0ccgAgrLMv3eUQ79zRN1HV7r4wajd6JoN5JaeELSV7bV9ctJCsl5IpKyWdq45ABBWWYfdwUQ79zRei6Xpdnomm2un6faw2VjaxrDBbW6BI4kUYVVUcAADGBWPwb7m/xbbBpel2eiaba6fp9rDZWNrGsMFtboEjiRRhVVRwAAMYFWqKKzLCiiigCG9vINOs57u6mS3tYI2llmlYKkaKMsxJ6AAE5r5d+LGvf8Jjp8uvazbTpp97p9zLZaY8beZZ6FGu68u3TqLi7Ux28a43os6gAHzhXtPx5tzL8KNcmMclxb2PkajdW0UfmNc21vPHPPBt/i8yKKRMDk78DmvNpHi8Y/E7XdKIee6v8AxRYxSyPhQmj2dhb38YiI+9E1zKAfVriUHhQK6aSt7xjUd/dM9JdY+G/j618V6jZa34q1LRfCdzP4r+y3SCC3FzLDLGlpbySKmIhZXACIASrAszuefUPEPx48OeH/AIXX/jabz0tbRngaxuVEFwLlSQYXDHCEEZLk7AgMm7Z81cS/gPxb4o+KXxeis/EGm6Xo+riw06WK706W7nW3FiNzRHzo1Qs00w5VwCmcMWIXO8W/Bpbr9orwdFPO8nhW5tm1ae1kQMLjUbOOKAO7YzveI22D3S3mU5D4qnyya5n0/wCDYlcyvyr+trnN+IfAXxf+Luk6X4tuLaLTtbsSuraRaT3kVr9ilUhlhjhFs0j+YoCsbi4UEhSYo8bV9E1v4iaFDr+g/ECwt7i2S1uW0LxWssRiuNLtmjeSN7yLOQsU6xYc5CpPI6koxY537U/jaa2uPCnguLxCvhCx1y5aTVvEMsyQR2dpEC7IZXZQjSBZCpOVPlFGGHweS/Zr8L+BrX47eOG+H8Npc+HrHTI7S7voI1YXk85jkLGQKBID5bjA4BBwBu5veHM1939fcTtLlTPqqKVJ4kkjdZI3AZXU5DA9CD3FcZ8bf+SR+L/+wbN/6Ca5rTJL34J6nrFn/YF9cfD2Sdbmwm0pRcnSQyKJYfsqL5ggDqzqUD7TIw2qirjT+JviXSfFnwQ8V6houp2mrWMmmz7bmynWWM4UgjKkjIOQR2xXMo2kmtjdu6ZU+BGrW+gfsu/DzVLsstpZeDdOuZigyQiWUbNgdzgGvkP4JftSfD/Uv26vHviCDUbptM8bRaXpGjSGzkDS3Oy2h2suMoN6kZPHevsn9m3/AJN2+Fv/AGKulf8ApJFXTeNPGlj4I0pLq6Sa6ubiQW9lp1ooe4vZyCViiUkZY4JJJCqoZmKqpI6lUjCdSLjfmut7db9n2OJ05ThSlGSXLZ7X6W7ruHjTxpY+CNKS6ukmurm4kFvZadaKHuL2cglYolJGWOCSSQqqGZiqqSMfwX4Lvl1V/FXip4brxTcRmKKGFi9vpUBIJt7ckDOcAySkBpGA4VVRFPBfgu+XVX8VeKnhuvFNxGYooYWL2+lQEgm3tyQM5wDJKQGkYDhVVEXtnQSIynIDDB2kg/mOlcjajojtSvqzntf+JHhLwpqVvp+t+KdF0e/uCFhtb/UIYJZSegVHYE/gK6FHWRFdGDowyGU5BHrXxJ+0t+zX8Dvg58D/ABnqetWs+peLdXjn/svVNXv5brU7nUHB+zpGd25grFN3ByoJcnk17b+xX4Q8T+Bv2a/B2k+LmnXVo4ZJFtrkkyWsDyM0MLZ5BVCo2n7v3f4a6J0YKkqsJPe2qt81qc0K03VdKcVtfR3+T0PcKz/EHiDTfCmiXur6vew6dplnEZri6nbakaDqSf6dSeBS69rdv4c0e71O7Wd7e2jMjpbQPPK3oEjQFmYnAAAJOa4XSvCOp/ELVLPxB41tFtLK0lW50nwwzBxayDlbi6YErJOOqqMpEehdsOOVLq9jqb6Ir/s/axdar4D1G2mtX029sdY1CJbS7jKy28Us7XNqsqZ+Vxb3EBK54zxiuU+I3ir4wWWseHtN0LT9BXxBI8rRxQ3U89nfRDaHe5RoF+zRrlTuErOGYKokyQfVtN8KXGleP9a1uC5X+ztWtLdZ7MrgrdRFl84HHO+JkRsnjyUx1NdNWnOlLmtcnlfLa55L4q8a+O/h2LDX/EcOj3PhKASf2ymi2kslzar5ZKTB5JVHlK4w/wC7JAIbhQxF74z6jpPiH4I6q8txcQjVrFTpf2VlW7a8YB7QQc4MwlEZXnAK5PAJr0sjIweRXi7xeEdJ8Ty2Pw28K6Vqfi+2klhe6toQLDRXf/WNNIvyxsc5MMf7x88gAlgRd2nbYGradzNm8Eal4o+KvgzTPEfiK68UXXh+JNc1CAxxQ2dq6q0dtujQDdNJNukVyCFFq+1Y9+G97rmfAXgiPwTpc6SXkmraxfTG71PVp1CyXtwVClyBwqhVVFQcKqqo6ZPTVM5c2nYcVYKKKKzLCvOdC/5OJ8b/APYq6B/6V6xXo1ec6F/ycT43/wCxV0D/ANK9YrWHwy9P1RlP4o+v6MNd/wCTifBH/Yq6/wD+lej1jfE39qTwX8Kteu9D1S31++1qBEcWWlaJcXJm3qCoSQL5ZJzj7w54NbOu/wDJxPgj/sVdf/8ASvR69Gq24pR5lfT9WQlJufK7a/oj42/Zz8A+Nvid+094l+PPifw5deCNFubE6dpGj34Md5PHtjRZJU4IG1CTuH3mG3IUGvb/ABFqmqfGLXL3wr4eurjS/CNlIbfXfEVq5SW6cffsbNxyCPuyzj7nKIfM3NFf1jWL74pard+HfDt3NY+HLSRrfWdftnKPK4OHs7Rx0fqJJh/q+UU+Zkxd/o+j2Ph7SrTTNMtIbHT7SNYYLaBAiRoBgKAOgq6lVykpNWaVkuyIp0lGPKne7u33ZQj/AOEe+HfhyztQ+n+HNDso0treN3S3t4VAwqLkgDgcCtiKVJ4kkjdZI3AZXQ5DA9CD3FfHfx2kP7Sv7V3g74RWzNP4S8HlfEPigx8xvMADDAx5B4ZVI44mfuvHu/7Pfxhl+NvhDVdcfT49NjtdavNMhijcvujhcKrkkDluuO3SpqUXGCm93q/nt9+5VOspzcFstPu3+7Y9QooormOkKKKKAGyRrLGyOodGBVlYZBB6givkXxDAPgN8XvBd5e3ItNN0udNLNxNjbeaJMzQWzM7EYaynuI4pOpMbwue4H15XH/Fb4V6F8YvBl74c1+FmtrhGEVzCds9tIVK+ZG3Y4ZgQchlZlYFWIO1Kai7S2ZnOLa03MvU7l/BXxdt9QuS39jeKraDS/M2/LbX8BmeLcQOBMkjJuY4DQRqPmkAOt8SPhhovxQ0iOz1VZ4Lm2LSWOo2UpiubGUqV82Jx0bBIIOQyllYFWIPiXgfUL7w+H+BfxSupZpbmHy/DniQNtN9Gh3R7JD92aJghQn5lKorFm2ST+qeDvijFZ/Y/Dfje7t9G8ZxYt3Fypt7fVGUf6+0ZjtdXA3eWrMyZKt0yalFxd47r+rkxakrM+cNb+BS+IdZ1qy13wXqGm6vpjxWZ1/Qbx9UtbqF0/dXL6XdKyfZ3IKvDCZGUq/PAevcPgJ4HvPD0aHxB8OvDvhXW7CB7SHVfDtvDbw3MQlZSvloSyA+WsgBJBV1PyNuRfZq5fx745i8GWNukNu2p67qEn2fTNJhYCS6lP/oMaj5nfoqgn0BJVZVFygqcYPmM3wxcXV/8WvHMwvpZNMtLTTNOWyZyUhuVWeeWQKTgF47q2BwBnyx1qD4w6TY6f8LPHNza2VvbXF3p8z3EsMSo8zBDguQMsRk8mtj4eeDpfB+jXH2+6TUNd1O5bUNVvo4/LW4uWVVJVeyIiRxoDkhI0BJIJNL42/8AJI/F/wD2DZv/AEE1Cd5q3kVa0Wcf8IvGlj4I/Zh+FV1dJNdXNx4Z0m3stOtFD3F7ObOMrFEpIyxwSSSFVQzMVVSR13gvwXfLqr+KvFTw3Xim4jMUUMLF7fSoCQTb25IGc4BklIDSMBwqqiL5n8OvgH8QvAMOlm3+IHhnVJdI0yDQ9Ol1PwlcSNZ2sMaRbIwmpIqmTyw7tjcxwCdqoq99/YXxb/6HfwV/4R13/wDLWtqnI5NxktfX/IwpuailKD09P8z0aivOf7C+Lf8A0O/gr/wjrv8A+WtH9hfFv/od/BX/AIR13/8ALWseSP8AMvx/yNueX8r/AA/zPlDS/wBlf9pe2+JEnjzVvEXw48VeKAR9kvNelvbhLAeltELdY4vqq5zznJJP2D8JLTx7Z+D0T4kX2i3/AInM7s76Aki2qxcBFXeqsTgZJI6n2rN/sL4t/wDQ7+Cv/COu/wD5a0f2F8W/+h38Ff8AhHXf/wAta6qtX2ytJx+Sf+Ry0aXsW3FS+bX+Z6NRXnP9hfFv/od/BX/hHXf/AMtaP7C+Lf8A0O/gr/wjrv8A+WtcvJH+Zfj/AJHVzy/lf4f5no1Fec/2F8W/+h38Ff8AhHXf/wAtaP7C+Lf/AEO/gr/wjrv/AOWtHJH+Zfj/AJBzy/lf4f5l74k+Jb6E2Phbw/MIvFGuB1gnwG+wWy7RPeMDwRGHUKDw0jxqcAkjpPC/hqw8H+H7DRdMiaKxsohFGHYs7erMx5ZmJLMx5JJJ5NefQ+BfiZBrdzrCeLfA66ncwR20t1/wht4XaKNnZEz/AGrwAZHOB3Y1f/sL4t/9Dv4K/wDCOu//AJa1TjG1lJfj/kTzSvdxf4f5no1Fec/2F8W/+h38Ff8AhHXf/wAtaP7C+Lf/AEO/gr/wjrv/AOWtTyR/mX4/5Fc8v5X+H+Z6NRXnP9hfFv8A6HfwV/4R13/8taP7C+Lf/Q7+Cv8Awjrv/wCWtHJH+Zfj/kHPL+V/h/mejV5zoX/JxPjf/sVdA/8ASvWKP7C+Lf8A0O/gr/wjrv8A+WtWPAvgXxFo3jPxB4m8TeINL1q/1TT7HTUj0nSJNPihjtpLuQEiS5nLsxvG5yoAQcHNUlGMZe8tvPuvIhuUpR91qz8uz8yvrv8AycT4I/7FXX//AEr0eotY1i++KWq3fh3w7dzWPhy0ka31nX7ZyjyuDh7O0cdH6iSYf6vlFPmZMXH/ALSmn6rH4k8KarpWsHSsafqOl3QjibzZbeeaxkdY5VdTEx+yhd4BIEjFSrAMM/R/jPqfh7SrTTNM0jRrHT7SNYYLaC3dEjQDAUAPwKu14xa3/wCCxLSUk9r/AKI9/wBH0ex8PaVaaZplpDY6faRrDBbQIESNAMBQB0FXK8A/4X/4h/589M/79Sf/AByj/hf/AIh/589M/wC/Un/xysvZyNedHjfwz/Z1/af+FWu+LNa0jxB8M7nV/FF6b7Ur7UGvZpXbLEIreQMIu5sL2zU3/BLeLxm/wpvbm9u9Lk8Evd3As4U3m/F3uTzGkJXbsx0w2c5yK9e/4X/4h/589M/79Sf/AByuT+GHiuD4NeFIvDfg/wAP6XpGjRyvMLfdcTEuxyzFpJmYk/X6V6E68qlOUZRV3bp2v/SPPhh406sZRk7JPr3t/wAG59V0V4B/wv8A8Q/8+emf9+pP/jlH/C//ABD/AM+emf8AfqT/AOOV5/s5Ho86Pf6K8A/4X/4h/wCfPTP+/Un/AMco/wCF/wDiH/nz0z/v1J/8co9nIOdHv9FeAf8AC/8AxD/z56Z/36k/+OUf8L/8Q/8APnpn/fqT/wCOUezkHOj1P4mfDDQfi14Yk0TX7eR4g6z213bSGK5sp1+5PBIOUkU9CPcEEEg8fDeeK9J8NS+F/Gvgu7+JISEw/wBraalj5Gqp0HnW888flSkfeGDHnkMM7V5z/hf/AIh/589M/wC/Un/xyj/hf/iH/nz0z/v1J/8AHKtRmlZkNxbucxcaf448O+IJRb2fiv4XeFLZlkSTSmPigXKnHyLBmX7IFIIKpCygHKsOceo/DTU/h+ut3txZ+MbfxL4xnjVby61W7i/tFY8nbH5GE8iPIOESNFJBJBbJrlf+F/8AiH/nz0z/AL9Sf/HKzdc+LV14mtTbax4e8P6tbHgw31kZkP4M5FW1KSs1/X5/iSrLZn0jXE/G3/kkfi//ALBs3/oJryPw58Wbnwdo8Gk6B4d8PaHpUG4w2Om2Jt4I9zFm2ojhRliScDkkmk8UfFfXPG3h7UNAnh0+2h1KFrV5o4ZCyBuCQDJ15rNU2pX6FuaaP//Z"
      },
      {
        "resourceType" : "Binary",
        "id" : "13935877",
        "contentType" : "image/jpeg",
        "data" : "iVBORw0KGgoAAAANSUhEUgAAAVcAAADvCAYAAABG35e0AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAgAElEQVR4nOydfTyV9//HX7s/Ry2hRifKCkkkES25mSRtjB1fUzTd7DTd0CZTkk0aurGyX3RjtJZFqTHGd0nyJTeL5CaqE6pTdKLipK+cs+27nd8fZ9eVw8E5nHMc8nw89ljOuc51fc65rut9fT7vm9f7JT6fz8coo4wyyihS5eWhHsAoo4wyykjk1e4vvGTJGIpxjDII+MUJPV4bPY/Di9FzODLoeh57GNfuG4yi2PR1A46ex+GBPM5h4qlMPO3ohC/DQyr7Gy5weTzYuAcgeJ0bIo+kIi3uK2jS1GVyrO7ncdQtMMooLwCxSdlwfc92qIchd6gUCqJDGDAzmYXoEAboPjvRxG6Ry7FHjesoo4xwiksrYayrKbMZm6JjaWECTZo6LC1M4OvliLBvvgeXx5P5cUeN6yjDmroGFmITUpCWdQFtnPahHo5CUlBSCXcnm6EehkLgvcwZb2upI/pwssyPNWpcRxm21DWwsCUiDjSNCai+1gC99zYh8VSmxPvh8ngj1jBzeTxsT86DmcmsoR6KwuC/3hPpeVdQVcOU6XFGjesow5Za5i14u9mD7rQI7JY2nD0YiNikbBSXVor1eWLWq2TFQH5xuYxHOzTcrGeBYTULqirKQz0UhYHww+7Yf1ymxxGZLTCcKS2/ivanHejo5GLa1MmYojlp9MJ6AVhqZ47zBWVIi/sKWi4BaMzY16uPsa6BhYSkTERllcp5lPLn6rV6WJkbDvUwFA5LCxNEHTmN4tJKWFqYyOQYI864zl+/t8drLoZaoC9ZgNmzdDHHSH8IRjWKrFlqb4mzeWW4zryFn3eswXyPIDQVHhPahsvjIfpwMrYn5/X4fGLqBQCA+kRVzNSbNmIeyIVltQjcsHyohzEktHHa+zyPges+QkHJqHEVi7oGFlwMtfD9/iCUV15DeTUT25PzkFHbiIzaFHK7QCcL2FuZwkB/+gsbQR0pdHR0AhAs9UK/WAOnT0Lx8ksvwUBTFXUNLOjpaAMAmtgt8N3+LTJqG0XuJ6P2HjJqnxtj4oFsZ20+bK8RLo+HhMJriN+vPdRDGRLUHDaCf/lEr+/PNZ6Jhb77EOy/RibHH1HG9VErBxNVxkFVRRkOdgvgYLcAwf5rUNfAwqXyGhSW1SKh8BqiskrJJeE8DWV4u1jDxEhvRM1YXgQM9acjIel5AEuTpo4PbEygPG4MWh5xyNeb2C2g++zE5Wbxg1bkA3lfClwMtbDhY2dYLZgLKoUi1e8gSxqbmhHoZDHUwxgSmtgtcDHUQnFpJZ4948LBbkGPbagUClwMtYQewtJkRBnXucYz4R+e0MOPoqejDT0dbXgvc8bW2/eQkPQLTl+ohMZ4Jfx2n4PLccIR5rfHvIH335mJdy1NYKg/XSY//CiyYY6hDgAIGVc1VWVEhzCQkV00ID9rRm0jMrYeIh/Ew6XKqZZ5C4YztIfs+P0ty2VJ+q/5cLAyQUFJJe40CooGRBlY89m6eNTKkck9PqKyBagUCtLivsJC330iqzDqGljQ9QiGuclMlP+8HyXpMWjNOYii2ADE+DjDxVALAHDn2e+Iza1Cw+0mbImIg7nzRsQmpIzYdJ3hDKe9o8drbZynqGOxwbrHBiC4LiwtTLA31A83T4aLnM25m7zd77EuN7fDL07yVK+hgll/F7Nn6Q7JsesaWFBz2Dgkx27jCM7Tsg+XINh/DTau/hCHfhR93vR1p6LlUZtMxjGijCsgWBoWxQaA7rOzRxVGQlKm4D2nReQTVVVFWVC5wfBA+rFdQsbW81+OSD+2C2lxXwEQ+HAGkkc5imzQ09FGQuE1odfGKlGRmJ4P89m6Imcqejra2Bvqh6LYAMzTeD6r8l3titTQ1YjwtBN6fbjC5fGQnncFUzQnyf3YTewWrPCPwjwNZWwJi8FL81bgpXkrsCUsBjl5JTI//u4DiTge4EHe43OM9JFR2yhycjRt6mRcunJdJuMYccYVEKRZeLtYY/n6MMQmpJDJwlFZpZhrPLPPz3Y1tkQgQ5OmDl+GB1pzDqKwrBaxCSl97mOUoaGqhomQ6CQU3muF/3rPPre1tDBBwZl95CxWY6Ia6E6LEOy/BmWZB1H5fQgiPO3kMWyZUFF9A7Zm+nJflnf3b9tbmaKzMAGdhQnwpC9GbuEVuK7ehroGlkyOH5uQAk57B7yXOQu9HuhkgcetnB7bK1Fl50MfUT7XrvgyPOD6ni3KKmpx8NjPSCi8BgddjUEFJFRVlHEg0h+bgqNlmh83imRweTxQKRQkp51HdAgDC333iXWeqRQK9ob6ifRLzjHSxxwjfaxb5Yb84nLsjkuTKCA21BSUVMLeylSux+TyePDd/i28XazxnYUxJqipCGVaEL9pcWklVvhHwdXOFOtWuUnlAUCk2d1pbMGBSP8e7xvO0EYt85Zc4ycjcuZKoElTB91pEeL3b8NPX66Es928Qe+TSqFg4+oPkZFdJIURjjJYAp0s0NjUTP49UU0FAMilKPHfnKXr4LftG9TeaOixD+9lzr3edKoqyqA7LULBmX0oig0g/fKKTtnVehjoT5fb8bg8HjYFR8Pecg58GR6YY6TfawobsWrQnDQRag4bkZZ1YVBCKnUNLCxfHwYAOBDpL/LBOv1tTZHLfy1NDZkVk4xo49qVBw/boDdNOjeGLJcSo/QNl8dDcWklYhNS4Lp6G34uqCbfGz9uDCquMvGu9lso+D9/nNuzAamhq/HOZBXw+UBLazs+WL9rQIFJIiiWfmyXNL+OTODyeMiobZRrfu6m4GgYG0wTO5OCSqHAe5kzWnMO4tKV67BxD5BYfKeJ3YLI6O+xwj8KGz52RrD/ml5XLHONZyIqq7SHEedyf5eZj33EugW6k1tcJTU9y0etHIwfN6bf7do47bjX9AC3794Hu/kx7t1/CE57R48gDMNqFpbamWOpveWwyqOUJ22cdiSnZiMx4yKMdTXh7mQD1/dsEbI7HlGHTqK6vgmXm9vxodFUzHhbA1nnSzBl8lugaUyAi50ZUs+XwcnOHNbmncgvLgfdadFQfyWZIe/8ViIGMZAUNVUVZewN9UNdAws5+aVQc9iICE872CwwEZl3zuXxUFF9AxnZRcgvZyLIh46C9Z793jdUCgURnnaoqL4h5M573MqBrZlsqjZfCONKPMnTpfQkv3WnCfq6U0Uep6L6BgpKKpGedwUAYGumj/mmBtCbpgUHW8EF371ipqqGieS089gdlyZTpfThSnFpJfzDE+DtYo3sxEihG261hyMob7wO3elT+/TdbfrUAzbuAfgu0g/JaedHtHGVZ35rVQ0TiRkXUXBm36D2Q+Sif7LChbyH/MMTcLm5HQyrWVBRHov8ciYuN7cjwtMOLo4LEbZ1rUSTEZsFAj0BecVKXgjjerOeJdUnee1NFhhez6ORxFPXLy4TEZ52MDPWh7fH+2Ibya6OfrrPzlED24WzuUUI/b+TOBEdKNIvamNpJtZ+qBQKXO1M8ccffyK/XLZSc0MNs/4uzIzlo6GxY/9xfBfpJ7UVF+F+sbQwIctSicyCoE3egwp+iRJrkeWD6IXwud6+ex/zTQ2ktr+orFJoaWqAy+MhNiEFK/yjQNOYgNacgwj2XwMHuwUDMo6WFiYI8qEj7JvvpTbW4Q4jLAGfrXxfKlFeM2N9xCdl4cGTTrm1+hgK7jS2QHsKTebHqaphYqLKOJmLIRGzWmlkFezYvBJRR06Tvldm/V1Mf1tz0PsVxQthXC9duY5pUydLZV9N7BbM01BGa1s7lq8Pw9P/PkPBmX1ChQmDgViuiqtJOpJp47Tjbz4wUXW8VPZHGBx3W2PcbWRLZZ+KSELhNbmkHF29Vo+lduYyP440mWOkj4kq47A98ggAID3vCmbqTZPJsV4I4xqVVYoZutpS2dfjVg60J6lCyyWg3wjlQAncsBxRR05LdZ/DkU4uD7M0VXHox0wypWowJch6OtqI378NCy2McOtOkxRHqjgQgiXyIO1cCcznDj+t2E0MN5zMq0LKz+dgrKsps0KLEe9zrWtgQedNCqIPJw86YZnL4+HgsZ9x9wGnTzHmwaKnow3246doYreMWN8rEfxredSGS1euY/y4MWSQ0FB/OrQ0NaBJU8eFWw/7lI0bCIb60xF16GSPKp6RwONWDvS0Ze8SyMkrgZ42bVhenyrjlTFX+y3UMm/LtLfYiJ+5su6xscH9XYx7cwzUHAQCLAMpvSOSpP/311/IP/ONzC8qWzN9dHZyZXqMoSInrwQ27gH4ISUbAOBJXwybBYIAQ0dHJ6IOnYSSFQNrN++Co94kXK6olerxRWkSjBSkHV8QBZfHQ0h0klBQdzihSVPHrzfZCE8rlmlvsRE7c23jtCO/uBxn88rgaGsGtw8Ww9PNEVnnLmJLRBzYj5+SOq5Ttfp+AhP10sNJbk5RiU1IQW5xVa/Rf0BQMXWAx8PNehZOpedi/VeHYDdvJhhevVdSSQrDapbMdDxHOqF74uHr5Tisfztb7YmYNEFZptoLI9K4Jp7KRGxSNny9HHG1oQlbfb0ACBKWvZc5w3uZM5rYLbjOvIWCkkqUXT2NjNpGMKxm4W0tdXJ5Om3qZNxtfICIwz8h3N9LpMqSrIjKKkXY1rVyO548yMkrQW5xFU4eDhUr6ZtIUSNcCFsi4qCnTcOmtR8NeuVgbDBN7rXm8oBZf5dcBciCtKwLqGOxh/21OX4sFQtM+xZxGiwjzrjGJqSg+vptZCdGAgBW7kuBzrQpPbbTpKlDk6ZOGkwuj4fGpmY8auWQ+o5Rh1OQd/UOvt/BkKthraphgmE1a0RVaxFLyRPRgRJ/LyL3ca7xTJzNLYaWSwDO7dkwqHNiYqSHgpKRl5Hx5OkzUl9B2hSXVpKFLsP92nzfzgx8vmyPMaKMa9dqESqFgqoaptjFA1QKhcynAwRP6PrGh7h8eo9U/auijHhXQQmiCgUAVMJi4OK4cESobxESeIOZKVIpFNCdFqFxriF8t3+L8mom/MUofRTFVC0ayq6OZmSIS3FpJRb67sPNk+HDMojVHVUVZbCbH8v0GCPKuO7YfxzRIQzyZrt6rX5Azv3YhBQkZlyUSqVUE7sFeRfLUHuTRarvEAafGJsnfTEpBhO0yRsAQKW+gZv1LOzYfxyVNXXD3tcbdeQ0Atd9JJV9adLUcfJwKKIPJ2NTcDRCv1gj8Xkqq6glBZRHWt+0Tu7AFaa608ZpR9a5i4hNykbl9yEjxo1iqD9dZiLZBCPGuLZx2sF+/FRolld7kwVP+mKJ9tPVrTCYm+7WnUakZuXhp5wy+Ho5wpO+WOLyvTlG+jh5OBSbgqMRm5AybA1sXQOrx7kZLFQKBcH+a5CWdQFaLgFIDV0tll5AXQMLUYdOAgDWvTsb95oejCjjOt/UALfv3pdK1VTXQO5g7wdFY4KaiszLoEdMKpYodRtJiwcIw8rwfB9rNu+G6+ptZBcDScjJK4HZ8u142tGJgjP74L3MGXOMBqYKT6VQcCDSH7nFVXJpkSELcvJLEeRDl8m+6U6L0JixD2fzyrAlLKbXIoPi0kpsCYvBCv8ouDvZIH7/Niy2NsXtu/dlMq7hDpfHA91nJ6JDGPBleAx7w9rGaRdKwVRVUZa5+PmImbkCws3q6hpYcDHUEtsfl5Z1AecKK2BmOB1+YXGIDmGg5VEbTNaEoyg2QKxZVxO7hdQFKD2xU2pLKCqFgtiIz6HlEoDWnFnD6kLn8njwi8tEa85BmR1Dk6aO+P3bkHgqE47ewYgKWo1J6hNQy7wFZv1dpOddgbGuJlZ5OAopKU2bOnnEK2QNlLO5xbA105e5v5+IQUxQU5HqdZ2TV4LcwitCQtgMq1lkfrOLoRZspk5A2ZUamJsaSe24XRkxxlVLUwPV9U2k4g3rHhv2lnPE+mxdAws7D56BuspYvPbqq2RADAAqp06GyZpwtOYc7PPkp2VdgFvYMbGXp5KiSVNHjI8zss5dHFaVRWdzixHhaSeXB4L3MmdMf1sTH2+NhfHb6lhkaQwzY/1eK/OmaE5CVFYp9ob6yXxs8mKsEhV1txsHvZ+zeWXYuPpDKYzoec45s/4unjx9JhS0BQQxiK6vRXja4V/OdgOanDSxW9DZycWYMVTMNzVAJX0xZuhqk/dz/D/b1TWwkH62AL47jsjM5TFijCuVQsF3kX4wWROO1NDVqLlxG++Yild9EXXoJJ79/j/4eC7tYRjnGOkj0MkCyanZIn2eXX14siyJBQAHWwskJA2v7rOJqbnYsXml3I5naWGCi8mR5ArCasHcXlcvqirKcDHUGlFlxtpTaMjOL0NxaSUKSirx5OkzAIJGgX39Ft1JKLyG+P3bpDImIsA27k1BibOL40IyXay7AW3jtONG3W2s8I/Cd5F+YvuOCf8wbcI4ofLfS1euIyqrFPM0lEltZUP96dDT0YbfWg2UVDDxuJUzalz7Y46RPhoz9uFA/GlcKLuOT7w+6PczbZx2JBRewy/ha+G8RHSdsSd9MT4NjhEyrlweD2fSzyM2KVtuBQbidkBQFAh/tawl6bqjSVPHgUh/hO6Jx6bg6F77KgGA+Wxd3G1kjxjj+vIrL+NCGROvvvIKacQ6uTz8mluCkOgkBPnQ+11Z1TWwwLAafFloVQ0TV6/Vo7CsFgmF18CwmoV79x+S7xNdOVwMtWBvOQcmRnqYqTcNlhYmsDXTFyswRxhjSwuTXmege0P9yK4gV6/Vk50rNFTfxMsvvwQtTY1Bf1dRDLlx5fJ4OJtbDEDgAxvsjahJU0fQJm9EOWwUqza/4fY9aLzxKuxtes+HffioDca6zzUfCZ0BFeWxco2itjxqE9kBQVH5NbcEGz4W34VR18BCLfMW+bf6RFWRrT7EZcrkt3Dut2tY6OaPlJhtIotJ9HWnorKmbkTkEgNA9oXf4LHEnBSaJphjJBBwPxB/GmfzyrDnyw19/q4qymMHPAaiQtJYVxNL7cwRuGF5j+4bBPEQnHfWPTYKSgS5tC6GWmA/fkqmJfbF41YOMrKLYGlh0uf3UVURlLrOMdKH9zJnlF2pwY79PyL16E6ZFUQMuXHdFBxNlpyarAkHw2oWNq7+cFBG9l7TA3jO08UK/yjYmunDk7641/2pqY7HG6+83OsPnJZ1Abvj0vBdpMAvRwStJGnGJi1kXdooTdo47dienIfWVW695pJ2b4tDmzAO9pZzQNOYAADkzRbj44xPVriIfRMQD79HnKc4HvU5wvYnYsGKL5F39EsYztQR2tZQfzrO5pUN/gsrCETwsIndAt/t3yKjVuB/Je6rvaF+yMkrweNWDm7U3cZc45lSNy6zZ+kiO9G634diG6cdj1s5AATuDAP96Qj2X4OqGuagA1zcf7QpikqrcY/9EIYztDHbQJds9/3666/BUE/8gPdAGFLjSjQ2C/Zfg5y8ErgYamGVhyM+DY5BdAhjwLOJq9fq4fbeQiy1t8TZ3GLs2H8cAGBvOQcLLYwxRXMSeeJokybibucfyMkrEVrad438E8UEVTVMgXvAy3FIgkplV+vxL2c7uR93IBz5IRUxPs5QVVHG2s27yCitk8FkjBujhNdfewU/lAgq6Oyteu9fv26VG478kEr2vxLnoUs8sAl3wM/HIrH5q28xf1UYmD8LK5oRClnxfexvuEBkyKiqKGPr14ew4WNnpNstIAtZktPOY46RPnmd5+SXyqRApbdz1PVhmnahHPfanuHRn39B500K7M308OARBxNVxvU7q+5O1ywhopGlX1wm3E3eRnkdG+8YaCEqsxTr3p2NB484iI34XC7qYeB3Aws+6f6STEjNzOUz/CP5nVwuv7XtCX+e0wb+zfo7fD6fz2+83yz0t6QE7jjAr7x6Q+i1xvvN/NTMXH7gjgN8mHnx5zlt4AfuOMBPzczlW9M38WHmxS+6VEGODWZe/NTMXD6fz+d3crn84yd/4c9z2kBuIy+I36CTy+XDzKvH+72dL3mdR1EUXargz3PawO/kcsnXKq/e4MfEn+LDzIvvzgjh/5RxXuh9cffZ3+9fdKmCDzMvfmvbk1730Xi/Weh1hn/kgK81aSCtc3iz/g4/cMcBwWdFXCvdaW17IvK36rofaVB59QY/Yv9RPsy8+BH7j/LPXSjm7znwAz9i/1E+n8/nn7tQzHdZFcTn8/n84yd/IV8XF+K7nrtQzJ/ntIF//OQv/Na2J3yXVUGkHTh+8hd+TPwp8jOpmbnk/S0tup+vISkiIAQgQr8QqPhv/fqQkISZJk0dQT50/JSZN6D9iyoe0KSpg+60CHtD/cC/fAJpcV+R1VvvzNGFFvU1hEb/iJfmrcDZvDI0ZuzDUntLFJdWwsY9ALU3WchOjJSbb47L4yEy+ntsiYgDIGiXLI0gg6xpYrfAPzxBSKCluLQSO/Yfh940LbTmHMTp+K/h9oG9REsySwsTpMV9Bf/whD5b4BSUVJIzZlH7iA5hwHf7t0KvEwpZLwJtnHby91NVUUZq6Gokp2bL5FixCSkwd96Ig8d+hpmxvlCPucdtT8lVmIPdAtJ9YWdtTmY4iAuR8ZFbeAVpcV/Be5ng/GfUNpKz6PlmRrh3/yHqGlgD0nMeCHI3rk3sFiz03UcutQnXQPdltq2lGbYnS25cxS0e0KSpY46RPuhOi7D7S1+cjNqExkf/xXzaeFiZG+JA/GnYuAcgI7sIJ6IDsTfUTy6BqyZ2C6pqmFi+PgwAcPJwKABBl0pjA9n0+pEWRDpMdAhDKMXG0sIE6cd2wcFuwaB+Q02aer8GVl93Kp7+t/ebk3g4dm1QaDBDG5U1dQMelyJRx+q/N5h/eAKZybHU3hKJGReFKtuUlKhi7ac/XN+zxckDQQjcsBxWC+b2OPeP/vG3dj12ZycXQZ/1H8jqCpHxsWntR8i7KEhDa+MIWnITVY0/ZeYBfD5W+EcN8luJj1yNK3HzFcUGkIa1+vptHIj077Ft1xxESZCkeICAy+OhoKQSeppq2LN1NTTeUgPDyxnZiZHYG+onE7GKugYWiksrkZZ1AVvCYrB28y68NG8FXD8Nw9L1u5FR24iyq/VobRNceMz6uzAx0pP6OKQFcW59vRxlOrvvz8AutbfEncYWREZ/T3b47I6eNo3MJGnjtCMh+SwulMpWxEMe6OloCwWwRM3QVFWU8V2kHz4NjgGXxwOVQoGvl6PQ7FWTpk7uZzBo0tTx345nZGeJLWExAj3YBhbet38H/uEJSDyViXVbvsFaa0OYO29EQlImVMdL9gA2M9ZHQUkl1FSVofGWmuDfDhvR+qQDK7/6DsaO6xB56j9ofvykT5F2qdOf30CafLwxjPRzxMSfIn2uvRG444DEvjDCpyMujfeb+S6rgvgR+49K5AOUlE4ul190qYL0PbmsCiJ9vkWXKkR+T8KHRPigu/sK+XzF8Ll2crl8l1VBQj4tWXOz/g4fZl78pNP/FjmeiP1H+Qz/yB7+xE4ul/wtu/roevPTygNpnkOXVUH8xvvN/d47xLXH5/PJmEfX618cn60kdHK5/MqrN/jHT/7CD9xxgD/PaQMfZl58nXc/4buvDeEfP/mLyOtbHIjxd+dm/R1+de1N/rkLxfz77Bah9+Thc5VLtgCRznS5uR3ffv0ZtoTFgNPe0WdyNyDQNhUn160rZVfr4e3xvljb5uSVYMnWQ/jKbSHKrtYLks6loHLflSZ2C9J/zUdixkXYmunDxXEhOsXUIHWwW4COTi72xgoa9CliojuR9mRvOUeuqWl6Oto4uW0F1u9NRvnVOqxb6UrOSAjFLEJrgJitcHk8bI84ApMZWvDd/i0mqowj36u9yRoRCll62jSybfijVo7QLK24tBItj9owbepkMLycsSUijmwJb6yriaMnMsg0OADkzFYadO0sIW2I8VfVMIX2T3z32bOGZsUnU+NaVcMk06CiQxi4dacJag4bcTzAA+6ui/s9cZebJdPaJJZB4hih2IQUZOZdxnKz6WA/5GDH5pUCEQ+fnVLRcS0urURGdhHyy5nw9XIccLHBUntLhPxfCpytZCMuMVhC98TjbS31IZFDXEZ3xOO2dlworhaZ00xoDTgydmK6hgqq7z3Goz//wo6PrOHtvkTIfSFNqb6hZL6pAVoetZH/J0jLuoCzeWVYamcO4LnhIUp/Q79Yg7J/GkF2dHQiwnN4pPwRuDvZ4NfcEoU6fzIxrnUNLBSUVCD+zAWhfFVLCxOxjCogME7iRseb2C0oq6gVSvbvi8RTmcgprETr004hPYE5RvpIPJUJ3+3fitXnqTtEtVliai4AIHDdR0IqTAOBSqFgrZsN1MaPG/A+ZEVa1gVw2juGtJ/SJytcUH39NjycraE6fhwOHvsZCYXXSEHyOhYb2m8pw8XeHF/O0oH1O6Yi9zNSFLLUJ6oiI7sI9lamKK9+LpdJtGcRyvHt4nsm2h4NV6wWzMWSrYd6zZceEvrzG0hC5dUbfJdVQfylnoF8G7fPBuXDdFkV1COnsZPL5d+sv8M/d6GYf/zkL3y/bd/wLV39+MaOPvyY+FM9cltFQeSLmixdJ9InRfjkJPHbtrY94cfEn+LPc9rAj9h/VOo5k0WXKvgM/0iR7w2Vz/Vm/Z1e/cDypnteNHGd3Ky/I/b4iJzPoUCa57Drb0HkjvL5on2orW1PZBpnkDcx8afE9vsPG59rXQMLRxLTkVpwFcl7/QYdLU48lQklyusABLOjS1euo47FJju0GhtMA01jApzs38G1W/fxqcdisSumam/cwszxSvglYYfIJzWVQkGQDx25hVf6FWOpqmEiOe088suZMlVrn2s8Ewt99+GAFH1gg4HL42FLRBzC/b0UYrajSVNHuL8XtkTEkSsOSSPCI0Uhixi7khIV7MdPey09rmtg4VErZ8RoKgCAp5sj1Bw2wtPNUSFmr4MyrnUNLCQkZaKOxcZLeAk/fRuAeSaDS3Q/l1eCz749g3d0NFBQUgl93anwpC/GBDUVpEmJQPMAACAASURBVHe76OsaWNCbqoG0cyViG9eYo6kI+sS5zxto2tTJvfbX4fJ4KCypwKEfBdJ/Gz52HvTSvz+oFAoYVrPQ2NSsED2MzuYWQ0+bJteOuP3hYLcA5dVMhO6JH7A+60hRyPJ2sUbexTJ4u1gjv7gcdKdFZGqWno422jjtmLE8BOf2bBjqoUoVVRVlxPg49yoP2p2Ojk6ZjmdAea5N7BayZYa9lSnSj+3Cz8ciB21Y7z9owbLgI4j81Bm/ntiLYP81oDstwhwj/V4v+DfHUMkxicOPpXWYPUu31/cJ/YDuvbfaOO2ITUiBkhUD5dVM7Ni8kkyMl8dsUlGqiLg8HnbHpYHhpXiC3f7rPcFp70Ba1oUBfZ5QyBruONhaIO1cCVzfs8XuuDQ0sVtgZW6InHyBKv/jVg4CnSwU6uEoLTzdHOEXl9lrux8CQ/3pqL3JkulYJDKudQ0sREZ/D7rPTsw3NUDBmX1SPUH7Dp+EgcZ4rF/jLtHn6EsWIO+ieMpG70xWQdyPv/R4ncvjIfFUJj4NjhESCGnjtCN8/1HYeW4FTWMCWcIn76hk1xSZoaSwpGLQLbJlBZVCQegXa7A7Lm1Avc8M9aej+vptGYxMvhDnprOTK9Bv9dkJS4s5QkZHGhVYighR0rv7QOJQD0U849rGaUdk9PdY4R8Ffd2pKDizD3SnRVKdsdU1sJBZVAs/7/ck/qydtTnSzonXvG+N27s4W8oUqu6pa2Bh+fow1N5koeDMPswx0geXx0Na1gWoOWzEmZzLePmllzBWiaoQvpyh5ExWAVwcFw56P03sFrLOu/t/vVVWiYMmTZ2sQJK0uo9QyBrM8RUFbzd75OSXgu60CNEhDKiMH4fjAR7Y+vUhUhx6uDa87I+l9pbIL2fKTUOgN/r0uRLyXYkZFxHkQ0eBmMnvksLl8RB16CQ+tDXG66+/JvHnCZeBOMEIutMirD2Qho074sBwexfjxioJdRNo47TjbG4xdselwdZMn+ydVVwq0BYdbg0CpU1C4TWR5cqiIHonEf7rrn2SXAy1hNpxdCUqqxQuhlrwdrPHUntLia+5OUb68PVyRNg33/dbqNKd4wEeWL4+DPaWc/Dh+7aYPGl4+l9tLc3g6B2MT1a4kEEr72XOeNrRieXrw2BrYYTs/DKFdw20cdpBpb4h0TkkgtIJSZlD2h9NpHHtWlUU5EMXatgnC46eyICK8ljMnztwfUXCNdBfYEtVRRlFsQHwC/sOTzue4eHjJzgYth6cJ0/h88VufFdQixgf5x45gZYWJgh0skB55TWpXZBN7BbcbWSj5VGbSAN0bs8G8liKIJTdxG6Bi6EWKqpvAEC/kWaid5InfTGUqBQEbfIW68G0N9QPTewWJKb8G7vj0gZUD+69zBm1N1k4eiJDogIH72XOmG9mhA/XR+LtKZOGrXFVVVGGq50pog8nC3Ul8GV4wMHWArXMW2JXMg4VRPxDkl5aBEvtLUl/81AFKEW6Beg+O0HTmCCT5X93CPGWwSaizzczEts1YGlhgu/3fAbwAd7vf+BM5n9QXs3EdwW16CxMgC/DQ+QJmW9qIJSYPRCqapikFBvdZycKSgTuCU/6YlIshn/5BPiXTwgZ8bKr9ZiqJXqmJ0/+/PMv+IcniDUWQuZxjpHARyvJjF+Tpo5g/zWIDmFgxvKQPmUGeyNs61okZlyU2P+qpETFH3/9jbCYFIldC4qE/3pP3GlsIZXnCPR0tMmyV0Vmx/7jiA5hDCi+QQjSEFVn3SEe/LJE5MxV1jNVgq6qWIM9np6ONtiPn4r9pBJV57w9Oa/PcahPVO01Rasv6hpYyMkvRWLGRRjrasLdyUaiEltJynpliSZNHb/eZON4gOiHjyywtDBBY8Y+UspQkrxMoiPwjv3HJaq423/kJNzenQMD3anQcgkAw2oW3J1sYGYyvFxCVAoFByL98Yn/bjx8HIedQT5DPSSJYD9+ipl6z2U2m9gtOBB/GlMmvwUTI71+W9TMnqXba9Xd7bv3YThDWxbDJhkSsexRRhlllJGOSOMq61krl8fD2s27pDZrJSCSpweKk4FmnxHGypo6sSPlTewWJJ7KhOvqbdgSEYdxY5WQnRiJ+P3b4GC3QKKZX0JSJrzd7MXeXlbUNbBgPGEs3F0X97+xFNGkqeNEdCAW+u6TOAI8x0gfeto0ssOwOGQW1UJV+U14L3NGa85BuDvZ4ExWAdQcNmLt5l3IySvpN49SUaBSKPjsEzoy8it7uAe6oojfydvFGjfqBKlxhF6wJ30x9KZp4YeUbNi4ByA2IQVVNUyRGR7POrm9tqJn1t/F9Lc1Rb4nLeQ+c61rYMHGPQDGBtMQv3+bVA35Qgtjsf2uolhiZYIP1kWQJ6qJ3YLi0krSSOYWV/W5LCUM6trNu0D32YmnHZ3Yu90H6cd2ka0nJKWugYX8ciaW2lsO+HtJi4SkTHy10X1ISnD1dLRRFBuAFf5REhsBhpczdseliZViVVXDxDSN8dj643lU1TChqqIMB7sFiN+/Da05B7HKwxHl1UyoOWyE6+ptSDyVqfCpW7MN9XC1tQNXahp6NbC5hVfITqyKgi/Dg7zfNGnqcLUzxQxdbfJ8ZCdGgqYxAclp53GzniX0WaLd0Hv2PYPPXB4P25PzhFwOskCu3V8JXdfBdHbtizlG+hL5Xbvjy/DAjqO/YvHyLShuasM8DWXYmuljvqkB9m736RGx7tq+N7e4CuzHT+HtYj3o1uBdSUjKRJAPfcg1BQgjP5QKWJYWJvD1csTWrw8hfv+2frcnUgnv3X8Ig7cnoaL6Rr/XXVFpNbw+sMGeWbr4NDiG1OC1tDCBqooyLC1MYGlhAv/1nrhZz0Jy2nlolFQodEoTlUJBoJMFPnZfggMJqT06HXN5PERllQ7puRWHrlkPAMjJyvhxY3D77n3cvnsf7ObHqL5+G9X1TQj39xJ5H1ZU3wDDSvb+c7kY165tqvsTNxlsvS9ZVz3A1teq1NfQ2NqB/WuW4v3FlmT/dPaDh7hYcgU83u9oftiKwrJaJBReA8NqFpbamSM24nOpB3ma2C1DbtAIFMXIey9zRmFZLdKyLvQpD0jkJQc6WcDFcSHWhhzG3z9m9mlcuTweEjMuksHGgjP7UFhSgR9SsuEfngBvF+segZTTeZXYtPYjqX9PaWM4Qxv1txsR+sUavLf6K5hm5MF58TsAgMTUXBwP8BjyczsQzOcaQn2iKqldqzdNCw62FtDS1Oj1+xSUVMLdyUbmY5O5cU3LugC3sGNIDV3dr1amof50RB06OWDDCAhcAzv2Hx/QPto47aj/Lw/HAwR5kQlJmYjKEtRjG6mNAfW11+BiNxf6ulMRuGE5DkT2fgKlQfqv+Qph0No47Qpj5AEg9Is10HIJQONcQ5EPNMKw3jwZTq42Nngswjc/nutVJQoQzGhoE8aR+6RSKHCwW0AWl5RXXkNGdhEAwSzaZE04Fk0bHjqoXSPn9uYzYW7yfEYnalWm6BA54pYWJhL9/oRLoHO9pwxHJ0BmxrWugYWoQycBAI0Z+8T6AfR0tPGI87RHu4a+eNjaLuQGGIxrgMhptLM2Jz9LVHgQCmDdlyaygsvjwS8uE605B+VyvL5ITs2Gr5fjkBt5Ak2aOlJDV+NA/GmRFTj+4Qk4HuAhZDAIQY//FJbB7QPRAbmCkkrQl4he3hO+V2I5TfhZXRebD/LbyIcZutrk0v/VV1/B3NmKqQ8hLteZt1BezURBSSXes18gtr0oLKlAhKedXK5lqQe0uDweNn/1LTw/3wt3JxvE798mkZHbsXmlRHXhjzhPEfaNcKfPgWYNXPytElOor0t9JsLl8YS6vcYmpGBLWAy2hMX0Gpw5m1uMCE+7Ic+rJJbKTkush3Qc3aE7LUIdi92jPr6N047Lze09MhpUVZThv9QMR5KzIQpiRmNnLZ6xbGxqhovhFIUR1OkPQrayovoGpkx+C6x7w1u4xUB/OtLzrsDMWJ9sJSUOZ7IK5FbpKFXjmvpLLibZforCinpkxIcOyMk/x0gf0SEM0H129issoaRExaMnz6CiPBbRh5PJ113fs0VsUrbEUdyn/32Ge9w/UFxaKSQkUlxaiYSkTEyZ/JZY+6lrYCEnrwSR0d/DdfU2KFkxEHXoJFmNpTdNCwwvZzC8es8g2B2Xhn85D30fo4rqGzDW1RxyIy+Kvdt9EBKdJHSeCdHrxqbmHtuH+K9G7i3RD+2K6htwMdSS6MH64PFTTJs6WfKBDxGrPBwRdeQ0aBoT0PFPe5fhiiZNHbZm+hiv/Ca5Uu2PJnYLquub5CYQLhW3QFUNE1t3JaD09kNMUx2Ly1mDW8paWpjgRHQgEpIycejHTASu+0jkD6JJU8fl5nYUbF2LTcHRZJCDSNuIPpwMfwnEZu40tkBvHAU/pJyFivKbQu/NNzXokQ7F5fHQ2NSMWuYtMkpJBLmMDabBzFgf3h7v9xD57o+cvBKFkfUrKKnEKg/HoR6GSPR0tOFqZ9pDP8DbzV6kaEdfD4gfUrIlyiVm3WNj3Jg3JB/0EGJpYYKM7CL8mHoBHs6KtRIRlyZ2C9n3i+HlDD0dbXwX6QclKoXMgVZSoop8SBIC4vJi0MY18VQmkn4pQOOjp/jQQg8MT+mIQejpaGNvqB+KSysRdeQ0fkjJRuCG5T0MDjFLCf1iDeg+O6E+UZVMlTl6IgNKVgwEOlnAcIY2pr+tialatF5nJwmF11AUG4CFvvsQ4WkHfd2pUJ+oijFKVNy+ex9nc4vBrL+LJ0+fkYGuQCcLTJn8FhmljN+vLXLf4sLl8RASnYQT0YGD2o80GIjzv6qGCZM14YjwtIPNApN+SxQHy7pVbj1aexCiHd2DV701vWzjtCOh8Br2fCm+Mn9HJxcmBtrDrmNs2Na12PV/4i+jFQWikzT78VPYmgl+b057B6rrm2Brpo/8ciaMdTWhojyWbLvUXbAn7VwJYiM+l9uYB21c3V0Xo7CsFs5283Dv/kNMVFORxrhIiLzC4tJKrPCPgq7WW/jsEzrMTQWtpgPXfYQV/lE4ER1I1pF7bYmBrfE0fODwDi7s98P//vwLHZ1cFJRUouzqabIXl4ryWBjO0MbYsUoYq0TF0hk0WFqYoDXnIMorr5GfefL0GQz1tdHAYmOJrTkmqqmIrfAkKWdzixVm1nqzngWG1SyJjOMcI33y98vILsJC331kuhoAsJsf4979hz0+ZzhDG05LrCX+TQlxZFfGVziXtAdUCoWUnOva7oPL48E/PAHRIYwe+yivvDagvMf7za2orq0fkCziUEGlULDE1px0USk6XB4PR09kIDHjosj8+DZOOx63coTuRy6PByUrhpBxJcR75JnZMWjjuik4GsYG0+DL8MCWsBhpjEkklhYm+NL3I2ze8yM+3nIALtazEbTJG5YWJogOYZB96/du98GDlsfYGBaP1159BW+OoeJ2UwsyahtJDdFUN3s8af8v1FSVceVqHb7+qRCrLWfCzGg6gOeR4a5weTzYuAdgia25zAwf0UJFEWatgCChnjCKktA1sh62dS1u1rNw++59AM/zELuTk18KR+/gARWYLLW3hH9UElzXhCBmpy/0dLSx1N4SNu4BWGhhjGedXDJPVdS+CdeTpMdkNz+GX1wm1np/CE3a8DCuADBRTQVPnj7r9f3i0kpU1tRJJNUobeoaWLhUXoPYpGzYmumTYlKEMWXdY6O8min0PeabGkB9oqrICV5RaTU2fCzf1kSDMq6JpwRN+j5Z4UK+Jkspr5rrt7Bn83IstbfE2dxiOHoHw9vFGp5ujig4sw9nc4uxwj8KrnamyDn+NX44lYWyq/WCElQdbdQ1sNDJ5eH23fvo5P4OZlkt6lgClaf+8mKpFArS4r4C3WcnfL0cB5WL2xtn0s/D1c5UIWatAJBbXIW92wenpESlUEQqkHVHT0cbDrYWWOEfJXJJ198xogO9UFRWgy0RceTSsfP3/8EnOBYudnN7NdpNbMGD96TxzF7331XPgHWPTQaD7t1/CIbVrGGR5yoJU7VoiDpyekiNa0b2RRzLKIKFwRRw2jugZNVzxdGDf1x1APD5ElPy30OV1jhg41pVw0RsUjayEyPJJdF8UwOZ+aDaOO3/LM+ng0qhgO60CEvtLXH0RAbUHDYixscZnm6OpOF1/TQM3i7W8Ge4kQaXCG4NdHyaNHVkJ0Zi69eHUFhWi9Av1kjtxqprYJG/pyLA5fGQUduIdDkaej0dbfIBpjdNS6JsE1tLM7iFHUNnYQJa29rR2cklAx59kXexDDE+ziKX9bEJKfCLyyRdSAAwZfJbZPqVvZUpzAbZlFMR0aSpD6qMXBospy9B8ZUbeHMMFa5LF8LYYBpyi6uQUdvY5+f8Fpsgr7wOKz2Wkq9VVN9AoJOFkNuHy+PhTPr5fl1R3EG0sx+wcSUUwrsObKwSFXW3+/7yktDGaUfWuYuITcrG5eZ2zByvBCeHBeQNQ6VQ4MvwgKebI5JTs6HmsBGpoaux1N4SS+0tceRYKmw//xb71yzFn//7H2zcA/C59/ugUN8Q0mUdP24M/uVsJ9aMUVVFGfH7tyEt6wK0XAJwPMAD7q6LB+Vz4/J42BIRh3B/L4VJeWpsahYZ/JE1mjR10sBqT6GJPYtXVVFGhKcdCiWo8+fyeL0+0Ait4c7ChGHjT5Umvl6OSP81f8hmr5o0dZw8HIqjJzJw8uc8xO/fBl+GB9o47bhRdxuVNXVCvvv5pgawtTRD1rmL0JumKTSBysgu6qFmdyb9PFbuSwH2pZATs+73HqHENVB96wHnuZ6IDuwxA9SeQpNa98w2TjscvYMBAGlxX4F/+QS+3bYKX0R+3yOnTVVFGQ62FvjYQg/s5sewcQ/A2dxiGBvqwGTim7hefw9bE89D6Y3XEJt0Fh0dnXBxXEjmmlIpb+D9T8NxuRfVclHQnRahNecgnnZ0ktJnA5Vsiz6cDPPZugol/tHJ5ZGzNXmjSVMn/eiS5CrbLDCRqFMEETzsflNJU8R9uOK0xFqsFtWyhEqhkC7HyGhBoRAhnuPL8MDeUD/yP7rTIlCpbyA2KRuu79mS+2jjtCMqqxRzu7h9qmqYAsP6D35xmVBz2NjjHg775ntcbm7HpuDoAY1/QMa1jdMuckYhze6ZyanZCPKhw3uZM7k0cbBbgCAfOikC05VHrRzoT9eEL8MDJ6IDcenKdQTtTcTSBYbIr7qFjy30EBG4EiXpMfBe5gxLCxNoaWog6tBJXK+/h40f2cHcZ7eQf62N097nd1FVUYYvw4Oc+ag5bMSWsBgUl1aK/RvEJqTgTmML/OVQ6ywJt+/ex3zTgfc0GyyWFiZwtTPFmfTzYn9mpt40pOdd6Xc7orPv7ri0HqIraVkXkJhxEXu+3PDCGlZAcVpUE90Unjx9hk3B0X0WCxw9kQFXO1MhV0Z55TUhtw+Xx8OnwaID712NbGJKJhIKrwEQpGj2pYXbGxK7BYimYca6mrAyNxSqwwcAhtUs3KxnDdrvSqgTdYfutAhn88p6yKY9e8bFuDcFwrh6OtrwpC9GxXUWSmtu49/fhfR4GBBT/q7Bkyma6vgpM4/UDyguq0J88lkc2uXfp++JMLKfrHBBRfUNFJQ8V2Sab2oAQ/3ppLoWAdEZNTHjopDfepTnEDms4qZoqaoo43JzOxlR5v3+BwDg77//JrMVLl25jvxyJmzN9Hu02ikurcTuuDSkxX2lMO6ZoWSpvSUSU3N73GvyhkqhYG+on6BIyGcnKQM6VokK7Sk0sO6xkVt4BZz2jh6diQ/9mIkdm1eSf4fuiScbgPaGX1ymyNdMjPQkymSR2LjOMdJHWeZBVNUwcfVaPXy3fwv246dwtTOFzQITmBhOx9Vr9YM2rpeb23s1aIEblmOFfxSsFswljZL2FBpyC6+gjdOO3QcSkV/O7DVCXFxaSeY8dn1ffaIqmPV3yb9z8i8j83oTqpdvQ/HJXf0696kUSg+9z6vX6pGQlCnU1RUA5mkIunP2J8H4IqOqoowYH2dknbsoVnZGE7sFlJcAc3oAxrzxKjRU38TtZg7eMZiCv/7+G27vWcHFcSGCNnnjcSsHj1s5KKuoJQtD8suZEvU2G+lQKRTs3e6DGctD0Jgxfch/FyKIXVF9o4vP9QrGjxsDeytTIXsACK4H9uOnpC3KySshi38GwkLffWKLUAGDCGgR6TXey5zRxG7BdeYtFJRU4tS5UlBffxVPOzphYqSHiWoqImeNnV1qm7vP6vpDT0cb3i7WOHoig8yZrLlej7MltYjKEgS1wrauFTkbJOToimIDehjeqCOnhVKP/v2boIX0vc4/YLl8G46F+8DOqmeOpijETUEapW9c37MVrDDEMK7pv+Zj4TR15N5qgc5LFOTUP4CZujJ+LK2Dxhuvor7xEfmAIzIA5psawMxYH9pTaL1eMy8yejraOLdnw6ACO9Kk6wSmP7qWuzaxWxASnTTo40vyO0hFW0CTJtC0dLBbgGD/NahrYIF1j/1PRVR9j/QJIpmfgJjVBTpZwJO+mDRIVTVMUl2ciAxy2jtIXwgAMK7fhoryWEx6SxWLzWfi7PrlvT5Z6hpYvRrW2IQU6Gk/j043sVvwN59Pvn+v8w8s23oIp/ZAbAM7yuAhBDqKSyv7vKFOpWXju5/ykH9yLx63ctD0oAUTVJ8/tJWoFHRyeUM++1IEapm3xBYhAgSxjrrbjdgUHD2sgnxp50rIyVJnJxfeLtYw/kf/Y6Bcbm5H6J54kVKX3ZGJnquejrYgKVwCPw2XxxO0X9h2AHZm+tCkvIaDx37GUjvzHlU9AxWpTkjKRIyPc4+bNC3rAnKLq3DycCj52i/ZBbjb+YfQdo/+/Av5xZUvhHGVdlrdYHBxXIioI6d7Na5pWRcQGJ2CmKCPoaqiDFUVZZEB11H3i2Dlxmy4C32dqRJ9zpfhgdiElCE3sFweD2dzi0nfubGuJt7WUu+h6UoEvojrgLBJABAPkBPAutuNuHf/oUTugqisUhjO0O53NSXXHlp9QUz35xloo6a+EdW/fCv1m8GTvhgma8IxbqwS+cMQUeO0uK+ELpgTvxT2+PzE117BkndHvmEFnvuwJaW4tBIz9aZJ9dxZWpjA6bPoHoGVNk47tn59CACgNvYNWC8w7W0Xo0DwexFaD2azJXdXdTWwe77cMKQPK4aXM+k7fySisWLexbJehc+BrhNAwd+EbRCXlftSMP1tzT5XU3Lv/tofHzouRNrRr2Vy4uYY6aMoNgAr96UgNiEFQV/H4tCJf/cIYjSxW9Dw8GmPzz/68y+hfLmRjJISFXUsyQWVnz3jwtE7uF8tXkkJ9LDFp2EJiE1IQV0DC2lZF+DoHQwrc0NsXP0htDUk89u/iCSnCoTCH3H+C+0ptH62Fo0vwwPGBtPg6B0stqC9NCGqM/V0tMkViqWFSY/YRtq5EsyepSvWPvtKz+oL//CEPvOAFWbmSiDrlA9LCxM0ZuzDhm3RqLzdgv8khvXww/2SXYBHf/7V47O+9nOGjb9psGjS1PssNSSq57qnSTnYLQCF+gZ2fpuMM1n5WOvljPH/aOMSdfnM+rsou1qPDR87i32+vT3eR9qFctA0JpDC5cRDMTYhpc9ZyiiC8+UXl4njAR4Iik2FlqbGgPfly/AATWMC6D47FTK7onuWQH9EH07uNz2rawCUSAHrqwkioIDGVdZweTyEffM91NWUURe3A1QKRah+mMvj4ZvEcz0+N/G1V7DMte8GiyON2WpjcSotG8voPcWyCYPq6B1M5h12dHQiNikbtAnjMFtPC8VVDbBYt4e8MMePGwN93amwWWCCO40tEs2eNGnquNLyFHSnRUKNLiUV5Ug8/Su8P3pP7OOOFJJTsxHoZAHvZc6ovcmSqExYFHSnRVCfqAq6z06ciA5UGLEhQNBfS1xR7KoaJrYn5wF4HmgnZEhF5adLwgtlXMuu1GBD6GGscrXBJytcSIMaGX0M7y6cCzsrC2T8mg/u/3rOWqmvvfLCuAQAge8UAMaMofa6jfcyZ7i7LkZF9Q20PGrD2LFKSIv7Cmqqyog+nIxJE95EUcgnIv1SBSWVyMkv7ffpT9C1cq4rkvQaq7t1Fyv/Lw3uHywClTK8uggMBmLWevOkwKe4ae1HoPvshIH+4HJXCbnPGctDRGbgDBXl1Uyx+2RNUFMR6hIsTRTO5yoLuDweEk9lwuWzfWC4vQtfhnCP9uZHHCzaHIOo2EQEHziD5t//12Mfa12GjyDyYGlit8A/PAGffeyImuu3+tyWCEQSM0o1VWWyFvvk4dBebzhvj/dx7/5DKFkxsHbzLmwJ67spZUJSZg8hGUL/VtxeYzkFlwEAFVfF1x8YCRCzVsKAENoNdJ+dg/abEm42//AEUoJ0qEnPu4KZetPE2laTpi6zWfeIN67FpZVYvj4M5VfrMGkcFSuX90yfaO8QFDTsTsrFY+4fPd7XeONVbFj9L5mPVVHQpKmjLPMgXN97V6xafQIuj0eKpwf7r+nzYaRJU8feUD/s+MgGk95SBcPLuddZVHFpJfLLmQj9Qrit+Zn08xJ1bUjMFATZMs5JN9im6PjFZYLhJXzdE7NOaRhYQoqzsKy2z47G8qCugQXahHEKEdwcsca1uLQSrqu3IerIaezYvBIaE1Wwhm4r8ob/85/gVdv//sZ//+Zj7MsvCb2/1mm+QpwseaOqogzahHFi33ytbe2wMjeUSKZui9/HePCwDVGHToq8KdOyLsA/PEFkRsfKfSkI2uQt1nGqam/i8j8ZIFHZV4bUAMibCE/RcpqWFibwdrGWioElpDgNZ2jLJFtEXBKSMiVqNClLRpxx7WpUA9d9hPRju6BEpSA974pQx4SupNfeE/q7428+Xu9iXz/3WS7LISs09CULkHexTKxtNWnqEndooFIoiN+/DVbmhnD0DkZsQgqqapjIySuB6+ptOJtX1sOwEkHJMWDOxwAAIABJREFU1NDVYj/0fr0gnCReXnVDonEOZ9atcuv1PV+GB3y9HKViYAGBH/5EdCAO/ZiJtZt39eorlwU5eSWoY7F7dGkeKkZMQIvoEgtAqBU3IUQdHcKQyGf6Bx94BcAaG8kb140k7KzN4bv9W5m0temK9zJnOC2xRn5xOZLTzmP8uDG9tlQ/eiIDKspjhbIG+oLL+x3bT18Ueu3Mr4VweHe+VMau6PR3/Xovc8b0tzVB99mJ7yL9Bq2HoaejjfRju1BcWoktEXGYqDIOqzwcZRrwKi6tREh0Uo9ioKFkWBtXohRud1wabM30sWPzyh4XxtncYuhp03o9sXUNLExVer1HqSsA/AUgvYQJlZ2x2LFFMuM8UiBmjFU1TJmL0KiqKPdItepOVyFrcREVwEoouYnQIWxjomgQPliTNeFSi/x37dz8Q0o2/MMT4OvlOKAuv32ReCoTsUnZCpdzOyyNa9f2L7Zm+r3m2TWxW+AWdqzPHMibt+6KNKwEj/78C3szL2H5h/YvrMKVt5s9ikqrh/z7D7RDQMFv1SJfzyu68kLmvPaGpYUJbp4MH1CTyP72a2lhgiZ2C9J/zYejdzCpBz3fzGhA0XpCiyTqyGnoadMUUrpzWBnXugYWcvJL4RcnEGDp7wc9EH+6X79cTv7lXt+b9MarcJirg/CgtQr1RJQ3tpZmUHPYKLLPkLwYTOsVfR2tHq+lBntBfaKqtIY3YiCaRIZ98z22hMVIVYZRk6Yu8PEyPEg96C0RcciobUSgk4VQ8r4oHrVy0Hi/Bdn55Tj+GxMuhlPg4/U+ltovFLn9UCOWcf33+SJExKXjtwdPwC9OkPWYhODyeCgsqcCZrAJU1zchyIeO1pyD/d7khHO7L2kwLo+H2NyqHq9rvPEq7GZrI3TzKoWqPBkMzPo7uHipGjlF1UitbcQ7k8aDbjcXH31ghyn9lEKqqiijKDZATiMVhkjvAjBgNSb6++8CkUk9XxtGDOb8SYomTR0HIv0RfTgZy9eHITbic6lPLrrqQXN5PDQ2NaOWeQsdHZ1ISOo9X3bK5LfwjMuDycQ3YT5bh+w+ooj0aVw7uTwcOpaGwKQ8iXa6JUwggkA8iSSla2fWqKxSRHjaSeQQ5/J4CIlOwonowD63q6gWRIxnKFNxs50LR71JcF40D8s+XKJwS4zBcOrnHCz/5rTQa789eILfkvKQlleBU99+0e8NOhTVN0RLIWkuUYcj3xxK7nEPEucvMCkPd1PCpW5gqRQKgv3XkK1VeuvqIa1jdZUE7Iu6BhbqbjfhbjMH+rpT0fKoTSZjkga9Gtd7Tc3Y/HUc+ZT87cETsXdKJCzXMvuu7ukNT/piKFEFM5SBLEuiDyfD28W635M1VYtGlgSOlBlqdzq5PBSU1eKdSeOx3ccV800NAQDnC8qw/JvT+O3BE2T/5xI+/dh1iEf6nDZOO478kIr0vCtSiV4Pd+bN0YdbdT38VjpjnokBlKgUMOvvYM22g/jtwRPsOpiMw7s29/r5rtoZkkJ3WoRpUyeTD7muZeNDxb0HrfB2sVYozWFR9OsWyI/aAPWJKpi5KkLsnXYVqJU3VTVMpOddQcGZff1u+yL4UZWoFIQHrgGVSiEfWACw7EMHcjZ7t0v/96GECHgQ6k2K0FZEEbBZMJc0qgT6um9jk5cDfvvmNI5cvI7DfXz+bG6x2GlrophjpI/sxEhs/foQNgVHI/SLNUN27/B+/wOl9Wzs3f4pAAxIc1he9FpEMEVTAz/FhcJmwVx5jmdQNLFb8GlwDL6L9Bu9Kbugpjpe6MYEgNa25yuRBUPYQpuAy+PBd/u3GDdWCa05B+G9zHn0HHah+/kDgKcdnQCAddZ9n7/dcWmDbndPVGAttTMH3WfnkFVgZeUUgfG+xbBYaY6YCi2iVXZ0COOFX0b2RyeXh5Co7wEIbsx3F5oN8YgEOgF62jR4L3MeUf5uadLa9gTM+jtg1t/Bv88XwedIFgBgmbNtn58jmnlKA7rTIrICKzL6+0EbbUkoLq1Eet4VBPuvBgBoaWoMqpurrBlWqVi9QRhWXy/ZVoGMBLr66tZZG2DfVxtEzorkSV0DC7FJ2chOjJTZMeSd5SILLl2phdOOH8i/35k0HjEhn8B0Tt9SmJ5ujnD0Dobre7ZSWc7r6Wjj5OFQHD2RARv3ALn4xQmltq6rUkVf2Qz7mWta1gVouQQgOoQh8xLN4Uwnl4fvfkzHzFUR+O3BE5z84iOFMKxEeXK4v9fojLUfxo5RQrCzOYKdzckg867Dp3GvqbnPz6mqKCPIh44D8af73E4SqBQKfBke+C7SD58Gx8h0FktMnsL9vYbVqnRYGdc2TrsgFaOBJSTs0Zixb3TG2gcFJRWw/zgEPkeysM7aADd+2I5lHzoMuWEFnrsDZNne59TPOXjJkoHvfkwHIHjQLPjXF3jJkiHke1Z0bBbMRUTQp4gI+hS5P4ZjnbUBUmsbsfnruH4/S3dahDoWW+q+0jlG+ig4sw/j3hwDG/cAUmRdWhAiPd4u1iKvERdDLbmKw0hCn26Bf58vElqGAMBLlgwEO5sjIujTQR+8jdOOx/90bszJL8VvFTdgaWYAVqNAnaeOxRbq46TxxquwMtCC9uS3MGXyWyK1BEbpiW3gIfLf1fVskZkfz3Jj5W5s5eEOAIAPHK3xTlIOfI5kwe19W1y6UkvO3tVUx8v02LJCiUoBw2Mpjly8jtTaRjDr70Bf9+0+P7N3uw9W+EfBzES6YkTELNbB1kJQcZVdBIaX86CDTk3sFvhu/xb2lnN6zXPW0x5Yo0V5IFOfK/FEIfJdieKA/HImLje3w2Tim5iiroJrdx9iHPV1LLKYCY231GBvbU7u43s1FTLnMciHjqX2L05HAFkgKl95nbWB3A2rPN0BSlQKdm32hG3gIRw79SvS8irwzqTx+MBRvD5LikpHJ1ei7fV0tOHr5YjdBxL7rFwcKIQaVlrWBVKfwMF2YJH9rnGU4eru69O4vr94IfiLJa/bfWneCgDPOyYSlVqe9MV4+eWX8a6lCSpr6rA9OQ9r6LbYsdlYaAZKiDJkZBchv5wJXy/H0ZzHQaCIwZwz6edhPltX5t1+CWwWzIWboRZZ6ZS1Y5VCuEUGSieXh5jjz8tEp2hOEutz7q6LkbY+DDl5JTL77elOi7DU3hJnc4uxJULgspBklVlcWgn/8ASxqsLGjxuDR60chUzNksnMlX/5hNDfhLH8NbcE25PzwLCahVUejuhc7ynUdbWi+gYKSiqxPTkPEZ52cHFcKFXhiFEUA8IdIE6hhzTZtv4jpG4UHFMR0s8Gyr2mZuw6mIzUf1xmkjwoqBSKzNwD3Y9DyEcWl1aKXcacmJKJrTGp8P/oXUxUU+n3OIpcAiszt0BdAwuse2yUVzNJg+ruZIPWVW7kCeXyeCgurSQNqqhtRhlZcHk8rPCPGpJCj/+UPA+2XK68PmwKZP59vggAcKP+Hi5V15NGFRAY1vclXF3K2j3QHUsLExSc2YdNwdECrQIR1WJcHg+he+LxqO0pfjnwBW7U3cGWiDjoadMQtMl7WNoDmRjXl+atwNIZNLxnawqbBSZCM9Q2Tjty8kpIoxvoZAF7K9NRg/qCEH04Ga52pnIPRDLr7yAwKQ/rrA1w5OJ1bNufjFwT+fuaB8L95sdkwQAABDubw2iGNhbbmA84IOfuuhiFwdEydQ90hUqhYM+XG2DtEUhKPbY8akNHRyfySqpxteE+Pvd+D+6ui0GlUDBvriHcXRfj6IkMOHoHK5wQtjjIxLhGeNphe3IeDHW1QNOYgLO5xWA3P8b/s3fWYVFlbQD/3ZlBKUFKJERAJMQALMJuRexuUde1u3Xtbtd27Y61uzGwRSxKFBRQDEJXGRW43x8js/IBgggCLr/nmefRYe65773nnvee8543Tl++Q8TrtzSrlVLp5vPfIKN5H7Kaxev2ATDIsznVK5Wm/bxdHDx+gXbN6/10Wb6X3zo3y/LEOmqqqkwc7kmxpsN4dqDET1NciSJ4fVlB2JYszsXr97kd+IxNc4ekeOEmeSEATJ63LtWUk4YGuhw4fumHcidkF9miXMcO8WRInw4EBIXwODQcAGvLYlkWIZJP3uX6obSrQmQXXt63WXnhIWM9KmFb0gIzUyNctirSMP7I7C+vY2psyInZfek/bhHbV0zM9onO4RMX6Nu2tlJhJvnEXtu/+Jvn7t+zLSMn/8nu/adSeA5kxC6bU2RbEIGaqioOZWyVRu16tVzzFWs+OULSrnrnlnUBhWvWuN6KmeDfR87nlFi5gnq1XKlUtiQLV2zL9nMt3XqcZo1qJPtOR1szQ0p99MAuLN16PNcGDKRGnorQyiefzLBn1UTEy38lc7J3r1sF8fJfuSqPbU4xpE8Hrt8NytZMV5ev+VCupGmyCZZbZUfO3/TPUEnvpBDePYe+L3F/TpKvXPPJ5z+OmqoqS6cPZvzCrdk2M/Ty9qF14+opvu/fsQH7j57PUBsN67gxbttZoqJjld/l5sxYgiiKYrIv3Hr+sNO54Nbzh47P5/tIrb/y+yBvkd+HvwZf92MK5ZpPPvnkk8+Pk28WyCeffPLJBvKVaz755JNPNpCvXPPJJ598soF85ZpPPvnkkw3kK9d88sknn2wgWfhrobr9ckqOfDLBu1MpQ0nz+zBvkVofQn4/5jVS68dkyvWfDx95e3LpTxMor3Dw+Hlu3PFn6ujfc1oUJVr1+qf6/a/ah3Ef5URFv8WkaBEAJsxaSfTb99wPDmfr4tHK7/MSafUh5M5+XLXpb+75hzBlZE90C+dnsEsirX5MkbilkEZ+lqr/p0n9qizddIS3b99iYpT7B/Gv2Iea6gXRL6yFRKKwZPXs0JjFa3YzZ2RXfhu1kO1/jskTffM95LZ+HNijDSvW76HL4FlsW/Lr3e+sJt/mmgE0NdTp0aoWB49fyGlR/rMIgqBUrAClbCyZMqoXNdwq0LdjA9oPmJFtpZ3zUVCggAp9PFsxcWB7rNuM5ozX1ZwWKVeTr1wzgCAINGlQnc0HvHJalHy+IJFIKFpED6lUSiuP2jSvU4npC9bntFi/PAVUVKjuWp7bGyaxYsth5i7dlP9SS4M8oVzj5PJkyRpyAgN9HfQLaxAUHJqjcuTzL4IgACCTyejRsQmRr2M4cOx8zgr1H0AqlVLSwpQ1c0fy+XM8DTqP4coN35wWK9eR65VrnFzO8ElL2bX/VI7KIQgCtVzK8uBLmfB8cheFNDUYM7Azc1bvzfEX8X8BiURCYe1CDO/XmdmjurNg9R7Gz1iZ6Xsf/vwlZ7yu/lKz4FytXMOfv6Tb4BncehhC88Y1c1ocbEuY8fbd+5wWI59UEAQBczNjWtV3zvEX8X8FQRAoUECFio6lWT13BOXsS2DWZAirNvz9XUry7oMA2g+YQeOxK2nQeQwHjp3/JZRsrlWuQcGhtB8wg799nnDjRQwlWoxg/IyVbNtzlLsPAnJEJnMzYx4G5psFcisSiYQOLeuz6YDXLzE48wpSqWIW29y9Jg93zuJNdCwNOo8h/PnLdI89cOw8zr1ncfnpa+Sf4rkU+op2Uzf8EqaGXKlcr9zwxaHrZKxMDejkbMOL40t5cmAB7ZvXIT4+gWmLt9Du94ls23P0py4B5R8/kZifoTFHufsggG17jqb59yL6utiaFyXwUf5L8GciCAIymYxiRgYM79eZiQPb037AjDT3KOLkcuYu3US7qRuI+/iZxC/DKlEE+WeFkq09eBHjZ6zMkJLOjeRK5Vp78CJub5zEgskDWDRlIPo62ujraGNnY0n7lg3ZuGQ800f1JCrmHWZNhjB36aafstH05GkEFR1+bknofJITHBJOwYIF0hxwgiDQoEZFZWHMfFInKjqW6q0VS/isVF5JpoLqruWZNKgDDl0npzkDrexUitpWqdfVSxQh7tNn5hz0zrNuX7lSucZ9+kxJC1O0tQqhrVUIQRCUfo4qKjLUVAtiUdyE37q24MmBBViYGTFu9l/0Hz2PKzd8s21J6B8Uipamera0nU/G2LrvLK9eR2PdZjTjZ6xM9TdWFqZcu/3wJ0uWt9AprMW2JWNQLahC+wEzlGMnq5BKpQqXrY2TGDFzXQovDtWCBXGr7Mju1VM4OX8A7nYmqbbzOSGRD/JPNB67Uun2FSeX03/0vFzvuZMtpbWzgq8dxtP6ewGJBH0dbZo1qkXj+tW5etOXgycuMWr2Bjo0dsO1QhnKlrbJEnnCn0cyccc5wjvlF7RbuWEPbZrWRVfn54ZABgWHEp+QQI9OzWnVrB69hs0mKDiUkiWKJ/udgb4u52/6/1TZ8hpnva4R+CSMkGcvqFjKAlVVFUbOWodawQJMGNCeqi5OP9R+VHQsPr5+PH/5hlKWRoxZuJ3A4KeM6N8FUMxwpVIpalIptdwqULWyI5eu3WHR2r858jDlqkP+KZ5xW07zIOgZj8JecS3sDfbWxVP0fW4i1ynX8OeRuJdK/S2WGgpbjxSZTEpVZydcKzrwOioG7+u+TF28hcjof+jQ2I1y9iVxKGOTqdrs4c8jadd/JhtGdkBf779Z4z6JlRv2MGjVIazMTfC5FwSAtVUxKjiUwsQo+0qnx8nljJ39F4N6tEBFRYZeYS08alXi2q17KQaYiZEhN57HZJssvwIFVQtgoFeYai4OADwMfEIZuxKcuXiLzmOX069FNXp0apqpF+iVG77UGbIYBwNNqjhaU7eqE/WqV2TtzuPEvF3B+KHdk41DqVSKVCqlplt5qlR2YO+Rs8xfe5DbL98ma/dzQiLnfIIJi/tEIrD54AX6eLb+ofuQneQ65fr+fRy25saZOjapk4wM9WnWqCaN61cjLCKSR8GhHDxxiTpDF9PNrRRu5UthYW6Cvm7hb775zpy/SlBIGEP/Osq6YW1p5VFH6bj+X2Tb7qMMWnWIT/EJrNxyhIGeill8yNPntOs/k44eVejarnGmXmDp8eeanZS1KU61LzMqQRBwKGPNzgMpSy1LJAIN7UwIfx6ZrQo/LxAnlxMX9zGFknSpWA5RVNwrABsrC+4+CCDug1wxS9x6mn1nbzLqt+Y0bfh9bpCJiYnYaquyccEIzEyKKlehtatVZPPOo9TvNIbtf45O0TdJ47dNk7rUcC3P2Jmr2ejtp5BPW42A2DiexX0iaUv5WkR0qiuX3EKuU66v3kSjo635Q218PZu1LG6KuZkxtapVZvywBJ6EhBHwKAQvbx+ehr9k4xWFW1c3NzsKa2kAcPF2ILci35KQkMD8Hg0J2D0LIwM9ZDLpD19fXuXKDV+Wbj3O7omeRL6KonMbd1S+3A+XSg40blCNbXuOU7/TGCb2b0vtGs5Zct44uZyla3bxKCSCeZMGIJX+2wdmpkYsPHqd2X+kPM7W3Jj37+OyRIa8TFh4JOPmrGXXqinJvpdKpURFxxLwKIRLV32ZtMuLLi42uDjZMdCzBQunFiMiIpLl6/exbf85po3skWEl5lyhLJ08qtB9+HzWzRmiPK6wViH6dG9FaTtL2vWfybLJfVI128lkignSqjkjKLNuN/tPXefyszcAfO2rkyjCff/gfOWaUR6HhGNjZZZl7UkkAhKkIJVSABVK2VhiW9KCRDERMVFkbmIicfKPvHjxiqRJaff2jTEqasDcpZspU8oK06IG/+kZ65UbvoyYuY5NC0dgbmaMKIqoyP59dKSAjrYWvbu2pJqLI8s37GPv8UsM7tX6hx788OeRzFi0CZOiesyZ2J9CmhrJ/q6nW5gyepqpzlDTs9n/VyhhUYxPnz5z5YYvLhXLESeXc+deAIdPebPo6A0mtK6Ga8XS+LdqQBHdwkikEiQSCRJBQFe7EIunD8H7hi+eIxdSrbwNFcvZIEiEb85mpVIp/Xu0oZy9FeW6TmL7uC40bVgTQRBQUZFR3bU8k4G+fyzn1LbZqa50BEGgYMECFFSR4R32hrQcIP2Dcu+mVq5Trpdu3GfIb22yrX2JRIJi3ClmQAUBddWC6GoX+upXAhKJQGUHO+4/DKaaS/lskye3k6RYN8wfjmVxU+Uy8v9JGjil7axYPG0IZ7yuKQdkt7aNvkvJRkXHsuvAKbYeusSY3i2pU9MZFZksxQtOEAQ6eVThof/j//zyPy0kEgmDerRg71EvnoSEs3LnKdwcrGhQszJD+nRAS1MdqUShUFO7vwULFqCaixMHSltzxus67aZvAiA4HRt7khK9s2kyC5Zv57qPP327t8DEyFDpSVDvmi8nz16haaOUijop7P0vr3tKH9jUiI79J3M35ieQq17vUdGxrLv4AGsr85963iQ3r38/iofMorgxvg8f/1RZchPhzyMZMXMd88f1/KZi/RqJRELBggWoV9uVA2sn42BvxdjZf9G29x+cOX/1m0EfQcGhrNywh2IeQ4iPT2DnsnHUq+1KARWVNFcO1ZzLsWrrkUxf43+Bio72LDp2k7Dnr9ixdCyTR/5GFWdH9AprUUBFBalU+s2VmVQqRUdbi+butQj6ew6/13Fg+sL0s2FJpVKszIuxePoQHOytKNl6DAeOnSP8eSSfPn8mPj6B6z6pu8ypFizIhCHdOP/nMLaO6URXV7tUf3fhds5Ea2aEXDVzvXDlNrO6Ncg1SzprK3PWXXrAqpwWJIeYvnAT/Ts3ooKjfYYU69fIvhqQHg2qc/dBADd8/Jj05w4EQaCqkzWFCymW+THv3nPxdiCGupq0bVwd/92zKKqvi0z27UEP4FDWjmeRKTc2gkKfo6aWu5JN5wQK31WRcS2r4lyhNEaG+pkycSXtY5gWNWDO+H6s2LCH4RP/ZN7kAd/cwJRIFLPf5u61cK5UjoNHz7F131mO+IXjbmdC03ouaZ7PsIgeBga6VHSwp6V7LaZGxeDj68fq7UeV7lq52Ssk1yjXOLmcuWv2sWbWoJwWRYlEIqG+rfF/ctf5wLFzaKgXpJVHHaSZfNl9vbFY3sEexzJ2eHZsSvjzl3z8+JE3UYqBoadbmH6erdDV0UYmlSKVplyipoVUImGIZxPWbz/CjPF9ld8fuv+Mv/9jfZYaJkZF6DBwFo2qluN1VEymFOuVG74KG+2xmzQuZULTOs507+DB+m2HqN9pDGtnD07X7JOkmH/r0pIenZrzNPwFnQfPxqnsvxGPUdGxymfC1MQQNVVVpIIAkn+PNyqiR72aLt/0ic0t5BrluvfQGZzLlMC2pEVOi5KM/+qu8+zV+/hr5sAs85CQSiRIv0TYWRY3BUSS0jQIAsoovMzQuF4VFm04hO/9AMqVtiEoOJTOLrbfPdv+FTE1LsrGBSOwazeWhT3dv+vYOLmcafPXExASzui+7RnatwOxMe/Yue8k7l3Hs3rGAJzLl6b7iAVUL29Lt3bftq0LgsC7f96zdc8xRm44wZQONbl15yFbdp9g4bEblDfUooqjNY9Cn2NtbsT0cX1THC+TSpFJpdR0q0DVyg74PwrJzG35KeQK5Xrlxh2WbT3OvtWTco1JIInSNuY8CHj80+3AOUn480j0tdWxtbbMlvYVSi/rFJ+GujqL/+hNp+GLuL5/Iddu3cPRPntkz2tIJAIWZibs/KM7M1bsoZl7jQyvwoZN/BPbEsUYMaATWpoaCIKAjpYWw/t3wbmiD06e0zi9YCCH1k/ltNc1uo9YQLmSptSt5kRFp9Lo6mjz6PEzQp9GEPb8FScv+XDl0QvefPxMK0dLVAsUQE1NlY4t69LHsxX6utpIJAJvomMx8xiaQrl+jVQqQSotQBk7q6y6VVlOjivXoOBQag5ahNefwyhioJvT4qSgUCENxP9YJqxzF29S26VcrnvRpYUgCFR0tCc+Pp5RU5cT/uINYwd0zGmxcg0SiUCT+tWIiopl2sKNLJgyMIWdNE4uZ++hs8qUmqqqBdBQK0gfz1bIvtrwEgSQSGRUcynP2cVDqTlwPrsmdCPug5zKpS1ZfOImR68HEJcg8jZRpEOlkvg9eYFIIjqaalzYMAkToyJfPBS+5Az5smqJePGS5ev2svDYdfSkAlHRselGiOXmZzRHJTt9/iplu0ziyOy+VHS0z5W+pIYGuly/7ZfTYvw04uRylm87TvsW9XNalO9CIpFQr7Id1ubGhL2MwbFsfvayr5FKpXRt1xhNdVU2bD+c4u/T5q/jadgLOrasS5VKZdhw+Ard2zVK1QVO0Z4EUyMDzNVV2HPkAhoaarRvXoeQ/Qt4eGwZFzdO4vXpFSybNZwzO+Zydsd8ZFIJr169QV21IAULqKAikyGTSpFIJES8eEnbfjNwKGPF+T+HU7GkETqFtX7Grck2cmTmeuXGHQ6fvELAk3DubpmCpZlJrn0DGejp/KdyuO49dIY2DVww0NfJaVG+G0f7Evg8COa3tnVz7fOUk8hkMsYP86RB5zG4VixDuS/RUeHPIzlz/SEnt8xCU0MdTU0N7M300zULDZ28jHkjOlO3pgtSqUQ5AxUEgRKpuO51bFaL4CdhuFZySPZ9nFxO234zmDq0ExUdS9F98EyG9WqZKydb38NPewJ97wewcv0eqrYczMZdJ6hXsyJbl/1BieKmSKW5dyAIgpCrHZWzEt/7ASzbepwOLRvkyQe7UCENvH0fUad6pZwWJdeipanBogm/0e+P5Uo/1XMXb9KrdR0KaWogkUiQyz9ibW70zRdUUHAonz/H07COGwULqChnoEnPTWqbiWVLWXE/ICTF93sPnaFWpVIUUJExYdZqDPULU/UXCNzJ9plrUHAo4+asRUxMpEfbBuxcNg493cJKl5vcjomxIesvP2RNTguSzURFx9Lvj+UsnPBbnpy1AtjbWHIr8i3FTIxyWpQsZdz0FdR0c6ROFuRrSLJP13Mtw95DZ+jY2p17/k9o27RWshdqejN/URSxMiuaLNdDehjo6+J1699UkEHBoTwODWfC8n2ExX0i4uUb6lWtQP06LnlCN6RHtirXKzfuMGLmesb83pI61Z2RyaTIL/ZJAAAgAElEQVSphtnlZtTVVEn4VvzdL0CcXM74mavp3qJmrrV9ZwQNDXWstdV+OResnp2b0GnQbDQ0VHGp6JD+AekgkUjo3bU5Zk2G0rBOFURRRENdLVPtfA+6OtrciIihSsvB3I58SzE1GVVKF2dk1wb4+j3Bs11DHMvY/RKKFVJRrupVPJnUtjrNG9X4oaQbUdGxDJ+xjpXTB1DKxvK73nC5ibyqaDJKnFyucLmxMqVru8Z52lZpYmRIYOyv55Nc3NSYTQtH0mXIHOaN9cwSBfsi8hWf4hMYMH4R8fHxKaoaB4U+T7eN7zWXCYLAqKYu6BQuxFxnRwz0ClPMpChSicDmXUcIi3hJRcfS39VmbibFSAo7sgjn8qXpNmIBY6cvz3TJlJ37TtKjZS3sbUvkWcWaRDdXu1xfUiIzXLl+hy4Dp2NbwpS+nq2RyXLcM++HkEgEuv6CfSWRCFgWN2HasM4Mn7GOsIjIH26zTClr3pxezm8d3FErWICq/ecxZ8lGfO8HYGVpxsH7z5QlVYKCQwkKDk2mC0xMFOay72XyqN4M+b0DlZ3sKWFuqrDXymRYWRTL1RmuMkOK0fThfRxuzo4cWW/Npl1HqNtxFBvnD+few0fUr+WSoUTIcXI5g1YfIvzwomyfCQUFh/IhTs6TpxEAXPdJ222qmHERHOytcChr+10JnfV1Cv1yvq4r1u/hzOU79O/elCqVHfO8Yk1CX6cQ7z/8erNXQRCo5lqeaUC7/jPYsXQspsaZD++VSCToaBWiiosTLhXLsSAujus37jJ18WYkgkArJwsWrdzOlN0XGNywAgDtmtVRehhIBIGqZgZcunobQwM91NRUMySPikrqz1kRfR2ePHuR6evJjaS40iET/0QQBAb3bEnf7q0oY1eCLkPnUdWxJCfP32B+Kg7I/8/lqz6Ma1kVfb3s3RjZuvsI+05eoaSZERUdFX6NLdyro56GfE/DnnPgxGVGzF7Pjj8z/nAKgsCHuOwpepgT7D96Dp/7j1i7YBSamhqZzh2Q04RFRBL3pV/0dAujq6NNZSc7njwNx6HMr+fnKpVIqOZanqkoFOzBtVN+qI6ZIAhIBQFpAQk6KjLq1nShZrXKXLlxh2l/bmf53oucmDcAMxNDbt55yI59p1m16SDrvR+CCPVKFmXPYS/UVAvwKPQ5h/3CmdymBh1aNfhuxV+yRHHWXXrI6kxfTe4jhXLdsmwiV27cYcHqPfzeSU7NapVYqK6Gproa63cc4e+DZ+jU5tsxyqcv3qJRbZdstVdGRcdiZmpEm8bVuHkngGtfHP1v+PiDAKVKFqdoEV2KFzPGylKRfNumpDm1qzuz98hZtu45xqiB3TJ0rkqOtr/MgI2Ty5mzei9rZg1Cq5BmtvTR10oPyPCsJiOMnb6chcduANDYzgSr4grPgIu3A7n18i2tHCww1NOmuXvtLDlfbiNJwbZ6EMS4matSjbbKDEkFA6VSKVVdynOkogOnzl1hzJwNFC+qQ4PqFWhYuzJ6uoWZP0WRXEkRYQUCAomiyOuoGK5cv4NV61GcWzgYl0oZtw1LJBIa2hrn6rIt30sK5VqwgApVXcrjWMaW2Lf/IJVIqOBQCoDh/TrSrNckGtWtkuYbM04uZ/7ha0wY5pnlwoZFROJ1+SYHTl0l4vVbqjhaU8nRljZNa6WYrfoFPSHwcRh7j15iwxU/hjSsSC03J2ytLdh1yIsazmWSyfx1naE5SzYS85WBv5ixASZFDbL8enKCwEeh2JkbYWdt+cOKVREyeYYHgaHExL5XzGhIrvTgX8XX3bUUvbs0US4tM8rX2ZKcypTkSLUK6OvpUERfBz0dRcHIhMREPsjl3LsfyNyVu9h/9BzNUknC/CsglUjo36MNy9ftZtgfSzK0mvze9qUFJDSs40Z5h1JMmLWa0nYlKFfGFoG0vQSMDfVp7l6Lle/jGDh1DUsm9PouBetUypJnES9+XeUKipurVUgTrUKKWlZJN7OIvi6Du3mwc9/JNKsuBj4KpZOzLepq3+/a8S1WrN/DWe87eNSuzMQhXSlhaZYsPvn/sSlpjiiKJIoi0z/Ecf9BIPf8HjNpyXZsixvSrb2H8rcnzl4BRJo1qgWAc4XS6OsqBu3rqGi2/H2axITELL2enOJxaBgNalbMMlt4dOw/WFuYEPb8NeuGtQOgrG0JNDTUlAlCvlZ8fScsY8O8YRkeQPuPnmPeX/up6mQNQGKi+CUKSKG0k3LDVnK0o4JDKaq4OBEcEoZfYAjNGmXJJeZKZDIZfT1bM2vxRqbOX8eMbyQ5ySxSqZSiRfRYPmeEMkjgW9x9EMj0JVvQ0dJAS60gXcYsI+hMxjzEg4JDuXonCEEiUKtq5awQP8dJcxcjSWGNnb6cCcM8UVNVRRAEalWpiEnjQXTr4JHq2/LugyCqVS6d5cvNXp2b4dmxqVKhSiQSwiIieRb2nMjX0ew/4c3jsNdExLwn/ONnhjSsSNumtSlX2gYdLRluzk64VnKgR6dmfPz0CU0NdWXbiYkKxRknl9N14HSc7C2p6uygqJCJBe/fxxEcGpGl15NTXL3lh0c910wfHyeXc+euPxev+nLQ6zYJ8YlUK2+DqZE+BVVk/PPPB7b8fUJpgxvSsKJS8VVwLIW+tjovX0elq1z3Hz1HBYdSeNSvRoPabqnahRMSE4mOeUv480iu3rzP1n1nCAiLwj/mPb4bUqla+Ishk8kY1LstQ//4kxXr99Cne6ssP4cgCBRQUfnmb4KCQ1m/4wiBIRH079YU10oOfIiT07jbuHSX+b73Azhx9ip/7DjH1Pa1eBWVdqWKvEa6W8QaagXZsP0QfborZqr6eoXpWNmGwEehqS7v7geE0LZprawXVCbjRUQk/oFPuH03gENePoiiSBVHaxzsS3DL/ykDOtTjybMX6BQuhKWZETv2naZcaRul4R6JBJlMYfr4WvkHPHpKVedyqBYsyJJpgwh8FMrmPScZPWcj1cpbc+rqQ1ZMzfqZQU4giiIGmdxo3H/0HO2nb2Jim2o42JekZZPaygxHSTlZRRHliuF9XByPnzzjof9jhkz8k8MPw+lYqSQOZdI3C4RFvETji602LVc+FaBoET0MDXRxKG1Dry4tGDB2PtPrumKTy/ICZxeaGhrMmzyAEZOWZpuCTYs4uZwN2w+z5dBFhnRrzKgBnZUbpCoyGTZmRVN42YR9NYYn7jpPVxdbmtV3I+JYc96+/Yd2/Wb8NPmzm3SVa6/OzTH1GEy39h7K2WujWpW4+yAoVeW64Mg1RvTvlKVC+t4PoP/EFRTV1aSGc1mcK5Smc1t3dAprIZVICH7ylHqVS+HZsRmBwSFs2HGUds3qUiSNMM7/n1U/efaCR6HPOXjiMk/CXqGmqoKhnjY9W9Vm1rpDzB7aAcc8tJmVZAvt2Dr1jcfMrircKjkQfrQ8hTTUkXypO/b/bUVFxxL+/CWXrvlSSFMNDXVVLIqb8Nf8Ubx6E4uBfuEMmYyMDPV49/5Diuu6c9efx0/DOXXRBwD3mpXQKayFUzk7dHW0WXfxAQsmD8zTwRDfgyAIaGlqMHVUL5r1moSDvdV32Tl/hBNnrxDy9DlH1k+jkKZ6sufh6g1fbgc+IzrmLfuPnuO6jx8Lj92gsZ2Jcgw/atMIA73CygKJOlqFuP48hji5PEttyDlFuk+ggb4O41pVxefuvzHBZexKpJqAISo6lnIGhdD7AfeQ1LCyNGPjghFsXT6REsVNuOcXzP2HQbx+E42KigyJRMLbfz4gk0n59OkzAM/CX2BR3DRD7Vd3KUc5OwuiY98R+DSSrdcCKaytQa/Fu+ndqgbu9arlucH69/HLeF+/k6Vt6usVRkerECoyWbKidmERkWzZdYTWvSZg7D4I976z2H3sMp7zd/Ik9DmXrvni3m08qgVVlEmX0+Pr38TJ5ew/eo66HUaxdvsxpq46gLGhLgVkUtbuOkVAcCgXvG8BkJCYuVDO3Mi3ijl+jSAIFDHQZeuS0QybsS7L+z0tbK2K43UrgIIFkxc53LLrCF3GLEMURfYdu0BiYiIt3asT/Pdcti6fSO+uLani7IixoX6yAomCIDC4YUWehf0a/q4pZq5hEZEMmbiUQw/DqGCoxY6lY6nsYIeXt48yVZiBvi5eN/1TNPb6TTQ1yttkub1VXU0VCzNjBEGggqPCcyHw8VMmLdmOsb42NV3KcPHuE+Yv28zN+48w0NFixMz17Fo+LkPtqxYsgHYhDdZf8uPOxomc8rrOGW9fhnu40L9H2zwX66xasCCDPFswf/XuFOndfoSv+zUqOpbbvg9ZtfUoEa9jae/uxqi+7XC95ouWpjqd27gT8CiEP+atZ/fqKZQtZcWW3ccYPahbhs5lbmbMzv1nqOFWgXEzV6Glqc6eFROIio5FXLmDySN/AxHcWgyicb1qmBoXSVXOvIyx+yAW9nLHo361dF3ZBEHAwsyYLYtH0WnQbOaN9czSvk8NaysL7C2NuXTFh7o1XQgKDmXBqp1oaapzYdtMdHUUlQW+TkWYXt9YFDMk9GnEL1H5I4VynbZwI20aV2Xz0hrExLzFsIge799/YNW2o8rf6Opocz2VqosPAh5T2ibrbV1fd4iebmHq1nShjijSs3MLIp6/JCAohPb1K3Lyki/qqgVwKm3Fb52bYmJU5But/ou9jSULVu0iQRSJj48nLk6OloYqYwZ1ybIaUj8TQRCo6uLEwr/+xvv6nSwfZCvW72bLoUt0cHdlVN92lLG3Vm407jp4loa1nClQQAV7WysO3n+KTCajTCkrHodmvJicgZ4OXjf96fEmmvbNauFSyQGZVMrbd/+gW1gxewYoU8KEt+/ece5iCHVqpF5JNK/yeN88Tp31pm2/6ZQtaUrLRlVxKlcqTTfIn61gJRKBBjUrctPXn0chYWw5eJHxfdtQp6ZzsuoF34NxUX0CnzyjbjbI+7NJoVx9AkJZNmsYUqkUwyJ6CIJAMdOiHLz/VPkbQRBILRj03bv3FCqknspfsg6Fs7Oi02RIMTczxszUiDo1KpOYKILAlw2WjGffMitmxLqLD3AqokWHYQsJio3j9MKByTwK8hJhEZGYGhsypGfLFLPXUiWL/3BNsF6dW1C/lis+d/0opKlOwQL/7iYXMzbALygEW2tLgp88pZGdKVHRsdzy9VNuimYEU2NDEkURPd3C3PcP5q/N+yhnXxIz06JcvB1IWEQkb6JiuOn/lGXr91HG1vyXU65GRfTo1Maddi0bcu9BINdu32fikh2UtTKhZaOquDk7prBN/r+C7duhfrpBPz9CEQMdfpu1hQ7V7fl75R8Y6Ov+0ErP3sZSGRCU10mhXKs6Wit3Z5OUk5qqKqcWJC953c3NDlW37gB0d7NDR0uTczf8WPaTd9X/VbaZ71A1VVUGNayAhnpBEuMTefTsBR/ln7LEyV7hQ0uG8zJkBcvW7WHm+H6pzl4LFVL/4TwJMpkU7UIavH8fx7jZa3kR9Q6PGk7YWJlhZVGMcQu2cNLrBl53HmNlpIOx+yDmeTb8rlWAIAh4VHfktq8f1VycuOnzEC9vHybv8uLT53jcOo7jhfwzlYy0qV3FiebuWe+hktN8HTXlVM4OhzK29OzcgnsPAjnldZ3G41YxuW1NGtRyTra5nKRg9676g4WrdtC61wSG9GqJgZ6OsmT1jxIWEcnydX9z/qY/9csVp1+3lsrJ2I9gVsyIBUevM2fiD4uY46RQrv+/cZOUYaiGa/LM4KvnjmJFYiJx8o88f/4SBGjeqBo2edBWIggCTetX4fApb6aP60OfEXN+OGG07/0Api3ejGWxokS8fEOPmZu4sXkKlubFskjqtDl33U/pX/hbh0bJ7OVZZY/U1dGmY+tGtGvZgKioWIIeh/LqTQxe3j5UdSzJhzg5v7euQblSJdlY2oZCmVgF1HBz5NK1u9Sp4awwBdWozJA+HYmTf1TOztXVVJFJJXk+81p6SCQSJBLFak2haG3o2t4D72t3mLpoE4IgoXfHRsrZrCAIGBbRY9rY3/G+dgcvbx/evvvAwuM3AIEKhlpUc1Io5GImBhgZ6gOgqa5K8WLGqcoQ8iyC9x/knDh/g/WXHrJldEdGDuzMvsNnCQgOpZRtiR++TjVVVRwMCmWoOGFuJ4VyDfrKWd73fgCVfpvJwp4p65GrqMhQQeEzqv0lkgvEPLuZUN7BjpGz1vMs7Dn3gsO/O0Tza7bsOsL+k96M7tcBdXVVug9fQJGCMrS1CmWhxGkz1LMJp7yuUbJEcSo5labp+DW8+0eRKcr/STgVy/z4IPh6VmVYRI8iBrqIoohHg+ok2YwEQVBG0GXmuXAqZ0etwYvp3bXFl4H2r5+ydiFNpW/tr8rNOw+VoedfI/niumRURI/m7jVp0rA6d+8HsufQOSYt2cHwns2o5uKEro42KjIZVV2ccKvsgAhMHNkLgJiYt0TFKLwRnj57wYcv6QQDgp9y5uLtFOcMfxnF+XshLBregTj5J7aO7UyzhjWQSCQYG+oT9CQsS65ZEARqlLfhadjzX0+5hr96q3xrXLrmy8aR7WnVuE6aDSSFIn75XzaJmf2oq6nR3t2NFRv30biaY6Zdr6KiY/FcsJNnBxcq3Nimr6BxDUdu3Hv00x6WWlUr0thzAn0926CnWxi/nTP49PEjoHDwl8s/Zen5vlaeWTl/VFdTY073BlzwvkWzr5b9yZ+5X5cWg+ezY86ANDel/t9sUK6MDc/CIzl66pLS06Bts3pfdu0Vz3NSxj/FC1EPABsrC5LeiKII4v/tqNy9H0Cl32YRuGsmnz99YtPfp2nWsKbStmpuZszfRy9m2XWbFNXnpq9fnk+UlEKDdGxchR37TgIQGhZJAZksT+6Yfy+CINChZX0WHr2BmUnGvAxS44L3LWZ3a0ARA12Cnzzj3A0/btwLZlivVj9tlqWnWxhDHcVqQlGJ0wTbkpbYlrTEzrpEnik7LQgCDWo5M3vNvpwWJUcw09Wg5qCFGfJblXyJirIwM+b3bq14vG8eCQmJGLsPYsX63SmS3ietKiQSAekXs4pUKkUmk6Iikyk/kS/fMGDyKk4tGIhlcRM27jzGkJ4tk21aFTMtyrqLD7LkmqOiY/G6dp+bvoFZ0l5OkkK5dmjZgE0HvPC+fodabo7MXbM/09UI8hr6ejqMb1UN/+Cn6f/4K4IehTB53hoWr9zG23/e8zzyDYIgsHbbYdxrOCAgUtXFKZukTokgCOxZMy3Z/5MGUlJehryCTUkL3MpZ/TTH+NzEqhkDKalVkMFT1zB7yYYMBRUIgoBMJsWoiB59urfiyRclW6f9SPYfPftdYzksIpI2/aYzc3gXariW5+6DQPwfh6V4ltVUVWloZ/JDFRIUgSJn8fCcgLODNQm/QKKkFKNMX68ws0d2Y9iMtVy/40/pEsYEPgrJAdF+PoIg0K97S+Yeupbh6JhT567QdfgCXr2O5cCZG8xcc4h7QU8JehSimLXeDWbob61+qkIbM20ZN3zu/7TzZScSQaBHh8bMX7U7p0X56djZlGBol0bYmRuhrqaKkfsgZi/ZgPf1OwQ9CvnmM5pkMij6RcluWTSKKzcfUqf9SLbsOpLu8x0VHUubftMZ36c1VV2ckEgkTFm0icG9WqZ4lgVBwNxYn9dvor/r+uLkcryv32H2kg0UrvU7V24+ZPXMgQzv34V1l76/hExuI4XNNckBfd9qC4KCQ1BXU6VMKeuckC1H0NfTYdWAluzYd4K+nm2++duwiEjcx6wgYOdMTE0MEUWYPHcNd/1DWLXlIG5lS/DgcThVnX/erBXA2FAP5wplf+o5sxMba0ssihmy/+hZZVrI/wISQaBrOw+8bz5EEARC9s3D954/Xt4+xL77wMXbAdyMfEsFQ22qlbemmHERjIvqYW9tiZ6eDro62kola25mzPSxfXgdFcOeg6fx8JxAWStT6tesgL21JSW/8vIJehTC/FU7advAhQZ13JBIJOw/ehadQhppPsuFtTUZPWsts8f0THMzOMk3+d7DR1y+8YB1lx/SzdWW5g2qELKvMQZ6OkikEiSCQCM7E4IehSSTK6+RauIWiUSCoYGuMvFJXlpG/iiCINC2eT3qdBhJ3WqV0uzcOLmcwX/8yd4pvTD/EpoLMHnkb8xduokJ285ip6tBfHwC2/Ycy1ZH7v/HuKj+L9VnEkGgR3t3PEcuon4t12/6aTYuZap00/oVkEqlLJw6kLodRyORCPzerZUyWCJRTEQUITrmLdHRMYSGveDlqyjWbj+iVLxDG1XE3tocS3MTzEyNMDEqQp/urfitq8Jf9srN+2zee4bDD/+NnitfRIuhnh40d6+FRCJRzC5X7WP7n2PSfK7qVa/IXf9Qlm/YzwZvP6XCj4l9z7ovhQy7u9lhblKEkiWK0bOjOzMn9EFDXe1L0E9yj5LKZa14+Sb611OuQKbdZ34FNNTVGOrZhLXbjzBrQr9UfzNl3lqqVbKnUR23ZPdJJpMyon8XurX3QE9Hm7DnL+kwcCaammo/bdYV+J0247yAjbUlbg5WHD/j/c2AARsLYz78YgUKNTU02L9mMgtWbKNN7z8Y2qsVjl8V2TQ00KWIgS42JS0QRRFRVCjeN1GxxMTE8jDwCV7ePty6v4dDD8OUCteiuDEe9avRu2tLEr8KLBEEkEqkSKUSTp27gvvYlVxePpLixYzSEhFzMxMEAZbOGsaSRBH5x49ERESip6vDIm2FC6JEIiAgKL09vqVjbEuaE/kqKgvv4s8npZ9rHp+KZwWCINCycR227z+Xamz+/qNneR31lnFDuqX6JpfJFLaupEiZ7UvG0GHgrBTLr+ziwNnbFDM2/Kmz5exGIgiM7N8ZE4/BRLqWT9OtTfILTggEQcDQQJcZ4/py+boPXt4+1By8CE+3UpgXK4KNlaJGnL21ZbLjRBQzX3ubEpSytsTKwpSm9T4RE/uOewGP+fvYZQLC3xD8z0cqGhambUNnipkWwd7akpBnzzl7+TYBTyLw2zEDi2JG35xsmRobcujBM2XOhwIqMgpZWyKQOV/kEuYm7Nh/hhaN824ttBTKtevwBZzZMSfVpVerXuOT7ULndrbsOkKPRbu5v2nSdys1qVTC4F4tk0U3geLlk7RE0lBPO+oo6YESBAFzM2OGeHrw95FzjB7UPVPX8j3EJyZS1r5ktp8ns8TJ5azfdogmDdLP9vQ1Bvo6zOneAC/vW79kuOu3SPICqOrshFslR4b27UTwk6c8ffacD/KP/PPPB9ZuP/LNNkqVNENDQw11tYIYGepRoawtpawtiPv4iZcv3xD38SNhEa+4essP7ULqNKztzJQK5ZDJ0k/CIggCXV3tlJMzQRB+yOtdX0+H86lk3stLpFCuDauWZcmqHYz6v9RwQY9CiI9P+Fly/TC+9wPovmAnc7o3oEQmC55VcChF7SGLGTNYoRCjomOp1HUSa0Z1pHg6b/KvEQSBkhbFuHknIFNyfC/e+xYjk6abBz3HmDJvLYU01NDV0fqu4wRBoEWjmrTrP+M/p1yT+DoM1tbaEtuSFihW9CLppYxQPK7Jn1lBIpB04P+3871ueyXMivLkaUSWrM5MjQ258X+Js4MehbD36Hli3r7H3tqcMqWsfiiSMrtJcecG/96eR6HPadVrvNLlw/d+APNX7qRjs7zzQG/fd4r4hEQa1nTO9FJRXU2NhMR/n9ixM1biWduBbQfOIf8S8ZRRTpy9SjHjn1NBtoCKChJJ7l0ezz10lZEDuioHTZxcTtCjkAz5YJqZFqWIjkaaPpULjl7H1OTX2MxKj6RqEElBADLZtz+KQAFJsk9SG6m1872bopbFjXnx8k2WXFtS4uykJP2+9wPoOnwBJcxN6dK6AWpqBZmyaBOteo0nKJe6iqa4e5rq6qyYM5KB3Zvh5e3D2u2H2b73FHWqOdHSI2/YP+LkcuYeukZ3Nzu6j1yYwqcvKjpWUZN96jJmLd7AqXNXUh3Y0TFvKW+omF1t2XWYhIREZk8cQI3KZRgyYXGG5Tl17gor9l4kPiEhw/6zWUlOnPNbNLI14cXL1wiCoEjOPmExa7cfRrtmb34fMRvv63fSVLSCIGBtnvqmVVhEJA4GhX6JEiF5hajoWJav241r84HcvBvAg1QqlGSWji3rMmz6WsIiIpmycBMzR3ahReNa2Fpb0ty9FjtWTqZHmwbYd5qYO4NMxK/AtYfy3wkJCWJ8fLz4+csnISFBzCsEBD0Ruw+aJn7+HC8+8HskJiYmipt3HhJVnLuIKs5dRJemA8Q/1+wQb955IB47dUmUVe4szly0PlkbH+LixN7DZom79p8UL1/zESs36SdGvnojiqIovvvnvdhzyAxx5qL14oe4uG/K8iz8hSir3Fl8GBAsbth2QFRx7iLuPXwm3ePS4+u++tb3AUFPxFFTlv7QubIar8s3xNdvokVRFEWfu35izyEzxM/x8eLHT59Fr8s3xRkL14kqzl3E3sNnpTj2WfgLUVKxk/L4rzlx5rI4dd6abJc/q0irD9P7W07zLPyFGBD0RLx8zUc5ll68fC2+fPVGrOTRN8vOk5CQKJ6/fEOs2LifaF+3V6o6KCEhQTx36Ybo3KS/+CYqJsvO/T2kORYz8qO8xt5Dp8XFq7eLoiiKiYmJoiiKYnx8gvjx02fx46fP4qdPn8X4+HgxISFRDHwUIq7a+Lf48lWUGBD0RLxzz0/cvPOQ6NJsgLh49XYx9FmE6Nykv1JJJ7X59t0/Ys8hM8Tew2elqSg/xMWJLXqMFQ+fuCAmJiaK8fEJ4vPI1+LIyUvEFj3Ginfu+WX6GjOqXH3u+okjJi3J9Hmyg4SEBOW9TEhIFB/6P0r2t/j4eDE4JEw8e+m6GBD0RPnZvPOQ6NK0v7h2yz7l8V8zcvKf4gXvmz/tOn6UvKZcP8TFiaOnLBVdmvYX+46aK5au31t84PdIjI+PFxMTE8XExERRqJX3cy4AACAASURBVNAxS5Xc07Dn4op1u0TTKt3Ezv2niG+iU7adkJAgrtuyX1z2184sO+/3kFZf/Tqe5l8hosisA//u2kulEgqoyCigIkNFRVFgLyb2LWu3HeKmbwAmHoNZt/0w2/eeRk1Nla2LR+PZoQnTF21iqGcT7Gwsk3kAaGoozCelrItTu/3IVEOEF6/agaOdJQ2/+MJKpYrgjOnj+jK2fwd+H68wS2R17oYkWcIiIlmxcT8e9VyztP0f5esqoRKJgO1XLkQK25+UXftPcvzMNdZtP6z8xLx9z1+zBtO1XZNUq87OO3wNp3IpU/TlkzVMmbsW46J6HN88E+MiOkzo0wI7G0ukUinyjx+5csMXj1LFCH+e+RwDSXhfv0OrnuNp2286UTHvmDmwFQVkUo6cTJl9SyKR0KZ5XQauPpSrTGC5d0v5B8nITr5OYS2mje0DIqxx6ar4NygLqq1YvxstTTVaetRO0V6Sa0w/z9aUs7ei6/D59OtQn5ZN6igqN5y7wjXfADb/OT7ZxoAgCMikUhzLluLE5pls3HGY2u1HsmJqX8qVzppsVfNX7mT95Yd42JvSvkkN3Co7Zkm72UVqinJE/y4pSgkJJFfMX3PrzkMmtqmOulq+vTU78L3vj9/jMMYN7Y6GuhoHz/twpGsLBEHA974/fSYsp0wJY6zNixL0+FmmQ+bj5HKmzF1LQEgE4wZ0oKy9DRKJQHTMW55HvmHx5qN0btM4xXHqamr80bo6foGPc83z/ksq13/++YCmZvqZ7+UfPxIX91HpkP7582flZsiUOas5dvkuJ7fN/uauqVSq8D3cv8aCtVsOULv9SHq0rMnvS/cRtGtWmr6wEolAIU0N+nq2pnbVivQYvYiV0/pliYJdNms4f4ril0gbSZ4LhZ2zdAv9e7TCL+AxdWtmrC7W7sNe/N4l5Yw2nx8nTi5nysLNTBjUCQ11Ne4+CKCoriZ6uoXxve/P7+OX8efE33EoY8vp81d4FJLxQpT/f54hExZjb12csUO68enTZ85fusHfRy9wNygcs6KFIY1kWQp3RxMOHr+Ua5Rr3hp1GSAsIpLl20+kmsH9/zl+xpsde08AMLRRRXzu+inbmLznIi9iPzBi0lLGTF3Gll2H01xySCQSiujrMmpgV5ZN7sPs9Uf5o1X1dH1hk5Jq2NlYMmtkV46evpKJK06JTCZVmD9ksjynWAESExP58CGORmNWZOj3YRGR+AY+w6GMnfK730fMxrX5QLbsOpxdYv5nOH7GG8tihjiWLYUgCFy6dpfm9VyQf/yoVKxO5Uohk0mxKG7C3YePM3WeIRMWY25qiLVlMUZMXoqR+yACgp/Sq6MHXrsXsGXpH5SzNmX5upT5aQFK2Viy78JdTp3LmnH0o+S9kZcObfpOo3ebuhQzKZrub8uXs2PTgQvEyeXUrVqeA8cvEyeX023oHBJFESNtDbq1aUiXNg2Jefuext0npOnykaQod+4/QyMXOw5f8CH8+csMySwIAqVtrdh/9tZ3XWta5Ca7049QTl8zQ+kuz128QQePKsl8e9d43eevmYO45/ckGyX89QmLiKTNlA2M7N8JiUQgTi5n84ELNK5fjYCgEEpZGOFUrpTy3hczLcraSw+/O7frll2H+fgpnmu+AZy97EOH5nV4dXIZfbq3wrGsHSoqMmQyGTPH/U7Isxd06j81xbNRsoQZC0d34Y9F23KFa9Yvp1z/mjWYLu08MrQ8LGZSlN5t6/Is7AVVXZ04f9OPDn2ncjY4kh3ju9CrTR1u3fXH1tqCPt1b8desQQybvhbf+6mH5e07cpY3Me/o060FdZ3tmbpgA2ERkURFx6ar8HR1tLnxPCZT1/z/fG9ezdxG0gZcs5pOfIhLf7Nv2bbjNG9UI9l3iaKITCZNtQR8Phln6do9bBnbCX09RYY8n7t+VHG0Rk+3MPceBtGwZsVkL7U79/wxUJHQpu80XJsPZPm63Yydtuybs8mwiEiWbj1O+TJWWJkZMX1cH6o4O6KlqYFUKk3WvoGeDjPG92WQZ3O6Dp+fbENYTVWVhrXd2PbnGIZNX8u+I2ez6a5kjCxRrsvX7so1syXF7mXGLksQBLq296BkieKoq6nRuUlVJAI0tDOhtUcdPBpUY+DqQ8g/flQu32eP6sbkhZtStBX4KIRh87ay9tIDxsxcQ+TrGNZcuEeVDmPpMXQ2foHfXioJgpCvCL7gVtmJkiWKM/j3DlhbfTt0+c49fwx1NFOsVDzsTZm/cgf21pkLfc5HEfzi/ziM1h51lJOVeat206GF4v8Xr9+njJ2V8vdR0bEMnb6Ws2v/4MKeRexfPQkNtYKERrzi9MWb/D58dqrL+aV/7aZ3u7oMWnOYkf07I5NK09y4TNoQruJcnpNbZpGYmIhryyHcuef/peKGBPNiRmxfOoZjZ6/z+/DZOZbsP0s2tELCInn9JjpXVGv81ow1Ti7n0hUfzly6jdctf26+eIutthoFVSRUsC2OT+Azdi0by8AJS7j7IJBypW2Y1KY6l67cpm5NVwRBoIqzEwvW7OHOPX9lAbU4uZyuw+azfnofXCs5ICCAAMtFkZs+D3DrO5e/K6ZeZO6/SpxcTkBQCN7X73LX7wlrv8o836S0KbVdymFUVJ9rtx+SFA/frlntFEXrjp25wu+dGqfo963LJhAWFolNSfPvlm3W4vVM2H6eYe6V0kw5+asTJ5czYdFW1s8ZorTb37nnT2KiiGNZO+Lkcv66+IBV88yVx3h536J327pKt0UDfR1aNa1D94W7+HxlAsvX7Wbw+MWsmjdKeUzgoxDO3fTjU3w828d2QV+vcLqyhUVEcvCYF2e8fdl/7ylN7E1p2Gc2y0Z1osUXz57ipkYsnzOC0+eu0HXYfOaP88S10s/d6MqSmau9dXHu+wdnRVPZRlhEJJ36TeX0xZu0aVKTk1tm8eb0MswNtVnyx28M6tWa09tmY2ZqRPN6Lly+7qso8+vqxOmL/9pCJRKB3h3d2b7vtPK7yXP/or27K1Wdy6PypaCjTKoo9KZasABDGlVMN9Y/LCISD3vTbLv+JDbvTHtjLrtRlPXwYdbi9WjV6M2KDfsxLKLLoF6t+XBprfKzYGI/DIsoSnW3aVKLbm0b0qZJTfqMX5ZsFhInlzN+21kqOpVOcS5NdXXKdp2UqQ29qJh/GFjfifFDsz+DWW5l8artdHB3S+aDvH3faYZ+KbQZEBTCkIYVk73URFFEq5BGMn9wdTU1nIpo8TzyNX17tCHyTQze132Ux6zddpherWtz2ScI97pu6Zrzlq/dRes+0xARaV7fhUltq2NV3Ii/Fwz68iJGeW6ZVEq9Wq5sXzqGagMW/lCNr8yQJcq1hIUp/kGhWdFUtuB93QeLFiPo2b4hM8b1RUNdjUZdx1K5+VCO+IXjXLEcttYWaGqoIwgCjetXY9MBhbNyeQc75h2+nqy9aq7lOXr5HjMWrmXzrsO8iX5Hj05NU1WgT55G4FLBPl0ZP3yII+Zd1iR5fvUNm+s9/yc8DXueJefJKIGPQlBx7opWjd50G7OccVvPEp+QQKIocv22Hxt2HmX+ss0cPnGBwycuEB3zltK2JbC3seT1mxj2HfXixLlrNKxSNtlL/LavH5PaVkcvlRWTIAjEZ7LIXTFjA8raWjBs4p+Zvua8TOCjEPaduUmPTk2Vyi7wUQjnb/pRwVHhhfM4NJyythYpjk3NH7xGeVtev4lGKpEwtFcr5n2phxYWEcn5m368ex/H8J7NUFdT+6Zcm3ce5sbdILq3qM7A1Yd5Gv6SGq5OmJkU4YH/Y6Ji/0lxjEQiobipEdvGdmbpXz+3DluWKFc7a0sOnMuane6sZt+RswydvpbTCwZSv5YrZy9cp3TniXRvUZMl47oj8m/QQNKDoadbmDIljJV2nMT/y+WmrqbKzKEd2Xj4KpNX7mf8kG5pPhjXbj2kqIFuhmT9+CkhS4zw38rgXsvNicvXfX/4HN9DyRLFubpqNCObOKOmIqGbqx1HZvSmn2dzurd3p3u7RrhVKocoirx7957t+06zbvsR1m0/QuDjZ1SpXI73cXIW7b2ULMPZxl0nqOHq9M3ZjopzV7oPnMbg8QtZvnYXm3cdTtcGZ1xUnxXbT6Kl+e3B/qsyeuYa5o72TPZM/334HMN7NFP6gV+79TBFzuDz3j7JVnlJlLE153Gowve1irMTiYki3td9OHDMi85NqjJ83XEapTNrjYqOpfuCnZgY6nDTN4iIw4sZNbAbbpUdcatUjldvYlh7KfXy3oIg4F7XjXM3/X7qqi1LbK66OtqUKWGSzA6Z0wQ+CsG+00SGNqzAhnnDeBMVw9jpKwh8Ek7grlkUNy1KUHAoQxtVTHGsIAh41HVh8JRVfPwcz6Ke7in+3qhuFWav2sOQ7k0xMy2a5oMRFfsPBl92WtOjjJUxs1fvpUHtb9eJ+hEqONnjPm4lnh2b/rTsUYIg4FTWFofS1kwaCXcfBLDrwBmCQp8z7LfWuFZywNoKICmvqPj1wVy94cupK/e5tP4PbK0Vs6Wo6FjuBD5jkYNdyhN+xYdLa1mxfg8Ciuz2o+dtwd7rFjtvPWZ440p41HPFsaxdsnvR3L0W5R1Koa+bvv3vV8P7ug+6WhpUcf73pRUVHcv+szc5u6PtvxtbR64zcWTPZMfGyT/x//liAYoW0ePWXUUuY4lEYGivVhw4fpnzN/0Z0aMpC3o0SnfWeuTkRUY1deXU1fuc2T4HDXV1pSxxcjlx8o90d03bt11dTQ1HGzMMGw5gca/GtGtRP9v3iLJk5ioIAq3cq3HsTO5w3l2+dhf2nf4gPiGBeUeuU6bzRPYeuYB7HWd2rZ6KeTEjJBIJcfKPSNOwydmWNMfWvCgH1kymf6+2Kf4ukUjo0ao2/7z/kEyx3rnnn2xHdO2lB1hnIHnwhzg5OtqaVHGw5rav3/dfdAbR09FmgWcjjp/xzrZzpEaSH7CKTIpTWTtmjOvLuAGdmL96N616jeeM11ViYt8pcwskfc56XWPYjLXsXDYOOxtLpQ31yMmLdPKoku4LQkUmIyziFW6VylHe0Z47r9+xYcn4/7V35nE1pv0ff98ZM51Eq0QkQxuikq2ylJElWbPvywghQ9bCqBhDyEyosWXtsUUzjD1r2ckIyTIhCWkxKDPPOL8/jnOm1KlTnXNqnp/36zXPy9O5l+u+r+v63tf1vb7X50vUglHcf5RGxI7DOPb5hrCNu8jIzCbu4jXCNu6mbu2aVNH6/zdyjT4Uy/gRPfO5uCKjDjO4m7PMAKakPsO9oUmBd6/5xedcvPWPLq/Uxx6+7YAsFQ2Ag11DDp27gbbm5xw5fYU2rWyL9bWu2nYIzS8qM26AWz7DCpKZmpGhHvq62nLPFwSBnp2cOLTEm/diMTW6TGL1+p0q9cMqbftrG8dmuM8Jx2t4b7VGDcRdvMazF5n5lOm9RnpiZlqTmUu3MLxHG54+z+Ds1SSGeLrx2WeVZMc9ePiEFvaFj3wEQaBqFRHVDfXkVnzTxhb5FrYAYi9e5/dHqfRydyUjMxt7o2oKxdw+ePiEls0aoi0Ssf9onMq28AmCwGDPzhh3nczzInJRqRKpobVvas3O8ECuJ9zhyInzhG3dz883Uxjt3BBdHW1OXUnEpr4J/wmdQ93a+Xe7RR2OY67PUIW3u1bR0iTlSRpTuzbns0qVuHHrPqP6deIrl9Z0HTKD5JRn1OgyCdvqVVk8XfHr/q8hFovR/uijsjn6NAc2Bsreya3E+3zlWNAgan7xOYY6WqwMjwRgbuRJRjpZM2VMH5xb/dOeRZqa+I/z5Mipy8QnPcauSdGz3fgbidTQ12b/qWvsWu1f4L6paelUqlR46FZe3Fwl8dPtnZvTt0dHzp6/St/xQbRzsKJ7J0elRxMozbhqiTRZProrkVGH8R7dT1mXLZKU1Ge0nbSCB1FL8v29koYGnTs4YWZai5HTV3A8cgmJd39nwtzVbFo2Ld9IsqgsBcVlwDWtXZMDsTdo/cFP+jQtnfibDwjeeoTOHRxJf5lJK5svWb1+J7Y25sVWnoYgUK9uLYbPX8vIAckKjXhLg4G+LtvnDGP2wrB8YTHqRip+Y9/UGlsbK0nmUsTcu/8IQYCp4wair68jS70sJSX1GWKxuNhOCRKf++kridg1qk9G9h84NLGQhBlFnuDZ8N4k3LqL6IvKLJwzHosv6xAWeQS/ZVsx0NOtMC4udZOekUXe5CmXnmZhkMdFkvTgMZb16xQ4TxAE/CcNIuH2fWwbW/BydF+0RCI0BI18I2GJW82Jb0N30bGldbFG8bebd2nXwoZTF28UuvPy+q0HmJvVkjtQkpI3csTIUI9e7q64ubQm/kYiETsOM23RBoZ6tMGxRRNMa9cs88BDaTu0pCOiyeHqk/36cd0uIv2GUqeQJHcaGhpYW3zJ4G7O/Lh2B82aNuT7WSOYtegn2THnr9yinmmtQq9toK/LqWISpOnr6XAr8+2HdMZiahjpM21cf9wcLNgdfYy0Fy+JOpNADSN9LBsUXFktDIsGZjz/878Er/mPQseXBkEQ8PTowPv379myo/z33kvlGD/7TBK+ZmVRD0vzelQ31OOzSgWT40UfPEXPjq0VGl16LtjIhafZDFkSyeTw/Qz5fjtDJwbiXEcfDUEgcu8xxg/pxp9//UX4jqNsWjaNVQsm4OkTzJIfNytdDrKi4+psz7UbSfn+JiZ/FMDx2HjM5PSbyp9Vwnt0P5xb2VG1SpUPGwIK1pOWSMTkIW68eVv8+024k0zlypXo4PTPaDknN5f4G4nMCgjlv3//Tdy1ROrXNVH4OaUbDrSraOHcyp41S2bw87oF1DczIXLvMSI/aI6UBaVufzXQ12X5mK6Eb4pS5mULJSX1GScv3abrV85yO5kgCIwe0p0Hj9KYHbiK9JdZXHuQls/4y5Oo09fTYfxAtyLLIAgCo5wb0sjyS3p2daGXuyuW5vUImjWW0G2H8Fu6iYXevejl7qrwV1D6LM8zsom9cK2YowunkeWXxR6joaHB3KkjCN12qNT3URXSGYO8et0cfQrXdi0UupY00uO9WCz7L+r6Q04/eolR50lsOXqZyp9/xoZtPzO4mzNWFvV4mPIU58Z1uX3vMVP8Q/5fGdjmdo3w+Wl/gWfO60eNTnhc6Kyqpb01D5KfyHZXFSdaNKRvV67fTSl2MBZ84AKG+jq8fv2WvQdi8PJdTNX2Y1kdsQ+j6rqcv/mQt7l/8TYnt9i6+vhe0nJWqqSBoYEeHV0cWeQ/gfEjPYu8jiIo1bgKgsCYIT3YF3NZ5VvOTpy+yPiBbsXqd2qJRKwI9MG9o8TfYqyjJRPzDT5wgTq1Cxd4yX33jqaNi9ek1NfRln0FpY3KUF+XUX3a8/69mOH9PeRu5ZOHQ41qeHZx5lRc6YyeoveqY2JMxNKptJu8vMIZWHnE30jEWL9qobMVRZHGIvz9/j1Pc/+L2/RVLIw4SKtmjXjy9Dl9AyJYMGMM65bP5sa9J/QY5a/2APTyQl9Ph2+6NOdM3FXZ36Z1bcGdu8kAPE5JY2rXFoW2scZW9TlzMUHhe2mJRAzxaMPla4WHUEkRi6GjS2tMjA15mZFFK3trlo3qQnzSY27ffcwPc0cxdXRPNu08TNX2Y4m/IX/G2XWE/LqU9GNBaTKdStdz1RKJWB3gzaxFP7Ft9TyVhftEHYlj8eyxCuVTr6IlwrmVHWKxmJTUFzxNS8emoQViMXLLdybuKkkPHmPXpGg/TmH3z333jg17ThKxdGqpKqm9gxU2DRswPPg/zPlmVInPVxRBELCyqMfxFVNoN3k5p36YWm5amBmZ2ZyKu8KFK//ssmlkaYa7W5t8o/6zF67Ty81RqQtO79+LeZr7F44TlmBnVI39C70wNTFm9YZdNKxXE2tzUzzHB/JrxMICM5C9B2LoGxjBra0BDJ+2jHbNLFk8b6LSyqZuBEFgUO+vCFy5VbYA1NqhIWcvXMfWxoqExPvYWJkVeq5FAzPWn7nJD3nSYRd3L/smFkxftBGj6vrY2lgRfyOR3x+lkpqWzq27D6n8WSUcalTDuMtkWYjeNPcWdHC258DGQPT1dD+kB4eOLo4EZWahXUV+lIfv6O5cvJpA7TJ8nBVF6apYgiBg39SaZo3rExIWqezLAx+mJjcKn5rIK5N0dGnfxILL1yVfNoca1cjMelXoOa/f5lCzhkGx1y5s6++h47G0tbeQxWQqQuLdh1T5MAoXBAHNLz5nhJN1qWYAJUktLQgCbVvbywxseY1g019mSra79nBlxICujBjQFS0tzQKqWFt+Pq2wS6Ck/P1ezOW0bPYeOsPS0C3E37xPSNAUhvd3RwAmF+IiEIvF/P33e46eusC00d15mfVHuQmFKAu7JtaIxWLZCLC9kwM+P/2zbVqeEL0gCEzNM8pVhOoGerRxsGCcfygtPCYSsGIzYrGYBmYmfF75M344cpXLz14x3NGK2T2d2L/Qi4mjPeno4oihgV6e9OCSqX11A70iDXvVKlpq202qEslBQRCYMm4gDx6lqUT2KyfnHeu/6Vuq0Yt0N9mWHfsZ0MWRU7GX5R6ryPWlDU1qlDIys1kcvpeZk0oWzmPZwDTf8YIgYNvwy1JpNpR0tiA1sPd2f8+0hevLxcCa169Lz64u2DWxxtJcsqDVy90Vk5pGsmOS7iWX2SWgCOtO3yRw2zGmew8kK/sPuo2ax0B3Z6zr12bBknX5ju3Z1QWAhynP0dDQQLdaFZWWTR0IgsC0sZ6yMEN9PR3WTfEkfFMURoZ63Ln3SO65NlZm/HbzrsL3smhgxgzvIfyyPoC6xrrUNzWmk6sjHV0cCf7Whz/jNvHqRDjTxw/AzqYB1xKSaDvYH1OX0awMjyzgAijO1/smJzdfzK0qUZmeq5ZIxNypI1gcHqX0zqqnW43hAzxKda6+ng47V/lz+sINTpz7jYDVu1m1fmehjvAqCuRj+uuv/7L/2HnaTV5OTm4us4PWMH5Ax3yhK4rQy92Vr9pLUproVNVCJNKkppEBh05cLObMgpTmoyNVEtqxyq9cDKx0ZpF3MetjX/X5yzeU7hIoDDHw+u/3DJj8Pd2/XsCSWSOYOKYf3dycibl4O9+AQer2cXW259CJi5y+cqfEdV8RcW5lz53fnxB74RqCINCvZ0f2xVzm88qVmRt5Qu7CUZNG5iXyuwqCgIG+LoYGemwMmYOpiRFT560kK/uVLIJEu4qW7GM7y2cEN379gYEudkQfv8j8ZRH0Hu2ncHtNTUsvEMerKlRmXAVBoI6JMTs/dFZljmClHa+055rWNmZFoA9NG5oR/+IPjp2NZ4p/SD5H9/krt+SGm3yMibEBAxwasHjlZt6LxQqLdedFsiAmOWf2lJHUrlUDiwamrDt9s8Sr1aVdfJG+G6mBXbV+Z6muoyr2HomjdXMbtd3v2vM/yP3zvzjYNiT64Em8/H5kllcvPBds5N6DR6z6oGN8c+sC3FwcmerVn52r/SuE9GZZEQSBeVOGMm3henJyc9ESiVg6exTfrYpkSCtLubsIbW2sFIoA+Phe0rUR79H9aGxpRufhfpw+d4Wke8ncvf+Q3HfvZIvG2lpaLJ7nTa+OraiuV40Jw7oRHL6LWQGhxfaVR0+eK9yvy4pKMxHk7awHYy4o9PDqQBp68d2+OG5uXYAYMQ9SXmDWazp7D8TIyqiIgaxc+TNsGzXgz7/+y93kVFYE+pR5pVE6Yvvi88+x1BGVeDtswLKNpX7P0jr7ZUMA8Tfvyx3Vq5uMzOwS+dmVxe2stzj3mcbBmAvsCPWjp7srs3s50X7Et4jFYjQ1P8fa4ks0NAQszesVqTPxb8OuiTXd2tmxYdvPCIJAm1b2NDA1pm5NA7mRLIIgMMSjTaniRKWDJu/R/RjevQ0DZ4YSsnYX67fvp2r7sfQe7cfeAzES8XoNDSaO6YeejjapT9PZ8qM/VbVF7I4+ptB91IHK07zkHSma1DTEpb9vhXD4S0NKrC2+ZNuquQzu0Q4bfS3WbD1At2FzOP/bPbJfFZQw+xhBEDh04hLVqohYu2yGUvejWzQwIzE7p8QhWTZWZvj4lT4+UxAEDA30CAny4WHKM3z8Qso908SjlKdMdS88BEjVXHvxik7tm/Pu3Ts8x/jzJC0dy5o6OLVogkhTU1am4vx9/zYEQeCb8QPZvO+UTCFu5qShBEXF4h8ZI7dNDPLsLDunNGhoaDB+VD9W+g4i9XkG83xH8S42Av/Jgzl3+SYu/X2Jv5GIhoYGMycN5UszE6poiZg9ZSRdOzoXee2TlxMRqSn9ulpyaAmCRDTXe3Q/ls4aydCpwUTtP66OW8vlxctM9KpVkZVtWH8P9q2dz9iBXRg3qDPv/vwb4xqGxV7nYMxFnjzLZOXCKWiJRErtXNJr+UfGlMhQeo/uh1gsLlO0hvS9LJ7rjZNDQ7oO9yt1Z1EGZy9cp2ObZuV2/36Bmxjos4Sxg9xZv2IO304Zgv/SiP8pY1oYWiIRa4K88fILJSX1GQb6uuyYOxzXekaclLMYbKCnIzuntB94DQ2BPh5f0cGxKQHBG6hUSQO7JtYsnuvN6oAJ/HpMIjxkoK+LU0s72ai3OJfMpbRstYRhgRoTFEof3rmVPTtX+3Ew5iIzy9FNcP/3FKzM6+Ypm4CpiTF9PDrg2aMjF9OyiqyEnNxcZgaEArBz7bdKN6xSHGpUY6RTwxKFt2hoaBAS5MODR2llesfSOhva34PVgRPw8gvlu5DSuxxKS9K9ZLZEn8bBrnjRcVWgoyEwv29bTu0MplMHR85dus7ytXv4PS2zQszCVIkgCNg1sWb6mJ4ELNtI7rt3eHp8BQgsW7+vyHMGezjz7UfRFSW9t/foflTTFpGRmS1rj3ZNrJnlM0J2zMdRNvLIyMzGoYZiQkrKQO3ZXwVBYsRCgnyoXY5ugqjDcTS2ql+gbHkrq6hKeJmRTTVtaFVNzwAAE9xJREFUESFBPlRRkWEFOB8dStsWjWViw4qiJRIRHjyT7/wnoPnFF2Uqg4aGpLMcj1yCdhURLv19idp/XC1GNic3l+A1/2H6173UvlCkoyHQvVEdru9egv+00WRl/0HrnpOIPnSWqV/3IWBSX3b/Ur4ZRtWBIAj08eggczflvntHaKA3t55mc+Hyb3LPGT24BxlZf5RplqqhocHsKSPR062W79qlWdc4GXuZnq7qm/2US2rt8nYTpKQ+IzX9ldzFEekXrihMahoxe8pIlY1YpVSqpEGTRuacz7NzSRE+3pJbVvKu5kYsncr5K7dw6e/Llh2qE+rJyc3Fxy8EGysz+nxIPKcubPSrsC3wa6I2LMS0tjEaGhqY1DRixyo/Fs/1pqFlfbREmiV22fxbkY4idapq4eMXgmmdmng6WTPAd6Xc59cSaTJ36gj6BkSUafuwMtpwTm4u3/8UhaeHa/EHK4lyMa6Q302wf2MgB2MuMnbaYrXs4d6y8wAzvu4lt8LSX2bS3qFoubnC4jBVhaGBHknJqSq/T3FIn9nSvB6L53rzy4ZAsv94S9fhfswMCCX2wjWlGZqke8kMmhCAjZUZ3qP7qdWwrvy6G3FRK+jasU0+uUNBENDWEjFu+hKMukwiPuEuPRqZqlTcXB6n4q4yYc4KTuXRAFA1GhoafDtjDGKxmCn+K5k/dSTvxWJG+CwqtN6l4Zj7F3kxyV++EVYHIWGRdG9vr9Zok3IzrlKkQichQT68ycnFc1wgW3b8orKKiL+RyN7jV+ja0UnuMW9zcivUQkXtWjWITnhc3sWQITWyhvq6TBjVl2ORS/Bwc2TTzkNot/ua70I2ciQmrlQfyvgbicwMCGXo1GC8BrnjPbqfUkQ0ikNLgAEODXh+8EcmjulHFa3CZySCIDDU043smHBm+YxgcG/XAhJ9quRK/G36jQvAdcYawk7d5PWbt2q7N0jcTSFBPthYmRGwPILvJnmSkf1GbnSKIAh07uBEA1NjNmyLVmtZpUj6/GWmjBuo1n6tdOGW0pD77h3fzP2BVnZWhAR2Yu3mvbj092XG173o8pWT0sRfUlKf4eUXSliQd5HXfPDwCS2LEd5VJ3fvP2SUs/z8QOVF3uBvp5Z2OLawZWFGNnfu/c7pc/Gs2bqfn28+xte9JaYmRjKthi/rmqAl0iT5USqv3+bw5s1bYuJ+4+Lth9QyqApiPuRJUq3LRUpz42qEL5pM00YWxYZT6elWw8y0FkdOnOPC1dsciktAv6qIiWMKpgJSNjv2HmHQsl28F4tZM9ad3l3bUd1QsfxsyiKvS2/V+p2s2LQfPW0RNQx18fELYeXCKQX6liAIfDtjDK79p2Pb2EKt4kA5ubmyPl9cni5lUyGM64Zt0ehU1ZJN/2b5jKCShgYn4+JZsnYv3oM64e7WtkwLGkdi4pgXsp3g2SOxa1K0+vn5K7fo3kn+yFbdJCTex7Zh8Rqt5UXeabOhgS6GBhJDKwYyMrJ5mZHFw8epvPkgwhIZdRQEqFPLiFrGhmhpibBvXJ96dYz443UOp67c4c8//0K7SuECIcqi1hefsdC7F0P7eaChoViMqiAIXLp2k9ev3+Lh5oiv92CMOk9SaTkB1m7dh1fYAVrWqMZKv1E42DZEENQXEJ8X6QfIe3Q/bBub4zUvnHovs2T+2MIMrJZIxKZl0xjuu5yDmwqqi6mKkLBIBns4F9vnVUGxxvVlRhbVu08H4NbGOViZK670pAjxNxLZtO80J3YGy6Z/giBwLv4OPwb5IBbDz4dO0WW4H03NTejs0oLGVvUV8p3k5OZy9fptNu08xPOMV0QET8PS3KzYl5yUnErdOurZIqcIm/ccY/43w0p83oGjZ/FYsKnQ31RRl5Df0AIfjK0uluZmsmN6fsh3lrcWovYf50VGNqYmRrRD4vdWVQfUFmBKL2d8xvbHQF+3xJ0ub742AE9bM5LuqS4tz4GjZ/Fasx8xsH6RN9YW9SqE20q6ZhK5YhqDpy5nwaS+pKal4+O3gpULv8lnYAVBsoNtwkA3ZgWu5qfls1VeviMxcVy4nsT21fPK5X0Va1z3HDiJWCymd6PaWCq58UiG7D8SFjQRrY++dNEJj9n7Ic7Ue3Q/Jozqy/WEO8Re/I2DMRdZf/YWPRrXwaJuTXSqVZHFrL5+/Zabd5LJfPWadWdu4evegmF9O+HYwlbhHTR5713eSAP3S5vPKV+a6jyoK210oX5LOccdPnuDsIXe/HosjhcvM5VurCoDTnUNWbNoMhbm9RDklK84MrNeMStoNevOSCI4bPTzK2FlZGZzMvYy7Z0cSH+ZCVDqZ3mbk8vC8H2IgW3T+lYYwypFEASaNLLg1w3fErg8gqYNv8Sqfh25BnbYAA/OXrpJ6LodKnWlJN1LZu6KbexaM1dtKeQ/pkjj+jIji3FhkhxLk4aXXIykOA4ei6WtvSV2TazkLh7k/betjdWHRHYQjpik+w8RkOy2ep4uacRVqogY0OsrtESahC2tC4JQqk5UURrw9qij+HqVTl7x9l2JNNzsbs0Jmvl1vt8qyvNJefg4DZB8RB48fMKzFxllut7Hiyv6lTTYMG8UHp3blnmbqp5uNaaNGyBpX8Cq9TtJfpQqM6Bdhvtx6WkWu+dLdHqtzOuW2rieOHuZc0+zAKhVw5C1W6N59OQ5piZGWNY3pZ2jfamfQ1lIowJCgqawYOk6MrNfY91AvoH9zn88Y6Z9z6s/3jBuRB+lz1BSUp8xdOpSgv1GU8ekRrm19SKN654DJxEDvRvVpp2jPY9S0oi79BuOzZtgKic9iqLk5OayODyKg5sWKvzw/0w5AQTZSFpew61oBqSkJN1LJik5tdQLAJkftBFsLM1KtOKuyiluYWRkZhP5axybl/kqbX/+7uijsn/7dLJn4ZxxSotJFgQBiwb/uJdqGRvy+m2O7PdNwdOwHjyX1LR0/LfHcHDx+FLfK+5DfHMrYx1cZ64B8YeEgUj+J8yrG2OH9izD0ygHyUKXJovnTWTVuh1s+fkMHu3taN/Plz1hc/PtdjTQ02Hbqnls2BaNYaeJBA10oZ2jHdYWX5bZ0KakPqPPuAAW+AzC+cO22PJCrnF9m5NLRPRZ4J9R686fY5ixLYZbEeZlvvHBY7H0cLEv9GUm3Uume6PaxV7j3248i2Pp6shSj1rzUlWOcrw8hk5divegzgwrpWZuSZkVuBrvQZ1kflkjQz1On4sv0zWrG+rL/r3y8FV+OOJVpusVidT1EhDB+4tbZNKRTi2asLOGAV1mryH9cONSGY5Fv0j0fAVBIHrecGys6mNooMuJ2Ct0X7CJcWH7MTE2xL0YwRJ1IHyYJU4c0x9bGwvaTVpO4CAX+owLYE/YPJmBlRriiWP6M2pwd86eu8apuGu0mbScHo3r0MutNa5tW5RYA0BqWId4tKGTq+p1f4tDrnGVTkdaGevQ3E4SBpT56jWFe/BKzuY9x/h+jvwcWBZmFWdBqTyIvXCNF5mvyhS2Iu2YEXtiOH/1NrrVtGlua1XsVPLAxiCWhG5l7LTvmDdtlEqFLkLX7UAM9O3ZUdYWqhvokfXqTZmu28nVkb8vtFZCCUuOSKSJr3sLLM3NOHj8HBu+6Zdv+2ZpmDO2Rz4D2q2jM2vS0hkffoCNu49XCOMqRRAEnFvakbx3KZ7jg3CybVCogQVJFIGbqyNuro7M8hlB0v2HXLySQJ9xATQ1r63wAnb8jUS8/H5kgc+gCmFYQY5xlTrRAfy8ehabYbWkSBdpinphFeHllBc5ubksDdvJ/G+GKeU97El4DAmPJVPJ7TGMa9uQ4LkT5Nargb4ui+dN5GhMHH3GBTBzbG+lxhtLCV23g2Ox8WxbNa+AX66slKf8X+1aNfh+/iQEJMLn0vKUht6NahN1M4XXb3IKXKO2sUS1bU8F2mAiReqH/TUiiNkLwzDS1aaX1wL2hs/P97H+eF3FsoEZlg3MGNLPvcACdnNjHdo3s5QtYGtriTCqrs+vx+KIPnGFNYET5a7flAeFGte8o1YXZwdZYaUjobJy9sJ1xg/pJvclJCTep5FFXaXcq7TkKJjBUhUcPBaLed2apY4QAMkH8uf5w6lf1wQrczNeZmSx59dTjA8/wJpTt3B3uSx3tCOd3rm5OtLMtiFLQreyJeoY38/xUpovNnTdDjZHn2b3mrloiTTztQUDfV1OXi4/ecOyIn1/ysDNuSlRN1M4dTGBAb3c8v2W+uwlIDHAFRFBkKRwCQmawoZt0azZGYPHmG/5Zd23cmdDeUP5Pl7ATkl9Tk5ODjFnLrFm66+8yHqDW+tGtLS3JsZrgMp1PkpKocZ1426JiIoqRq0Am6NPsydsbpHHyMswqQ583VvwOCVN7ar3IPEbeS7YyIvDoWVqKCLNL+j2wXhKgvv18Brak0dPnvPd/ksKTSWlnWPxvIlcv5HIzIXhWJjVYubkYWVaeMhrWAtbzdXX0+FSWvmKc1cU2rZqCuEHCDt9iwFxV2UuncS7v8sieUZ6dijPIhZJXv+qbWML2k5ejutQf2K2BBXrbvp4Afvxk6cEh+1EDMyfMhjHFrayaKC8x1cUChjXxLu/y6YZHgs2QSFB6NYjFjLHowULZ40t8Q1jL1yjT8fmRb7Y1LR0zOuV39e4PCtpQfAGds0bUeZV04+fQfr/HZs1hP2XFJ5KSkdhtjZWbFs9j4PHYuk8bA7tHazo0dm5RD7hnNxc1m+N5vqtB7JdOsWF4P1/x8q8HieWjMdlxhraT19Nn8Z1qK5flbDTkiiCJYNcKpS/tTCk9encyo5H+4LpNyEI54GzORv5nUL+/NgL11gaJsnn5uvVV9bmKno7Uev215TUZ3wTtI4ty32LfDGPnjyno4py0ytCI4u6JCTeV/vI9UiMRF29dzfVyeu9fiMJGSrpVFIQBESamvTu1oEuXzlx9fptlobtJGLHIeb7Fr/olZOby+Q5KwBk2yOLe8bydM1UFARBoJ2jPbc2zmH/0XPM2H4CAK821gzwaE87R/sKb2SkCIJA7Vo1OP6fpeyKPkpvrwBW+I8p9AMt3YgRtHo3lStVomPrhnR2bUV1A71/zfMWMK6WDcx4f3ZtoQdrOEsC0UuzdTIl9Rm9vQIInDKoWKOVmf26XF+gtrYWr1+rV20oJfUZnWau5tG+YJU9+9ucXHYfOgdIfHklRVoukaYmTi3tcGppx5GYOHp7BRAVPk+ugU26l4znxO+48VISAdB0288M6tO5yNF5ebpmKhqCIGBlXg8r83r4ThhU4Ld/E9KP9LD+HjRpaM6CFZuJ2HGILq7/DKYOxlxk3Zmb/OjlQeTKGYBkHeb0uXgu/naX6ITHjGnTiHp1amBlXlcmBFTR2koB46qoeIW84xat2ABAO0c77Jtac+duMpt3HWLjkatk/f2eK7/doZF1gyJHOuvO3OSnZeW3oNXYqj7rt+9X6z0XBG9g97wRKgt7epuTy8KVm9mT8JhWxjr0cW9f6mvlrXs3V0cAJvqFsG/jd7K/5+Tm8jgljYTE+ywOj2L1t144tbSTjUgM3Lw5GzpNrlvh32Y0VM3/0vuQPoutjRV7Nywi6V4yN+88kP0+YUTPAuIvHxvOpHvJsp2Z26OOkpScSnTCY0lEgYMVpiYSUSBtLVGBVNqGBnpqEY5RultAT0eb+FsP+Np/Dbez3jK9W0uaN7Vk5AB36terzcFjsUWOdKSq9uXZmLS0RGoVp5ZmYVCmOyDx7u/EJ9ylqrYWT9LSiYg+K4sA+U+ILwZK0hYQBAE3V0c6z1pDz5Gzqa5XjXVnbgLQxECbpg1qyXboCIKAvp4Ovbt1INGqPkOnBsudFn7ifx9pW7doYFboqLOovpD3nLxCOhmZ2aS/zCT5kUSFLenBY46duZLv3MaWZmrZIFNi49rKWKdIP9jhM9cYP6Qb/t8UPgrr3U2ysvnD2p0smV9Qqi39ZSa+7uXnbwX1ilNnZGazODyKPWFzlfpBMdTX5YdtR2T70md3a86cZg1xcXYoEPpUVu7ef4hDjWr8GOTD27c5LPbXo/OwOczy6i2r74/VsiwamLFluS9DpwZzaPOiAiMJnapaKhFv+UTFozRtUd45+no66OvpVIh2UyLj+vroj8WGZn0/Z6zsweS9gC5fOeEZEMGsQkJ6XrzMRLdalULPUxfScqtjQWX7nkN4D+qkdHeAgb4usbuWFvqbsmcFR05eYJZXb9kz7D0QQ0/XZkWOxKX7870HdWLxD5sLfGitzOuWWbzlE///qEjukxLlz5COeIp6gPSMrGKPEWlKtgdK5djy8uxFhkw+sDzp3qg2OTnvVH6fgb075dv6qSykdVDYf8okJzeXSeG/0N7JQXb9do7N8I88Qe67ot+fIAj07dmRk5cTC2QArkid5BOfKA0lMq6KNHhF8gkJgkBjSzMSEu8X+O38lVvUqK5fyFnqZcPyWWXeD64I+npFu1kqOlev3yZooEu+GYi+ng5BA104o0DyPJGmJjPH9mLdtl9UWcxPfELtKD3z27FYxdSM5BnqpORUjAzL37iWRqG+NJTnHnhlcCruGu2d8sdaCoKAe0cnVm8p3mAKgkDXjs6cvJyYL0W3tpaI1LR0lZT5E59QB0o3rqnprxTKY59wJ5nGVvUL/D064XGFcEZ/onhycnPx2x6DfdOCyRxtbaxITX+lUAZYkaYmw3q0Zf/h07K/mZnW4tGT50ot7yc+oU4EcZ48IILTGMSx68p2QacxZS7UJxSjsLr6VIf/LuTV1ac6+HdRaF8Uy0uy9IlPfOITnyg1SncLfOITn/jEJ+D/AFCSCuhY8ByEAAAAAElFTkSuQmCC"
      }],
      "identifier" : [{
        "system" : "https://felleskatalogen.no/vsid",
        "value" : "545806"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/COPD-MPD-6"
      }],
      "date" : "2021-01-01",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "felleskatalogen"
        }
      }],
      "title" : "Airomir Autohaler Teva",
      "section" : [{
        "title" : "Pakningsvedlegg: Informasjon til brukeren",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Pakningsvedlegg: Informasjon til brukeren</h1><h2>Airomir Autohaler 0,1 mg/dose inhalasjonsaerosol, suspensjon</h2><h3>salbutamol</h3></div>"
        },
        "section" : [{
          "title" : "Les nøye gjennom dette pakningsvedlegget før du begynner å bruke legemidlet. Det inneholder informasjon som er viktig for deg.",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Les nøye gjennom dette pakningsvedlegget før du begynner å bruke legemidlet. Det inneholder informasjon som er viktig for deg.</h2><div class=\"paragraph\"><ul><li>Ta vare på dette pakningsvedlegget. Du kan få behov for å lese det igjen.</li><li>Spør lege eller apotek hvis du har flere spørsmål eller trenger mer informasjon.</li><li>Dette legemidlet er skrevet ut kun til deg. Ikke gi det videre til andre. Det kan skade dem, selv om de har symptomer på sykdom som ligner dine.</li><li>Kontakt lege eller apotek dersom du opplever bivirkninger. Dette gjelder også bivirkninger som ikke er nevnt i pakningsvedlegget. Se avsnitt 4.</li></ul></div></div>"
          }
        },
        {
          "title" : "I dette pakningsvedlegget finner du informasjon om:",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>I dette pakningsvedlegget finner du informasjon om:</h2><div class=\"paragraph\"><ol><li>Hva Airomir Autohaler er og hva det brukes mot</li><li>Hva du må vite før du bruker Airomir Autohaler</li><li>Hvordan du bruker Airomir Autohaler</li><li>Mulige bivirkninger</li><li>Hvordan du oppbevarer Airomir Autohaler</li><li>Innholdet i pakningen og ytterligere informasjon</li></ol></div></div>"
          }
        },
        {
          "title" : "Hva Airomir Autohaler er og hva det brukes mot",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hva Airomir Autohaler er og hva det brukes mot</h2><div class=\"paragraph\">Salbutamol, som er virkestoffet i Airomir Autohaler, er en selektiv adrenerg beta2-stimulator som virker ved å utvide bronkiene, og derved gjør at du puster lettere.</div><div class=\"paragraph\">Airomir Autohaler brukes hos voksne og barn over 4 år mot bronkospasme ved bronkialastma, kronisk bronkitt, emfysem og andre lungesykdommer hvor bronkokonstriksjon er en kompliserende faktor.</div></div>"
          }
        },
        {
          "title" : "Hva du må vite før du bruker Airomir Autohaler",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hva du må vite før du bruker Airomir Autohaler</h2></div>"
          },
          "section" : [{
            "title" : "Bruk ikke Airomir Autohaler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029897"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Bruk ikke Airomir Autohaler</h3><div class=\"paragraph\"><ul><li>dersom du er allergisk overfor salbutamol eller noen av de andre innholdsstoffene i dette legemidlet (listet opp i avsnitt 6).</li></ul></div></div>"
            }
          },
          {
            "title" : "Advarsler og forsiktighetsregler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029898"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Advarsler og forsiktighetsregler</h3><div class=\"paragraph\">Snakk med lege eller apotek før du bruker Airomir Autohaler.<ul><li>Hvis du har en stoffskiftesykdom, høyt blodtrykk, diabetes eller hjerte/kar sykdom, skal du nevne dette for din lege.</li><li>Ved hjerte/kar sykdom: Oppsøk medisinsk hjelp dersom du opplever brystsmerter eller andre symptomer på forverring av hjertesykdomen</li><li>Hvis du på noe tidspunkt føler at dine vanlige legemidler ikke virker, eller du bruker mer enn avtalt med legen, bør du umiddelbart ta kontakt med din lege. Et økende behov for legemiddel kan tyde på at din sykdom forverres.</li><li>Hvis effekten varer mindre enn 3 timer, kontakt din lege.</li><li>Hvis du kontakter en annen lege enn den som har forskrevet Airomir Autohaler, nevn at du bruker Airomir Autohaler.</li></ul></div><div class=\"paragraph\">Informer legen din før du begynner med dette legemidlet:<ul><li>Dersom du har eller har hatt hjertesykdom, uregelmessig hjerterytme eller angina.</li></ul></div></div>"
            }
          },
          {
            "title" : "Andre legemidler og Airomir Autohaler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029900"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Andre legemidler og Airomir Autohaler</h3><div class=\"paragraph\">Snakk med lege eller apotek dersom du bruker, nylig har brukt eller planlegger å bruke andre legemidler.</div><div class=\"paragraph\">Det er viktig at din lege vet hvilke andre legemidler du bruker. Spesielt skal du nevne om du bruker vanndrivende midler (diuretika), aminofyllin eller teofyllin, digoksin (hjertemedisin), steroider, avføringsmidler, betablokkere (hjerte og/eller blodtrykksmedisin), disulfiram (for å unngå alkholinntak) eller metronidazol (antibiotika). Din lege vil gi deg råd om hvordan du skal forholde deg.</div></div>"
            }
          },
          {
            "title" : "Graviditet, amming og fertilitet",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029902"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Graviditet, amming og fertilitet</h3><div class=\"paragraph\">Snakk med lege eller apotek før du tar dette legemidlet dersom du er gravid eller ammer, tror at du kan være gravid eller planlegger å bli gravid.</div><div class=\"paragraph\">Hvis du må bruke Airomir Autohaler under graviditet, må dette bare gjøres slik din lege har bestemt. Det er begrenset erfaring med bruken av Airomir Autohaler under graviditet.</div><div class=\"paragraph\">Det er mulig at barn som ammes kan påvirkes og bli urolige. Bruk av Airomir Autohaler under amming skal bare gjøres slik legen har bestemt.</div></div>"
            }
          },
          {
            "title" : "Kjøring og bruk av maskiner",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029903"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Kjøring og bruk av maskiner</h3><div class=\"paragraph\">Du må bare kjøre bil eller utføre risikofylt arbeid når det er trygt for deg. Legemidler kan påvirke din evne til å kjøre bil eller utføre risikofylt arbeid. Les informasjonen i pakningsvedlegget nøye. Er du i tvil må du snakke med lege eller apotek.</div></div>"
            }
          },
          {
            "title" : "Airomir Autohaler inneholder etanol",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029904"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Airomir Autohaler inneholder etanol</h3><div class=\"paragraph\">Dette legemidlet inneholder 4,33 mg alkohol (etanol) per dose. Mengden per dose av dette legemidlet tilsvarer mindre enn 0,1 ml øl eller 0,04 ml vin.<br/>Mengden alkohol i dette legemidlet er lav og vil ikke gi merkbare effekter.</div></div>"
            }
          }]
        },
        {
          "title" : "Hvordan du bruker Airomir Autohaler",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hvordan du bruker Airomir Autohaler</h2><div class=\"paragraph\">Bruk alltid dette legemidlet nøyaktig slik legen har fortalt deg. Kontakt lege eller apotek hvis du er usikker<b>. </b>Dosen bestemmes av legen som tilpasser den for deg.</div><div class=\"paragraph\">Hvis dosen som vanligvis brukes ikke virker tilfredsstillende og du/barnet ditt føler at dosen må økes for å få effekt, skal du ta kontakt med din lege. Det er viktig at dosen ikke økes på egen hånd.</div><span class=\"inline-title\">Den vanlige dosen er:</span><div class=\"paragraph\"><b>Voksne</b>: En til to inhalasjoner ved behov, opp til 3-4 ganger daglig. I alvorlige tilfeller kan dosen økes ytterligere etter avtale med lege.</div><div class=\"paragraph\"><b>Barn fra 12 år</b>: Dosering som for voksne.</div><div class=\"paragraph\"><b>Barn 4-11 år</b>: En inhalasjon ved behov, inntil 4 ganger daglig. I samråd med legen, kan dosen økes til to inhalasjoner hvis det er nødvendig.</div><div class=\"paragraph\"><b>Barn under 4 år</b>: Airomir Autohaler er ikke egnet for barn under 4 år. For yngre barn anbefales i stedet Airomir inhalasjonsaerosol sammen med et inhalasjonskammer.</div><span class=\"inline-title\">Før du bruker Airomir Autohaler første gang</span><div class=\"paragraph\">Før du bruker Airomir Autohaler første gang, trykk fire “puffer” ut i luften. Hvis du ikke har brukt legemidlet på 2 uker, gjør det samme før du tar en dose.</div><span class=\"inline-title\">Følg denne fremgangsmåten:</span><div class=\"paragraph\"><img src=\"#13935878\" alt=\"null\"/></div><div class=\"paragraph\"><ol><li>Ta av beskyttelseshetten på munnstykket ved å trekke ned flippen bak (fig 1).<br/>Rist inhalatoren et par ganger.</li><li>Hold munnstykket fra deg slik at puffet går ut i luften.<br/>Hev hendelen på toppen, slik at den står rett opp.(fig 2).</li><li>Utløs et puff ved å skyve utløseren i bunden av inhalatoren i pilens retning (mot munnstykket) (fig 3).</li><li>Slipp hendelen på toppen ned igjen (fig 4).</li></ol>Gjenta punktene 2-4 inntil 4 puff er utløst.<br/>Slipp hendelen på toppen ned, og inhalatoren er klar til bruk.<br/>Husk å sette på beskyttelseshetten etter bruk.</div><span class=\"inline-title\">Bruksanvisning</span><div class=\"paragraph\"><ol><li>Fjern beskyttelseshetten fra munnstykket og rist inhalatoren.</li><li>Hold inhalatoren som vist. Hev hendelen på toppen, slik at den står rett opp.</li><li>Pust rolig ut.</li><li>Ta munnstykket i munnen slik at leppene slutter tett om dette. Pust rolig inn. Stopp ikke når du hører et klikk og kjenner sprayen i munnen, men fortsett til lungene er fylt.</li><li>Hold pusten i ca 10 sekunder, eller så lenge som det er komfortabelt. Pust så rolig ut.</li><li>Slipp hendelen på toppen ned, og inhalatoren er klar til bruk igjen. Husk å sette på beskyttelseshetten etter bruk.</li></ol><img src=\"#13935877\" alt=\"null\"/></div><span class=\"inline-title\">Rengjøring</span><div class=\"paragraph\">For normal hygiene bør munnstykket tørkes av med en ren tørr klut.</div><div class=\"paragraph\"><b>ADVARSEL: </b>Ikke trykk noe inn i munnstykket, da dette kan ødelegge bevegelige deler i inhalatoren. Ta ikke inhalatoren i fra hverandre eller putt den i vann.</div><span class=\"inline-title\">Merk:</span><div class=\"paragraph\">Beholderen er under trykk. Den må ikke brennes eller stikkes hull på, selv når den er tom.</div><span class=\"inline-title\">Når er Airomir Autohaler tom?</span><div class=\"paragraph\">Airomir Autohaler er tom når du verken kjenner eller hører at det utløses noen dose.</div></div>"
          },
          "entry" : [{
            "reference" : "13935878"
          },
          {
            "reference" : "13935877"
          }],
          "section" : [{
            "title" : "Dersom du tar for mye av Airomir Autohaler",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029907"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dersom du tar for mye av Airomir Autohaler</h3><div class=\"paragraph\">Symptomer på for høy dose kan være uttalt hjertebank, skjelving i armer og ben, svimmelhet, hodepine og hyperglykemi.</div><div class=\"paragraph\">Spør lege eller apotek dersom du har noen spørsmål om bruken av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "Mulige bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mulige bivirkninger</h2><div class=\"paragraph\">Som alle legemidler kan dette legemidlet forårsake bivirkninger, men ikke alle får det.<br/>Bivirkninger kan forekomme med følgende hyppighet:</div><div class=\"paragraph\"><div class=\"table-wrapper\"><table cellspacing=\"0\" class=\"top left bottom right insideH insideV\"><!-- columnwidth: 50 --><col width=\"26.728913%\"/><!-- columnwidth: 50 --><col width=\"73.271085%\"/><tbody><tr><td class=\"null\"><div class=\"paragraph\">Svært vanlige</div></td><td class=\"null\"><div class=\"paragraph\">kan forekomme hos flere enn 1 av 10 brukere</div></td></tr><tr><td class=\"null\"><div class=\"paragraph\">Vanlige</div></td><td class=\"null\"><div class=\"paragraph\">kan forekomme hos opptil 1 av 10 brukere</div></td></tr><tr><td class=\"null\"><div class=\"paragraph\">Mindre vanlige</div></td><td class=\"null\"><div class=\"paragraph\">kan forekomme hos opptil 1 av 100 brukere</div></td></tr><tr><td class=\"null\"><div class=\"paragraph\">Sjeldne</div></td><td class=\"null\"><div class=\"paragraph\">kan forekomme hos opptil 1 av 1000 brukere</div></td></tr><tr><td class=\"null\"><div class=\"paragraph\">Svært sjeldne</div></td><td class=\"null\"><div class=\"paragraph\">kan forekomme hos opptil 1 av 10 000 brukere</div></td></tr><tr><td class=\"null\"><div class=\"paragraph\">Ikke kjent</div></td><td class=\"null\"><div class=\"paragraph\">hyppigheten kan ikke anslås ut ifra tilgjengelige data</div></td></tr></tbody></table></div></div><div class=\"paragraph\"><i>Vanlige:</i><ul><li>Hjertebank</li><li>Rask hjerterytme (takykardi)</li><li>Skjelving i muskulatur (tremor)</li><li>Hodepine</li><li>Svimmelhet</li></ul></div><div class=\"paragraph\"><i>Sjeldne:</i><ul><li>Reduserte nivåer av kalium i blodet (hypokalemi)</li><li>Endret adferdsmønster</li><li>Irritasjon i munn og svelg</li><li>Muskelkramper</li></ul></div><div class=\"paragraph\"><i>Svært sjeldne:</i><ul><li>Forstyrrelse av hjerterytmen (arrytmi)</li><li>Overfølsomhetsreaksjoner som hevelse i ansikt og svelg (angioødem), elveblest, pusteproblemer (sammentrekninger i bronkiene, bronkospasme), lavt blodtrykk og kollaps</li></ul></div><div class=\"paragraph\"><i>Ikke kjent:</i><ul><li>Hyperaktivitet hos barn</li><li>Problemer med å sovne</li></ul></div><div class=\"paragraph\">Selv om det ikke er kjent nøyaktig hvor ofte det inntreffer, kan noen personer av og til oppleve å få brystsmerter (på grunn av hjerteproblemer som angina). Informer legen din dersom du får slike symptomer under behandling med Airomir Autohaler<i>, </i>men avbryt ikke behandlingen uten at du har fått beskjed om å gjøre det.</div><div class=\"paragraph\">Hvis du umiddelbart etter en inhalasjon blir verre av din astma, skal du ikke ta flere inhalasjoner, men ta kontakt med din lege omgående.</div></div>"
          },
          "section" : [{
            "title" : "Melding av bivirkninger",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029912"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Melding av bivirkninger</h3><div class=\"paragraph\">Kontakt lege, apotek eller sykepleier dersom du opplever bivirkninger, inkludert mulige bivirkninger som ikke er nevnt i dette pakningsvedlegget. Du kan også melde fra om bivirkninger direkte via meldeskjema som finnes på nettsiden til Statens legemiddelverk: <a href=\"https://www.legemiddelverket.no/pasientmelding\" title=\"www.legemiddelverket.no/pasientmelding\">www.legemiddelverket.no/pasientmelding</a>. Ved å melde fra om bivirkninger bidrar du med informasjon om sikkerheten ved bruk av dette legemidlet.</div></div>"
            }
          }]
        },
        {
          "title" : "Hvordan du oppbevarer Airomir Autohaler",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Hvordan du oppbevarer Airomir Autohaler</h2><div class=\"paragraph\">Oppbevares utilgjengelig for barn.</div><div class=\"paragraph\">Bruk ikke dette legemidlet etter utløpsdatoen som er angitt på pakningen. Utløpsdatoen er den siste dagen i den angitte måneden.</div><div class=\"paragraph\">Airomir Autohaler skal oppbevares ved høyst 25ºC. Unngå å legge aerosolen direkte i solen eller i nærheten av sterk varme. Beholderen er under trykk. Stikk ikke hull på den eller brenn den, selv om den er tom.</div><div class=\"paragraph\">Legemidler skal ikke kastes i avløpsvann eller sammen med husholdningsavfall. Spør på apoteket hvordan du skal kaste legemidler som du ikke lenger bruker. Disse tiltakene bidrar til å beskytte miljøet.</div><div class=\"paragraph\">Klor-fluor-karboner (KFK) gasser har vist seg å påvirke ozonlaget i atmosfæren. Din Airomir Autohaler inhalasjonsaerosol inneholder ikke KFK-gasser, men hydro-fluor-alkan (HFA-134a) som drivgass. HFA gasser er utviklet som en erstatning for KFK, fordi de ikke har skadelige effekter på ozonlaget.<br/>Dersom du tidligere har brukt KFK-aerosol, vil du kanskje føle inhalasjonen annerledes. Dette er normalt og har ingen betydning for effekten.</div></div>"
          }
        },
        {
          "title" : "Innholdet i pakningen og ytterligere informasjon",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Innholdet i pakningen og ytterligere informasjon</h2></div>"
          },
          "section" : [{
            "title" : "Sammensetning av Airomir",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029915"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Sammensetning av Airomir</h3><div class=\"paragraph\"><ul><li>Virkestoff er salbutamolsulfat tilsvarende salbutamol 0,1 mg. Hver dose inneholder 0,1 mg salbutamol.</li><li>Andre innholdsstoffer er oljesyre, etanol og drivgass norfluran (HFA-134a, freonfri).</li></ul></div></div>"
            }
          },
          {
            "title" : "Hvordan Airomir ser ut og innholdet i pakningen",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029916"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Hvordan Airomir ser ut og innholdet i pakningen</h3><div class=\"paragraph\">Pakningen inneholder 200 doser.</div></div>"
            }
          },
          {
            "title" : "Innehaver av markedsføringstillatelsen og tilvirker",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Innehaver av markedsføringstillatelsen og tilvirker</h3><div class=\"paragraph\"><i>Innehaver av markedsføringstillatelse</i><br/>Teva Sweden AB, Box 1070, SE - 251 10 Helsingborg, Sverige</div><div class=\"paragraph\"><i>Tilvirker</i><br/>Norton (Waterford) Limited T/A Teva Pharmaceuticals Ireland<br/>Unit 27/35 IDA Industrial Park, Cork Road, Waterford, Irland</div><div class=\"paragraph\">For ytterligere opplysninger om dette legemidlet bes henvendelser rettet til det lokale informasjonskontor for innehaveren av markedsføringstillatelsen.</div><div class=\"paragraph\">Teva Norway AS<br/>Kinoveien 3A<br/>1337 Sandvika<br/>Tlf: 66 77 55 90<br/>info@tevapharm.no</div></div>"
            }
          },
          {
            "title" : "Dette pakningsvedlegget ble sist oppdatert 01.01.2021",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h3>Dette pakningsvedlegget ble sist oppdatert 01.01.2021</h3></div>"
            }
          },
          {
            "title" : "Andre informasjonskilder",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029920"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Detaljert informasjon om dette legemidlet er tilgjengelig på nettstedet til <a href=\"http://www.felleskatalogen.no/\" title=\"\n               \n                  www.felleskatalogen.no\n               \n            \">www.felleskatalogen.no</a></div></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/COPD-MPD-6",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "COPD-MPD-6",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_COPD-MPD-6\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition COPD-MPD-6</b></p><a name=\"COPD-MPD-6\"> </a><a name=\"hcCOPD-MPD-6\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_0E8C5CA3-25BE-4FC0-BAB9-3070A797BE79</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Airomir Autohaler inh aerosol, susp 0,1 mg/dose</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_0E8C5CA3-25BE-4FC0-BAB9-3070A797BE79"
      }],
      "name" : [{
        "productName" : "Airomir Autohaler inh aerosol, susp 0,1 mg/dose"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/COPD-PPD-9",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "COPD-PPD-9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_COPD-PPD-9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition COPD-PPD-9</b></p><a name=\"COPD-PPD-9\"> </a><a name=\"hcCOPD-PPD-9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_1978B8B3-6A7F-4E0B-BC10-677F0FDE0C30, <code>https://farmalogg.no/varenummer</code>/529269</p><p><b>name</b>: Airomir Autohaler inh aerosol, susp 0,1 mg/dose</p><p><b>packageFor</b>: <a href=\"Bundle-FK545806.html#MedicinalProductDefinition_COPD-MPD-6\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_0E8C5CA3-25BE-4FC0-BAB9-3070A797BE79</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_1978B8B3-6A7F-4E0B-BC10-677F0FDE0C30"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "529269"
      }],
      "name" : "Airomir Autohaler inh aerosol, susp 0,1 mg/dose",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/COPD-MPD-6"
      }]
    }
  }]
}

```
