# FK82671 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK82671**

## Example Bundle: FK82671

**Composition category:**

**Composition status:**final

### Lisätietoa

 

****Remicade 100 mg kuiva-aine välikonsentraatiksi infuusionestettä varten, liuos****
infliksimabi (infliximab.)


#### Yleisiä ohjeita

 

## Yleisiä ohjeita

**Lue tämä pakkausseloste huolellisesti ennen kuin aloitat tämän lääkkeen käyttämisen, sillä se sisältää sinulle tärkeitä tietoja.**

* Säilytä tämä pakkausseloste. Voit tarvita sitä myöhemmin.
* Lääkäri antaa sinulle myös potilaskortin, joka sisältää tärkeää turvallisuuteen liittyvää tietoa, mikä sinun tulee tietää ennen Remicade-hoidon aloitusta ja hoidon aikana.
* Jos sinulla on kysyttävää, käänny lääkärin puoleen.
* Tämä lääke on määrätty vain sinulle eikä sitä pidä antaa muiden käyttöön. Se voi aiheuttaa haittaa muille, vaikka heillä olisikin samanlaiset oireet kuin sinulla.
* Jos havaitset haittavaikutuksia, kerro niistä lääkärille. Tämä koskee myös sellaisia mahdollisia haittavaikutuksia, joita ei ole mainittu tässä pakkausselosteessa. Ks. kohta Mahdolliset haittavaikutukset.


#### Tässä pakkausselosteessa kerrotaan

 

## Tässä pakkausselosteessa kerrotaan

1. Mitä Remicade on ja mihin sitä käytetään
1. Mitä sinun on tiedettävä, ennen kuin käytät Remicade-valmistetta
1. Miten Remicade-valmistetta annetaan
1. Mahdolliset haittavaikutukset
1. Remicade-valmisteen säilyttäminen
1. Pakkauksen sisältö ja muuta tietoa


#### Mitä valmiste on ja mihin sitä käytetään

 

## Mitä valmiste on ja mihin sitä käytetään

Remicaden vaikuttava aine on infliksimabi. Infliksimabi on monoklonaalinen vasta-aine – valkuaisaineen (proteiini) tyyppi, joka kiinnittyy elimistössä tiettyyn kohteeseen, joka on nimeltään TNF (tuumorinekroositekijä) alfa.

Remicade kuuluu lääkeryhmään, jota kutsutaan nimellä TNF-salpaajat. Sitä käytetään aikuisille seuraaviin tulehduksellisiin sairauksiin:

* Nivelreuma
* Nivelpsoriaasi
* Selkärankareuma (Bechterewin tauti)
* Psoriaasi.

Remicadea käytetään myös aikuisille ja yli 6-vuotiaille lapsille seuraaviin sairauksiin:

* Crohnin tauti
* Haavainen paksusuolitulehdus.

Remicade toimii kiinnittymällä selektiivisesti tuumorinekroositekijä alfaan (TNFα) ja estämällä sen toiminnan. TNFα on mukana elimistön tulehdusprosesseissa, joten sen estäminen voi vähentää elimistössä tapahtuvia tulehduksia.

**Nivelreuma**
Nivelreuma on nivelten tulehduksellinen sairaus. Jos sinulla on aktiivinen nivelreuma, sinua hoidetaan ensin muilla lääkkeillä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea, jota otat yhdessä toisen lääkeaineen, metotreksaatin kanssa:

* vähentämään sairauden merkkejä ja oireita
* hidastamaan nivelvaurioiden syntyä
* parantamaan fyysistä suorituskykyä.

**Nivelpsoriaasi**
Nivelpsoriaasi on nivelten tulehduksellinen sairaus, johon yleensä liittyy psoriaasi. Jos sinulla on aktiivinen nivelpsoriaasi, sinua hoidetaan ensin muilla lääkkeillä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea:

* vähentämään sairauden merkkejä ja oireita
* hidastamaan nivelvaurioiden syntyä
* parantamaan fyysistä suorituskykyä.

**Selkärankareuma (Bechterewin tauti)**
Selkärankareuma on selkärangan tulehduksellinen sairaus. Jos sinulla on selkärankareuma, sinua hoidetaan ensin muilla lääkkeillä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea:

* vähentämään sairauden merkkejä ja oireita
* parantamaan fyysistä suorituskykyä.

**Psoriaasi**
Psoriaasi on ihon tulehduksellinen sairaus. Jos sinulla on kohtalainen tai vaikea plakkipsoriaasi, saat ensin muita lääkkeitä tai hoitoja kuten valohoitoa. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea vähentämään sairauden merkkejä ja oireita.

**Haavainen paksusuolitulehdus**
Haavainen paksusuolitulehdus on suoliston tulehduksellinen sairaus. Jos sinulla on haavainen paksusuolitulehdus, käytät ensin muita lääkkeitä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea sairautesi hoitoon.

**Crohnin tauti**
Crohnin tauti on suoliston tulehduksellinen sairaus. Jos sinulla on Crohnin tauti, käytät ensin muita lääkkeitä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea:

* aktiivisen Crohnin taudin hoitoon
* suolen ja ihonpinnan välisten epänormaalien avanteiden (fistelien) vähentämiseen, kun niitä ei ole saatu hallintaan muilla lääkkeillä tai leikkauksella.


#### Mitä sinun on tiedettävä ennen valmisteen käyttöä

 

## Mitä sinun on tiedettävä ennen valmisteen käyttöä

**Sinulle ei anneta Remicade-valmistetta, jos:**

* olet allerginen infliksimabille tai Remicaden jollekin muulle aineelle (lueteltu kohdassa Pakkauksen sisältö ja muuta tietoa)
* olet allerginen (yliherkkä) hiiristä peräisin oleville valkuaisaineille
* sinulla on tuberkuloosi tai muu vakava infektio kuten keuhkokuume tai verenmyrkytys (sepsis)
* sinulla on kohtalainen tai vaikea sydämen vajaatoiminta.

Älä käytä Remicadea, jos jokin yllä olevista koskee sinua. Jos et ole varma, keskustele lääkärin kanssa ennen kuin saat Remicadea.

**Varoitukset ja varotoimet**
Keskustele lääkärin kanssa ennen kuin saat Remicade-valmistetta tai Remicade-hoidon aikana, jos:

Olet saanut Remicade-hoitoa aiemmin

* Kerro lääkärille, jos olet saanut Remicade-hoitoa aiemmin ja olet nyt aloittamassa hoidon uudelleen.
Jos Remicade-hoidossasi on ollut yli 16 viikon tauko, allergisten reaktioiden riski on suurempi, kun hoitosi aloitetaan uudelleen.

Infektiot

* Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on jokin infektio, vaikka se olisi hyvin vähäinen.
* Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos olet joskus asunut tai matkustanut alueilla, joilla histoplasmoosi-, kokkidioidomykoosi- tai blastomykoosi-infektiot ovat yleisiä. Näitä infektioita aiheuttavat tietyntyyppiset sienet, jotka voivat olla haitallisia keuhkoille tai elimistön muille osille.
* Saatat saada infektioita helpommin, kun sinua hoidetaan Remicade-valmisteella. Jos olet 65-vuotias tai vanhempi, riski on suurempi.
* Nämä infektiot saattavat olla vakavia ja niitä ovat tuberkuloosi, virusten, sienten, bakteerien tai muiden luonnossa olevien organismien aiheuttamat infektiot sekä verenmyrkytys (sepsis), joka voi olla hengenvaarallinen.

Kerro lääkärille heti, jos saat infektion merkkejä Remicade-hoidon aikana. Merkkeihin kuuluvat kuume, yskä, flunssan kaltaiset oireet, huonovointisuus, punainen tai kuuma iho, haavat ja hammasongelmat. Lääkäri saattaa suositella Remicade-hoidon väliaikaista lopettamista.

Tuberkuloosi

* On erittäin tärkeää, että kerrot lääkärille, jos sinulla on joskus ollut tuberkuloosi tai jos olet ollut läheisessä kontaktissa henkilön kanssa, jolla on ollut tai on tuberkuloosi.
* Lääkäri tekee sinulle kokeita, joiden avulla nähdään, onko sinulla tuberkuloosi. Tuberkuloosia on raportoitu Remicade-hoitoa saaneilla potilailla, myös potilailla, jotka ovat jo saaneet tuberkuloosilääkkeitä. Lääkäri kirjaa tuberkuloositestien tulokset potilaskorttiisi.
* Jos lääkärin mielestä sinulla on tuberkuloosin riski, sinua voidaan hoitaa tuberkuloosilääkkeillä ennen kuin saat Remicade-valmistetta.

Kerro lääkärille heti, jos saat tuberkuloosin merkkejä Remicade-hoidon aikana. Merkkeihin kuuluvat itsepintainen yskä, painon aleneminen, väsymyksen tunne, kuume, yöhikoilu.

B-hepatiittivirus

* Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos olet hepatiitti B-viruksen kantaja tai sinulla on tai on joskus ollut B-hepatiitti.
* Kerro lääkärille, jos uskot olevasi vaarassa sairastua B-hepatiittiin.
* Lääkäri tekee sinulle B-hepatiittitestin.
* Hoito TNF-salpaajilla kuten Remicade-valmisteella saattaa johtaa B-hepatiittiviruksen palautumiseen aktiiviseksi potilailla, jotka kantavat tätä virusta. Tämä saattaa toisinaan olla hengenvaarallista.

Sydänongelmat

* Kerro lääkärille, jos sinulla on sydänongelmia kuten lievä sydämen vajaatoiminta.
* Lääkäri saattaa haluta tarkkailla sydäntäsi.

Kerro lääkärille heti, jos saat Remicade-hoidon aikana uusia sydämen vajaatoiminnan merkkejä tai ne pahenevat. Merkkeihin kuuluvat hengästyneisyys tai jalkojen turvotus.

Syöpä ja lymfooma

* Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on tai on joskus ollut lymfooma (eräänlainen verisyöpä) tai jokin muu syöpä.
* Potilailla, joilla on vaikea nivelreuma ja joilla tauti on ollut kauan, saattaa lymfooman kehittymisen riski olla suurempi.
* Remicadea käyttävillä lapsilla ja aikuisilla lymfooman tai muun syövän kehittymisen riski saattaa suurentua.
* Joillekin potilaista, joita on hoidettu TNF-salpaajalla, mukaan lukien Remicade-valmisteella, on kehittynyt harvinainen syöpä, jota kutsutaan hepatospleeniseksi T-solulymfoomaksi. Useimmat näistä potilaista olivat teini-ikäisiä poikia tai nuoria miehiä ja useimmilla heistä oli joko Crohnin tauti tai haavainen paksusuolitulehdus. Tämän tyyppinen syöpä on tavallisimmin johtanut kuolemaan. Lähes kaikki potilaat olivat saaneet myös atsatiopriinia tai 6-merkaptopuriinia sisältäviä lääkkeitä TNF-salpaajan lisäksi.
* Joillekin infliksimabihoitoa saaneille potilaille on kehittynyt tietynlaisia ihosyöpiä. Jos havaitset mitä tahansa muutoksia ihossasi tai kasvaimia ihossa hoidon aikana tai sen jälkeen, kerro asiasta lääkärille.
* Joillekin naisille, jotka ovat saaneet Remicade-valmistetta nivelreuman hoitoon, on kehittynyt kohdunkaulan syöpä. Remicade-valmistetta saaville naisille, mukaan lukien yli 60-vuotiaille, lääkäri voi suositella säännöllisiä kohdunkaulan syövän seulontatutkimuksia.

Keuhkosairaus tai runsas tupakointi

* Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on keuhkosairaus nimeltä pitkäaikainen ahtauttava keuhkosairaus (keuhkoahtaumatauti, COPD) tai jos tupakoit runsaasti.
* Potilailla, joilla on COPD tai jotka tupakoivat runsaasti, syövän kehittymisen riski saattaa lisääntyä Remicade-hoidon aikana.

Hermoston sairaus

* Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on tai on joskus ollut hermostoon vaikuttavia ongelmia. Näitä ovat MS-tauti (multippeli skleroosi), Guillain-Barrén oireyhtymä, jos sinulla on kouristuskohtauksia tai jos sinulla on todettu näköhermon tulehdus (optinen neuriitti).

Kerro lääkärille heti, jos saat hermoston sairauksien oireita Remicade-hoidon aikana. Tällaisia oireita ovat näkökyvyn muutos, käsien tai jalkojen heikkous, puutumisen tai pistelyn tunne kehossa.

Epänormaalit ihon avanteet

* Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on epänormaaleja ihon avanteita (fisteleitä).

Rokotukset

* Kerro lääkärille, jos olet hiljattain saanut rokotuksen tai sinulle on suunniteltu annettavan rokotus.
* Sinun pitää saada suositellut rokotukset ennen Remicade-hoidon aloittamista. Voit saada joitakin rokotteita Remicade-hoidon aikana, mutta sinulle ei saa antaa eläviä rokotteita (rokotteet, jotka sisältävät eläviä, mutta heikennettyjä taudinaiheuttajia), koska ne voivat aiheuttaa infektioita.
* Jos sait Remicade-valmistetta raskauden aikana, myös lapsellasi saattaa olla suurentunut eläviin rokotteisiin liittyvä infektioriski ensimmäisen elinvuoden ajan. On tärkeää, että kerrot lastasi hoitavalle lääkärille ja muille terveydenhuollon ammattilaisille Remicade-hoidostasi, jotta he voivat päättää, milloin lapsesi voi saada jonkin rokotuksen, mukaan lukien elävät rokotteet kuten BCG -rokote (käytetään tuberkuloosin ehkäisyyn).
* Jos imetät, on tärkeää että kerrot lapsesi hoitavalle lääkärille ja muille terveydenhuollon ammattilaisille Remicade-hoidostasi, ennen kuin lapsellesi annetaan jokin rokotus. Katso lisätietoja kohdasta Raskaus ja imetys.

Hoidolliset tartunnanaiheuttajat

* Kerro lääkärille, jos olet hiljattain saanut tai sinulle on suunniteltu annettavan hoitoa hoidollisella tartunnanaiheuttajalla (kuten BCG-rokote instillaationa syövän hoitoon).

Leikkaukset tai hammastoimenpiteet

* Kerro lääkärille, jos olet menossa johonkin leikkaukseen tai hammastoimenpiteeseen.
* Kerro kirurgille tai hammaslääkärille, että saat Remicade-hoitoa ja näytä hänelle potilaskorttisi.

Maksaongelmat

* Joillekin Remicade-hoitoa saaville potilaille on kehittynyt vakavia maksaongelmia.

Kerro lääkärillesi välittömästi, jos sinulle ilmaantuu Remicade-hoidon aikana maksaongelmien oireita. Merkkejä ovat ihon ja silmien keltaisuus, virtsan värjäytyminen tummanruskeaksi, kipu tai turvotus oikealla ylävatsalla, nivelkipu, ihottuma tai kuume.

Alhaiset verisolujen määrät

* Joidenkin Remicade-valmistetta saavien potilaiden elimistö ei tuota riittävästi verisoluja, jotka auttavat taistelemaan infektioita vastaan tai lopettamaan verenvuodon.

Kerro lääkärillesi välittömästi, jos sinulle ilmaantuu Remicade-hoidon aikana oireita alhaisesta verisolujen määrästä. Merkkejä ovat itsepintainen kuume, herkästi syntyvät mustelmat tai verenvuoto, ihonalaisen verenvuodon aiheuttamat pienet punaiset tai violetit pisteet iholla tai ihon kalpeus.

Immuunijärjestelmän häiriö t

* Joillekin Remicade-valmistetta saaville potilaille on kehittynyt lupus-nimisen immuunijärjestelmän häiriön oireita.

Kerro lääkärillesi välittömästi, jos sinulle ilmaantuu lupuksen oireita Remicade-hoidon aikana. Merkkejä ovat nivelkipu tai auringolle herkkä ihottuma poskilla tai käsivarsilla.

**Lapset ja nuoret**
Yllä olevat tiedot koskevat myös lapsia ja nuoria. Tämän lisäksi:

* Joillain TNF-estäjiä kuten Remicade-valmistetta saaneilla lapsilla ja teini-ikäisillä potilailla on esiintynyt syöpätapauksia, mukaan lukien harvinaisia syöpätyyppejä. Ne ovat toisinaan johtaneet kuolemaan.
* Remicade-valmistetta saaneille lapsille kehittyi infektioita useammin kuin aikuisille.
* Lasten pitää saada suositusten mukaiset rokotukset ennen Remicade-hoidon aloitusta. Lapsille voidaan antaa joitakin rokotteita Remicade-hoidon aikana, mutta heille ei saa antaa eläviä rokotteita Remicade-hoidon aikana.

Mikäli et ole varma, koskeeko jokin yllä olevista sinua, keskustele lääkärin kanssa ennen kuin saat Remicade-valmistetta.

**Muut lääkevalmisteet ja Remicade**
Potilaat, joilla on jokin tulehduksellinen sairaus, käyttävät valmiiksi lääkevalmisteita sairautensa hoitoon. Nämä lääkevalmisteet saattavat aiheuttaa haittavaikutuksia. Lääkäri neuvoo, mitä muita lääkkeitä sinun tulee edelleen käyttää Remicade-hoidon aikana.

Kerro lääkärille, jos parhaillaan käytät tai olet äskettäin käyttänyt muita lääkkeitä, myös muita lääkkeitä Crohnin taudin, haavaisen paksusuolitulehduksen, nivelreuman, selkärankareuman, nivelpsoriaasin tai psoriaasin hoitoon tai lääkkeitä, joita lääkäri ei ole määrännyt kuten vitamiineja tai rohdosvalmisteita.

Erityisesti kerro lääkärille, jos käytät jotain seuraavista lääkkeistä:

* Lääkkeitä, jotka vaikuttavat immuunijärjestelmään.
* Kineret (anakinra). Remicadea ja Kineret-valmistetta ei pidä käyttää samanaikaisesti.
* Orencia (abatasepti). Remicadea ja Orenciaa ei pidä käyttää samanaikaisesti.

Sinulle ei saa antaa eläviä roketteita Remicade-hoidon aikana. Jos sait Remicade-hoitoa raskauden aikana tai jos saat Remicade-hoitoa imetyksen aikana, kerro lastasi hoitavalle lääkärille ja muille terveydenhuollon ammatilaisille Remicade- hoidostasi, ennen kuin lapsesi saa mitään rokotteita.

Mikäli et ole varma, koskeeko jokin yllä olevista sinua, keskustele lääkärin tai apteekkihenkilökunnan kanssa ennen Remicade-valmisteen käyttöä.

**Raskaus, imetys ja hedelmällisyys**

* Jos olet raskaana tai imetät, epäilet olevasi raskaana tai jos suunnittelet lapsen hankkimista, kysy lääkäriltä neuvoa ennen tämän lääkkeen käyttöä. Remicadea tulee käyttää raskauden tai imetyksen aikana vain, jos se lääkärin mielestä on välttämätöntä.
* Sinun tulee välttää raskaaksi tuloa Remicade-hoidon aikana ja 6 kuukautta hoidon lopettamisen jälkeen. Keskustele lääkärin kanssa ehkäisyn käytöstä tuona aikana.
* Jos sait Remicadea raskauden aikana, lapsellasi saattaa olla suurentunut infektioriski.
* On tärkeää, että kerrot lastasi hoitavalle lääkärille ja muille terveydenhuollon ammattilaisille Remicade-hoidostasi ennen kuin lapsellesi annetaan jokin rokotus. Jos sait Remicade-hoitoa raskauden aikana, BCG-rokotteen (käytetään tuberkuloosin ehkäisyyn) antaminen lapsellesi 12 kuukauden aikana syntymän jälkeen voi aiheuttaa infektion, jolla saattaa olla vakavia, jopa kuolemaan johtavia komplikaatioita. Eläviä rokotteita, kuten BCG-rokotetta, ei saa antaa lapsellesi 12 kuukauteen syntymän jälkeen ellei lastasi hoitava lääkäri toisin suosittele . Katso lisätietoja kohdasta Rokotukset.
* Jos imetät, on tärkeää että kerrot lapsesi hoitavalle lääkärille ja muille terveydenhuollon ammattilaisille Remicade-hoidostasi, ennen kuin lapsellesi annetaan jokin rokotus. Eläviä rokotteita ei tule antaa lapsellesi imetyksen aikana ellei lastasi hoitava lääkäri toisin suosittele.
* Remicade-hoitoa raskauden aikana saaneiden naisten imeväisikäisillä lapsilla on raportoitu voimakkaasti alentuneita valkosolujen määriä. Jos lapsellasi on jatkuvaa kuumeilua tai infektioita, ota heti yhteyttä lastasi hoitavaan lääkäriin.

**Ajaminen ja koneiden käyttö**
Remicaden ei oleteta vaikuttavan ajokykyyn tai kykyyn käyttää koneita. Jos tunnet olevasi väsynyt, sinua huimaa tai olet huonovointinen saatuasi Remicadea, älä aja tai käytä mitään työvälineitä tai koneita.

**Remicade sisältää natriumia**
Remicade sisältää alle 1 mmol natriumia (23 mg) per annos eli se on käytännössä natriumiton. Ennen kuin Remicade annetaan, se kuitenkin sekoitetaan natriumia sisältävään liuokseen. Keskustele lääkärin kanssa, jos noudatat vähäsuolaista ruokavaliota.


#### Miten valmistetta käytetään

 

## Miten valmistetta käytetään

**Nivelreuma**
Tavanomainen annos on 3 mg painokiloa kohti.

**Nivelpsoriaasi, selkärankareuma (Bechterewin tauti), psoriaasi, haavainen paksusuolitulehdus ja Crohnin tauti**
Tavanomainen annos on 5 mg painokiloa kohti.

**Miten Remicadea annetaan**

* Lääkäri tai hoitaja antaa sinulle Remicade-valmisteen.
* Lääkäri tai hoitaja valmistaa lääkkeen infuusiota varten.
* Lääke annetaan infuusiona (tiputus) (2 tunnin aikana) laskimoon, yleensä käsivarteen. Kolmannen hoitokerran jälkeen lääkäri voi päättää, että saat Remicade-annoksen 1 tunnin aikana.
* Vointiasi tarkkaillaan Remicade-tiputuksen aikana ja vielä 1-2 tunnin ajan sen jälkeen.

**Kuinka paljon Remicade-valmistetta annetaan**

* Lääkäri päättää saamasi annoksen suuruuden ja kuinka usein Remicade-valmistetta sinulle annetaan. Tämä riippuu sairaudestasi, painostasi ja siitä, miten Remicade-hoito sinuun vaikuttaa.
* Alla olevasta taulukosta näet, miten usein tätä lääkettä yleensä annetaan ensimmäisen annoksen jälkeen.

| | |
| :--- | :--- |
| 2. annos | 2 viikkoa 1. annoksen jälkeen |
| 3. annos | 6 viikkoa 1. annoksen jälkeen |
| Myöhemmät annokset | 6-8 viikon välein riippuen sairaudestasi |

**Käyttö lapsille ja nuorille**
Remicade-valmistetta annetaan lapsille vain Crohnin taudin tai haavaisen paksusuolitulehduksen hoitoon. Näiden lasten pitää olla 6 vuotta täyttäneitä.

**Jos saat enemmän Remicade-valmistetta kuin sinun pitäisi**
Lääkäri tai hoitaja antaa sinulle tämän lääkevalmisteen. Siksi on epätodennäköistä, että saisit sitä enemmän kuin pitäisi. Liian suuren Remicade-annoksen ei tiedetä aiheuttaneen haittavaikutuksia.

**Jos unohdat tai jäät vaille Remicade-infuusiota**
Jos unohdat tai myöhästyt vastaanottokäynniltä, jolla oli tarkoitus saada Remicade-valmistetta, sovi uusi aika mahdollisimman pian.

Jos sinulla on kysymyksiä tämän lääkkeen käytöstä, käänny lääkärin puoleen.


#### Mahdolliset haittavaikutukset

 

## Mahdolliset haittavaikutukset

Kuten kaikki lääkkeet, tämäkin lääke voi aiheuttaa haittavaikutuksia. Kaikki eivät kuitenkaan niitä saa. Useimmat haittavaikutukset ovat lieviä tai kohtalaisia vaikeusasteeltaan. Joillain potilailla haittavaikutukset kuitenkin voivat olla vakavia ja vaatia hoitoa. Haittavaikutuksia voi ilmaantua myös Remicade-lääkityksen lopettamisen jälkeen.

**Kerro välittömästi lääkärille, jos huomaat jotain seuraavista:**

* **Merkkejä allergisesta reaktiosta** kuten kasvojen, huulten, suun tai kurkun turvotus, mikä saattaa vaikeuttaa nielemistä tai hengitystä, ihottuma, nokkosrokko, käsien, jalkojen tai nilkkojen turvotus. Jotkut näistä reaktioista voivat olla vakavia tai hengenvaarallisia. Allerginen reaktio voi ilmaantua 2 tunnin kuluessa tiputuksesta tai myöhemmin. Muita oireita, jotka voivat olla merkkejä allergisista reaktioista, joita saattaa esiintyä jopa 12 päivän kuluttua tiputuksesta, ovat lihaskipu, kuume, kipu nivelissä tai leukapielissä, kurkkukipu tai päänsärky.
* **Merkkejä sydänongelmasta** kuten rintatuntemus tai rintakipu, käsivarren kipu, mahakipu, hengenahdistus, ahdistuneisuus, heikotuksen tunne, huimaus, pyörtyminen, hikoilu, huonovointisuus (pahoinvointi), oksentaminen, sydämen tykytys tai hakkaaminen, nopea tai hidas sydämensyke ja jalkojen turvotus.
* **Merkkejä infektiosta (mukaan lukien tuberkuloosi)** kuten kuume, väsymyksen tunne, yskä, joka voi jatkua pitkään, hengenahdistus, flunssan kaltaiset oireet, painon aleneminen, yöhikoilu, ripuli, haavat, märkäkertymä (paise) suolistossa tai peräaukon ympärillä, hammasongelmat tai kirvelevä tunne virtsatessa.
* **Mahdollisia merkkejä syövästä, **mukaan lukien mutta rajoittumatta: imusolmukkeiden turvotus, painon lasku, kuume, epätavalliset ihokyhmyt, muutokset luomissa tai ihon värissä tai epätavallinen emätinverenvuoto.
* **Merkkejä keuhko-ongelmasta** kuten yskä, hengitysvaikeudet tai ahdistava tunne rinnassa.
* **Merkkejä hermoston ongelmasta (mukaan lukien silmäongelmat)** kuten aivohalvauksen merkit (äkillinen kasvojen, käsien tai jalkojen puutuminen tai voimattomuus, etenkin toisella puolella kehoa; äkillinen sekavuus, puhe- tai ymmärtämisvaikeudet; näköhäiriöt toisessa tai molemmissa silmissä, kävelemisvaikeudet, heitehuimaus, tasapainon tai koordinaatiokyvyn menettäminen tai voimakas päänsärky), kouristuskohtaukset, pistely/puutuminen jossain kehon osassa tai käsien tai jalkojen voimattomuus, muutokset näkökyvyssä kuten kahtena näkeminen tai muut silmäongelmat.
* **Merkkejä maksaongelmasta** (mukaan lukien B-hepatiitti-infektio, jos sinulla on aiemmin ollut B-hepatiitti) kuten ihon tai silmien keltaisuus, virtsan värjäytyminen tummanruskeaksi, kipua tai turvotusta oikealla ylävatsalla, nivelkipu, ihottumat tai kuume.
* **Merkkejä immuunijärjestelmän sairaudesta,** kuten nivelkipua tai auringolle herkkää ihottumaa poskilla tai käsissä (lupus) tai yskää, hengenahdistusta, kuumetta tai ihottumaa (sarkoidoosi).
* **Merkkejä alhaisista verisolujen määristä** kuten itsepintainen kuume, herkästi tuleva verenvuoto tai mustelmat, ihonalaisesta verenvuodosta johtuvat pienet punaiset tai violetit pisteet iholla tai ihon kalpeus.
* **Merkkejä vakavista iho-ongelmista** kuten vartalolla punoittavat kokardimaiset pilkut tai pyöreät laikut, joiden keskellä on usein rakkula, laaja-alainen ihon kuoriutuminen ja irtoaminen (kesiminen), haavaumat suussa, kurkussa, nenässä, sukupuolielimissä ja silmissä tai pienet märkäiset paukamat, jotka voivat levitä ympäri kehoa. Näiden ihoreaktioiden yhteydessä voi ilmetä kuumetta.

Kerro lääkärille heti, jos huomaat jotain yllä mainituista.

Seuraavia haittavaikutuksia on havaittu Remicaden käytön yhteydessä:

**Hyvin yleisiä: useammin kuin yli 1 potilaalla kymmenestä**

* vatsakipu, huonovointisuus
* virusinfektiot kuten herpes tai flunssa
* ylähengitystieinfektiot kuten sinuiitti
* päänsärky
* infuusion aiheuttama haittavaikutus
* kipu.

**Yleisiä: harvemmin kuin 1 potilaalla kymmenestä**

* muutokset maksan toiminnassa, maksaentsyymien kohoaminen (näkyy verikokeissa)
* infektio keuhkoissa tai rinnassa kuten keuhkoputkitulehdus tai keuhkokuume
* hengitysvaikeudet, rintakipu
* verenvuoto vatsassa tai suolistossa, ripuli, ruoansulatushäiriö, närästys, ummetus
* nokkosrokko, kutiseva ihottuma tai kuiva iho
* tasapaino-ongelmat tai huimauksen tunne
* kuume, lisääntynyt hikoilu
* verenkierto-ongelmat kuten matala tai korkea verenpaine
* mustelmat, kuumat aallot tai nenäverenvuoto, kuuma, punoittava iho (punastuminen)
* väsymyksen tai heikkouden tunne
* bakteeri-infektiot kuten verenmyrkytys, absessi (märkäpesäke) tai infektio ihon alla (selluliitti)
* sienen aiheuttama ihoinfektio
* veriongelmat kuten anemia tai valkosolujen vähyys
* turvonneet imusolmukkeet
* masennus, univaikeudet
* silmäongelmat mukaan lukien silmien punoitus ja infektiot
* sydämen nopealyöntisyys (takykardia) tai sydämentykytys
* kipu nivelissä, lihaksissa tai selässä
* virtsatieinfektio
* psoriaasi, iho-ongelmat kuten ihottuma ja hiusten lähtö
* pistokohdan reaktiot kuten kipu, turvotus, punoitus tai kutina
* vilunväreet, nesteen kertyminen ihon alle turvotusta aiheuttaen
* tunnottomuus tai pistelyn tunne.

**Melko harvinaisia: harvemmin kuin 1 potilaalla sadasta**

* riittämätön verensaanti, verisuonien turpoaminen
* veren kerääntyminen verisuonien ulkopuolelle (hematooma) tai mustelmat
* iho-ongelmat kuten rakkulat, syylät, epänormaali ihon värjäytyminen tai pigmentaatio, tai huulten turvotus tai ihon paksuuntuminen tai punainen, hilseilevä ja hiutaleinen iho
* vakavat allergiset reaktiot (esim. anafylaksi), immuunijärjestelmän sairaus nimeltään lupus, yliherkkyysreaktiot vieraita valkuaisaineita kohtaan
* haavojen hitaampi paraneminen
* maksan suurentuminen (hepatiitti) tai sappirakon turvotus, maksavaurio
* muistamattomuus, ärtyisyys, sekavuus, hermostuneisuus
* silmäongelmat mukaan lukien näön sumentuminen tai heikentyminen, silmien turvotus tai näärännäpyt
* sydämen vajaatoiminnan puhkeaminen tai paheneminen, hidas sydämen syke
* pyörtyminen
* kouristukset, hermo-ongelmat
* reikä suolessa tai suolen tukkeuma, vatsakipu tai krampit
* haiman turpoaminen (haimatulehdus)
* sieni-infektiot kuten hiivainfektio tai kynsien sieni-infektio
* keuhko-ongelmat (kuten turvotus)
* nesteen purkautuminen keuhkopussiin
* hengitysteiden ahtaus keuhkoissa, joka aiheuttaa hengitysvaikeuksia
* keuhkopussin tulehtumisen aiheuttama terävä rintakipu, joka tuntuu pahemmalta hengitettäessä (keuhkopussintulehdus)
* tuberkuloosi
* munuaisinfektiot
* verihiutaleiden vähyys, valkosolujen ylimäärä
* emättimen infektiot
* veriarvojen tulokset, jotka osoittavat vasta-aineita omaa elimistöä vastaan
* muutokset veren kolesteroli- ja rasva-arvoissa.

**Harvinaisia: harvemmin kuin 1 potilaalla tuhannesta**

* tietyntyyppinen verisyöpä (lymfooma)
* veri ei kuljeta riittävästi happea elimistölle, verenkierto-ongelmat kuten verisuonien kaventuminen
* aivokalvotulehdus (meningiitti)
* infektiot, jotka johtuvat heikentyneestä immuunijärjestelmästä
* B-hepatiitti-infektio, kun sinulla on aiemmin ollut B-hepatiitti
* maksatulehdus, joka johtuu ongelmasta immuunijärjestelmässä (autoimmuunihepatiitti)
* maksaongelma, joka aiheuttaa ihon tai silmien keltaisuutta (keltatauti)
* epänormaali kudosten turvotus tai kasvu
* vakava allerginen reaktio, joka voi aiheuttaa tajuttomuutta ja voi olla hengenvaarallinen (anafylaktinen sokki)
* pienten verisuonien turpoaminen (verisuonitulehdus)
* immuunihäiriöt, jotka voivat vaikuttaa keuhkoihin, ihoon tai imusolmukkeisiin (kuten sarkoidoosi)
* tulehdusvasteesta johtuvat immuunijärjestestelmän solujen paikalliset kertymät (granulomatoottiset leesiot)
* kiinnostuksen tai tunteiden puute
* vakavat iho-ongelmat kuten toksinen epidermaalinen nekrolyysi, Stevens-Johnsonin oireyhtymä ja akuutti yleistynyt eksantematoottinen pustuloosi
* muut iho-ongelmat kuten erythema multiforme, jäkälää muistuttavat reaktiot (kutiseva, punertavanvioletti ihottuma ja/tai säiemäisiä valkoisenharmaita viivoja limakalvoilla), rakkulat ja ihon kuoriutuminen tai paiseet (paisetauti)
* vakavat hermoston sairaudet kuten selkäytimen poikittaistulehdus, MS-taudin kaltainen sairaus, optinen neuriitti ja Guillain-Barrén oireyhtymä
* silmätulehdus, joka voi aiheuttaa näkökyvyn muutoksia, mukaan lukien sokeutta
* nesteen purkautuminen sydänpussiin
* vakavat keuhko-ongelmat (kuten interstitiaali keuhkosairaus)
* melanooma (ihosyöpätyyppi)
* kohdunkaulan syöpä
* alhaiset veriarvot, mukaan lukien voimakkaasti alentunut valkosolujen määrä
* pienet punaiset tai violetit pisteet ihon alla (ihonalaisen verenvuodon aiheuttamat)
* immuunijärjestelmään kuuluvan komplementtitekijä-nimisen veren proteiinin poikkeavat arvot.

**Tuntemattomia: koska saatavissa oleva tieto ei riitä esiintyvyyden arviointiin**

* syöpä lapsilla ja aikuisilla
* harvinainen verisyöpä, joka esiintyy useimmiten teini-ikäisillä pojilla tai nuorilla miehillä (hepatospleeninen T-solulymfooma)
* maksan vajaatoiminta
* merkelinsolusyöpä (ihosyöpätyyppi)
* Kaposin sarkooma, harvinainen syöpä, joka liittyy ihmisen herpesvirus 8 -infektioon. Kaposin sarkooma ilmenee yleisimmin sinipunaisina ihovaurioina.
* dermatomyosiitti-nimisen sairauden paheneminen (havaitaan lihasheikkoutena, johon liittyy ihottumaa)
* sydänkohtaus
* aivohalvaus
* ohimenevä näkökyvyn menetys infuusion aikana tai 2 tunnin kuluessa infuusiosta
* elävästä rokotteesta johtuva infektio heikentyneen immuunijärjestelmän takia.

**Muut haittavaikutukset lapsilla ja nuorilla**
Remicadea Crohnin tautiin saaneilla lapsilla havaittiin haittavaikutuksissa eroja verrattuna Remicadea Crohnin tautiin saaneisiin aikuisiin. Lapsilla havaittiin enemmän seuraavia haittavaikutuksia: alhainen punasolujen määrä (anemia), verta ulosteessa, alhainen valkosolujen kokonaismäärä (leukopenia), punastuminen, virusinfektiot, alhainen infektioita vastaan taistelevien valkosolujen määrä (neutropenia), luunmurtuma, bakteeri-infektio ja hengityselinten allerginen reaktio.

**Haittavaikutuksista ilmoittaminen**
Jos havaitset haittavaikutuksia, kerro niistä lääkärille, apteekkihenkilökunnalle tai sairaanhoitajalle. Tämä koskee myös sellaisia mahdollisia haittavaikutuksia, joita ei ole mainittu tässä pakkausselosteessa. Voit ilmoittaa haittavaikutuksista myös suoraan (ks. yhteystiedot alla). Ilmoittamalla haittavaikutuksista voit auttaa saamaan enemmän tietoa tämän lääkevalmisteen turvallisuudesta.

www-sivusto: www.fimea.fi
Lääkealan turvallisuus- ja kehittämiskeskus Fimea
Lääkkeiden haittavaikutusrekisteri
PL 55
00034 FIMEA


#### Valmisteen säilyttäminen

 

## Valmisteen säilyttäminen

Terveydenhoidon ammattilaiset huolehtivat yleensä Remicade-valmisteen säilyttämisestä. Seuraavassa ovat säilytysohjeet, mikäli tarvitset niitä:

* Ei lasten ulottuville eikä näkyville.
* Älä käytä tätä lääkettä etiketissä ja kotelossa mainitun viimeisen käyttöpäivämäärän (EXP) jälkeen. Viimeinen käyttöpäivämäärä tarkoittaa kuukauden viimeistä päivää.
* Säilytä jääkaapissa (2°C−8 °C).
* Tätä lääkettä voi myös säilyttää alkuperäisessä kotelossa poissa jääkaapista, alle 25 ºC:ssa, yhden enintään kuuden kuukauden pituisen jakson ajan. Säilytys ei saa kuitenkaan ylittää alkuperäistä viimeistä käyttöpäivämäärää. Tällöin sitä ei saa laittaa enää takaisin jääkaappisäilytykseen. Uusi viimeinen käyttöpäivämäärä kirjoitetaan koteloon muodossa pv/kk/vuosi. Lääke on hävitettävä, jos sitä ei käytetä ennen uutta viimeistä käyttöpäivämäärää tai koteloon painettua alkuperäistä viimeistä käyttöpäivämäärää, kumpi tahansa on aikaisempi.
* On suositeltavaa, että käyttövalmis Remicade-infuusioliuos käytetään mahdollisimman pian (3 tunnin kuluessa). Jos liuos valmistetaan kuitenkin aseptisissa olosuhteissa, sitä voidaan säilyttää enintään 28 päivää jääkaapissa 2°C–8°C:ssa ja lisäksi 24 tuntia 25°C:ssa jääkaapista ottamisen jälkeen.
* Älä käytä tätä lääkettä, jos se on värjääntynyt tai sisältää vieraita hiukkasia.


#### Pakkauksen sisältö ja muuta tietoa

 

## Pakkauksen sisältö ja muuta tietoa

**Mitä Remicade sisältää**

* Vaikuttava aine on infliksimabi. Yksi injektiopullo sisältää 100 mg infliksimabia. Liuottamisen jälkeen yksi millilitra sisältää 10 mg infliksimabia.
* Muut aineet ovat sakkaroosi, polysorbaatti 80, mononatriumfosfaatti ja dinatriumfosfaatti.

**Lääkevalmisteen kuvaus ja pakkauskoot**
Remicade kuiva-aine välikonsentraatiksi infuusionestettä varten, liuos on pakattu lasiseen injektiopulloon. Kuiva-aine on kylmäkuivattu, valkoinen pelletti.
Remicade on saatavana 1, 2, 3, 4 tai 5 injektiopullon pakkauksina. Kaikkia pakkauskokoja ei välttämättä ole myynnissä.

**Myyntiluvan haltija ja valmistaja**
Janssen Biologics B.V.
Einsteinweg 101
2333 CB Leiden
Alankomaat

Lisätietoja tästä lääkevalmisteesta antaa myyntiluvan haltijan paikallinen edustaja:

**Suomi/Finland**
MSD Finland Oy
Puh/Tel: +358 (0)9 804 650
info@msd.fi

**Tämä pakkausseloste on tarkistettu viimeksi 09/2022**

**Muut tiedonlähteet**
Lisätietoa tästä lääkevalmisteesta on saatavilla Euroopan lääkeviraston verkkosivulla http://www.ema.europa.eu/.


####  Remicade pulv til kons til inf væske, oppl 100 mg 
LEGEMIDDELMERKEVAREID:
** ID_D50B98BD-030D-461D-A35D-17E101E1396B **
-------

Full name: **Remicade pulv til kons til inf væske, oppl 100 mg**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 2

LEGEMIDDELPAKNINGID: ** ID_359EDC49-19B2-4933-84B2-61F473D0A002 ** 

VARENUMMER: ** 063187 ** 

VNR: ** 063187 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:

 Package 2 of 2

LEGEMIDDELPAKNINGID: ** ID_C204F161-C434-4A8C-83E0-4152B0FABFCE ** 

VARENUMMER: ** 575787 ** 

VNR: ** 575787 ** 

Description:

## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK82671",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "fi",
  "identifier" : {
    "system" : "https://pharmaca.fi/documentId",
    "value" : "82671"
  },
  "type" : "document",
  "timestamp" : "2023-01-01T01:17:17Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK82671-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK82671-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "fi",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fi\" lang=\"fi\"><a name=\"Composition_FK82671-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK82671-COMP</b></p><a name=\"FK82671-COMP\"> </a><a name=\"hcFK82671-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: fi</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://pharmaca.fi/documentId</code>/82671</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2023-01-01 01:17:17+0000</p><p><b>author</b>: Identifier: <code>https://gravitatehealth.eu/organization</code>/Pharmaca Health Intelligence Oy</p><p><b>title</b>: REMICADE kuiva-aine välikonsentraatiksi infuusionestettä varten, liuos 100 mg</p></div>"
      },
      "identifier" : [{
        "system" : "https://pharmaca.fi/documentId",
        "value" : "82671"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-21"
      }],
      "date" : "2023-01-01T01:17:17Z",
      "author" : [{
        "identifier" : {
          "system" : "https://gravitatehealth.eu/organization",
          "value" : "Pharmaca Health Intelligence Oy"
        }
      }],
      "title" : "REMICADE kuiva-aine välikonsentraatiksi infuusionestettä varten, liuos 100 mg",
      "section" : [{
        "title" : "Lisätietoa",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><b/><b><strong>Remicade 100 mg kuiva-aine välikonsentraatiksi infuusionestettä varten, liuos</strong></b><p>infliksimabi (infliximab.)</p><p/></div>"
        },
        "section" : [{
          "title" : "Yleisiä ohjeita",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "rules"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Yleisiä ohjeita</h2><p><strong>Lue tämä pakkausseloste huolellisesti ennen kuin aloitat tämän lääkkeen käyttämisen, sillä se sisältää sinulle tärkeitä tietoja.</strong></p><ul><li>Säilytä tämä pakkausseloste. Voit tarvita sitä myöhemmin.</li><li>Lääkäri antaa sinulle myös potilaskortin, joka sisältää tärkeää turvallisuuteen liittyvää tietoa, mikä sinun tulee tietää ennen Remicade-hoidon aloitusta ja hoidon aikana.</li><li>Jos sinulla on kysyttävää, käänny lääkärin puoleen.</li><li>Tämä lääke on määrätty vain sinulle eikä sitä pidä antaa muiden käyttöön. Se voi aiheuttaa haittaa muille, vaikka heillä olisikin samanlaiset oireet kuin sinulla.</li><li>Jos havaitset haittavaikutuksia, kerro niistä lääkärille. Tämä koskee myös sellaisia mahdollisia haittavaikutuksia, joita ei ole mainittu tässä pakkausselosteessa. Ks. kohta <a class=\"cross-reference\">Mahdolliset haittavaikutukset</a>.</li></ul></div>"
          }
        },
        {
          "title" : "Tässä pakkausselosteessa kerrotaan",
          "code" : {
            "coding" : [{
              "system" : "https://gravitatehealth.eu/section",
              "code" : "toc"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Tässä pakkausselosteessa kerrotaan</h2><ol><li>Mitä Remicade on ja mihin sitä käytetään</li><li>Mitä sinun on tiedettävä, ennen kuin käytät Remicade-valmistetta</li><li>Miten Remicade-valmistetta annetaan</li><li>Mahdolliset haittavaikutukset</li><li>Remicade-valmisteen säilyttäminen</li><li>Pakkauksen sisältö ja muuta tietoa</li></ol></div>"
          }
        },
        {
          "title" : "Mitä valmiste on ja mihin sitä käytetään",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mitä valmiste on ja mihin sitä käytetään</h2><p>Remicaden vaikuttava aine on infliksimabi. Infliksimabi on monoklonaalinen vasta-aine – valkuaisaineen (proteiini) tyyppi, joka kiinnittyy elimistössä tiettyyn kohteeseen, joka on nimeltään TNF (tuumorinekroositekijä) alfa.</p><p>Remicade kuuluu lääkeryhmään, jota kutsutaan nimellä TNF-salpaajat. Sitä käytetään aikuisille seuraaviin tulehduksellisiin sairauksiin:</p><ul><li>Nivelreuma</li><li>Nivelpsoriaasi</li><li>Selkärankareuma (Bechterewin tauti)</li><li>Psoriaasi.</li></ul><p>Remicadea käytetään myös aikuisille ja yli 6-vuotiaille lapsille seuraaviin sairauksiin:</p><ul><li>Crohnin tauti</li><li>Haavainen paksusuolitulehdus.</li></ul><p>Remicade toimii kiinnittymällä selektiivisesti tuumorinekroositekijä alfaan (TNF<sub>α</sub>) ja estämällä sen toiminnan. TNF<sub>α</sub> on mukana elimistön tulehdusprosesseissa, joten sen estäminen voi vähentää elimistössä tapahtuvia tulehduksia.</p><p><strong>Nivelreuma</strong><br/>Nivelreuma on nivelten tulehduksellinen sairaus. Jos sinulla on aktiivinen nivelreuma, sinua hoidetaan ensin muilla lääkkeillä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea, jota otat yhdessä toisen lääkeaineen, metotreksaatin kanssa:</p><ul><li>vähentämään sairauden merkkejä ja oireita</li><li>hidastamaan nivelvaurioiden syntyä</li><li>parantamaan fyysistä suorituskykyä.</li></ul><p><strong>Nivelpsoriaasi</strong><br/>Nivelpsoriaasi on nivelten tulehduksellinen sairaus, johon yleensä liittyy psoriaasi. Jos sinulla on aktiivinen nivelpsoriaasi, sinua hoidetaan ensin muilla lääkkeillä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea:</p><ul><li>vähentämään sairauden merkkejä ja oireita</li><li>hidastamaan nivelvaurioiden syntyä</li><li>parantamaan fyysistä suorituskykyä.</li></ul><p><strong>Selkärankareuma (Bechterewin tauti)</strong><br/>Selkärankareuma on selkärangan tulehduksellinen sairaus. Jos sinulla on selkärankareuma, sinua hoidetaan ensin muilla lääkkeillä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea:</p><ul><li>vähentämään sairauden merkkejä ja oireita</li><li>parantamaan fyysistä suorituskykyä.</li></ul><p><strong>Psoriaasi</strong><br/>Psoriaasi on ihon tulehduksellinen sairaus. Jos sinulla on kohtalainen tai vaikea plakkipsoriaasi, saat ensin muita lääkkeitä tai hoitoja kuten valohoitoa. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea vähentämään sairauden merkkejä ja oireita.</p><p><strong>Haavainen paksusuolitulehdus</strong><br/>Haavainen paksusuolitulehdus on suoliston tulehduksellinen sairaus. Jos sinulla on haavainen paksusuolitulehdus, käytät ensin muita lääkkeitä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea sairautesi hoitoon.</p><p><strong>Crohnin tauti</strong><br/>Crohnin tauti on suoliston tulehduksellinen sairaus. Jos sinulla on Crohnin tauti, käytät ensin muita lääkkeitä. Jos nämä lääkkeet eivät toimi riittävän hyvin, sinulle annetaan Remicadea:</p><ul><li>aktiivisen Crohnin taudin hoitoon</li><li>suolen ja ihonpinnan välisten epänormaalien avanteiden (fistelien) vähentämiseen, kun niitä ei ole saatu hallintaan muilla lääkkeillä tai leikkauksella.</li></ul></div>"
          }
        },
        {
          "title" : "Mitä sinun on tiedettävä ennen valmisteen käyttöä",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mitä sinun on tiedettävä ennen valmisteen käyttöä</h2><p><strong>Sinulle ei anneta Remicade-valmistetta, jos:</strong></p><ul><li>olet allerginen infliksimabille tai Remicaden jollekin muulle aineelle (lueteltu kohdassa <a class=\"cross-reference\">Pakkauksen sisältö ja muuta tietoa</a>)</li><li>olet allerginen (yliherkkä) hiiristä peräisin oleville valkuaisaineille</li><li>sinulla on tuberkuloosi tai muu vakava infektio kuten keuhkokuume tai verenmyrkytys (sepsis)</li><li>sinulla on kohtalainen tai vaikea sydämen vajaatoiminta.</li></ul><p>Älä käytä Remicadea, jos jokin yllä olevista koskee sinua. Jos et ole varma, keskustele lääkärin kanssa ennen kuin saat Remicadea.</p><p><strong>Varoitukset ja varotoimet</strong><br/>Keskustele lääkärin kanssa ennen kuin saat Remicade-valmistetta tai Remicade-hoidon aikana, jos:</p><p><span class=\"underline\">Olet saanut Remicade-hoitoa aiemmin</span></p><ul><li>Kerro lääkärille, jos olet saanut Remicade-hoitoa aiemmin ja olet nyt aloittamassa hoidon uudelleen.<br/>Jos Remicade-hoidossasi on ollut yli 16 viikon tauko, allergisten reaktioiden riski on suurempi, kun hoitosi aloitetaan uudelleen.</li></ul><p><span class=\"underline\">Infektiot</span></p><ul><li>Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on jokin infektio, vaikka se olisi hyvin vähäinen.</li><li>Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos olet joskus asunut tai matkustanut alueilla, joilla histoplasmoosi-, kokkidioidomykoosi- tai blastomykoosi-infektiot ovat yleisiä. Näitä infektioita aiheuttavat tietyntyyppiset sienet, jotka voivat olla haitallisia keuhkoille tai elimistön muille osille.</li><li>Saatat saada infektioita helpommin, kun sinua hoidetaan Remicade-valmisteella. Jos olet 65-vuotias tai vanhempi, riski on suurempi.</li><li><span>Nämä infektiot saattavat olla vakavia ja niitä ovat tuberkuloosi, virusten, sienten, bakteerien tai muiden luonnossa olevien organismien aiheuttamat infektiot sekä verenmyrkytys (sepsis), joka voi olla hengenvaarallinen.</span></li></ul><p>Kerro lääkärille heti, jos saat infektion merkkejä Remicade-hoidon aikana. Merkkeihin kuuluvat kuume, yskä, flunssan kaltaiset oireet, huonovointisuus, punainen tai kuuma iho, haavat ja hammasongelmat. Lääkäri saattaa suositella Remicade-hoidon väliaikaista lopettamista.</p><p><span class=\"underline\">Tuberkuloosi</span></p><ul><li>On erittäin tärkeää, että kerrot lääkärille, jos sinulla on joskus ollut tuberkuloosi tai jos olet ollut läheisessä kontaktissa henkilön kanssa, jolla on ollut tai on tuberkuloosi.</li><li>Lääkäri tekee sinulle kokeita, joiden avulla nähdään, onko sinulla tuberkuloosi. Tuberkuloosia on raportoitu Remicade-hoitoa saaneilla potilailla, myös potilailla, jotka ovat jo saaneet tuberkuloosilääkkeitä. Lääkäri kirjaa tuberkuloositestien tulokset potilaskorttiisi.</li><li>Jos lääkärin mielestä sinulla on tuberkuloosin riski, sinua voidaan hoitaa tuberkuloosilääkkeillä ennen kuin saat Remicade-valmistetta.</li></ul><p>Kerro lääkärille heti, jos saat tuberkuloosin merkkejä Remicade-hoidon aikana. Merkkeihin kuuluvat itsepintainen yskä, painon aleneminen, väsymyksen tunne, kuume, yöhikoilu.</p><p><span class=\"underline\">B-hepatiittivirus</span></p><ul><li>Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos olet hepatiitti B-viruksen kantaja tai sinulla on tai on joskus ollut B-hepatiitti.</li><li>Kerro lääkärille, jos uskot olevasi vaarassa sairastua B-hepatiittiin.</li><li>Lääkäri tekee sinulle B-hepatiittitestin.</li><li>Hoito TNF-salpaajilla kuten Remicade-valmisteella saattaa johtaa B-hepatiittiviruksen palautumiseen aktiiviseksi potilailla, jotka kantavat tätä virusta. Tämä saattaa toisinaan olla hengenvaarallista.</li></ul><p><span class=\"underline\">Sydänongelmat</span></p><ul><li>Kerro lääkärille, jos sinulla on sydänongelmia kuten lievä sydämen vajaatoiminta.</li><li>Lääkäri saattaa haluta tarkkailla sydäntäsi.</li></ul><p>Kerro lääkärille heti, jos saat Remicade-hoidon aikana uusia sydämen vajaatoiminnan merkkejä tai ne pahenevat. Merkkeihin kuuluvat hengästyneisyys tai jalkojen turvotus.</p><p><span class=\"underline\">Syöpä ja lymfooma</span></p><ul><li>Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on tai on joskus ollut lymfooma (eräänlainen verisyöpä) tai jokin muu syöpä.</li><li>Potilailla, joilla on vaikea nivelreuma ja joilla tauti on ollut kauan, saattaa lymfooman kehittymisen riski olla suurempi.</li><li>Remicadea käyttävillä lapsilla ja aikuisilla lymfooman tai muun syövän kehittymisen riski saattaa suurentua.</li><li>Joillekin potilaista, joita on hoidettu TNF-salpaajalla, mukaan lukien Remicade-valmisteella, on kehittynyt harvinainen syöpä, jota kutsutaan hepatospleeniseksi T-solulymfoomaksi. Useimmat näistä potilaista olivat teini-ikäisiä poikia tai nuoria miehiä ja useimmilla heistä oli joko Crohnin tauti tai haavainen paksusuolitulehdus. Tämän tyyppinen syöpä on tavallisimmin johtanut kuolemaan. Lähes kaikki potilaat olivat saaneet myös atsatiopriinia tai 6-merkaptopuriinia sisältäviä lääkkeitä TNF-salpaajan lisäksi.</li><li>Joillekin infliksimabihoitoa saaneille potilaille on kehittynyt tietynlaisia ihosyöpiä. Jos havaitset mitä tahansa muutoksia ihossasi tai kasvaimia ihossa hoidon aikana tai sen jälkeen, kerro asiasta lääkärille.</li><li>Joillekin naisille, jotka ovat saaneet Remicade-valmistetta nivelreuman hoitoon, on kehittynyt kohdunkaulan syöpä. Remicade-valmistetta saaville naisille, mukaan lukien yli 60-vuotiaille, lääkäri voi suositella säännöllisiä kohdunkaulan syövän seulontatutkimuksia.</li></ul><p><span class=\"underline\">Keuhkosairaus tai runsas tupakointi</span></p><ul><li>Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on keuhkosairaus nimeltä pitkäaikainen ahtauttava keuhkosairaus (keuhkoahtaumatauti, COPD) tai jos tupakoit runsaasti.</li><li>Potilailla, joilla on COPD tai jotka tupakoivat runsaasti, syövän kehittymisen riski saattaa lisääntyä Remicade-hoidon aikana.</li></ul><p><span class=\"underline\">Hermoston sairaus</span></p><ul><li>Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on tai on joskus ollut hermostoon vaikuttavia ongelmia. Näitä ovat MS-tauti (multippeli skleroosi), Guillain-Barrén oireyhtymä, jos sinulla on kouristuskohtauksia tai jos sinulla on todettu näköhermon tulehdus (optinen neuriitti).</li></ul><p>Kerro lääkärille heti, jos saat hermoston sairauksien oireita Remicade-hoidon aikana. Tällaisia oireita ovat näkökyvyn muutos, käsien tai jalkojen heikkous, puutumisen tai pistelyn tunne kehossa.</p><p><span class=\"underline\">Epänormaalit ihon avanteet</span></p><ul><li>Kerro lääkärille ennen kuin saat Remicade-valmistetta, jos sinulla on epänormaaleja ihon avanteita (fisteleitä).</li></ul><p><span class=\"underline\">Rokotukset</span></p><ul><li>Kerro lääkärille, jos olet hiljattain saanut rokotuksen tai sinulle on suunniteltu annettavan rokotus.</li><li><span>Sinun pitää saada suositellut rokotukset ennen Remicade-hoidon aloittamista. Voit saada joitakin rokotteita Remicade-hoidon aikana, mutta sinulle ei saa antaa eläviä rokotteita (rokotteet, jotka sisältävät eläviä, mutta heikennettyjä taudinaiheuttajia), koska ne voivat aiheuttaa infektioita.</span></li><li>Jos sait Remicade-valmistetta raskauden aikana, myös lapsellasi saattaa olla suurentunut eläviin rokotteisiin liittyvä infektioriski <span><span>ensimmäisen elinvuoden</span> </span>ajan. On tärkeää, että kerrot lastasi hoitavalle lääkärille ja muille terveydenhuollon ammattilaisille Remicade-hoidostasi, jotta he voivat päättää, milloin lapsesi voi saada jonkin rokotuksen, mukaan lukien elävät rokotteet kuten BCG<span> <span>-rokote</span> </span>(käytetään tuberkuloosin ehkäisyyn).</li><li><span><span>Jos imetät, on tärkeää että kerrot lapsesi hoitavalle lääkärille ja muille terveydenhuollon ammattilaisille Remicade-hoidostasi, ennen kuin lapsellesi annetaan jokin rokotus. </span></span>Katso lisätietoja kohdasta Raskaus ja imetys.</li></ul><p><span class=\"underline\">Hoidolliset tartunnanaiheuttajat</span></p><ul><li>Kerro lääkärille, jos olet hiljattain saanut tai sinulle on suunniteltu annettavan hoitoa hoidollisella tartunnanaiheuttajalla (kuten BCG-rokote instillaationa syövän hoitoon).</li></ul><p><span class=\"underline\">Leikkaukset tai hammastoimenpiteet</span></p><ul><li>Kerro lääkärille, jos olet menossa johonkin leikkaukseen tai hammastoimenpiteeseen.</li><li>Kerro kirurgille tai hammaslääkärille, että saat Remicade-hoitoa ja näytä hänelle potilaskorttisi.</li></ul><p><span><span class=\"underline\">Maksaongelmat</span></span></p><ul><li><span>Joillekin Remicade-hoitoa saaville potilaille on kehittynyt vakavia maksaongelmia.</span></li></ul><p><span>Kerro lääkärillesi välittömästi, jos sinulle ilmaantuu Remicade-hoidon aikana maksaongelmien oireita. Merkkejä ovat ihon ja silmien keltaisuus, virtsan värjäytyminen tummanruskeaksi, kipu tai turvotus oikealla ylävatsalla, nivelkipu, ihottuma tai kuume.</span></p><p><span><span class=\"underline\">Alhaiset verisolujen määrät</span></span></p><ul><li><span>Joidenkin Remicade-valmistetta saavien potilaiden elimistö ei tuota riittävästi verisoluja, jotka auttavat taistelemaan infektioita vastaan tai lopettamaan verenvuodon.</span></li></ul><p><span>Kerro lääkärillesi välittömästi, jos sinulle ilmaantuu Remicade-hoidon aikana oireita alhaisesta verisolujen määrästä. Merkkejä ovat itsepintainen kuume, herkästi syntyvät mustelmat tai verenvuoto, ihonalaisen verenvuodon aiheuttamat pienet punaiset tai violetit pisteet iholla tai ihon kalpeus.</span></p><p><span><span><span class=\"underline\">Immuunijärjestelmän häiriö</span> <span class=\"underline\">t</span></span></span></p><ul><li>Joillekin Remicade-valmistetta saaville potilaille on kehittynyt lupus-nimisen immuunijärjestelmän häiriön oireita.</li></ul><p>Kerro lääkärillesi välittömästi, jos sinulle ilmaantuu lupuksen oireita Remicade-hoidon aikana. Merkkejä ovat nivelkipu tai auringolle herkkä ihottuma poskilla tai käsivarsilla.</p><p><strong>Lapset ja nuoret</strong><br/><span class=\"underline\">Yllä olevat tiedot koskevat myös lapsia ja nuoria. Tämän lisäksi:</span></p><ul><li>Joillain TNF-estäjiä kuten Remicade-valmistetta saaneilla lapsilla ja teini-ikäisillä potilailla on esiintynyt syöpätapauksia, mukaan lukien harvinaisia syöpätyyppejä. Ne ovat toisinaan johtaneet kuolemaan.</li><li>Remicade-valmistetta saaneille lapsille kehittyi infektioita useammin kuin aikuisille.</li><li>Lasten pitää saada suositusten mukaiset rokotukset ennen Remicade-hoidon aloitusta. Lapsille voidaan antaa joitakin rokotteita Remicade-hoidon aikana, mutta heille ei saa antaa eläviä rokotteita Remicade-hoidon aikana.</li></ul><p>Mikäli et ole varma, koskeeko jokin yllä olevista sinua, keskustele lääkärin kanssa ennen kuin saat Remicade-valmistetta.</p><p><strong>Muut lääkevalmisteet ja Remicade</strong><br/>Potilaat, joilla on jokin tulehduksellinen sairaus, käyttävät valmiiksi lääkevalmisteita sairautensa hoitoon. Nämä lääkevalmisteet saattavat aiheuttaa haittavaikutuksia. Lääkäri neuvoo, mitä muita lääkkeitä sinun tulee edelleen käyttää Remicade-hoidon aikana.</p><p>Kerro lääkärille, jos parhaillaan käytät tai olet äskettäin käyttänyt muita lääkkeitä, myös muita lääkkeitä Crohnin taudin, haavaisen paksusuolitulehduksen, nivelreuman, selkärankareuman, nivelpsoriaasin tai psoriaasin hoitoon tai lääkkeitä, joita lääkäri ei ole määrännyt kuten vitamiineja tai rohdosvalmisteita.</p><p>Erityisesti kerro lääkärille, jos käytät jotain seuraavista lääkkeistä:</p><ul><li>Lääkkeitä, jotka vaikuttavat immuunijärjestelmään.</li><li>Kineret (anakinra). Remicadea ja Kineret-valmistetta ei pidä käyttää samanaikaisesti.</li><li>Orencia (abatasepti). Remicadea ja Orenciaa ei pidä käyttää samanaikaisesti.</li></ul><p><span><span>Sinulle ei saa antaa eläviä roketteita Remicade-hoidon aikana. Jos sait Remicade-hoitoa raskauden aikana tai jos saat Remicade-hoitoa imetyksen aikana, kerro lastasi hoitavalle lääkärille ja muille terveydenhuollon ammatilaisille Remicade- hoidostasi, ennen kuin lapsesi saa mitään rokotteita.</span></span></p><p>Mikäli et ole varma, koskeeko jokin yllä olevista sinua, keskustele lääkärin tai apteekkihenkilökunnan kanssa ennen Remicade-valmisteen käyttöä.</p><p><strong>Raskaus, imetys ja hedelmällisyys</strong></p><ul><li>Jos olet raskaana tai imetät, epäilet olevasi raskaana tai jos suunnittelet lapsen hankkimista, kysy lääkäriltä neuvoa ennen tämän lääkkeen käyttöä. Remicadea tulee käyttää raskauden tai imetyksen aikana vain, jos se lääkärin mielestä on välttämätöntä.</li><li>Sinun tulee välttää raskaaksi tuloa Remicade-hoidon aikana ja 6 kuukautta hoidon lopettamisen jälkeen. Keskustele lääkärin kanssa ehkäisyn käytöstä tuona aikana.</li><li>Jos sait Remicadea raskauden aikana, lapsellasi saattaa olla suurentunut infektioriski.</li><li>On tärkeää, että kerrot lastasi hoitavalle lääkärille ja muille terveydenhuollon ammattilaisille Remicade-hoidostasi ennen kuin lapsellesi annetaan jokin rokotus. Jos sait Remicade-hoitoa raskauden aikana, BCG-rokotteen (käytetään tuberkuloosin ehkäisyyn) antaminen lapsellesi 12 kuukauden aikana syntymän jälkeen voi aiheuttaa infektion, jolla saattaa olla vakavia, jopa kuolemaan johtavia komplikaatioita. Eläviä rokotteita, kuten BCG-rokotetta, ei saa antaa lapsellesi 12 kuukauteen syntymän jälkeen<span> <span>ellei lastasi hoitava lääkäri toisin suosittele</span> </span>. Katso lisätietoja kohdasta Rokotukset.</li><li><span><span>Jos imetät, on tärkeää että kerrot lapsesi hoitavalle lääkärille ja muille terveydenhuollon ammattilaisille Remicade-hoidostasi, ennen kuin lapsellesi annetaan jokin rokotus. Eläviä rokotteita ei tule antaa lapsellesi imetyksen aikana ellei lastasi hoitava lääkäri toisin suosittele.</span></span></li><li>Remicade-hoitoa raskauden aikana saaneiden naisten imeväisikäisillä lapsilla on raportoitu voimakkaasti alentuneita valkosolujen määriä. Jos lapsellasi on jatkuvaa kuumeilua tai infektioita, ota heti yhteyttä lastasi hoitavaan lääkäriin.</li></ul><p><strong>Ajaminen ja koneiden käyttö</strong><br/>Remicaden ei oleteta vaikuttavan ajokykyyn tai kykyyn käyttää koneita. Jos tunnet olevasi väsynyt, sinua huimaa tai olet huonovointinen saatuasi Remicadea, älä aja tai käytä mitään työvälineitä tai koneita.</p><p><strong>Remicade sisältää natriumia</strong><br/>Remicade sisältää alle 1 mmol natriumia (23 mg) per annos eli se on käytännössä natriumiton. Ennen kuin Remicade annetaan, se kuitenkin sekoitetaan natriumia sisältävään liuokseen. Keskustele lääkärin kanssa, jos noudatat vähäsuolaista ruokavaliota.</p></div>"
          }
        },
        {
          "title" : "Miten valmistetta käytetään",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Miten valmistetta käytetään</h2><p><span><strong>Nivelreuma</strong></span><br/>Tavanomainen annos on 3 mg painokiloa kohti.</p><p><span><strong>Nivelpsoriaasi, selkärankareuma (Bechterewin tauti), psoriaasi, haavainen paksusuolitulehdus ja Crohnin tauti</strong></span><br/>Tavanomainen annos on 5 mg painokiloa kohti.</p><p><strong>Miten Remicadea annetaan</strong></p><ul><li>Lääkäri tai hoitaja antaa sinulle Remicade-valmisteen.</li><li>Lääkäri tai hoitaja valmistaa lääkkeen infuusiota varten.</li><li>Lääke annetaan infuusiona (tiputus) (2 tunnin aikana) laskimoon, yleensä käsivarteen. Kolmannen hoitokerran jälkeen lääkäri voi päättää, että saat Remicade-annoksen 1 tunnin aikana.</li><li>Vointiasi tarkkaillaan Remicade-tiputuksen aikana ja vielä 1-2 tunnin ajan sen jälkeen.</li></ul><p><strong>Kuinka paljon Remicade-valmistetta annetaan</strong></p><ul><li>Lääkäri päättää saamasi annoksen suuruuden ja kuinka usein Remicade-valmistetta sinulle annetaan. Tämä riippuu sairaudestasi, painostasi ja siitä, miten Remicade-hoito sinuun vaikuttaa.</li><li>Alla olevasta taulukosta näet, miten usein tätä lääkettä yleensä annetaan ensimmäisen annoksen jälkeen.</li></ul><table><tbody><tr><td>2. annos</td><td>2 viikkoa 1. annoksen jälkeen</td></tr><tr><td>3. annos</td><td>6 viikkoa 1. annoksen jälkeen</td></tr><tr><td>Myöhemmät annokset</td><td>6-8 viikon välein riippuen sairaudestasi</td></tr></tbody></table><p/><p><strong>Käyttö lapsille ja nuorille</strong><br/>Remicade-valmistetta annetaan lapsille vain Crohnin taudin tai haavaisen paksusuolitulehduksen hoitoon. Näiden lasten pitää olla 6 vuotta täyttäneitä.</p><p><strong>Jos saat enemmän Remicade-valmistetta kuin sinun pitäisi</strong><br/>Lääkäri tai hoitaja antaa sinulle tämän lääkevalmisteen. Siksi on epätodennäköistä, että saisit sitä enemmän kuin pitäisi. Liian suuren Remicade-annoksen ei tiedetä aiheuttaneen haittavaikutuksia.</p><p><strong>Jos unohdat tai jäät vaille Remicade-infuusiota</strong><br/>Jos unohdat tai myöhästyt vastaanottokäynniltä, jolla oli tarkoitus saada Remicade-valmistetta, sovi uusi aika mahdollisimman pian.</p><p>Jos sinulla on kysymyksiä tämän lääkkeen käytöstä, käänny lääkärin puoleen.</p></div>"
          }
        },
        {
          "title" : "Mahdolliset haittavaikutukset",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Mahdolliset haittavaikutukset</h2><p>Kuten kaikki lääkkeet, tämäkin lääke voi aiheuttaa haittavaikutuksia. Kaikki eivät kuitenkaan niitä saa. Useimmat haittavaikutukset ovat lieviä tai kohtalaisia vaikeusasteeltaan. Joillain potilailla haittavaikutukset kuitenkin voivat olla vakavia ja vaatia hoitoa. Haittavaikutuksia voi ilmaantua myös Remicade-lääkityksen lopettamisen jälkeen.</p><p><strong>Kerro välittömästi lääkärille, jos huomaat jotain seuraavista:</strong></p><ul><li><strong>Merkkejä allergisesta reaktiosta</strong> kuten kasvojen, huulten, suun tai kurkun turvotus, mikä saattaa vaikeuttaa nielemistä tai hengitystä, ihottuma, nokkosrokko, käsien, jalkojen tai nilkkojen turvotus. Jotkut näistä reaktioista voivat olla vakavia tai hengenvaarallisia. Allerginen reaktio voi ilmaantua 2 tunnin kuluessa tiputuksesta tai myöhemmin. Muita oireita, jotka voivat olla merkkejä allergisista reaktioista, joita saattaa esiintyä jopa 12 päivän kuluttua tiputuksesta, ovat lihaskipu, kuume, kipu nivelissä tai leukapielissä, kurkkukipu tai päänsärky.</li><li><strong>Merkkejä sydänongelmasta</strong> kuten rintatuntemus tai rintakipu, käsivarren kipu, mahakipu, hengenahdistus, ahdistuneisuus, heikotuksen tunne, huimaus, pyörtyminen, hikoilu, huonovointisuus (pahoinvointi), oksentaminen, sydämen tykytys tai hakkaaminen, nopea tai hidas sydämensyke ja jalkojen turvotus.</li><li><strong>Merkkejä infektiosta (mukaan lukien tuberkuloosi)</strong> kuten kuume, väsymyksen tunne, yskä, joka voi jatkua pitkään, hengenahdistus, flunssan kaltaiset oireet, painon aleneminen, yöhikoilu, ripuli, haavat, märkäkertymä (paise) suolistossa tai peräaukon ympärillä, hammasongelmat tai kirvelevä tunne virtsatessa.</li><li><strong>Mahdollisia merkkejä syövästä, </strong>mukaan lukien mutta rajoittumatta: imusolmukkeiden turvotus, painon lasku, kuume, epätavalliset ihokyhmyt, muutokset luomissa tai ihon värissä tai epätavallinen emätinverenvuoto.</li><li><strong>Merkkejä keuhko-ongelmasta</strong> kuten yskä, hengitysvaikeudet tai ahdistava tunne rinnassa.</li><li><span><span><strong>Merkkejä hermoston ongelmasta (mukaan lukien silmäongelmat)</strong> kuten aivohalvauksen merkit (äkillinen kasvojen, käsien tai jalkojen puutuminen tai voimattomuus, etenkin toisella puolella kehoa; äkillinen sekavuus, puhe- tai ymmärtämisvaikeudet; näköhäiriöt toisessa tai molemmissa silmissä, kävelemisvaikeudet, heitehuimaus, tasapainon tai koordinaatiokyvyn menettäminen tai voimakas päänsärky), kouristuskohtaukset, pistely/puutuminen jossain kehon osassa tai käsien tai jalkojen voimattomuus, muutokset näkökyvyssä kuten kahtena näkeminen tai muut silmäongelmat.</span></span></li><li><strong>Merkkejä maksaongelmasta</strong> (mukaan lukien B-hepatiitti-infektio, jos sinulla on aiemmin ollut B-hepatiitti) kuten ihon tai silmien keltaisuus, virtsan värjäytyminen tummanruskeaksi, kipua tai turvotusta oikealla ylävatsalla, nivelkipu, ihottumat tai kuume.</li><li><strong>Merkkejä immuunijärjestelmän sairaudesta,</strong> kuten nivelkipua tai auringolle herkkää ihottumaa poskilla tai käsissä (lupus) tai yskää, hengenahdistusta, kuumetta tai ihottumaa (sarkoidoosi).</li><li><strong>Merkkejä alhaisista verisolujen määristä</strong> kuten itsepintainen kuume, herkästi tuleva verenvuoto tai mustelmat, ihonalaisesta verenvuodosta johtuvat pienet punaiset tai violetit pisteet iholla tai ihon kalpeus.</li><li><strong>Merkkejä vakavista iho-ongelmista</strong> kuten vartalolla punoittavat kokardimaiset pilkut tai pyöreät laikut, joiden keskellä on usein rakkula, laaja-alainen ihon kuoriutuminen ja irtoaminen (kesiminen), haavaumat suussa, kurkussa, nenässä, sukupuolielimissä ja silmissä tai pienet märkäiset paukamat, jotka voivat levitä ympäri kehoa. Näiden ihoreaktioiden yhteydessä voi ilmetä kuumetta.</li></ul><p>Kerro lääkärille heti, jos huomaat jotain yllä mainituista.</p><p>Seuraavia haittavaikutuksia on havaittu Remicaden käytön yhteydessä:</p><p><strong>Hyvin yleisiä: useammin kuin yli 1 potilaalla kymmenestä</strong></p><ul><li>vatsakipu, huonovointisuus</li><li>virusinfektiot kuten herpes tai flunssa</li><li>ylähengitystieinfektiot kuten sinuiitti</li><li>päänsärky</li><li>infuusion aiheuttama haittavaikutus</li><li>kipu.</li></ul><p><span><strong>Yleisiä: harvemmin kuin 1 potilaalla kymmenestä</strong></span></p><ul><li>muutokset maksan toiminnassa, maksaentsyymien kohoaminen (näkyy verikokeissa)</li><li>infektio keuhkoissa tai rinnassa kuten keuhkoputkitulehdus tai keuhkokuume</li><li>hengitysvaikeudet, rintakipu</li><li>verenvuoto vatsassa tai suolistossa, ripuli, ruoansulatushäiriö, närästys, ummetus</li><li>nokkosrokko, kutiseva ihottuma tai kuiva iho</li><li>tasapaino-ongelmat tai huimauksen tunne</li><li>kuume, lisääntynyt hikoilu</li><li>verenkierto-ongelmat kuten matala tai korkea verenpaine</li><li>mustelmat, kuumat aallot tai nenäverenvuoto, kuuma, punoittava iho (punastuminen)</li><li>väsymyksen tai heikkouden tunne</li><li>bakteeri-infektiot kuten verenmyrkytys, absessi (märkäpesäke) tai infektio ihon alla (selluliitti)</li><li>sienen aiheuttama ihoinfektio</li><li>veriongelmat kuten anemia tai valkosolujen vähyys</li><li>turvonneet imusolmukkeet</li><li>masennus, univaikeudet</li><li>silmäongelmat mukaan lukien silmien punoitus ja infektiot</li><li>sydämen nopealyöntisyys (takykardia) tai sydämentykytys</li><li>kipu nivelissä, lihaksissa tai selässä</li><li>virtsatieinfektio</li><li>psoriaasi, iho-ongelmat kuten ihottuma ja hiusten lähtö</li><li>pistokohdan reaktiot kuten kipu, turvotus, punoitus tai kutina</li><li>vilunväreet, nesteen kertyminen ihon alle turvotusta aiheuttaen</li><li>tunnottomuus tai pistelyn tunne.</li></ul><p><strong>Melko harvinaisia: harvemmin kuin 1 potilaalla sadasta</strong></p><ul><li>riittämätön verensaanti, verisuonien turpoaminen</li><li>veren kerääntyminen verisuonien ulkopuolelle (hematooma) tai mustelmat</li><li>iho-ongelmat kuten rakkulat, syylät, epänormaali ihon värjäytyminen tai pigmentaatio, tai huulten turvotus tai ihon paksuuntuminen tai punainen, hilseilevä ja hiutaleinen iho</li><li>vakavat allergiset reaktiot (esim. anafylaksi), immuunijärjestelmän sairaus nimeltään lupus, yliherkkyysreaktiot vieraita valkuaisaineita kohtaan</li><li>haavojen hitaampi paraneminen</li><li>maksan suurentuminen (hepatiitti) tai sappirakon turvotus, maksavaurio</li><li>muistamattomuus, ärtyisyys, sekavuus, hermostuneisuus</li><li>silmäongelmat mukaan lukien näön sumentuminen tai heikentyminen, silmien turvotus tai näärännäpyt</li><li>sydämen vajaatoiminnan puhkeaminen tai paheneminen, hidas sydämen syke</li><li>pyörtyminen</li><li>kouristukset, hermo-ongelmat</li><li>reikä suolessa tai suolen tukkeuma, vatsakipu tai krampit</li><li>haiman turpoaminen (haimatulehdus)</li><li>sieni-infektiot kuten hiivainfektio tai kynsien sieni-infektio</li><li>keuhko-ongelmat (kuten turvotus)</li><li>nesteen purkautuminen keuhkopussiin</li><li>hengitysteiden ahtaus keuhkoissa, joka aiheuttaa hengitysvaikeuksia</li><li>keuhkopussin tulehtumisen aiheuttama terävä rintakipu, joka tuntuu pahemmalta hengitettäessä (keuhkopussintulehdus)</li><li>tuberkuloosi</li><li>munuaisinfektiot</li><li>verihiutaleiden vähyys, valkosolujen ylimäärä</li><li>emättimen infektiot</li><li>veriarvojen tulokset, jotka osoittavat vasta-aineita omaa elimistöä vastaan</li><li><span><span>muutokset veren kolesteroli- ja rasva-arvoissa.</span></span></li></ul><p><span><strong>Harvinaisia: harvemmin kuin 1 potilaalla tuhannesta</strong></span></p><ul><li>tietyntyyppinen verisyöpä (lymfooma)</li><li>veri ei kuljeta riittävästi happea elimistölle, verenkierto-ongelmat kuten verisuonien kaventuminen</li><li>aivokalvotulehdus (meningiitti)</li><li>infektiot, jotka johtuvat heikentyneestä immuunijärjestelmästä</li><li>B-hepatiitti-infektio, kun sinulla on aiemmin ollut B-hepatiitti</li><li>maksatulehdus, joka johtuu ongelmasta immuunijärjestelmässä (autoimmuunihepatiitti)</li><li>maksaongelma, joka aiheuttaa ihon tai silmien keltaisuutta (keltatauti)</li><li>epänormaali kudosten turvotus tai kasvu</li><li>vakava allerginen reaktio, joka voi aiheuttaa tajuttomuutta ja voi olla hengenvaarallinen (anafylaktinen sokki)</li><li>pienten verisuonien turpoaminen (verisuonitulehdus)</li><li>immuunihäiriöt, jotka voivat vaikuttaa keuhkoihin, ihoon tai imusolmukkeisiin (kuten sarkoidoosi)</li><li>tulehdusvasteesta johtuvat immuunijärjestestelmän solujen paikalliset kertymät (granulomatoottiset leesiot)</li><li>kiinnostuksen tai tunteiden puute</li><li>vakavat iho-ongelmat kuten toksinen epidermaalinen nekrolyysi, Stevens-Johnsonin oireyhtymä ja akuutti yleistynyt eksantematoottinen pustuloosi</li><li>muut iho-ongelmat kuten erythema multiforme, jäkälää muistuttavat reaktiot (kutiseva, punertavanvioletti ihottuma ja/tai säiemäisiä valkoisenharmaita viivoja limakalvoilla), rakkulat ja ihon kuoriutuminen tai paiseet (paisetauti)</li><li>vakavat hermoston sairaudet kuten selkäytimen poikittaistulehdus, MS-taudin kaltainen sairaus, optinen neuriitti ja Guillain-Barrén oireyhtymä</li><li>silmätulehdus, joka voi aiheuttaa näkökyvyn muutoksia, mukaan lukien sokeutta</li><li>nesteen purkautuminen sydänpussiin</li><li>vakavat keuhko-ongelmat (kuten interstitiaali keuhkosairaus)</li><li>melanooma (ihosyöpätyyppi)</li><li>kohdunkaulan syöpä</li><li>alhaiset veriarvot, mukaan lukien voimakkaasti alentunut valkosolujen määrä</li><li>pienet punaiset tai violetit pisteet ihon alla (ihonalaisen verenvuodon aiheuttamat)</li><li><span><span>immuunijärjestelmään kuuluvan komplementtitekijä-nimisen veren proteiinin poikkeavat arvot.</span></span></li></ul><p><span><strong>Tuntemattomia: koska saatavissa oleva tieto ei riitä esiintyvyyden arviointiin</strong></span></p><ul><li>syöpä lapsilla ja aikuisilla</li><li>harvinainen verisyöpä, joka esiintyy useimmiten <span><span>teini-ikäisillä pojilla tai </span></span>nuorilla miehillä (hepatospleeninen T-solulymfooma)</li><li>maksan vajaatoiminta</li><li>merkelinsolusyöpä (ihosyöpätyyppi)</li><li><span><span>Kaposin sarkooma, harvinainen syöpä, joka liittyy ihmisen herpesvirus 8 -infektioon. Kaposin sarkooma ilmenee yleisimmin sinipunaisina ihovaurioina.</span></span></li><li>dermatomyosiitti-nimisen sairauden paheneminen (havaitaan lihasheikkoutena, johon liittyy ihottumaa)</li><li>sydänkohtaus</li><li>aivohalvaus</li><li>ohimenevä näkökyvyn menetys infuusion aikana tai 2 tunnin kuluessa infuusiosta</li><li>elävästä rokotteesta johtuva infektio heikentyneen immuunijärjestelmän takia.</li></ul><p><strong>Muut haittavaikutukset lapsilla ja nuorilla</strong><br/>Remicadea Crohnin tautiin saaneilla lapsilla havaittiin haittavaikutuksissa eroja verrattuna Remicadea Crohnin tautiin saaneisiin aikuisiin. Lapsilla havaittiin enemmän seuraavia haittavaikutuksia: alhainen punasolujen määrä (anemia), verta ulosteessa, alhainen valkosolujen kokonaismäärä (leukopenia), punastuminen, virusinfektiot, alhainen infektioita vastaan taistelevien valkosolujen määrä (neutropenia), luunmurtuma, bakteeri-infektio ja hengityselinten allerginen reaktio.</p><p><strong>Haittavaikutuksista ilmoittaminen</strong><br/>Jos havaitset haittavaikutuksia, kerro niistä lääkärille, apteekkihenkilökunnalle tai sairaanhoitajalle. Tämä koskee myös sellaisia mahdollisia haittavaikutuksia, joita ei ole mainittu tässä pakkausselosteessa. Voit ilmoittaa haittavaikutuksista myös suoraan (ks. yhteystiedot alla). Ilmoittamalla haittavaikutuksista voit auttaa saamaan enemmän tietoa tämän lääkevalmisteen turvallisuudesta.</p><p>www-sivusto: <a>www.fimea.fi</a><br/>Lääkealan turvallisuus- ja kehittämiskeskus Fimea<br/>Lääkkeiden haittavaikutusrekisteri<br/>PL 55<br/>00034 FIMEA</p></div>"
          }
        },
        {
          "title" : "Valmisteen säilyttäminen",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Valmisteen säilyttäminen</h2><p>Terveydenhoidon ammattilaiset huolehtivat yleensä Remicade-valmisteen säilyttämisestä. Seuraavassa ovat säilytysohjeet, mikäli tarvitset niitä:</p><ul><li>Ei lasten ulottuville eikä näkyville.</li><li>Älä käytä tätä lääkettä etiketissä ja kotelossa mainitun viimeisen käyttöpäivämäärän (EXP) jälkeen. Viimeinen käyttöpäivämäärä tarkoittaa kuukauden viimeistä päivää.</li><li>Säilytä jääkaapissa (2°C−8 °C).</li><li>Tätä lääkettä voi myös säilyttää alkuperäisessä kotelossa poissa jääkaapista, alle 25 ºC:ssa, yhden enintään kuuden kuukauden pituisen jakson ajan. Säilytys ei saa kuitenkaan ylittää alkuperäistä viimeistä käyttöpäivämäärää. Tällöin sitä ei saa laittaa enää takaisin jääkaappisäilytykseen. Uusi viimeinen käyttöpäivämäärä kirjoitetaan koteloon muodossa pv/kk/vuosi. Lääke on hävitettävä, jos sitä ei käytetä ennen uutta viimeistä käyttöpäivämäärää tai koteloon painettua alkuperäistä viimeistä käyttöpäivämäärää, kumpi tahansa on aikaisempi.</li><li>On suositeltavaa, että käyttövalmis Remicade-infuusioliuos käytetään mahdollisimman pian (3 tunnin kuluessa). Jos liuos valmistetaan kuitenkin aseptisissa olosuhteissa, sitä voidaan säilyttää enintään 28 päivää jääkaapissa 2°C–8°C:ssa ja lisäksi 24 tuntia 25°C:ssa jääkaapista ottamisen jälkeen.</li><li>Älä käytä tätä lääkettä, jos se on värjääntynyt tai sisältää vieraita hiukkasia.</li></ul></div>"
          }
        },
        {
          "title" : "Pakkauksen sisältö ja muuta tietoa",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Pakkauksen sisältö ja muuta tietoa</h2><p><strong>Mitä Remicade sisältää</strong></p><ul><li>Vaikuttava aine on infliksimabi. Yksi injektiopullo sisältää 100 mg infliksimabia. Liuottamisen jälkeen yksi millilitra sisältää 10 mg infliksimabia.</li><li>Muut aineet ovat sakkaroosi, polysorbaatti 80, mononatriumfosfaatti ja dinatriumfosfaatti.</li></ul><p><strong>Lääkevalmisteen kuvaus ja pakkauskoot</strong><br/>Remicade kuiva-aine välikonsentraatiksi infuusionestettä varten, liuos on pakattu lasiseen injektiopulloon. Kuiva-aine on kylmäkuivattu, valkoinen pelletti.<br/>Remicade on saatavana 1, 2, 3, 4 tai 5 injektiopullon pakkauksina. Kaikkia pakkauskokoja ei välttämättä ole myynnissä.</p><p><strong>Myyntiluvan haltija ja valmistaja</strong><br/>Janssen Biologics B.V.<br/>Einsteinweg 101<br/>2333 CB Leiden<br/>Alankomaat</p><p>Lisätietoja tästä lääkevalmisteesta antaa myyntiluvan haltijan paikallinen edustaja:</p><p><strong>Suomi/Finland</strong><br/>MSD Finland Oy<br/>Puh/Tel: +358 (0)9 804 650<a><br/>info@msd.fi</a></p><p><strong>Tämä pakkausseloste on tarkistettu viimeksi 09/2022</strong></p><p><strong>Muut tiedonlähteet</strong><br/>Lisätietoa tästä lääkevalmisteesta on saatavilla Euroopan lääkeviraston verkkosivulla <a>http://www.ema.europa.eu/</a>.</p></div>"
          },
          "section" : [{
            "title" : "Ohjeet terveydenhuollon ammattilaiselle",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029921"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Ohjeet terveydenhuollon ammattilaiselle</h2><p>Remicade-hoitoa saaville potilaille pitää antaa potilaskortti.</p><p><strong><em>Käyttö- ja käsittelyohjeet – säilytysolosuhteet</em></strong></p><p>Säilytä 2°C−8°C:ssa.</p><p>Remicade voidaan säilyttää enintään 25°C:ssa yhden enintään 6 kuukauden pituisen jakson ajan, mutta niin, että alkuperäinen viimeinen käyttöpäivämäärä ei ylity. Uusi viimeinen käyttöpäivämäärä on kirjoitettava koteloon. Jääkaappisäilytyksestä poiston jälkeen Remicadea ei saa laittaa takaisin jääkaappisäilytykseen.</p><p><strong><em>Käyttö- ja käsittelyohjeet – sekoittaminen, laimentaminen ja antaminen</em></strong></p><p>Biologisten lääkkeiden jäljitettävyyden parantamiseksi annetun lääkevalmisteen kauppanimi ja eränumero on kirjattava selvästi.</p><ol><li>Laske tarvittava annos ja tarvittavien Remicade-injektiopullojen määrä. Yksi Remicade-injektiopullo sisältää 100 mg infliksimabia. Laske vaadittavan käyttövalmiin Remicade-liuoksen kokonaismäärä.<br/></li><li>Jokaisen Remicade-injektiopullon sisältö tehdään käyttövalmiiksi aseptisissa olosuhteissa liuottamalla 10 ml:aan injektionesteisiin käytettävää vettä käyttäen ruiskua, jossa on 21 G:n (0,8 mm) tai pienempi neula. Repäise injektiopullon alumiininen suojus pois ja pyyhi korkki 70 %:lla alkoholilla kostutetulla pyyhkeellä. Työnnä ruiskun neula injektiopulloon kumitulpan keskiosan läpi ja ohjaa injektionesteisiin käytettävä vesi injektiopullon sisäpintaan. Heiluta liuosta kevyesti pyörittämällä injektiopulloa, jotta kylmäkuivattu kuiva-aine liukenee. Vältä pitkittynyttä tai voimakasta sekoittamista. ÄLÄ RAVISTA. Käyttöön valmistamisen yhteydessä liuokseen muodostuu usein vaahtoa. Anna käyttöön valmistetun liuoksen seistä 5 minuuttia. Tarkista, että liuos on väritöntä tai vaalean kellertävää ja opaalinhohtoista. Koska infliksimabi on proteiini, liuokseen saattaa muodostua joitakin pieniä läpinäkyviä hiukkasia. Mikäli samentumia, värin muuttumista tai muita vieraita hiukkasia havaitaan, liuosta ei saa käyttää.<br/></li><li>Liuota koko määrä käyttöön valmistettua Remicade-liuosta 250 ml:aan 9 mg/ml (0,9 %) natriumkloridi-infuusionestettä. Älä laimenna käyttöön valmistettua Remicade-liuosta millään muulla laimennusnesteellä. Laimennoksen voit tehdä siten, että otat käyttöön valmistetun Remicade-liuoksen verran 9 mg/ml (0,9 %) natriumkloridi-infuusionestettä pois 9 mg/ml (0,9 %) natriumkloridi-infuusionestettä sisältävästä 250 ml:n lasipullosta tai infuusiopussista. Lisää käyttöön valmistetun Remicade-liuoksen koko määrä hitaasti 250 ml:n infuusiopulloon tai -pussiin. Sekoita kevyesti. Jos tilavuus on yli 250 ml, käytä joko isompaa infuusiopussia (esim. 500 ml tai 1 000 ml) tai useampaa 250 ml:n infuusiopussia. Tällä varmistetaan, ettei infuusioliuoksen pitoisuus ylitä 4 mg/ml. Jos infuusioliuos on säilytetty jääkaapissa käyttökuntoon saattamisen ja laimentamisen jälkeen, sen on annettava lämmetä huoneenlämmössä 25°C:seen 3 tunnin ajan ennen vaihetta 4 (infuusio). Säilytys yli 24 tuntia 2°C–8°C:ssa koskee ainoastaan Remicaden käyttöön valmistamista infuusionestepussissa.<br/></li><li>Anna infuusioliuos vähintään sen kestoisena, kuin suositellaan. Käytä ainoastaan infuusiolaitteistoa, jossa on letkuun liitetty steriili, pyrogeeniton, vähän proteiineja sitova suodatin (huokoskoko 1,2 mikrometriä tai pienempi). Koska valmisteessa ei ole säilytysainetta, on suositeltavaa, että infuusioliuoksen antaminen aloitetaan mahdollisimman pian ja enintään 3 tunnin kuluttua käyttövalmiiksi sekoittamisesta ja laimentamisesta. Jos valmistetta ei käytetä välittömästi, säilytysaika ja -olosuhteet ennen käyttöä ovat käyttäjän vastuulla eivätkä tavallisesti saisi ylittää 24 tuntia 2°C–8°C:ssa, ellei käyttökuntoon saattamista/laimennusta ole tehty valvotuissa ja validoiduissa aseptisissa olosuhteissa. Älä säilytä jäljelle jäävää infuusioliuosta uudelleenkäyttöä varten.<br/></li><li>Fysikaalisia, biokemiallisia yhteensopivuustutkimuksia, joissa arvioidaan Remicaden antamista samanaikaisesti muiden aineiden kanssa, ei ole tehty. Älä infusoi Remicadea saman suonensisäisen linjan kautta muiden aineiden kanssa.<br/></li><li>Tarkasta Remicade silmämääräisesti vieraiden hiukkasten ja värimuutosten havaitsemiseksi ennen lääkkeen antamista. Älä käytä liuosta, jos huomaat selviä samentumia, värin muuttumista tai vieraita hiukkasia.<br/></li><li>Käyttämätön valmiste tai jäte on hävitettävä paikallisten vaatimusten mukaisesti.</li></ol></div>"
            }
          },
          {
            "title" : "Tekstin muuttamispäivämäärä",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Tekstin muuttamispäivämäärä</h2>22.09.2022</div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/IBD-MPD-21",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "IBD-MPD-21",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_IBD-MPD-21\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition IBD-MPD-21</b></p><a name=\"IBD-MPD-21\"> </a><a name=\"hcIBD-MPD-21\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_D50B98BD-030D-461D-A35D-17E101E1396B</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Remicade pulv til kons til inf væske, oppl 100 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_D50B98BD-030D-461D-A35D-17E101E1396B"
      }],
      "name" : [{
        "productName" : "Remicade pulv til kons til inf væske, oppl 100 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/IBD-PPD-22",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "IBD-PPD-22",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_IBD-PPD-22\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition IBD-PPD-22</b></p><a name=\"IBD-PPD-22\"> </a><a name=\"hcIBD-PPD-22\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_359EDC49-19B2-4933-84B2-61F473D0A002, <code>https://farmalogg.no/varenummer</code>/063187, <code>https://pharmaca.fi/vnr</code>/063187</p><p><b>name</b>: Remicade pulv til kons til inf væske, oppl 100 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK82671.html#MedicinalProductDefinition_IBD-MPD-21\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_D50B98BD-030D-461D-A35D-17E101E1396B</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_359EDC49-19B2-4933-84B2-61F473D0A002"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "063187"
      },
      {
        "system" : "https://pharmaca.fi/vnr",
        "value" : "063187"
      }],
      "name" : "Remicade pulv til kons til inf væske, oppl 100 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-21"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/IBD-PPD-23",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "IBD-PPD-23",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_IBD-PPD-23\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition IBD-PPD-23</b></p><a name=\"IBD-PPD-23\"> </a><a name=\"hcIBD-PPD-23\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_C204F161-C434-4A8C-83E0-4152B0FABFCE, <code>https://farmalogg.no/varenummer</code>/575787, <code>https://pharmaca.fi/vnr</code>/575787</p><p><b>name</b>: Remicade pulv til kons til inf væske, oppl 100 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK82671.html#MedicinalProductDefinition_IBD-MPD-21\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_D50B98BD-030D-461D-A35D-17E101E1396B</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_C204F161-C434-4A8C-83E0-4152B0FABFCE"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "575787"
      },
      {
        "system" : "https://pharmaca.fi/vnr",
        "value" : "575787"
      }],
      "name" : "Remicade pulv til kons til inf væske, oppl 100 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-21"
      }]
    }
  }]
}

```
