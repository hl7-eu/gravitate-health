# Glimepirida Generis - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Glimepirida Generis**

## Example Composition: Glimepirida Generis

Language: pt

Profile: [Composition (ePI)](http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html)

> **HtmlElementLink**
* elementClass: pregnancyCategory
* concept: Pregnancy

**identifier**: `https://infarmed.pt/INFOMED/fi`/Glimepirida-Generis

**status**: Final

**type**: 100000155538

**category**: Processed

**date**: 2022-11-14

**author**: [Organization Infarmed](Organization-Infarmed.md)

**title**: Glimepirida Generis



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "PT-Glimepirida-Generis-1-processed-composition",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
  },
  "language" : "pt",
  "extension" : [{
    "extension" : [{
      "url" : "elementClass",
      "valueString" : "pregnancyCategory"
    },
    {
      "url" : "concept",
      "valueCodeableReference" : {
        "concept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "77386006",
            "display" : "Pregnancy"
          }]
        }
      }
    }],
    "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
  }],
  "identifier" : [{
    "system" : "https://infarmed.pt/INFOMED/fi",
    "value" : "Glimepirida-Generis"
  }],
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
      "code" : "100000155538"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
      "code" : "P",
      "display" : "Processed"
    }]
  }],
  "subject" : [{
    "reference" : "MedicinalProductDefinition/MPD-619944"
  }],
  "date" : "2022-11-14",
  "author" : [{
    "reference" : "Organization/Infarmed"
  }],
  "title" : "Glimepirida Generis",
  "section" : [{
    "title" : "Folheto informativo: Informação para o utilizador",
    "code" : {
      "coding" : [{
        "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
        "code" : "200000029894"
      }]
    },
    "text" : {
      "status" : "additional",
      "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h1>Folheto informativo: Informação para o utilizador</h1><h2>Glimepirida Generis 1 mg comprimidos</h2><h2>Glimepirida Generis 2 mg comprimidos</h2><h2>Glimepirida Generis 3 mg comprimidos</h2><h2>Glimepirida Generis 4 mg comprimidos</h2><h3>Glimepirida</h3></div>"
    },
    "section" : [{
      "title" : "Leia com atenção todo este folheto antes de começar a tomar este medicamento, pois contém informação importante para si.",
      "code" : {
        "coding" : [{
          "system" : "https://gravitatehealth.eu/section",
          "code" : "rules"
        }]
      },
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Leia com atenção todo este folheto antes de começar a tomar este medicamento, pois contém informação importante para si.</h2><div class=\"paragraph\"><ul><li>Conserve este folheto. Pode ter necessidade de o ler novamente. Caso ainda tenha dúvidas, fale com o seu médico ou farmacêutico.</li><li>Este medicamento foi receitado apenas para si. Não deve dá-lo a outros. O medicamento pode ser-lhes prejudicial mesmo que apresentem os mesmos sinais de doença.</li><li>Se tiver quaisquer efeitos indesejáveis, incluindo possíveis efeitos indesejáveis não indicados neste folheto, fale com o seu médico ou farmacêutico. Ver secção 4.</li></ul></div></div>"
      }
    },
    {
      "title" : "O que contém este folheto:",
      "code" : {
        "coding" : [{
          "system" : "https://gravitatehealth.eu/section",
          "code" : "toc"
        }]
      },
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\"><ol><li>O que é Glimepirida Generis e para que é utilizado</li><li>O que precisa de saber antes de tomar Glimepirida Generis 3. Como tomar Glimepirida Generis</li><li>Efeitos indesejáveis possíveis</li><li>Como conservar Glimepirida Generis</li><li>Conteúdo da embalagem e outras informações</li></ol></div></div>"
      }
    },
    {
      "title" : "1. O que é Glimepirida Generis e para que é utilizado",
      "code" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
          "code" : "200000029895"
        }]
      },
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Glimepirida Generis é um medicamento ativo por via oral que baixa o nível de açúcar no sangue. Este medicamento pertence a um grupo de medicamentos que baixam o nível de açúcar no sangue chamados sulfonilureias. Glimepirida Generis atua aumentando a quantidade de insulina libertada pelo seu pâncreas. A insulina baixa os seus níveis de açúcar no sangue.</div><div class=\"paragraph\">Para que é utilizado Glimepirida Generis:</div><div class=\"paragraph\">Glimepirida Generis é usado para tratar uma certa forma de diabetes (diabetes mellitus tipo 2) quando a dieta, o exercício físico e a perda de peso por si só não são capazes de controlar os seus níveis de açúcar no sangue.</div></div>"
      }
    },
    {
      "title" : "2. O que precisa de saber antes de tomar Glimepirida Generis",
      "code" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
          "code" : "200000029896"
        }]
      },
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div><h3>Não tome Glimepirida Generis:</h3><div class=\"paragraph\"><ul><li>se tem alergia à glimepirida ou outras sulfonilureias (medicamentos usados para diminuir o seu nível de açúcar no sangue, tal como a glibenclamida) ou sulfonamidas (medicamentos usados para infeções bacterianas, tal como o sulfametoxazol) ou a qualquer outro componente deste medicamento (indicados na secção 6)</li><li>se tem diabetes insulinodependente (diabetes mellitus tipo 1)</li><li>se tem cetoacidose diabética (uma complicação da diabetes em que os níveis de ácido estão aumentados no seu organismo e em que poderá ter alguns dos seguintes sinais: cansaço, mal-estar (náuseas), elevada frequência urinária e rigidez muscular)</li><li>se está em coma diabético</li><li>se tem doença grave nos rins</li><li>se tem doença grave no fígado.</li></ul></div><div class=\"paragraph\">Não tome este medicamento se alguma das situações acima se aplica a si. Se não tem a certeza, fale com o seu médico ou farmacêutico antes de tomar Glimepirida Generis.</div></div><div><h3>Advertências e precauções</h3><div class=\"paragraph\">Fale com o seu médico ou farmacêutico antes de tomar Glimepirida Generis se:<br/>Está a recuperar de uma ferida, operação, infeções com febre ou de outras formas de stress, informe o seu médico, uma vez que pode ser necessário uma mudança temporária do tratamento<br/>Tem uma alteração grave no fígado ou nos rins.</div><div class=\"paragraph\">Se não tiver a certeza se alguma das situações descritas se aplica a si, fale com o seu médico ou farmacêutico antes de tomar Glimepirida Generis.</div><div class=\"paragraph\">A diminuição do nível de hemoglobina e a quebra dos glóbulos vermelhos do sangue (anemia hemolítica) pode ocorrer em doentes sem a enzima glucose-6-fosfato desidrogenase.</div><div class=\"paragraph\">A informação disponível sobre uso de Glimepirida Generis em pessoas com menos de 18 anos de idade é limitada. Assim, a utilização nestes doentes não é recomendada.</div><span class=\"inline-title\">Informação importante sobre hipoglicemia (nível baixo de açúcar no sangue)</span><div class=\"paragraph\">Quando toma Glimepirida Generis, pode ter hipoglicemia (nível baixo de açúcar no sangue). Por favor ver abaixo a informação adicional sobre hipoglicemia, os seus sinais e tratamento.</div><span class=\"inline-title\">Os seguintes fatores podem aumentar o risco de ter hipoglicemia:</span><div class=\"paragraph\"><ul><li>Subnutrição, refeições irregulares, falhadas ou atrasadas, ou períodos de jejum Alterações da dieta</li><li>Tomar mais Glimepirida Generis do que o necessário Rins que não funcionem corretamente</li><li>Doença grave no fígado.</li><li>Se sofre de alterações particulares induzidas por hormonas (alterações das glândulas da tiroide, da glândula pituitária e do córtex adrenal)</li><li>Beber álcool (especialmente quando falha uma refeição).</li><li>Tomar outros medicamentos (ver &quot;Outros medicamentos e Glimepirida Generis&quot; abaixo).</li><li>Se aumentar a quantidade de exercício e não comer o suficiente, ou comer alimentos com menos hidratos de carbono do que o habitual.</li></ul></div><span class=\"inline-title\">Os sinais da hipoglicemia incluem:</span><div class=\"paragraph\">Sensação de fome, dores de cabeça, náuseas, vómitos, apatia, sonolência, perturbação do sono, inquietude, agressividade, problemas de concentração, diminuição do sentido de alerta e do tempo de reação, depressão, confusão, perturbações da fala e da visão, discurso desarticulado, tremor, paralisia parcial, tonturas, sensação de desespero.</div><div class=\"paragraph\">Os seguintes sinais também podem ocorrer: suor, pele húmida, ansiedade, batimento cardíaco rápido ou aumentado, pressão arterial elevada, palpitações, dor forte súbita no peito que pode irradiar para as áreas vizinhas (angina de peito e arritmias cardíacas).</div><div class=\"paragraph\">Se os níveis de açúcar no sangue continuarem a descer, pode sentir-se consideravelmente confuso (delírio), desenvolver convulsões, perder o autocontrolo, a respiração pode ser pouco profunda e o seu batimento cardíaco desacelerar, pode ficar inconsciente. A situação clínica de uma descida grave de açúcar no sangue pode parecer a de um enfarte.</div><span class=\"inline-title\">Tratar a hipoglicemia:</span><div class=\"paragraph\">Na maioria dos casos, os sinais de redução do nível de açúcar no sangue desaparecem muito rápido quando consome alguma forma de açúcar, como por exemplo cubos de açúcar, sumo doce e chá açucarado.<br/>Deve por isso levar sempre consigo alguma forma de açúcar (como por exemplo cubos de açúcar). Lembre-se que os adoçantes artificiais não são eficazes. Por favor contacte o seu médico ou vá ao hospital se a toma de açúcar não ajudar ou se os sintomas voltarem.</div><span class=\"inline-title\">Testes laboratoriais</span><div class=\"paragraph\">O nível de açúcar no seu sangue ou urina deve ser verificado com regularidade. O seu médico poderá também pedir exames sanguíneos para monitorizar os níveis das células sanguíneas e a função do fígado.</div><div class=\"paragraph\">Crianças e adolescentes<br/>O uso de Glimepirida Generis não é recomendado em crianças com menos de 18 anos de idade.</div></div><div><h3>Outros medicamentos e Glimepirida Generis</h3><div class=\"paragraph\">Informe o seu médico ou farmacêutico se estiver a tomar, ou tiver tomado recentemente, ou se vier a tomar outros medicamentos.</div><div class=\"paragraph\">O seu médico poderá querer alterar a sua dose de Glimepirida Generis se estiver a tomar outros medicamentos que podem aumentar ou diminuir o efeito de Glimepirida Generis no nível de açúcar no seu sangue.</div><div class=\"paragraph\">Os seguintes medicamentos podem aumentar o efeito que Glimepirida Generis tem na redução do nível de açúcar no sangue. Isto pode levar ao risco de hipoglicemia (nível baixo de açúcar no sangue):<ul><li>Outros medicamentos para tratar a diabetes mellitus (tal como a insulina ou metformina).</li><li>Medicamentos para tratar a dor e inflamação (fenilbutazona, azapropazona, oxifenobutazona, medicamentos semelhantes à aspirina).</li><li>Medicamentos para tratar infeções urinárias (tal como algumas sulfonamidas de ação prolongada).</li><li>Medicamentos para tratar infeções bacterianas e fúngicas (tetraciclinas, cloranfenicol, fluconazol, miconazol, quinolonas, claritromicina).</li><li>Medicamentos que inibem a coagulação do sangue (derivados cumarínicos como a varfarina).</li><li>Medicamentos que suportam a formação de músculo (anabólicos). Medicamentos usados para substituição de hormonas sexuais masculinas.</li></ul></div><div class=\"paragraph\"><ul><li>Medicamentos para tratar a depressão (fluoxetina, inibidores da MAO). Medicamentos que baixam os níveis elevados de colesterol no sangue (fibratos). Medicamentos que baixam a pressão arterial elevada (inibidores da ECA).</li><li>Medicamentos chamados antiarritmicos, usados no controlo do batimento cardíaco anormal (disopiramida).</li><li>Medicamentos para tratar a gota (alopurinol, probenecida, sulfinpirazona). Medicamentos para tratar o cancro (ciclofosfamida, ifosfamidas, trofosfamida). Medicamentos usados para reduzir peso (fenfluramina).</li><li>Medicamentos que aumentam a circulação quando administrados numa dose elevada por perfusão intravenosa (pentoxifilina).</li><li>Medicamentos para tratar alergias nasais tal como a febre dos fenos (tritoqualina). Medicamentos chamados simpaticolíticos para tratar a pressão arterial elevada, insuficiência cardíaca ou sintomas da próstata.</li></ul></div><div class=\"paragraph\">Os seguintes medicamentos podem diminuir o efeito que Glimepirida Generis tem na redução do nível de açúcar no sangue. Isto pode levar ao risco de hiperglicemia (nível elevado de açúcar no sangue):<ul><li>Medicamentos que contêm hormonas sexuais femininas (estrogéneos e progestagéneos).</li><li>Medicamentos usados para tratar a pressão arterial elevada e que promovem a produção de urina (diuréticos tiazídicos).</li><li>Medicamentos usados para estimular a glândula tiroideia (tal como a levotiroxina). Medicamentos para tratar alergias e inflamação (glucocorticoides).</li><li>Medicamentos para tratar perturbações mentais graves (cloropromazina e outros derivados fenotiazínicos).</li><li>Medicamentos usados para aumentar o batimento cardíaco, para tratar a asma ou a congestão nasal, tosse ou constipação, usados para reduzir o peso, ou usados em emergências de risco de vida (adrenalina e simpaticomiméticos).</li><li>Medicamentos para tratar o nível elevado de colesterol (ácido nicotínico). Medicamentos para tratar a obstipação quando são usados a longo prazo (laxantes). Medicamentos para tratar crises epiléticas (fenitoína).</li><li>Medicamentos para tratar problemas de nervosismo e de sono (barbitúricos). Medicamentos usados para tratar o aumento de pressão ocular (acetazolamida). Medicamentos usados para tratar a pressão arterial elevada ou diminuir o açúcar no sangue (diazóxido).</li><li>Medicamentos usados para tratar infeções, tuberculose (rifampicina).</li><li>Medicamentos usados para tratar situações graves de níveis baixos de açúcar no sangue (glucagom).</li></ul></div><div class=\"paragraph\">Os seguintes medicamentos podem aumentar ou diminuir o efeito que Glimepirida Generis tem na redução do nível de açúcar no sangue:<ul><li>Medicamentos para tratar úlceras do estômago (chamados antagonistas H2). Medicamentos usados para tratar pressão arterial elevada ou insuficiência cardíaca, tais como bloqueadores beta, clonidina, guanetidina e reserpina. Estes podem também esconder sinais de hipoglicemia, pelo que é necessário um cuidado especial ao tomar estes medicamentos.</li></ul></div><div class=\"paragraph\">Glimepirida Generis pode aumentar ou diminuir os efeitos dos seguintes medicamentos:<ul><li>Medicamentos que inibem a coagulação sanguínea (derivados cumarínicos como a varfarina).</li><li>Colesevelam, um medicamento utilizado para reduzir o colesterol, tem um efeito sobre a absorção de Glimepirida Generis. Para evitar este efeito, deve ser aconselhado a tomar Glimepirida Generis pelo menos 4 horas antes de colesevelam.</li></ul></div></div><div><h3>Glimepirida Generis com alimentos, bebidas e álcool</h3><div class=\"paragraph\">A ingestão de álcool pode aumentar ou diminuir a ação que Glimepirida Generis tem na redução do nível de açúcar no sangue de uma forma imprevisível.</div></div><div class=\"pregnancyCategory\"><h3>Gravidez, amamentação e fertilidade</h3><div class=\"paragraph\"><i>Gravidez</i><br/>Glimepirida Generis não deve ser tomado durante a gravidez. Se está grávida, se pensa estar grávida ou planeia engravidar, informe o seu médico.<br/><i>Amamentação</i><br/>Glimepirida Generis pode passar para o leite materno. Glimepirida Generis não deve ser utilizado durante a amamentação.</div><div class=\"paragraph\">Consulte o seu médico ou farmacêutico antes de tomar qualquer medicamento.</div></div><div><h3>Condução de veículos e utilização de máquinas</h3><div class=\"paragraph\">A sua capacidade de concentração e de reação pode estar reduzida se o seu nível de açúcar no sangue diminuir (hipoglicemia) ou aumentar (hiperglicemia) ou se desenvolver problemas visuais como resultado destas condições. Tenha em mente que se pode magoar a si próprio ou aos outros (como por exemplo ao conduzir um carro ou a utilizar máquinas). Por favor pergunte ao seu médico se pode conduzir um carro se:<ul><li>tem episódios frequentes de hipoglicemia,</li><li>tem poucos ou nenhuns sinais de hipoglicemia</li></ul></div></div><div><h3>Glimepirida Generis contém lactose</h3><div class=\"paragraph\">Se foi informado pelo seu médico que tem intolerância a alguns açúcares, contacte-o antes de tomar este medicamento.</div></div><div><h3>Glimepirida Generis contém sódio</h3><div class=\"paragraph\">Este medicamento contém menos do que 1 mmol (23 mg) de sódio por comprimido, ou seja, é praticamente &quot;isento de sódio&quot;.</div></div></div>"
      }
    },
    {
      "title" : "3. Como tomar Glimepirida Generis",
      "code" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
          "code" : "200000029905"
        }]
      },
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Tome este medicamento exatamente como indicado pelo seu médico ou farmacêutico. Fale com o seu médico ou farmacêutico se tiver dúvidas.</div><span class=\"inline-title\">Ao tomar este medicamento</span><div class=\"paragraph\">Tome este medicamento pela boca, mesmo antes ou durante a primeira refeição principal do dia (normalmente o pequeno almoço). Se não tomar o pequeno-almoço deve tomar o medicamento no horário prescrito pelo seu médico. É importante não falhar nenhuma refeição enquanto está a tomar Glimepirida Generis<br/>Engula os comprimidos inteiros com pelo menos metade de um copo de água. Não esmague ou mastigue os comprimidos</div><span class=\"inline-title\">Que quantidade tomar</span><div class=\"paragraph\">A dose de Glimepirida Generis depende das suas necessidades, condição e resultados das análises ao açúcar no sangue e urina e é determinada pelo seu médico. Não tome mais comprimidos que os prescritos pelo seu médico.<ul><li>A dose inicial recomendada é de um comprimido de Glimepirida Generis 1 mg uma vez por dia.</li><li>Se necessário, o seu médico pode aumentar a dose após cada 1 a 2 semanas de tratamento.</li><li>A dose máxima recomendada é de 6 mg de Glimepirida Generis por dia.</li><li>Pode ser iniciada uma terapêutica de combinação da glimepirida com metformina ou da glimepirida com insulina. Neste caso, o seu médico irá determinar as doses adequadas de glimepirida, metformina ou insulina individualmente para si.</li><li>A sua dose de Glimepirida Generis pode precisar de ser alterada se mudar de peso, mudar o seu estilo de vida ou se estiver numa situação de stress. Fale com o seu médico se alguma destas situações de aplica a si.</li><li>Se sentir que o efeito do seu medicamento é demasiado fraco ou demasiado forte não altere a dose sozinho, mas fale com o seu médico.</li></ul></div></div>"
      },
      "section" : [{
        "title" : "Se tomar mais Glimepirida Generis do que deveria",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029907"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Se acontecer tomar demasiado Glimepirida Generis ou uma dose adicional há um perigo de hipoglicemia (sinais de hipoglicemia ver Secção 2 - Advertências e precauções) e por isso deve consumir imediatamente açúcar suficiente (como por exemplo cubos de açúcar, sumo doce, chá açucarado) e informar um médico imediatamente. Ao tratar a hipoglicemia devido à toma acidental em crianças, a quantidade de açúcar a dar deve ser controlada cuidadosamente para evitar a possibilidade de produzir uma situação perigosa de hiperglicemia. Não deve ser dada comida ou bebida às pessoas em estado de inconsciência.</div><div class=\"paragraph\">Uma vez que o estado de hipoglicemia pode durar algum tempo, é muito importante que o doente seja cuidadosamente monitorizado até não haver mais perigo. O internamento no hospital pode ser necessário como medida de precaução. Mostre ao médico a embalagem ou os comprimidos que faltam, para que o médico saiba o que foi tomado.</div><div class=\"paragraph\">Casos graves de hipoglicemia acompanhados de perda de conciência e falência neurológica grave são casos de emergência médica que requerem tratamento médico imediato e internamento no hospital. Deve ser assegurado que há sempre uma pessoa pré-informada que pode chamar um médico no caso de emergência.</div></div>"
        }
      },
      {
        "title" : "Caso se tenha esquecido de tomar Glimepirida Generis",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029908"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Não tome uma dose a dobrar para compensar uma dose que se esqueceu de tomar.</div></div>"
        }
      },
      {
        "title" : "Se parar de tomar Glimepirida Generis",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029909"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Se interromper ou parar o tratamento, deve estar alerta de que o efeito desejado de diminuir o açúcar no sangue não é alcançado e que a doença se pode deteriorar de novo. Continue a tomar Glimepirida Generis até o médico lhe dizer para parar.</div><div class=\"paragraph\">Caso ainda tenha dúvidas sobre a utilização deste medicamento, fale com o seu médico ou farmacêutico.</div></div>"
        }
      }]
    },
    {
      "title" : "4. Efeitos indesejáveis possíveis",
      "code" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
          "code" : "200000029910"
        }]
      },
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Como todos os medicamentos, este medicamento pode causar efeitos indesejáveis, embora estes não se manifestem em todas as pessoas.</div><span class=\"inline-title\">Diga ao seu médico imediatamente se tiver algum dos seguintes sintomas:</span><div class=\"paragraph\"><ul><li>Reações alérgicas (incluindo inflamação dos vasos sanguíneos, geralmente com erupção na pele) que podem evoluir para reações graves com dificuldade de respirar, queda da pressão arterial e por vezes progressão até ao choque.</li><li>Fígado com função anormal incluindo amarelecimento da pele e olhos (icterícia), problemas com a circulação da bílis (colestase), inflamação do fígado (hepatite) ou falência do fígado.</li><li>Alergia (hipersensibilidade) da pele, tal como comichão, erupção cutânea, urticária e aumento da sensibilidade ao sol. Algumas reações ligeiras podem evoluir para reações graves.</li><li>Hipoglicemia grave incluindo perda de conciência, epilepsia ou coma.</li></ul></div><div class=\"paragraph\">Alguns doentes experienciaram os seguintes efeitos adversos ao tomar Glimepirida Generis:</div><span class=\"inline-title\">Efeitos indesejáveis raros (podem afetar até 1 em cada 1 000 pessoas)</span><div class=\"paragraph\"><ul><li>Nível de açúcar no sangue mais baixo que o normal (hipoglicemia) (Ver Secção 2 - Advertências e precauções).</li><li>Diminuição do número de células sanguíneas:<ul><li>Plaquetas sanguíneas (o que aumenta o risco de hemorragia ou nódoas negras).</li><li>Glóbulos brancos (o que torna as infeções mais prováveis).</li><li>Glóbulos vermelhos (o que pode tornar a pele mais pálida e causar fraqueza ou dificuldade em respirar).</li></ul></li></ul>Estes problemas geralmente melhoram depois de parar de tomar Glimepirida Generis.</div><span class=\"inline-title\">Efeitos indesejáveis muito raros (podem afetar até 1 em cada 10 000 pessoas)</span><div class=\"paragraph\"><ul><li>Reações alérgicas (incluindo inflamação dos vasos sanguíneos, geralmente com erupção na pele) que podem evoluir para reações graves com dificuldade de respirar, queda da pressão arterial e por vezes progressão até ao choque. Se tiver algum destes sintomas, informe o seu médico imediatamente</li><li>Fígado com função anormal, incluindo amarelecimento da pele e olhos (icterícia), problemas com a circulação da bílis (colestase), inflamação do fígado (hepatite) ou insuficiência do fígado. Se tiver algum destes sintomas informe o seu médico imediatamente</li><li>Náuseas ou vómitos, diarreia, sentir-se cheio ou inchado e dor abdominal.</li><li>Diminuição do nível de sódio no seu sangue (demonstrado por análises sanguíneas).</li></ul></div><span class=\"inline-title\">Outros efeitos indesejáveis incluem:</span><div class=\"paragraph\"><ul><li>Pode ocorrer alergia (hipersensibilidade) da pele, tal como comichão, erupção cutânea, urticária e aumento da sensibilidade ao sol. Algumas reações ligeiras podem evoluir para reações graves com problemas em engolir e em respirar, inchaço dos lábios, garganta ou língua. Portanto, caso tenha um destes efeitos indesejáveis, informe o seu médico imediatamente</li><li>Podem ocorrer reações alérgicas com sulfonilureias, sulfonamidas ou medicamentos relacionados</li><li>Podem ocorrer problemas com a sua vista quando inicia o tratamento com Glimepirida Generis. Isto é devido a alterações nos seus níveis de açúcar no sangue e deve melhorar em breve.</li></ul></div><div class=\"paragraph\">Aumento das enzimas hepáticas.</div><div class=\"paragraph\">Hemorragias graves ou hematomas sob a pele.</div><span class=\"inline-title\">Comunicação de efeitos indesejáveis</span><div class=\"paragraph\">Se tiver quaisquer efeitos indesejáveis, incluindo possíveis efeitos indesejáveis não indicados neste folheto, fale com o seu médico ou farmacêutico. Também poderá comunicar efeitos indesejáveis diretamente ao INFARMED, I.P., através dos contactos abaixo. Ao comunicar efeitos indesejáveis, estará a ajudar a fornecer mais informações sobre a segurança deste medicamento.</div><div class=\"paragraph\">Sítio da internet: <a href=\"http://www.infarmed.pt/web/infarmed/submissaoram\" title=\"http://www.infarmed.pt/web/infarmed/submissaoram\">http://www.infarmed.pt/web/infarmed/submissaoram</a> (preferencialmente) ou através dos seguintes contactos:<br/>Direção de Gestão do Risco de Medicamentos Parque de Saúde de Lisboa, Av. Do Brasil 53 1749-004 Lisboa<br/>Tel: +351 21 798 73 73<br/>Linha do Medicamento: 800222444 (gratuita) E-mail: <a href=\"mailto:farmacovigilancia@infarmed.pt\" title=\"farmacovigilancia@infarmed.pt\">farmacovigilancia@infarmed.pt</a></div></div>"
      }
    },
    {
      "title" : "5. Como conservar Glimepirida Generis",
      "code" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
          "code" : "200000029913"
        }]
      },
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Manter este medicamento fora da vista e do alcance das crianças.</div><div class=\"paragraph\">Não utilize este medicamento após o prazo de validade impresso na embalagem exterior, após EXP. O prazo de validade corresponde ao último dia do mês indicado.</div><div class=\"paragraph\">O medicamento não necessita de quaisquer precauções especiais de conservação. Não utilize este medicamento se verificar sinais visíveis de deterioração.</div><div class=\"paragraph\">Não deite fora quaisquer medicamentos na canalização ou no lixo doméstico. Pergunte ao seu farmacêutico como deitar fora os medicamentos que já não utiliza. Estas medidas ajudarão a proteger o ambiente.</div></div>"
      }
    },
    {
      "title" : "6. Conteúdo da embalagem e outras informações",
      "code" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
          "code" : "200000029914"
        }]
      },
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"></div>"
      },
      "section" : [{
        "title" : "Qual a composição de Glimepirida Generis",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029915"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">A substância ativa é glimepirida. Cada comprimido contém 1 mg, 2 mg, 3 mg ou 4 mg de glimepirida.</div><div class=\"paragraph\">Os outros excipientes são: Celulose microcristalina, lactose mono-hidratada, povidona (K 25) amidoglicolato de sódio, estearato de magnésio</div><div class=\"paragraph\">Os comprimidos contêm adicionalmente os seguintes corantes:<ul><li>os comprimidos de 1 mg contêm óxido de ferro vermelho (E172)</li><li>os comprimidos de 3 mg contêm óxido de ferro amarelo (E172)</li><li>os comprimidos de 4 mg contêm laca de alumínio índigo carmim (E132)</li></ul></div></div>"
        }
      },
      {
        "title" : "Qual o aspeto de Glimepirida Generis e conteúdo da embalagem Comprimido.",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029916"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Glimepirida Generis 1mg Comprimidos:</div><div class=\"paragraph\">Comprimidos não revestidos de cor rosa, planos, oblongos, com ranhura de ambos os lados, gravados com “X” e “76” de cada lado da ranhura numa das faces do comprimido e sem gravação na outra face.<br/>O comprimido pode ser dividido em doses iguais.</div><div class=\"paragraph\">Glimepirida Generis 2mg Comprimidos:<br/>Comprimidos não revestidos de cor branca a esbranquiçada, planos, oblongos, com ranhura de ambos os lados, gravados com “Y” e “32” de cada lado da ranhura numa das faces do comprimido e sem gravação na outra face.<br/>O comprimido pode ser dividido em doses iguais.</div><div class=\"paragraph\">Glimepirida Generis 3mg Comprimidos:<br/>Comprimidos não revestidos de cor amarelo-claro, planos, oblongos, com ranhura de ambos os lados, gravados com “Y” e “33” de cada lado da ranhura numa das faces do comprimido e sem gravação na outra face.<br/>O comprimido pode ser dividido em doses iguais.</div><div class=\"paragraph\">Glimepirida Generis 4mg Comprimidos:<br/>Comprimidos não revestidos de cor azul-claro a azul, planos, oblongos, com ranhura de ambos os lados, gravados com “Y” e “34” de cada lado da ranhura numa das faces do comprimido e sem gravação na outra face.<br/>O comprimido pode ser dividido em doses iguais.</div><div class=\"paragraph\">Os comprimidos de Glimepirida Generis encontram-se disponíveis em embalagens blister.</div><div class=\"paragraph\">Dimensão das embalagens:<br/>Glimepirida Generis 1 mg: 20 e 60 comprimidos.<br/>Glimepirida Generis 2 mg, 3 mg, 4 mg: 60 comprimidos.</div><div class=\"paragraph\">É possível que não sejam comercializadas todas as apresentações.</div></div>"
        }
      },
      {
        "title" : "Titular da Autorização de Introdução no Mercado e Fabricante",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029917"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"paragraph\">Generis Farmacêutica, S.A. Rua João de Deus, 19 2700-487 Amadora Portugal</div><span class=\"inline-title\">Fabricante</span><div class=\"paragraph\">APL Swift Services (Malta) Limited HF26, Hal Far Industrial Estate, Hal Far Birzebbugia, BBG 3000<br/>Malta<br/>ou</div><div class=\"paragraph\">Generis Farmacêutica, S.A. Rua João de Deus, 19 2700-487 Amadora Portugal<br/>Este folheto foi revisto pela última vez em</div></div>"
        }
      },
      {
        "title" : "Este folheto foi aprovado pela última vez em 14.11.2022",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029919"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"></div>"
        }
      }]
    }]
  }]
}

```
