# FK40703 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK40703**

## Example Bundle: FK40703

**Composition category:**

**Composition status:**final

### Indlægsseddel: Information til patienten

 

## Indlægsseddel: Information til brugeren

### Remicade® 100 mg pulver til koncentrat til infusionsvæske, opløsning

infliximab

### Læs denne indlægsseddel grundigt, inden du begynder at bruge dette lægemiddel, da den indeholder vigtige oplysninger.

* Gem indlægssedlen. Du kan få brug for at læse den igen.
* Din læge vil også udlevere et patientinformationskort til dig, som indeholder vigtig sikkerhedsinformation, som du skal være opmærksom på før og under din behandling med Remicade.
* Spørg lægen, hvis der er mere, du vil vide.
* Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.
* Kontakt lægen, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se [punkt 4](#Section4).

Se den nyeste indlægsseddel på
[www.indlaegsseddel.dk](https://www.indlaegsseddel.dk).

### Oversigt over indlægssedlen

1. Virkning og anvendelse
1. Det skal du vide, før du får Remicade
1. Sådan får du Remicade
1. Bivirkninger
1. Opbevaring
1. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

 

## 1. Virkning og anvendelse

Remicade indeholder det aktive stof infliximab. Infliximab er et monoklonalt antistof - en type protein, der binder sig til et specifikt mål i kroppen kaldet TNF (tumor nekrose faktor) alfa .

 

Remicade tilhører en medicingruppe kaldet ”TNF-blokkere”. Det bruges til voksne til behandling af følgende betændelsessygdomme:

* Reumatoid arthritis
* Psoriasisarthritis
* Ankyloserende spondylitis (Bekhterevs sygdom)
* Psoriasis.

 

Remicade bruges også til voksne og børn fra 6 år og opefter til behandling af:

* Crohns sygdom
* Colitis ulcerosa.

 

Remicade virker ved selektivt at binde sig til TNF alfa og blokere dets virkning. TNF alfa er involveret i kroppens betændelsesprocesser, så blokering af dette kan mindske betændelsen i din krop.

 

**Reumatoid arthritis**

Reumatoid arthritis er en betændelsessygdom i leddene. Hvis du har aktiv reumatoid arthritis, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade, som du skal tage sammen med et andet lægemiddel, der hedder methotrexat, for at:

* Reducere tegn og symptomer på din sygdom
* Forsinke skaden i dine led
* Forbedre din fysiske funktionsevne.

 

**Psoriasisarthritis**

Psoriasisarthritis er en betændelsessygdom i leddene, almindeligvis ledsaget af psoriasis. Hvis du har aktiv psoriasisarthritis, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade for at:

* Reducere tegn og symptomer på din sygdom
* Forsinke skaden i dine led
* Forbedre din fysiske funktionsevne.

 

**Ankyloserende spondylitis (Bekhterevs sygdom)**

Ankyloserende spondylitis er en betændelsessygdom i rygraden. Hvis du lider af ankyloserende spondylitis, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade for at:

* Reducere tegn og symptomer på din sygdom
* Forbedre din fysiske funktionsevne.

 

**Psoriasis**

Psoriasis er en betændelsessygdom i huden. Hvis du har moderat til svær plaque psoriasis, vil du først få andre lægemidler eller behandlinger, såsom lysterapi. Hvis disse lægemidler eller behandlinger ikke virker godt nok, vil du få Remicade for at reducere tegn og symptomer på din sygdom.

 

**Colitis ulcerosa**

Colitis ulcerosa er en betændelsessygdom i tarmen. Hvis du lider af colitis ulcerosa, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade til behandling af din sygdom.

 

**Crohns sygdom**

Crohns sygdom er en betændelsessygdom i tarmen. Hvis du lider af Crohns sygdom, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade for at:

* Behandle aktiv Crohns sygdom
* Sænke antallet af unormale åbninger (fistler) mellem din tarm og hud, der ikke har kunnet behandles tilfredsstillende med andre lægemidler eller operation.


#### 2. Det skal du vide, før du får Remicade

 

 

## 2. Det skal du vide, før du får Remicade

### Du må ikke få Remicade

* hvis du er allergisk over for infliximab eller et af de øvrige indholdsstoffer i Remicade (angivet i [punkt 6](#Section6)).
* hvis du er allergisk over for proteiner, som stammer fra mus.
* hvis du har tuberkulose (TB) eller en anden alvorlig infektion, såsom lungebetændelse eller blodforgiftning (sepsis).
* hvis du har hjertesvigt i moderat eller svær grad.

 

Du må ikke få Remicade, hvis noget af ovenstående passer på dig. Hvis du er i tvivl, så tal med din læge, før du får Remicade.

### Advarsler og forsigtighedsregler

Kontakt lægen før eller under behandlingen med Remicade, hvis du har:

**Været i behandling med Remicade tidligere**

* Fortæl din læge, hvis du tidligere har været i behandling med Remicade og nu starter behandling med Remicade igen.

Hvis du har holdt pause i Remicade-behandlingen i over 16 uger, er der en højere risiko for at få en allergisk reaktion, når du starter behandlingen igen.

 

**Infektioner**

* Fortæl din læge, før du får Remicade, hvis du har en infektion, også selvom det er en meget let infektion.
* Fortæl din læge, før du får Remicade, hvis du nogensinde har boet eller rejst i et område, hvor infektioner kaldet histoplasmose, kokcidioidomykose eller blastomykose er almindelige. Disse infektioner forårsages af særlige svampetyper, som kan påvirke lungerne eller andre dele af kroppen.
* Du har lettere ved at få infektioner, når du er i behandling med Remicade. Du har en højere risiko, hvis du er 65 år eller derover.
* Disse infektioner kan være alvorlige og indbefatter tuberkulose, infektioner forårsaget af virus, svampe, bakterier eller andre organismer i miljøet samt blodforgiftning, som kan være livstruende.

Fortæl straks din læge, hvis du får tegn på infektion under behandling med Remicade. Tegn inkluderer feber, hoste, influenzalignende symptomer, utilpashed, rød eller ophedet hud, sår eller problemer med tænderne. Din læge kan anbefale en midlertidig pause med Remicade.

 

**Tuberkulose (TB)**

* Det er meget vigtigt, at du fortæller din læge, hvis du nogensinde har haft TB, eller hvis du har været i tæt kontakt med en person, som har eller har haft TB.
* Din læge vil teste dig for at se, om du har TB. Tilfælde af TB har været rapporteret hos patienter i behandling med Remicade, også hos patienter, der allerede har været i behandling med medicin mod TB. Din læge vil notere disse tests på dit patientinformationskort.
* Hvis din læge tror, at du har risiko for at få TB, kan du blive behandlet med lægemidler mod TB, inden du får Remicade.

Fortæl straks din læge, hvis du får tegn på TB under behandlingen med Remicade. Tegn inkluderer vedvarende hoste, vægttab, træthedsfølelse, feber eller natlig svedtendens.

 

**Hepatitis B-virus**

* Fortæl din læge, før du får Remicade, hvis du er bærer af hepatitis B, eller hvis du nogensinde har haft det.
* Fortæl din læge, hvis du tror, du kan have en risiko for at blive smittet med hepatitis B.
* Din læge skal teste dig for hepatitis B.
* Behandling med TNF-blokkere, såsom Remicade, kan medføre, at hepatitis B igen bliver aktiv hos patienter, som bærer denne virus. Dette kan i nogle tilfælde være livstruende.

 

**Hjerteproblemer**

* Fortæl din læge, hvis du har nogen form for hjerteproblemer, såsom let hjertesvigt.
* Din læge vil nøje overvåge dit hjerte.

Fortæl straks din læge, hvis du får nye eller forværrede tegn på hjertesvigt under behandlingen med Remicade. Tegn inkluderer åndenød eller hævede fødder.

 

**Kræft og lymfom**

* Fortæl din læge, før du får Remicade, hvis du har eller nogensinde har haft lymfom (en type blodkræft) eller enhver anden form for kræft.
* Patienter med alvorlig reumatoid arthritis, som har haft sygdommen i lang tid, kan have en større risiko for at udvikle lymfom.
* Børn og voksne i behandling med Remicade kan have en øget risiko for at udvikle lymfom eller anden form for kræft.
* Nogle patienter, som har fået TNF-blokerende behandling, herunder Remicade, har udviklet en sjælden kræftform kaldet hepatosplenisk T-celle-lymfom. Af disse patienter var de fleste teenagedrenge eller unge mænd, hvoraf de fleste havde enten Crohns sygdom eller colitis ulcerosa. Denne type kræft har oftest haft dødelig udgang. Næsten alle patienterne havde også fået medicin, der indeholder azathioprin eller 6- mercaptopurin ud over den TNF-blokerende behandling.
* Nogle patienter, der er blevet behandlet med infliximab, har udviklet visse former for hudkræft. Hvis der er forandringer i huden eller svulster på huden under eller efter behandlingen, skal du fortælle det til lægen.
* Nogle kvinder, der er blevet behandlet for reumatoid arthritis med Remicade, har udviklet livmoderhalskræft. Lægen kan tilråde, at kvinder, der får Remicade, herunder kvinder over 60 år, bliver regelmæssigt screenet for livmoderhalskræft.

 

**Lungesygdom eller højt tobaksforbrug**

* Fortæl din læge, før du får Remicade, hvis du har en lungesygdom kaldet kronisk obstruktiv lungesygdom (KOL, rygerlunger), eller hvis du er storryger.
* Patienter med KOL og patienter, som er storrygere, kan have en øget risiko for at udvikle kræft under behandling med Remicade.

 

**Sygdom i nervesystemet**

* Fortæl din læge, hvis du har eller nogensinde har haft en lidelse, som påvirker dit nervesystem, før du får Remicade. Dette inkluderer dissemineret sklerose, Guillain-Barré syndrom, hvis du har krampeanfald eller har fået stillet diagnosen ”optisk neuritis” (betændelse i synsnerven).

Fortæl straks din læge, hvis du får symptomer på en nervesygdom under behandlingen med Remicade. Tegn inkluderer synsændringer, muskelsvaghed i arme eller ben, følelsesløshed eller prikken et sted i kroppen.

 

**Unormale hudåbninger**

* Fortæl din læge, hvis du har unormale hudåbninger (fistler), før du får Remicade.

 

**Vaccinationer**

* Tal med din læge, hvis du lige er blevet eller har planlagt at blive vaccineret.
* Du skal have de anbefalede vaccinationer, før du starter behandling med Remicade. Der er visse vaccinationer, du kan få, mens du er i behandling med Remicade, men du må ikke få levende vacciner (vacciner der indeholder et levende men svækket smitstof), da de kan give infektioner.
* Hvis du har fået Remicade, mens du var gravid, kan dit barn også have en større risiko for at få en infektion som et resultat af at have fået en levende vaccine i løbet af det første leveår. Det er vigtigt, at du fortæller dit barns læger og andet sundhedspersonale, at du får Remicade, så de kan finde frem til, hvornår dit barn skal vaccineres; det gælder også levende vacciner som BCG-vaccinen (bruges til at forebygge tuberkulose).
* Hvis du ammer, er det vigtigt, at du fortæller dit barns læge eller andet sundhedspersonale, at du har fået Remicade, før barnet bliver vaccineret. Se afsnittet om Graviditet, amning og frugtbarhed for yderligere information.

 

**Terapeutiske smitstoffer**

* Tal med din læge, hvis du fornylig har fået eller det er planlagt, at du skal have behandling med et terapeutisk smitstof (fx instillation af BCG til behandling af kræft).

 

**Operationer eller tandindgreb**

* Fortæl din læge, hvis du skal have foretaget en operation eller et tandindgreb.
* Fortæl kirurgen eller tandlægen, at du er i behandling med Remicade ved at vise dem dit patientinformationskort.

 

**Leverproblemer**

* Nogle patienter, der får Remicade, har udviklet alvorlige leverproblemer.

Fortæl det straks til lægen, hvis du får symptomer på leverproblemer under behandlingen med Remicade. Tegn omfatter gulfarvning af hud og øjne, mørkebrun urin, smerter eller hævelse i øvre højre side af maven, ledsmerter, hududslæt eller feber.

 

**Lave blodtal**

* Hos nogle patienter, som får Remicade, kan kroppen måske ikke lave nok af de blodlegemer, der skal hjælpe med at bekæmpe infektioner eller stoppe blødning.

Fortæl det straks til lægen, hvis du får symptomer på lave blodtal under behandlingen med Remicade. Tegn omfatter vedvarende feber, større tendens til blødning eller blå mærker, små røde eller lilla pletter, der skyldes blødning under huden, eller bleghed.

 

**Sygdomme i immunsystemet**

* Nogle patienter, der får Remicade, har udviklet symptomer på en sygdom i immunsystemet kaldet lupus.

Fortæl det straks til lægen, hvis du får symptomer på lupus under behandlingen med Remicade. Tegn omfatter ledsmerter eller udslæt på kinder eller arme, som er følsomme over for solen.

### Børn og unge

**Ovenstående oplysninger gælder også for børn og unge. Derudover gælder, at:**

* Nogle børn og unge, som har fået TNF-blokkere såsom Remicade, har udviklet kræft inklusive usædvanlige typer kræft, som i visse tilfælde har været dødelige.
* Flere børn end voksne, der får Remicade, fik infektioner.
* Børn skal have de anbefalede vaccinationer, før behandling med Remicade påbegyndes. Børn kan få visse vacciner under behandlingen med Remicade, men må ikke få levende vacciner, mens de får Remicade.

 

Hvis du er i tvivl, om noget af ovenstående passer på dig, skal du tale med din læge, før du får Remicade.

### Brug af anden medicin sammen med Remicade

Patienter, som har betændelsessygdomme, tager allerede medicin for at behandle deres lidelse. Disse lægemidler kan give bivirkninger. Din læge vil rådgive dig om, hvilke andre lægemidler du skal blive ved med at tage, mens du er i behandling med Remicade.

 

Fortæl altid lægen, hvis du bruger anden medicin, for nylig har brugt anden medicin eller planlægger at bruge anden medicin. Dette gælder også medicin til behandling af Crohns sygdom, colitis ulcerosa, reumatoid arthritis, ankyloserende spondylitis, psoriasisarthritis eller psoriasis eller medicin, som ikke er købt på recept, fx vitaminer og naturlægemidler.

Det er specielt vigtigt, at du fortæller din læge, hvis du får nogen af følgende lægemidler:

* Lægemidler som påvirker dit immunsystem.
* Kineret (anakinra). Du må ikke få Remicade og Kineret samtidig.
* Orencia (abatacept). Du må ikke få Remicade og Orencia samtidig.

 

Du må ikke få levende vacciner, mens du får Remicade. Hvis du har fået Remicade, mens du var gravid, eller hvis du får Remicade, mens du ammer, skal du fortælle dit barns læge og andet sundhedspersonale, der tager sig af dit barn, at du har fået Remicade, før barnet bliver vaccineret.

 

Hvis du er i tvivl, om noget af ovenstående passer på dig, skal du tale med din læge eller apotekspersonalet, før du får Remicade.

### Graviditet, amning og frugtbarhed

* Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge til råds, før du får dette lægemiddel. Du må kun få Remicade under graviditeten, eller mens du ammer, hvis lægen finder det nødvendigt.
* Du skal undgå at blive gravid, mens du er i behandling med Remicade, og i mindst 6 måneder efter du er stoppet med behandlingen. Tal med lægen om anvendelse af prævention i denne tidsperiode.
* Hvis du fik Remicade under graviditeten, kan dit barn have en øget risiko for at få en infektion.
* Det er vigtigt, at du fortæller dit barns læge og andet sundhedspersonale, at du har fået Remicade, før barnet bliver vaccineret. Hvis du har fået Remicade under graviditeten, kan vaccination af dit barn med BCG-vaccine (bruges til at forebygge tuberkulose) inden for 12 måneder efter fødslen medføre infektion med alvorlige komplikationer herunder død. Dit barn må ikke få levende vacciner som BCG-vaccinen inden for 12 måneder efter fødslen, medmindre barnets læge anbefaler noget andet. For mere information, se afsnit om vaccination.
* Hvis du ammer, er det vigtigt, at du fortæller dit barns læge eller andet sundhedspersonale, at du har fået Remicade, før barnet bliver vaccineret. Dit barn må ikke få levende vacciner, mens du ammer, medmindre barnets læge anbefaler noget andet.
* Alvorligt fald i antal hvide blodlegemer er set hos spædbørn født af kvinder, der er blevet behandlet med Remicade under graviditeten. Hvis dit barn hyppigt får feber eller infektioner, skal du omgående kontakte barnets læge.

### Trafik- og arbejdssikkerhed

Remicade påvirker sandsynligvis ikke arbejdssikkerheden eller evnen til at færdes sikkert i trafikken. Hvis du føler dig træt, svimmel eller utilpas efter at have fået Remicade, må du ikke køre bil eller betjene nogen form for maskiner.

### Remicade indeholder natrium

Remicade indeholder mindre end 1 mmol natrium (23 mg) pr. dosis, dvs. det er i det væsentlige ”natriumfrit”. Men før du får Remicade, blandes det sammen med en opløsning, som indeholder natrium. Tal med din læge, hvis du er på en diæt med et lavt saltindhold.


#### 3. Sådan får du Remicade

 

 

## 3. Sådan får du Remicade

**Reumatoid arthritis**

Den sædvanlige dosis er 3 mg pr. kg kropsvægt.

 

**Psoriasisarthritis, ankyloserende spondylitis (Bekhterevs sygdom), psoriasis, colitis ulcerosa og Crohns sygdom**

Den sædvanlige dosis er 5 mg pr. kg kropsvægt.

### Sådan får du Remicade

* Du vil få Remicade af din læge eller sygeplejerske.
* Din læge eller sygeplejerske vil klargøre medicinen til infusion.
* Medicinen vil blive givet som en infusion (drop) (over 2 timer) i en af dine blodårer (vener), sædvanligvis i armen. Efter den tredje behandling kan din læge beslutte at give dig din dosis Remicade over 1 time.
* Du vil blive overvåget, mens du får Remicade og i 1-2 timer derefter.

### Den sædvanlige dosis

* Lægen vil bestemme din dosis og hvor ofte, du skal have Remicade. Dette vil afhænge af din sygdom, vægt og hvor godt, du reagerer på Remicade.
* Tabellen nedenfor viser, hvor ofte du sædvanligvis vil få denne medicin efter din første dosis.

 

| | |
| :--- | :--- |
| 2. dosis | 2 uger efter din 1. dosis |
| 3. dosis | 6 uger efter din 1. dosis |
| Efterfølgende doser | Hver 6. til 8. uge afhængig af din sygdom |

 

**Brug til børn og unge**

Remicade må kun anvendes til børn, hvis de behandles for Crohns sygdom eller colitis ulcerosa.

Børnene skal være 6 år eller ældre.

### Hvis du får for meget Remicade

Da du får denne medicin af din læge eller sygeplejerske, er det usandsynligt, at du vil få for meget.

Der kendes ikke til bivirkninger efter at have fået for meget Remicade.

### Hvis du har glemt eller kommer for sent til din Remicade-infusion

Hvis du glemmer eller kommer for sent til en aftale, hvor Remicade gives, skal du lave en ny aftale så hurtigt som muligt.

 

Spørg lægen, hvis der er noget, du er i tvivl om.


#### 4. Bivirkninger

 

 

## 4. Bivirkninger

Dette lægemiddel kan som alle andre lægemidler give bivirkninger, men ikke alle får bivirkninger. De fleste bivirkninger er lette til moderate. Nogle patienter kan dog opleve alvorlige bivirkninger, som kan kræve behandling. Bivirkninger kan også opstå efter ophør af din behandling med Remicade.

### Fortæl straks din læge, hvis du bemærker noget af følgende:

* **Tegn på en allergisk reaktion** såsom hævelse af ansigt, læber, mund eller svælg, som kan forårsage besvær med at synke eller trække vejret, kløende udslæt, hævelse af hænder, fødder eller ankler. Nogle af disse reaktioner kan være alvorlige eller livstruende. En allergisk reaktion kan opstå inden for 2 timer efter din injektion eller senere. Yderligere tegn på allergiske bivirkninger, som kan opstå op til 12 dage efter din injektion, inkluderer muskelsmerter, feber, led- eller kæbesmerter, ondt i halsen eller hovedpine.
* **Tegn på hjerteproblemer** såsom ubehag i brystkassen eller brystsmerter, armsmerter, mavesmerter, åndenød, angst, ørhed, svimmelhed, besvimelse, svedtendens, kvalme (utilpashed), opkastning, skælven eller banken i brystet, hurtigt eller langsomt hjerteslag og hævede fødder.
* **Tegn på infektion (inklusive tuberkulose (TB))** såsom feber, træthedsfølelse, hoste, der kan være vedvarende, åndenød, influenzalignende symptomer, vægttab, natlig svedtendens, diarré, sår, ansamling af pus i tarmen eller omkring anus (absces), tandproblemer eller brændende smerte, når du lader vandet.
* **Mulige tegn på kræft, **inklusive men ikke begrænset til hævede lymfeknuder, vægttab, feber, usædvanlige knuder i huden, ændringer i modermærker eller hudfarven eller usædvanlig blødning fra skeden.
* **Tegn på lungeproblemer** såsom hoste, åndedrætsbesvær eller trykken for brystet.
* **Tegn på et problem i nervesystemet (inklusive øjenproblemer)** såsom tegn på slagtilfælde (pludselig følelsesløshed eller svaghed i ansigt, arme eller ben, særligt i den ene side af kroppen; pludselig forvirring, besvær med at tale eller forstå; besvær med at se med det ene eller begge øjne, gangbesvær, svimmelhed, tab af balance- eller koordinationsevne eller svær hovedpine), krampanfald, prikken/følelsesløshed et sted i kroppen, eller svaghed i arme eller ben, ændringer i synet såsom dobbeltsyn eller andre øjenproblemer.
* **Tegn på leverproblemer **(inklusive hepatitis B-infektion, hvis du tidligere har haft hepatitis B) såsom gulfarvning af hud eller øjne, mørkebrun urin, smerter eller hævelser i øvre højre side af maven, ledsmerter, hududslæt eller feber.
* **Tegn på en sygdom i immunsystemet **såsom ledsmerter, udslæt på kinder eller arme, som er følsomme over for solen (lupus) eller hoste, åndenød, feber eller hududslæt (sarkoidose).
* **Tegn på lave blodtal** såsom vedvarende feber, blødningstendens, tendens til lettere at få blå mærker, små røde eller lilla pletter, der skyldes blødning under huden, eller bleghed.
* **Tegn på alvorlige hudproblemer** såsom rødlige, målskivelignende pletter eller runde områder ofte med blærer centralt på kroppen, store områder med afskalning (eksfoliation) samt sår i mund, svælg, næse, kønsorganer og øjne eller små pusholdige blærer, som kan sprede sig over hele kroppen. Disse hudreaktioner kan være ledsaget af feber.

 

Fortæl straks din læge, hvis du bemærker noget af ovenstående.

### Følgende bivirkninger er observeret med Remicade:

**Meget almindelig: kan forekomme hos flere end 1 ud af 10 personer**

* Mavesmerter, kvalme
* Virusinfektioner såsom herpes eller influenza
* Øvre luftvejsinfektioner såsom bihulebetændelse
* Hovedpine
* Bivirkninger i forbindelse med infusionen
* Smerter.

 

**Almindelig: kan forekomme hos op til 1 ud af 10 personer**

* Ændringer i hvordan din lever fungerer, forhøjede leverenzymer (vist i blodprøver)
* Infektioner i lunger eller luftveje såsom bronkitis eller lungebetændelse
* Besværet eller smertefuldt vejrtrækning, smerter i brystet
* Blødning i mave eller tarme, diarré, fordøjelsesbesvær, halsbrand, forstoppelse
* Nældefeber, kløende udslæt eller tør hud
* Balanceproblemer eller svimmelhed
* Feber, øget svedtendens
* Kredsløbsproblemer såsom for lavt eller for højt blodtryk
* Blå mærker, hedeture eller næseblod, varm, rød hud (rødmen)
* Trætheds- eller svaghedsfølelse
* Bakterieinfektioner såsom blodforgiftning, byld eller infektion under huden (cellulitis)
* Svampeinfektion i huden
* Blodproblemer såsom blodmangel eller lavt antal hvide blodlegemer
* Hævede lymfeknuder
* Depression, problemer med at sove
* Øjenproblemer inklusive røde øjne og øjeninfektioner
* Galoperende hjerte (hurtig puls) eller hjertebanken
* Smerter i leddene, musklerne eller ryggen
* Urinvejsinfektion
* Psoriasis, hudproblemer såsom eksem og hårtab
* Reaktioner på injektionsstedet såsom smerte, hævelse, rødme eller kløe
* Kuldegysninger, hævelse på grund af ophobning af væske under huden
* Følelsesløshed eller en prikkende fornemmelse.

 

**Ikke almindelig: kan forekomme hos op til 1 ud af 100 personer**

* Manglende blodtilførsel, hævelse af en blodåre
* Ansamling af blod uden for blodkarrene (hæmatom) eller blå mærker
* Hudproblemer såsom blæredannelse, vorter, unormal hudfarve eller pigmentering, eller hævede læber, eller fortykkelse af huden eller rød, skællende hud og afskalning af huden
* Alvorlige allergiske reaktioner (fx anafylaksi), en sygdom i immunsystemet kaldet lupus, allergiske reaktioner over for fremmede proteiner
* Længere sårhelingstid
* Hævelse af lever (hepatitis) eller galdeblære, leverskade
* Glemsomhed, irritabilitet, forvirring, nervøsitet
* Øjenproblemer inklusive sløret eller nedsat syn, hævede øjne eller bygkorn
* Debuterende eller forværring af eksisterende hjertesvigt, langsom hjertefrekvens (puls)
* Besvimelse
* Kramper, nerveforstyrrelser
* Hul i tarmen eller blokering af tarmen, mavesmerter eller -kramper
* Hævelse af bugspytkirtlen (bugspytkirtelbetændelse)
* Svampeinfektioner såsom gærsvampeinfektion eller svampeinfektion i neglene
* Lungeproblemer såsom ødemer
* Væske rundt om lungerne (pleuraekssudat)
* Forsnævrede luftveje i lungerne, der giver åndedrætsbesvær
* Lungehindebetændelse, der giver skape smerter, som forværres ved vejrtrækning (pleuritis)
* Tuberkulose
* Nyreinfektioner
* Lavt antal blodplader, for mange hvide blodlegemer
* Infektioner i skeden
* Blodprøveresultater, der viser ‘antistoffer’ mod din egen krop
* Ændringer i kolesterol- og fedtindholdet i blodet.

 

**Sjælden: kan forekomme hos op til 1 ud af 1.000 personer**

* En type blodkræft (lymfom)
* Blodet tilfører ikke nok ilt til kroppen, kredsløbsproblemer såsom indsnævring af et blodkar
* Betændelse i hjernehinderne (meningitis)
* Infektioner, som skyldes nedsat immunforsvar
* Hepatitis B-infektion, hvis du tidligere har haft hepatitis B
* Betændelsestilstand i leveren forårsaget af et problem med immunsystemet (autoimmun hepatitis)
* Leverproblemer, der giver gulfarvning af hud eller øjne (gulsot)
* Unormal vævshævelse eller -vækst
* Alvorlig allergisk reaktion, som kan medføre tab af bevidsthed og kan være livstruende (anafylaktisk shock)
* Hævelse af små blodkar (blodkarbetændelse)
* Immunsystemdefekt, som kan påvirke lunger, hud og lymfekirtler (såsom sarkoidose)
* Ansamling af immunceller som følge af et inflammatorisk respons (granulomatøse læsioner)
* Mangel på interesse eller følelser
* Alvorlige hudproblemer såsom toksisk epidermal nekrolyse, Stevens-Johnsons syndrom og akut generaliseret eksantematøs pustulose
* Andre hudproblemer såsom erythema multiforme, lichenoide reaktioner (kløende, rødligt-lilla hududslæt og/eller trådlignende gråhvide linjer på slimhinderne), blærer og afskalning af huden eller bylder (furunkulose)
* Alvorlige lidelser i nervesystemet såsom transversal myelitis, multipel sklerose-lignende sygdom, optisk neuritis og Guillain-Barrés syndrom
* Øjenbetændelse, der kan forårsage synsforandringer, inklusive blindhed
* Væske omkring hjertet (perikardial effusion)
* Alvorlige lungeproblemer (såsom interstitiel lungesygdom)
* Melanom (en type hudkræft)
* Livmoderhalskræft
* Lave blodtal, herunder svært nedsat antal hvide blodlegemer
* Små røde eller lilla pletter, der skyldes blødning under huden
* Unormale værdier for et protein i blodet kaldet ‘komplementfaktor’, som er en del af immunsystemet.

 

**Ikke kendt: hyppigheden kan ikke estimeres ud fra forhåndenværende data**

* Kræft hos børn og voksne
* En sjælden blodkræft som hovedsageligt rammer teenagedrenge eller unge mænd (hepatosplenisk T-celle-lymfom)
* Leversvigt
* Merkelcellekarcinom (en type hudkræft)
* Kaposis sarkom, en sjælden type kræft, der er forbundet med infektion med humant herpesvirus 8. Kaposis sarkom forekommer oftest som lilla læsioner på huden.
* Forværring af en sygdom der hedder dermatomyositis (muskelsvaghed med hududslæt som følgetilstand)
* Hjerteanfald
* Slagtilfælde
* Midlertidigt synstab under eller inden for 2 timer efter infusionen
* Infektion, der skyldes en levende vaccine, som følge af et svækket immunsystem.

 

**Hos børn og unge ses yderligere følgende bivirkninger:**

De bivirkninger, som børn i behandling med Remicade mod Crohns sygdom fik, var forskellige fra de bivirkninger, som voksne i behandling med Remicade mod Crohns sygdom fik. Følgende bivirkninger forekom hyppigere hos børn: nedsat antal røde blodlegemer (anæmi), blod i afføringen, nedsat samlet indhold af hvide blodlegemer (leukopeni), anfaldsvis ansigtsrødme, virusinfektioner, lavt indhold af hvide blodlegemer, der bekæmper infektion (neutropeni), knoglebrud, bakterieinfektion og allergiske reaktioner i luftvejene.

### Indberetning af bivirkninger

Hvis du oplever bivirkninger, bør du tale med din læge, apotekspersonalet eller sygeplejersken. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via Lægemiddelstyrelsen, Axel Heides Gade 1, DK-2300 København S, Websted: www.meldenbivirkning.dk. Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.

[Meld en bivirkning.](https://www.meldenbivirkning.dk)


#### 5. Opbevaring

 

 

## 5. Opbevaring

Remicade opbevares normalt af sundhedspersonalet. Skulle du få brug for information omkring opbevaring, gælder følgende:

* Opbevar lægemidlet utilgængeligt for børn
* Brug ikke lægemidlet efter den udløbsdato, der står på etiketten og kartonen efter EXP. Udløbsdatoen er den sidste dag i den nævnte måned
* Opbevares i køleskab (2 °C - 8 °C)
* Lægemidlet kan også opbevares i den originale karton uden for køleskab ved højst 25 °C i en enkelt periode på op til 6 måneder, men den oprindelige udløbsdato må ikke overskrides. I denne situation må det ikke sættes tilbage i køleskab. Skriv den nye udløbsdato på æsken med dag/måned/år. Kasser lægemidlet, hvis det ikke er brugt før den nye udløbsdato eller den dato, der er trykt på æsken, alt efter, hvilken dato der kommer først.
* Det anbefales, at Remicade anvendes så hurtigt som muligt (inden for 3 timer), efter det er klargjort til infusion. Hvis opløsningen er klargjort under aseptiske betingelser, kan den dog opbevares i køleskab ved 2 °C - 8 °C i op til 28 dage og i yderligere 24 timer ved 25 °C efter udtagning fra køleskab.
* Brug ikke dette lægemiddel, hvis det er misfarvet, eller hvis det indeholder partikler.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

 

## 6. Pakningsstørrelser og yderligere oplysninger

### Remicade indeholder

* Aktivt stof: infliximab. Hvert hætteglas indeholder 100 mg infliximab. Efter klargøring indeholder hver ml 10 mg infliximab.
* Øvrige indholdsstoffer: saccharose, polysorbat 80, natriumdihydrogenphosphat og dinatriumphosphatdihydrat.

### Udseende og pakningsstørrelser

Remicade leveres som et hætteglas (glasflaske) indeholdende et pulver til koncentrat til infusionsvæske, opløsning. Pulveret er en frysetørret hvid pellet.

Remicade fremstilles i kartoner med 1, 2, 3, 4 eller 5 hætteglas. Ikke alle pakningsstørrelser er nødvendigvis markedsført.


####  

-------

Full name: ****

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK40703",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
    "value" : "40703"
  },
  "type" : "document",
  "timestamp" : "2022-04-22T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK40703-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK40703-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_FK40703-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK40703-COMP</b></p><a name=\"FK40703-COMP\"> </a><a name=\"hcFK40703-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/</code>/40703</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2022-04-22</p><p><b>author</b>: Identifier: <code>https://medicin.dk</code>/medicin.dk</p><p><b>title</b>: Remicade 100 mg pulver til konc. til infusionsvæske</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
        "value" : "40703"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "date" : "2022-04-22",
      "author" : [{
        "identifier" : {
          "system" : "https://medicin.dk",
          "value" : "medicin.dk"
        }
      }],
      "title" : "Remicade 100 mg pulver til konc. til infusionsvæske",
      "section" : [{
        "title" : "Indlægsseddel: Information til patienten",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section0\"/><h2>Indlægsseddel: Information til brugeren</h2><h3>Remicade® 100 mg pulver til koncentrat til infusionsvæske, opløsning</h3><div class=\"paragraph\">infliximab</div><h3>Læs denne indlægsseddel grundigt, inden du begynder at bruge dette lægemiddel, da den indeholder vigtige oplysninger.</h3><ul><li>Gem indlægssedlen. Du kan få brug for at læse den igen.</li><li>Din læge vil også udlevere et patientinformationskort til dig, som indeholder vigtig sikkerhedsinformation, som du skal være opmærksom på før og under din behandling med Remicade.</li><li>Spørg lægen, hvis der er mere, du vil vide.</li><li>Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give medicinen til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.</li><li>Kontakt lægen, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se <a href=\"#Section4\" title=\"Anchor link til afsnit - punkt 4\">punkt 4</a>.</li></ul><div class=\"paragraph\">Se den nyeste indlægsseddel på <a href=\"https://www.indlaegsseddel.dk\" title=\"null\">www.indlaegsseddel.dk</a>.</div><h3>Oversigt over indlægssedlen</h3><ol><li>Virkning og anvendelse</li><li>Det skal du vide, før du får Remicade</li><li>Sådan får du Remicade</li><li>Bivirkninger</li><li>Opbevaring</li><li>Pakningsstørrelser og yderligere oplysninger</li></ol></div>"
        },
        "section" : [{
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section1\"/><div> </div><h2>1. Virkning og anvendelse</h2><div class=\"paragraph\">Remicade indeholder det aktive stof infliximab. Infliximab er et monoklonalt antistof - en type protein, der binder sig til et specifikt mål i kroppen kaldet TNF (tumor nekrose faktor) alfa .</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Remicade tilhører en medicingruppe kaldet ”TNF-blokkere”. Det bruges til voksne til behandling af følgende betændelsessygdomme:</div><ul><li>Reumatoid arthritis</li><li>Psoriasisarthritis</li><li>Ankyloserende spondylitis (Bekhterevs sygdom)</li><li>Psoriasis.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Remicade bruges også til voksne og børn fra 6 år og opefter til behandling af:</div><ul><li>Crohns sygdom</li><li>Colitis ulcerosa.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Remicade virker ved selektivt at binde sig til TNF alfa og blokere dets virkning. TNF alfa er involveret i kroppens betændelsesprocesser, så blokering af dette kan mindske betændelsen i din krop.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Reumatoid arthritis</b></div><div class=\"paragraph\">Reumatoid arthritis er en betændelsessygdom i leddene. Hvis du har aktiv reumatoid arthritis, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade, som du skal tage sammen med et andet lægemiddel, der hedder methotrexat, for at:</div><ul><li>Reducere tegn og symptomer på din sygdom</li><li>Forsinke skaden i dine led</li><li>Forbedre din fysiske funktionsevne.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Psoriasisarthritis</b></div><div class=\"paragraph\">Psoriasisarthritis er en betændelsessygdom i leddene, almindeligvis ledsaget af psoriasis. Hvis du har aktiv psoriasisarthritis, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade for at:</div><ul><li>Reducere tegn og symptomer på din sygdom</li><li>Forsinke skaden i dine led</li><li>Forbedre din fysiske funktionsevne.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ankyloserende spondylitis (Bekhterevs sygdom)</b></div><div class=\"paragraph\">Ankyloserende spondylitis er en betændelsessygdom i rygraden. Hvis du lider af ankyloserende spondylitis, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade for at:</div><ul><li>Reducere tegn og symptomer på din sygdom</li><li>Forbedre din fysiske funktionsevne.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Psoriasis</b></div><div class=\"paragraph\">Psoriasis er en betændelsessygdom i huden. Hvis du har moderat til svær plaque psoriasis, vil du først få andre lægemidler eller behandlinger, såsom lysterapi. Hvis disse lægemidler eller behandlinger ikke virker godt nok, vil du få Remicade for at reducere tegn og symptomer på din sygdom.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Colitis ulcerosa</b></div><div class=\"paragraph\">Colitis ulcerosa er en betændelsessygdom i tarmen. Hvis du lider af colitis ulcerosa, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade til behandling af din sygdom.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Crohns sygdom</b></div><div class=\"paragraph\">Crohns sygdom er en betændelsessygdom i tarmen. Hvis du lider af Crohns sygdom, vil du først få andre lægemidler. Hvis disse lægemidler ikke virker godt nok, vil du få Remicade for at:</div><ul><li>Behandle aktiv Crohns sygdom</li><li>Sænke antallet af unormale åbninger (fistler) mellem din tarm og hud, der ikke har kunnet behandles tilfredsstillende med andre lægemidler eller operation.</li></ul></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du får Remicade",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section2\"/><div> </div><h2>2. Det skal du vide, før du får Remicade</h2><h3>Du må ikke få Remicade</h3><ul><li>hvis du er allergisk over for infliximab eller et af de øvrige indholdsstoffer i Remicade (angivet i <a href=\"#Section6\" title=\"Anchor link til afsnit - punkt 6\">punkt 6</a>).</li><li>hvis du er allergisk over for proteiner, som stammer fra mus.</li><li>hvis du har tuberkulose (TB) eller en anden alvorlig infektion, såsom lungebetændelse eller blodforgiftning (sepsis).</li><li>hvis du har hjertesvigt i moderat eller svær grad.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Du må ikke få Remicade, hvis noget af ovenstående passer på dig. Hvis du er i tvivl, så tal med din læge, før du får Remicade.</div><h3>Advarsler og forsigtighedsregler</h3><div class=\"paragraph\">Kontakt lægen før eller under behandlingen med Remicade, hvis du har:</div><div class=\"paragraph\"><br/><b>Været i behandling med Remicade tidligere</b></div><ul><li>Fortæl din læge, hvis du tidligere har været i behandling med Remicade og nu starter behandling med Remicade igen.</li></ul><div class=\"paragraph\">Hvis du har holdt pause i Remicade-behandlingen i over 16 uger, er der en højere risiko for at få en allergisk reaktion, når du starter behandlingen igen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Infektioner</b></div><ul><li>Fortæl din læge, før du får Remicade, hvis du har en infektion, også selvom det er en meget let infektion.</li><li>Fortæl din læge, før du får Remicade, hvis du nogensinde har boet eller rejst i et område, hvor infektioner kaldet histoplasmose, kokcidioidomykose eller blastomykose er almindelige. Disse infektioner forårsages af særlige svampetyper, som kan påvirke lungerne eller andre dele af kroppen.</li><li>Du har lettere ved at få infektioner, når du er i behandling med Remicade. Du har en højere risiko, hvis du er 65 år eller derover.</li><li>Disse infektioner kan være alvorlige og indbefatter tuberkulose, infektioner forårsaget af virus, svampe, bakterier eller andre organismer i miljøet samt blodforgiftning, som kan være livstruende.</li></ul><div class=\"paragraph\">Fortæl straks din læge, hvis du får tegn på infektion under behandling med Remicade. Tegn inkluderer feber, hoste, influenzalignende symptomer, utilpashed, rød eller ophedet hud, sår eller problemer med tænderne. Din læge kan anbefale en midlertidig pause med Remicade.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Tuberkulose (TB)</b></div><ul><li>Det er meget vigtigt, at du fortæller din læge, hvis du nogensinde har haft TB, eller hvis du har været i tæt kontakt med en person, som har eller har haft TB.</li><li>Din læge vil teste dig for at se, om du har TB. Tilfælde af TB har været rapporteret hos patienter i behandling med Remicade, også hos patienter, der allerede har været i behandling med medicin mod TB. Din læge vil notere disse tests på dit patientinformationskort.</li><li>Hvis din læge tror, at du har risiko for at få TB, kan du blive behandlet med lægemidler mod TB, inden du får Remicade.</li></ul><div class=\"paragraph\">Fortæl straks din læge, hvis du får tegn på TB under behandlingen med Remicade. Tegn inkluderer vedvarende hoste, vægttab, træthedsfølelse, feber eller natlig svedtendens.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Hepatitis B-virus</b></div><ul><li>Fortæl din læge, før du får Remicade, hvis du er bærer af hepatitis B, eller hvis du nogensinde har haft det.</li><li>Fortæl din læge, hvis du tror, du kan have en risiko for at blive smittet med hepatitis B.</li><li>Din læge skal teste dig for hepatitis B.</li><li>Behandling med TNF-blokkere, såsom Remicade, kan medføre, at hepatitis B igen bliver aktiv hos patienter, som bærer denne virus. Dette kan i nogle tilfælde være livstruende.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Hjerteproblemer</b></div><ul><li>Fortæl din læge, hvis du har nogen form for hjerteproblemer, såsom let hjertesvigt.</li><li>Din læge vil nøje overvåge dit hjerte.</li></ul><div class=\"paragraph\">Fortæl straks din læge, hvis du får nye eller forværrede tegn på hjertesvigt under behandlingen med Remicade. Tegn inkluderer åndenød eller hævede fødder.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Kræft og lymfom</b></div><ul><li>Fortæl din læge, før du får Remicade, hvis du har eller nogensinde har haft lymfom (en type blodkræft) eller enhver anden form for kræft.</li><li>Patienter med alvorlig reumatoid arthritis, som har haft sygdommen i lang tid, kan have en større risiko for at udvikle lymfom.</li><li>Børn og voksne i behandling med Remicade kan have en øget risiko for at udvikle lymfom eller anden form for kræft.</li><li>Nogle patienter, som har fået TNF-blokerende behandling, herunder Remicade, har udviklet en sjælden kræftform kaldet hepatosplenisk T-celle-lymfom. Af disse patienter var de fleste teenagedrenge eller unge mænd, hvoraf de fleste havde enten Crohns sygdom eller colitis ulcerosa. Denne type kræft har oftest haft dødelig udgang. Næsten alle patienterne havde også fået medicin, der indeholder azathioprin eller 6- mercaptopurin ud over den TNF-blokerende behandling.</li><li>Nogle patienter, der er blevet behandlet med infliximab, har udviklet visse former for hudkræft. Hvis der er forandringer i huden eller svulster på huden under eller efter behandlingen, skal du fortælle det til lægen.</li><li>Nogle kvinder, der er blevet behandlet for reumatoid arthritis med Remicade, har udviklet livmoderhalskræft. Lægen kan tilråde, at kvinder, der får Remicade, herunder kvinder over 60 år, bliver regelmæssigt screenet for livmoderhalskræft.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Lungesygdom eller højt tobaksforbrug</b></div><ul><li>Fortæl din læge, før du får Remicade, hvis du har en lungesygdom kaldet kronisk obstruktiv lungesygdom (KOL, rygerlunger), eller hvis du er storryger.</li><li>Patienter med KOL og patienter, som er storrygere, kan have en øget risiko for at udvikle kræft under behandling med Remicade.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Sygdom i nervesystemet</b></div><ul><li>Fortæl din læge, hvis du har eller nogensinde har haft en lidelse, som påvirker dit nervesystem, før du får Remicade. Dette inkluderer dissemineret sklerose, Guillain-Barré syndrom, hvis du har krampeanfald eller har fået stillet diagnosen ”optisk neuritis” (betændelse i synsnerven).</li></ul><div class=\"paragraph\">Fortæl straks din læge, hvis du får symptomer på en nervesygdom under behandlingen med Remicade. Tegn inkluderer synsændringer, muskelsvaghed i arme eller ben, følelsesløshed eller prikken et sted i kroppen.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Unormale hudåbninger</b></div><ul><li>Fortæl din læge, hvis du har unormale hudåbninger (fistler), før du får Remicade.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Vaccinationer</b></div><ul><li>Tal med din læge, hvis du lige er blevet eller har planlagt at blive vaccineret.</li><li>Du skal have de anbefalede vaccinationer, før du starter behandling med Remicade. Der er visse vaccinationer, du kan få, mens du er i behandling med Remicade, men du må ikke få levende vacciner (vacciner der indeholder et levende men svækket smitstof), da de kan give infektioner.</li><li>Hvis du har fået Remicade, mens du var gravid, kan dit barn også have en større risiko for at få en infektion som et resultat af at have fået en levende vaccine i løbet af det første leveår. Det er vigtigt, at du fortæller dit barns læger og andet sundhedspersonale, at du får Remicade, så de kan finde frem til, hvornår dit barn skal vaccineres; det gælder også levende vacciner som BCG-vaccinen (bruges til at forebygge tuberkulose).</li><li>Hvis du ammer, er det vigtigt, at du fortæller dit barns læge eller andet sundhedspersonale, at du har fået Remicade, før barnet bliver vaccineret. Se afsnittet om Graviditet, amning og frugtbarhed for yderligere information.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Terapeutiske smitstoffer</b></div><ul><li>Tal med din læge, hvis du fornylig har fået eller det er planlagt, at du skal have behandling med et terapeutisk smitstof (fx instillation af BCG til behandling af kræft).</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Operationer eller tandindgreb</b></div><ul><li>Fortæl din læge, hvis du skal have foretaget en operation eller et tandindgreb.</li><li>Fortæl kirurgen eller tandlægen, at du er i behandling med Remicade ved at vise dem dit patientinformationskort.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Leverproblemer</b></div><ul><li>Nogle patienter, der får Remicade, har udviklet alvorlige leverproblemer.</li></ul><div class=\"paragraph\">Fortæl det straks til lægen, hvis du får symptomer på leverproblemer under behandlingen med Remicade. Tegn omfatter gulfarvning af hud og øjne, mørkebrun urin, smerter eller hævelse i øvre højre side af maven, ledsmerter, hududslæt eller feber.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Lave blodtal</b></div><ul><li>Hos nogle patienter, som får Remicade, kan kroppen måske ikke lave nok af de blodlegemer, der skal hjælpe med at bekæmpe infektioner eller stoppe blødning.</li></ul><div class=\"paragraph\">Fortæl det straks til lægen, hvis du får symptomer på lave blodtal under behandlingen med Remicade. Tegn omfatter vedvarende feber, større tendens til blødning eller blå mærker, små røde eller lilla pletter, der skyldes blødning under huden, eller bleghed.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Sygdomme i immunsystemet</b></div><ul><li>Nogle patienter, der får Remicade, har udviklet symptomer på en sygdom i immunsystemet kaldet lupus.</li></ul><div class=\"paragraph\">Fortæl det straks til lægen, hvis du får symptomer på lupus under behandlingen med Remicade. Tegn omfatter ledsmerter eller udslæt på kinder eller arme, som er følsomme over for solen.</div><h3>Børn og unge</h3><div class=\"paragraph\"><b>Ovenstående oplysninger gælder også for børn og unge. Derudover gælder, at:</b></div><ul><li>Nogle børn og unge, som har fået TNF-blokkere såsom Remicade, har udviklet kræft inklusive usædvanlige typer kræft, som i visse tilfælde har været dødelige.</li><li>Flere børn end voksne, der får Remicade, fik infektioner.</li><li>Børn skal have de anbefalede vaccinationer, før behandling med Remicade påbegyndes. Børn kan få visse vacciner under behandlingen med Remicade, men må ikke få levende vacciner, mens de får Remicade.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du er i tvivl, om noget af ovenstående passer på dig, skal du tale med din læge, før du får Remicade.</div><h3>Brug af anden medicin sammen med Remicade</h3><div class=\"paragraph\">Patienter, som har betændelsessygdomme, tager allerede medicin for at behandle deres lidelse. Disse lægemidler kan give bivirkninger. Din læge vil rådgive dig om, hvilke andre lægemidler du skal blive ved med at tage, mens du er i behandling med Remicade.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Fortæl altid lægen, hvis du bruger anden medicin, for nylig har brugt anden medicin eller planlægger at bruge anden medicin. Dette gælder også medicin til behandling af Crohns sygdom, colitis ulcerosa, reumatoid arthritis, ankyloserende spondylitis, psoriasisarthritis eller psoriasis eller medicin, som ikke er købt på recept, fx vitaminer og naturlægemidler.<br/><br/>Det er specielt vigtigt, at du fortæller din læge, hvis du får nogen af følgende lægemidler:</div><ul><li>Lægemidler som påvirker dit immunsystem.</li><li>Kineret (anakinra). Du må ikke få Remicade og Kineret samtidig.</li><li>Orencia (abatacept). Du må ikke få Remicade og Orencia samtidig.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Du må ikke få levende vacciner, mens du får Remicade. Hvis du har fået Remicade, mens du var gravid, eller hvis du får Remicade, mens du ammer, skal du fortælle dit barns læge og andet sundhedspersonale, der tager sig af dit barn, at du har fået Remicade, før barnet bliver vaccineret.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du er i tvivl, om noget af ovenstående passer på dig, skal du tale med din læge eller apotekspersonalet, før du får Remicade.</div><h3>Graviditet, amning og frugtbarhed</h3><ul><li>Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge til råds, før du får dette lægemiddel. Du må kun få Remicade under graviditeten, eller mens du ammer, hvis lægen finder det nødvendigt.</li><li>Du skal undgå at blive gravid, mens du er i behandling med Remicade, og i mindst 6 måneder efter du er stoppet med behandlingen. Tal med lægen om anvendelse af prævention i denne tidsperiode.</li><li>Hvis du fik Remicade under graviditeten, kan dit barn have en øget risiko for at få en infektion.</li><li>Det er vigtigt, at du fortæller dit barns læge og andet sundhedspersonale, at du har fået Remicade, før barnet bliver vaccineret. Hvis du har fået Remicade under graviditeten, kan vaccination af dit barn med BCG-vaccine (bruges til at forebygge tuberkulose) inden for 12 måneder efter fødslen medføre infektion med alvorlige komplikationer herunder død. Dit barn må ikke få levende vacciner som BCG-vaccinen inden for 12 måneder efter fødslen, medmindre barnets læge anbefaler noget andet. For mere information, se afsnit om vaccination.</li><li>Hvis du ammer, er det vigtigt, at du fortæller dit barns læge eller andet sundhedspersonale, at du har fået Remicade, før barnet bliver vaccineret. Dit barn må ikke få levende vacciner, mens du ammer, medmindre barnets læge anbefaler noget andet.</li><li>Alvorligt fald i antal hvide blodlegemer er set hos spædbørn født af kvinder, der er blevet behandlet med Remicade under graviditeten. Hvis dit barn hyppigt får feber eller infektioner, skal du omgående kontakte barnets læge.</li></ul><h3>Trafik- og arbejdssikkerhed</h3><div class=\"paragraph\">Remicade påvirker sandsynligvis ikke arbejdssikkerheden eller evnen til at færdes sikkert i trafikken. Hvis du føler dig træt, svimmel eller utilpas efter at have fået Remicade, må du ikke køre bil eller betjene nogen form for maskiner.</div><h3>Remicade indeholder natrium</h3><div class=\"paragraph\">Remicade indeholder mindre end 1 mmol natrium (23 mg) pr. dosis, dvs. det er i det væsentlige ”natriumfrit”. Men før du får Remicade, blandes det sammen med en opløsning, som indeholder natrium. Tal med din læge, hvis du er på en diæt med et lavt saltindhold.</div></div>"
          }
        },
        {
          "title" : "3. Sådan får du Remicade",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section3\"/><div> </div><h2>3. Sådan får du Remicade</h2><div class=\"paragraph\"><b>Reumatoid arthritis</b></div><div class=\"paragraph\">Den sædvanlige dosis er 3 mg pr. kg kropsvægt.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Psoriasisarthritis, ankyloserende spondylitis (Bekhterevs sygdom), psoriasis, colitis ulcerosa og Crohns sygdom</b></div><div class=\"paragraph\">Den sædvanlige dosis er 5 mg pr. kg kropsvægt.</div><h3>Sådan får du Remicade</h3><ul><li>Du vil få Remicade af din læge eller sygeplejerske.</li><li>Din læge eller sygeplejerske vil klargøre medicinen til infusion.</li><li>Medicinen vil blive givet som en infusion (drop) (over 2 timer) i en af dine blodårer (vener), sædvanligvis i armen. Efter den tredje behandling kan din læge beslutte at give dig din dosis Remicade over 1 time.</li><li>Du vil blive overvåget, mens du får Remicade og i 1-2 timer derefter.</li></ul><h3>Den sædvanlige dosis</h3><ul><li>Lægen vil bestemme din dosis og hvor ofte, du skal have Remicade. Dette vil afhænge af din sygdom, vægt og hvor godt, du reagerer på Remicade.</li><li>Tabellen nedenfor viser, hvor ofte du sædvanligvis vil få denne medicin efter din første dosis.</li></ul><div class=\"paragraph\"> </div><table border=\"1\" cellpadding=\"4\" cellspacing=\"0\" width=\"50%\" style=\"border-collapse:collapse;\"><colgroup><col width=\"50%\"/><col width=\"50%\"/></colgroup><tr><td style=\"width:50%;\" valign=\"top\" align=\"left\"><div class=\"paragraph\">2. dosis</div></td><td style=\"width:50%;\" valign=\"top\" align=\"left\"><div class=\"paragraph\">2 uger efter din 1. dosis</div></td></tr><tr><td style=\"width:50%;\" valign=\"top\" align=\"left\"><div class=\"paragraph\">3. dosis</div></td><td style=\"width:50%;\" valign=\"top\" align=\"left\"><div class=\"paragraph\">6 uger efter din 1. dosis</div></td></tr><tr><td style=\"width:50%;\" valign=\"top\" align=\"left\"><div class=\"paragraph\">Efterfølgende doser</div></td><td style=\"width:50%;\" valign=\"top\" align=\"left\"><div class=\"paragraph\">Hver 6. til 8. uge afhængig af din sygdom</div></td></tr></table><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Brug til børn og unge</b></div><div class=\"paragraph\">Remicade må kun anvendes til børn, hvis de behandles for Crohns sygdom eller colitis ulcerosa.</div><div class=\"paragraph\">Børnene skal være 6 år eller ældre.</div><h3>Hvis du får for meget Remicade</h3><div class=\"paragraph\">Da du får denne medicin af din læge eller sygeplejerske, er det usandsynligt, at du vil få for meget.</div><div class=\"paragraph\">Der kendes ikke til bivirkninger efter at have fået for meget Remicade.</div><h3>Hvis du har glemt eller kommer for sent til din Remicade-infusion</h3><div class=\"paragraph\">Hvis du glemmer eller kommer for sent til en aftale, hvor Remicade gives, skal du lave en ny aftale så hurtigt som muligt.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Spørg lægen, hvis der er noget, du er i tvivl om.</div></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section4\"/><div> </div><h2>4. Bivirkninger</h2><div class=\"paragraph\">Dette lægemiddel kan som alle andre lægemidler give bivirkninger, men ikke alle får bivirkninger. De fleste bivirkninger er lette til moderate. Nogle patienter kan dog opleve alvorlige bivirkninger, som kan kræve behandling. Bivirkninger kan også opstå efter ophør af din behandling med Remicade.</div><h3>Fortæl straks din læge, hvis du bemærker noget af følgende:</h3><ul><li><b>Tegn på en allergisk reaktion</b> såsom hævelse af ansigt, læber, mund eller svælg, som kan forårsage besvær med at synke eller trække vejret, kløende udslæt, hævelse af hænder, fødder eller ankler. Nogle af disse reaktioner kan være alvorlige eller livstruende. En allergisk reaktion kan opstå inden for 2 timer efter din injektion eller senere. Yderligere tegn på allergiske bivirkninger, som kan opstå op til 12 dage efter din injektion, inkluderer muskelsmerter, feber, led- eller kæbesmerter, ondt i halsen eller hovedpine.</li><li><b>Tegn på hjerteproblemer</b> såsom ubehag i brystkassen eller brystsmerter, armsmerter, mavesmerter, åndenød, angst, ørhed, svimmelhed, besvimelse, svedtendens, kvalme (utilpashed), opkastning, skælven eller banken i brystet, hurtigt eller langsomt hjerteslag og hævede fødder.</li><li><b>Tegn på infektion (inklusive tuberkulose (TB))</b> såsom feber, træthedsfølelse, hoste, der kan være vedvarende, åndenød, influenzalignende symptomer, vægttab, natlig svedtendens, diarré, sår, ansamling af pus i tarmen eller omkring anus (absces), tandproblemer eller brændende smerte, når du lader vandet.</li><li><b>Mulige tegn på kræft, </b>inklusive men ikke begrænset til hævede lymfeknuder, vægttab, feber, usædvanlige knuder i huden, ændringer i modermærker eller hudfarven eller usædvanlig blødning fra skeden.</li><li><b>Tegn på lungeproblemer</b> såsom hoste, åndedrætsbesvær eller trykken for brystet.</li><li><b>Tegn på et problem i nervesystemet (inklusive øjenproblemer)</b> såsom tegn på slagtilfælde (pludselig følelsesløshed eller svaghed i ansigt, arme eller ben, særligt i den ene side af kroppen; pludselig forvirring, besvær med at tale eller forstå; besvær med at se med det ene eller begge øjne, gangbesvær, svimmelhed, tab af balance- eller koordinationsevne eller svær hovedpine), krampanfald, prikken/følelsesløshed et sted i kroppen, eller svaghed i arme eller ben, ændringer i synet såsom dobbeltsyn eller andre øjenproblemer.</li><li><b>Tegn på leverproblemer </b>(inklusive hepatitis B-infektion, hvis du tidligere har haft hepatitis B) såsom gulfarvning af hud eller øjne, mørkebrun urin, smerter eller hævelser i øvre højre side af maven, ledsmerter, hududslæt eller feber.</li><li><b>Tegn på en sygdom i immunsystemet </b>såsom ledsmerter, udslæt på kinder eller arme, som er følsomme over for solen (lupus) eller hoste, åndenød, feber eller hududslæt (sarkoidose).</li><li><b>Tegn på lave blodtal</b> såsom vedvarende feber, blødningstendens, tendens til lettere at få blå mærker, små røde eller lilla pletter, der skyldes blødning under huden, eller bleghed.</li><li><b>Tegn på alvorlige hudproblemer</b> såsom rødlige, målskivelignende pletter eller runde områder ofte med blærer centralt på kroppen, store områder med afskalning (eksfoliation) samt sår i mund, svælg, næse, kønsorganer og øjne eller små pusholdige blærer, som kan sprede sig over hele kroppen. Disse hudreaktioner kan være ledsaget af feber.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\">Fortæl straks din læge, hvis du bemærker noget af ovenstående.</div><h3>Følgende bivirkninger er observeret med Remicade:</h3><div class=\"paragraph\"><b>Meget almindelig: kan forekomme hos flere end 1 ud af 10 personer</b></div><ul><li>Mavesmerter, kvalme</li><li>Virusinfektioner såsom herpes eller influenza</li><li>Øvre luftvejsinfektioner såsom bihulebetændelse</li><li>Hovedpine</li><li>Bivirkninger i forbindelse med infusionen</li><li>Smerter.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Almindelig: kan forekomme hos op til 1 ud af 10 personer</b></div><ul><li>Ændringer i hvordan din lever fungerer, forhøjede leverenzymer (vist i blodprøver)</li><li>Infektioner i lunger eller luftveje såsom bronkitis eller lungebetændelse</li><li>Besværet eller smertefuldt vejrtrækning, smerter i brystet</li><li>Blødning i mave eller tarme, diarré, fordøjelsesbesvær, halsbrand, forstoppelse</li><li>Nældefeber, kløende udslæt eller tør hud</li><li>Balanceproblemer eller svimmelhed</li><li>Feber, øget svedtendens</li><li>Kredsløbsproblemer såsom for lavt eller for højt blodtryk</li><li>Blå mærker, hedeture eller næseblod, varm, rød hud (rødmen)</li><li>Trætheds- eller svaghedsfølelse</li><li>Bakterieinfektioner såsom blodforgiftning, byld eller infektion under huden (cellulitis)</li><li>Svampeinfektion i huden</li><li>Blodproblemer såsom blodmangel eller lavt antal hvide blodlegemer</li><li>Hævede lymfeknuder</li><li>Depression, problemer med at sove</li><li>Øjenproblemer inklusive røde øjne og øjeninfektioner</li><li>Galoperende hjerte (hurtig puls) eller hjertebanken</li><li>Smerter i leddene, musklerne eller ryggen</li><li>Urinvejsinfektion</li><li>Psoriasis, hudproblemer såsom eksem og hårtab</li><li>Reaktioner på injektionsstedet såsom smerte, hævelse, rødme eller kløe</li><li>Kuldegysninger, hævelse på grund af ophobning af væske under huden</li><li>Følelsesløshed eller en prikkende fornemmelse.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ikke almindelig: kan forekomme hos op til 1 ud af 100 personer</b></div><ul><li>Manglende blodtilførsel, hævelse af en blodåre</li><li>Ansamling af blod uden for blodkarrene (hæmatom) eller blå mærker</li><li>Hudproblemer såsom blæredannelse, vorter, unormal hudfarve eller pigmentering, eller hævede læber, eller fortykkelse af huden eller rød, skællende hud og afskalning af huden</li><li>Alvorlige allergiske reaktioner (fx anafylaksi), en sygdom i immunsystemet kaldet lupus, allergiske reaktioner over for fremmede proteiner</li><li>Længere sårhelingstid</li><li>Hævelse af lever (hepatitis) eller galdeblære, leverskade</li><li>Glemsomhed, irritabilitet, forvirring, nervøsitet</li><li>Øjenproblemer inklusive sløret eller nedsat syn, hævede øjne eller bygkorn</li><li>Debuterende eller forværring af eksisterende hjertesvigt, langsom hjertefrekvens (puls)</li><li>Besvimelse</li><li>Kramper, nerveforstyrrelser</li><li>Hul i tarmen eller blokering af tarmen, mavesmerter eller -kramper</li><li>Hævelse af bugspytkirtlen (bugspytkirtelbetændelse)</li><li>Svampeinfektioner såsom gærsvampeinfektion eller svampeinfektion i neglene</li><li>Lungeproblemer såsom ødemer</li><li>Væske rundt om lungerne (pleuraekssudat)</li><li>Forsnævrede luftveje i lungerne, der giver åndedrætsbesvær</li><li>Lungehindebetændelse, der giver skape smerter, som forværres ved vejrtrækning (pleuritis)</li><li>Tuberkulose</li><li>Nyreinfektioner</li><li>Lavt antal blodplader, for mange hvide blodlegemer</li><li>Infektioner i skeden</li><li>Blodprøveresultater, der viser ‘antistoffer’ mod din egen krop</li><li>Ændringer i kolesterol- og fedtindholdet i blodet.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Sjælden: kan forekomme hos op til 1 ud af 1.000 personer</b></div><ul><li>En type blodkræft (lymfom)</li><li>Blodet tilfører ikke nok ilt til kroppen, kredsløbsproblemer såsom indsnævring af et blodkar</li><li>Betændelse i hjernehinderne (meningitis)</li><li>Infektioner, som skyldes nedsat immunforsvar</li><li>Hepatitis B-infektion, hvis du tidligere har haft hepatitis B</li><li>Betændelsestilstand i leveren forårsaget af et problem med immunsystemet (autoimmun hepatitis)</li><li>Leverproblemer, der giver gulfarvning af hud eller øjne (gulsot)</li><li>Unormal vævshævelse eller -vækst</li><li>Alvorlig allergisk reaktion, som kan medføre tab af bevidsthed og kan være livstruende (anafylaktisk shock)</li><li>Hævelse af små blodkar (blodkarbetændelse)</li><li>Immunsystemdefekt, som kan påvirke lunger, hud og lymfekirtler (såsom sarkoidose)</li><li>Ansamling af immunceller som følge af et inflammatorisk respons (granulomatøse læsioner)</li><li>Mangel på interesse eller følelser</li><li>Alvorlige hudproblemer såsom toksisk epidermal nekrolyse, Stevens-Johnsons syndrom og akut generaliseret eksantematøs pustulose</li><li>Andre hudproblemer såsom erythema multiforme, lichenoide reaktioner (kløende, rødligt-lilla hududslæt og/eller trådlignende gråhvide linjer på slimhinderne), blærer og afskalning af huden eller bylder (furunkulose)</li><li>Alvorlige lidelser i nervesystemet såsom transversal myelitis, multipel sklerose-lignende sygdom, optisk neuritis og Guillain-Barrés syndrom</li><li>Øjenbetændelse, der kan forårsage synsforandringer, inklusive blindhed</li><li>Væske omkring hjertet (perikardial effusion)</li><li>Alvorlige lungeproblemer (såsom interstitiel lungesygdom)</li><li>Melanom (en type hudkræft)</li><li>Livmoderhalskræft</li><li>Lave blodtal, herunder svært nedsat antal hvide blodlegemer</li><li>Små røde eller lilla pletter, der skyldes blødning under huden</li><li>Unormale værdier for et protein i blodet kaldet ‘komplementfaktor’, som er en del af immunsystemet.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Ikke kendt: hyppigheden kan ikke estimeres ud fra forhåndenværende data</b></div><ul><li>Kræft hos børn og voksne</li><li>En sjælden blodkræft som hovedsageligt rammer teenagedrenge eller unge mænd (hepatosplenisk T-celle-lymfom)</li><li>Leversvigt</li><li>Merkelcellekarcinom (en type hudkræft)</li><li>Kaposis sarkom, en sjælden type kræft, der er forbundet med infektion med humant herpesvirus 8. Kaposis sarkom forekommer oftest som lilla læsioner på huden.</li><li>Forværring af en sygdom der hedder dermatomyositis (muskelsvaghed med hududslæt som følgetilstand)</li><li>Hjerteanfald</li><li>Slagtilfælde</li><li>Midlertidigt synstab under eller inden for 2 timer efter infusionen</li><li>Infektion, der skyldes en levende vaccine, som følge af et svækket immunsystem.</li></ul><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Hos børn og unge ses yderligere følgende bivirkninger:</b></div><div class=\"paragraph\">De bivirkninger, som børn i behandling med Remicade mod Crohns sygdom fik, var forskellige fra de bivirkninger, som voksne i behandling med Remicade mod Crohns sygdom fik. Følgende bivirkninger forekom hyppigere hos børn: nedsat antal røde blodlegemer (anæmi), blod i afføringen, nedsat samlet indhold af hvide blodlegemer (leukopeni), anfaldsvis ansigtsrødme, virusinfektioner, lavt indhold af hvide blodlegemer, der bekæmper infektion (neutropeni), knoglebrud, bakterieinfektion og allergiske reaktioner i luftvejene.</div><h3>Indberetning af bivirkninger</h3><div class=\"paragraph\">Hvis du oplever bivirkninger, bør du tale med din læge, apotekspersonalet eller sygeplejersken. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via Lægemiddelstyrelsen, Axel Heides Gade 1, DK-2300 København S, Websted: www.meldenbivirkning.dk. Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</div><div class=\"paragraph\"><a href=\"https://www.meldenbivirkning.dk\" title=\"Meld en bivirkning\">Meld en bivirkning.</a></div></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section5\"/><div> </div><h2>5. Opbevaring</h2><div class=\"paragraph\">Remicade opbevares normalt af sundhedspersonalet. Skulle du få brug for information omkring opbevaring, gælder følgende:</div><ul><li>Opbevar lægemidlet utilgængeligt for børn</li><li>Brug ikke lægemidlet efter den udløbsdato, der står på etiketten og kartonen efter EXP. Udløbsdatoen er den sidste dag i den nævnte måned</li><li>Opbevares i køleskab (2 °C - 8 °C)</li><li>Lægemidlet kan også opbevares i den originale karton uden for køleskab ved højst 25 °C i en enkelt periode på op til 6 måneder, men den oprindelige udløbsdato må ikke overskrides. I denne situation må det ikke sættes tilbage i køleskab. Skriv den nye udløbsdato på æsken med dag/måned/år. Kasser lægemidlet, hvis det ikke er brugt før den nye udløbsdato eller den dato, der er trykt på æsken, alt efter, hvilken dato der kommer først.</li><li>Det anbefales, at Remicade anvendes så hurtigt som muligt (inden for 3 timer), efter det er klargjort til infusion. Hvis opløsningen er klargjort under aseptiske betingelser, kan den dog opbevares i køleskab ved 2 °C - 8 °C i op til 28 dage og i yderligere 24 timer ved 25 °C efter udtagning fra køleskab.</li><li>Brug ikke dette lægemiddel, hvis det er misfarvet, eller hvis det indeholder partikler.</li></ul></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section6\"/><div> </div><h2>6. Pakningsstørrelser og yderligere oplysninger</h2><h3>Remicade indeholder</h3><ul><li>Aktivt stof: infliximab. Hvert hætteglas indeholder 100 mg infliximab. Efter klargøring indeholder hver ml 10 mg infliximab.</li><li>Øvrige indholdsstoffer: saccharose, polysorbat 80, natriumdihydrogenphosphat og dinatriumphosphatdihydrat.</li></ul><h3>Udseende og pakningsstørrelser</h3><div class=\"paragraph\">Remicade leveres som et hætteglas (glasflaske) indeholdende et pulver til koncentrat til infusionsvæske, opløsning. Pulveret er en frysetørret hvid pellet.</div><div class=\"paragraph\">Remicade fremstilles i kartoner med 1, 2, 3, 4 eller 5 hætteglas. Ikke alle pakningsstørrelser er nødvendigvis markedsført.</div></div>"
          },
          "section" : [{
            "title" : "Indehaver af markedsføringstilladelsen og fremstiller",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Indehaver af markedsføringstilladelsen og fremstiller</h2><h3>Indehaver af markedsføringstilladelsen og fremstiller</h3><div class=\"paragraph\">Janssen Biologics B.V.<br/>Einsteinweg 101</div><div class=\"paragraph\">2333 CB Leiden</div><div class=\"paragraph\">Holland</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du ønsker yderligere oplysninger om dette lægemiddel, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:</div><div class=\"paragraph\"> </div><div class=\"paragraph\">MSD Danmark ApS</div><div class=\"paragraph\">Tlf: + 45 4482 4000</div><div class=\"paragraph\">dkmail@merck.com</div><h3>Andre informationskilder</h3><div class=\"paragraph\">Du kan finde yderligere oplysninger om dette lægemiddel på Det Europæiske Lægemiddelagenturs hjemmeside http://www.ema.europa.eu/.</div></div>"
            }
          },
          {
            "title" : "Denne indlægsseddel blev senest ændret 02/2022",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Denne indlægsseddel blev senest ændret 02/2022</h2></div>"
            }
          },
          {
            "title" : "7. Oplysninger tiltænkt læger og sundhedspersonale",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029921"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section8\"/><div> </div><h2>7. Oplysninger tiltænkt læger og sundhedspersonale</h2><div class=\"paragraph\">Nedenstående oplysninger er til læger og sundhedspersonale:</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Patientinformationskortet skal udleveres til patienter, som er i behandling med Remicade.</div><h3>Instruktion i anvendelse og håndtering - opbevaring</h3><div class=\"paragraph\">Opbevares ved 2 °C - 8 °C.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Remicade kan opbevares ved temperaturer på op til højst 25 °C i en enkelt periode på op til 6 måneder, men den oprindelige udløbsdato må ikke overskrides. Den nye udløbsdato skal skrives på kartonen. Når Remicade er taget ud af køleskabet, må det ikke sættes tilbage på køl igen.</div><h3>Instruktion i anvendelse og håndtering - rekonstitution, fortynding og administration</h3><div class=\"paragraph\">For at øge sporbarheden af biologiske lægemidler skal præparatnavnet og lot-nummeret på det administrerede lægemiddel tydeligt noteres.</div><ol><li>Beregn dosis og det nødvendige antal Remicade-hætteglas. Hvert Remicade-hætteglas indeholder 100 mg infliximab. Beregn det samlede påkrævede volumen rekonstitueret Remicade-koncentrat.<br/><br/></li><li>Rekonstituer under aseptiske forhold hvert Remicade-hætteglas med 10 ml vand til injektionsvæsker ved hjælp af en sprøjte med en gauge 21 (0,8 mm) kanyle eller en mindre kanyle. Fjern plastiklåget fra hætteglasset og tør toppen med en 70 % alkoholvatpind. Indsæt sprøjtekanylen i hætteglasset gennem midten af gummiproppen og ret injektionsvæskestrømmen mod glasvæggen i hætteglasset. Bland forsigtigt koncentratet ved at vende hætteglasset for at opløse det lyofiliserede pulver. Undgå at svinge for længe eller for kraftigt. MÅ IKKE RYSTES. Opskumning af koncentratet ved rekonstitution er ikke usædvanlig. Lad det rekonstituerede koncentrat stå i 5 minutter. Kontroller at koncentratet er farveløst til lysegult og opaliserende. Der kan opstå nogle få fine gennemsigtige partikler i koncentratet, da infliximab er et protein. Koncentratet må ikke anvendes, hvis det indeholder uigennemsigtige partikler, er misfarvet eller indeholder andre fremmedlegemer.<br/><br/></li><li>Fortynd den samlede dosis (volumen) af det rekonstituerede Remicade-koncentrat til 250 ml med natriumchlorid 9 mg/ml (0,9 %) infusionsvæske. Fortynd ikke det rekonstituerede Remicade-koncentrat med andre infusionsvæsker. Fortyndingen kan opnås ved at udtrække et volumen af natriumchlorid 9 mg/ml (0,9 %) infusionsvæske fra 250 ml glasflasken eller infusionsposen svarende til voluminet af det rekonstituerede Remicade-koncentrat. Tilføj langsomt det samlede volumen af rekonstitueret Remicade-koncentrat til 250 ml infusionsflasken eller -posen. Bland forsigtigt. Brug enten en større infusionspose (fx 500 ml, 1.000 ml) til voluminer over 250 ml eller brug flere 250 ml infusionsposer for at sikre, at koncentrationen af infusionsvæsken ikke overstiger 4 mg/ml. Hvis infusionsvæsken har været opbevaret i køleskab efter rekonstitution og fortynding, skal den have tid til at opnå stuetemperatur (25 °C) i 3 timer forud for trin 4 (infusion). Opbevaring i mere end 24 timer ved 2 °C - 8 °C gælder udelukkende for klargøring af Remicade i infusionsposen.<br/><br/></li><li>Indgiv infusionsvæsken over en periode på ikke mindre end den anbefalede infusionstid. Anvend kun et infusionssæt med et in-line, sterilt, ikke-pyrogent, minimalt proteinbindende filter (porestørrelse 1,2 μm eller derunder). Da der ikke er anvendt konserveringsmiddel, anbefales det, at indgivelsen af infusionsvæsken påbegyndes så hurtigt som muligt og inden for 3 timer efter rekonstitution og fortynding. Hvis infusionsvæsken ikke anvendes straks, er opbevaringstider og -forhold efter anbrud indtil anvendelse brugerens ansvar, og de vil normalt ikke overskride 24 timer ved 2 °C - 8 °C, medmindre rekonstitution/fortynding har fundet sted under kontrollerede og validerede aseptiske forhold. Opbevar ikke rester af den ikke anvendte infusionsvæske til fornyet brug.<br/><br/></li><li>Der er ikke gennemført biokemiske forligelighedsstudier for at vurdere samtidig indgivelse af Remicade med andre midler. Infunder ikke Remicade i den samme intravenøse slange med andre midler.<br/><br/></li><li>Undersøg Remicade visuelt for partikler eller misfarvning før indgivelsen. Anvendes ikke, hvis der observeres synligt uigennemsigtige partikler, misfarvning eller fremmedlegemer.<br/><br/></li><li>Ikke anvendt lægemiddel samt affald heraf skal bortskaffes i henhold til lokale retningslinjer.</li></ol></div>"
            }
          }]
        }]
      }]
    }
  }]
}

```
