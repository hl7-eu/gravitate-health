# [Enhanced-Alicia] ePI document for Biktarvy 50 mg/200 mg/25 mg film-coated tablets Package Leaflet - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **[Enhanced-Alicia] ePI document for Biktarvy 50 mg/200 mg/25 mg film-coated tablets Package Leaflet**

## Example Bundle: [Enhanced-Alicia] ePI document for Biktarvy 50 mg/200 mg/25 mg film-coated tablets Package Leaflet

**Composition category:**Focused

**Composition status:**final

### B. Package Leaflet

 

**Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.**

* Keep this leaflet. You may need to read it again.
* If you have any further questions, ask your doctor or pharmacist.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.
* If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.

**If Biktarvy has been prescribed for your child, please note that all the information in this leaflet is addressed to your child (in this case please read “your child” instead of “you”).**


#### Package leaflet: Information for the user

 

**Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.**

* Keep this leaflet. You may need to read it again.
* If you have any further questions, ask your doctor or pharmacist.
* This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.
* If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.

**If Biktarvy has been prescribed for your child, please note that all the information in this leaflet is addressed to your child (in this case please read “your child” instead of “you”).**


#### What is in this leaflet

 

What is in this leaflet

1. What Biktarvy is and what it is used for
1. What you need to know before you take Biktarvy
1. How to take Biktarvy
1. Possible side effects
1. How to store Biktarvy
1. Contents of the pack and other information


#### 1. What Biktarvy 50 mg/200 mg/25 mg film-coated tablets is and what it is used for

 

Biktarvy contains three active substances:

* bictegravir, an antiretroviral medicine known as an integrase strand transfer inhibitor (INSTI)
* emtricitabine, an antiretroviral medicine of a type known as a nucleoside reverse transcriptase inhibitor (NRTI)
* tenofovir alafenamide, an antiretroviral medicine of a type known as a nucleotide reverse transcriptase inhibitor (NtRTI)

Biktarvy is a single tablet for the treatment of human immunodeficiency virus 1 (HIV-1) infection in adults, adolescents and children 2 years of age and older, who weigh at least 14 kg.

Biktarvy reduces the amount of HIV in your body. This will improve your immune system and reduce the risk of developing illnesses linked to HIV infection.


#### 2. What you need to know before you take Biktarvy 50 mg/200 mg/25 mg film-coated tablets

 

**Do not take Biktarvy**

* If you are allergic to bictegravir, emtricitabine, tenofovir alafenamide or any of the other ingredients of this medicine (listed in section 6).
* If you are currently taking any of the following medicines:
* If any of these apply to you, **do not take Biktarvy and tell your doctor immediately.**

**Warnings and precautions**

**Talk to your doctor before taking Biktarvy:**

* If you have liver problems or a history of liver disease, including hepatitis. Patients with liver disease including chronic hepatitis B or C, who are treated with antiretrovirals, have a higher risk of severe and potentially fatal liver complications. If you have hepatitis B infection, your doctor will carefully consider the best treatment regimen for you.
* If you have hepatitis B infection. Liver problems may become worse after you stop taking Biktarvy
* Do not stop taking Biktarvy if you have hepatitis B. Talk to your doctor first. For more details, see section 3, Do not stop taking Biktarvy.
* If you have had kidney disease or if tests have shown problems with your kidneys. Your doctor may order blood tests to monitor how your kidneys work when starting and during treatment with Biktarvy.

**While you are taking Biktarvy**

Once you start taking Biktarvy, look out for:

* Signs of inflammation or infection
* Joint pain, stiffness or bone problems

**If you notice any of these symptoms, tell your doctor immediately. For more information see section 4, Possible side effects.**

There is a possibility that you may experience kidney problems when taking Biktarvy over a long period of time (see Warnings and precautions).

This medicine is not a cure for HIV infection. While taking Biktarvy you may still develop infections or other illnesses associated with HIV infection.

**Children and adolescents**

Do not give this medicine to children under 2 years of age, or weighing less than 14 kg regardless of age. The use of Biktarvy in children under 2 years of age, or weighing less than 14 kg has not yet been studied. For children and adolescents who weigh 25 kg or more, Biktarvy 50 mg/200 mg/25 mg film-coated tablets are available.

Loss of bone mass has been reported in some children from 3 to less than 12 years of age who received one of the medicinal products (tenofovir alafenamide) contained in Biktarvy. The effects on long term bone health and future fracture risk in children is uncertain. Your doctor will monitor your child’s bone health as needed.

**Other medicines and Biktarvy**

Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines. Biktarvy may interact with other medicines. As a result, the amounts of Biktarvy or other medicines in your blood may change. This may stop your medicines from working properly, or may make any side effects worse. In some cases, your doctor may need to adjust your dose or check your blood levels.

**Medicines that must never be taken with Biktarvy:**

* rifampicin used to treat some bacterial infections such as tuberculosis
* St. John’s wort (Hypericum perforatum), a herbal remedy used for depression and anxiety, or products that contain it.
* If you are taking any of these medicines, do not take Biktarvy and tell your doctor immediately.

**Talk to your doctor if you are taking:**

* medicines used for treating HIV and/or hepatitis B, containing:
* adefovir dipivoxil, atazanavir, bictegravir, emtricitabine, lamivudine, tenofovir alafenamide, or tenofovir disoproxil

* antibiotics used to treat bacterial infections, containing:
* azithromycin, clarithromycin, rifabutin or rifapentine

* anticonvulsants used to treat epilepsy, containing:
* carbamazepine, oxcarbazepine, phenobarbital or phenytoin

* immunosuppressants used to control your body’s immune response after a transplant, containing ciclosporin
* ulcer-healing medicines containing sucralfate
* Tell your doctor if you are taking any of these medicines. Do not stop your treatment without contacting your doctor.

**Get advice from a doctor or pharmacist if you are taking:**

* antacids to treat stomach ulcers, heartburn, or acid reflux, containing aluminium and/or magnesium hydroxide
* mineral supplements or vitamins containing magnesium or iron
* Get advice from your doctor or pharmacist before taking Biktarvy if you are taking any of these medicines.

Antacids and magnesium supplements: you will need to take Biktarvy at least 2 hours before antacids or supplements containing aluminium and/or magnesium. Or you can take Biktarvy with food at least 2 hours after.

Iron supplements: you will need to take Biktarvy at least 2 hours before iron supplements, or you can take them together with food.

**Pregnancy and breast-feeding**

* If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor or pharmacist for advice before taking this medicine.
* Tell your doctor immediately if you become pregnant and ask about the potential benefits and risks of your antiretroviral therapy to you and your child.

If you have taken Biktarvy during your pregnancy, your doctor may request regular blood tests and other diagnostic tests to monitor the development of your child. In children whose mothers took nucleoside reverse transcriptase inhibitors (NRTIs) during pregnancy, the benefit from the protection against HIV outweighed the risk of side effects.

**Do not breast-feed during treatment with Biktarvy.** This is because some of the active substances in this medicine pass into human breast milk. Breast-feeding is not recommended in women living with HIV because HIV infection can be passed on to the baby in breast milk. If you are breast-feeding, or thinking about breast-feeding, you should discuss it with your doctor as soon as possible.

**Driving and using machines**

Biktarvy can cause dizziness. If you feel dizzy when taking Biktarvy, do not drive or ride a bicycle and do not use any tools or machines.

**Biktarvy contains sodium**

This medicine contains less than 1 mmol sodium (23 mg) per tablet, that is to say essentially ‘sodium-free’.


#### 3. How to take Biktarvy 50 mg/200 mg/25 mg film-coated tablets

 

Always take this medicine exactly as your doctor has told you. Check with your doctor or pharmacist if you are not sure.

There are two strengths of Biktarvy tablets. Your doctor will prescribe the appropriate tablet for your age and weight.

**The recommended dose is:**

Children 2 years of age and older, who weigh at least 14 kg but less than 25 kg: one tablet each day with or without food (one 30 mg/120 mg/15 mg tablet).

Due to the bitter taste, it is recommended not to chew or crush the tablet. If you have difficulty swallowing the tablet whole, you can split it in half. Take both halves of the tablet one after the other to get the full dose. Do not store the split tablet.

The score line on the tablet is only there to help you break the tablet if your child has difficulty swallowing it whole.

The 90-day multipack contains three 30-day packs together.

* Get advice from a doctor or pharmacist if you are taking:
* antacids to treat stomach ulcers, heartburn, or acid reflux, containing aluminium and/or magnesium hydroxide
* mineral supplements or vitamins containing magnesium or iron
* See section 2 for more information on taking these medicines with Biktarvy.

If you are on dialysis, take your daily dose of Biktarvy following completion of dialysis.

**If you take more Biktarvy than you should**

If you take more than the recommended dose of Biktarvy you may be at higher risk of side effects of this medicine (see section 4, Possible side effects). Contact your doctor or nearest emergency department immediately for advice. Keep or take the tablet bottle or carton with you so that you can easily describe what you have taken.

**If you forget to take Biktarvy**

It is important not to miss a dose of Biktarvy.

If you miss a dose:

* If you notice within 18 hours of the time you usually take Biktarvy, you must take the tablet as soon as possible. Then take the next dose as usual.
* If you notice 18 hours or more after the time you usually take Biktarvy, then do not take the missed dose. Wait and take the next dose at your usual time.

If you vomit less than 1 hour after taking Biktarvy, take another tablet. If you vomit more than 1 hour after taking Biktarvy you do not need to take another tablet until your next regularly scheduled tablet.

**Do not stop taking Biktarvy**

Do not stop taking Biktarvy without talking to your doctor. Stopping Biktarvy can seriously affect how future treatment works. If Biktarvy is stopped for any reason, speak to your doctor before you restart taking Biktarvy tablets.

When your supply of Biktarvy starts to run low, get more from your doctor or pharmacist. This is very important because the amount of virus may start to increase if the medicine is stopped for even a short time. The disease may then become harder to treat.

If you have both HIV infection and hepatitis B, it is especially important not to stop your Biktarvy treatment without talking to your doctor first. You may require blood tests for several months after stopping treatment. In some patients with advanced liver disease or cirrhosis, stopping treatment is not recommended as this may lead to worsening of your hepatitis, which may be life-threatening.

* Tell your doctor immediately about new or unusual symptoms after you stop treatment, particularly symptoms you associate with hepatitis B infection. If you have any further questions on the use of this medicine, ask your doctor or pharmacist.


#### 4. Possible side effects

 

Like all medicines, this medicine can cause side effects, although not everybody gets them.

**Possible side effects: tell a doctor immediately**

* Any signs of inflammation or infection. In some patients with advanced HIV infection (AIDS) and a history of opportunistic infections (infections that occur in people with a weak immune system), signs and symptoms of inflammation from previous infections may occur soon after HIV treatment is started. It is thought that these symptoms are due to an improvement in the body’s immune response, enabling the body to fight infections that may have been present with no obvious symptoms.
* Autoimmune disorders, when the immune system attacks healthy body tissue, may also occur after you start taking medicines for HIV infection. Autoimmune disorders may occur many months after the start of treatment. Look out for any symptoms of infection or other symptoms such as:
* muscle weakness
* weakness beginning in the hands and feet and moving up towards the trunk of the body
* palpitations, tremor or hyperactivity

* If you notice these or any symptoms of inflammation or infection, tell your doctor immediately.

**Common side effects** (may affect up to 1 in 10 people)

* depression
* abnormal dreams
* headache
* dizziness
* diarrhoea
* feeling sick (nausea)
* tiredness (fatigue)

**Uncommon side effects**

(may affect up to 1 in 100 people)

* anaemia
* vomiting
* stomach pain
* problems with digestion resulting in discomfort after meals (dyspepsia)
* wind (flatulence)
* swelling of the face, lips, tongue or throat (angioedema)
* itching (pruritus)
* rash
* hives (urticaria)
* joint pain (arthralgia)
* suicidal thoughts and suicide attempt (particularly in patients who have had depression or mental health problems before)
* anxiety
* sleep disorders Blood tests may also show:
* higher levels of substances called bilirubin and/or serum creatinine in the blood

**Rare side effects**

(may affect up to 1 in 1000 people)

* Stevens-Johnson syndrome (SJS) is a serious life-threatening condition which usually starts with flu- like symptoms. A few days later other symptoms appear including:
* Painful red or purple skin that looks burned and peels off
* Blisters on your skin, mouth, nose, and genitals
* Red, painful, watery eyes

* If you have any of these symptoms, stop your medicine immediately and tell your doctor straight away.
* If any of the side effects get serious, tell your doctor.

**Other effects that may be seen during HIV treatment**

The frequency of the following side effects is not known (frequency cannot be estimated from the available data).

* Bone problems. Some patients taking combination antiretroviral medicines such as Biktarvy may develop a bone disease called osteonecrosis (death of bone tissue caused by loss of blood supply to the bone). Taking this type of medicine for a long time, taking corticosteroids, drinking alcohol, having a very weak immune system, and being overweight, may be some of the many risk factors for developing this disease. Signs of osteonecrosis are:
* joint stiffness
* joint aches and pains (especially of the hip, knee and shoulder)
* difficulty with movement

* If you notice any of these symptoms tell your doctor.

During HIV therapy there may be an increase in weight and in levels of blood lipids and glucose. This is partly linked to restored health and life style, and in the case of blood lipids sometimes to the HIV medicines themselves. Your doctor will test for these changes.

**Reporting of side effects** If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the national reporting system listed in Appendix V. By reporting side effects you can help provide more information on the safety of this medicine.


#### 5. How to store Biktarvy 50 mg/200 mg/25 mg film-coated tablets

 

Keep this medicine out of the sight and reach of children.

Do not use this medicine after the expiry date which is stated on the carton and bottle or blister strips after {EXP}. The expiry date refers to the last day of that month.

Store in the original package in order to protect from moisture. Keep the bottle tightly closed. Do not use if the seal over the bottle opening is broken or missing.

Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.


#### 6. Contents of the pack and other information

 

**What Biktarvy contains**

The active substances are bictegravir, emtricitabine and tenofovir alafenamide. Each Biktarvy tablet contains bictegravir sodium equivalent to 30 mg of bictegravir, 120 mg of emtricitabine and tenofovir alafenamide fumarate equivalent to 15 mg of tenofovir alafenamide.

**The other ingredients are****Tablet core**Microcrystalline cellulose (E460), croscarmellose sodium (E468), magnesium stearate (E470b).

**Film-coating**Polyvinyl alcohol (E203), titanium dioxide (E171), macrogol (E1521), talc (E553b), iron oxide red (E172), iron oxide black (E172).

**What Biktarvy looks like and contents of the pack**

Biktarvy 30 mg/120 mg/15 mg film-coated tablets are pink, capsule-shaped, film-coated tablets, debossed with “BVY” on one side and a score line on the other side of the tablet.

The tablets are supplied in a bottle. Not all pack sizes may be marketed.

Biktarvy comes in bottles of 30 tablets and in packs made up of 3 bottles, each containing 30 tablets. Each bottle contains a silica gel desiccant that must be kept in the bottle to help protect your tablets. The silica gel desiccant is contained in a separate sachet or canister and should not be swallowed.


####  Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 
PMSWI:
** EU/1/18/1289/001 **PHPID:
** 0xF79CABF272B6A7EEF104DDDA44E827gy **
-------

Full name: **Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion**

 - Invented name part: ** Biktarvy ** 

 - Scientific name part: ** bictegravir/emtricitabine/tenofovir alafenamide ** 

 - Strength part: ** 50 mg/200 mg/25 mg ** 

 - Pharmaceutical dose form part: ** film-coated tablets ** 

 Name usage: **English (United Kingdom)** 

-------

 Authorised dose form: **** 

 Legal status of supply: **Medicinal product subject to medical prescription** 

 Domain: **Human use** 

 Resource status: **active** 

-------

 Product classification: 

 **Marketing Authorisation** 1 of 1

Authorisation number: ** EU/1/18/1289/001 ** 

 Region: ** ** 

Marketing authorisation holder: **Gilead Sciences Ireland UC** 

 Identifier: 
*  **ORG-100008368** 
 

 Status: ** Active (2018-06-21T13:28:17Z) ** 

 Package 1 of 2

PMSWI: ** EU/1/18/1289/001 ** 

GTIN: ** 07612345678904 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **90 Child-resistant closure** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

 Marketing status: 
 

 Pack size: 
 

Package: **1 Box** **(Cardboard)** 

Containing:

Package: **30 Child-resistant closure** **(PolyVinyl Chloride)** 

Containing: ** ** 

Manufactured Item

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 

 Package 2 of 2

PMSWI: ** EU/1/18/1289/001 ** 

Description:

Administrable Product (1 of 1)

 Dose form: ** Tablet ** 

 Unit of presentation: ** Tablet ** 

 Route of administration: 
*  ** Oral use ** 
 
Ingredients:

Ingredient

 Role: ** Active ** 

 Substance: ** BICTEGRAVIR SODIUM ** 

Ingredient

 Role: ** Active ** 

 Substance: ** Emtricitabine ** 

Ingredient

 Role: ** Active ** 

 Substance: ** tenofovir alafenamide ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Microcrystalline cellulose ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Croscarmellose sodium ** 

Ingredient

 Role: ** Excipient ** 

 Substance: ** Magnesium stearate ** 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "enhanced-bundlebik-alicia",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "en",
  "identifier" : {
    "system" : "https://www.gravitatehealth.eu/sid/doc",
    "value" : "EU/1/97/049/001"
  },
  "type" : "document",
  "timestamp" : "2023-04-25T11:55:27Z",
  "entry" : [{
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Composition/enhanced-composition1846d2b12fecbbb0310cd8c196c98a58",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "enhanced-composition1846d2b12fecbbb0310cd8c196c98a58",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi"]
      },
      "language" : "en",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><a name=\"Composition_enhanced-composition1846d2b12fecbbb0310cd8c196c98a58\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition enhanced-composition1846d2b12fecbbb0310cd8c196c98a58</b></p><a name=\"enhanced-composition1846d2b12fecbbb0310cd8c196c98a58\"> </a><a name=\"hcenhanced-composition1846d2b12fecbbb0310cd8c196c98a58\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: en</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a></p></div><p><b>eu/fhir/ig/gravitate-health/StructureDefinition/Lenses</b>: <code>mock-lib</code></p><p><b>eu/fhir/ig/gravitate-health/StructureDefinition/Lenses</b>: <code>mock-lib2</code></p><p><b>eu/fhir/extension/dummyValidationReference</b>: <a href=\"#hcenhanced-composition1846d2b12fecbbb0310cd8c196c98a58/binary1\">Binary: image/png (50748 bytes base64)</a></p><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: indication</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ B90}\">HIV-infection/AIDS</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: pregnancyCategory</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ W78}\">Pregnancy</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: breastfeedingCategory</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 69840006}\">Normal breast feeding (finding)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: liver</li><li>concept: <span title=\"Codes:{https://icpc2.icd.com/ D97}\">Liver disease, other</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: contra-indication-hypericum</li><li>concept: <span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta XK4IUX8MNB}\">Hypericum perforatum L.</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: hepatitisB</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 66071002}\">Viral hepatitis type B (disorder)</span></li></ul></blockquote><blockquote><p><b>HtmlElementLink</b></p><ul><li>elementClass: hepatitisB</li><li>concept: <span title=\"Codes:{http://snomed.info/sct 66071002}\">Viral hepatitis type B (disorder)</span></li></ul></blockquote><blockquote><p><b>LensesApplied</b></p><ul><li>lens: <a href=\"Library-pregnancy-lens.html\">pregnancy-lens</a></li><li>elementClass: pregnancyCategory</li><li>explanation: This paragraph was highlighted because you are a female of 18+ years and this sections refers to potential issues with pregnancy or breastfeeding.</li></ul></blockquote><blockquote><p><b>LensesApplied</b></p><ul><li>lens: <code>indication-lens</code></li><li>elementClass: indication</li><li>explanation: This paragraph was highlight because you have stated in your IPS the diagnostic of HIV-1</li></ul></blockquote><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/</code>/EU/1/18/1289/001</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000155538}\">Package Leaflet</span></p><p><b>category</b>: <span title=\"Codes:{http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs F}\">Focused</span></p><p><b>date</b>: 2022-02-16 13:28:17+0000</p><p><b>author</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mra-1133a7374c78f1d40f41885344f06a5a\">Organization European Medicines Agency</a></p><p><b>title</b>: TEST PURPOSES ONLY - Biktarvy 50 mg/200 mg/25 mg film-coated tablets</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/composition-attestation-mode official}\">Official</span></td><td>2022-02-16 13:28:17+0000</td></tr></table><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Binary #binary1</b></p><a name=\"enhanced-composition1846d2b12fecbbb0310cd8c196c98a58/binary1\"> </a><a name=\"hcenhanced-composition1846d2b12fecbbb0310cd8c196c98a58/binary1\"> </a><p><b>contentType</b>: image/png</p><p><b>data</b>: <code>/9j/4AAQSkZJRgABAQAAAQABAAD/2wBD...</code> (base64 data - 50,748 base64 chars)</p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Binary",
        "id" : "binary1",
        "contentType" : "image/png",
        "data" : "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDACgcHiMeGSgjISMtKygwPGRBPDc3PHtYXUlkkYCZlo+AjIqgtObDoKrarYqMyP/L2u71////m8H////6/+b9//j/2wBDASstLTw1PHZBQXb4pYyl+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj/wAARCAQABAADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwC7mikzRUjFpabS0AOpabS0AOpRTaUUAPFPFRipFpiHUUUUAFFFFACUlLSUAFLSUUgFpaSlpgFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkNLSGkIa/Sq0hqxJVWQ0mUiFjUZNOY1GTSGLmlBqPNKDQMnVulTI3PrVUNUqN70CLQfNPBqBTUmc80xD800mjOO9NJoAaxqBzUjGoWqRkb1E1SNURpjGGkNONNNMQ2kp1JQAlJS0UANpKdSUxCUUtJQAUUUUCEopaSgApKWimAlFLSUAFFFFAgpKWigBKKWigBKKKKACiiigAooooAKKKKACiiigApaKKAClpKWgAooopDCkpaKYCUlLSUCCiiigAooooASilooASilpKACkpaSmB0FFJRUFC0tJRQA6lptLQA6lFIKUUAOFSLUYqRaYh1LSUtABSUtIaAENJSmkpAFFFFAC0opKUUwFooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQIKb3paTvSAZIeKqSGrMlU5DSZSImNRk05jUZpDDNGaaTRmgZKDT1aoAaerUAWkapVNVVap1bigRLmkJpM0hNADGNRNUjGompDI2qM09qYaYDTTacaaaAEopaSmISkpaKAEpKWigBKSlopiEpKWigBKKKKACkpaKBCUUUUwEopaSgAooooEFFFFABRRRQAlFLRQAlFFFABRS0UAJS0UUAFFFFABS0UUDCloopAJRRRTASkpaKBCUUUUAFFFFABRRRQAUUUlABRRRQBvUUlFSULS0lFADqWm0tADhSiminCgBwqVaiFSLTEPpaSloAKQ0tIaAGmkpTTaQC0UlLQMWnCmU4UCHUUUVQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQIKKKKAENJ2oNIeBSAhlNVJKsymqjmpLRE1Rk09jUZoAQmkzSGimAuacDUdLmgCwrVMrVUVqmVqQy0ppTUStTs0gENRNUhqNqAI2php7Uw0wGGkpTSUAFJRRTEJRRRQAlFFFABSUtJQAUlLRTEJSUtFACUUUUCCkpaKAEooopgFJS0UAJRS0lABRRRQIKKKKACiiigAooooAKKKKACloooGFLRRSAKKKKAEooooASiiimISiiigAooooAKKKKACkpaSgAooooA3KKSipKHUUlLSAWlptKKAHCnCm0opgPFSrUQqVaBMfS0gpaYgpDS000DENNpTTTSGLRSUUAOpQabSg0CHilpgNLmmA6ikzRmgBaKTNGaAFopM0ZoAWikzRmgBaKSjNAC0UmaM0ALRSUZoAWijNGaACijNGaACikooAWiiimAUUUUAFFFJQAtFJRQIWikozQAtFJmjNAC0hpM0hNIANIx4oHWkkPFAyvKaquanlNVnNSURNTDTmppoGNoopKYgpM0Gm0APBqVGqvmnq2DQMuKakBqujVKDxUgONRtTyaYaAGNUZp7Uw0wGmkpTSUAJSUtJTEFJRRQAUUUlAC0UlFABRRRTEFJS0lABRRRQAlFLSUCCiiigBKKWigBKKWkpgFFFFABSUtFACUUtFABSUtFABRRS0gCiiloASiiigAooooASiiigApKWkpiCkpaSgAooooAKKKKACiikoAKKKKANqlptLUlC0tJRSAdS02loAcKUU2nCgB4qVahWplpiZIKWmilpiCkNLSGgY0000ppppAFLSUUDFpaSlFACiloFLTEFFLRQAlFLRQAUUtFACUUtFACUUtFACUUtFACUUtFACUUUUAFFLRQAlFLRQAlFLRQAlFLRQISilooASilooASkp1JQAmKKWigBtIafSEUANFRytT24FV5DmkykQyGq7GpXqJqRRGaYakIppFADDSU/FIVoAZikp+2kIpgMoFLikoETxmrCmq0dWF6VLGO+lNanU00AMaozUhqM0wGmkpTTTTAKSikoEFFFJQAUUUUAFFFFABRRRTEFFFFACUUtFACUUUUAFFFFACUUtFAhKKWkoAKKKKAEopaKAEopaKACiloxQAUYpcUtAxtFOpKAEpKWigQlFFFACUUUUAFJS0lMAooooEJRRRQAUUUUAFJS0lABRRRQBs0UlFSUOopKWkAtLSUUAOFOFNFKKAJBUy1AtTLTEyQUtIKWmIKaacaaaBjTTTTjTDSAKWkooGLTxTBUgoEKKWgUtMAooopgFFFFABRRRQAUUUUAFFFFAgooooAKKKKBhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAgooooAKKKKACiiigBKKWigCOQfL9KquKuGoJIz1UZHpUtDTKjCoytWCuajKUiyAgCk57CptlGygCuQaQg+tWhCx6Kx+gprxFfvKR9RigLlUg+tN+tWGSomWgCM03qaeRQq0wJIxU6jio0FTCkAdKYaf2pjUgGGozUhqM0wGmmmnGm0wEpKWkoEFJS0lABRRRQAUUUUxBRRRQAUUUUAFFFFABRRRQAlFLRQAlFLRQAlFLRQAlFLRQAlFLRQAlFLS0AJS4oxS0gExS0tFAxKSlooAbSU6kxTEIaSlpKBCUUtJQAUUUUwEooooEJRS0lABRRRQAUlFFABRRRQBr0UlLUlC0tNpaQxwpabSigQ4U4UwU4UASLUy1AtTLTEyUUtNFOpiCmmlpDQMYaaacaYaQxaKSloAUVItRipF6UCHClpBS1QgooooAKKKKBhRRRQAUUUUAFFFFAgooooGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAgooooAKKKKACiiigAooooASmmnUhoAjZQ3UA0nlJ6H86eaBSGNEMf8Adz9TUioq9FA/CgUtMQUdRg0UUAUrmAIdyj5T29DVNlrXlXfGRWe681LKTKhWlC1KVpMUigAp9NpaQBmmNS5ppNADTTDTjTDTAQ000ppDTASkpaSgQlFFFABRRRTAKKKKBBRRRQAUUUUgCilooASilpKACiiigAopaKAEopaKAEpaKKACilooASlxRS0DCiiigAooooAKSlooASkpaKAG0lONJTENpKdSUCEooopgJRRRQIKSlpKACiiigBKKWkoAKKKKANWlptLUli0tJRSAdThTKcKAHCnCmCnCgQ9anSoFqZKaEyUU6minUxCGmmnU00DGGmmnGmmkMKKSloAcKkWoxUi0xDhS0gpaYgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKBhRRRQAUUUUAFFFFAgooooAKKKKACiiigAooooAKKKKACiiigBKQ0tIaAGmlFIaUUgHCigUUwCiiigAqnKvNXKrSck0mNFUimmpWqNqkobTSaU0wmkMCaaTQTTSaYCE000pptAAaSiimAlJS0lAgpKWkoAKKKKYBRRRQIKKKKACiiikAUtFFABRRRQAUUUUAFFFFAwopaKACilooAKKXFFABSUtJSGFFJRTEFFFFABS0lFAC0lLSUAFNp1JQA2kp1IaYhtFLSUCEopaSmAUUUUCEooooAKSlpKACiiigDUopKWpLFpabS0gHUoptKKAHCnCmCnigQ9etTpVdanSmhMmFLTRTqYgNNNOppoAaaYaeaaaQxKKKKBiipVqIVItMQ8UtIKWmIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBKQ0tIaAGmlFIaUUgHCigUUwFooooAZJwhqqzEd6uEZBB71TcbSVPUVLKRGzA9RUTU9qiYGpKENMNKc+9MJoADTTSk0lMBppKU0lACUUtJTASiiigQlFFFACUUtJQAUUUUAFFFFAgoopaBhRRRQAUUUUAFFFLQAUUUUAFLRS0AFLijFLSGJig0tIaAENJS0hpiEpKKKACiikoELS0lFAxaWkooAKKKKAGmkNONIaBDaSlpKYgpKWimAlFFFAgpKWigBKSlooASiiigDTopKKkodRSUtIYtKKbThQA4U4UwU4UASLUyGoFqZDTETA06owadmmIdmkNJmkzQAGmmgmkJpAFJRS0AKKkWoxUq0wHClpBS0xBRRRQAUUUUAFFJmjNAC0UUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACUhpaaaAGmnCmmlFIB4paQUtMAooooAKjliEg9GHQ1JRQBnyI0f3xgeo6U3y9w+Vq0ajNvETkxrmpsVcobEU4csCfTmnfZlPVZj/wCr6Ron3FC/QU+nYLmb9hyeI5MepYCmnTZD90qPq3/wBatGWVIULucD+dZdxfzS5Ef7tfbrS0GrsbLaCH/WTxr7ck1UkYI+AQ49QCKXHPPLH9aRR3NAxaSgmikAUlLRTASkpaKBCUlLRQAlFLRQAlFLRQAlLRRQAUUUUAFFFLQAUUUtABS0UoFAABS4oApwFIYmKXFPC45NIRSAYaaaeRTSKYDTSGnEU00wEpKWkoEJRS0lAgpaSigBaWkpRQMKKKKAENIadSGgQ00lKaSmISiiimAlFFFABRRRQISiiigBKKKKANGikpakoWlptLSGOFLTaWgBwpwpgpwoAeDUqmoQakU0CJgadmogadmmIfmmk03NFABmlFJSigBwpQKBSigBQKeKZTgaYD6Wmg0tAhaKSimAUmaCaaTSAUmjNNzSUDJAaWmCnigQtFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiikoADTTTjTTSAaaUUhpRQA8UtIKKYC0UhOBRQAtFFNZgPegBaKhacr/CCPrUkciyLuX8j2oAdQSACT0FFRzHgDsTz9KQFWaJ5iJH7nCqO1VJAiqQOO4NW5piV2nH5VSl5A9Kk0RE3L7unOfpTSeeKe1MNACUUUUwCiiikAlFFFMApKWkoEFFFFABRRRQAUUtFACUtFFABS0YpcUAGKMUuKdikMQClApQKcBQAgFPAx161LFFwGbp2FTdOnH0osK5VPuDScGrWT60hAPUA/hRYLlUrTSKtGFT935T+lQspVtrDBoC5CRTSKlK0wigZHikNPIpMUxDKKWigBtFLRQIKKKKAFpaQUtAxKQ06mmgBppKcaSmIbRS0lAgpKWkpgFFFFAgpKWkoAKSlpKAL9LTaWpKHUUlFADqUU2lFIY6nCm0ooAeKkWohUyCgQ8U4CkUVIBTEMxRin4pDQAw0ClNNoAkBpc1HmjdQBLmlBqLdSg0ATA07NRA04UwH5pM0lFAgJptKaSgYUUlFADgaeDUdOFAh9LSClpgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRSdKAFpCaazgVC0uKlsaRPnJxSGoI5hu57CpjQncGrDTTlpppVpgPFLSUx3AFDYJBKwCj3qOKYB9p6GoZZAx9wKrs/FRfUtLQ1Hbbx3qB5AKhNxvUMepFQvLmquRYleSm20xW6Rc8PkH+lVy+als1Ml0h7LljQBq1XujhlPqDVio54zJEQPvDkU2CM6TmoSKnbmoyDUGhCwpuKsrEW6ClNu3pTEVMUlTtGR2qIjFADKKU0lACUUtJTAKKKKBBRRRQAUUUUAFFLiloASlxSgUoFIBAKUCnBaeFoGMApwWnhaeE9qAGBasRQY+Zx9BU0Vts+Z/vdh6U9qaRLZEabTjSGgBtFLSUAKKeyLKu1h9D3FNWpFoApSRtE21vwPY1GRWoyq6lWGVNUpoGhPPzIejf40NAmVSKaRUxWoyKRRHikxTyKaRTENpKdikoASiiigBaWkFLQAUlLSGgBppDTjTTQISkpaSmIKKKKAEopaSmAUlLRQISkpaKALtFJS1JQtLTaWgB1KKbSikMcKUU0U4UAPWp0qBanSgRKoqQCmrThTEBpppxprUAMJphNK1MNIYZpc02loAcDT1pgqRKYh6ipAKaop4FMQYoxS0UAJikIp1FAEe2jFSYoxQAzFKKXFGKAFFLSUtMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooprOFFACk4qJ5PSopJqi+d+gwPU8VDZaQ55KiJJGT0pxCp1O4/pULuWNSULu5q9E26FD7Vn1fiG2BAfTNOIpDiaeBgc9T0FIq7Rub8qHbYMt1NWQDtgYqrNLimSz1XJLnJqGzRIkXk7i4HtioZDild8cCnW0Pnvuf/AFann39qRQSI0UUTH7rKPwNQFq055QQVwCD2rOkRM5UY/Gncm1xoNX7J1iU5+83Ws9eKlU02wUTaRw65FLVC0kIlAPRuDWhVJmbVmQy2ySndyreo7/WoRZkH76n/AIDVyiiwXZALcDq7H6cUpt4z/eH/AAI1NRTC5TmgKjruX17iqEqbTWy4yjD2rNmWpaKTKRFNqRxTDSGNpKWigBKKKKYgoopaACilpQKAExTgKAKeFpDEAp4WlC1Iq0CGhaeEp6pU8UJfnovrRYLkSRFjhRk1bihEfPVvWpERUGFGBS1ViWxpqNqkNRtQIhPWm05qaaRQlJS0lADlqRajWpFoAkFOwCCCMg9QaaKeKZJQngMXI5j/AJVXZa1+CMEZB6iqVxbmL5l5jP8A47Q0NMpEUwip2WoyKksiIpDTyKaRTENopaTFABS0lKKAFpKWkoAaaSnGmmgQlJSmkpiEopaKAEopaSgBKKWkpgJRS0lAi5RRRUlC0tNpaAFpRSUopDHClFNpwoAkWrEdVlqzHQImWn0xafVCENManmmNSAjaozT2phpDClptKKAHCpkqEVMlNCJlp1NWnUxBRRRTAKKKWgAooooASilooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKQmkZgKheWk2Ow9nxULyZqN5KhZ6hstIlMmOgFRtKT3qMtTc0DHFs0lJTgKBj4Y/McL+f0rRC9z07VHbReXHubq38qWSXHSq2IerB5AvLdewqnPMWPWnOGc/fA+tMPlR/7bep/wqRoiCFuTwPWmu4AwOlLLKWPNVycmgoCcmrNoxEcn1FVasRfJb5/vHNDAWR+ahZs0O2TUeaSQx4qRaiFSpTEWrf/AFyf71aVZtsMzJ9a0qpGcgoooqiQooooAD0NUJhwK0KpyL1HoaTKRQcVCRVqRagYVJRFSU8ikxQA2ilxRigBKXFLinAUANxTgKcFp4WgBqrUirTlWpVSgQ1UqRUqSOIt06etWUjVOnX1ppCbI44Mcv8AlU1LRVEiUUUUAIajapDUbUgIDTTT2phpDEpKWkpDHLUi1GtSLTAlFOFNFOFMkWiiimBSnttmWjGV7r6fSqpGa1jVSeANlk4PcetJoaZQIphFTsPzqMipKI8UlPIpuKAG0tGKKAFpKWigY000040hpiGmm040lMQlFFFAgooooASilpKAEpKWimItUUlLUlC0tJRQAtKKSlFIY4U4UwU4UASLVmOqy1YjoETrT6YtPqhCGmNTzUbUgI2qM9akaojSGLSim0ooAeKmSoRUqmmhEy0+ogaeDTEOopM0uaAClpKWmAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFMdsCnE4FVZnyalsaQkklQM9IzVExqS7Cs1NJppNFAxaBQBT1XpjqaAADpgZPtVyC22gPL17L6fWnwQiFdzY3n9KSWbHQ09ib3HSSAVVklpjy5qBnpDSJGkNQs9NLU2gYE5pKXFOC+1MBEQu4Ud+/oKsTEAYHAHAqaOAwJ8332GT7D0qvL1qWNFdqbTmptUMctTJUK1MlIRctf9en4/yrQqhaf69Px/lV+rRnIKKKKZItFFFABUE64bd2PBqekIDAg9DQBnSJzVdlq/IhBwevY+tV3SoLTKpWm7anKU3ZQMh20u2pdlKEoAiC08LUgSnKlAhgSpFSnhKmjhLew9TRYLkSpVmODu/5VIkap0HPrT6qxNxBwOKWiimIKKKKAEooooAQ1G1SGo2pAQtTDTzTDSGIaSlNJQMctSLUa1ItAEop1NFOFMkWiilpgNNRtUhqNqQFWZQfrVZlINW5KhIzSKRXIppFSsuKaRSKI8UmKeRSYoASg0tFADDTTTzTTTEMNIacaaaYhKKKKBBS0lLQMSg0tJQISkpaKALFFJS0hi0tNpaAFp1NpaQxwpwpgpwoAkWrMdVlqxHQIsLTxUa08VQgNRtUhqNqQETVGakaojSGFKDTaUUASCpFNQg08NQBMGpwaoN1AencRZ3UBqg30qvTAs5ozUO+lDUCJc0tRg08UAOopKWmAUUlJmgB1FNzS5oAWikpaACiiigAooooAKKKKACiiigAooprHAoAZK2BVN2qWV6rMazZaGsajJpSaaaChKUCkp6D1oAcq1et4fLXe4+bsPSkt4AgDyDnqB6UTy44FPYncSaXqM1TeTNJJJk1AWpFWsOZqYTSE0lMBaUCgCpY42dgqjJPagBqoSQAM1p2tqIwHcZft7UttbLD8xwX9fT6VZqkiGyrcffaqEtXp/8AWN/ntVKWs3uXHYqtTae1NqihRUyVCKmSkSXLYhZkJ+laFZi9OOo5rTU7lBHcZq0RIWiiimSFFFFABRRRQA1lDDDDIqCSEjtuHqOtWaKBmeUB6GmmOr7Roxyygn1pht17Fh+NKw7lPZShKt/Zx/eP5UogXuSaVguVNmKkSJm6Lgep4q0qKvRQKdTsK5EkKryfmPvUtFFMQUUUUAFFFFABRRRQAUlLSUAIajapDUTUgIjTDTjTTSGIaSlpKBjlqRaiWpVoAlWnCmrTxTJCloooAaajapDUbUAV5KhNTSVEaRQ3GaR4iF3AZHf2qRFyauRpgUBcyyKaRVq5hCNuT7p6j0quaTGmMoxSmikMYRTTUjCmEUwGGmmnGmmmSJSUppKYBS0lLQAUUUUAJSUtB6UCJqKKKQxaWkpaAFpabS0hjhThTRSigCRetWIzVZanQ0CLCmng1CDTw1MQ8mmMaQtTC1ACMajNOJplIYuKXFApaAExRmlppoAXNGabS0ALmng1HT1BNMB4apFNMVakC0xDlqVajAqQUCFooozTAQ00mlNIaQBSim0oNAD6Wmg0uaAFpKQmk3UwH0UzdTgaAFopKWgAooooAQ1DK+BUjnAqpK3NS2UkRu1QsacxqMmpLENOjjaVwiDJPNNq3br5MBkP3pOnsKYmVGUqxVhgjrV20t8YkkGP7oP86haQH/e9alS5Lrhj8w/WlcbTJZZODiqMr5NPlkz3qszUtwSsNZqbQTSVQBTgKAKs2sPmSjI+UcmgQkNu0nI4X+8f881oQxrGuFH1Pc0GnrVENjxTqQUtAipP/rG/D+VU5KvXIxID6iqcgrN7msdiowplSuKjNMYCpUqIVKtAizGav2zZhA/unFZ0Zq5avhyv96miWW6KKKsgKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkpaSgBpqNqkNRtSAhammnN1pppFDaKKKQCrUq1EtSrTAlWnCmrThTJHUUUUANNRtUhqNqAK71HipH60irk0ih8KVYJwtJGuBTJmwKYivM2TVYj0qR2yaiJpMaENJTutGKkoTGRUZqUcGmyLg0ICE001IaYaoQ00lONNpiEpaKKACloooASmt6U6mGgTJ6WkpaQxaKSloAWlpKWkMWnCm04UAOFTJUI61MlAEoNOzTBTqBCE00mnGozQAhNJmkNNoAlBp1RK1P3UAOpDSbqQmgBaeq5pi8mp1HFMBoSpVSgCpVFMQgWnAU7FFAhMUZpTUbGgBxak3VCzYpoegZY3UmaiD0u6gB+aUGoi1G+gCbNLuqDfS76AJC1JuqPNGaAH7qeGqGnrQBKGpwpiin0xC0hOKKY7YpARyvxVR2qSV+arOag0QjGm0GkoGPij82VY+zHn6d6nuXzIfQUWgKRvOR1G1P6moSPMc5+6OWNDBDD93cerfypiyYcHNLM+SagzzSsUTu1RE0rHmm00IKcBSCpFWmIVFrTgi8qPB+8eWqG0g/5aMOB933PrVo0yGxppy0009aZI8UtIKWmBFcrmMN/dNUZBWmQCCD0NUJE2sVPaoki4spuKhIqy4qBhSLGinrTKcKBFhDU8TYdT6GqyGpl5piZqUVHC++IHuODUlWZhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUlLSUANNRtUhqNqQELU005qaaRQ2iiikAq1KtRLUq0xEq04U1acKYh1FFFMBpqN6kNRtSAgbrT4l5pMZNTRrgUDHdBVOd8k1albCms+RsmgCJjTaGNIKQyaFdzU6aExnI+6f0p1spzmrEvK7SOtAFCnH5k9xTpIzGwB79DTVPPtUlEBFMIqaRcGozTERmkpxpKYhtFLRTAKKKKAGsaYacetNNMksUtJRUlC0tJS0ALS0lLSGKKUUgpRQA9amSoVqdKAJVFOxQop+KZJGwqJhVgiomFIZAaYakYVGaADNLmm0UAPzRmmZpw5oAkTrVpOlVVFWYzTQmSgU9aYDTgaYiSkpM0m6gBxqJqeTTDQBGVzTdlTAUuKBkG3FNJxU5FQvSAYWpM000ooGOFSAUwVItAgxSgU7FOVaYCBaeq04ClAoEAFLRQTgZpgIxwKrSPSyPVZ2qGy0hrtUJNOY0ykMKkgi8+YKfuDlvp6VHyTgDJPAHrWhGgtocdWPLH1NNAx05QgAthR2WqEsihdqDC9fc06eUk1VdqW40rDHbNIOtIaUdDTGLmlFIKcKBDlFXLW2MnzNwg/X2qvEmSK0rZ+NmMAdKE9RPYm6DA4ApppxppqiBpp60w09aBDxS0gpaYBUNymV3jqOv0qajr1pMEZci1XcVdkTaSvoarOKg1RXNKKU02gCVTUyGqympkNAF62fa+Ozfzq3Wap9OorQjcOgYVaIY6iiimSFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFJS0lADTUbVIajekBCaaacaaaRQ2iiikAq1KtRLUq0xEq08UxaeKYhaKKKYDTUbVIajakA1Rk1N0FMQU8nAoArXDcYqi5qzcNk1Uc0hoaaVRk02nxDLUDL0AwtKzZalQYWhRl6BEd0w2gY6VVqW8cbiveok5ShlIVhuTPcVAwqwvXHrUTripQyE001IRTDVCG0UtFAhKDSimsaaBjCc0hpTSUySxRRRUlC0tJS0AFOptOpDFFKKQU4UAOWrMYqutWI6BE6in01afTENIqJhUxqNhQwK7Co2FTMKiakMZSU402gYlSrTAKeKBDxUqGoRT1agCxupd1Q7qTfTEWN/FNL81AZKaZKLhYs76A2TVXzKkRsmgC0KWmIeKfTENbpUElWDUElJjK5PNOU01hQvWgZMKmUVCtTrQIcBTwKaKeKYhaKKKYBTZDhKdSOu5CKQIpSGoHNTNyKhcVBoiI0lKaQ8An0oAs2SfM0pH3eF+venTy8VIAIbdU6EDnnuetUZXyxpsEMduagY05jUZoSGFO9qQdaU0AAp68kAUwVInHNAyxFgc9u1X7aMj5ycZ7VnIe1XIZSO9StxNaFs000qsHHvSGtDMaaetMNPWgQ8UtIKWmAUUUUAVrlfnB9RVOQVoXI+QH0NUZRWb3NIlVhUdSvURoKFBqVTUOacpoEW0arVvJtbaejfzqgjVYU5FNEs0qKhgl3fK33u3vU1WQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFJS0lADTUb1IajekBCaaacaaaQxtFFFIYq1KtRLUq0xEq04U1aeKYhaKKSmAhph6080mKQAvSmynCmn4qC4bAoApyHk1XY1K5qE0ihKngXLVBVy1FAFoDC0JwCaGbApkh2xHnFAihcHdMafEM1F95s1ftYeNxpMorEc0SDKhqlmTbIwpgGVYfjSYFZhTDUrjmozTAZRiloxTAQ8D3NRHmpG5NRmmiWNpKU0UxFiiiipKFoopaACnU2nCkMUU4U0U4UAPWrMdVlqzHQInWpBTFp9UIQ1G1SGmNSYEDVE1TNUTUhjDTadRigYgpwoAp4WgQ2kzipCtRstABvo30w0maAHFqTNNpaAHA1NGar1KjUAW0apA1VVapVamIlY1C1PzmmkZoAhYUzoanKVEU5oGOU1KrVAOKcrUCLSmpAarq1SK1MRMKKQUtMAooooAqzptfPZuarOK0JU3oR3HIqkwyKlopMrkU6GPzJ0U9M5P0FKRU9ou1XkI5PA+lJDYl09UHNWJ2yTVVzSKWxGxptBpKoQ4dKKDSUhiipVHAqJRk1MKTGiROKnU1XU1IppDLccmKs5DjjrVBWqxFJg0JkNEh609aRvmww/GlWtEQx4paQUtMQUUUUAMn5iaqEtX5T8mPWqE3Ws5blxKr1EaleojQixtOBpuaAaYiZWqZGqspqVGpAW1b35HQ1eifzEz36Gs1GqxBJskGejcGqTJaLtFFFUQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUlLSUANNRvUhqN6QEJpppxpppFDaSlpKQDlqVaiWpVpiJFp4pi08UxC0tJS0wEopaQ0AITVS4arJPFUbhuaQFdzURp7GmUigHWr1sMLVNBk1oQLhaAH9TUV02FAFTcbuKr3OC4oERQR75AK1I0CqBUFnFtTcRyatUIGypeL8wPtVZB8+PUGrlyMgVWUfvF+tJjRWkXmoSKtTL8xqLyz1x1oGQ4peB1qUx4qGQ9hTBkTHI5+tRmnsaYeTVECUuMnFHvSjpmgCfFFSEUwipKEpaKKAFpRSUopDFFOFIKUUAPXrVmOqy9asx0CZYWnimLTxVCENManmmNSAhaomqZqiakMZSgUYpQKQxVHNSAU1RUqimIaRUbCrG2mMtMCowpuKsGPNHlUAVqcBUvlUnl4pAMApcYqQLSlaAIt2KkV6ay00cUAWVepF5qvGMmrKjimIDUbCpTTCKAIWpoPNSMKVI6AEU1KhpBHTgmKYEymn1GoqQUxBS0lLQAlVZ02v7NzVuo5k3Rn1HIpDRnuCOg56D61YcCKIRjsMUkS7pQxHC8/jTLhqTKKkpyarMamkPNQMalFDTQKSlHSqEBooNORNx9AKQwX1qRTSEAdOlIDSKJRTgajBp2aQEwNSK1QA08NSAuxy7Rz0qdXVhms/d8tPjkxjBqkyHEvjHalqGOQMPQ1Jux1qkyGh1FIGB70mfxp3CxFM9U5DVuTYOsZqnI6ehFZstFd6hapXYVEzCmihppKCwpNwpiHg1IpqEMKcGFAFlGqdTkVUVxUyOKQjUt33xAnqODUtZ8MrIfl6dx61fVgyhh0NWmQ0LRRRTEFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSUtJQA01G9SGo3pAQmmmnGmGkUJSUppKQDlqVaiWpVpgSLTxTFp4pki0tJS0wCmsacTUZPNADX6VQmPzGrsh+U1nynJNIZCxpmeaU0lAyWL7wrQjBxVGAfMKvrwKQCqMZJqFU82f2qZyQhPrT7SPCbj3oAnAwMUhNKTTCaYiObpUKLlxUz8mlRcc1Iyu0Zklx2709ovQVYRAoJ7nmlYcY6VVhXM+YbASfTArPc5PJq5dnEmM5x/OqLEdP1oAYabTj+tJTEJinngAChQMZNIetAy4RSEVJikxUjI9tG2pQuadspAQYoqYpTCtAxopRRilFAD161YjquvWrEdAmTrUlRrT6oQGmNTzTGpARNUZ61I1MIpDG0oFAFOAoAUCpkFRKKnQcU0JihaCmakApcUxEQjpDHU2KMUAQeXSGMVMRTCaBkJTFNIqY1C1IBjCom4NSk1Cx5pDJ4qnB4qunSnbjTETZpCaYppTQAgGTU6rxTIxUwpiALShadRQAgFLRRTAWiiigAooprnCk0AQthFIHTrVKZs1ZlbiqUh61DLRA5qFqleoTQhiU7HFNp45FMEN704HHFIRg0lIoeG9aU+oqOnq1AxwNOBphGPpSg0gJAacGqLNKDQBMW+U0I9RE/LTValYC6kmGyKspLms4PTvM7igVi8Tk9cU1nYdDVVbjsaUzZpCsSm5dTzTGuAeqioy4PWomAPQ4pjsPaRD/AtRMU7KKawP1phJ9KaQCnb6U3A9KQmkzVCHcUoxTM0oNAiVSKmUiqwNSK1IZcjarltJ/yzP4Vmo1To9CJaNSiq9vMWOxjk9jVirICiiigAooooAKKKKACiiigAooooAKKKKACiiigApKWkoAaaiepTUT0gIjTDTzTDSKEpKU0lIBy1KtRLUi0wJVp4pi08UyRRTqQUGmA1jUdOY02gCOY/Kaz5OtXLhvlqi5pDIzSCg0CgC1bDmro4FVbYVbApDY2XkKvrVpRtQCqhGblatE0AITSdqDQKAGgc1KowKaopzHAxQIM1HNJsiZu+OKUtVS8l2gDnjtTApTHBOT71WPvUjnJx781EcnimIae5ox0HrR1NOQZJNACnjimdKcTk000AaFKKbmnA1BRIop+KYpqSmIYRUbCpjTGFIZCRRinkUYoGIvWrEdQgc1MlAidaeKjU08GmIU0w0+mmgCMimEVKaYaQxmKUClooActTp0qAVOnSqQmSiigUUxBRRQaAGE1C7U+QkVUeSkMk31E71C0lRlzSGSl6jLc0wsabmgC0j8U/dVQMRTxJQBaDUu+q2+lVuaQF6M1OpzVJGq3F0qkJktFFFMQtFFFABRRRQAU1xuQj1FOooAoOciqsgq9cJtfI6N/Oqki1DLRUeoTVhxUDU0MbTgcGm0UASYzSYxQp7U4c0hjcU3pUhGKQjI96BgpyMGjoab0px5H0oAUGlzTM06gBSeKYDS0wnBoAlDUbqjzSbqLASE5pNxFMzRmiwXH+ZS7/AHqOjFFgH7qQnNM5oyaYrimkpM0ZoELRSUUCHCnqajpwNAydTUyNVVTUqtUjLiPggg8jpV6KUSL6EdRWWhqeJypBHUVSZLRo0U2NxIu4fl6U6qICiiigAooooAKKKKACiiigAooooAKKKKACkpaSgBpqJ6lNRPSAiNMNPNMNIoQ0lKaSkA5akWolqVaYEq08UxaetMkcKRjxTqjY0wGNSUE0dqQytcniqL1cuTVNqQEZpV60lOTrTGXrYcVZzzUFuPlqYHGaQMjictdHParRqjbtm6Jq9SAKUCgU4CmIUCo2bmnscCoSaAEZsCs24Ys59F6/WrU8hCkjr2qjI275TnI60wImPHuajNPJyTTOvNMQe1PHyqfU9KaoJNOY80hjMUhFLQAScUwLeacppopRUjJlNPDVCDTgaQiUtTCaTNGaBhS0lOFAABUi00CnDigCRTTwahBp6tTES5oNNBozQAGmGlJpDQAlFFApAOFTp0qAVMnSqQMlFFAopiCiiigCGUcGs+Tqa0ZehrNlPJqSkQsaYTTmNRk0ALmkpM0UAOpRTacKAHipFqIVItAFiPrV6L7oqjH1q9F90U0JklFFFMQtFFFABRRRQAUUUUANdA6lTWe6kEg9RxWlVW6TBDjvwaTGjNkWq7Crsq1VcVJZAaKcwptMQop4NRinqaCkSdRTTwaVTinEBhxSGRkbhkdaQHBpfumlIyMjrQIaRQDSjpg0lAwpjU6kNAhoNB9aQ8GlBpiDNGaCKSgB2aM03NLmgLjs0lJRQAUUmaM0CFooopgFOFNpaQDxT1NRA08GkMnVqnRqqKamRqQFyKQo2R+I9avAhgCDkGstGq3bSYOw9D0+tUmS0WqKKKokKKKKACiiigAooooAKKKKACiiigApKWkoAaaiepTUT0gIjTDTzTDSKENJSmkpAKtSrUS1ItMCZakFRrUopkgaiY1I1QsaYDSaXtTT1pSeKQypcnmqjVYuG+aqzGkMbT4/vUzNSQ/epgaEI+Wnn7jU1OFHFEhKxntSAhtBm4rQqjYDMzH2q+aQMBThSCnVQiOQ1C5wKlc81XkPWkBVnbuOT2qmx/lVidhuJ9BgVVY+lNANPT60nfFB7mgUwHr90sPpSU4/KoFMNIAPNSIuOaai5NPkO1aAJRThTRTxSAKWilpDCilooABThTaetADhS5pAKWgQmacDTCaAaBkwalzUQNOzQIcTRTc0ZoAdRSA0uaAFFTp0qAGpUNNATClpoNOzVCCg0ZpjNSAinbANZshyTVq5k7VSY0ihjGmGnGm0AJS0lLTAUUooAp6ikAqipUWmqtTotIB8a1ci6VCi1OgxVITH0UUUxC0UUUAFFFFABRRRQAU11DoVPenUUAZsinkEcjg1UkWtO6TB3joeDVGVallopsKjNTuKiIoGNpRTaUUASc05TiiIg8EZqUxDGVNIY1gHGe9R8g1LsYcimkZ+tIBhHekIpxGDRTAZTaeRTTQA0jIpnQ4NSUjLmmIQGkIpvIODTgaYhKKdjNIRQAUZpKM0ALRSUtABRRRQIWlpuaWgY7NKDTKdmkA8E1ItQg+lPUE0hllGqZWJ6de1VlwKlV/SkBrRtvjVvUU6qlnJnch+oq3VohhRRRTEFFFFABRRRQAUUUUAFFFFABSUUGgBpqJ6kJqJzSAiNNNONNNIobRRRSAValWolqVKYEyVJTUHFONMkY1RNUjVC5oAShulNDc04n5aQyhOfmNV2NTzffNVzTASrFuPmqvVm2GWoYzQB4FR3LYjxUi9qr3YywpAT6cvys1Wj1qK0TZAPepD1pIGPFDHAoHSmOeKoQw1BMQIzzjPFTE1Uun7Y6c0gKUnJJB61CTUjnnntUR6/WmAlPQZb2FMFSoMKD60ANY5PFIF3HFL3NSRjvQAoG0VBK+Tip5WwtVTzQgZaBp6moQakU0gJhTqjBp26kMdSZppajNADs09TUYNOFAEuaQmmg0E0ABNIGppNJmgCUNS7qizS5oAlzSg1FmnA0ASZpaYDTs0AOzT1aoqXNAFkNTt1Vg+KPMp3FYsF6gllwKjeaq0km6gdhJH3GoiaCaYTQAGkoooAKUUlOFACgVIopgqRaQyVBU6CoFNTKaBFhKlU1XVqlVqokmFFNU06mAUUUUALSUhNG6gBaKTdSbqAHUUm6k3UAKwDKQRkGs2aMoxVu3Q+orR3VFcJ5sfH3h0pMaMlxULCrLioGFSWQmkpzCm0xDlPNWEkqqKcGosO5dWSnlVcccGqavUqSYqRisuOGFRsu0+1WgwcYNMePHvQBXIppFSbGAzjj2ptMCMjFFPIppHpQA0jNRlSKlopisRA07NBQGm4IpiHUmKTdS5oASkzTqKBCZozRijFABmjmlooAMGnAUmRSbiaBkgIFKGJ6VGKeKQyRfepkNQqakU1Iy1FJskV/Q8/StOsdTkYrStZN8Iz1Xg1SZMkTUtNzRmqIHUU3NGaAHUU3NGaAHUU3NGaAHUlJmjNAC0hNITTS1ACMaiY05mqMmkMaaaaU0hpDEpKWkpAOWpoxUK1ZjFNAyZelIaWmuaokjc1Cxp7moWNJjEB+apD92ol+9UjHCmkMoS/eNQGpZDljURpiEq3aDJqqOtXbMdaTGXFqnLlrnHbNXeik1RhYvd8+tAI1QNqAegpB1oJ4po60gJM8VGxpxPFMNMQ1jgZNZ075Y88mr8rbVOOazJDx179aAIW6n3phpT6UmefpTAByakP3DTUHOae3JGaAERcmpcYFCAAUyVscUhkcjZqPFL1NPVKYgBp6mo6cDQImBpc1GDS5pDHE0ZpuaKBjwakBqEU4GkBLupN1MzRmgBxNNzSZozQA7NOzUeaUGgCQU8VGDTwaQDxS00UtAC5ozSZppNAxS1Rs1DGo2amAM1Rk0hNNJpiFJpKTNFABRSUtAC0optKKAHg08GowacDSGSqalVqrg08NQBZV6kV6qhqeHoEXFepVbNUg9SLJincVi5RUSPkU/NUIRqjJxUhqNqQCbqN1MzRmkMfvNG80zNJmgY/eaTeaZSUrgQ3C/NuHeqrir0gylVHFBRWYVGanYVEwpgMozQaSmIeDTw1RZpQaQFlHxVhJOMdaoBqlR8UrDLhAbletRtGCMgZHrSRy9M1agdWJTru54PekBQKEU3GKvyxKeT+dQNCR0NAyqRTanZCOophQHvTAjpCKeUYe9NPuKYhhUGm7SKkpCKYrEeT3pc07FIVFAhM0UbaMe9ABRijHvRg+tACgUtNwaOaAHjFOBFRg08UhjwRT1aoxT1pFEymrdo+JCOzCqSmpo22kH0NIGaO6jdSZyAfWirMx26jdTaSgB+6jdTKKAH7qTdTc0ZoAdupN1NzSZpAOLUham5pDQAE000pppoGBptLSUgEooooAkQc1ajHFV4hVpelNCYtRuaexwKhY1QiN6iI5qRmpmaljEUfNTpPuGkX71LL/qzQMz36mojUjnmojTEKOtaFqPkrPHWtG1GFpMaJZ22w1Uszm7FWLxtqAdqqWR/0sUAjWJpB1pKB1pAOJppPFBppOPegCvdPhQB3rPc4OPSrVy3zsMe1U2P61QhppO9B60Ac0ASRrxk09RubJpNvAqUDAzSGIx2iq7HcakkbJxTVWgBFWnE4FOIxUTmgBwWl21IFpdtFxEPSlp7LTCKADNKDTaWgB1LmmZpc0AOzSZoFLigYmaM0uKSkAoNPFMFPWgB6inikUU4CkAtFLijFACU008io2oGMY1C5qRzUDHmqQATSUlFMQUUlFAhaKSigYtLSUUgHZpwNMpc0APBpwNRg04GgZIDTg1RA04GkBMGqRWquDTw1Ai0j4qwrZFUVap43p3FYsZpppAaCaYDDSZpWplSMWikooAKKKSgAPIxVZxVmoXHzGkNFVhUTCp3FRMKaGQkU01IRTDVCEoopKBDs04NUdLmgCZXxU8EuJE+tUwacGxSsO5pG4zweaTzFY9hVEOfWl30rDLuRTWVe4qsH96cJDSsMeYx2P50xlPel831o3g0ARlfakKCpuDTcCmBFtpNtS4oIouIh20balxSYouFiLbSbTU2KTFO4WIsUuKkxRtouFhmKNop+2jFAWGgGnClxS4pDHA1IpqEVIppAaFu+6LHdalqjBJscHt3q8aaJaCikopkhRRRQAUlFFABSUUhoGFJRSGgANNpTSUAIaKKSkAUopKcgyaAJ4VqwKjjGBUlUiWMc1C9SOagdqAI3NMyc0MabmkUSp1pJzhKWLmm3BwlAFF6jNPY80ymIfGMmtG3FUIutaNvSYyG+k52+lVbU/6UtPu33SmorU/6Sn1o6AbJpAaDSUhik0xiBknpinGo5jiI8ZoEZ8xy3HTqc1ATxUkhJ5PUmoj1qhCU5ByDSdqljXjNDGSIAaVzgU5RgVG3LVIEe3Jp/QUuKa5wKYDGcCoWbNDcmmGqSJuaYFLimq1PzUDIyKYwqU0xqBkJFNp7Uw0xBmlBplKDTAkFPFMBp4NIYUlLRSABT1FNFPWgCRaeBTVpwNADqSjNGaAENRtTmNROaQyNzUJpzmmVSEJRRSUxC0UlFAC0UlLQAUtJRQMWlpKKQDqXNNFLQA4GnA0wUtAx4NPBqMUoNICZTUqNzVcGpFNAi2rU7NQo1SA0ABptONNwaAEopdpo2mgBKKdsNGw0ANqKUd6n2GmMOMGgZUk9aharLrjIqBhSGQkU0ipCKYRVAMIpKeRTcUyRtFLiigBKXNJRTAdmlzTKKQXJN1Lmo80uaAuSbqXdUWaXNKw7koenbqhzS7qLDuTbqM1Fupd1KwXJKKj3UoagB9FNzS5oGLRSZpc0ALRikzSikAm2lFOoK0ANxmlFHSloAcDV22ffHtPVaoipbeTZKCeh4NAMvUUppKogSiiigApKKKAEoopKACkNFJSASiikoAKSiigBRUka80xasRimBKowKGOBS9qjY5pkjHaq7mpnqu5oY0RuaaDQ3JpAKQyxEeKZcjinxdKiuWoAptTacaTFMRJFy1aMfEZNUoIznNXHbZCakZnTNucmi1/4+VPvTHOSTT7U/v1pvYEbDU2lakFIYVWvHwME89qs1Ru23SkHtxmmhFRuOKYacTk5pvvTEOHJqxGuBioYxzVoUmNCMeMUzpTzUbnigBjvioWkzSvURqkiWwJpppaSmI0AacGqHdTg1QWS5pjGm5ppNACMaYTSk02mISlFFOFACinDNIKXNIY8UtNBpwpDHAU4UgpaQDxS5ptLmgB2aQmm5pCaABjUTmnMaic00BGx5ptKaSqEJRRRQIKKKKACiiigBaKKKAFooooGLS0lLSAWlpKKAHUoptOFIY4GnqajFOBoAnQ1MpqupqZDQImAp4FMU1IKYhQtLtopaYCbaNtOzSZoAaRUTipSahkNJgVZeKrHnpU8rVXNIoaRTSKlBPcA0bVPqDQMhxSEVOY/8imFadwIiKbipStIVoERYoxTyKQimIZRTsUmKBCUUtJTAKWkooAWlzSUUgFzS5ptLQMXNLmm0tAxwNLmmUuaQXH5pc0zNLmgdx+acDUYNKDSGSg04GogaeDSGOIoFKORSEUAFLSUooEX4X8yIHuODT6qW77H5+63Bq2RimiWJSUtJTEFJS0lACUlLSUAFJRSUgCkopKACiikoAcvWrUQqsg5q2gwKaBjj0qJjUjHAqtI1MkHaqznJpzNUTGkUITSA00mlBpAWoh8tQ3J5qeH7tVrn71MCsaQUppBTEW7du1TTuBHg1BbDLU67OQBUlFFjzUlr/r1qJutSW3+uX61T2EjYNJSnpSCoGL0UtjOO1ZkpJ3MTwece9aExZYSR3NZkhqkIjPX8KQUU5R2piJYV71PjApsa4FK7YqRkbtiq7SU+Rs1XNUkJsUtmmmkpKokKSiigC1mlBqPNKDUlEmaQmm5pM0hgaSjNJTAdSim5ozSAkzRmmZpc0DHg81KpqFeanQUmMeKdihRT8UhDMUU7FGKAG0hp+KaaAImqF6maoXpoBhptLSVQgooooEFFFLQAlLRilxQAlLRilxQMSlpcUYpAFFLilxQAlLS4oxQAUtGKXFIYCnCkxSigB6mpUaoRTwaALCtUgeqoY0u80XFYt76XeKp7z60b29adwsXPMFJ5gqnvb1pC7etFwsW2kFV5JKiLH1phpDEY5NMp5FJigBAKlWPNIo5qdBQAzyhTWiHY/nVnbSFaAuUjEfTP0phXFXClJtz1GfrQMpFaaVq40KnplTUTxMvUZHqKLgViKaRU5WmFadxWIsUYp5WkxTFYZijFOxSYoASiloxQISloooGFFFLQAUUUUDFooopALThTRSigY8U4GmCnCkMlU04io1NSDkVIxpoFKaQUxEi1ehJkjBHUcGqAq3Zvtl29mH60ITJ/Lb0pCjDtViirsZ3KhFJirLKDURWlYdyLFJUmKTFAyOkqTFJtpAR0lS7aTFAEdJUmKMUALEMmrajioIhzU/aqQmMkPFVXqeVqqO1DAaxqFjTmPNRmkMQ04U2lU0AXYR8lV7n71WIs7ar3P3qAKrUgpWpB1pgXbUc1DdsTIcdKsWw+Uk1TmbLGkgICealt/8AWj61Camtv9YKb2BGx2oFIPu0q8nFSMr3j4CRj1JNZzHcfoKtXTAzSFQRVZhVEjamiXJqMDNW40wtJjF+6tVpXqaVsCqjnNCExhbNNJoNNqhAaSikpiCiiigCaiikqShc0ZpKKBi0UlLQAUUUUgFpRSUooGSIKsJUCVOlSxkq0tIDRmgQtFJmjNAC0xqdmmMaAI3qBqmY1C1NAMpKWkpiCiilpgAFOxU0KQD/AFpdm9AcCrCrb/wwwj/eDt/SgRR49RS8eo/OtJWQdPs4/wC2DU8SY6PCP+2JoAy+PUUoXPStYSn/AJ7Rf9+zTvNb/ntH/wB8GgDICN/dP5U4RP8A3G/75Navmv8A89ov++TS+Y//AD2h/KgDK8l/7j/98ml8mT/nm/8A3ya1N8n/AD1hpd8n/PSL86BmX5En/PN/++TS+RL/AM83/wC+a098n9+L86N0n96P86QGb5Ev/PJ/yo8iX/nm/wCVae6T+9H+dG6T+9H+dAGb5Ev/ADyf8qUQS/8APJ/yrR3Sf3o/zo3v/ej/ADosFygIJf8Anm35U4Qy/wDPNvyq7vf+/H+dJvb/AJ6R0WC5U8mT/nm35UeTJ/cb8qub2/56R0b2/wCeiUWC5S8qT+435Uhif+435Ve3t/z0Sjef+ei0WC5QMb/3W/KkKN/dP5VoeYf+ei0eYf8AnoPyosFzNKn0P5U3FanmH/noPyNJvP8Az0/8dosFzM/EUAVpFs9WH/fFMPlfxbD9UFFguU1FTLTi9sDjKD6L/wDXo8y2I+Uyf8BUmiwXHCkNIWAPBJ4zyMEfWmlqAA0mKM0ZpDDFGKXNLQBE8CtyPlPtVeSJk+8OPUdKu0tIDNK00rV57dW5X5T+lQPEyfeH49qYysRSYqYrTStO4rEWKMU8ikxQFhmKKdijFMQ2inYpMUhhRRRQAUUUtAAKUUlLQMcKUU0U4UhjwakU1EKkWkMc1Npx6U2kIcKkQkcjqORUYpynBoA10YOgYdxS1Vs5PlMZ7cirG6tE7mbQpqNqUtTSaAEpKXNITQAmKTFLmkzSATFJilzSZoGGKTFLmkzQBJHUpPFRRmnseKYiCU1UY81PK1VWPNIYGo2pxNMY0AGaVetNpV+8KAL8Z+WqtwctVpPuVUn+9QBA1C9aQ0qdaYF+P5YCfas+TBJNX2yLY1nPmkgZHVi1Hz1Xqzaj5qctgRqr90UuQFOfSmr90Uk5xA2ByRgVKBmdI7MCxAyx7CoiCalkJbaPQYpqKS1MCSKPvU7HAoUbRUUr8UAQSvzUJanOcmozVEgaaaM0lMQUlLRQAlLiinAUAONJRRUlBS0lLQMKWkpaQBS0lLQMKcKbThQBItTpUC1MtSxkmaKSikAUUUUwCmtTqa1AETVE1StUTU0IbSUppKYgpV5YD1NJSr99fqKYEwYf3QakWUf3FP4CoB1I96UGkBaE6j/lkv5f/XpwuEH/ACxB/wCBEf1NVM0hagC8LmPvCf8Av4acLmL/AJ5P/wB/Kz91LupgaH2mL+5J/wB90v2mL+7L/wB91nbqXdSA0PtMPpL/AN9Cj7RD6S/mKz91G6gDQ+0w+kv6UfaYfST9Kz91LuoA0PtMXpJ+lH2mH+6/6Vn7qN1AGh9ph/uv+lL9ph/uv+lZ26l3UAaH2mH+6/6UfaYf7kn5is/dS7qAL/2qH+4/50v2qH+4/wCdZ+6gNQBofaov+eb/APfVH2qL/nm//fVUAadmi4WLv2mL/nk//fVH2mL/AJ5N/wB9VSzS5ouFi39pi/54t/31R9oj/wCeA/Fqp5pVyaLhYuiRT0t0/Fv/AK1OBPaGIfj/APWqvEhq2i4FFwI5HdBwkP5GoHklHLSBQf7q80t23ao5BgovoopXCw2QlXblj0+99KZvNOuT/pEn1/oKhzQMk3mlDmos04GkMk3ml3mo80uaAJN5pd5qPNGaAJd5pQ5qLNLmgBWjRuR8p9ulRNEw7ZHqKkzSgkUAVilNKVbIVvvD8RSGLPQ59jRcCoVpMVYKYPoaYVp3AhxSYqUrSFaLhYjxSYp5FJimA2inYpMUCCiiloGFOFNpwpAKKkWoxTxSKHk8UlApO9ADhTh0plOBoESxuUZWHarJkJ71THQip4zlB7UITJgTS0wU6qJCkpaSgApKKKQCUhpaSgAoopcUASR9Kc5+U0xOKVz8tUIqyGq7VPIKgakMaTTCacaYaAEzTk+8KZT4/vCgC8h+SqkvLVbUfJVSXhqAIjToxzTCalhAz1oAsTNiACqDnNXbv5Y1qg1CBjatWvWq1W7UUSCJop0FR3jFI12jnOakToKguXJmVSowBmkgZUYZI9/SpoU4piJlqsYwtMBrnAqnK+TU0z1VbmmhDSaYaU0lMQlJS0UxCUYopwFAABT1FKq1IFpNlJFelpKKQC0tJRQMWiiigBaKSlpDFpy0gpy0ASrUq1GtSCpGOpKM0maAFopM0ZoAWmmlzSGgCNqjapWqNhTQDDSUppKYhKB1H1oopiJP+WjD3NJ0NO/5bH6mlkXBzSGIKRqQHFKTQA2jNBpKYhc0uaSigBc0uabS0ALmjNJRQAuaXNJRSAXNGaKKAFBpc0lFAwzSg0mKUDNAC5pc05Y6eI6QEeTSgE1MIvapFi9qAIFQmp446lWKplUCgLiImKcxwKWoLiTatMRUnbdIB706X/j5x6YH6VHF88wPvUjfNeH/AHqQyGc/6RL/AL5qOnTHM0n++f51HQA7NKKZTgaBjhSimg0uaQDqWm0tADqWm0tAC0tJRQA6gGkooAfkEYIzSGNT9049jSCnA0AQspU4IxTSKtZBGCMionjKcjlf5UAQFaaVqWkIoGRYpMVKRTCKYhmKKdikxQAlLRRQMUU4U2lFADxQaSlpAHalFNBpaAJBwalibBIqDNPU4YGgC2KWmg8UtMgWikooAKSiigBKKKBQAoFKBQBTsUwBaVulAoNMRWkqu3WrEnU1XekMjNMNOJphoASnxfeFR0+L74pgXwcJVKU5Y1bI+SqT/eNJAMNSQffqM1NbgbqGCJr37q1Qarl4TkD2qk3WmgYCrlqKpjrV22HFKQRNBOlU5RmVzjDbqtlxFHuIOegxVTG4rnvSAfGuFpJGAFSHgVTnbmmBFI2SaiJpzHNMNUSIaSiigBKXFGKeq5oAaFp6pUix1IFxSuOw1VxT8Yozims9IZUpaSlpiCiiigYUtFFABSikpwpDFFOWm09aBkq1IKjWpVFSAhpKk20uygCKjFS7KXZQBDiiptlHl0AVyKjYVaZKidKAK5ppqRhimGqENpD0paQ9KYiY/wCuP1NTldy5qBv9aasxcjFSxortHTdpFXGSmFaLjKhFGKslBTfLFO4rEOKMVOIGPRWP4U8Wkx6Rt+VAitilxVkWU/8AzzP5inCxuP8Ann+ooAqYpcVb+wz/ANwf99Cl+wz/AN0fnQBU20baufYZ/wC6v50v2Gb0X86AKe2l21c+wzei/nR9hm/2fzoAp7aUJV0WUv8As/nSizkH9386AKYjqRYqti1cdh+dPEDDtQFyssdSrHUwiI7UoQ+lFguRhBTwtOxS0WENApaKY8gUUAEjhRzWdcS7zgU+aYtUKKXbJ6Uiia1X519zQh3XhP8AtH+dSwD98vtUMHNwT75/nQBWc5dz/tH+dNoY/Mfqf503NMB2aUGmZpQaAHg04GowaUGkMkzS5qPNOzQA/NGaZmlzSAfmlzTM0ZoAfmlzTM0ZoAkzS5qPNGaAJQaeG9ag3U4NQAskWOR0/lUeMVYRu1JLFgZH3f5UAViKQ1IRTSKBkZFJinGkNADcUUUUwCgUlFADs0tNpaQC06m0ooAcKcOlMFOHWgC1E2Up+aggOGIqztpoljaKdtpNtAhtFOxRtoAbSilC0oFMBQKWgClpiCjFFOxxQBVlGDVR6vTCqUgpDITTTTzTWoAZUkI+ao6lg+9QBbYkJVJ/vGrrkbKpN1oQEZqxbD5qr1YtvvUMEF22Xx6VUarNz/rDVU9aaExVq/bfdqgtX7YfKKUhouSELb9Rk8VCg/i70645kAIGB0PtR91aQDJX2iqUhzUkz5NVyc1QhDTaU0mKYhMUoFOC1KkdK47EapmplTFPVMU/pSGMxikJxSO+KiaSiwXB3qMtSM2aYTVWJuLRRRSGLS0lFAxaKKKAFpRSU4Uhi09BTKlQUhkiCp1Wo0FWEFIAVaeEp6rTwKBEWyjZU22l20AQ7KNlTYpcUBcrMlQulXStRulAXM2VMVAa0JY6pSIQaaGRGmnpTjTT0qiWSt/rKsRHpVZuSMZ6DpTlJBzxn1IpWC5oqq4y8iL9TzQWth/HuqvHPsPzRp9cYqwtzxwqj6UWC4olhX7sef8AgOaeLhv4YW/75xSC4b2pwnb1oEL5056Qn8aXzLk9Ih+dJ5zetL5retMBd10f4EH40v8ApXon50nmt60okb1oAXFz6pRtuP7yUeY3rSh29aADbcf3lo2z/wB5aXe3rS7j60BcTbN/fX8qNs399fyp24+tG4+tAhuyX++Pyo2S/wB8flT9x9aNxoAbtl/vijE3qtPyaXNAEf730X86N0v90fnUmaM0wI97946PMPeM1JRQBCXXujD8KicQN1LL+NW6TA9KVguZ7W0bcpP+DCnCBlHChvdTmrjRo3VFP4U3yEByoKn2NFh3KkXE3PYGq9rzJWhLH8pZjllBIb+hrMgcRnnr6ClYpMq0VKI+1L5VFwIaKm8qnCKi4EApwqYRUoipXAhpam8ql8qi4yClqfyqPKoAgpam8ml8qgRBmlzU3lUvlUAQUtTeVSiKgCEA05VNTiKnrFSAjRTVlVDKVPQ0ipUirTEUZEKsQeoqMirt1HwHHbrVQikUiIimkVIRTCKBjDSU4000wEoopKBC0tNpc0AOpaaDS0DHU8dKYKcKQEiNhga0FAZQazRWhaNuTB7UIlj9tG2pMUYqiSLbSbalxRigCPbSYqTFJimA2kpaKAAU7HFNFSAcUCK844qhJ1rRnHFZ8nWkUiE0wmnmmGgBpqWAZaoqmgPNNgizIPkqk3WrkrHZVJuaSAbVu1HtVTvV22OEoYIr3LZc1WPWp5jljUB600JirWjZgnAIGKz161p2QBYbc9OaTGiSQ7pyDj5eKZK2FpUxy2c571BcP81AFeQ5NRGnMcmkxmmIbT1XNOSPNTqgFDYWGJHUoUCl6UjNikMGOKiaSmu+agZjTSFcc5qImgtSE0xCZopKKYh9FFFIoWiiikMWiiigBacKaKcKQxwqVBUQqeMUhk6CrCCoYxVhKQiRRTgKQU4UxBS0UUCFooozTAKawp2aaTSGV5FqpKtXZOlVJaRRSdcVEasSVXaqRLHMRhfm28elSKG7fN9Khf7q/wC7T/731piJgcdQRT1ZR3x+FV97qq4Zh171NvOwEqhye60DJlkX+8PyqUOvqp/HFV/k7p+TGpFjjP8AfH5GgCcFf/1MKcAvqfypkdpvXKyfmtO+xuBnevH1oEPAX++v4ginBfRkP/AqjFtLjIZSP96gQzEcYPOOtAEwjb0/Wl2N/dNQeRN/dH5ijypx/CfwNAFjaf7ppcH0P5VXxMOz/maN0w/56UBYs4PofyowfQ1V3zDvJR5s3q/5UBYt4PoaX8DVPzZvV/yo82f/AKaflQFi5S1R8y4PaT8qN9x6SfiaAsXqWs4vP3JH1cf400tJ3dfxcUBY06QsB1NZTMe8yD/gR/wphMfeZfwBP9KAsarTRr1YfmKie9hX+IfnWbmEfxMfon+JppliHRGP1IH8hTAvtqKn7gB/M/0qF76Vuh2/kP8AGqpuPRFH1yf5mkE7/wB7H0GP5UgFmMkjZfJ92Of501B86jOTnFRliTyc1NbDM0Y/2hSGWRHThHU6pTglKw7lcR04R1OEpQtFhXIBHS+XVjbRtosFyDy6Xy6n20u2iwXK/l0vl1PtpdtFguV/Lo8urG2jbTsFyv5dL5dT7aNtFguQeXSiOp9tG2iwrkQSnbKkxRiiwXGBacBTsUUxDWUMpU96zXUqxU9RWpVW7i/5aD8aTRSZRIphFSkUwipKIiKaakIphoGMNJTjTaYgooooAUUtNpaAHCnCmCnA0DJRVm1fbJjsaqKakU4IIpCNfrRimQvvjBqSrIExSYp1JQIaaaaeaaaAGUlOwaApoAFFP7UBcUHpQBDN0qhIOavy8iqEnWkxortTCae9RmmMSpoOtQVPbjJpMETyn5KpsauSj5KpsKEA3vVyD/V1S71dh/1RPtQwRUk+8aiqV+pqKqQmOTrWpZ8W7nFZqDmtOEYteCTubFSxg3ypVOU5q3McLVTG40ARBc1IkVSpHUoWgBipindKVjioHloAV3wOKrvIaVpM1CzU0hNil6YTSE0lUSBpKKSgBaSiigB9LSUopFC0UlFIBaWkooGOFOFMFOFIY8dasR1XXrVmOkxliOrC1BHUwNIRKKXNR5o3UxEmaM1HupC9AEu6kLVEXphkoCxMXphkqBpaiaSgZO8uaryNUbSGoyxNFgEkNQmpDTCKpCYN9xPpTh/F+FIR+7T8aeB978KBDT9xfqam/wCWa/WoiPkH1NTD/VD60DHd6nQVERyKmQUAy7bf6v8AE1Kw+RvpUdv/AKv8TUp+6fpTJGp/qx9KI+jf7x/nSp9wfSiPof8AeP8AOgB1JilooAqXI+ZaZt+v51LcD5loK8VIyE59T+dJ8395vzqQimkUhkTFgPvN+ZqNmbH3m/M1LIOKjkGEWgZEx9z+dCAbPXmmsacn3fxoAJMBelR55H0p833ahJ5H0piFc8/hTc0OefwpmaYh2aaTSZppNMB2aevT/PvUWakX7v4f40mCEHWrVkM3Ef1z+lVR1q7YDNyvsD/KkM0VHFPAoApwpiExSgUtLQAmKXFLRQITFLiiigAxRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABQRkYNFJmgChPF5bcfdPSoCK05FEiEGs91wSD1FSy0yBhTCKlYUwikMjNNNPIphpgJSUtJQAUtJRTAcKcKYDTgaQEgNSA1CDT1NIC9ZyYYqe9XqyEbawI7VqROHQGmiWh9FFFUSJRilopgJijFLRQAlNY04mo2oAjfpVCXg1eaqUw5qWNFZqYakaomNMY2p7frUFWLfrSYIlmJxVNquTfdqm3WmgEq5H/AKgj2qmOtXI+IaTBFN+pqOpHOSaZ3qkJksXXkVqZJjjBFULYZccA/WtFhhgP7oqeoyGcZAFMWPFTMMmkPFADQMU1mAod8VWlf3oAWSSoHNNZs0wtTSJuBNNzQaSqEFJRRQAlFFFABRRRQA6lpKWkMWikpaBi0UUUgFFOFNFOFIY9OtWUqulToaTKLKGpA1QKadupCJd1IXqItSFqAJS9NMlRFqQmgY8vTCxpKVEaRtqj/wCtQA0mkCljhQSfar0dpGv3yXP6VYRQhIUYApiuZgtJ26RH8cUx7eVPvRsB64rapadhXOf20hWtqa0jlycbW9RWfLbtE2GH0PrQPcq7cxL9TS7cFvoKsJHmMfWmuuCfpSuFiAj5P+BVKP8AU/jTSPkP+9T1H7k/WmIeRyKmSomHSpo6aBly3/1f4mpT0P0qO3/1f4mpT0NMkav3R9KI+h/3j/OhfuihOh+p/nQA6iiigCCf7y0pHFE331p5HFIZERTCKlIphFIZXl6VHL9xKllqGY8L9KQyu/WnJ90fWmNUkf3V+tACT/d/GoD1H0qe4+7+NQfxfhTENfr+FNpz9fwplMQU2nU2mIKkX7v4VHUo+7+ApMaEHWr+nD9+T6IaorWhpo+eQ/7P9aQzRFOFNFOFMkWiiloAKKKKACiiigAooopgFFFFABRRRSAKKKKYBRRRQAUUUUgCkNLRQAyq9zH/ABD8atU1l3KRSY0ZbCmMKnkXaxFRMKkshNMNSkVGaAGGkpxpppgJRRRTAWlFNpaAHg08GowacDSAlU1ds5cHaazwakRypBHakBs5pC2Kihl3oDSStVmdh5k5oD1V30okouOxa3Uu6q4enb6BWJSaaaZvpC/vQArVTnHNWS1QT8ikxlN6hNTvUDU0NiVYthk1XqxbA0MESzcCqbVbn6VUNCAQVbU/uaqDrVsf6qkwRUahFyaftyamSOi4WJbVRnFWz94mooVAOaczcmgGBOKhkkxSSSVVeTNAgkkqFmzQxphNUICaaaDSUxBSUUUAFJS0lABRRRQAUUUUAOooooGLS0lLikMKWgClC0gAU4ClC04LSKQ5RUq0xRTxSGSA0uaaKKQDs0maKKAEopcUuKAG4qxGdi4/OosUbsUAWEkO4DNWFbJz61QRuSanWSi4NFsMKdmq6vUoaquQSU1gHGGAIpM0c0ARfZkC4BI5z61WltZMkqAwxjg81cY4phkAHQ4+tAzNZSoIYEHPQ0qj9yavs6ONrqGHpURtl2kRtjPZ+340AQsOBUqUx1ZMB1Ip6U0JlyD/AFf4mpT0NRQfc/E1IehpiEX7ooTofqf50L90UJ0P1P8AOgB1FFFAEU330+tPxxTJfvp9ak7UgGEUwipCKY3SgZVlqvP/AA/SrUgqpcfeH0qRkBqaLoKgNWIvu0xjLj7v41B/F+FT3H3B9ag/ioENf734Uynv978KZTQgNNpxptMQCpegP0FRDpUp7/hSY0C1paaP9YfoKzlrT00fu5D7igC6KcKaKcKBC0tJRQAtFFFABRRRQAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKQBSUtFAFS6T+IVUYVpyruQis9hg4qWUmQMKjIqZhUbCkURGmmnkU00wGUUppKYgooooAcKUGmU4GgY8GnA1GKcDSAtW8pVsVZkbIzWcpwatI+5aBNDWamh6VxULcUCLAkpwkqpuxTg9MC0XppeoN9LupATq9JJytRq3NPY5BoAqvULVM9RNVIBtWrY1Vq3ajikwQtweKqGrdx0qqaaARRk1cVcx4qtGuSKvKvyUmBCkfNTqmKULilJwKAELbahkkpJHqs70CCR/eoS1KxphNUJgTTTRmkpiCkpaSgApKWigBKKKKACiiigAooooAk20u2pAtKFqbl2IwtOC1IFpwWlcdiMLTgtSBaULSuMYFpwWngUuKAGgU4ClApcUgExS4pwFLigBuKXFOAp2KAGAUuKfilAoEMC02SPPIOD71MBSSRll46igaIBxx6U9WqLocHqKcDSGWFapVb3qsrVIGpktFgHmlLBRyag80Af0qJpsgk07hYkmk4681X833qGSQk9ajL80ii0JKmSTHTNUA9SK+O9MRorKfXr2pfLibkDafaqSykVMk31/KncTRdjXauM55p56VWWUetSrID3p3JsPXpQnQ/U/wA6QEYpyjAP1NMQtFFFAEUv30+tS1DL/rE+tTUANNMbpUhpjdKQFaQVSuPv/hV9xVG4/wBYakogNTxfcqEip4v9X+NMCO4+6PrUH8Zqe56LUJ++aAGP96mU9/vGm0xCGm040lMQDpUp6N9aiFSt0P8AvUmNAta2ncQOf9r+lZS9K19PH+jN7tSGTqwb6+lPqJkZTuA6VIpyM00JjqKSloELRRRQAUUUUAFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKpXCbXz2NXahuU3Jn0pMaM9hUTCp2qJhUFkRFMNSEUwimBGaSnGkNMBKKKSgQtKKbS0AOpQaaKWgY8GpYmwcVADTlODSAttyKhcU5X4pDQIhIpvSpiKjIpiEDU4PTCKSgCZW5qcHIqkGq0jcUgIpOtQsKnl61CapAM71btwcVV71btjgUmAkwqvjmrM5qELk0AOhX5qvAcCoIUxU54FAMCcCq8r0sj1WkegQ13zUTGhjmmE1QgJpuaDSUxBSUtJQAUUUUAFJS0lABRRRQAUUUUAFFFFAF4LSgU7FOArM1GgUoFOC04CkA0ClxTgKXFADQKUCnhaUCgBuKUCnBaULQIbilxT8UYoAQClAp2KUCgBoFKBTgKXFMQgFLilApcUARSwLLz0b1FVZIpIuWXK/wB4VoYpaLDuZqtnpT92Ksy2iOC0YCP+hqnkjIPBHBFIe45iKru2OlOdjULmgYham5pDSVQh4NOBqPNOBoETBqer1XzTg1Kwy0slTJL+P4VRDU8PQBpLLk9alWUY54+tZqvxUqSkU7isaIbNOyKorLz71IstO5NiZ0LOpGMCpKhEv0pwcUBYeaaaUN9KODQIgccVRnH7w1pMmehqnPCwckqceuKTKRTxzU0X+r/GkMZpyDCAUhkNz/DUP8TVNcckVFjk0xEb/eNNp7/eNMpiENJSmkpiFXtUp6fiajXqPrUn8I/GkxoVe1bFhxbf8CNZCVsWXFsv1NIZY5pjMVPI49RUgoIpiGggjIpaZjY2R909fan0CFopKWgAooooAKKKKACiiigAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUjDIxS0UgM6RdrkVCwq5dLhg1VGFQy0RMKjNSmo2FAyM0008immmA2kpTSUxBRRRQAtLTaWgB2aWm0tAEitTt1RA81IFLCkAbqOKaysKTcRTEONNIpN1OBoAYRU8Z4qImpIqACQVAasydKrtQgYgq3bjK1THWr0C/LQwGyjmiNKkZcmnquBQAqjApkj4pztgVVkkzQIZI9V2bJpXaozVCFJphpc0hpiEoopKACiiigAooooAKKKKAEopaKAEopaKAEooooA1QKUCnAUuKyNRMUoFLilxQAgFLilxS4oEIBTgKMUooAAKdikpaADFKBRSigAxS4opaYgxSgUCnCgAxRilpHbauaYBmmtwcioPM5qUHgVO47WFDkVDcxrMNyYEg/8AHqlIyKifIoGigxz16jtULdavyosvJ4b+8KqvBIvONw9VoTGQGkp2KTFUISlzSUUxC5pc02igB4NODVFSg0gJ1apFbPWqwNPVqALitxgfjT1J7AVWR/8A9VTo2eB+PFICZSRxTwT7mmqBjqKkAHbvQAoJ9qcGIHX9KaCAKRplHYU7iJN5ApPOqu1yPQVE0+aLjsWnWJ+nyt7VBJGU5OCPUdKh870P609bj3/GkFiN0zUZTmrOFfG04J7djTGBBwRg0gKxTNMMftVoikK07gVClN8v3q2VFNKe1O4WIUjORzTxCSBginhcGnKCKVwsKluRglhWlbjbEo9KoqKvRfdApoTJxS00U6mICMimjjinUGgQlFFFABS0lFAC0UlFAC0UUUAFFFFABRRRTAKKKKACiiikAUUUUAFFFFABRRRQBFcLuSqDVpsMrWfKu1zUspFdqYakamGkURGmmnmmmmAw02nGkNMQlFFJQAtFJRQA6lptLQA6rVuQRVQVJG+1qQF5owRVaWHHSp0lBFDfNTEUGUg0mcVaeMVWdMGmAmakiPNQZxT0bmgRZfkVWNT5JWoSKSGxB1q9B92qS9avwD5RQwJMUhOBTyQBVaZ8UCGSyVUd+acz5qJqaAQmm5pc000xAaSiimIKKKXFACUYpQKdigBmKXFPxRigBmKMU/FJigBuKTFOpKAEpKdSUAJRRRQBtYpQKXFLisjQbilxS0UAJilFFLQAUZopKAFzRmkooAeDS5popaYDs0oNNpRQIeKcKYKUUwH1BcnAFS0yVN6Ed6TBblPdk1OGquAVJz1p6mpRbLKtQwBqMGpFPFUSQuh7CoSStW3bjHb1qjM4JOKVikxWkRxiRA3v3H40w2yOMwyf8Bf/ABqJjxSBiOlADWUqxVhgim1MWDkbxnFMkVRyoIH507g0R0U4jv1HqKSmSJRRRTAWlBptLQBKrVOj4xVUGpFNIZdSTg5qXf17Y4qmrcU4vxSCxNJNxgVWeTJpjvmoi1ICQtTS9M3UmadgH76A9R0Zp2C5ZSU/hVhJ8rhvmHpWeGqRHx3pWEXjHkZj+Yeneo6bHJyOufap8pIPmBz/AHhQBDRT3jKjPVfUUykAA0opKUUwHrVqAk1UFXYRhF9TQgZNS7hUTuAetNElUSTbqaX5xmmA5B/pSdc9z34oAd5mO5zR5394Y9MjrTMY7ZppBJO6kMsqwbp19KWqeGQ5FWYpBIme/emJokopKWgQtFJS0AFFFFABRRRQAUUUUwCiiikAlLSUUALRRRQAUUUlAC1TuVwc1cqGdcqaTGjOamGpGFRmpLIzTDUhphoAYaaaeaaaYDaSlNJTEFFFFMQUtJRSAcKUGm0uaBkyNipVkqtmkDmgGWy+RUbDNMV6duoEQutRg4NWGGahcU0IsI2RUb/epITT3FIYRrk1ejGFqvClWOgoASV8CqUr5qaZqpseaaENY03NKTTTTEBptLRTEJRilApwWgBMU4LTgtPC4pXGM20u2ngUUhjMUYpxpDTENNNNOJppoASkpabQAUlFJTEFFFFAG7RTc0ZrI0HUtNBpRQAtFFFACUUuKUCgBAKdilApwFMQ0ClApwFKBQA0LTsUuKXFACYoxS4pcUxDaXFLijFAFO6Xa27sahU1ougddrDIqrLalPmQ7h6HrU2LTGg07eAMdKjU8Z9Kjkc8igLCSykk4PFV2ahmxxUZOTTGPHPNGKaKfn9KYhtAJFOwKQjNIY5HToy/iOKlFvHN/qyA31/pVbFAJHSmIfLbSQ/eGR6iosVbjvZFAD/OvoaVltp+UbyHPY/dNAinRT5YnhIDgc9CDkGmUwFFOBplKDSAmDUpbiogaUmkMRjTCacaYaYAaTNFJTEOBpetMpQcUCF6UoNKMGkIxQBIrc1Oj+9VBT1akM0I5SOmKf5cUnT923qOn5VSST3qdZD1zQA9reVegDj1U0w5U4ZWH1FTLKR1FWFnz34+tKwFeGMuckHaOvFWGfy87vvdlHapcbxkOaaIUXOB9adhXKuWJyRzSrn1BH51YaMfSoWQ9cn1oAUMMcning7uOfoKh5XrT1b/ADigCQgnvjFJjkntQDk4pw57dOMUxDSBjjr3pqN5cuf4Twakxzk5oKBgQx4pAS0tNXgYJyRS0xC0tJRQAtFFFABRRRQAUUUUAFFFFACUUUUAFLRRQAUUUUAFMfpT6jkOBQBQlGGNQmrEvNVzUGiGGmGpDTDQMYaaaeaYaYhpptONIaYhKSlpKYgpaSigBaWkpaQC0wnmnUxqaBj1ang1AKkFAiXNNYZpoNLmgYiHBqwBkVABzVqIZpMESxDAp0hwtA+UVFK/FAFeV8moGNOc5NRk1RLGmkpaKYhKUClAqQLSGNC08LTgtPApXHYaFp22lpc0hjcYpCKCaaTQIDTCaCaaaoQE03NBpKAAmkJoNJTEJRRRQAUlFFAG3SU/FGKyNBBTqMUYoAUUuKQU4UAAFOApBThTEKBS4oFLQAmKdRRQIKWkpaYBS0UtABQeBRUc7EJxQwQ4NkYqL5lfBOc9KiSXHWpgd4BpFWsVp1COfRqpu1acyb0xWZKpDGkUQse9MpzCm1QhwpwNMFOBoEPopuaM0AOpCKTNOB6UDG4o20/HrSgf/XpARFM03YasY/OjbTAr4PpSgGp9tIVouIiop5X2ppXFADTTTTiKaaYDTRQaSmIWkoooEOBxUgIYVDTgaQyQikpVbPWlIpDEBxUitzmoqUGgC4kn05qdGGOcZ9jVBXI71MkvrigRoRyYqZZA3FUlcHuc/WplbuD1oAs01lzTEepM5piIWT0FRFcHoM+9WjTWXPsKAIVOOhyfUVICe9MZenY/WlGceoNADwefSlOD2/Wmg9sfgKXIxn+RoAUkDvt96ejhh7jrTAcn1pQT1HbtQBJS00HIzS0CFpaSigBaKSloAKKKKACiiigAooooAKKKKACiiigBDVeZsCp2PFU7huKBoiLZqJhSK/NOPIqGWiM0004000DGGmmnmmmmAw0008000xDaSlNJQIKKKSmIWlptLQAuaa1LSNQhMaDTgTTKcKYhwJpwNNBpRQMkXk1chHFVolyauINoqRiyHC1RlfnFWJnqm/JzTQhpOaYaWimIbTgKAKkVc0XARVqUChVp4FSUIBTgKXFJQAYpDQaYTQAE1GTSmmGmSGaaTSmmmmAhNNpTSUxBSUUUAFJRRQAUUUUAb1FLRWRoFFLRQAUoopRTEKKcKQU4UALRRS0CCikooAWlpBTqYAKWkpaACo5xmPjtUlJQxozC3NWVfAAps9qc7k6dcU0HmpKLJ5FVLiMNyOtWUPFNcA0MEZbrg0wirs0Yqsy4ppjIsUUtGKYhKKKSgQuaXNNpRQBIDTx61EpqZCO/IoAUClHX2HYVIFB54pQnPY/56UhkeP8A9dGKl2d+PejZ9BQBFtppT2qYgjrzTG4//VQBAy+1RMKmYiomNNCIjSU402qJCiiigApaSigBwNSK1RUoNIZMRmm0K1O60hjacGppFFAE6SkdKsxzZHUflVDNPVyKBGoGBA6A+tSK3vx2NZ8dxjj+dWY5gT1BPpQBaDZFL1HrUQY+tPDeppiEYUzGKlznvTG9PT0FADRkU4MR9cU3HJPencA8nn0pAKOg9KePSm5A5H50FsCmA/p0pw5qAyY49aaJcHjHv70AWaWmqwZciloELRSUUALRmkooAdRTaM0AOopM0ZoAWikzRmgBaKSigBr9Kz7k1ffpWfcmkNFQNhqmU5FVmPNSxtSZSHmmmnmmGkUNNMNPNNNADDTTTzTTTENNNpxpDTEJSUtJTEFFFFAgpDS000wYlKKSlFMQ4CngUwVLGMmpYyxAKnc4WmxrgUkp4pDK0r5NRE0r9aZTEIaUClAp6rTuIRVqULSqtSBRU3KGgUuKdiikA3FBoNNNMBGNRsac1RmmhCE00mlNNNMQhNNJpTSGmISkpaSgApKWkoAKKKKACiiigDfopM0VkaC0tNpc0AOFOFMFPFMQ4Uopop1AC0UmaKAFoopaYhRRRRQAtFJRQAtFFFABjII9az+jEHqK0aq3ceD5ij60mUhgbinZzUSnNPVgDk0AI65HP61UlX0qw8gPXoKqSSbjSKREwxSZp5ORTSKYChd33cH270hGDg8H0NJ0qRZTjDgOvo1AWI8UlTiKOT/VybG/uv0/OmSRvEQJEK56HsfoaYhgNSI2KjxQKBFyJ9verCbTVGN+anVsUhlrZwG7etRtkcHIpgmKcg81HJLkdc0gsK7+9QM59aaz1GTTAczVGTQabVCYGkoopkhRRRQAUUUUAFLSUUAOBp6tio6UGkO5N1pCKarVJ1pDGUZpxFNxQIUNUqSFehqGjNMDRinyeTVhXzgnk/WshWINWorjB5+lIDQz06fSkJ7de3Wo0cMOuafnPSgQE+/0FN3fpQRx6Co2YevQUDH+Zz6fU1G03sPoageTk9qhLUAT+bnvSiXtVXcfWlDUhl+GYo2c5HcVeBBAIOQelYytz1q9azYOxjwensaaE0W6KKKZIUtFFACUZoooAKM0lFAC5ooFLQAUtJRQA1+lZ9zV+Q8VnXJpDRSeljamv1poODTGXAcikNMjanmoLGmmmnGmmgBppppxpppiGmmmnGkNMQ2kpaSmIKSiigQUhopDTEFKKSlFMBy9atwJnmqqir0AwtSxokJ2iq0r5NTyHAqm/WkgGnmgLTgM1KqU7gMVKlVKeFp4WkMYFp22n4opAM20YpSaYTQAhwKYTSmmGmAhNMJoNNNMQ0mmmnGm0yRKaaWkpgFJS4pKACkpaKAEopaSgAooooA3M0ZptKKzNB1AopQKAHCnimCnigQtLRSUALS0lKKAFpabRmmIdRSZooAWlpKWgApaSloAKazDp2prvioC+TQMjdfLkwOh6VGzYqaVSY93pVSQ1JSI3kJ4zUWaD1pKoB3pTwOOelR04GgBSuRSFeadmj/PNAEfSpY7l4xt6qeqkZB/Cmn/ACaaVoC5Ntgm/wBWfJf0PKn/AAqN43jbbIpU9vQ/Q0wrQXfbs3Nt9M8UAKDg1OrZFVwc09WwaAJGNRs1PPIzUTUhjSaTNBpKYhaQiiimIbRTqTFBIlFGKKYBRRRQAUUUUAFLSUUAOBp6tUdKDSHcsAgikK1GrYqVWpDGEUlSEU0igBtKDikNFAE8cpU1cjl3d6zAakR9tAGp2/DBqGRcZxmmRzlhjNWFKt0zQIospqFq0Xhz0qrLEQTkHNIZWpRQRQKYEimpUbBqAVItIZpwThwFbr0z61PWWnH+FXYJs4Vz9Cf600yGixS0lLTEJRS0UANpKdSUAApaKKACiikoAZJ0rOuBzV+U8VnXDc0ikVGqM1I1RmmImiaps8VUQ4NWVORUstCmmmnGmmkMQ0004000wGmmmnGkNMQ2mmnGkNMkbRS0lAhKQ0tJTEApwpAKcBQBJGMmrqDC1XgXmrJGBUlEcrcVBjJp78mlRaABEqZUpyJUoUCgBgWnYFKRRigBhpKe1MJoAa1Mp5yaaVoAjbioiamK00pQIhJppzUxSk207gQYNJtNWNtJtouFiDbSbanK0hWncViHbSbamxTSKAI8UmKkxSEUxDMUmKfSUANxSYp1FAGwBTgKUClrM0ExTgKAKcKBABTqSlzQAUUmaWgBRS02jNAC5opM0tACilpKWmIWiiigBajeTFNkkxUBbJoGKzZNORc0iJmpwMUgDaCCp6HisuZSrFT/AAnFawqreIrtlfvgYPvQxxMwim1K6lTg8GmYpjGilFGKKBC5ozSUlADt1KDTKXNAD80hFIDTqAGYwaWnYpKAANj6Up56U2k6UDENJS59aQ0CEoxRS0wEopaTFAgpMUtFADcUU6kIoEJRRiimAUUUUAFLSUUAOBpwNMpQaQ7k6vT+DVcGpFekUKy00ipgQRTWWkIhozTiKbTAeGI6VPHMR9aq04GgDTjn6f1qRgJF5H6Vmo9WIn/KkAy4tynzDoagxWmsgYYPI96ry22MsnK/yoAqgVIopQlSKhoGKgqTGPpQq4pSDmkIs28u4bG6jofWp6z+Qcg4I6GrsUgkTPQ9x6VSZLQ+iiimIKSlooASiiloASg0tIaAIJulZk3U1pzDisybqaRRWamGntTDTEIODU8bVXqSNqGNMsmmmgHIoqCxDTTTqQ0wGmmmnGkNMQ0000802gQ2kpxFJimSNopaMUxAKeopAKkRcmhjRYgXAqV/u0RrgUrKTUjIVXJqdI6ckdTKuKAGhcUuKdijFMQykxT8UhFADMUm2pKSkBHtpCtSU0mgCMimkU8kU0mgZGRTSKcTTSwoAQ0hpCwppegQpppNIXphamK44mkJpm6kzTEOJpCabupM0wHZpM03NJmgB2aKbmigDepaKKzNBaWkooELRmkooAWlpKWgAooooAKXNJRQA7NKKbS9KAHVFJLjpTZZcVXLFjQA4tk0+Nc9abGmanAxQMcBinCminCmSLVW5GHz61ZpkqeYmO/akykU8qww4BHvQ1mrLmNsH0PIphBVsEYNTq2DSKZTkheP7y4HqOlR4rVDZFQyQI2SBtPtTuIz8UhFWHhZO2R6ioiKdwsR0U4rTcUxBTgabS0gH0lCmpAAaAI6QiptnSmslIZAaSpGXFRmqJEozSUUCHZpc0ylzQA7rRimg07NAxKKdSYoASkxS0UANop2KTFAhKKWkpgFLSUUAOBpQabQDSHcmVsVKGBqsDT1alYdycrUZWpEfPWnlQeRSGVSKKnKU0pTuIatSqfSmBcVIopATRtzzVqN+KrRrVlFoBivAr8rwajMRU4PSrK0/APWmK5VC0u2rJQUmwClYLlbZSoTG24cjoRUxWmkCgCYEEZHQ0tQI2w+q/yqYHIzVEi0UUUAFFFFABRSUZoAjkGRWfcJjNabciqs6ZBpFIyWFRkVYkTBNQtTQMjNAODSmm0ySwjU+oENTA5FQzRMKSlxShaBjMUEVKIye1PENAitik21b8n2pPJNAioVpNtWzD7Unk+1O4irspRGatCH2qRYqLhYqLHU0cfNTiKnqmDQAqrxTttOFLnFAgC06mbgKQyUwH5pM1EZKaZaAJiRTSwqu0tMMtAFkvSb6qmWmGWgCy0o9ajMlVy5NJvoAnMlMaWoS1MLUWFclL00vUeaQtTsFx5amlqaTSZpiFJpM0maM0AGaM0lFABRSUUALSUUUAFFFFAG/S0lLWZYtFJS0AFFFFAC0UUUAFGaSigBaWkpegyaAF6VDLLikll9KqlixoAcWLGpY480kUXc1YAxQMUAAUtJSZoEPFOqMGlzTAfRTc0uaBDZYlkHI59apg4q8DVOdNkp9DyKllpiq2DUuciq6mnhqABqgdQTkgZ9RUzsCeuKgkbB9KBkZUZ4P501lI6g0buacrn1pgRkUmKsDy3+8MH1HFBtyRmNg3t0NFxWIBUimmEYOCCCOxpQaYEwagkelMzTSeKQCPUJp7GmGmhMbRRRVEhRRRQAUtJRQA4GlzTKWkA+kpAaXNAwopaTFACYpMU6igBtFOxSYoEJSU7FJimAZpwNMpaQEqtip435qqDUimk0Ui6MOPekMdQo+KsK4brUjGBKkSOpAFPenZAoEKqgVIKiDU8GmBKDTwaiBp4NMkkFLTQadmmIRhUD5FWKY65FIZULkU+KfacN90/pTZUINQ0ijSFLVOCfZ8rfc9fSrdUSLSUZozQIKSlpDQAVFIOKkJph5pDM65TvVNhWpMuRVCVMGhDK5FJin4pyxk07isRjg1MnNSLb5qZIQKTGtCNUqVIsmpVQVMqilYLjFiFP2DFPGBRmqsIZsFIUFPzSFhQBGUpCopxamF6QBijiml6Y0lAEuaNwqsZaaZCTQBaMgHemGWq5emNJQBYaamebmqxYmjdTAnMnvUbSVEXpM0WC5JuzSFqYTTS1Arji1JnNNzRmmA7NIWppNNJoAcWpM0lITTEOJpuaKSgBaKSigAoopKACiiigAooooAKKKKACiiigDoKKSlrMsKWkozQAtFNpRQAtGaKSgBaUU2lyAOaAHdBUEslPLbjR5O7rQBTOWNTxQ9zU624FSeXimFxgGBRT9lLsosAzFIRUuyjZQBFiipdlJsoAZRT9ho2UANzTZYxKmOhHQ0/YaUKaAuZ2CrFWGCOop2auywLKOeGHQ1UeNozhh+PrUlXuQs2BioHbmpZODUDdaYxOtKKSlpiFyRTlkIPWmUlFguWDIsgw4z6EdRUbpt5ByvrUVLuNKwDw1BplOzTAYaaaeaaaYhtJTqSgQlFLRTEJRRRQAUUUUALRSUUAOBpabRmkA6ikzS5oGFLSUUALijFFKDQA0rTcVL1oK0XCxGKeDSbaUCgB6mpVaoRTwakosK9SBqrqakU0gJ1NSA1ApqQGgRMDTwahBp4NMRMDTgaiBpwNMRJmlpgNOzTAa6hhVWSIg5FXKRlyKTQJmd0qxbS4PlN0/hP9KJIe4qBlIpbD3NCkqOCXzFwfvDr71JVCDNITQaYaAFY1GWpxNRtSGNc5qrIhY8VOQaQsBSArrAc1KqKtBmAqCWYnpTsFyyZFFRNPzxVQufWlVsmnYReicmrKniqcFWQeKQEhaml6jLVGXxTAmMlRtLULPUZfNICYyZppeo801noGPaSoy9MJzTaYiQGgtUZaml6LAPZ6Zupuc0ZpiH5ppNNLUmaAFzS5ptBNAhSaTNNpaYC5pCaTNFABRRSUALSUUUAFFFJQAtJRRQAUUUUAFFFFABRRRQAUUUUAFFFFAG9mjNNzRWZoOzRmm0ooAWlzTc0UAOzRmm0ucDJoAdnAzUEkuTgU2WbtTIlLtmgRZhGatrUUaYFSgVQh3FLxTcUtAheKKSlxQAUtJS0AFGKMUUAGKMUUUAGKMUUUAJimuiyIVb/9VPpKAMm4iZGKnqKqkc1r3ighc1nSRkc9qk03IMUuKXFGKYDTSU40lAhKMUtFABRSnpSUAJmmmlNNpgFJRRQIKKKWgQlFLikoASilopgJRRRQAUUUUALRmkooAdmlzTKWkA6im5pc0DHA08Go6XNIZJxRimg08GgYmKUUopRSAUVItMApwpASKaeDUYpwoAlU1IDUINSA0CJQaeDUQNPBpiJAacDTAacKYh9LTRS0wEIqGSPNWKaRSsBRIaNgy8EVajkEi5HXuKR0zUBUxtuWgZZJpmaRXEi5HB7iigQhNMLACkkfAqlLKe1AE7yiqskhPeojIaaWp2AUuaQtTCaSmIdmnpUYqROtDAtw9KsZ4qCLgVMelSUMJqJ2pznFRmgBpOaDQTTC1AAzcUzOaM0lMQuaQtTSaYTTEKWpKBS0AFITQTTaYhaKKKADNJmiigAopKKACiiigAooooAKKKKACkoooAKKKKACiiigAooooAKKKKACiiigAooooA3KQmjNNNZmguaXdTaMUAO3UoNNpRxyaAH5AGTVaab0pJpscCoAC7UAOQF2rRgiwKhgiC1cQgCmJijinikGKWmSFLRS0AFFFGaACijNFABmlptLQAtFNpc0ALSUZozQAUlLSUAV7wfugfQ1R8wrweRWhdf6gn0NZreq8juKRQ/EL9QQf9n/AAprW5/5ZsH9uh/KnRC3kHzSNGfccU6RIY9u2YSA+naiwXKpXsRzTCMVpiFZVHzCT055H41DJZOBlQSPQ9aQyjilp7IQcEEH0NNxTAKQ06kIoAjNNNPNNNMBtJS0UyQozRSUALmlpKKAFoxSUuaQCYopaKAG0UuKKYCUUUUAFFFFABS0lFADs0uabRSAeKcDUYNOBpFEoNPFRA1IppDHgU6minCkAop4popwoAcKeDTBThQBIDUgqIU8GgRKKcKYDTgaYh4pwpgpwNMQ6ikpaYhpFRumalpjdKBlYjY2RUck4FOnf0qjIeaQDpJ896rs+aaxphNOwCk03NGaSmIWikpRQAoqaNcmmKuatQx0mNEsS1I3SlAwKY5xSGRPUZanMahY0ADNTMUtGaYhOlNZqGaozzTEBOaMUAUtAhOlITQTSUwCiiigApKKKACiiigAooooAKKKKACiiigBKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigDZpaMUVmaAKWkFOyAMmgAIwMmq00+OBSTz9hVdQXamAqgyNVuKPaKIowgqYDJpAPSn5xSLxTxg0yQDGnAmgCnYpgAJpc0UUCFzRmkooAdRmkooAXNFFFABRRRQAUUUYoAKSlpKAI7j/UNWS/BrXmGYX+lZMnU0ikMBBPzdfUdaXYeuQR9KjH36kRiFBBIPrQA5WZemR9DUyTt/ek/PNRBwT88Yb3B2mn7Im6O6H0YZH5igCd1eVfmSU+mVH+NQNayjkIxHuKVYJf8Almyt/utingXKH5hOB6rk0AVcYNBFWXMb53SMW9XXBqELkdR+BpDuQMKYRVgpTGWmBDikxUhWm7aYhlFOxRigQ2ilxRTASiiigAozRRQAUUUUAFFFFACUUtFACUUUUALRSUtAC0optKKQx4qQGohTxSGSg08GoQakBpDJRThUYNPFIB4pwpopwoAcKeDTBThQIkBp4NRg04GmIkFKDTAacDQA7NLmm5ozTEKzYFVZpwoqSR+KoTNk9aAGSz5NV2kzQ9RE0wFJzTTRSUxBRRQKYC09RSKKsRR5pNghYY81dRMCkijwKl6CpGNJwKryGpXaq7mgCJmpnWlbrTTxTADUbNTiabjNMQ3rS4pcU0mgANNJoJopiEpaDSUAFJRRQAUUUUAFFFFABRRRQAUUUlABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAG3mikpSQoyazNA4Ayaqzz9hSTz54FV1Uu1NIQqqXarkUYQe9EUYQe9S0mxigZqaJO5psQ3cYqXYR3poTH7RQAKYC3Sn0xC0UUUALRSc0UAOxRSUUCFopKWgApaSjNAC0tNzRQA6ik/Gj8aYBRRSHPrSAbIMxv9DWRJ1rYJ4I9qyJetIpEH8Yp6dD9aYeopy9WHvQwQ8dT9ak7ioh1qUdqAJVFSqzL0Yj6Go1qRaAJPMc/eIb6gGkOxhzEmPYYNGKXFMRA8QPKcD0JqBkI7VexSFQeozSHczylNKVfaEHpUTREdRQMpFKaVq20dRslAiuRTcVOUphWmBFiinEUhFAhtFLSUwEooooAKKKKAClpKKAFopKKAFooopALSikpwoGKKUUgp1IYopwNNFOFIZIDUgNQipFNICUU8VGKeKAHilFNFOFAhwp4NMFKDQA8GnA0wGlzTEPzTHkwKXPFVZzTAinn7CqbyEmpXqu9NCELZptFJTEFJRS0wCnAUgqWNcmkA6NM1dhjxTIY6tquBUlCgYFMY081G9AiNqrvU5NQyUDImqNqVjzTetMQ2jNOqNjTEBNN60UooEGKQ8U4mmE0wDNJRRQAUUUUAFFFFABRSUtABRRSUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAGySFGTVSeck4FE82eBUKIXaoSLBELtVyOMIKWOMIMVIAKTYwFOAJNSLGGI2t9amRAo65osK4xRtHFOV2zzUmABRwRmqEN39sUobnpS4FJgUAL1o5o2+9GPegA59KOfSiigBcGlx602jpxmgBwFLimZ9+9G7r3oAfRimbuO9LuPoaBDsUYpu7mlz9aAFx1owKTNISaAHUGm7qRm4PX6UAO4P41jzD5q0HlOeDVCbqf1pFIgIIpR1NLSigBR1qReQKZn2FTJnsBQBIgJ7VOsTY7D8abGsh/hq0qnAyKdhXEFv8A7X6Uvkf7X6VLRRYVyB49o65pRDkZzT5Ogp9Fh3IvI/2qPI46/pUtFFhXKzWin+LFV5LcqcA5rRqBo2dsjGPXNFh3M54ivVSKhZK3FXauDzUUlpC4+7tPqtKw7mGy0witC6tfJIw24H2qmy46igCEikp5FNIpiG0lKaSmAUlLSUAFFFFAC0UlFAC0tJRQAtOFNpwpDHinCminikMWlFJThSGAp4popwoAkWnioxUgpAPFKKaKUUCHA07NMpaAH5ozTaQnigAkkCiqcs2adMSc1VaqRLEZ8moyaDTTVCA0lLSUwClFFOVc0AORc1ahjpkUeauxpgVDGPjTAp9AFBoAQmmnkUNUZftQBFIcVAzZqWQ5qA8UANIppGKcTTGNMBCaZ1oNFMQuKaeKXNNNMQZopKKAFpKKKACiikoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKALCIXarkaBRihIwowBUgGKzbLQU+NQ/XPHpTQpJ4qyilRjBHuOaEDARIRxmneVzwSMdKdk9CKXcOnFUIQI3980u1uPmoJ45PHfijcM8nGelACgCk2g0gK9jSbh/n/PSgB/HajpTd3tSbgSQOtAD8jNJuFNzkg8/Wgnk8ECgBwIPY0dO1Nzgnvz6/55pMcfrQA/OD2oJP0/Cm9R1x/n+dJxnGRz7UAPz6EUme+eKbnA7jPt/Olye5NADs5POKOKZuwOe3X2oLdj/k0APznj+lJn0phPvn3FN3kcEc8cZoAfnPT9Kazgjgg96aXyMHhvzqJmyP8DQAjn3z+NQMMnp+VSM5/p06VGeedppDIyKBUmc9c04BT2oAiAJ6VKm4U8RA8Dk/WpFR16MwoAWOSRfuvj2qyk0nRsGolZv4grfhinqwzzER6bTTEWgwNGRUO5fVx9VzS7l/v/pTESM6g4IzTgQRkVD8p/jWnAj++v50ASUUzI/vL+dGR/eX86AHk8VErqincccntSPgj76j8ajwoP8ArfyBoAmEyHoT+Rp+4etQbk9WP4UhkUDiNz9TQFiHUSMp9DWcxq/MrTPnaenAFRm2cfwqKQyiVz2NNKmr5twPvNn07VGQi9PX8aQykykdRimkVcJBHKgj3qJolY/K20+nWncLFaipWicc7cj1HNR0xDaKWkoEFFFFABS0lFAxacKbThSAkWnio1p4NIodSim04UhjxThTBTxQA4U8UwU4UgHilpopwoAWlptLQIdTXOBQWwKrTSGmgGSyCqzNmlfJNRmrRDAmkopKYBRRSgUAKBzU8aZpiJmrcSVLY0SxJirCjFNRcCpMUgDNNJpTTGOKYA/SqrnBqcvVaQ0gELVExpCTSZzTAY1MqUimMKYhtIaCaTNACUlLSUxBRRRQAUUUlABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAbHtT1QEjqT7U1QWOFySasJGoGTnPuOlZlgiqvO0mpAy4HB5+opvoe57YPSj8d2fftVCHZBzx/n/ABpCx6gDPvSfLj75x+NIAAPu4x6nge1ACnPPT6ml6g9OTjBo5z1/MfpTd3HJycZ/CgB3vz+XWkxz0H+f6Uhz3x26d/Q0d+Bz65oAXIyCMc+3J/8A1UuSOSQR603B3HoOmf8AGkwexHXr7+tAC5/2j+PX/wDXS8HODkkcU3kY4zyOaPbjnpjqaAFBHT2Bpc8d+npSZ44zgDPpSHgYwoAGB6YoAdwc8cUZIJAxSEnI7nP5UnT+7QAv4E+1JnPAOT7dfrSE4PYe/WkbnjOB7dvegB2f/rHt9KCcE+3OM8imkjJ5GT69/rTSR1Gdo7igBwbJ4ycdccZ96aWOeB+I/lTTnuo68c4FIenPOehpDB2HfJH0xUZ4PQf0pzE49ce2ajJ68+vNAAeR6Z5pv/1s0Eg5Ix9aOlAB+HT0pwP6imj0xzjpTh04PH0xQBIrH0JHXjsamWQjr1xxkdRVccc84/WnjGdvrwecUAWw+Wx8o+o5qRGU/wAJH1qorcZ6jtUgOP6EnINMRaDDjgjPelyKgBOT6Y6MacDnv16c8GmBLhfbijavp+lRg596UNnp19KAH7F9BRtX0FNB54PSjPv3oEO2j0owKZu7bjSEjP8AjxQA/wCX0FNLqD29aYXHt+JqLPBGd3PYUhkjzcZAyMZNV5JZD2wKcwOOT065IqFsE8knFIZG3U569fXNRsTk/wD6qexxxn8u1Rk/hQMaTRn/ACKQnt/Okz+NADt2P/rdqH2t98A+/f8AOmZPrSbj1zj6UAKYFJwrEexFRmFu2G+hp+71o3cfrimIgIKnBBB96SrHmD3prBW/hH1HFO4rENLTzEexphUr1GKBBThTM04UDJFNOBqMGnA0hokBpQaYDTgaQyQGng1EDTwaQyQGnA0wGnCkA8UopoNKKAH0U2lzxQIRzxVSRhmpJnqq5NUkSxGIqM0E0lUIKKKKYgp6imip41zSY0TRLVuMVDEtWVGKkY8UE0maTNMBSajfpSscVGWzSAiY81G1PeoiaBjSKYeKeTTG5piELU0nNIaSmIQimmn000xDaKKKACiikoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA6BE2r90fl1pQ3y5wMYzwaCc9z/j70hPfdjvx/OoKHFsnHB/H9aOvPb3P+eabjJA6g8+31FB285IPrk0AO3Nn3HUCgYIGOc9Mjr7UnTqc9OhpcnnP45pgBHP8AFj/P60bgRuzx1/z6GkyPvMecDLUc4Jwc9/f1oAU8HJAGP88UgxkYPTpx0+lGey9aTGeoyf8A9VADhxz1+ppAOmDn0FNLEjnA9Mj+VKee2Rjp2oAUjnHP50hAI64A4wO9IxHHIJ+tBOQeh7HnpSAdkMMdjnoaMAgHHt0pm7K9R16g8UZAHJGcc89qAHZGO3TApOM49uMCmnG70Zv5ikyOOcZ9fWgY45x1P1FAbngc9Djt/wDWpmR64A7A0hYZIz07emKAHk9iSB2Hp70zcCQf4setJkcgHOeOBTSw6ZJB7dqAHEjGMdOvPSmk8nOOT26fjSE565J7U0jrj8x2oAC3HXnIz2zTfoeaXuefrik7AfmKAE/yD6UUfWjkHkjNAAOg5pynnOabz25NL/nmgB6n0x+FOXnj8BzUYz6f0p3Hp9KAJlyeex6tipAcc5/KoBz7808Y+qn3oAmGMHsM/XFPz6455+v0qAZBHU4/zzTlbHt3I/wNMRPkHHT86N2e1RDPfP4CgHnv/SgCbdn3PuOtJuGTn8aj5xjnmm7s9T19RQBLv/x6U3zPX65qPccdecdhSFj13fhigB+/Lcde2ehpjN16nB4ppLDJ6Z/lTD7kY9PakMGPoMd/WmMxPByaG92J+lRtznjn3oARmqM/nTj3x+lNP+RmgBCe2f8ACm0pPrTT1oAM/SjI9aTNJTAWmmlpKYgNJmikoAXefWk3mjFJigQhOegxQDRijFMBwNLmmZpc0rDuSA04Goc08GlYaZMDTwahU1IDSGSg04GowaeDUjHinCmA04GgB1DHigU2RsChCZBJVdzmnSvk1CTWiIYGkopKYgpaSlFADlHNWohUEYq1GKllIsJ0qUGokp+RSAUmk3UhYVGW5oAc5qItinluKhY0DAnNRsKN1G6gQw00mnNUZNMANNNKTTSaYhCaSikpiCiiigBKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAOg3DOcjGf070A+pGR7fnWUs2O3H1p4uWUDaMYqbFGmGOB+n0o3ZwcisszuSMHGOnFN82T+8eKANXeMdQPQ9ce1IWHXOeM9elZXmPnO40m9v7xoA1y4/vf/Wpu8EAn8eay97etKJWAwDQBpeYBgc+3FJvUA/KMf5zVEXJ4yOlBucjpQBe3/NyuMHjPammTgtjp0qobrknFN+1EHOKAL5kGGxheetIJuuR7is83DEYp32onOR1/SgC8ZFPXB59KTzRn2/+vVT7QhJ4x1pfOj55/wA5pDLJl4I7ex/Om+aOf1qt568nHWgyoT36UAWfN4OB0HFIXHTnH86riUHAPHrS+YuO3PFAExk555P8qTzD+tQ+aoPUdaZ5/HHvRYCxuJA6U0sT1Ge9QGc0zzm5osFyzk9O1G44AquJueRxSiUd6dguThs9qTd/jUPmqMUeaMUrBcsbuegoDAdBxVbzvQUolHfjpRYLlncOtOBOOtVhIp4JxTw6nuKLAWAw9/zp+9R/CPeqwZc/eFG9f7w9KALe8dMdPenLIOn6ZqoHUj7wpRIvXcKALQlBYA9z1JpPOG3t9KredGMfMKQyxnGG/WgC4ZhyAPak80DrnrVUSpx8w/Ok8xOPmH596ALRlTsScdKaZgD0PXmoPNTsR19ajM6YxmgCx5oxnb9BTfNOccDn0quZx6k80wzD0oAseacevtTGfJqHzR70hkBzTsBLvpu7jGKZvHrRvB70AKTSUm4etGfegQtJRmkyBQAUUZopgFJS5FGR60CExRRketGR6igBMUUuR60ZHrQAmKbinFhRketMBlKDilyKTigCRWqQGq4OKlVs1LQ0ycGng1Cpp4NSWSg04GowaeDSAfnAqCZjUx6VBIKpEsrketMNPc1GTVEiUUUlMQtKKSnL1oAmjFWU6VBHVhahlokFO6UwGjNADjUbUpamk5oATcaaaQ0maAGsKYSRUhqNqYhpNNNBpM0xCGm0402mIKSlpKACkpaSgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA0fs6jilMKdhipPelGc5NZmhELdPel8hewqWgDIoAg8hc9KcIExnFTYHpSMcUARGJP7tJ5a4xtHNSgdzSdDQMjMa4xtFHlKB0FSYoIzQIi8sEdOKXyhjoKk+vSmk0AR+WoHQUeUuORzUgHrQT6UARGJQMd6Ty1HWpMc5NJgsc9qAIygA6c0oiHenkc5pDlqAGBASfSk8sGnnpijHFAEZjGelGxQMmpBTTzTAj2ijYAMmngZNIeT7UAMCDGTSbQTTyc/SkoEN2ijaKd1opgN2igKKd1pcUAIEFOEQNKBT1pXHYZ5ANPFuKcpycVKKV2BF9mXGcUG1XAqyRgdaCTgUXAhFquOlOa1TA4qXqOaD0oAgNsgFIbdABU5wRTSRikBA1sKaIFGcmpyeKY2c07hYiMaimMg7VLtppAAouFiHaKQgVIeaZimIbgYpCBTsUEUwGYoxTttG2i4rDcUmKftpMUwsNxRilxRQAmKMU6koATFGKdikxQAmKMUuKMUAJijFLRQITFJinUlACYoBwaWigCRWzUoNVgSKlRs0mikycGnqahBqVakoezYFVZHzU0h4qs/WqRLGE000pppqiAooooAUVIgqMVLHSY0ToKlWo1p4NSUPxSZpN1FAC0lJSE0ABpjcU7NNNADN1NJzStTCaYgNMNOJpppiG0UUlMQtJRRQAUlFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAwooooA//2Q=="
      }],
      "extension" : [{
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/Lenses",
        "valueReference" : {
          "reference" : "mock-lib"
        }
      },
      {
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/Lenses",
        "valueReference" : {
          "reference" : "mock-lib2"
        }
      },
      {
        "url" : "http://ema.europa.eu/fhir/extension/dummyValidationReference",
        "valueReference" : {
          "reference" : "#binary1"
        }
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "indication"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "B90",
                "display" : "HIV-infection/AIDS"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "pregnancyCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "W78",
                "display" : "Pregnancy"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "breastfeedingCategory"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "69840006",
                "display" : "Normal breast feeding (finding)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "liver"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://icpc2.icd.com/",
                "code" : "D97",
                "display" : "Liver disease, other"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "contra-indication-hypericum"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
                "code" : "XK4IUX8MNB",
                "display" : "Hypericum perforatum L."
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "hepatitisB"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "66071002",
                "display" : "Viral hepatitis type B (disorder)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "elementClass",
          "valueString" : "hepatitisB"
        },
        {
          "url" : "concept",
          "valueCodeableReference" : {
            "concept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "66071002",
                "display" : "Viral hepatitis type B (disorder)"
              }]
            }
          }
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
      },
      {
        "extension" : [{
          "url" : "lens",
          "valueCodeableReference" : {
            "reference" : {
              "reference" : "Library/pregnancy-lens"
            }
          }
        },
        {
          "url" : "elementClass",
          "valueString" : "pregnancyCategory"
        },
        {
          "url" : "explanation",
          "valueString" : "This paragraph was highlighted because you are a female of 18+ years and this sections refers to potential issues with pregnancy or breastfeeding."
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/LensesApplied"
      },
      {
        "extension" : [{
          "url" : "lens",
          "valueCodeableReference" : {
            "reference" : {
              "reference" : "indication-lens"
            }
          }
        },
        {
          "url" : "elementClass",
          "valueString" : "indication"
        },
        {
          "url" : "explanation",
          "valueString" : "This paragraph was highlight because you have stated in your IPS the diagnostic of HIV-1"
        }],
        "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/LensesApplied"
      }],
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/rmswi/",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000155538"
        }],
        "text" : "Package Leaflet"
      },
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/epicategory-cs",
          "code" : "F",
          "display" : "Focused"
        }]
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "date" : "2022-02-16T13:28:17Z",
      "author" : [{
        "reference" : "Organization/mra-1133a7374c78f1d40f41885344f06a5a"
      }],
      "title" : "TEST PURPOSES ONLY - Biktarvy 50 mg/200 mg/25 mg film-coated tablets",
      "attester" : [{
        "mode" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/composition-attestation-mode",
            "code" : "official"
          }]
        },
        "time" : "2022-02-16T13:28:17Z"
      }],
      "section" : [{
        "title" : "B. Package Leaflet",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi/",
            "code" : "100000155538"
          }],
          "text" : "B. PACKAGE LEAFLET"
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.</strong></p><ul><li>Keep this leaflet. You may need to read it again.</li><li>If you have any further questions, ask your doctor or pharmacist.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.</li><li>If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.</li></ul><p><strong>If Biktarvy has been prescribed for your child, please note that all the information in this leaflet is addressed to your child (in this case please read “your child” instead of “you”).</strong></p></div>"
        },
        "section" : [{
          "title" : "Package leaflet: Information for the user",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "Package leaflet: Information for the user"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Read all of this leaflet carefully before you start taking this medicine because it contains important information for you.</strong></p><ul><li>Keep this leaflet. You may need to read it again.</li><li>If you have any further questions, ask your doctor or pharmacist.</li><li>This medicine has been prescribed for you only. Do not pass it on to others. It may harm them, even if their signs of illness are the same as yours.</li><li>If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. See section 4.</li></ul><p><strong>If Biktarvy has been prescribed for your child, please note that all the information in this leaflet is addressed to your child (in this case please read “your child” instead of “you”).</strong></p></div>"
          }
        },
        {
          "title" : "What is in this leaflet",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "What is in this leaflet"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>What is in this leaflet</p><ol><li>What Biktarvy is and what it is used for</li><li>What you need to know before you take Biktarvy</li><li>How to take Biktarvy</li><li>Possible side effects</li><li>How to store Biktarvy</li><li>Contents of the pack and other information</li></ol></div>"
          }
        },
        {
          "title" : "1. What Biktarvy 50 mg/200 mg/25 mg film-coated tablets is and what it is used for",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "1. What Biktarvy 50 mg/200 mg/25 mg film-coated tablets is and what it is used for"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Biktarvy contains three active substances:</p><ul><li>bictegravir, an antiretroviral medicine known as an integrase strand transfer inhibitor (INSTI)</li><li>emtricitabine, an antiretroviral medicine of a type known as a nucleoside reverse transcriptase inhibitor (NRTI)</li><li>tenofovir alafenamide, an antiretroviral medicine of a type known as a nucleotide reverse transcriptase inhibitor (NtRTI)</li></ul><p>Biktarvy is a single tablet for the treatment <span class=\"indication highlight mock-lib\">of human immunodeficiency virus 1 (HIV-1) infection in adults, adolescents and children 2 years of age and older, who weigh at least 14 kg.</span></p><p>Biktarvy reduces the amount of HIV in your body. This will improve your immune system and reduce the risk of developing illnesses linked to HIV infection.</p><img alt=\"How to take medication\" class=\"mock-lib\" src=\"#binary1\"/></div>"
          }
        },
        {
          "extension" : [{
            "extension" : [{
              "url" : "type",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/type-of-data-cs",
                  "code" : "PCT",
                  "display" : "Pictogram"
                }]
              }
            },
            {
              "url" : "concept",
              "valueBase64Binary" : "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAIAAABMXPacAAAraUlEQVR4nO19edgdRZnv763u0+f7voTsCyRhjcMmJATwDjgjoihIQMCNKKgwyh5FcbyKBBTC5h1GvYFRQFmS4Iis0TzKBZ951BCUZUAggQABwpY9gXzZvnNOL/XeP7q7urqqus8B/53K95z06X6r6q13r7eq+lCHO8iLYCFJCkZNkYQqgJpH76YI1V75jgRE+knEgGBOysBCq/IuShltIQmCi74AKUkIhqKMPUz9TjURsgYlSX2YglnKHO/0mSS9TqkbwN2685HWTuUdJ5aSZJmUUhJS0qQlATNz/igDzgf27opFr5TKQmtTCJYp9SVlQzA+deqnn+pPbzltUDAEpzzOBiyIAY18GkKlIdVIt5P0NnwP+iGdEqTQVe2oEep0qWxUo1cPKKVMtRUROe2yWmnXei/6U9W4DmMxWwq7fo+lSsANChpg6mtVdRvp/FrZRql9FrUMMQRKTKrHHA4yddEnW8gMzF0CbfYiCYJIEJVMTVdcjXb1Lu3RVn3tRT8slpSIbkMaRHHKIyzJrehdOLHtwYo6W3OUDFvnXViDsW0fUJIvWyKqBM2WbuOOatOWL9Rqatfe3w2kboUKKjmZ52zHoBIs25CNMff4dShCk271aSDUzd4VNx1IsBugF6vdu6xVEa46qFPhisMX1qiy3b49TIWPkKTiIfXp4IchlYruxthsNthd2tdVVaqMkpIp58BseB2sqwMwauXRiwnZlZ014SIKegpRNUjjTlcj2FX2YUl61aMqHACHENhmUG+w3tP0GAjow69xreW+3G41b1nk6Ek17yjq9G5MehxV1U0nTJUvcTKsa9hX05cdrTnVyyl8dvRp92CDacgX0YQiemHpUtvXQ0xSKlWqV0XQqhZ6kVmn9XPCVxWnG3eGSWq8hh7Y4aYLk5L3NkoWTaivqJA1/b4ew1Sxt0Y69HZ69BbO7qoigncVn9gWpt6vGISuFxQAkkre20AyT2/kDLClW1rTSxX/GbSosua2bnZF2h6ecWHIoCjPPHrxPXaM24vb7N24ab04YidJhVpIEoJFliEyRMBp12ybCJcxNeCd46m5WeONdcnQ6VilLoYkGaTsas1s0ncNt3T/IV0ZIa01CUhJUijrrwRKtWUHAzUzhqqIwrh2RrE18uV09U69qTFrwpW0Mb7WqHLNtdFFD4Ko7JJQ302BMmhUHnbBKr31erXo+tQpX/Uhh9G4QrvK7tnI1KiagWq9bAEO/G2m5lWyzG6RDXVZ/1KGDrUSqjqrcQxVVqJGr6ssey9exHhkKLRuHFAWOLs1p2YY0mNj6HSiunyUerStPyB18deth33T9oROqXFyyGXizBEaI+/9q04Cwzqp3g1PUNWI8anfN3isDxAwaZLfEWrdRTAEs2SWsDjmHL8ulU4LU2VPbROnFwNdg1sGWPmrgCk9NgwZo7M55+y6ojWHruh3aoyk3ZrMw1Czqyob59Q+WwENSbFtVJWfR1myqvBJu0qfqGm9GqfVWtGWPgRds0vtuhTdRsOpuIDZuKXNdmpPgKhLfKuNUOi0c9oQmyVq2E6zaMPbQ3VZpCyJK9gRFwhXTKL7AP0ONLPpJLETDZ3rTk9QvkjppoJ+TXG7GgRAlwipUxNlKTaUw4m6U42MYptsOKRP5BGFCSOpkvq6OhqfumOAi+tOhbBppaGqT3LVgn6huOlTimTH6WaNPpxf31Vx2rGuVXqE74pnjXuzRc0GcDbYDSvD2qhtFsjXnCVQnlhVuR0DFRu+lyiiHl0j2Khqx9m1oVI2M4yxGEZPloOlKsNlNFjFYA1PWcZZz3VqSbryMB3IWdeOVUzL5JWG7bSedr/19rRKwHVXVBVv2GMxMKmyw85SxV0N88ziW8Yz3XZVImBp6dnZrrqTE6Kn7QLQPJuwYjunjOvmGJbS6CpiyDtgVtSr6Pwz+Go4G6Mjuxcb0mmr8y1csuzDBCDzxI9U5qjkA2y0nLypkQ6n1a6x/tVj6K71do/v2Wf0WGowrIHXIHU3AN0HmLkHoxX9fk0AY4+/qzW3ox37PqpJX1NkbRrHqUN2y7a82zbHWcUeY/oQmQ8oNEAkQDoZZgYz9FlxlfIa7VYRQm/BBq5A0d1FPQKwonsn58oGocCwBsaQ9170tZ5oDsgykLS1wUky+06V+gsr+WXgYXfhFEn7keFsjGtRnhUbPTpdglF6V7sqSFtF9OFnS7/6Zl17l1yFnArrTl3sIVgpmVRC5zRERiykt2DLtWDIQn0lVwRXqOa386vzjlG9q/WDRRDDBhRjEdlub+SBqhnk2HGCDaOaNmy6Lcv2U+OOHs/pF85aXNrCXuwloLJ+1HgU1aNtdXXcYHGxKnwyMNef6pwrDBEBABFBl/0e9dHuz+hYXXgQBEq70AlqDEbxgHOlSYAEMKS7zNHSBkIiCuA3EDQQEPncQ0zh1ADdSehIOo277dirCCisaUoRhjob1Ss7FdmWJv3aKdp2s6nnFwxtLahQMsU2kPDh6blbCY64k4UTJBrww6Szds3aLYNbGw1/wsRxE8ZMBCjmkLVquk4YlsFpG2tGVyOXNQTR288YUGPB4RJ/u4o9GKMn45HChsG5hBeHUjSiw0cjpd6W7VvWrl6zatVrb77xxuDg4Lbt26e+b+q/nHkGiH0RtDudu+666+67737t1VWtVlsIMXLUiEMOnXHmGWd++ENHMZJEy5t2Jb2Bee/U1+7ry7/SVVcAkiLZKbcgjLM49bSu6r48qnQSWIYEC5ASfwPYgwB5PjyJ5NVXX1269JGlSx5e8cKKTRs3DQ21ZJIkzEEj+PXdvzrqQx8CsG7d+m9edNGf/vhH32sAkFISkRAikXEQNM46+6xLLr5ENLw0CkC1UpYI0Y3KtRpgEh2ApPSwTabrgqUk4ZfrdMfAlgX9wqB+3oiJSvYVBfUBwSKzEgK+D3/LtsEHH3hw0f33Pf30M4ODg0II3/eFEL7fYOGFQzvPnj37wx86OkG4dXD7V88668nH/7t/YADA1KlTJ+w6ceeOHStXvrxt61awuOH6n8ZxMvfyuZI4XZ+pp35NgGCAwS3y6eCK+C19mhOkOIYmWPoaaaQO56SvcWEris4J477BHoAEIymQloAgUAONbTu23n3XvbfffvvLK1cSURAEfX19URSFYej73ogRI0aPGTN+wvgzv/plicRDcMMNNzzx6OPDhg8HIGVy+he/cNZXz0k4ennlK9dff/2i+3/T399/6y23Hv3ho4756LEJwhrKVllqIxayx6uGoJ9y1B6V0nCp7KfVlQnSDwVW0t0uPRooJzMksjjSg2CgQT6DHnroweuuu275sud83/d9P4qiOI5HjR417eBpRxx5xPQZ06ZO3Wfc+PH9wwYEhAdav3HjsR8/9p3N7wghkiTxfd/3vSuuvPxLp58BQHLy3YsvvmPBHQAfc8wxC+9YyIIlSvjp9LWvy0LTk++toEZx1jMV99QKKQ0oEng6A2uoqWCcd+DinyFKxAwS6dnYAMGmzRuvvPKq+++7X8qk2d8Xh1Gn097/gAM+/dnPHn/8cXtP3auBAGCJRGauWxIFf3vqb5vWbwJh5szjJ0+ZctNNN0npX/K9OVEYfeVfzhIkLr74uw//ecmbb65etnz5+o3rJu06SSIxhmNf2xZVlSqhTAmqj92mfn5HZRyEbxsTu3XL9rkPjVQpoG2OBCOBJAaImBAgeOyJx777nYtfWLGi2d8HcKvVOuig95937jkzTzxhxLCRCWSCqMNtFR0xZQ7jlVdeYSkh6GOf+Pisz8zyGt5Pr/+p7/vfv+wHSZKcfda5Y0ePmzZ92muvvbF9+/YNGzZM3nV3wYlPQYIoYckwl8RtAdLv1Ii/nqhX5t6wK+md0q5pUc7VOCkuzQxMaXOdVrEU6ui1nOyUBIAb8O+5754vfvH0l196qa+/v91uDwwbNmfOnMWLf/P5Waf1DRvW4TDmmLXJmE6FdrsFkkTwfQ/AnO/N+fqFs6MoBOiKy+fecuvNABpBAyRZchInAOI4Xvy7RUkUe+TZblhaaSt9OC77bsJoF0VyIYfPVoOLrUEWAtDDIV0EDHGwcTJbscRHR5FIEChAc+EvF37rm99qDbU9vzE0tPPIDx75m0X3XvSNbw4bPtDhUA+TkC8f6T1OnDgxzeM++fiTafuXXDLnaxd+LQxDZlxx+ZU/u/E/Xln5iif8vv6+sePGAoij+OqrrrrooovaQ62AGlWYG9eiOqdbY4dREtB0FNBWJWWJAYpLWjVh1DfiAWXLdCCD1oZuScqOugfU/OWdv7zke3OYAKIwDs+94Lw7f/Wf7z9wWofbsYYMilUkLjfLh3/g8GG7DPf9xuLFi194+QUfIoGcc8ml551/ThiFAF199bUvvbQS4H/4h30mT5oM4NVVqzZs2Hz3r++ePfuCHTt2NOAZFFf4G9Zf3e9qqPUWyvd14yEBUZn/yfeuFNsU0zq5/RI1a5OGB3OpCDWp+bsHfz/ne5cSwJIBzL3yyquvuLLZ3ww51FFEnqYlEnoeQjASjg/Y78CPHnNMGHbeeeedr51/wfMrnvPhCxJzr7jq3HPPTuJYkGDmRMovnXlGs9EP4KGHHtq2devAsOG//90D3/7f3w6jSBSHtkzp0QnqHFc9pBHU5mqkJVr0XJAk5PStX/gVmjcv9e0MnIz7kjhA8Ozzy06bddrWwa0kiIl++MNrv/iF00N0mEkLEkqZCX0YqjWP/FdWvfqZUz69ceMmEEaPHnXcccftf8ABYbvzxBOPL1mylIh27tw588SZt9xyi+dDkL9s2bJzzj7nzTdeD4LmUKv1jYsuvOySH8QcSTIlpSrC7j1Sd0KmbWdTn3IqosiFlefNduvv5dUkkkCAgLflnS2zZn1+xfMvNBp+GEdX//Car37pzA46yLKXEoCT6MbXFCufgiUP/2n2+bM3bNjUCBpxnHnsdPLcarWO/sjRN95847hxY6WMATRE3/Lnlp3xpS+vW7/B9/0kSW66+caTPnlyhJhYGr04R9H7rKjipsi9sSz2yKGwUNKwMMbgtUAI5ermhXFTMASTgLj66muWP/tcM2i22q2zzz/nKxn1OTf0ZjEQAEgSSEpmSFDE0YeP+si99993yqdOHhg2wHkBMHbs2H/9zrfmL7h9/LhxMcepUe5w++CDpt3wsxuGDR8mpQT48ssvf3P1mz48257oIaLhcu3xOi2YMftJ/y+CESsZB+Wp3xX/a+RCLz4FDzz0wFlfOafhN8LO0JFHfWjhwgXNvoYsexQiMyNSnkNAWacsNAIaFAD88qqXn3122fp16zzP23OvvQ45ZPqkiZMjxJKlUaVJwfyFt3/32xc3+5qtVutTnzrlxptvZEokiBkAEwljY+/fU7SYJfPDqRwX6WgdosqO9/i1CkCQ2LZt+8knn/LKS68Ij4aPHnHPonsPnLpfxJGCdJIe5dkcm69XyNlAwoOvP0gQJ7BXK1MT53lSXDD7/PvuuX9gYCAMw9vm3zLzEyfGHObiyYbPN7AyjHNXmmilbILKDUmjUa37mpCpPD4rpZVFBfAXLFy44vkVfsPvRNEFF1540NQDI44ydwphUL+uTUJAQTP760svGmXqA/DgB1BgOnxfgIYnvMu+f9kee0yJ4wjAvJ/MG2rtEIXvIeRrzrr/1Mmlo1RPE2MsipgUycjY82yx1MhjOJqrkoISLcjbuHnz8Z+YuXH9hiRJph96yD333dPfDJJ8osh5TOxsrWR/QYLw6KOPLXvmWZlIIiWrBFBuN4p7lC65ppRK/2NqBP4RRx5x0AEHL/zlgn+96Nt9fX2dsD3vhv/7hVNPD/OMaVdSGnh2VQsA+YGGTAN8aLkdw3kaOlFlZGomI/pXgnf//Yveemv1sP5+ycn5X79gl75hHe4IBpEAZWSzW7N7b5D345/85EfX/SiKCtsFAMyc7TGgdKFNQojcn6UcYEIabTLz6FEj/+Omn5166qwF8xc8t/x5glhw24JPnfxpv+mnGdMqUagSdidBynWVimcLMqUoyKCdLGdFbADjTg2AINHq7Lz/3nsDX0RhOG3GjGOP+ViEiEBM5GwQ7pkkPPLfWvPWz2/+OYEG+vozwSYCERMxscyUgDjlK6UjEDINwQAAvu8PDAwMbts+b968ZtA886tfSWTSaDSeXbbs0ccf89GAZl7MsdQO3L5Zrqs2xyH1BL4FYc+bXO7UIla9i/bhP/XUX19Y8aLv++12OGvWrP5Gf4gwXwRzyI7tSFIAIrF27brtO3YKQY2g8YkTZzabzSRJhBDMIDBklq7QDQ8o+wdAkHjj9defePwJv+EPbhkc6uw4fubxP/n3H69ftz6KksW/+e1HjvqITsSa+KLK5LoCf+S2ROZvpxQAihUxuFyKEYfA0qkaPEo2ivDggw+FYacZ9E2YMOH4448DECCwTqeVC2mfWvE9T4CZMTBs4NofXjVm5LjaVhzl1/fc+cgjj/iNgASSJBk3cuzHPv6x2265LQiCpUuXvD24adSoMUl52UCVnDJCsCNSd8VIejo6g1JUVWvC6viStCtUeRgLpxK8AiOiVjj06KOP+X4jTpI99txj7Zo1q1evJjAgdJ9JIJRFNiuqRyIfYuWLLytn22l35MgoBgMqPHVP0dOpNYObaEZRQiQEINJOgeOPP/6OBXcIIVa/tfapp/527DHHVTEgH7LRS2lnWJkC6n5G5Jy2EhA+8pmt9tZWqS/uoKwfhkLAzfMSnwT8t95a9cbrb3ieR0TPLX/+5E+eklM/xY9S0mSEylwoOHOZRDlM6q8ZnC5AMjlOeObkQJkTKuBOK3DeIQHEkNMPmT5pyqS1a9bGiVy69C/HHnOcFlCZI3IVM3x3WaEs0aD8sKRsHqBOHKrKamnNcR5Gh4SL51b8Q88+++y2bVtTgyxlwpKlhJRSSslM2cZsmf6xlJIlM6eBDCPbuc3MrJ5lLTPAIIhUWYnSzXfOfGIpzGMGZxpGIEogx4wcM33atDiKfc97+m9Px0no1Yb5tu+tcdQWPtrahmZ5FEGLFL+wNtLYVJZk/tnO8+mnnuYEKkVDWlEwcRS32+0wDMMwjKIo3QYRhmEnisIwLu5GUZzEGR0B4XkEL01We/A8eB4Jj0iQL0gI8gV5goRHQkD4EF6W3wZBMiBJaR6mTT+YWXqe9+Ybb7z9ztuiSPqaATqs06V2EOiqlZFePU33BQkUUp8doEm/OgMem7h2KWkAgZG8umqVEKYyqcLMURQedthhJ5z4yclTJpFAHqyXSirgvvBeWvnSddddBwCStw9u6wv68rcvU25WmEGSmFikgSgBTIKYGezBHxoaSjsGS8GZGdtvv/08zxMktg1uXb9+3cTxuwKJHYinVrpqvBW+0zxNnsIqH6DEv3TouYL5SB2msJINzkkDgdpx5+3Nm4QoJkE6TZk5juNvXHThRRd9q785YJHdUcZNGP9v/3adJ8T2HTtOPfVU8jwC5Vt4Sc2GmbK8Wp7ZJkKqgXJoqNUM+pIkSf1M6hAmTZnc398fx7IddtZv2DD9YKox+ra3qw3Q1Zah4nxSukPLVz66THfzNeq24NcbQVUIFLY7O3cOkfAcUg20O53PfO4z37v4khiyw6EDotxtk5ph2E631Esp16/fyMyGw9RwIsrcbQaTzQeIhBCpm0nrMXjMqNEDAwPbtm2XSbJ1y6AapjP2c8QatdPVVA/yO1K9c8BXQSdKUw89/VREpflnNrl0ztGMawbFcRJ2Iuf7EKSUAwP9551/LkFIjvOISC2KmXukAWHEPZ7npRdxHMdxBBL6Y45ZJYny/AQAeL6fvrFT27/OfX19QRCkfmrH0E5UU98er/0V5dBT7UWU2VYoZCZIbdysYKC5Vxc56Q3Vq5qvC4BZSk4cEyogSZI99tx9n6n7xEj9KgHkEVEmGRlpkAYruZh7nig2BgEAwjA8+eSTTjzxxDy3Snlsy5LSSClPw4E98v/62KML5i/wSOhKSUIoRyVjc/NW17lnPTPyLJDQ5FgA0lckdkX3qcqUNEDBOCNOo0jKJFYIU3LTwsyNRuAJT7URkL/5nc2tVouQzZsK0FR54a9bu56YdZVKknj/A/Y76aSTK1EplzAJb7/1Nk/LXjOysDj96nkNNQSU1d2w9fXyp8EXB1T1H4go5YLKTZhTBKe9sy5KdkMwQOw3GkHQRO5yTWJQPg+D9ODfePNNP7/5F1EnJErfZcTIiJ/ygiVDJgmlPMtb6+vrv/WWW5955umTTj5l5oknDAT9ISJ9QsBgQBBLEAUIok5EnM4CAEgBJog0CBZCCCEGdhnmpCYsydM/XUVq++OQU7KIYvXd0fpFsXJmpCVqRN6YPyMTHw6C5rBhwxmSSdiekkQ2G/DIW79x/byfzNu2dZvnCZWlsHlmTCDSO4OD2/7w0H/94Q//9cH//OU11/xw//0OCBGjeE0JAZxlvQkgMMms8XRbEmjLli07h4aISHhi9JhROrltEjsnvU6voByvWgnQtywWGQzbBKX/w9QMg756Z47omIBmEIwcNUJKJgZZvljki7oMHjl8xH777ttqtdvtTqs11Gq1Wq1Wu91ut9vadavVag0NZU9VCcOO5/nNoO+vf3nstNNO+9szTwWWeBWFlW0jztPXa9es6bQ7AJrN5oQJE4w8hLPUph+U0U9pXUwFJBWvq1G5IIOyXX7Kx+7P2LFbREHMHjUmT5okZQw49gEq38DAwMCwG39+0+LFi3du20lEDEhiwWn8LvMwRqYkYyICEwvmREq8/fbmh5c+8vqq1/r6+9euWff1C7++aNGisWPHJZQYFhwAg/K3BjOQNogXV76cJImUcvSY0RMnTmTDllYMXLupL7ir36KBZvqL1tTuRL/CX1fO9GyclIo5n6Zl3/32Y06jEpuxWSguGBLJpF13Pf+c8y2YnsqmzZvmzr3inrvvbTabL72w8hc33zznku8zl+IZwWmiNc/tEeXX/NyyZ4koSZLddtttzOixcUVW1R3saVYl/wpl+g0rpL3VWAhdLvIsh0F9XXeKC23S4CaHrrbTp08LAt88bgoAYEooHyoTIiQxhyHC9DPisMPtDrdDdEJ0QoRVfzGH48eN/9GPfnz00Ud3wk4zaC5a9Nu3t2zyyDMMBQAQZwdE0hgNYtvObc8//4Lv+3EcH/j+A5tek21/VSaLNkA1l1Ibfoq9JyrHrMWg2uZcK7KslH2hHc0Rrjm3QXoFkCA54MADJk6cGCeJ7QOosAYOj0eAl2XQKM1/FIO2rmOOg0Zw/uzzPE8IIdasXrt8+XKCJ6xpPEFkux+IU9KsXPnSmtVrPc8jgSM++I+VYyt6lAZT87gR+g9qCVbaILSzcoW5VrMyPV1nDMxh2fU7gDk8EwbJ2NHjDj10RhzH1kAILNTBOb2uLbZGpKCroLqW4P33P2DsmHHMHCfxm2+96UQblHrhdAmIAfz5j0s6rTYYY8aOPex/Ha5WY/QBViRjCuOTmxAdoNAM7VxGMQ9ImSbQLb+qhmFFPiWqOQsxCPTxY49zPALiJN/KaRrDzNAlkPmp+XRhIFNz9YqIFCCf3GeLC+lEWWUazOFwtl7MzESiE7Yf/H8P+Q0/iqNDDp2xx+S91DEmK9gvvTcyp6YqeiQirRYMNpT2hsrcqDkyE84JsF6qojT1iJEcffRRkydPSpKyS/TEurVr161d52nxWEGl7BUcQvsDIDg72l3cSYElQUA8t/y5d95+hwQ1Go2999pHOXm9cdbi0GbQt/SRpStWrPD9BjOfcPInG5TNzMuDza22tvynGx+V3jH6yhkmbSkHtJ9ONMy63oQtm4KRHvHqyom0boRk4vjdZp4ws9MpbUUVQmx5Z/CO+XekAQnyt9xqJDaKtK7Vpk800NjR2nHD9TdIKZMk2X2P3Q866P2x2riYqa8AUKyHEYWd8Bc//4WUUibxnvvs/fFjj4uRcLEmaFpCO/egSK8sdi6s+mZnffOVtsewvA5jbD4svhoGV2bTeJOhVXZMMBj8+dM+P2zEcJVvSUuz2bz1ltsWLLyN2AvQCBC4NhOauxC16z51sW7dutkXzH7s0ceCIGh32p+b9dkxI8ZKlXEusS1dBUDQbC76zW8ffnhpEASdMPzMabMmjhybcMLl4D0lsT06nRP6EUlDWHPSC5i/BwiKZKR9d0uclZ8oYWBfOwsTfDQumH3BPXfd09/fX2pHSinlP/3TB4848h8Hhg0XAgAJEqmVEGnsQ8XKPYPz+StDCAJY8urVax544IE3Xn+jv7+/1WrNOHTGXffetcsuwxNO06CcD1AGCOZdP++aK68O+pqjR4/2fX/Dhg0Adp0yedHvF+82bqzMNsoXO4XtkdoWooom2h1RrisVAzL+CGtbhz0pQ1mu7UdVLGGCB3/Fi89/6qRPD+0cMlYomTmKoiSJs2UtMEOAVV6Z8ibz/DEX2VUiCAgQ+Q0/DeT33W/f+Qvn77X7XiZ+AID1mzZ84XOff+nlFxt+kK7ze57Xarev+ff/c9aXzuxwWxFB3yxsEFQPzIxPF+mhwh7dVQBSaUDRiy3p9aWr7KuSQDap77LvX3rzz25u9vf13oVZ9O4KNlBKzVGjRp1/wfl7771PGLWhsj5MRBDEG9dv+tWv73zxhRcbjUY6KSGiVqt19Mc+On/BfL/hqZmzOqLjsviOYuuKgi+zoXTfz9ki9ew/rCVJvSHDH9TogfE03ZGwx557cO2eJ7uY3qY66BJCbN+x45qrr43iiEiQlk/lVLEYvuc3GkVWKkmSyVMmXXXV3GajEXNkNlgt4+oprClkFQV0apfeluI4wW2pnrNFp+zbE1q95Eu4XUoayQClBGoalqbf07azTCYR5StnSAgMIQSEILAQwqv+uVgAURSed8G5++6zb4fb6R0PdoLAlDZ9nSrDTeNQBQVKmSL9XRHm3MGYcOp8rlI0AwPno7SQ58luDIiiaPTYMbtNmiSISPVuWUYGBBMTETHl7AFzGtylM5BNmzZuWLc+CIKqvpixedNmA1u49Lts+qWw1sUsGOOziGhyk5NvTbTYK41eDZraN+tnxaWbBMe6jFaiKDrsA4fNu37e7rtPYU7TzgCYIPJkalFdOzzMumtmZoCJvMF3tlx77bV3/urOKh4Q0Ssvv6KSzx6EGnyNNc8FMQtSbKtgEEQFQor6aZPZkmQVNfM6jujTYH4vfjgVDYKQzi0SANJV4qBx6WVz3rf3+0JEacIs3ydBdoaSHKEzAJkTwZs4YeKlP7h0yZIlG9ZvUFsoVF9Zj/1NxbkqL1px30yUGXQv30wtj747yLVbzTXHU9dZ01VRsLM1A5LMmVGpMPPw4cP23GvPBAlni8LpH2W1QawX6H9Jcc3MTJKjCPHIESNHjR5lTABVSaScMWOG2mThHE458jEXWPSKtaZCGo4WyBLWpW6MUMfqvtLKO69tSM2POooQYnDL4F+XPuLBa1IQUKOBRgO+/hek9ykIqBHA1/4CddHIAIIG/IcfXrrq1dd837e7i6No0qRJJ554QoJIR15aL4pQZNGzzVX00S90W6L9gkZ2y0/3enja7mhomWu975o5oeGc63WCrZmdUYjE5T+Yu2PH0OGHf4A810aK1NdmuyRSuyaB0jYrCSZCEsVPPvnUDdffEIeR8Ex1T5IkiuNvffubu++6hwqB9DHajq2XULA6CMzWKfU1Lj/d5SZLymJuVqwitNGNjbdbV2QXd+F53pYtg9/9znf6+vs98jg7VCf0oxzIGJmxh8CShPIslO1EZJlwO+wEjYbX8Dk3QUmcJDKJ42jEyBEXX3rxGV8+w9gSWeMUFRHqx2gOuSCgCvezCa+vG3Q9hNLxcAZkgBtFVIgJcpUcPXpkFEdR5DAIyB0jERF57VYHQD5lTQwYe5jZ/1Q4ayJqBk2iYgeRlHLylMnjx48/7PBDPvu5z00/eEYHHWUSqWLGYEuby8e6Rw1LuNW0F+nLOpxzayOMhcv4ODGoKhkM0Y5t2+bOvfrJ/35SCJHnhFOygdLwJT+pxMxJkrz22mtGUxUMqCzZAVXmJEl2GbHL4gcWT917H58aDNnhmLTsi/5y5SrxMiZGvaiCcy6dOnPqcJGgrzI7VU33yH8YDAN8eK1Om9MEDQSBmYiRbiRNNQCAkGDE8stfPmPJn5f09f0duaO8bN+542sXfv2qy+eG6JS5mNkEqp1LFtCMJIdXd2pGXb5WCwNlBjiJ2HVa24vsOwsVOeLMYjNkuoUfak8cEMB/8pmnTp912pYtg81mU2/BuWOu2Eqab+lNr5l5aGjoQx85asH8+buM2CVhc3Xafnd5lXilnEhDieIVyxZxqiyHBi8kyYwBgmEfzHNGO/bT3kuVV9BevmG+mwlAgOAvf1166aWXPbd8hZTFvoreDREzDx8+/JOnnHT5D74/ZuxYK+Mm0n57ntCwlhahGsF1WhH9QvmAbKXGiltNS2cAdIl26mbXDrkAoJ+h0bBEgGDrzq1L/vTnp595emhHq+E3svN52cbC9BWk6VfkUSozsuzQlN2n/PM//9P0g6YnkEn23hq9lBhQL/g1pRcZtYmQLcjU8MruuMo+1khQvcbICkuqY0JAA5UJta5FIomhjleWGKCTXkfDdrMGtuqpjXxvwpcdUXLz1qB+FXv1ONXuSQeox0ZV1wdjqFdIobpTPZsr7QlUneSPsn2yigdkvanCVvQqbG2EqwRRG0ixbTQFzl5XY8G5+3PC/D3lPcRR0IbN7PAZuvvV0a6xIV0jPSfOqm4VcFXdtF72n46WzlidmYYs6OKvS649QmfjerGpXwNpj8o5b8oPM2WaZ5gXuCS07BgrgaUrQaQTTeRbRiQ5aF1uLZ+ROcbq6liUkxC2kjolqEqm9EEa0iTY5IdR0dmXISiwRF4B6Bf6n1Pg7CKs1S77q+iWDcsRk0DFjkSbscbAbFWo8sxGRbgoaEtfjRIY9lqnqVMFqzw8LEm3DYAOY/gqw2+pT5cvlDD7KuSeOtxRllSRxknZHq2zBlP4urz70rtIUcFOZ7G9BWoloGYgvQC8BydXXaVEB1N3q+SibMV69VH5YIpQRBFaMFCdZ4Ulg85ebMtj1LUltIxYZYPKfDsHa+ulfW30qF1XUl9S9uYKYTfqNLIGmO0/kb/iw6pYTNkNGwKLCijTq4ocegu6OOvErRkFYPKsapgGnjakU4ecCpdfa24ZVhHluN6JpSwf1Nb6Kxa0JUFjfkkKZMVLVWyMdXjn4PXRGuw05NHuy6hVpV42VihLIVyyWKvNhYA609FCWK9Q7mpDDfyqSo2S2Y0b167GHZv4erGc7xayCuY9uAoAKBKi6rVBpejKNiAOA1dllKtQVwDCmhjbkM54wyXa0qjoxEEXRqkdcDN6qapljM5oQQeuknqjTe31NMUZh6w5fbSG4XMaOMM4uLrXrX9xeMFwA877OvXrTZDdjn7TMBoWOerq2vBw2SsdZ6OuEx9JQH5AuuCGYeJtZ+s0fLYqCIbiq3pHprJ9hoM1utDbty1773Jql3rrUcNaoyMnKaqNpIP9OZgEyltcqlqpilKqDY4yzSrMtfbDsP60Ug8M6wGT4r0m8W2joUREsEPCrI6KulUajFr+5Y/UK4Py3o12bU037ne18si8iJoKqKe2t+xuwXXfY1Oq3EKJwYaVt1tDdXhuY6LD2JpkXDifplW1VGgmkaUoyGnCDCScwY+BObQDCBqkvuXdOAZS12NVebe1DPwzPKpNh9Ga09S8pyiodFLDPQ/QvaWh+IZcWPzXjyOrc2vF+ULtkTmqcjtuG11VqwZDo26NsDu9tDMGq9IGq8fsEGcZeakZovIR9bw/x++X1HgFqwVRfqQrRPcB1HuF/NotN85iqKzhw6pMro6ngZI2rhKGzirp8BXCak9c/imMY/JQsQpMrjgcY8Ud4zCmVGrRNdIwhmSJXuHStSjLrKVXF65dZShTShfzKuFwGXrThVi9FJEI8hOohneUJLv4AKeN60ZHoXPRhVCXUkOv3oshMb15r56Q6eFpsfOw/Ik87JT5AZvyD7kZRrAqOBPWMlO5okz5bMlmkSYqVzF1ucoUGLjpF049qAHTL+wWdHhby+2nVrPSaC0vpSNK6cCzX1GyrIrjkJ6BX4WWaFmO2pjKbq1eTmvvlDq1m0W3AK/r6KrHa5fC5+k/4qzaLkdB1osN8q+ln62pj0DK2JiEKDs6d3dVrrjKQxo0Vbrl1NcqtA2Aqt4tp1oZmymia5JeQq/8uprMXxYTMVFKKtg/2qlXc6DugrfBzONUthbbQ60ZvDMS1V2isJZwncBGsR2h/dTVpjIvxokuFYVnmTfNQea/IaNJk9A3yomKLKmTcNJ6m2t9Uf3aptYWTPtOGWeTHKplS13c+BsCVPUV1YxJH0J75UY+NPViYmlNgGThA5zW3yao0attZGueCnY0aA+mwta7U/+o+F1Xp0rZ/QImYrCI3tUflGdOVZP8iqULq49SiK0TK+UnZz+nILn0kwMFsP5ZY+6dAArMZf2rTmaVXnztoprQ26ynvgGjbkorWCp7CJ3ihaHXX9CqZkKSSkgKlGc0+mttKiKHgpM5J7J3ViVWZtsilgMDEyHL4ttN2VhVyaZgGD+EYHBLV00ntlohA8AYi4GkyHcBV8Gkj4rfktQQMpSltNuy6xE7APnbAzivniuhexE47Y60s6sFAuoXn5S86/OG/E4Gm1tb9ZLy0leUJyLlujZuCisyIE3sMxbqr0Ep/XoludisrqnDkQpOlE+r6qyHUuzaL34O6X9KVhzTY18xMFUA4tRT11BNliVIz/tnG+3L8Kx1iWz650KFuzE+rcVpm6Vf4yhYrX7DJGuWNdUiVudYmUCqESYmBac+UXOa3I1dHTzlxzrSUnjf/w/KLTY4m9zBDgAAAABJRU5ErkJggg=="
            }],
            "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
          }],
          "title" : "2. What you need to know before you take Biktarvy 50 mg/200 mg/25 mg film-coated tablets",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "2. What you need to know before you take Biktarvy 50 mg/200 mg/25 mg film-coated tablets"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>Do not take Biktarvy</strong></p><ul><li>If you are allergic to bictegravir, emtricitabine, tenofovir alafenamide or any of the other ingredients of this medicine (listed in section 6).</li><li><p>If you are currently taking any of the following medicines:</p><ul><li>rifampicin used to treat some bacterial infections such as tuberculosis</li><li><span class=\"contra-indication-hypericum highlight mock-lib\">St. John’s wort (Hypericum perforatum), a herbal remedy used for depression and anxiety, or products that contain it.</span></li></ul></li><li><p>If any of these apply to you, <strong>do not take Biktarvy and tell your doctor immediately.</strong></p></li></ul><p><strong>Warnings and precautions</strong></p><p><strong>Talk to your doctor before taking Biktarvy:</strong></p><ul><li><span class=\"liver collapse mock-lib2\">If you have liver problems or a history of liver disease, including hepatitis. Patients with liver disease including chronic hepatitis B or C, who are treated with antiretrovirals, have a higher risk of severe and potentially fatal liver complications. If you have hepatitis B infection, your doctor will carefully consider the best treatment regimen for you.</span></li><li><p><span class=\"hepatitisB collapse mock-lib2\">If you have hepatitis B infection. Liver problems may become worse after you stop taking Biktarvy</span></p></li><li><p>Do not stop taking Biktarvy if you have hepatitis B. Talk to your doctor first. For more details, see section 3, Do not stop taking Biktarvy.</p></li><li><p>If you have had kidney disease or if tests have shown problems with your kidneys. Your doctor may order blood tests to monitor how your kidneys work when starting and during treatment with Biktarvy.</p></li></ul><p><strong>While you are taking Biktarvy</strong></p><p>Once you start taking Biktarvy, look out for:</p><ul><li>Signs of inflammation or infection</li><li>Joint pain, stiffness or bone problems</li></ul><p><strong>If you notice any of these symptoms, tell your doctor immediately. For more information see section 4, Possible side effects.</strong></p><p>There is a possibility that you may experience kidney problems when taking Biktarvy over a long period of time (see Warnings and precautions).</p><p>This medicine is not a cure for HIV infection. While taking Biktarvy you may still develop infections or other illnesses associated with HIV infection.</p><p><strong>Children and adolescents</strong></p><p>Do not give this medicine to children under 2 years of age, or weighing less than 14 kg regardless of age. The use of Biktarvy in children under 2 years of age, or weighing less than 14 kg has not yet been studied. For children and adolescents who weigh 25 kg or more, Biktarvy 50 mg/200 mg/25 mg film-coated tablets are available.</p><p>Loss of bone mass has been reported in some children from 3 to less than 12 years of age who received one of the medicinal products (tenofovir alafenamide) contained in Biktarvy. The effects on long term bone health and future fracture risk in children is uncertain. Your doctor will monitor your child’s bone health as needed.</p><p><strong>Other medicines and Biktarvy</strong></p><p>Tell your doctor or pharmacist if you are taking, have recently taken or might take any other medicines. Biktarvy may interact with other medicines. As a result, the amounts of Biktarvy or other medicines in your blood may change. This may stop your medicines from working properly, or may make any side effects worse. In some cases, your doctor may need to adjust your dose or check your blood levels.</p><p><strong>Medicines that must never be taken with Biktarvy:</strong></p><ul><li>rifampicin used to treat some bacterial infections such as tuberculosis</li><li>St. John’s wort (Hypericum perforatum), a herbal remedy used for depression and anxiety, or products that contain it.</li><li>If you are taking any of these medicines, do not take Biktarvy and tell your doctor immediately.</li></ul><p><strong>Talk to your doctor if you are taking:</strong></p><ul><li>medicines used for treating HIV and/or hepatitis B, containing:<ul><li>adefovir dipivoxil, atazanavir, bictegravir, emtricitabine, lamivudine, tenofovir alafenamide, or tenofovir disoproxil</li></ul></li><li>antibiotics used to treat bacterial infections, containing:<ul><li>azithromycin, clarithromycin, rifabutin or rifapentine</li></ul></li><li>anticonvulsants used to treat epilepsy, containing:<ul><li>carbamazepine, oxcarbazepine, phenobarbital or phenytoin</li></ul></li><li>immunosuppressants used to control your body’s immune response after a transplant, containing ciclosporin</li><li><p>ulcer-healing medicines containing sucralfate</p></li><li><p>Tell your doctor if you are taking any of these medicines. Do not stop your treatment without contacting your doctor.</p></li></ul><p><strong>Get advice from a doctor or pharmacist if you are taking:</strong></p><ul><li>antacids to treat stomach ulcers, heartburn, or acid reflux, containing aluminium and/or magnesium hydroxide</li><li>mineral supplements or vitamins containing magnesium or iron</li><li>Get advice from your doctor or pharmacist before taking Biktarvy if you are taking any of these medicines.</li></ul><p>Antacids and magnesium supplements: you will need to take Biktarvy at least 2 hours before antacids or supplements containing aluminium and/or magnesium. Or you can take Biktarvy with food at least 2 hours after.</p><p>Iron supplements: you will need to take Biktarvy at least 2 hours before iron supplements, or you can take them together with food.</p><div class=\"pregnancyCategory highlight mock-lib2\"><p><strong>Pregnancy and breast-feeding</strong></p><ul><li>If you are pregnant or breast-feeding, think you may be pregnant or are planning to have a baby, ask your doctor or pharmacist for advice before taking this medicine.</li><li>Tell your doctor immediately if you become pregnant and ask about the potential benefits and risks of your antiretroviral therapy to you and your child.</li></ul><p>If you have taken Biktarvy during your pregnancy, your doctor may request regular blood tests and other diagnostic tests to monitor the development of your child. In children whose mothers took nucleoside reverse transcriptase inhibitors (NRTIs) during pregnancy, the benefit from the protection against HIV outweighed the risk of side effects.</p><div class=\"breastfeedingCategory highlight mock-lib2\"><p><strong>Do not breast-feed during treatment with Biktarvy.</strong> This is because some of the active substances in this medicine pass into human breast milk. Breast-feeding is not recommended in women living with HIV because HIV infection can be passed on to the baby in breast milk. If you are breast-feeding, or thinking about breast-feeding, you should discuss it with your doctor as soon as possible.</p></div></div><p><strong>Driving and using machines</strong></p><p>Biktarvy can cause dizziness. If you feel dizzy when taking Biktarvy, do not drive or ride a bicycle and do not use any tools or machines.</p><p><strong>Biktarvy contains sodium</strong></p><p>This medicine contains less than 1 mmol sodium (23 mg) per tablet, that is to say essentially ‘sodium-free’.</p><img alt=\"How to take medication\" class=\"mock-lib\" src=\"https://github.com/hl7-eu/gravitate-health/blob/master/input/images/test-image.jpeg?raw=true\"/></div>"
          }
        },
        {
          "extension" : [{
            "extension" : [{
              "url" : "type",
              "valueCodeableConcept" : {
                "coding" : [{
                  "system" : "http://hl7.eu/fhir/ig/gravitate-health/CodeSystem/type-of-data-cs",
                  "code" : "PCT",
                  "display" : "Pictogram"
                }]
              }
            },
            {
              "url" : "concept",
              "valueUrl" : "https://www.aidsmap.com/sites/default/files/styles/medium/public/2019-07/Biktarvy.png?itok=Cw7BoVdg"
            }],
            "url" : "http://hl7.eu/fhir/ig/gravitate-health/StructureDefinition/HtmlElementLink"
          }],
          "title" : "3. How to take Biktarvy 50 mg/200 mg/25 mg film-coated tablets",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "3. How to take Biktarvy 50 mg/200 mg/25 mg film-coated tablets"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Always take this medicine exactly as your doctor has told you. Check with your doctor or pharmacist if you are not sure.</p><p>There are two strengths of Biktarvy tablets. Your doctor will prescribe the appropriate tablet for your age and weight.</p><p><strong>The recommended dose is:</strong></p><p>Children 2 years of age and older, who weigh at least 14 kg but less than 25 kg: one tablet each day with or without food (one 30 mg/120 mg/15 mg tablet).</p><p>Due to the bitter taste, it is recommended not to chew or crush the tablet. If you have difficulty swallowing the tablet whole, you can split it in half. Take both halves of the tablet one after the other to get the full dose. Do not store the split tablet.</p><p>The score line on the tablet is only there to help you break the tablet if your child has difficulty swallowing it whole.</p><p>The 90-day multipack contains three 30-day packs together.</p><ul><li>Get advice from a doctor or pharmacist if you are taking:</li><li>antacids to treat stomach ulcers, heartburn, or acid reflux, containing aluminium and/or magnesium hydroxide</li><li>mineral supplements or vitamins containing magnesium or iron</li><li>See section 2 for more information on taking these medicines with Biktarvy.</li></ul><p>If you are on dialysis, take your daily dose of Biktarvy following completion of dialysis.</p><p><strong>If you take more Biktarvy than you should</strong></p><p>If you take more than the recommended dose of Biktarvy you may be at higher risk of side effects of this medicine (see section 4, Possible side effects). Contact your doctor or nearest emergency department immediately for advice. Keep or take the tablet bottle or carton with you so that you can easily describe what you have taken.</p><p><strong>If you forget to take Biktarvy</strong></p><p>It is important not to miss a dose of Biktarvy.</p><p>If you miss a dose:</p><ul><li>If you notice within 18 hours of the time you usually take Biktarvy, you must take the tablet as soon as possible. Then take the next dose as usual.</li><li>If you notice 18 hours or more after the time you usually take Biktarvy, then do not take the missed dose. Wait and take the next dose at your usual time.</li></ul><p>If you vomit less than 1 hour after taking Biktarvy, take another tablet. If you vomit more than 1 hour after taking Biktarvy you do not need to take another tablet until your next regularly scheduled tablet.</p><p><strong>Do not stop taking Biktarvy</strong></p><p>Do not stop taking Biktarvy without talking to your doctor. Stopping Biktarvy can seriously affect how future treatment works. If Biktarvy is stopped for any reason, speak to your doctor before you restart taking Biktarvy tablets.</p><p>When your supply of Biktarvy starts to run low, get more from your doctor or pharmacist. This is very important because the amount of virus may start to increase if the medicine is stopped for even a short time. The disease may then become harder to treat.</p><p>If you have both HIV infection and hepatitis B, it is especially important not to stop your Biktarvy treatment without talking to your doctor first. You may require blood tests for several months after stopping treatment. In some patients with advanced liver disease or cirrhosis, stopping treatment is not recommended as this may lead to worsening of your hepatitis, which may be life-threatening.</p><ul><li>Tell your doctor immediately about new or unusual symptoms after you stop treatment, particularly symptoms you associate with hepatitis B infection. If you have any further questions on the use of this medicine, ask your doctor or pharmacist.</li></ul></div>"
          }
        },
        {
          "title" : "4. Possible side effects",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "4. Possible side effects"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Like all medicines, this medicine can cause side effects, although not everybody gets them.</p><p><strong>Possible side effects: tell a doctor immediately</strong></p><ul><li>Any signs of inflammation or infection. In some patients with advanced HIV infection (AIDS) and a history of opportunistic infections (infections that occur in people with a weak immune system), signs and symptoms of inflammation from previous infections may occur soon after HIV treatment is started. It is thought that these symptoms are due to an improvement in the body’s immune response, enabling the body to fight infections that may have been present with no obvious symptoms.</li><li>Autoimmune disorders, when the immune system attacks healthy body tissue, may also occur after you start taking medicines for HIV infection. Autoimmune disorders may occur many months after the start of treatment. Look out for any symptoms of infection or other symptoms such as:<ul><li>muscle weakness</li><li>weakness beginning in the hands and feet and moving up towards the trunk of the body</li><li>palpitations, tremor or hyperactivity</li></ul></li><li>If you notice these or any symptoms of inflammation or infection, tell your doctor immediately.</li></ul><p><strong>Common side effects</strong> (may affect up to 1 in 10 people)</p><ul><li>depression</li><li>abnormal dreams</li><li>headache</li><li>dizziness</li><li>diarrhoea</li><li>feeling sick (nausea)</li><li>tiredness (fatigue)</li></ul><p><strong>Uncommon side effects</strong></p><p>(may affect up to 1 in 100 people)</p><ul><li>anaemia</li><li>vomiting</li><li>stomach pain</li><li>problems with digestion resulting in discomfort after meals (dyspepsia)</li><li>wind (flatulence)</li><li>swelling of the face, lips, tongue or throat (angioedema)</li><li>itching (pruritus)</li><li>rash</li><li>hives (urticaria)</li><li>joint pain (arthralgia)</li><li>suicidal thoughts and suicide attempt (particularly in patients who have had depression or mental health problems before)</li><li>anxiety</li><li>sleep disorders Blood tests may also show:</li><li>higher levels of substances called bilirubin and/or serum creatinine in the blood</li></ul><p><strong>Rare side effects</strong></p><p>(may affect up to 1 in 1000 people)</p><ul><li>Stevens-Johnson syndrome (SJS) is a serious life-threatening condition which usually starts with flu- like symptoms. A few days later other symptoms appear including:<ul><li>Painful red or purple skin that looks burned and peels off</li><li>Blisters on your skin, mouth, nose, and genitals</li><li>Red, painful, watery eyes</li></ul></li><li>If you have any of these symptoms, stop your medicine immediately and tell your doctor straight away.</li><li>If any of the side effects get serious, tell your doctor.</li></ul><p><strong>Other effects that may be seen during HIV treatment</strong></p><p>The frequency of the following side effects is not known (frequency cannot be estimated from the available data).</p><ul><li>Bone problems. Some patients taking combination antiretroviral medicines such as Biktarvy may develop a bone disease called osteonecrosis (death of bone tissue caused by loss of blood supply to the bone). Taking this type of medicine for a long time, taking corticosteroids, drinking alcohol, having a very weak immune system, and being overweight, may be some of the many risk factors for developing this disease. Signs of osteonecrosis are:<ul><li>joint stiffness</li><li>joint aches and pains (especially of the hip, knee and shoulder)</li><li>difficulty with movement</li></ul></li><li>If you notice any of these symptoms tell your doctor.</li></ul><p>During HIV therapy there may be an increase in weight and in levels of blood lipids and glucose. This is partly linked to restored health and life style, and in the case of blood lipids sometimes to the HIV medicines themselves. Your doctor will test for these changes.</p><p><strong>Reporting of side effects</strong> If you get any side effects, talk to your doctor or pharmacist. This includes any possible side effects not listed in this leaflet. You can also report side effects directly via the national reporting system listed in Appendix V. By reporting side effects you can help provide more information on the safety of this medicine.</p></div>"
          }
        },
        {
          "title" : "5. How to store Biktarvy 50 mg/200 mg/25 mg film-coated tablets",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "5. How to store Biktarvy 50 mg/200 mg/25 mg film-coated tablets"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p>Keep this medicine out of the sight and reach of children.</p><p>Do not use this medicine after the expiry date which is stated on the carton and bottle or blister strips after {EXP}. The expiry date refers to the last day of that month.</p><p>Store in the original package in order to protect from moisture. Keep the bottle tightly closed. Do not use if the seal over the bottle opening is broken or missing.</p><p>Do not throw away any medicines via wastewater or household waste. Ask your pharmacist how to throw away medicines you no longer use. These measures will help protect the environment.</p></div>"
          }
        },
        {
          "title" : "6. Contents of the pack and other information",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi/",
              "code" : "100000155538"
            }],
            "text" : "6. Contents of the pack and other information"
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><p><strong>What Biktarvy contains</strong></p><p>The active substances are bictegravir, emtricitabine and tenofovir alafenamide. Each Biktarvy tablet contains bictegravir sodium equivalent to 30 mg of bictegravir, 120 mg of emtricitabine and tenofovir alafenamide fumarate equivalent to 15 mg of tenofovir alafenamide.</p><p><strong>The other ingredients are</strong><em>Tablet core</em>Microcrystalline cellulose (E460), croscarmellose sodium (E468), magnesium stearate (E470b).</p><p><em>Film-coating</em>Polyvinyl alcohol (E203), titanium dioxide (E171), macrogol (E1521), talc (E553b), iron oxide red (E172), iron oxide black (E172).</p><p><strong>What Biktarvy looks like and contents of the pack</strong></p><p>Biktarvy 30 mg/120 mg/15 mg film-coated tablets are pink, capsule-shaped, film-coated tablets, debossed with “BVY” on one side and a score line on the other side of the tablet.</p><p>The tablets are supplied in a bottle. Not all pack sizes may be marketed.</p><p>Biktarvy comes in bottles of 30 tablets and in packs made up of 3 bottles, each containing 30 tablets. Each bottle contains a silica gel desiccant that must be kept in the bottle to help protect your tablets. The silica gel desiccant is contained in a separate sachet or canister and should not be swallowed.</p></div>"
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ClinicalUseDefinition/cud-d79af6e660f456c6c7091803d6bd1a92",
    "resource" : {
      "resourceType" : "ClinicalUseDefinition",
      "id" : "cud-d79af6e660f456c6c7091803d6bd1a92",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ClinicalUseDefinition-contraindication-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ClinicalUseDefinition_cud-d79af6e660f456c6c7091803d6bd1a92\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalUseDefinition cud-d79af6e660f456c6c7091803d6bd1a92</b></p><a name=\"cud-d79af6e660f456c6c7091803d6bd1a92\"> </a><a name=\"hccud-d79af6e660f456c6c7091803d6bd1a92\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ClinicalUseDefinition-contraindication-uv-epi.html\">ClinicalUseDefinition Contraindication (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/rmswi/#/</code>/pregnancy (use: official, )</p><p><b>type</b>: Contraindication</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><blockquote><p><b>contraindication</b></p><h3>DiseaseSymptomProcedures</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/mdr nan}\">nan</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/rmswi/#/",
        "value" : "pregnancy"
      }],
      "type" : "contraindication",
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "contraindication" : {
        "diseaseSymptomProcedure" : {
          "concept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/mdr",
              "code" : "nan",
              "display" : "nan"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-bictegravirsodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-bictegravirsodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-bictegravirsodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-bictegravirsodium</b></p><a name=\"ingredient-for-biktarvy-bictegravirsodium\"> </a><a name=\"hcingredient-for-biktarvy-bictegravirsodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/4L5MP1Y7W7 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 4L5MP1Y7W7}\">BICTEGRAVIR SODIUM</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>50 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "4L5MP1Y7W7"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "4L5MP1Y7W7",
              "display" : "BICTEGRAVIR SODIUM"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 50,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-emtricitabine",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-emtricitabine",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-emtricitabine\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-emtricitabine</b></p><a name=\"ingredient-for-biktarvy-emtricitabine\"> </a><a name=\"hcingredient-for-biktarvy-emtricitabine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/G70B4ETF4S (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta G70B4ETF4S}\">Emtricitabine</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>200 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "G70B4ETF4S"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "G70B4ETF4S",
              "display" : "Emtricitabine"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 200,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-tenofoviralafenamide",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-tenofoviralafenamide",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-tenofoviralafenamide\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-tenofoviralafenamide</b></p><a name=\"ingredient-for-biktarvy-tenofoviralafenamide\"> </a><a name=\"hcingredient-for-biktarvy-tenofoviralafenamide\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/EL9943AG5J (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072072}\">Active</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta EL9943AG5J}\">tenofovir alafenamide</span></td></tr></table><h3>Strengths</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Presentation[x]</b></td><td><b>Basis</b></td></tr><tr><td style=\"display: none\">*</td><td>25 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleClass ACTIB}\">active ingredient - basis of strength</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "EL9943AG5J"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072072",
          "display" : "Active"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "EL9943AG5J",
              "display" : "tenofovir alafenamide"
            }]
          }
        },
        "strength" : [{
          "presentationQuantity" : {
            "value" : 25,
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          },
          "basis" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleClass",
              "code" : "ACTIB",
              "display" : "active ingredient - basis of strength"
            }]
          }
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-microcrystallinecellulose",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-microcrystallinecellulose",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-microcrystallinecellulose\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-microcrystallinecellulose</b></p><a name=\"ingredient-for-biktarvy-microcrystallinecellulose\"> </a><a name=\"hcingredient-for-biktarvy-microcrystallinecellulose\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/OP1R32D61U (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta OP1R32D61U}\">Microcrystalline cellulose</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "OP1R32D61U"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "OP1R32D61U",
              "display" : "Microcrystalline cellulose"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-croscarmellosesodium",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-croscarmellosesodium",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-croscarmellosesodium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-croscarmellosesodium</b></p><a name=\"ingredient-for-biktarvy-croscarmellosesodium\"> </a><a name=\"hcingredient-for-biktarvy-croscarmellosesodium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/M28OL1HH48 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta M28OL1HH48}\">Croscarmellose sodium</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "M28OL1HH48"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "M28OL1HH48",
              "display" : "Croscarmellose sodium"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Ingredient/ingredient-for-biktarvy-magnesiumstearate",
    "resource" : {
      "resourceType" : "Ingredient",
      "id" : "ingredient-for-biktarvy-magnesiumstearate",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Ingredient-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Ingredient_ingredient-for-biktarvy-magnesiumstearate\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Ingredient ingredient-for-biktarvy-magnesiumstearate</b></p><a name=\"ingredient-for-biktarvy-magnesiumstearate\"> </a><a name=\"hcingredient-for-biktarvy-magnesiumstearate\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Ingredient-uv-epi.html\">Ingredient (ePI)</a></p></div><p><b>identifier</b>: <code>https://gsrs.ncats.nih.gov/ginas/app/beta</code>/70097M6I30 (use: official, )</p><p><b>status</b>: Active</p><p><b>for</b>: </p><ul><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></li><li><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\">AdministrableProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001; status = active; administrableDoseForm = Tablet; unitOfPresentation = Tablet</a></li></ul><p><b>role</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072082}\">Excipient</span></p><blockquote><p><b>substance</b></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://gsrs.ncats.nih.gov/ginas/app/beta 70097M6I30}\">Magnesium stearate</span></td></tr></table></blockquote></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
        "value" : "70097M6I30"
      },
      "status" : "active",
      "for" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      },
      {
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      },
      {
        "reference" : "AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "role" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072082",
          "display" : "Excipient"
        }]
      },
      "substance" : {
        "code" : {
          "concept" : {
            "coding" : [{
              "system" : "https://gsrs.ncats.nih.gov/ginas/app/beta",
              "code" : "70097M6I30",
              "display" : "Magnesium stearate"
            }]
          }
        }
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/AdministrableProductDefinition/ap-94a96e39cfdcd8b378d12dd4063065f9",
    "resource" : {
      "resourceType" : "AdministrableProductDefinition",
      "id" : "ap-94a96e39cfdcd8b378d12dd4063065f9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/AdministrableProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AdministrableProductDefinition_ap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AdministrableProductDefinition ap-94a96e39cfdcd8b378d12dd4063065f9</b></p><a name=\"ap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><a name=\"hcap-94a96e39cfdcd8b378d12dd4063065f9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-AdministrableProductDefinition-uv-epi.html\">AdministrableProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001</p><p><b>status</b>: Active</p><p><b>formOf</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>administrableDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p><p><b>producedFrom</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></p><blockquote><p><b>routeOfAdministration</b></p><p><b>code</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073619}\">Oral use</span></p><h3>TargetSpecies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000109093}\">Human</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "active",
      "formOf" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "administrableDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      },
      "producedFrom" : [{
        "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
      }],
      "routeOfAdministration" : [{
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073619",
            "display" : "Oral use"
          }]
        },
        "targetSpecies" : [{
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000109093",
              "display" : "Human"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/RegulatedAuthorization/authorization94a96e39cfdcd8b378d12dd4063065f90",
    "resource" : {
      "resourceType" : "RegulatedAuthorization",
      "id" : "authorization94a96e39cfdcd8b378d12dd4063065f90",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RegulatedAuthorization_authorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RegulatedAuthorization authorization94a96e39cfdcd8b378d12dd4063065f90</b></p><a name=\"authorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><a name=\"hcauthorization94a96e39cfdcd8b378d12dd4063065f90\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>subject</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000061}\">Marketing Authorisation</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2018-06-21 13:28:17+0000</p><p><b>holder</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mah-715f8a161ed438d0584510e5b4512caa\">Organization Gilead Sciences Ireland UC</a></p><p><b>regulator</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#Organization_mra-1133a7374c78f1d40f41885344f06a5a\">Organization European Medicines Agency</a></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "subject" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000061",
          "display" : "Marketing Authorisation"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2018-06-21T13:28:17Z",
      "holder" : {
        "reference" : "Organization/mah-715f8a161ed438d0584510e5b4512caa"
      },
      "regulator" : {
        "reference" : "Organization/mra-1133a7374c78f1d40f41885344f06a5a"
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mah-715f8a161ed438d0584510e5b4512caa",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mah-715f8a161ed438d0584510e5b4512caa",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mah-715f8a161ed438d0584510e5b4512caa\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mah-715f8a161ed438d0584510e5b4512caa</b></p><a name=\"mah-715f8a161ed438d0584510e5b4512caa\"> </a><a name=\"hcmah-715f8a161ed438d0584510e5b4512caa\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100008368 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000034}\">Marketing authorisation holder</span></p><p><b>name</b>: Gilead Sciences Ireland UC</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carrigtohill, County Cork, T45 County Cork IR(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100008368"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000034",
          "display" : "Marketing authorisation holder"
        }]
      }],
      "name" : "Gilead Sciences Ireland UC",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carrigtohill, County Cork, T45 County Cork IR",
          "line" : ["Carrigtohill, County Cork, T45"],
          "city" : "County Cork",
          "country" : "IR"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/Organization/mra-1133a7374c78f1d40f41885344f06a5a",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mra-1133a7374c78f1d40f41885344f06a5a",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Organization-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_mra-1133a7374c78f1d40f41885344f06a5a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mra-1133a7374c78f1d40f41885344f06a5a</b></p><a name=\"mra-1133a7374c78f1d40f41885344f06a5a\"> </a><a name=\"hcmra-1133a7374c78f1d40f41885344f06a5a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Organization-uv-epi.html\">Organization (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/omswi</code>/ORG-100013412 (use: official, )</p><p><b>active</b>: true</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 220000000032}\">Medicines Regulatory Authority</span></p><p><b>name</b>: European Medicines Agency</p><h3>Contacts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Address</b></td></tr><tr><td style=\"display: none\">*</td><td>Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL(work)</td></tr></table></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/omswi",
        "value" : "ORG-100013412"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "220000000032",
          "display" : "Medicines Regulatory Authority"
        }]
      }],
      "name" : "European Medicines Agency",
      "contact" : [{
        "address" : {
          "use" : "work",
          "type" : "physical",
          "text" : "Carretera De Martorell 41 61, Poligono Industrial Nord-Est Amsterdam NL",
          "line" : ["Carretera De Martorell 41 61, Poligono Industrial Nord-Est"],
          "city" : "Amsterdam",
          "postalCode" : "1083 HS",
          "country" : "NL"
        }
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-e34e4b65abd3fd8e667db05606cc25a9",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-e34e4b65abd3fd8e667db05606cc25a9",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-e34e4b65abd3fd8e667db05606cc25a9</b></p><a name=\"ppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><a name=\"hcppd-e34e4b65abd3fd8e667db05606cc25a9\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, ), Gtin/07612345678904 (use: official, )</p><p><b>name</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 90</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 90</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      },
      {
        "use" : "official",
        "system" : "https://www.gs1.org/gtin",
        "value" : "07612345678904"
      }],
      "name" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 90",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 90,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/PackagedProductDefinition/ppd-6d93344139a7793e7b9bd0f5e32b6c91",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "ppd-6d93344139a7793e7b9bd0f5e32b6c91",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_ppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition ppd-6d93344139a7793e7b9bd0f5e32b6c91</b></p><a name=\"ppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><a name=\"hcppd-6d93344139a7793e7b9bd0f5e32b6c91\"> </a><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>name</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 30</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000155527}\">Chemical Medicinal Product</span></p><p><b>packageFor</b>: <a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\">MedicinalProductDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001,https://www.who-umc.org/phpid#0xF79CABF272B6A7EEF104DDDA44E827gy; type = Medicinal Product; domain = Human use; status = active; legalStatusOfSupply = Medicinal product subject to medical prescription</a></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">Active</span></p><p><b>statusDate</b>: 2012-02-07 13:28:17+0000</p><blockquote><p><b>packaging</b></p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073498}\">Box</span></p><p><b>quantity</b>: 1</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003529}\">Cardboard</span></p><blockquote><p><b>packaging</b></p><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/654321</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000073504}\">Child-resistant closure</span></p><p><b>quantity</b>: 30</p><p><b>material</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000003222}\">PolyVinyl Chloride</span></p><blockquote><p><b>containedItem</b></p><h3>Items</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundlepackageleaflet-da-94a96e39cfdcd8b378d12dd4063065f9.html#ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\">ManufacturedItemDefinition: identifier = https://spor.ema.europa.eu/pmswi#EU/1/18/1289/001 (use: official, ); status = active; manufacturedDoseForm = Tablet; unitOfPresentation = Tablet</a></td></tr></table></blockquote></blockquote></blockquote></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "name" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion 30",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000155527",
          "display" : "Chemical Medicinal Product"
        }]
      },
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949"
      }],
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "statusDate" : "2012-02-07T13:28:17Z",
      "packaging" : {
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "100000073498",
            "display" : "Box"
          }]
        },
        "quantity" : 1,
        "material" : [{
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/rmswi",
            "code" : "200000003529",
            "display" : "Cardboard"
          }]
        }],
        "packaging" : [{
          "identifier" : [{
            "system" : "https://spor.ema.europa.eu/pmswi",
            "value" : "654321"
          }],
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "100000073504",
              "display" : "Child-resistant closure"
            }]
          },
          "quantity" : 30,
          "material" : [{
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/rmswi",
              "code" : "200000003222",
              "display" : "PolyVinyl Chloride"
            }]
          }],
          "containedItem" : [{
            "item" : {
              "reference" : {
                "reference" : "ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9"
              }
            }
          }]
        }]
      }
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/MedicinalProductDefinition/mp2a9c4333cfd126f2e7b73ad3cafd6949",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "mp2a9c4333cfd126f2e7b73ad3cafd6949",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_mp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition mp2a9c4333cfd126f2e7b73ad3cafd6949</b></p><a name=\"mp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><a name=\"hcmp2a9c4333cfd126f2e7b73ad3cafd6949\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001, <code>https://www.who-umc.org/phpid</code>/0xF79CABF272B6A7EEF104DDDA44E827gy</p><p><b>type</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-type MedicinalProduct}\">Medicinal Product</span></p><p><b>domain</b>: <span title=\"Codes:{http://hl7.org/fhir/medicinal-product-domain Human}\">Human use</span></p><p><b>status</b>: <span title=\"Codes:{http://hl7.org/fhir/publication-status active}\">active</span></p><p><b>legalStatusOfSupply</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 100000072084}\">Medicinal product subject to medical prescription</span></p><blockquote><p><b>name</b></p><p><b>productName</b>: Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000001}\">Full name</span></p><blockquote><p><b>part</b></p><p><b>part</b>: Biktarvy</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000002}\">Invented name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: bictegravir/emtricitabine/tenofovir alafenamide</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000003}\">Scientific name part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: 50 mg/200 mg/25 mg</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000004}\">Strength part</span></p></blockquote><blockquote><p><b>part</b></p><p><b>part</b>: film-coated tablets</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/lists/220000000000 220000000005}\">Pharmaceutical dose form part</span></p></blockquote><h3>Usages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Country</b></td><td><b>Jurisdiction</b></td><td><b>Language</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:iso:std:iso:3166 GBR}\">United Kingdom</span></td><td><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></td></tr></table></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      },
      {
        "system" : "https://www.who-umc.org/phpid",
        "value" : "0xF79CABF272B6A7EEF104DDDA44E827gy"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-type",
          "code" : "MedicinalProduct",
          "display" : "Medicinal Product"
        }]
      },
      "domain" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/medicinal-product-domain",
          "code" : "Human",
          "display" : "Human use"
        }]
      },
      "status" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/publication-status",
          "code" : "active",
          "display" : "active"
        }]
      },
      "legalStatusOfSupply" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "100000072084",
          "display" : "Medicinal product subject to medical prescription"
        }]
      },
      "name" : [{
        "productName" : "Biktarvy 50 mg/200 mg/25 mg film-coated tabletsmg powder for concentrate for solution for infusion",
        "type" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/lists/220000000000",
            "code" : "220000000001",
            "display" : "Full name"
          }]
        },
        "part" : [{
          "part" : "Biktarvy",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000002",
              "display" : "Invented name part"
            }]
          }
        },
        {
          "part" : "bictegravir/emtricitabine/tenofovir alafenamide",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000003",
              "display" : "Scientific name part"
            }]
          }
        },
        {
          "part" : "50 mg/200 mg/25 mg",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000004",
              "display" : "Strength part"
            }]
          }
        },
        {
          "part" : "film-coated tablets",
          "type" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/lists/220000000000",
              "code" : "220000000005",
              "display" : "Pharmaceutical dose form part"
            }]
          }
        }],
        "usage" : [{
          "country" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "jurisdiction" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "GBR",
              "display" : "United Kingdom"
            }]
          },
          "language" : {
            "coding" : [{
              "system" : "urn:ietf:bcp:47",
              "code" : "en",
              "display" : "English"
            }]
          }
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://hl7.eu/fhir/ig/gravitate-health/ManufacturedItemDefinition/mid-94a96e39cfdcd8b378d12dd4063065f9",
    "resource" : {
      "resourceType" : "ManufacturedItemDefinition",
      "id" : "mid-94a96e39cfdcd8b378d12dd4063065f9",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/ManufacturedItemDefinition-uv-epi"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ManufacturedItemDefinition_mid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ManufacturedItemDefinition mid-94a96e39cfdcd8b378d12dd4063065f9</b></p><a name=\"mid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><a name=\"hcmid-94a96e39cfdcd8b378d12dd4063065f9\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-ManufacturedItemDefinition-uv-epi.html\">ManufacturedItemDefinition (ePI)</a></p></div><p><b>identifier</b>: <code>https://spor.ema.europa.eu/pmswi</code>/EU/1/18/1289/001 (use: official, )</p><p><b>status</b>: Active</p><p><b>manufacturedDoseForm</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi/ 100000073664}\">Tablet</span></p><p><b>unitOfPresentation</b>: <span title=\"Codes:{https://spor.ema.europa.eu/rmswi 200000002152}\">Tablet</span></p></div>"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "https://spor.ema.europa.eu/pmswi",
        "value" : "EU/1/18/1289/001"
      }],
      "status" : "active",
      "manufacturedDoseForm" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi/",
          "code" : "100000073664",
          "display" : "Tablet"
        }]
      },
      "unitOfPresentation" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/rmswi",
          "code" : "200000002152",
          "display" : "Tablet"
        }]
      }
    }
  }]
}

```
