# FK47224 - Gravitate Health FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FK47224**

## Example Bundle: FK47224

**Composition category:**

**Composition status:**final

### Indlægsseddel: Information til patienten

 

## Indlægsseddel: Information til patienten

### XELJANZ 5 mg filmovertrukne tabletter

**XELJANZ 10 mg filmovertrukne tabletter**

tofacitinib

### Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger.

* Gem indlægssedlen. Du kan få brug for at læse den igen.
* Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide.
* Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give lægemidlet til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.
* Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se [afsnit 4](#Section4).

Udover denne indlægsseddel vil lægen også give dig et patientkort, som indeholder vigtige sikkerhedsoplysninger, som du skal være opmærksom på, før du tager XELJANZ, og så længe du er i behandling med XELJANZ. Du skal altid have dette patientkort på dig.

Se den nyeste indlægsseddel på
[www.indlaegsseddel.dk](https://www.indlaegsseddel.dk)

### Oversigt over indlægssedlen

1. Virkning og anvendelse
1. Det skal du vide, før du begynder at tage XELJANZ
1. Sådan skal du tage XELJANZ
1. Bivirkninger
1. Opbevaring
1. Pakningsstørrelser og yderligere oplysninger


#### 1. Virkning og anvendelse

 

 

## 1. Virkning og anvendelse

XELJANZ er et lægemiddel, der indeholder det aktive stof tofacitinib.

XELJANZ bruges til behandling af følgende betændelsessygdomme:

* Leddegigt
* Psoriasisgigt
* Tyktarmsbetændelse
* Bechterews sygdom (ankyloserende spondylitis)
* Børneleddegigt - polyartikulær børneleddegigt og psoriasisrelateret børneleddegigt

### Leddegigt

XELJANZ bruges til at behandle voksne patienter med moderat til svær, aktiv leddegigt, en langvarig sygdom som hovedsagelig giver smerter og hævede led.

XELJANZ bruges sammen med methotrexat, når den forudgående behandling af leddegigt ikke har været tilstrækkelig eller ikke tåles.

XELJANZ kan også tages alene i de tilfælde, hvor behandling med methotrexat ikke tåles eller ikke tilrådes.

Det er blevet vist, at XELJANZ nedsætter smerte og hævelse i leddene og forbedrer evnen til at udføre daglige aktiviteter, når det tages alene eller sammen med methotrexat.

### Psoriasisgigt

XELJANZ bruges til at behandle voksne patienter med en sygdom, som kaldes psoriasisgigt. Denne sygdom er en betændelsessygdom i leddene, som ofte er ledsaget af psoriasis. Hvis du har aktiv psoriasisgigt, vil du først få et andet lægemiddel til at behandle din psoriasisgigt. Hvis du ikke reagerer tilstrækkeligt eller ikke kan tåle lægemidlet, vil du muligvis få XELJANZ for at nedsætte tegn og symptomer på aktiv psoriasisgigt og forbedre evnen til at udføre daglige aktiviteter.

 

XELJANZ bruges sammen med methotrexat til at behandle voksne patienter med aktiv psoriasisgigt.

### Bechterews sygdom (ankyloserende spondylitis)

XELJANZ anvendes til at behandle en sygdom ved navn Bechterews sygdom (ankyloserende spondylitis). Denne tilstand er en inflammatorisk sygdom i rygsøjlen.

Hvis du har ankyloserende spondylitis, vil du måske først få et andet lægemiddel. Hvis du ikke reagerer tilstrækkeligt på det lægemiddel, vil du få XELJANZ. XELJANZ kan nedsætte rygsmerter og forbedre fysiske funktioner. Disse virkninger kan gøre dine hverdagsaktiviteter nemmere og forbedre din livskvalitet.

### Tyktarmsbetændelse (colitis ulcerosa)

Blødende tyktarmsbetændelse er en betændelsessygdom i tyktarmen. XELJANZ anvendes hos voksne patienter til at reducere tegn og symptomer på blødende tyktarmsbetændelse, hvis du ikke har reageret godt nok på eller ikke har kunnet tåle tidligere behandling af tyktarmsbetændelse.

### Børneleddegigt - polyartikulær børneleddegigt og psoriasisrelateret børneleddegigt

XELJANZ bruges til at behandle en aktiv polyartikulær børneleddegigt, der er en langvarig sygdom som hovedsagelig giver smerter og hævede led hos patienter, der er 2 år og ældre.

XELJANZ bruges til at behandle psoriasisrelateret børneleddegigt, en sygdom, der er en betændelsessygdom i leddene, som ofte er ledsaget af psoriasis, hos patienter, der er 2 år og ældre.

XELJANZ kan bruges sammen med methotrexat, når forudgående behandling af polyartikulær børneleddegigt eller psoriasisrelateret børneleddegigt ikke har været tilstrækkelig eller lægemidlet ikke tåles.

XELJANZ kan også tages alene i de tilfælde, hvor behandling med methotrexat ikke tåles eller ikke tilrådes.


#### 2. Det skal du vide, før du begynder at tage XELJANZ

 

 

## 2. Det skal du vide, før du begynder at tage XELJANZ

### Tag ikke XELJANZ:

* hvis du er allergisk over for tofacitinib eller et af de øvrige indholdsstoffer i XELJANZ (angivet i [afsnit 6](#Section6)).
* hvis du har en alvorlig infektion, såsom blodforgiftning eller aktiv tuberkulose.
* hvis du har fået at vide, at du har alvorlige leverproblemer inklusive skrumpelever (cirrose, ardannelse i leveren).
* hvis du er gravid eller ammer.

Hvis du er i tvivl om noget af ovenstående, skal du kontakte lægen.

### Advarsler og forsigtighedsregler

Kontakt lægen eller apotekspersonalet, før du tager XELJANZ:

* hvis du tror, du har en infektion eller har symptomer på en infektion såsom feber, svedtendens, kuldegysninger, muskelsmerter, hoste, åndenød, slimdannelse eller ændring i slim, vægttab, varm eller rød eller smertefuld hud eller sår på kroppen, synkebesvær eller smerter, når du synker, diarré eller mavesmerter, brændende fornemmelse, når du lader vandet, eller lader vandet hyppigere end normalt, udtalt træthed.
* hvis du har en sygdom, som øger din risiko for at få en infektion (fx sukkersyge, HIV/AIDS eller et svagt immunforsvar).
* hvis du har en infektion, behandles for en infektion, eller hvis du har infektioner, som bliver ved med at komme igen. Fortæl det straks til lægen, hvis du føler dig utilpas. XELJANZ kan nedsætte kroppens evne til at reagere på infektioner og kan forværre en eksisterende infektion eller øge risikoen for at få en ny infektion.
* hvis du har eller har haft tuberkulose eller har været i tæt kontakt med nogen, der har tuberkulose. Din læge vil undersøge, om du har tuberkulose, før du begynder at få XELJANZ og vil måske undersøge dig igen i løbet af behandlingen.
* hvis du har kronisk lungesygdom.
* hvis du har problemer med leveren.
* hvis du har eller har haft hepatitis B eller hepatitis C (virus, som påvirker leveren). Virussen kan blive aktiv, mens du tager XELJANZ. Lægen vil muligvis tage blodprøver og teste dig for hepatitis, før du påbegynder behandling med XELJANZ, og mens du tager XELJANZ.
* hvis du er 65 år eller derover, hvis du nogensinde har haft en eller anden form for kræft, også hvis du ryger eller har røget. XELJANZ kan øge din risiko for visse former for kræft. Der er rapporteret om kræft i de hvide blodlegemer, lungekræft og andre former for kræft (såsom brystkræft, hudkræft, prostatakræft og kræft i bugspytkirtlen) hos patienter, der blev behandlet med XELJANZ. Hvis du får kræft, mens du tager XELJANZ, vil din læge overveje, om behandlingen skal stoppes.
* hvis du har en kendt risiko for knoglebrud, fx hvis du er 65 år eller derover, du er en kvinde, eller du tager kortikosteroider (fx prednison).
* Der er set tilfælde af non-melanom hudkræft (hudkræft, som ikke er modermærkekræft) hos patienter, som tager XELJANZ. Lægen vil muligvis anbefale dig, at du jævnligt får huden undersøgt, mens du tager XELJANZ. Du skal fortælle det til lægen, hvis der opstår nye hudlæsioner under eller efter behandlingen, eller hvis eksisterende læsioner ændrer udseende.
* hvis du har haft diverticulitis (en type betændelse i tyktarmen) eller mavesår eller sår i tarmene (se [afsnit 4](#Section4)).
* hvis du har problemer med nyrerne.
* hvis du planlægger at blive vaccineret, skal du fortælle det til lægen. Der er visse typer vaccine, du ikke må få, når du tager XELJANZ. Inden du begynder at tage XELJANZ, skal du være ajour med alle anbefalede vaccinationer. Din læge vil afgøre, om du har brug for en vaccine mod herpes zoster.
* hvis du har problemer med hjertet, forhøjet blodtryk, forhøjet kolesterol, også hvis du ryger eller har røget.

Der er rapporteret om patienter behandlet med XELJANZ, der har fået blodpropper i lunger eller vener. Din læge vil tage stilling til din risiko for, at du udvikler blodpropper i lungerne eller venerne, og beslutte, om XELJANZ er egnet til dig. Hvis du allerede har haft problemer med blodpropper i lunger og vener eller har en øget risiko for at få dem (fx: Hvis du er svært overvægtig, har kræft, hjerteproblemer, diabetes, har haft et hjerteanfald (inden for de seneste 3 måneder), nylig større operation, hvis du bruger hormonel prævention/hormonerstatningsbehandling, eller hvis du eller et nært familiemedlem har en koagulationsdefekt), hvis du er ældre eller hvis du ryger eller har røget, kan din læge beslutte, at XELJANZ ikke er egnet til dig.

Tal straks med din læge, hvis du får pludselig åndenød eller vejrtrækningsbesvær, brystsmerter eller smerter i den øvre ryg, hævelse af ben eller arme, smerter eller ømhed i ben eller rødme eller misfarvning på ben eller arme, mens du tager XELJANZ, da dette kan være tegn på en blodprop i lungerne eller venerne.

 

Tal straks med din læge, hvis du oplever akutte synsforandringer (sløret syn, delvist eller fuldstændigt synstab), da dette kan være tegn på en blodprop i øjnene.

Der er rapporteret om patienter behandlet med XELJANZ, der har haft hjerteproblemer, herunder hjerteanfald. Din læge vil tage stilling til din risiko for at udvikle hjerteproblemer og beslutte, om XELJANZ er egnet til dig. Kontakt straks lægen, hvis du udvikler tegn og symptomer på et hjerteanfald, herunder svære brystsmerter eller trykken for brystet (der kan sprede sig til arme, kæbe, hals, ryg), åndenød, koldsved, svimmelhed eller pludselig svimmelhed.

**Yderligere prøver til at overvåge dit helbred
**Din læge vil tage blodprøver, før du begynder at tage XELJANZ, efter 4 til 8 ugers behandling og derefter hver 3. måned for at se, om du har et lavt antal hvide blodlegemer (neutrofiler eller lymfocytter) eller et lavt antal røde blodlegemer (blodmangel, anæmi).

Du bør ikke tage XELJANZ, hvis antallet af hvide blodlegemer (neutrofiler eller lymfocytter) eller røde blodlegemer er for lavt. Hvis det er nødvendigt, kan din læge afbryde behandlingen med XELJANZ i et stykke tid for at nedsætte risikoen for infektioner (lavt antal hvide blodlegemer) eller blodmangel (lavt antal røde blodlegemer).

Lægen kan også udføre andre tests, såsom at tjekke kolesterolindholdet i dit blod eller undersøge, hvor godt din lever fungerer. Lægen bør tjekke dit kolesteroltal 8 uger efter, du er begyndt at tage XELJANZ. Lægen bør undersøge din leverfunktion med jævne mellemrum.

### Ældre

Patienter på 65 år og derover får oftere infektioner. hvoraf visse kan være alvorlige. Fortæl det til lægen, så snart du bemærker tegn eller symptomer på en infektion.

Patienter på 65 år og derover kan have øget risiko for infektioner, hjerteanfald og visse former for kræft. Din læge kan beslutte, at XELJANZ ikke er egnet til dig.

### Asiatiske patienter

Helvedesild forekommer hyppigere hos japanske og koreanske patienter. Fortæl det til lægen, hvis du får smertefulde blærer på huden.

Der kan også være en større risiko for, at du får visse lungeproblemer. Fortæl det til lægen, hvis du får vejrtrækningsproblemer.

### Børn og unge

Sikkerheden og fordelene ved XELJANZ hos børn, der er under 2 år gamle er endnu ikke blevet fastlagt.

### Brug af andre lægemidler sammen med XELJANZ

Fortæl lægen eller apotekspersonalet, hvis du tager andre lægemidler, for nylig har taget andre lægemidler eller planlægger at tage andre lægemidler.

Fortæl det til lægen, hvis du har diabetes eller tager lægemidler til behandling af diabetes. Din læge kan beslutte, at du har brug for lavere doser af lægemidler mod diabetes, mens du tager tofacitinib.

Nogle lægemidler bør ikke tages sammen med XELJANZ. Hvis de tages sammen med XELJANZ, kan de forårsage en ændring af niveauet af XELJANZ i kroppen, og det kan være nødvendigt at justere dosis af XELJANZ. Du skal fortælle det til lægen, hvis du bruger lægemidler, der indeholder et eller flere af følgende aktive stoffer:

* antibiotika, såsom rifampicin, der bruges til at behandle bakterie-infektioner
* fluconazol, ketoconazol, der bruges til at behandle svampeinfektioner

Det frarådes, at XELJANZ bruges sammen med lægemidler, der undertrykker immunforsvaret, herunder såkaldte målrettede biologiske behandlinger (antistoffer), som dem, der hæmmer tumor-nekrose-faktorer, interleukin-17, interleukin-12/interleukin-23, anti-integriner og stærke kemiske lægemidler, der undertrykker immunforsvaret, herunder azathioprin, mercaptopurin, ciclosporin og tacrolimus. Hvis du tager XELJANZ sammen med disse lægemidler, kan det øge din risiko for bivirkninger herunder infektioner.

Alvorlige infektioner og knoglebrud kan forekomme oftere hos personer, der også tager kortikosteroider (fx prednison).

### Graviditet og amning

Hvis du er kvinde i den fødedygtige alder, skal du bruge sikker svangerskabsforebyggelse, mens du er i behandling med XELJANZ og i mindst 4 uger efter den sidste dosis.

Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge til råds, før du tager dette lægemiddel. Du må ikke tage XELJANZ, hvis du er gravid. Fortæl det straks til lægen, hvis du bliver gravid, mens du tager XELJANZ.

Hvis du tager XELJANZ og ammer, skal du holde op med at amme, indtil du har talt med lægen om at standse behandlingen med XELJANZ.

### Trafik- og arbejdssikkerhed‌

XELJANZ påvirker ikke eller kun i mindre grad evnen til at føre motorkøretøj og betjene maskiner.

### XELJANZ indeholder lactose

Kontakt lægen, inden du tager dette lægemiddel, hvis din læge har fortalt dig, at du ikke kan tåle visse sukkerarter.

### XELJANZ indeholder natrium

Dette lægemiddel indeholder mindre end 1 mmol natrium (23 mg) pr. tablet, dvs. det er i det væsentlige natriumfrit.


#### 3. Sådan skal du tage XELJANZ

 

 

## 3. Sådan skal du tage XELJANZ

Du har fået dette lægemiddel af en speciallæge, som overvåger din behandling, og som ved, hvordan din sygdom skal behandles.

Tag altid lægemidlet nøjagtigt efter lægens anvisning, den anbefalede dosis må ikke overskrides. Er du i tvivl, så spørg lægen eller apotekspersonalet.

**Leddegigt**

* Den anbefalede dosis er 5 mg 2 gange dagligt.

**Psoriasisgigt**

* Den anbefalede dosis er 5 mg 2 gange dagligt.

Hvis du lider af leddegigt eller psoriasisgigt, kan din læge skifte dine tabletter mellem XELJANZ 5 mg filmovertrukne tabletter to gange dagligt og XELJANZ 11 mg depottabletter én gang dagligt. Du kan begynde at tage XELJANZ depottabletter én gang dagligt eller XELJANZ filmovertrukne tabletter to gange dagligt dagen efter den sidste dosis af den anden af disse tabletter. Du må ikke skifte mellem XELJANZ filmovertrukne tabletter og XELJANZ depottabletter, medmindre det sker efter lægens anvisninger.

**Bechterews sygdom (ankyloserende spondylitis)**

* Den anbefalede dosis er 5 mg to gange dagligt.
* Din læge vil eventuelt beslutte, at du skal holde op med at tage XELJANZ, hvis XELJANZ ikke virker for dig i løbet af 16 uger.

**
Blødende tyktarmsbetændelse**

* Den anbefalede dosis er 10 mg to gange dagligt i 8 uger, efterfulgt af 5 mg to gange dagligt.
* Din læge kan beslutte at forlænge den indledende behandling på 10 mg to gange dagligt med yderligere 8 uger (16 uger i alt) efterfulgt af 5 mg to gange dagligt.
* Din læge kan beslutte at stoppebehandlingen med XELJANZ, hvis XELJANZ ikke virker for dig inden for 16 uger.
* For patienter, der tidligere har taget biologiske lægemidler til behandling af blødende tyktarmsbetændelse (såsom de lægemidler, der blokerer aktiviteten af tumornekrosefaktor i kroppen), og hvis disse lægemidler ikke virkede, kan lægen beslutte øge din dosis XELJANZ til 10 mg to gange dagligt, hvis du ikke reagerer tilstrækkeligt på 5 mg to gange om dagen. Din læge vil tage de mulige risici, herunder risikoen for blodpropper i lungerne eller venerne, samt mulige fordele for dig i betragtning. Din læge vil fortælle dig, hvis dette gælder for dig.
* Hvis din behandling afbrydes, kan din læge beslutte at starte din behandling på ny.

**Brug til børn og unge
Børneleddegigt - polyartikulær børneleddegigt og psoriasisrelateret børneleddegigt**

* Den anbefalede dosis er 5 mg 2 gange dagligt til patienter ≥40 kg.

Sørg for at tage tabletten på samme tidspunkt hver dag (en tablet om morgenen og en tablet om aftenen).

Tofacitinib 5 mg tabletter kan knuses og indtages med vand.

Lægen kan nedsætte din dosis, hvis du har problemer med leveren eller nyrerne, eller hvis du får ordineret visse andre lægemidler. Lægen kan også afbryde behandlingen midlertidigt eller permanent, hvis blodprøver viser et lavt indhold af hvide eller røde blodlegemer.

XELJANZ skal tages gennem munden. Du kan tage XELJANZ med eller uden mad.

### Hvis du har taget for meget XELJANZ

Hvis du har taget for mange tabletter, skal du
**øjeblikkeligt **fortælle det til din læge eller apotekspersonalet.

### Hvis du har glemt at tage XELJANZ

Du må ikke tage en dobbeltdosis som erstatning for en glemt tablet. Tag den næste tablet på det sædvanlige tidspunkt og fortsæt som før.

### Hvis du holder op med at tage XELJANZ

Du må ikke holde op med at tage XELJANZ uden først at diskutere det med lægen.

Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.


#### 4. Bivirkninger

 

 

## 4. Bivirkninger

Dette lægemiddel kan som alle andre lægemidler give bivirkninger, men ikke alle får bivirkninger.

Nogle af bivirkningerne kan være alvorlige og kræve lægehjælp.

Bivirkninger hos patienter med polyartikulær børneleddegigt og psoriasisrelateret børneleddegigt var tilsvarende dem, der blev set hos voksne patienter med leddegigt bortset fra nogle infektioner (influenza, betændelse i svælget, bihulebetændelse, virusinfektion)) og symptomer i mave-tarm-kanalen eller almene sygdomme (mavesmerter, kvalme, opkastning, feber, hovedpine, hoste), som var mere almindelige hos børn med polyartikulær leddegigt.

### Alvorlige bivirkninger

I sjældne tilfælde kan infektioner være livstruende.

Der er også rapporteret om lungekræft, kræft i de hvide blodlegemer og hjerteanfald.

 

**Hvis du oplever nogen af følgende alvorlige bivirkninger**, skal du straks kontakte en læge.

**
Tegn på alvorlige infektioner (hyppighed ”almindelig”) inkluderer**

* feber og kuldegysninger
* hoste
* blærer på huden
* mavesmerter
* vedvarende hovedpine

**Tegn på sår eller huller (perforationer) i mavesækken eller tarmene (ikke almindelige) inkluderer**

* feber
* mavesmerter
* blod i afføringen
* uforklarlige ændringer i afføringsvaner

Huller i mavesækken eller tarmene opstår oftest hos patienter, som også tager non-steroide antiinflammatoriske lægemidler (NSAID) eller kortikosteroider (fx prednison).

**Tegn på allergiske reaktioner (hyppighed ”sjælden”) inkluderer**

* trykken for brystet
* hivende vejrtrækning
* alvorlig svimmelhed eller ørhed
* hævelse af læber, tunge og svælg
* nældefeber (kløe eller hududslæt)

**Tegn på blodpropper i lunger eller vener eller øjne (hyppighed ”ikke almindelig”: venøs tromboemboli) inkluderer**

* pludselig åndenød eller vejrtrækningsbesvær
* brystsmerter eller smerter øverst i ryggen
* hævelse af ben eller arme
* smerter eller ømhed i benet
* rødme eller misfarvning på ben eller arme
* akutte synsforandringer

**Tegn på hjerteanfald (ikke almindelig) omfatter:**

* alvorlige brystsmerter eller trykken for brystet (der kan brede sig til arme, kæbe, hals, ryg)
* åndenød
* koldsved
* svimmelhed eller pludselig svimmelhed

### Andre bivirkninger, der er blevet observeret med XELJANZ, er anført nedenfor.

**Almindelig **(kan forekomme hos op til 1 ud af 10 personer):

lungeinfektion (lungebetændelse og bronkitis), helvedesild (herpes zoster), infektioner i næse, hals eller luftrør (forkølelse), influenza, bihulebetændelse, urinvejsinfektion (blærebetændelse), ondt i halsen (svælgkatar), forhøjede muskelenzymer i blodet (tegn på muskelproblemer), mavesmerter (som kan skyldes betændelse i mavens slimhinde), opkastning, diarré, kvalme, fordøjelsesbesvær, lavt antal hvide blodlegemer, lavt antal røde blodlegemer (blodmangel, anæmi), hævede fødder og hænder, hovedpine, forhøjet blodtryk (hypertension), hoste, udslæt, akne.

**
Ikke almindelig **(kan forekomme hos op til 1 ud af 100 personer):

lungekræft, tuberkulose, nyrebetændelse, betændelse i huden, herpes simplex eller forkølelsessår (oral herpes), forhøjet blodkreatinin (tegn på mulige nyreproblemer), forhøjet kolesterol (herunder forhøjet LDL), feber, udmattelse (træthedsfornemmelse), vægtstigning, væskemangel, forstrækning af muskler, senebetændelse, hævede led, forstrækning af led, føleforstyrrelser, dårlig søvn, tilstoppede bihuler, åndenød eller vejrtrækningsbesvær, hudrødme, kløe, fedtlever, smertefuld betændelse i de små udposninger i tarmen (diverticulitis), virusinfektioner, virusinfektioner, der påvirker mave-tarm-kanalen, visse typer hudkræft (ikke-melanom typer).

**
Sjælden **(kan forekomme hos op til 1 ud af 1.000 personer):

blodforgiftning (sepsis), lymfom (kræft i de hvide blodlegemer), tuberkulose i knogler, andre organer samt andre usædvanlige infektioner, ledbetændelse, forhøjede leverenzymer i blodet (tegn på leverproblemer), muskel- og ledsmerter.

**
Meget sjælden**(kan forekomme hos op til 1 ud af 10.000 personer): tuberkulose som involverer hjerne og rygrad, meningitis, infektion i bløddele og bindevæv.

Generelt blev der set færre bivirkninger, når XELJANZ blev brugt alene til leddegigt.

### Indberetning af bivirkninger

Hvis du oplever bivirkninger, bør du tale med din læge eller apotekspersonalet. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via

Lægemiddelstyrelsen

Axel Heides Gade 1

DK-2300 København S

Websted: www.meldenbivirkning.dk

Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.

[Meld en bivirkning.](https://www.meldenbivirkning.dk)


#### 5. Opbevaring

 

 

## 5. Opbevaring

Opbevar lægemidlet utilgængeligt for børn.

Brug ikke lægemidlet efter den udløbsdato, der står på blisterpakningen, tabletbeholderen eller kartonen efter EXP. Udløbsdatoen er den sidste dag i den nævnte måned.

Der er ingen særlige krav vedrørende opbevaringstemperaturer for dette lægemiddel.

Opbevares i den originale pakning for at beskytte med fugt.

Brug ikke dette lægemiddel, hvis du opdager, at tabletterne udviser tegn på beskadigelse (for eksempel er gået i stykker eller er misfarvede).

Spørg apotekspersonalet, hvordan du skal bortskaffe lægemiddelrester. Af hensyn til miljøet må du ikke smide lægemiddelrester i afløbet, toilettet eller skraldespanden.


#### 6. Pakningsstørrelser og yderligere oplysninger

 

 

## 6. Pakningsstørrelser og yderligere oplysninger

### XELJANZ indeholder:

**XELJANZ 5 mg filmovertrukket tablet**

* Aktivt stof: tofacitinib.
* Hver 5 mg filmovertrukken tablet indeholder 5 mg tofacitinib (som tofacitinibcitrat).
* Øvrige indholdsstoffer: mikrokrystallinsk cellulose, lactosemonohydrat (se [afsnit 2](#Section2) ”XELJANZ indeholder lactose”), croscarmellosenatrium (se [afsnit 2 ](#Section2)”XELJANZ indeholder natrium”), magnesiumstearat, hypromellose (E464), titandioxid (E171), macrogol og triacetin .

**
XELJANZ 10 mg filmovertrukket tablet**

* Aktivt stof: tofacitinib.
* Hver 10 mg filmovertrukket tablet indeholder10 mg tofacitinib (som tofacitinibcitrat).
* Øvrige indholdsstoffer: mikrokrystallinsk cellulose, lactosemonohydrat (se [afsnit 2](#Section2) ”Xeljanz indeholder lactose”), croscarmellosenatrium (se [afsnit 2](#Section2) ”XELJANZ indeholder natrium”), magnesiumstearat, hypromellose (E464), titanoxid (E171), macrogol, triacetin , Indigotin (indigocarmin) (E132), og Brilliant Blue FCF (E133).

### Udseende og pakningsstørrelser

**XELJANZ 5 mg filmovertrukne tabletter**

XELJANZ 5 mg filmovertrukne tabletter er hvide og runde.

Tabletterne findes som blisterkort med 14 tabletter. Hver pakning indeholdende 56, 112 eller 182 tabletter og i tabletbeholdere indeholdende 60 eller 180 tabletter.

**XELJANZ 10 mg filmovertrukne tabletter**

XELJANZ 10 mg filmovertrukne tabletter er blå og runde.

* Tabletterne findes som blisterkort med 14 tabletter. Hver pakning indeholder 56, 112 eller 182 tabletter og i tabletbeholdere indeholdende 60 eller 180 tabletter.

Ikke alle pakningsstørrelser er nødvendigvis markedsført.


####  Xeljanz tab 10 mg 
LEGEMIDDELMERKEVAREID:
** ID_425E2639-8B0C-4158-88A8-EA58F01B98D5 **
-------

Full name: **Xeljanz tab 10 mg**

-------

 Authorised dose form: **** 

 Legal status of supply: **** 

 Domain: **** 

 Resource status: **** 

-------

 Product classification: 

 Package 1 of 3

LEGEMIDDELPAKNINGID: ** ID_6282AE20-8670-4CB5-B3CE-028D31CBFD81 ** 

VARENUMMER: ** 128750 ** 

 Description:  * * 

 Marketing status: 
 

 Pack size: 
 

Package: ** ** 

Containing:


## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FK47224",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Bundle-uv-epi"]
  },
  "language" : "da",
  "identifier" : {
    "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
    "value" : "47224"
  },
  "type" : "document",
  "timestamp" : "2023-11-06T01:01:01Z",
  "entry" : [{
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/Composition/FK47224-COMP",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "FK47224-COMP",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/Composition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL"]
      },
      "language" : "da",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"da\" lang=\"da\"><a name=\"Composition_FK47224-COMP\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition FK47224-COMP</b></p><a name=\"FK47224-COMP\"> </a><a name=\"hcFK47224-COMP\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Language: da</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-Composition-uv-epi.html\">Composition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-Composition-PIL</code></p></div><p><b>identifier</b>: <code>https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/</code>/47224</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{https://spor.ema.europa.eu/v1/lists/100000155531/terms/ 100000155538}\">100000155538</span></p><p><b>date</b>: 2023-11-06</p><p><b>author</b>: Identifier: <code>https://medicin.dk</code>/medicin.dk</p><p><b>title</b>: Xeljanz 5 mg og 10 mg filmovertrukne tabletter</p></div>"
      },
      "identifier" : [{
        "system" : "https://www.indlaegssedler.dk/Indlaegssedler/Indlaegsseddel/",
        "value" : "47224"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "https://spor.ema.europa.eu/v1/lists/100000155531/terms/",
          "code" : "100000155538"
        }]
      },
      "subject" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-62"
      },
      {
        "reference" : "MedicinalProductDefinition/IBD-MPD-63"
      }],
      "date" : "2023-11-06",
      "author" : [{
        "identifier" : {
          "system" : "https://medicin.dk",
          "value" : "medicin.dk"
        }
      }],
      "title" : "Xeljanz 5 mg og 10 mg filmovertrukne tabletter",
      "section" : [{
        "title" : "Indlægsseddel: Information til patienten",
        "code" : {
          "coding" : [{
            "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
            "code" : "200000029894"
          }]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section0\"/><h2>Indlægsseddel: Information til patienten</h2><h3>XELJANZ 5 mg filmovertrukne tabletter</h3><div class=\"paragraph\"><b>XELJANZ 10 mg filmovertrukne tabletter</b></div><div class=\"paragraph\">tofacitinib</div><h3>Læs denne indlægsseddel grundigt, inden du begynder at tage dette lægemiddel, da den indeholder vigtige oplysninger.</h3><ul><li>Gem indlægssedlen. Du kan få brug for at læse den igen.</li><li>Spørg lægen eller apotekspersonalet, hvis der er mere, du vil vide.</li><li>Lægen har ordineret dette lægemiddel til dig personligt. Lad derfor være med at give lægemidlet til andre. Det kan være skadeligt for andre, selvom de har de samme symptomer, som du har.</li><li>Kontakt lægen eller apotekspersonalet, hvis du får bivirkninger, herunder bivirkninger, som ikke er nævnt i denne indlægsseddel. Se <a href=\"#Section4\" title=\"Anchor link til afsnit - afsnit 4\">afsnit 4</a>.</li></ul><div class=\"paragraph\"><br/>Udover denne indlægsseddel vil lægen også give dig et patientkort, som indeholder vigtige sikkerhedsoplysninger, som du skal være opmærksom på, før du tager XELJANZ, og så længe du er i behandling med XELJANZ. Du skal altid have dette patientkort på dig.<br/><br/>Se den nyeste indlægsseddel på <a href=\"https://www.indlaegsseddel.dk\" title=\"null\">www.indlaegsseddel.dk</a></div><h3>Oversigt over indlægssedlen</h3><ol><li>Virkning og anvendelse</li><li>Det skal du vide, før du begynder at tage XELJANZ</li><li>Sådan skal du tage XELJANZ</li><li>Bivirkninger</li><li>Opbevaring</li><li>Pakningsstørrelser og yderligere oplysninger</li></ol></div>"
        },
        "section" : [{
          "title" : "1. Virkning og anvendelse",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029895"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section1\"/><div> </div><h2>1. Virkning og anvendelse</h2><div class=\"paragraph\">XELJANZ er et lægemiddel, der indeholder det aktive stof tofacitinib.</div><div class=\"paragraph\"><br/>XELJANZ bruges til behandling af følgende betændelsessygdomme:</div><ul><li>Leddegigt</li><li>Psoriasisgigt</li><li>Tyktarmsbetændelse</li><li>Bechterews sygdom (ankyloserende spondylitis)</li><li>Børneleddegigt - polyartikulær børneleddegigt og psoriasisrelateret børneleddegigt</li></ul><h3>Leddegigt</h3><div class=\"paragraph\">XELJANZ bruges til at behandle voksne patienter med moderat til svær, aktiv leddegigt, en langvarig sygdom som hovedsagelig giver smerter og hævede led.</div><div class=\"paragraph\"><br/>XELJANZ bruges sammen med methotrexat, når den forudgående behandling af leddegigt ikke har været tilstrækkelig eller ikke tåles.</div><div class=\"paragraph\"><br/>XELJANZ kan også tages alene i de tilfælde, hvor behandling med methotrexat ikke tåles eller ikke tilrådes.</div><div class=\"paragraph\"><br/>Det er blevet vist, at XELJANZ nedsætter smerte og hævelse i leddene og forbedrer evnen til at udføre daglige aktiviteter, når det tages alene eller sammen med methotrexat.</div><h3>Psoriasisgigt</h3><div class=\"paragraph\">XELJANZ bruges til at behandle voksne patienter med en sygdom, som kaldes psoriasisgigt. Denne sygdom er en betændelsessygdom i leddene, som ofte er ledsaget af psoriasis. Hvis du har aktiv psoriasisgigt, vil du først få et andet lægemiddel til at behandle din psoriasisgigt. Hvis du ikke reagerer tilstrækkeligt eller ikke kan tåle lægemidlet, vil du muligvis få XELJANZ for at nedsætte tegn og symptomer på aktiv psoriasisgigt og forbedre evnen til at udføre daglige aktiviteter.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">XELJANZ bruges sammen med methotrexat til at behandle voksne patienter med aktiv psoriasisgigt.</div><h3>Bechterews sygdom (ankyloserende spondylitis)</h3><div class=\"paragraph\">XELJANZ anvendes til at behandle en sygdom ved navn Bechterews sygdom (ankyloserende spondylitis). Denne tilstand er en inflammatorisk sygdom i rygsøjlen.<br/><br/>Hvis du har ankyloserende spondylitis, vil du måske først få et andet lægemiddel. Hvis du ikke reagerer tilstrækkeligt på det lægemiddel, vil du få XELJANZ. XELJANZ kan nedsætte rygsmerter og forbedre fysiske funktioner. Disse virkninger kan gøre dine hverdagsaktiviteter nemmere og forbedre din livskvalitet.</div><h3>Tyktarmsbetændelse (colitis ulcerosa)</h3><div class=\"paragraph\">Blødende tyktarmsbetændelse er en betændelsessygdom i tyktarmen. XELJANZ anvendes hos voksne patienter til at reducere tegn og symptomer på blødende tyktarmsbetændelse, hvis du ikke har reageret godt nok på eller ikke har kunnet tåle tidligere behandling af tyktarmsbetændelse.</div><h3>Børneleddegigt - polyartikulær børneleddegigt og psoriasisrelateret børneleddegigt</h3><div class=\"paragraph\">XELJANZ bruges til at behandle en aktiv polyartikulær børneleddegigt, der er en langvarig sygdom som hovedsagelig giver smerter og hævede led hos patienter, der er 2 år og ældre.<br/><br/>XELJANZ bruges til at behandle psoriasisrelateret børneleddegigt, en sygdom, der er en betændelsessygdom i leddene, som ofte er ledsaget af psoriasis, hos patienter, der er 2 år og ældre.<br/><br/>XELJANZ kan bruges sammen med methotrexat, når forudgående behandling af polyartikulær børneleddegigt eller psoriasisrelateret børneleddegigt ikke har været tilstrækkelig eller lægemidlet ikke tåles.<br/><br/>XELJANZ kan også tages alene i de tilfælde, hvor behandling med methotrexat ikke tåles eller ikke tilrådes.</div></div>"
          }
        },
        {
          "title" : "2. Det skal du vide, før du begynder at tage XELJANZ",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029896"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section2\"/><div> </div><h2>2. Det skal du vide, før du begynder at tage XELJANZ</h2><h3>Tag ikke XELJANZ:</h3><ul><li>hvis du er allergisk over for tofacitinib eller et af de øvrige indholdsstoffer i XELJANZ (angivet i <a href=\"#Section6\" title=\"Anchor link til afsnit - afsnit 6\">afsnit 6</a>).</li><li>hvis du har en alvorlig infektion, såsom blodforgiftning eller aktiv tuberkulose.</li><li>hvis du har fået at vide, at du har alvorlige leverproblemer inklusive skrumpelever (cirrose, ardannelse i leveren).</li><li>hvis du er gravid eller ammer.</li></ul><div class=\"paragraph\"><br/>Hvis du er i tvivl om noget af ovenstående, skal du kontakte lægen.</div><h3>Advarsler og forsigtighedsregler</h3><div class=\"paragraph\">Kontakt lægen eller apotekspersonalet, før du tager XELJANZ:</div><ul><li>hvis du tror, du har en infektion eller har symptomer på en infektion såsom feber, svedtendens, kuldegysninger, muskelsmerter, hoste, åndenød, slimdannelse eller ændring i slim, vægttab, varm eller rød eller smertefuld hud eller sår på kroppen, synkebesvær eller smerter, når du synker, diarré eller mavesmerter, brændende fornemmelse, når du lader vandet, eller lader vandet hyppigere end normalt, udtalt træthed.</li><li>hvis du har en sygdom, som øger din risiko for at få en infektion (fx sukkersyge, HIV/AIDS eller et svagt immunforsvar).</li><li>hvis du har en infektion, behandles for en infektion, eller hvis du har infektioner, som bliver ved med at komme igen. Fortæl det straks til lægen, hvis du føler dig utilpas. XELJANZ kan nedsætte kroppens evne til at reagere på infektioner og kan forværre en eksisterende infektion eller øge risikoen for at få en ny infektion.</li><li>hvis du har eller har haft tuberkulose eller har været i tæt kontakt med nogen, der har tuberkulose. Din læge vil undersøge, om du har tuberkulose, før du begynder at få XELJANZ og vil måske undersøge dig igen i løbet af behandlingen.</li><li>hvis du har kronisk lungesygdom.</li><li>hvis du har problemer med leveren.</li><li>hvis du har eller har haft hepatitis B eller hepatitis C (virus, som påvirker leveren). Virussen kan blive aktiv, mens du tager XELJANZ. Lægen vil muligvis tage blodprøver og teste dig for hepatitis, før du påbegynder behandling med XELJANZ, og mens du tager XELJANZ.</li><li>hvis du er 65 år eller derover, hvis du nogensinde har haft en eller anden form for kræft, også hvis du ryger eller har røget. XELJANZ kan øge din risiko for visse former for kræft. Der er rapporteret om kræft i de hvide blodlegemer, lungekræft og andre former for kræft (såsom brystkræft, hudkræft, prostatakræft og kræft i bugspytkirtlen) hos patienter, der blev behandlet med XELJANZ. Hvis du får kræft, mens du tager XELJANZ, vil din læge overveje, om behandlingen skal stoppes.</li><li>hvis du har en kendt risiko for knoglebrud, fx hvis du er 65 år eller derover, du er en kvinde, eller du tager kortikosteroider (fx prednison).</li><li>Der er set tilfælde af non-melanom hudkræft (hudkræft, som ikke er modermærkekræft) hos patienter, som tager XELJANZ. Lægen vil muligvis anbefale dig, at du jævnligt får huden undersøgt, mens du tager XELJANZ. Du skal fortælle det til lægen, hvis der opstår nye hudlæsioner under eller efter behandlingen, eller hvis eksisterende læsioner ændrer udseende.</li><li>hvis du har haft diverticulitis (en type betændelse i tyktarmen) eller mavesår eller sår i tarmene (se <a href=\"#Section4\" title=\"Anchor link til afsnit - afsnit 4\">afsnit 4</a>).</li><li>hvis du har problemer med nyrerne.</li><li>hvis du planlægger at blive vaccineret, skal du fortælle det til lægen. Der er visse typer vaccine, du ikke må få, når du tager XELJANZ. Inden du begynder at tage XELJANZ, skal du være ajour med alle anbefalede vaccinationer. Din læge vil afgøre, om du har brug for en vaccine mod herpes zoster.</li><li>hvis du har problemer med hjertet, forhøjet blodtryk, forhøjet kolesterol, også hvis du ryger eller har røget.</li></ul><div class=\"paragraph\"><br/>Der er rapporteret om patienter behandlet med XELJANZ, der har fået blodpropper i lunger eller vener. Din læge vil tage stilling til din risiko for, at du udvikler blodpropper i lungerne eller venerne, og beslutte, om XELJANZ er egnet til dig. Hvis du allerede har haft problemer med blodpropper i lunger og vener eller har en øget risiko for at få dem (fx: Hvis du er svært overvægtig, har kræft, hjerteproblemer, diabetes, har haft et hjerteanfald (inden for de seneste 3 måneder), nylig større operation, hvis du bruger hormonel prævention/hormonerstatningsbehandling, eller hvis du eller et nært familiemedlem har en koagulationsdefekt), hvis du er ældre eller hvis du ryger eller har røget, kan din læge beslutte, at XELJANZ ikke er egnet til dig.</div><div class=\"paragraph\"><br/>Tal straks med din læge, hvis du får pludselig åndenød eller vejrtrækningsbesvær, brystsmerter eller smerter i den øvre ryg, hævelse af ben eller arme, smerter eller ømhed i ben eller rødme eller misfarvning på ben eller arme, mens du tager XELJANZ, da dette kan være tegn på en blodprop i lungerne eller venerne.</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Tal straks med din læge, hvis du oplever akutte synsforandringer (sløret syn, delvist eller fuldstændigt synstab), da dette kan være tegn på en blodprop i øjnene.<br/><br/>Der er rapporteret om patienter behandlet med XELJANZ, der har haft hjerteproblemer, herunder hjerteanfald. Din læge vil tage stilling til din risiko for at udvikle hjerteproblemer og beslutte, om XELJANZ er egnet til dig. Kontakt straks lægen, hvis du udvikler tegn og symptomer på et hjerteanfald, herunder svære brystsmerter eller trykken for brystet (der kan sprede sig til arme, kæbe, hals, ryg), åndenød, koldsved, svimmelhed eller pludselig svimmelhed.</div><div class=\"paragraph\"><br/><b>Yderligere prøver til at overvåge dit helbred<br/></b>Din læge vil tage blodprøver, før du begynder at tage XELJANZ, efter 4 til 8 ugers behandling og derefter hver 3. måned for at se, om du har et lavt antal hvide blodlegemer (neutrofiler eller lymfocytter) eller et lavt antal røde blodlegemer (blodmangel, anæmi).</div><div class=\"paragraph\"><br/>Du bør ikke tage XELJANZ, hvis antallet af hvide blodlegemer (neutrofiler eller lymfocytter) eller røde blodlegemer er for lavt. Hvis det er nødvendigt, kan din læge afbryde behandlingen med XELJANZ i et stykke tid for at nedsætte risikoen for infektioner (lavt antal hvide blodlegemer) eller blodmangel (lavt antal røde blodlegemer).</div><div class=\"paragraph\"><br/>Lægen kan også udføre andre tests, såsom at tjekke kolesterolindholdet i dit blod eller undersøge, hvor godt din lever fungerer. Lægen bør tjekke dit kolesteroltal 8 uger efter, du er begyndt at tage XELJANZ. Lægen bør undersøge din leverfunktion med jævne mellemrum.</div><h3>Ældre</h3><div class=\"paragraph\">Patienter på 65 år og derover får oftere infektioner. hvoraf visse kan være alvorlige. Fortæl det til lægen, så snart du bemærker tegn eller symptomer på en infektion.<br/><br/>Patienter på 65 år og derover kan have øget risiko for infektioner, hjerteanfald og visse former for kræft. Din læge kan beslutte, at XELJANZ ikke er egnet til dig.</div><h3>Asiatiske patienter</h3><div class=\"paragraph\">Helvedesild forekommer hyppigere hos japanske og koreanske patienter. Fortæl det til lægen, hvis du får smertefulde blærer på huden.</div><div class=\"paragraph\"><br/>Der kan også være en større risiko for, at du får visse lungeproblemer. Fortæl det til lægen, hvis du får vejrtrækningsproblemer.</div><h3>Børn og unge</h3><div class=\"paragraph\">Sikkerheden og fordelene ved XELJANZ hos børn, der er under 2 år gamle er endnu ikke blevet fastlagt.</div><h3>Brug af andre lægemidler sammen med XELJANZ</h3><div class=\"paragraph\">Fortæl lægen eller apotekspersonalet, hvis du tager andre lægemidler, for nylig har taget andre lægemidler eller planlægger at tage andre lægemidler.</div><div class=\"paragraph\"><br/>Fortæl det til lægen, hvis du har diabetes eller tager lægemidler til behandling af diabetes. Din læge kan beslutte, at du har brug for lavere doser af lægemidler mod diabetes, mens du tager tofacitinib.</div><div class=\"paragraph\"><br/>Nogle lægemidler bør ikke tages sammen med XELJANZ. Hvis de tages sammen med XELJANZ, kan de forårsage en ændring af niveauet af XELJANZ i kroppen, og det kan være nødvendigt at justere dosis af XELJANZ. Du skal fortælle det til lægen, hvis du bruger lægemidler, der indeholder et eller flere af følgende aktive stoffer:</div><ul><li>antibiotika, såsom rifampicin, der bruges til at behandle bakterie-infektioner</li><li>fluconazol, ketoconazol, der bruges til at behandle svampeinfektioner</li></ul><div class=\"paragraph\"><br/>Det frarådes, at XELJANZ bruges sammen med lægemidler, der undertrykker immunforsvaret, herunder såkaldte målrettede biologiske behandlinger (antistoffer), som dem, der hæmmer tumor-nekrose-faktorer, interleukin-17, interleukin-12/interleukin-23, anti-integriner og stærke kemiske lægemidler, der undertrykker immunforsvaret, herunder azathioprin, mercaptopurin, ciclosporin og tacrolimus. Hvis du tager XELJANZ sammen med disse lægemidler, kan det øge din risiko for bivirkninger herunder infektioner.</div><div class=\"paragraph\"><br/>Alvorlige infektioner og knoglebrud kan forekomme oftere hos personer, der også tager kortikosteroider (fx prednison).</div><h3>Graviditet og amning</h3><div class=\"paragraph\">Hvis du er kvinde i den fødedygtige alder, skal du bruge sikker svangerskabsforebyggelse, mens du er i behandling med XELJANZ og i mindst 4 uger efter den sidste dosis.</div><div class=\"paragraph\"><br/>Hvis du er gravid eller ammer, har mistanke om, at du er gravid, eller planlægger at blive gravid, skal du spørge din læge til råds, før du tager dette lægemiddel. Du må ikke tage XELJANZ, hvis du er gravid. Fortæl det straks til lægen, hvis du bliver gravid, mens du tager XELJANZ.</div><div class=\"paragraph\"><br/>Hvis du tager XELJANZ og ammer, skal du holde op med at amme, indtil du har talt med lægen om at standse behandlingen med XELJANZ.</div><h3>Trafik- og arbejdssikkerhed‌</h3><div class=\"paragraph\">XELJANZ påvirker ikke eller kun i mindre grad evnen til at føre motorkøretøj og betjene maskiner.</div><h3>XELJANZ indeholder lactose</h3><div class=\"paragraph\">Kontakt lægen, inden du tager dette lægemiddel, hvis din læge har fortalt dig, at du ikke kan tåle visse sukkerarter.</div><h3>XELJANZ indeholder natrium</h3><div class=\"paragraph\">Dette lægemiddel indeholder mindre end 1 mmol natrium (23 mg) pr. tablet, dvs. det er i det væsentlige natriumfrit.</div></div>"
          }
        },
        {
          "title" : "3. Sådan skal du tage XELJANZ",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029905"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section3\"/><div> </div><h2>3. Sådan skal du tage XELJANZ</h2><div class=\"paragraph\">Du har fået dette lægemiddel af en speciallæge, som overvåger din behandling, og som ved, hvordan din sygdom skal behandles.</div><div class=\"paragraph\"><br/>Tag altid lægemidlet nøjagtigt efter lægens anvisning, den anbefalede dosis må ikke overskrides. Er du i tvivl, så spørg lægen eller apotekspersonalet.</div><div class=\"paragraph\"><br/><b>Leddegigt</b></div><ul><li>Den anbefalede dosis er 5 mg 2 gange dagligt.</li></ul><div class=\"paragraph\"><br/><b>Psoriasisgigt</b></div><ul><li>Den anbefalede dosis er 5 mg 2 gange dagligt.</li></ul><div class=\"paragraph\">Hvis du lider af leddegigt eller psoriasisgigt, kan din læge skifte dine tabletter mellem XELJANZ 5 mg filmovertrukne tabletter to gange dagligt og XELJANZ 11 mg depottabletter én gang dagligt. Du kan begynde at tage XELJANZ depottabletter én gang dagligt eller XELJANZ filmovertrukne tabletter to gange dagligt dagen efter den sidste dosis af den anden af disse tabletter. Du må ikke skifte mellem XELJANZ filmovertrukne tabletter og XELJANZ depottabletter, medmindre det sker efter lægens anvisninger.</div><div class=\"paragraph\"><br/><b>Bechterews sygdom (ankyloserende spondylitis)</b></div><ul><li>Den anbefalede dosis er 5 mg to gange dagligt.</li><li>Din læge vil eventuelt beslutte, at du skal holde op med at tage XELJANZ, hvis XELJANZ ikke virker for dig i løbet af 16 uger.</li></ul><div class=\"paragraph\"><b><br/>Blødende tyktarmsbetændelse</b></div><ul><li>Den anbefalede dosis er 10 mg to gange dagligt i 8 uger, efterfulgt af 5 mg to gange dagligt.</li><li>Din læge kan beslutte at forlænge den indledende behandling på 10 mg to gange dagligt med yderligere 8 uger (16 uger i alt) efterfulgt af 5 mg to gange dagligt.</li><li>Din læge kan beslutte at stoppebehandlingen med XELJANZ, hvis XELJANZ ikke virker for dig inden for 16 uger.</li><li>For patienter, der tidligere har taget biologiske lægemidler til behandling af blødende tyktarmsbetændelse (såsom de lægemidler, der blokerer aktiviteten af tumornekrosefaktor i kroppen), og hvis disse lægemidler ikke virkede, kan lægen beslutte øge din dosis XELJANZ til 10 mg to gange dagligt, hvis du ikke reagerer tilstrækkeligt på 5 mg to gange om dagen. Din læge vil tage de mulige risici, herunder risikoen for blodpropper i lungerne eller venerne, samt mulige fordele for dig i betragtning. Din læge vil fortælle dig, hvis dette gælder for dig.</li><li>Hvis din behandling afbrydes, kan din læge beslutte at starte din behandling på ny.</li></ul><div class=\"paragraph\"><br/><b>Brug til børn og unge<br/>Børneleddegigt - polyartikulær børneleddegigt og psoriasisrelateret børneleddegigt</b></div><ul><li>Den anbefalede dosis er 5 mg 2 gange dagligt til patienter ≥40 kg.</li></ul><div class=\"paragraph\"><br/>Sørg for at tage tabletten på samme tidspunkt hver dag (en tablet om morgenen og en tablet om aftenen).</div><div class=\"paragraph\"><br/>Tofacitinib 5 mg tabletter kan knuses og indtages med vand.</div><div class=\"paragraph\"><br/>Lægen kan nedsætte din dosis, hvis du har problemer med leveren eller nyrerne, eller hvis du får ordineret visse andre lægemidler. Lægen kan også afbryde behandlingen midlertidigt eller permanent, hvis blodprøver viser et lavt indhold af hvide eller røde blodlegemer.</div><div class=\"paragraph\"><br/>XELJANZ skal tages gennem munden. Du kan tage XELJANZ med eller uden mad.</div><h3>Hvis du har taget for meget XELJANZ</h3><div class=\"paragraph\">Hvis du har taget for mange tabletter, skal du <b>øjeblikkeligt </b>fortælle det til din læge eller apotekspersonalet.</div><h3>Hvis du har glemt at tage XELJANZ</h3><div class=\"paragraph\">Du må ikke tage en dobbeltdosis som erstatning for en glemt tablet. Tag den næste tablet på det sædvanlige tidspunkt og fortsæt som før.</div><h3>Hvis du holder op med at tage XELJANZ</h3><div class=\"paragraph\">Du må ikke holde op med at tage XELJANZ uden først at diskutere det med lægen.</div><div class=\"paragraph\"><br/>Spørg lægen eller apotekspersonalet, hvis der er noget, du er i tvivl om.</div></div>"
          }
        },
        {
          "title" : "4. Bivirkninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029910"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section4\"/><div> </div><h2>4. Bivirkninger</h2><div class=\"paragraph\">Dette lægemiddel kan som alle andre lægemidler give bivirkninger, men ikke alle får bivirkninger.</div><div class=\"paragraph\"><br/>Nogle af bivirkningerne kan være alvorlige og kræve lægehjælp.<br/><br/>Bivirkninger hos patienter med polyartikulær børneleddegigt og psoriasisrelateret børneleddegigt var tilsvarende dem, der blev set hos voksne patienter med leddegigt bortset fra nogle infektioner (influenza, betændelse i svælget, bihulebetændelse, virusinfektion)) og symptomer i mave-tarm-kanalen eller almene sygdomme (mavesmerter, kvalme, opkastning, feber, hovedpine, hoste), som var mere almindelige hos børn med polyartikulær leddegigt.</div><h3>Alvorlige bivirkninger</h3><div class=\"paragraph\">I sjældne tilfælde kan infektioner være livstruende.<br/><br/>Der er også rapporteret om lungekræft, kræft i de hvide blodlegemer og hjerteanfald.</div><div class=\"paragraph\"> </div><div class=\"paragraph\"><b>Hvis du oplever nogen af følgende alvorlige bivirkninger</b>, skal du straks kontakte en læge.</div><div class=\"paragraph\"><b><br/>Tegn på alvorlige infektioner (hyppighed ”almindelig”) inkluderer</b></div><ul><li>feber og kuldegysninger</li><li>hoste</li><li>blærer på huden</li><li>mavesmerter</li><li>vedvarende hovedpine</li></ul><div class=\"paragraph\"><br/><b>Tegn på sår eller huller (perforationer) i mavesækken eller tarmene (ikke almindelige) inkluderer</b></div><ul><li>feber</li><li>mavesmerter</li><li>blod i afføringen</li><li>uforklarlige ændringer i afføringsvaner</li></ul><div class=\"paragraph\"><br/>Huller i mavesækken eller tarmene opstår oftest hos patienter, som også tager non-steroide antiinflammatoriske lægemidler (NSAID) eller kortikosteroider (fx prednison).</div><div class=\"paragraph\"><br/><b>Tegn på allergiske reaktioner (hyppighed ”sjælden”) inkluderer</b></div><ul><li>trykken for brystet</li><li>hivende vejrtrækning</li><li>alvorlig svimmelhed eller ørhed</li><li>hævelse af læber, tunge og svælg</li><li>nældefeber (kløe eller hududslæt)</li></ul><div class=\"paragraph\"><br/><b>Tegn på blodpropper i lunger eller vener eller øjne (hyppighed ”ikke almindelig”: venøs tromboemboli) inkluderer</b></div><ul><li>pludselig åndenød eller vejrtrækningsbesvær</li><li>brystsmerter eller smerter øverst i ryggen</li><li>hævelse af ben eller arme</li><li>smerter eller ømhed i benet</li><li>rødme eller misfarvning på ben eller arme</li><li>akutte synsforandringer</li></ul><div class=\"paragraph\"><br/><b>Tegn på hjerteanfald (ikke almindelig) omfatter:</b></div><ul><li>alvorlige brystsmerter eller trykken for brystet (der kan brede sig til arme, kæbe, hals, ryg)</li><li>åndenød</li><li>koldsved</li><li>svimmelhed eller pludselig svimmelhed</li></ul><h3>Andre bivirkninger, der er blevet observeret med XELJANZ, er anført nedenfor.</h3><div class=\"paragraph\"><b>Almindelig </b>(kan forekomme hos op til 1 ud af 10 personer):<br/>lungeinfektion (lungebetændelse og bronkitis), helvedesild (herpes zoster), infektioner i næse, hals eller luftrør (forkølelse), influenza, bihulebetændelse, urinvejsinfektion (blærebetændelse), ondt i halsen (svælgkatar), forhøjede muskelenzymer i blodet (tegn på muskelproblemer), mavesmerter (som kan skyldes betændelse i mavens slimhinde), opkastning, diarré, kvalme, fordøjelsesbesvær, lavt antal hvide blodlegemer, lavt antal røde blodlegemer (blodmangel, anæmi), hævede fødder og hænder, hovedpine, forhøjet blodtryk (hypertension), hoste, udslæt, akne.</div><div class=\"paragraph\"><b><br/>Ikke almindelig </b>(kan forekomme hos op til 1 ud af 100 personer):<br/>lungekræft, tuberkulose, nyrebetændelse, betændelse i huden, herpes simplex eller forkølelsessår (oral herpes), forhøjet blodkreatinin (tegn på mulige nyreproblemer), forhøjet kolesterol (herunder forhøjet LDL), feber, udmattelse (træthedsfornemmelse), vægtstigning, væskemangel, forstrækning af muskler, senebetændelse, hævede led, forstrækning af led, føleforstyrrelser, dårlig søvn, tilstoppede bihuler, åndenød eller vejrtrækningsbesvær, hudrødme, kløe, fedtlever, smertefuld betændelse i de små udposninger i tarmen (diverticulitis), virusinfektioner, virusinfektioner, der påvirker mave-tarm-kanalen, visse typer hudkræft (ikke-melanom typer).</div><div class=\"paragraph\"><b><br/>Sjælden </b>(kan forekomme hos op til 1 ud af 1.000 personer):</div><div class=\"paragraph\">blodforgiftning (sepsis), lymfom (kræft i de hvide blodlegemer), tuberkulose i knogler, andre organer samt andre usædvanlige infektioner, ledbetændelse, forhøjede leverenzymer i blodet (tegn på leverproblemer), muskel- og ledsmerter.</div><div class=\"paragraph\"><b><br/>Meget sjælden</b> (kan forekomme hos op til 1 ud af 10.000 personer): tuberkulose som involverer hjerne og rygrad, meningitis, infektion i bløddele og bindevæv.<br/><br/>Generelt blev der set færre bivirkninger, når XELJANZ blev brugt alene til leddegigt.</div><h3>Indberetning af bivirkninger</h3><div class=\"paragraph\">Hvis du oplever bivirkninger, bør du tale med din læge eller apotekspersonalet. Dette gælder også mulige bivirkninger, som ikke er medtaget i denne indlægsseddel. Du eller dine pårørende kan også indberette bivirkninger direkte til Lægemiddelstyrelsen via<br/><br/>Lægemiddelstyrelsen<br/>Axel Heides Gade 1<br/>DK-2300 København S<br/>Websted: www.meldenbivirkning.dk<br/><br/>Ved at indrapportere bivirkninger kan du hjælpe med at fremskaffe mere information om sikkerheden af dette lægemiddel.</div><div class=\"paragraph\"><a href=\"https://www.meldenbivirkning.dk\" title=\"Meld en bivirkning\">Meld en bivirkning.</a></div></div>"
          }
        },
        {
          "title" : "5. Opbevaring",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029913"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section5\"/><div> </div><h2>5. Opbevaring</h2><div class=\"paragraph\">Opbevar lægemidlet utilgængeligt for børn.<br/><br/>Brug ikke lægemidlet efter den udløbsdato, der står på blisterpakningen, tabletbeholderen eller kartonen efter EXP. Udløbsdatoen er den sidste dag i den nævnte måned.<br/><br/>Der er ingen særlige krav vedrørende opbevaringstemperaturer for dette lægemiddel.<br/><br/>Opbevares i den originale pakning for at beskytte med fugt.<br/><br/>Brug ikke dette lægemiddel, hvis du opdager, at tabletterne udviser tegn på beskadigelse (for eksempel er gået i stykker eller er misfarvede).<br/><br/>Spørg apotekspersonalet, hvordan du skal bortskaffe lægemiddelrester. Af hensyn til miljøet må du ikke smide lægemiddelrester i afløbet, toilettet eller skraldespanden.</div></div>"
          }
        },
        {
          "title" : "6. Pakningsstørrelser og yderligere oplysninger",
          "code" : {
            "coding" : [{
              "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
              "code" : "200000029914"
            }]
          },
          "text" : {
            "status" : "additional",
            "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Section6\"/><div> </div><h2>6. Pakningsstørrelser og yderligere oplysninger</h2><h3>XELJANZ indeholder:</h3><div class=\"paragraph\"><b>XELJANZ 5 mg filmovertrukket tablet</b></div><ul><li>Aktivt stof: tofacitinib.</li><li>Hver 5 mg filmovertrukken tablet indeholder 5 mg tofacitinib (som tofacitinibcitrat).</li><li>Øvrige indholdsstoffer: mikrokrystallinsk cellulose, lactosemonohydrat (se <a href=\"#Section2\" title=\"Anchor link til afsnit - afsnit 2\">afsnit 2</a> ”XELJANZ indeholder lactose”), croscarmellosenatrium (se <a href=\"#Section2\" title=\"Anchor link til afsnit - afsnit 2&amp;#160;\">afsnit 2 </a>”XELJANZ indeholder natrium”), magnesiumstearat, hypromellose (E464), titandioxid (E171), macrogol og triacetin .</li></ul><div class=\"paragraph\"><b><br/>XELJANZ 10 mg filmovertrukket tablet</b></div><ul><li>Aktivt stof: tofacitinib.</li><li>Hver 10 mg filmovertrukket tablet indeholder10 mg tofacitinib (som tofacitinibcitrat).</li><li>Øvrige indholdsstoffer: mikrokrystallinsk cellulose, lactosemonohydrat (se <a href=\"#Section2\" title=\"Anchor link til afsnit - afsnit 2\">afsnit 2</a> ”Xeljanz indeholder lactose”), croscarmellosenatrium (se <a href=\"#Section2\" title=\"Anchor link til afsnit - afsnit 2\">afsnit 2</a> ”XELJANZ indeholder natrium”), magnesiumstearat, hypromellose (E464), titanoxid (E171), macrogol, triacetin , Indigotin (indigocarmin) (E132), og Brilliant Blue FCF (E133).</li></ul><h3>Udseende og pakningsstørrelser</h3><div class=\"paragraph\"><b>XELJANZ 5 mg filmovertrukne tabletter</b></div><div class=\"paragraph\">XELJANZ 5 mg filmovertrukne tabletter er hvide og runde.</div><div class=\"paragraph\"><br/>Tabletterne findes som blisterkort med 14 tabletter. Hver pakning indeholdende 56, 112 eller 182 tabletter og i tabletbeholdere indeholdende 60 eller 180 tabletter.</div><div class=\"paragraph\"><br/><b>XELJANZ 10 mg filmovertrukne tabletter</b></div><div class=\"paragraph\">XELJANZ 10 mg filmovertrukne tabletter er blå og runde.</div><ul><li>Tabletterne findes som blisterkort med 14 tabletter. Hver pakning indeholder 56, 112 eller 182 tabletter og i tabletbeholdere indeholdende 60 eller 180 tabletter.</li></ul><div class=\"paragraph\"><br/>Ikke alle pakningsstørrelser er nødvendigvis markedsført.</div></div>"
          },
          "section" : [{
            "title" : "Indehaver af markedsføringstilladelsen og fremstiller",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029917"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Indehaver af markedsføringstilladelsen og fremstiller</h2><h3>Indehaver af markedsføringstilladelsen</h3><div class=\"paragraph\">Pfizer Europe MA EEIG</div><div class=\"paragraph\">Boulevard de la Plaine 17</div><div class=\"paragraph\">1050 Bruxelles</div><div class=\"paragraph\">Belgien</div><h3>Fremstiller</h3><div class=\"paragraph\">Pfizer Manufacturing Deutschland GmbH</div><div class=\"paragraph\">Betriebsstätte Freiburg</div><div class=\"paragraph\">Mooswaldallee 1</div><div class=\"paragraph\">79090 Freiburg</div><div class=\"paragraph\">Tyskland</div><div class=\"paragraph\"> </div><div class=\"paragraph\">Hvis du ønsker yderligere oplysninger om dette lægemiddel, skal du henvende dig til den lokale repræsentant for indehaveren af markedsføringstilladelsen:</div><div class=\"paragraph\"><br/><b>Danmark</b></div><div class=\"paragraph\">Pfizer ApS</div><div class=\"paragraph\">Tlf.: +45 44 20 11 00</div><h3>Andre informationskilder</h3><div class=\"paragraph\">Du kan finde yderligere oplysninger om dette lægemiddel på Det Europæiske Lægemiddelagenturs hjemmeside: http://www.ema.europa.eu.</div></div>"
            }
          },
          {
            "title" : "Denne indlægsseddel blev senest ændret oktober 2023.",
            "code" : {
              "coding" : [{
                "system" : "https://spor.ema.europa.eu/v1/lists/200000029659/terms/",
                "code" : "200000029919"
              }]
            },
            "text" : {
              "status" : "additional",
              "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><h2>Denne indlægsseddel blev senest ændret oktober 2023.</h2></div>"
            }
          }]
        }]
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/IBD-MPD-62",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "IBD-MPD-62",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_IBD-MPD-62\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition IBD-MPD-62</b></p><a name=\"IBD-MPD-62\"> </a><a name=\"hcIBD-MPD-62\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_425E2639-8B0C-4158-88A8-EA58F01B98D5</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Xeljanz tab 10 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_425E2639-8B0C-4158-88A8-EA58F01B98D5"
      }],
      "name" : [{
        "productName" : "Xeljanz tab 10 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/IBD-PPD-74",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "IBD-PPD-74",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_IBD-PPD-74\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition IBD-PPD-74</b></p><a name=\"IBD-PPD-74\"> </a><a name=\"hcIBD-PPD-74\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_6282AE20-8670-4CB5-B3CE-028D31CBFD81, <code>https://farmalogg.no/varenummer</code>/128750</p><p><b>name</b>: Xeljanz tab 10 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK47224.html#MedicinalProductDefinition_IBD-MPD-62\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_425E2639-8B0C-4158-88A8-EA58F01B98D5</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_6282AE20-8670-4CB5-B3CE-028D31CBFD81"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "128750"
      }],
      "name" : "Xeljanz tab 10 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-62"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/MedicinalProductDefinition/IBD-MPD-63",
    "resource" : {
      "resourceType" : "MedicinalProductDefinition",
      "id" : "IBD-MPD-63",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/MedicinalProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicinalProductDefinition_IBD-MPD-63\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicinalProductDefinition IBD-MPD-63</b></p><a name=\"IBD-MPD-63\"> </a><a name=\"hcIBD-MPD-63\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-MedicinalProductDefinition-uv-epi.html\">MedicinalProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-MedicinalProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelMerkevareID</code>/ID_22849E0B-A45A-413E-A7DC-25D861B28B46</p><h3>Names</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ProductName</b></td></tr><tr><td style=\"display: none\">*</td><td>Xeljanz tab 5 mg</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelMerkevareID",
        "value" : "ID_22849E0B-A45A-413E-A7DC-25D861B28B46"
      }],
      "name" : [{
        "productName" : "Xeljanz tab 5 mg"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/IBD-PPD-76",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "IBD-PPD-76",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_IBD-PPD-76\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition IBD-PPD-76</b></p><a name=\"IBD-PPD-76\"> </a><a name=\"hcIBD-PPD-76\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_5BAE8C10-C6C0-4190-8826-7A14FBE88AFD, <code>https://farmalogg.no/varenummer</code>/591405</p><p><b>name</b>: Xeljanz tab 5 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK47224.html#MedicinalProductDefinition_IBD-MPD-63\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_22849E0B-A45A-413E-A7DC-25D861B28B46</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_5BAE8C10-C6C0-4190-8826-7A14FBE88AFD"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "591405"
      }],
      "name" : "Xeljanz tab 5 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-63"
      }]
    }
  },
  {
    "fullUrl" : "https://gravitatehealth.eu/fhir/nordic-epi/PackagedProductDefinition/IBD-PPD-75",
    "resource" : {
      "resourceType" : "PackagedProductDefinition",
      "id" : "IBD-PPD-75",
      "meta" : {
        "profile" : ["http://hl7.org/fhir/uv/emedicinal-product-info/StructureDefinition/PackagedProductDefinition-uv-epi",
        "https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PackagedProductDefinition_IBD-PPD-75\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PackagedProductDefinition IBD-PPD-75</b></p><a name=\"IBD-PPD-75\"> </a><a name=\"hcIBD-PPD-75\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"http://hl7.org/fhir/uv/emedicinal-product-info/STU1/StructureDefinition-PackagedProductDefinition-uv-epi.html\">PackagedProductDefinition (ePI)</a>, <code>https://gravitatehealth.eu/fhir/nordic-epi-ig/StructureDefinition/Nordic-ePI-PackagedProductDefinition</code></p></div><p><b>identifier</b>: <code>http://legemiddelverket.no/FEST/LegemiddelPakningID</code>/ID_D3424D7B-C2AD-4D10-9886-5EA24746C59C, <code>https://farmalogg.no/varenummer</code>/456804</p><p><b>name</b>: Xeljanz tab 5 mg</p><p><b>packageFor</b>: <a href=\"Bundle-FK47224.html#MedicinalProductDefinition_IBD-MPD-63\">MedicinalProductDefinition: identifier = http://legemiddelverket.no/FEST/LegemiddelMerkevareID#ID_22849E0B-A45A-413E-A7DC-25D861B28B46</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://legemiddelverket.no/FEST/LegemiddelPakningID",
        "value" : "ID_D3424D7B-C2AD-4D10-9886-5EA24746C59C"
      },
      {
        "system" : "https://farmalogg.no/varenummer",
        "value" : "456804"
      }],
      "name" : "Xeljanz tab 5 mg",
      "packageFor" : [{
        "reference" : "MedicinalProductDefinition/IBD-MPD-63"
      }]
    }
  }]
}

```
